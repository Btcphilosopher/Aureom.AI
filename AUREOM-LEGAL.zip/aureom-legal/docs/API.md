# API reference

Generated from the running application by `scripts/export_openapi.py` (`docs/openapi.json` is the machine-readable OpenAPI 3 document;
interactive docs are served at `/api/docs` when the API is running). All paths are under `/api/v1`.

## Conventions

* **Auth**: `POST /auth/login` sets an HttpOnly session cookie and returns `csrf_token`; send it as `X-CSRF-Token` on every non-GET request. `POST /auth/demo-login` exists only when `DEMO_MODE=true`.
* **Errors**: `{"error": {"code", "message", "details"}}` — e.g. `permission_denied` (403), `matter_access_denied` (403), `not_found` (404; also used for other firms' records), `version_conflict` (409), `invalid_state` (409), `approval_required` / `approval_stale` (409), `integration_unavailable` (503), `budget_exceeded` (429).
* **Pagination**: `limit` (1–200, default 50) and `offset`; responses are `{items, total, limit, offset}`.
* **Optimistic concurrency**: mutable records carry `version`; send `expected_version` on PATCH/PUT. A mismatch returns 409 `version_conflict`.
* **Money**: decimal strings (never floats), explicit `currency` (GBP default).
* **Approvals**: actions needing authorisation return **202** with an `approval_id` (and the bound `payload_hash`); a different authorised person decides; the action is then executed with the approved payload. Content changes invalidate the approval.
* **Simulated results** are labelled (`simulated: true`, mock provider names, `SYNTHETIC`/`SIMULATED` text).

## administration

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/admin/audit` | Matter-linked events on restricted/walled matters the viewer cannot access are excluded (summaries could reveal them). |
| GET | `/api/v1/admin/audit.csv` | Audit Csv |
| GET | `/api/v1/admin/audit/verify` | Audit Verify |
| GET | `/api/v1/admin/offices` | Offices |
| POST | `/api/v1/admin/offices` | Create Office |
| GET | `/api/v1/admin/retention` | Retention |
| POST | `/api/v1/admin/retention` | Upsert Retention |
| GET | `/api/v1/admin/roles` | List Roles |
| PUT | `/api/v1/admin/roles/{role_id}` | Update Role |
| GET | `/api/v1/admin/settings` | Get Firm Settings |
| PUT | `/api/v1/admin/settings` | Put Firm Settings |
| GET | `/api/v1/admin/system` | System |
| GET | `/api/v1/admin/teams` | Teams |
| POST | `/api/v1/admin/teams` | Create Team |
| GET | `/api/v1/admin/users` | List Users |
| POST | `/api/v1/admin/users` | Create User |
| PATCH | `/api/v1/admin/users/{user_id}` | Update User |
| POST | `/api/v1/admin/users/{user_id}/reset-password` | Reset Password |

## ai-workspace

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/agents` | Catalog |
| GET | `/api/v1/agents/provider` | Provider Info |
| GET | `/api/v1/agents/runs` | List Runs |
| POST | `/api/v1/agents/runs` | Start |
| GET | `/api/v1/agents/runs/{run_id}` | Get Run |
| PATCH | `/api/v1/agents/runs/{run_id}/actions/{action_id}` | Edit Action |
| POST | `/api/v1/agents/runs/{run_id}/cancel` | Cancel |
| POST | `/api/v1/agents/runs/{run_id}/retry` | Retry |
| POST | `/api/v1/agents/runs/{run_id}/review` | Review |
| GET | `/api/v1/agents/usage` | Usage |

## approvals

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/approvals` | scope: waiting_for_me (pending, I hold the permission, not my own request) \| requested_by_me \| all (audit.read). |
| GET | `/api/v1/approvals/{approval_id}` | Get Approval |

## auth

| Method | Path | Description |
|---|---|---|
| POST | `/api/v1/auth/demo-login` | Persona picker for the demonstration. Disabled unless DEMO_MODE=true; never enable in production. |
| GET | `/api/v1/auth/directory` | Minimal staff/team/office/retention directory for pickers (assignees, partners, teams). Names and roles only - |
| POST | `/api/v1/auth/login` | Login |
| POST | `/api/v1/auth/logout` | Logout |
| GET | `/api/v1/auth/me` | Me |
| POST | `/api/v1/auth/office` | Office/team selector: a UI filter preference stored on the session; it never widens access. |
| GET | `/api/v1/auth/personas` | Personas |
| GET | `/api/v1/auth/sso/start` | SSO boundary: an OIDC provider adapter plugs in here. Not configured in this build. |

## billing

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/billing/invoices` | List Invoices |
| POST | `/api/v1/billing/invoices` | Create Invoice |
| GET | `/api/v1/billing/invoices/{invoice_id}` | Get Invoice |
| PATCH | `/api/v1/billing/invoices/{invoice_id}` | Patch Invoice |
| POST | `/api/v1/billing/invoices/{invoice_id}/credit-note` | Credit Note |
| POST | `/api/v1/billing/invoices/{invoice_id}/decision` | Partner approves or rejects the exact invoice content (four-eyes: not the person who submitted it). |
| POST | `/api/v1/billing/invoices/{invoice_id}/issue` | Issue Invoice |
| POST | `/api/v1/billing/invoices/{invoice_id}/submit` | Submit Invoice |
| POST | `/api/v1/billing/invoices/{invoice_id}/void` | Void Invoice |
| GET | `/api/v1/billing/matters/{matter_id}/unbilled` | Candidate time entries and expenses for a new draft invoice. |
| GET | `/api/v1/billing/rate-cards` | List Rate Cards |
| POST | `/api/v1/billing/rate-cards` | Create Rate Card |
| PUT | `/api/v1/billing/rate-cards/{rate_card_id}/entries` | Put Rate Entries |

## client portal

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/portal/documents/{document_id}/download` | Download |
| GET | `/api/v1/portal/matters` | My Matters |
| GET | `/api/v1/portal/matters/{matter_id}` | Matter |
| GET | `/api/v1/portal/matters/{matter_id}/correspondence` | Correspondence |
| GET | `/api/v1/portal/matters/{matter_id}/documents` | Documents |
| GET | `/api/v1/portal/matters/{matter_id}/invoices` | Invoices |

## clients

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/clients` | List Clients |
| POST | `/api/v1/clients` | Create Client |
| GET | `/api/v1/clients/duplicates` | Duplicates |
| GET | `/api/v1/clients/lookup/companies-house` | Demonstrates the integration-unavailable state: the provider is not configured, so this returns HTTP 503. |
| GET | `/api/v1/clients/merges` | List Merges |
| POST | `/api/v1/clients/merges` | Propose Merge |
| POST | `/api/v1/clients/merges/{merge_id}/complete` | Complete Merge |
| POST | `/api/v1/clients/merges/{merge_id}/reject` | Reject Merge |
| GET | `/api/v1/clients/{contact_id}` | Get Client |
| PATCH | `/api/v1/clients/{contact_id}` | Patch Client |
| POST | `/api/v1/clients/{contact_id}/addresses` | Add Address |
| DELETE | `/api/v1/clients/{contact_id}/addresses/{address_id}` | Delete Address |
| PATCH | `/api/v1/clients/{contact_id}/addresses/{address_id}` | Patch Address |
| GET | `/api/v1/clients/{contact_id}/onboarding` | Get Onboarding |
| POST | `/api/v1/clients/{contact_id}/onboarding` | Start Onboarding |
| POST | `/api/v1/clients/{contact_id}/onboarding/approve` | Approve Onboarding |
| POST | `/api/v1/clients/{contact_id}/onboarding/checks` | Run Check |
| POST | `/api/v1/clients/{contact_id}/onboarding/checks/{check_id}/review` | Review Check |
| POST | `/api/v1/clients/{contact_id}/onboarding/checks/{check_id}/waive` | Waive Check |
| PUT | `/api/v1/clients/{contact_id}/onboarding/form` | Submit Form |
| POST | `/api/v1/clients/{contact_id}/onboarding/reject` | Reject Onboarding |
| POST | `/api/v1/clients/{contact_id}/onboarding/submit` | Submit Onboarding |
| POST | `/api/v1/clients/{contact_id}/relationships` | Add Relationship |
| DELETE | `/api/v1/clients/{contact_id}/relationships/{rid}` | Delete Relationship |
| PATCH | `/api/v1/clients/{contact_id}/relationships/{rid}` | Patch Relationship |

## conflicts

| Method | Path | Description |
|---|---|---|
| PATCH | `/api/v1/conflicts/matches/{match_id}` | Review Match |
| GET | `/api/v1/conflicts/searches` | List Searches |
| POST | `/api/v1/conflicts/searches` | Run Search |
| GET | `/api/v1/conflicts/searches/{search_id}` | Get Search |
| POST | `/api/v1/conflicts/searches/{search_id}/decision` | Decide |

## correspondence

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/correspondence` | List Correspondence |
| POST | `/api/v1/correspondence` | Create Draft |
| GET | `/api/v1/correspondence/client-view` | Preview of exactly what an authorised client would see for a matter (no drafts, notes or approval data). |
| GET | `/api/v1/correspondence/matter-notes` | Matter Notes |
| POST | `/api/v1/correspondence/matter-notes` | Add Matter Note |
| POST | `/api/v1/correspondence/sync` | Pull new messages from the configured mailbox provider (a SIMULATED mailbox in this build). Idempotent. |
| GET | `/api/v1/correspondence/{corr_id}` | Get One |
| PATCH | `/api/v1/correspondence/{corr_id}` | Edit Draft |
| POST | `/api/v1/correspondence/{corr_id}/approve` | Approve |
| POST | `/api/v1/correspondence/{corr_id}/file` | File To Matter |
| GET | `/api/v1/correspondence/{corr_id}/notes` | List Notes |
| POST | `/api/v1/correspondence/{corr_id}/notes` | Add Note |
| POST | `/api/v1/correspondence/{corr_id}/read` | Mark Read |
| POST | `/api/v1/correspondence/{corr_id}/request-approval` | Request Approval |
| POST | `/api/v1/correspondence/{corr_id}/send` | Sends via the e-mail provider (SIMULATED in this build). Refused unless the exact current content is approved. |

## diary

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/diary/calendars` | List Calendars |
| POST | `/api/v1/diary/calendars` | Create Calendar |
| PATCH | `/api/v1/diary/calendars/{calendar_id}` | Update Calendar |
| GET | `/api/v1/diary/calendars/{calendar_id}/holidays` | List Holidays |
| POST | `/api/v1/diary/calendars/{calendar_id}/holidays` | Add Holiday |
| POST | `/api/v1/diary/calendars/{calendar_id}/holidays/import` | Bulk input of bank-holiday data. The source note records where the data came from and who loaded it. |
| DELETE | `/api/v1/diary/calendars/{calendar_id}/holidays/{holiday_id}` | Remove Holiday |
| GET | `/api/v1/diary/deadline-rules` | List Rules |
| POST | `/api/v1/diary/deadline-rules` | Create Rule |
| PATCH | `/api/v1/diary/deadline-rules/{rule_id}` | Update Rule |
| GET | `/api/v1/diary/deadlines` | List Deadlines |
| POST | `/api/v1/diary/deadlines` | Create Deadline |
| POST | `/api/v1/diary/deadlines/calculate` | Creates an UNCONFIRMED suggestion with its full calculation record. It is not authoritative until confirmed. |
| GET | `/api/v1/diary/deadlines/{deadline_id}` | Get Deadline |
| PATCH | `/api/v1/diary/deadlines/{deadline_id}` | Patch Deadline |
| POST | `/api/v1/diary/deadlines/{deadline_id}/confirm` | Confirm Deadline |
| POST | `/api/v1/diary/deadlines/{deadline_id}/reject` | Reject Deadline |
| GET | `/api/v1/diary/events` | List Events |
| POST | `/api/v1/diary/events` | Create Event |
| DELETE | `/api/v1/diary/events/{event_id}` | Delete Event |
| GET | `/api/v1/diary/events/{event_id}` | Get Event |
| PATCH | `/api/v1/diary/events/{event_id}` | Patch Event |
| POST | `/api/v1/diary/events/{event_id}/sync` | Sync Event |
| GET | `/api/v1/diary/feed` | Feed |
| GET | `/api/v1/diary/ics` | Ics |

## documents

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/documents` | List Documents |
| POST | `/api/v1/documents` | Multipart upload (drag-and-drop). The file is validated by extension AND content, stored write-once, then scanned/OCR'd/indexed by the worker. |
| GET | `/api/v1/documents/exports` | List Exports |
| POST | `/api/v1/documents/exports` | Request Export |
| GET | `/api/v1/documents/exports/{export_id}` | Get Export |
| POST | `/api/v1/documents/exports/{export_id}/decision` | Decide Export |
| GET | `/api/v1/documents/exports/{export_id}/download` | Download Export |
| GET | `/api/v1/documents/folders` | List Folders |
| POST | `/api/v1/documents/folders` | Create Folder |
| DELETE | `/api/v1/documents/folders/{folder_id}` | Delete Folder |
| PATCH | `/api/v1/documents/folders/{folder_id}` | Rename Folder |
| GET | `/api/v1/documents/search` | Full-text search over extracted text of CURRENT versions, only in documents the user may see. |
| POST | `/api/v1/documents/signature-requests/{sr_id}/simulate-complete` | SIMULATED: stands in for the e-signature provider's completion webhook. Only available while the provider is a mock. |
| GET | `/api/v1/documents/templates` | List Templates |
| POST | `/api/v1/documents/templates` | Create Template |
| GET | `/api/v1/documents/templates/{template_id}` | Get Template |
| PATCH | `/api/v1/documents/templates/{template_id}` | Update Template |
| POST | `/api/v1/documents/templates/{template_id}/approve` | Approve Template |
| POST | `/api/v1/documents/templates/{template_id}/generate` | Generate From Template |
| POST | `/api/v1/documents/templates/{template_id}/preview` | Previewed field substitution. Nothing is stored. Shows which fields are missing. |
| GET | `/api/v1/documents/{document_id}` | Get Document |
| PATCH | `/api/v1/documents/{document_id}` | Patch Document |
| POST | `/api/v1/documents/{document_id}/approve` | Approve |
| GET | `/api/v1/documents/{document_id}/compare` | Compare |
| POST | `/api/v1/documents/{document_id}/legal-hold` | Legal Hold |
| POST | `/api/v1/documents/{document_id}/retention` | Retention |
| POST | `/api/v1/documents/{document_id}/review-request` | Review Request |
| POST | `/api/v1/documents/{document_id}/signature-request` | Signature Request |
| POST | `/api/v1/documents/{document_id}/supersede` | Supersede |
| POST | `/api/v1/documents/{document_id}/versions` | Add Version |
| GET | `/api/v1/documents/{document_id}/versions/{version_no}/download` | Original bytes, served as an attachment with nosniff + sandbox CSP. Blocked unless scan is clean, the matter permits export, and the user may preview. |
| GET | `/api/v1/documents/{document_id}/versions/{version_no}/preview` | SAFE preview: extracted plain text with page/paragraph references. The original file is never rendered in the browser. |

## home

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/home` | Home |

## integrations

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/integrations` | Every external dependency, its current mode (mock/live/unavailable) and what data would leave the application if live. |
| GET | `/api/v1/integrations/{key}` | Get Integration |

## knowledge

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/knowledge` | List Items |
| POST | `/api/v1/knowledge` | Create |
| GET | `/api/v1/knowledge/search` | APPROVED items only (even for managers): this is what the knowledge agent may rely on. |
| DELETE | `/api/v1/knowledge/{kid}` | Delete |
| GET | `/api/v1/knowledge/{kid}` | Get Item |
| PATCH | `/api/v1/knowledge/{kid}` | Update |
| POST | `/api/v1/knowledge/{kid}/approval` | Approval |

## ledger

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/ledger/accounts` | Accounts |
| GET | `/api/v1/ledger/accounts/{account_id}/lines` | Account Lines |
| POST | `/api/v1/ledger/approvals/{approval_id}/decision` | Authorise or reject a ledger action (journal, receipt allocation, client-money transfer, revenue recognition). Four-eyes applies. |
| POST | `/api/v1/ledger/bank-feed/sync` | Bank Sync |
| GET | `/api/v1/ledger/bank-lines` | Bank Lines |
| POST | `/api/v1/ledger/client-transfers` | Move client money to office account to settle an issued invoice. Requires separate human authorisation (four-eyes). |
| GET | `/api/v1/ledger/journals` | List Journals |
| POST | `/api/v1/ledger/journals` | Create Journal |
| GET | `/api/v1/ledger/journals/{journal_id}` | Get Journal |
| POST | `/api/v1/ledger/journals/{journal_id}/decision` | Decide Journal |
| POST | `/api/v1/ledger/journals/{journal_id}/post` | Post Journal |
| POST | `/api/v1/ledger/journals/{journal_id}/reverse` | Reverse Journal |
| POST | `/api/v1/ledger/journals/{journal_id}/submit` | Submit Journal |
| GET | `/api/v1/ledger/matters/{matter_id}/client-balance` | Matter Client Balance |
| GET | `/api/v1/ledger/payments` | List Payments |
| POST | `/api/v1/ledger/payments` | Record a bank receipt (creates a payment + draft journal awaiting authorisation). Not revenue. |
| POST | `/api/v1/ledger/payments/{payment_id}/allocate` | Without approval_id: requests authorisation (202, returns the approval). With an approved approval_id: executes atomically (200). |
| GET | `/api/v1/ledger/reconciliations` | List Recs |
| POST | `/api/v1/ledger/reconciliations` | Create Rec |
| GET | `/api/v1/ledger/reconciliations/{rec_id}` | Get Rec |
| POST | `/api/v1/ledger/reconciliations/{rec_id}/match` | Match |
| POST | `/api/v1/ledger/reconciliations/{rec_id}/sign-off` | Sign Off |
| GET | `/api/v1/ledger/revenue-recognition` | List Recognitions |
| POST | `/api/v1/ledger/revenue-recognition` | Creates the draft recognition journal + approval request. Revenue is recognised only when that journal is authorised and posted. |
| GET | `/api/v1/ledger/trial-balance` | Trial Balance |

## matters

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/matters` | Restricted / ethical-wall matters the caller cannot access are excluded from items AND from the total. |
| POST | `/api/v1/matters` | Create Matter |
| GET | `/api/v1/matters/templates` | List Templates |
| POST | `/api/v1/matters/templates` | Create Template |
| DELETE | `/api/v1/matters/templates/{template_id}` | Deactivate Template |
| GET | `/api/v1/matters/templates/{template_id}` | Get Template |
| PUT | `/api/v1/matters/templates/{template_id}` | Update Template |
| GET | `/api/v1/matters/{matter_id}` | Get Matter |
| PATCH | `/api/v1/matters/{matter_id}` | Patch Matter |
| PUT | `/api/v1/matters/{matter_id}/access` | Set Access |
| GET | `/api/v1/matters/{matter_id}/activity` | Matter Activity |
| POST | `/api/v1/matters/{matter_id}/checklist` | Add Checklist Item |
| POST | `/api/v1/matters/{matter_id}/checklist/{item_id}` | Toggle Checklist |
| GET | `/api/v1/matters/{matter_id}/chronology` | Chronology |
| POST | `/api/v1/matters/{matter_id}/chronology` | Add Chronology |
| DELETE | `/api/v1/matters/{matter_id}/chronology/{entry_id}` | Delete Chronology |
| PATCH | `/api/v1/matters/{matter_id}/chronology/{entry_id}` | Patch Chronology |
| POST | `/api/v1/matters/{matter_id}/legal-hold` | Legal Hold |
| POST | `/api/v1/matters/{matter_id}/members` | Add Member |
| DELETE | `/api/v1/matters/{matter_id}/members/{member_id}` | Remove Member |
| POST | `/api/v1/matters/{matter_id}/parties` | Add Party |
| DELETE | `/api/v1/matters/{matter_id}/parties/{party_id}` | Remove Party |
| PUT | `/api/v1/matters/{matter_id}/retention` | Retention |
| POST | `/api/v1/matters/{matter_id}/stage` | Change Stage |
| GET | `/api/v1/matters/{matter_id}/summary` | Matter Summary |
| POST | `/api/v1/matters/{matter_id}/transitions` | Transition |
| GET | `/api/v1/matters/{matter_id}/transitions/available` | Transitions Available |
| POST | `/api/v1/matters/{matter_id}/transitions/{approval_id}/decide` | Decide Transition |

## notifications

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/notifications` | List Notifications |
| POST | `/api/v1/notifications/read-all` | Read All |
| POST | `/api/v1/notifications/{notification_id}/read` | Read One |

## reports

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/reports` | Catalogue of reports and the permission each needs |
| GET | `/api/v1/reports/{name}` | Report |
| GET | `/api/v1/reports/{name}.csv` | CSV export (audited as a sensitive export) |

## search

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/search` | Global Search |

## system

| Method | Path | Description |
|---|---|---|
| GET | `/api/health` | Health |

## tasks

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/tasks` | List Tasks |
| POST | `/api/v1/tasks` | Create |
| GET | `/api/v1/tasks/{task_id}` | Get |
| PATCH | `/api/v1/tasks/{task_id}` | Patch |
| POST | `/api/v1/tasks/{task_id}/cancel` | Cancel |
| POST | `/api/v1/tasks/{task_id}/complete` | Complete |
| GET | `/api/v1/tasks/{task_id}/dependencies` | Dependencies |
| POST | `/api/v1/tasks/{task_id}/dependencies` | Add Dependency |
| DELETE | `/api/v1/tasks/{task_id}/dependencies/{depends_on_id}` | Remove Dependency |
| POST | `/api/v1/tasks/{task_id}/reopen` | Reopen |
| POST | `/api/v1/tasks/{task_id}/start` | Start |

## time & expenses

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/time/entries` | List Entries |
| POST | `/api/v1/time/entries` | Create Entry |
| DELETE | `/api/v1/time/entries/{entry_id}` | Delete Entry |
| PATCH | `/api/v1/time/entries/{entry_id}` | Patch Entry |
| POST | `/api/v1/time/entries/{entry_id}/approve` | Approve Entry |
| POST | `/api/v1/time/entries/{entry_id}/submit` | Submit Entry |
| POST | `/api/v1/time/entries/{entry_id}/write-off` | Writeoff Entry |
| GET | `/api/v1/time/expenses` | List Expenses |
| POST | `/api/v1/time/expenses` | Create Expense |
| PATCH | `/api/v1/time/expenses/{expense_id}` | Patch Expense |
| POST | `/api/v1/time/expenses/{expense_id}/approve` | Approve Expense |
| POST | `/api/v1/time/expenses/{expense_id}/write-off` | Writeoff Expense |
| GET | `/api/v1/time/home-summary` | Home Summary |
| GET | `/api/v1/time/matters/{matter_id}/budget` | Matter Budget |
| GET | `/api/v1/time/timer` | Get Timer |
| POST | `/api/v1/time/timer/start` | Timer Start |
| POST | `/api/v1/time/timer/stop` | Timer Stop |
