# AUREOM LEGAL — Practice Database & Intelligence

A law-firm management platform for a **fictional** UK firm, *Pennine & Calder Solicitors* (Leeds, Manchester, Halifax). The **matter** is the centre of the system:
clients and parties, documents, correspondence, tasks and deadlines, time, billing and ledgers, approvals and controlled AI activity all hang off it.

> **Demonstration build. All data is synthetic.** Integrations (email, calendar, e-signature, bank feed, identity checks, malware scanning, OCR, legal research, SSO) are
> clearly labelled mocks or unavailable adapters. See [`docs/IMPLEMENTATION_STATUS.md`](docs/IMPLEMENTATION_STATUS.md) for exactly what is implemented, simulated and dependent on external services,
> and [`docs/COMPLIANCE_REVIEW.md`](docs/COMPLIANCE_REVIEW.md) for the professional and regulatory review required before any real use. No compliance certification is claimed.

**Stack:** React 18 + TypeScript + Tailwind (Vite) · Python 3.12 + FastAPI + SQLAlchemy 2 · PostgreSQL 16 (relational data, full-text search, row-level security) · S3-compatible object storage (MinIO) · PostgreSQL-backed background worker · Docker Compose.

## Quick start (Docker)

```bash
cp .env.example .env            # development defaults; edit if you wish
docker compose up --build
```

Then open **http://localhost:5173** → choose a persona (demo mode) or sign in with `daniel.rhodes@pennine-calder.example` / `pennine-demo-2026`.
API docs: http://localhost:8000/api/docs · MinIO console: http://localhost:9001.
The `api` container applies the migrations and seeds the demonstration firm on first start; the `worker` container runs OCR/scan/index/export/agent jobs.

## Quick start without Docker

Requires PostgreSQL 14+ (with a superuser connection), Python 3.11+ and Node 20+.

```bash
# 1. backend dependencies
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements.txt

# 2. database + non-superuser app role + migrations + demo seed (writes backend/.env)
PG_ADMIN_URL=postgresql://postgres:postgres@localhost:5432/postgres ./scripts/local_setup.sh

# 3. API (EMBEDDED_WORKER=true in backend/.env runs the background worker in-process)
cd backend && python -m uvicorn app.main:app --reload --port 8000

# 4. frontend (new terminal)
cd frontend && npm install && npm run dev          # http://localhost:5173  (proxies /api to :8000)
```

## Tests and checks

```bash
cd backend
pip install -r requirements-dev.txt
export TEST_ADMIN_URL=postgresql+psycopg://postgres:postgres@localhost:5432/postgres   # a PostgreSQL superuser; tests create/drop throw-away databases
python -m pytest -q                                 # full backend suite
TEST_USE_MIGRATIONS=1 python -m pytest -q tests/test_e2e_demo.py tests/test_platform_safeguards.py   # same tests on a schema built by Alembic
alembic check                                       # models and migrations are in sync (needs a migrated database)

cd ../frontend && npm run typecheck && npm run build
```

Backend tests run against a real PostgreSQL as a **non-superuser** role, so row-level security is genuinely enforced.

## Demonstration

Follow [`docs/DEMO_SCRIPT.md`](docs/DEMO_SCRIPT.md) or open **Guided demonstration** in the sidebar. The 11-step workflow
(prospective client → conflict review → simulated onboarding → restricted matter → agreement upload & versioning → document-review & chronology agents →
confirm suggested task & deadline → approve a draft client message → time & draft invoice → allocate a synthetic receipt & reconcile → close with retention)
is also executed end to end, through the public API, by `backend/tests/test_e2e_demo.py`.
Sample files for the UI are in [`sample-docs/`](sample-docs/) (including a hostile document used to demonstrate prompt-injection handling).

Seeded personas (password for all: `pennine-demo-2026`; the persona picker works without it in demo mode):

| Persona | Role | Use it to… |
|---|---|---|
| Daniel Rhodes | Solicitor (commercial) | run most of the workflow |
| Eleanor Whitcombe | Partner (corporate & commercial) | approve matter opening / invoices / messages |
| Margaret Thackray | Compliance (COLP & MLRO) | review conflicts, approve onboarding, audit log |
| Nadia Siddiqui / Colin Whitaker | Finance | issue invoices, receipts, allocations, reconciliation (four-eyes) |
| Ben Holroyd | Paralegal | see permission limits (cannot confirm deadlines) |
| Oliver Bancroft | Administrator | users, roles, settings, audit, integrations (no matter content access) |
| Anna Hartley | Authorised client | the client portal |

## Repository layout

```
backend/   FastAPI app (app/api, services, models, agents, integrations, storage, seed), Alembic migrations, tests
frontend/  React + TypeScript + Tailwind SPA (src/pages per sidebar section, src/components/ui design system)
docs/      ARCHITECTURE, SECURITY, API (+openapi.json), BACKUP_RESTORE, COMPLIANCE_REVIEW, IMPLEMENTATION_STATUS, DEMO_SCRIPT
docker/    Postgres role bootstrap       scripts/  local setup, sample-doc + OpenAPI generators      sample-docs/  fictional files
```

`backend/CONVENTIONS.md` documents the module contracts (request context, permissions, approvals, jobs, storage, finance conventions).

## Configuration

See [`.env.example`](.env.example). Key switches: `DEMO_MODE` (persona picker — **never** enable outside demonstrations), `STORAGE_BACKEND` (`s3`|`local`), `AI_PROVIDER` (`mock`|`anthropic`),
`DATA_RESIDENCY`, `ALLOW_UNSCANNED_DOWNLOADS`, `SECRET_KEY`. Credentials are read server-side only.

## Backup and restore

See [`docs/BACKUP_RESTORE.md`](docs/BACKUP_RESTORE.md): back up PostgreSQL and the documents bucket together, then verify the audit hash chain after restore.
