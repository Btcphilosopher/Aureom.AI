Fictional sample documents for AUREOM LEGAL demonstrations. All names are invented.

* Distribution Agreement v1/v2 (PDF): upload v1 to a matter, then upload v2 as a new version of the same document to see version history and comparison.
* Client instruction email.txt: note it states a different start date (1 April 2027) from the agreement (1 March 2027) - the chronology agent should flag the contradiction.
* HOSTILE schedule (test): contains instruction-like text aimed at an AI assistant. The platform must treat it as data, flag it, and never act on it.
