#!/usr/bin/env bash
# Local (non-Docker) setup: creates the database + the NON-superuser app role, writes backend/.env, runs migrations and seeds the demo firm.
#
#   PG_ADMIN_URL=postgresql://postgres:postgres@localhost:5432/postgres ./scripts/local_setup.sh
#
# Requires: PostgreSQL 14+ client+server (psql on PATH), Python 3.11+ with `pip install -r backend/requirements.txt`.
set -euo pipefail
cd "$(dirname "$0")/.."

PG_ADMIN_URL="${PG_ADMIN_URL:-postgresql://postgres:postgres@localhost:5432/postgres}"   # a superuser connection
DB_NAME="${AUREOM_DB:-aureom}"
APP_PASSWORD="${APP_DB_PASSWORD:-aureom_app_dev}"
PY="${PYTHON:-python3}"

# split the admin URL into pieces for building the other URLs
IFS="|" read -r PG_USER PG_PASS PG_HOST PG_PORT < <("$PY" - "$PG_ADMIN_URL" <<'PYEOF'
import sys; from urllib.parse import urlparse
u = urlparse(sys.argv[1]); print("|".join([u.username or "postgres", u.password or "", u.hostname or "localhost", str(u.port or 5432)]))
PYEOF
)
auth="${PG_USER}"; [ -n "${PG_PASS}" ] && auth="${PG_USER}:${PG_PASS}"
OWNER_URL="postgresql+psycopg://${auth}@${PG_HOST}:${PG_PORT}/${DB_NAME}"
APP_URL="postgresql+psycopg://aureom_app:${APP_PASSWORD}@${PG_HOST}:${PG_PORT}/${DB_NAME}"

echo "==> Creating database '${DB_NAME}' and role 'aureom_app' (NOSUPERUSER NOBYPASSRLS)"
psql "$PG_ADMIN_URL" -v ON_ERROR_STOP=1 -q <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aureom_app') THEN
    CREATE ROLE aureom_app LOGIN PASSWORD '${APP_PASSWORD}' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
  END IF;
END \$\$;
SELECT 'CREATE DATABASE ${DB_NAME}' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${DB_NAME}')\gexec
SQL

cat > backend/.env <<ENV
ENV=development
DATABASE_URL=${APP_URL}
MIGRATION_DATABASE_URL=${OWNER_URL}
STORAGE_BACKEND=local
LOCAL_STORAGE_PATH=./.storage
DEMO_MODE=true
EMBEDDED_WORKER=true
AI_PROVIDER=mock
ENV
echo "==> Wrote backend/.env"

cd backend
echo "==> Applying migrations"
"$PY" -m alembic upgrade head
echo "==> Seeding demonstration data (skipped if already present)"
"$PY" -m app.seed.demo --if-empty
echo
echo "Done. Start the API:      cd backend && $PY -m uvicorn app.main:app --reload --port 8000"
echo "      (EMBEDDED_WORKER=true runs the background worker inside the API process)"
echo "Start the frontend:       cd frontend && npm install && npm run dev      # http://localhost:5173"
