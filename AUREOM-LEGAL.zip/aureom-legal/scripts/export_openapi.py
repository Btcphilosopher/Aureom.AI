"""Export docs/openapi.json and docs/API.md (endpoint reference grouped by tag) from the live FastAPI app."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from app.main import create_app  # noqa: E402

app = create_app()
spec = app.openapi()
(ROOT / "docs" / "openapi.json").write_text(json.dumps(spec, indent=1))

by_tag: dict[str, list] = {}
for path, ops in spec["paths"].items():
    for method, op in ops.items():
        if method not in ("get", "post", "put", "patch", "delete"):
            continue
        tag = (op.get("tags") or ["other"])[0]
        summary = (op.get("summary") or "").strip()
        doc = (op.get("description") or "").strip().split("\n")[0]
        by_tag.setdefault(tag, []).append((path, method.upper(), summary, doc))

lines = ["# API reference", "",
         "Generated from the running application by `scripts/export_openapi.py` (`docs/openapi.json` is the machine-readable OpenAPI 3 document;",
         "interactive docs are served at `/api/docs` when the API is running). All paths are under `/api/v1`.", "",
         "## Conventions", "",
         "* **Auth**: `POST /auth/login` sets an HttpOnly session cookie and returns `csrf_token`; send it as `X-CSRF-Token` on every non-GET request. `POST /auth/demo-login` exists only when `DEMO_MODE=true`.",
         "* **Errors**: `{\"error\": {\"code\", \"message\", \"details\"}}` — e.g. `permission_denied` (403), `matter_access_denied` (403), `not_found` (404; also used for other firms' records), `version_conflict` (409), `invalid_state` (409), `approval_required` / `approval_stale` (409), `integration_unavailable` (503), `budget_exceeded` (429).",
         "* **Pagination**: `limit` (1–200, default 50) and `offset`; responses are `{items, total, limit, offset}`.",
         "* **Optimistic concurrency**: mutable records carry `version`; send `expected_version` on PATCH/PUT. A mismatch returns 409 `version_conflict`.",
         "* **Money**: decimal strings (never floats), explicit `currency` (GBP default).",
         "* **Approvals**: actions needing authorisation return **202** with an `approval_id` (and the bound `payload_hash`); a different authorised person decides; the action is then executed with the approved payload. Content changes invalidate the approval.",
         "* **Simulated results** are labelled (`simulated: true`, mock provider names, `SYNTHETIC`/`SIMULATED` text).", ""]
for tag in sorted(by_tag):
    lines += [f"## {tag}", "", "| Method | Path | Description |", "|---|---|---|"]
    for path, method, summary, doc in sorted(by_tag[tag]):
        desc = (doc or summary).replace("|", "\\|")[:150]
        lines.append(f"| {method} | `{path}` | {desc} |")
    lines.append("")
(ROOT / "docs" / "API.md").write_text("\n".join(lines))
print(sum(len(v) for v in by_tag.values()), "operations in", len(by_tag), "groups")
