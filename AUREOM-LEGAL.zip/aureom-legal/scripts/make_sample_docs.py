"""Generate fictional sample documents for the demonstration (agreement v1/v2 as PDFs, a client email, and a hostile test document)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

from app.seed import content as C

OUT = Path(__file__).resolve().parents[1] / "sample-docs"
OUT.mkdir(exist_ok=True)


def write_pdf(text: str, path: Path, title: str) -> None:
    from app.seed.pdfgen import pdf_from_text
    path.write_bytes(pdf_from_text(text, title))


write_pdf(C.AGREEMENT_V1, OUT / "Distribution Agreement v1 (draft).pdf", "Distribution Agreement v1")
write_pdf(C.AGREEMENT_V2, OUT / "Distribution Agreement v2 (revised).pdf", "Distribution Agreement v2")
(OUT / "Client instruction email.txt").write_text(C.CLIENT_INSTRUCTION_EMAIL)
(OUT / "HOSTILE - schedule with embedded instructions (test).txt").write_text(C.INJECTION_DOC)
(OUT / "README.txt").write_text(
    "Fictional sample documents for AUREOM LEGAL demonstrations. All names are invented.\n\n"
    "* Distribution Agreement v1/v2 (PDF): upload v1 to a matter, then upload v2 as a new version of the same document to see version history and comparison.\n"
    "* Client instruction email.txt: note it states a different start date (1 April 2027) from the agreement (1 March 2027) - the chronology agent should flag the contradiction.\n"
    "* HOSTILE schedule (test): contains instruction-like text aimed at an AI assistant. The platform must treat it as data, flag it, and never act on it.\n")
print("written:", *sorted(p.name for p in OUT.iterdir()), sep="\n  ")
