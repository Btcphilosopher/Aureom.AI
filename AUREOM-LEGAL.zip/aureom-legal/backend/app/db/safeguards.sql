-- Database-level safeguards. Idempotent; executed by migration 0002 and by the test bootstrap.
-- 1) Tenant isolation (row-level security) 2) append-only audit 3) immutable document originals
-- 4) balanced, immutable posted journals 5) deadline authority

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------- 1. Row-level security
-- Auth bootstrap tables (users/sessions/firms) and the worker job queue (jobs: ids only, no content) are exempt: login must resolve a user before a tenant is known.
-- Every other table with a firm_id column is isolated by the app.firm_id GUC set per transaction.
DO $$
DECLARE t record;
BEGIN
  FOR t IN
    SELECT c.table_name FROM information_schema.columns c
    JOIN information_schema.tables tb ON tb.table_name = c.table_name AND tb.table_schema = c.table_schema AND tb.table_type = 'BASE TABLE'
    WHERE c.table_schema = 'public' AND c.column_name = 'firm_id'
      AND c.table_name NOT IN ('users', 'sessions', 'jobs', 'alembic_version')
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t.table_name);
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON %I', t.table_name);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %I USING (firm_id = nullif(current_setting(''app.firm_id'', true), '''')::uuid) WITH CHECK (firm_id = nullif(current_setting(''app.firm_id'', true), '''')::uuid)',
      t.table_name);
  END LOOP;
END $$;

-- ---------------------------------------------------------------- 2. Append-only audit log
CREATE OR REPLACE FUNCTION aureom_block_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION '% on % is not permitted: table is append-only', TG_OP, TG_TABLE_NAME USING ERRCODE = 'insufficient_privilege';
END $$ LANGUAGE plpgsql;

DO $$
DECLARE tbl text;
BEGIN
  FOREACH tbl IN ARRAY ARRAY['audit_events', 'conflict_review_events', 'matter_state_events', 'revenue_recognitions', 'payment_allocations']
  LOOP
    IF to_regclass('public.' || tbl) IS NOT NULL THEN
      EXECUTE format('DROP TRIGGER IF EXISTS %I_no_update ON %I', tbl, tbl);
      EXECUTE format('CREATE TRIGGER %I_no_update BEFORE UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION aureom_block_mutation()', tbl, tbl);
    END IF;
  END LOOP;
END $$;
DROP TRIGGER IF EXISTS audit_events_no_truncate ON audit_events;
CREATE TRIGGER audit_events_no_truncate BEFORE TRUNCATE ON audit_events FOR EACH STATEMENT EXECUTE FUNCTION aureom_block_mutation();

-- ---------------------------------------------------------------- 3. Immutable document originals
CREATE OR REPLACE FUNCTION aureom_document_version_immutable() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'document_versions rows cannot be deleted (immutable originals)' USING ERRCODE = 'insufficient_privilege';
  END IF;
  IF NEW.storage_key <> OLD.storage_key OR NEW.sha256 <> OLD.sha256 OR NEW.size_bytes <> OLD.size_bytes
     OR NEW.content_type <> OLD.content_type OR NEW.original_filename <> OLD.original_filename
     OR NEW.author_id <> OLD.author_id OR NEW.version_no <> OLD.version_no OR NEW.document_id <> OLD.document_id
     OR NEW.created_at <> OLD.created_at THEN
    RAISE EXCEPTION 'document version % is immutable (original file, hash and authorship cannot change)', OLD.id USING ERRCODE = 'insufficient_privilege';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS document_versions_immutable ON document_versions;
CREATE TRIGGER document_versions_immutable BEFORE UPDATE OR DELETE ON document_versions FOR EACH ROW EXECUTE FUNCTION aureom_document_version_immutable();

-- ---------------------------------------------------------------- 4. Journals: balanced & immutable once posted
CREATE OR REPLACE FUNCTION aureom_journal_post_check() RETURNS trigger AS $$
DECLARE d numeric; c numeric; n int; bad int;
BEGIN
  IF NEW.status IN ('posted', 'reversed') AND (TG_OP = 'INSERT' OR OLD.status NOT IN ('posted', 'reversed')) THEN
    SELECT coalesce(sum(debit),0), coalesce(sum(credit),0), count(*) INTO d, c, n FROM journal_lines WHERE journal_id = NEW.id;
    IF n < 2 THEN RAISE EXCEPTION 'journal % cannot be posted with fewer than two lines', NEW.id USING ERRCODE = 'check_violation'; END IF;
    IF d <> c THEN RAISE EXCEPTION 'journal % is unbalanced: debits % <> credits %', NEW.id, d, c USING ERRCODE = 'check_violation'; END IF;
    SELECT count(*) INTO bad FROM journal_lines l JOIN ledger_accounts a ON a.id = l.account_id
      WHERE l.journal_id = NEW.id AND (a.ledger <> NEW.ledger OR a.currency <> NEW.currency);
    IF bad > 0 THEN RAISE EXCEPTION 'journal % mixes ledgers or currencies (office and client funds must stay separate)', NEW.id USING ERRCODE = 'check_violation'; END IF;
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.status IN ('posted', 'reversed') THEN
    IF NEW.status = 'posted' OR NEW.effective_date <> OLD.effective_date OR NEW.ledger <> OLD.ledger OR NEW.description <> OLD.description THEN
      RAISE EXCEPTION 'posted journal % is immutable; post a reversal instead', OLD.id USING ERRCODE = 'insufficient_privilege';
    END IF;
    IF NEW.status NOT IN ('reversed', 'posted') THEN RAISE EXCEPTION 'posted journal cannot return to %', NEW.status USING ERRCODE = 'insufficient_privilege'; END IF;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS journals_post_check ON journals;
CREATE TRIGGER journals_post_check BEFORE INSERT OR UPDATE ON journals FOR EACH ROW EXECUTE FUNCTION aureom_journal_post_check();

CREATE OR REPLACE FUNCTION aureom_journal_line_guard() RETURNS trigger AS $$
DECLARE st text; jid uuid;
BEGIN
  jid := CASE WHEN TG_OP = 'DELETE' THEN OLD.journal_id ELSE NEW.journal_id END;
  SELECT status INTO st FROM journals WHERE id = jid;
  -- reconciliation markers are the only permitted change on posted lines
  IF st IN ('posted', 'reversed') THEN
    IF TG_OP = 'UPDATE' AND NEW.journal_id = OLD.journal_id AND NEW.account_id = OLD.account_id AND NEW.debit = OLD.debit AND NEW.credit = OLD.credit THEN
      RETURN NEW;
    END IF;
    RAISE EXCEPTION 'lines of posted journal % are immutable', jid USING ERRCODE = 'insufficient_privilege';
  END IF;
  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS journal_lines_guard ON journal_lines;
CREATE TRIGGER journal_lines_guard BEFORE INSERT OR UPDATE OR DELETE ON journal_lines FOR EACH ROW EXECUTE FUNCTION aureom_journal_line_guard();

-- ---------------------------------------------------------------- 5. Permissions for the application role
-- The application connects as aureom_app (NOSUPERUSER, NOBYPASSRLS). Created by docker init / test bootstrap.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aureom_app') THEN
    EXECUTE 'GRANT USAGE ON SCHEMA public TO aureom_app';
    EXECUTE 'GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO aureom_app';
    EXECUTE 'GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO aureom_app';
    EXECUTE 'REVOKE UPDATE, DELETE, TRUNCATE ON audit_events FROM aureom_app';
    EXECUTE 'REVOKE UPDATE, DELETE, TRUNCATE ON conflict_review_events, matter_state_events, revenue_recognitions, payment_allocations FROM aureom_app';
    EXECUTE 'REVOKE DELETE, TRUNCATE ON document_versions FROM aureom_app';
    EXECUTE 'REVOKE DELETE, TRUNCATE ON journals, journal_lines FROM aureom_app';
    -- journal_lines: allow INSERT on drafts + UPDATE of reconciliation markers only
    EXECUTE 'GRANT DELETE ON journal_lines TO aureom_app';  -- guarded by trigger (draft lines only)
    EXECUTE 'GRANT DELETE ON journals TO aureom_app';       -- draft only: enforced by trigger below
  END IF;
END $$;

CREATE OR REPLACE FUNCTION aureom_journal_delete_guard() RETURNS trigger AS $$
BEGIN
  IF OLD.status <> 'draft' THEN RAISE EXCEPTION 'only draft journals can be deleted' USING ERRCODE = 'insufficient_privilege'; END IF;
  RETURN OLD;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS journals_delete_guard ON journals;
CREATE TRIGGER journals_delete_guard BEFORE DELETE ON journals FOR EACH ROW EXECUTE FUNCTION aureom_journal_delete_guard();
