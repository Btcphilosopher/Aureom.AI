"""Engine/session factory and tenant context.

Every request/worker transaction is bound to a firm. The firm id is written to the
PostgreSQL session variable ``app.firm_id`` at the start of every transaction so that
row-level security policies (see ``app/db/safeguards.sql``) can enforce tenant isolation
even if application code forgets a WHERE clause.
"""
from __future__ import annotations

import uuid
from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import Session, sessionmaker

from app.config import get_settings

_engine = None
_SessionLocal: sessionmaker[Session] | None = None


def get_engine():
    global _engine
    if _engine is None:
        _engine = create_engine(get_settings().database_url, pool_pre_ping=True, future=True)
    return _engine


def reset_engine() -> None:
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None


def session_factory() -> sessionmaker[Session]:
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, expire_on_commit=False, future=True)
    return _SessionLocal


@event.listens_for(Session, "after_begin")
def _apply_tenant(session: Session, transaction, connection) -> None:  # noqa: ANN001
    """Re-apply the tenant GUC on every new transaction of a session."""
    firm_id = session.info.get("firm_id")
    if firm_id is not None:
        connection.execute(text("SELECT set_config('app.firm_id', :f, true)"), {"f": str(firm_id)})


def bind_firm(session: Session, firm_id: uuid.UUID | str) -> None:
    """Bind a session to a firm. Takes effect for the current and all later transactions."""
    session.info["firm_id"] = str(firm_id)
    if session.in_transaction():
        session.connection().execute(text("SELECT set_config('app.firm_id', :f, true)"), {"f": str(firm_id)})


def new_session(firm_id: uuid.UUID | str | None = None) -> Session:
    s = session_factory()()
    if firm_id is not None:
        s.info["firm_id"] = str(firm_id)
    return s


@contextmanager
def session_scope(firm_id: uuid.UUID | str | None = None) -> Iterator[Session]:
    s = new_session(firm_id)
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()
