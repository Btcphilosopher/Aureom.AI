"""Decimal money helpers. Never use float for money."""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

TWO = Decimal("0.01")
ZERO = Decimal("0.00")


def D(v) -> Decimal:
    if isinstance(v, Decimal):
        return v
    if isinstance(v, float):
        raise TypeError("floats are not accepted for money; pass str/int/Decimal")
    return Decimal(str(v))


def q(v: Decimal) -> Decimal:
    return D(v).quantize(TWO, rounding=ROUND_HALF_UP)


def time_amount(minutes: int, hourly_rate: Decimal) -> Decimal:
    return q(Decimal(minutes) * D(hourly_rate) / Decimal(60))


def vat(net: Decimal, rate_pct: Decimal) -> Decimal:
    return q(D(net) * D(rate_pct) / Decimal(100))
