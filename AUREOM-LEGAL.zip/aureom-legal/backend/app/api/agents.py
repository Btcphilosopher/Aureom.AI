from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select

from app.agents import runner
from app.agents.agents import registry
from app.agents.llm import get_provider
from app.agents.policy import PROHIBITED_TOOLS
from app.config import get_settings
from app.deps import Ctx, get_ctx, require
from app.errors import ValidationFailed
from app.integrations import base as integrations
from app.models import AgentProposedAction, AgentRun, AgentRunEvent, Firm, Matter, User
from app.pagination import Page, PageParams, paginate
from app.schemas.agents import ActionEdit, ReviewIn, RunStart

router = APIRouter(prefix="/agents", tags=["ai-workspace"])


def _names(db, ids) -> dict:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    return {u.id: u.name for u in db.execute(select(User).where(User.id.in_(ids))).scalars()}


def _summary(run: AgentRun, names: dict, refs: dict, n_pending: int = 0, n_actions: int = 0) -> dict:
    return {"id": str(run.id), "agent_type": run.agent_type, "agent_name": registry()[run.agent_type].title, "status": run.status, "approval_state": run.approval_state,
            "matter_id": str(run.matter_id) if run.matter_id else None, "matter_reference": refs.get(run.matter_id), "contact_id": str(run.contact_id) if run.contact_id else None,
            "requested_by": str(run.requested_by), "requested_by_name": names.get(run.requested_by), "provider": run.provider, "model": run.model,
            "prompt_template_version": run.prompt_template_version, "cost_gbp": str(run.cost_gbp), "tokens_in": run.tokens_in, "tokens_out": run.tokens_out,
            "attempts": run.attempts, "created_at": run.created_at, "started_at": run.started_at, "finished_at": run.finished_at, "error": run.error,
            "summary": (run.result or {}).get("summary"), "proposed_actions": n_actions, "pending_actions": n_pending}


def _action(a: AgentProposedAction, names: dict) -> dict:
    return {"id": str(a.id), "action_type": a.action_type, "summary": a.summary, "params": a.params, "evidence": a.evidence, "risk": a.risk, "status": a.status,
            "approved_by": str(a.approved_by) if a.approved_by else None, "approved_by_name": names.get(a.approved_by), "approved_at": a.approved_at,
            "approved_hash": a.approved_hash, "params_hash": a.params_hash, "decision_note": a.decision_note, "executed_at": a.executed_at, "result": a.result, "error": a.error,
            "edit_count": a.edit_count, "edit_history": a.edit_history or [], "version": a.version, "approval_is_current": bool(a.approved_hash and a.status == "approved")}


def detail(ctx: Ctx, run: AgentRun) -> dict:
    db = ctx.db
    acts = db.execute(select(AgentProposedAction).where(AgentProposedAction.run_id == run.id).order_by(AgentProposedAction.created_at)).scalars().all()
    evs = db.execute(select(AgentRunEvent).where(AgentRunEvent.run_id == run.id).order_by(AgentRunEvent.created_at, AgentRunEvent.id)).scalars().all()
    names = _names(db, [run.requested_by, run.reviewed_by, *[a.approved_by for a in acts], *[e.actor_user_id for e in evs]])
    refs = {m.id: m.reference for m in db.execute(select(Matter).where(Matter.id == run.matter_id)).scalars()} if run.matter_id else {}
    d = _summary(run, names, refs, sum(1 for a in acts if a.status == "proposed"), len(acts))
    events = [{"id": str(e.id), "kind": e.kind, "summary": e.summary, "details": e.details, "actor_user_id": str(e.actor_user_id) if e.actor_user_id else None,
               "actor_name": names.get(e.actor_user_id), "created_at": e.created_at} for e in evs]
    d.update({"scope": run.scope, "input": run.input, "source_versions": run.source_versions, "result": run.result, "execution_result": run.execution_result,
              "actions": [_action(a, names) for a in acts], "events": events,
              "approval_history": [e for e in events if e["kind"] in ("human_decision", "human_edit", "execution")],
              "reviewed_by": str(run.reviewed_by) if run.reviewed_by else None, "reviewed_by_name": names.get(run.reviewed_by), "reviewed_at": run.reviewed_at,
              "max_attempts": run.max_attempts, "timeout_seconds": run.timeout_seconds, "version": run.version, "cancel_requested": run.cancel_requested,
              "provider_notice": "Mock provider: heuristic extraction, not a language model." if run.provider == "mock" else None})
    return d


def _sync_allowed(sync: bool) -> bool:
    if sync and get_settings().env == "production":
        raise ValidationFailed("sync execution is disabled in production; runs are processed by the worker.")
    return sync


@router.get("")
def catalog(ctx: Ctx = Depends(require("ai.use"))):
    return {"agents": [a.catalog() for a in registry().values()], "prohibited_tools": sorted(PROHIBITED_TOOLS),
            "notice": "Agents are read-only. They can only propose changes, which a human must review and approve. Agents run with your permissions."}


@router.get("/provider")
def provider_info(ctx: Ctx = Depends(get_ctx)):
    ctx.require("ai.use") if not ctx.has("ai.admin") else None
    firm = ctx.db.get(Firm, ctx.firm_id)
    cfg = runner.ai_settings(ctx.db, ctx.firm_id)
    info = integrations.get("ai_provider").info().to_dict()
    p = get_provider(cfg) if info["available"] else None
    return {"integration": info, "active_provider": p.name if p else None, "model": p.model if p else None, "data_residency": firm.data_residency,
            "train_on_matter_content": False, "training_note": "This application never uses matter content for model training. Confirm provider terms before enabling a live provider.",
            "settings": {"enabled": cfg["enabled"], "auto_complete_readonly": cfg["auto_complete_readonly"], "allowed_agents": cfg["allowed_agents"],
                         "monthly_budget_gbp": str(cfg["monthly_budget_gbp"]), "per_run_budget_gbp": str(cfg["per_run_budget_gbp"]), "user_daily_runs": cfg["user_daily_runs"]},
            "egress_by_agent": {k: a.catalog()["retrieves"] for k, a in registry().items()},
            "never_sent": ["original files", "other matters or matters you cannot access", "restricted/ethical-wall matters", "bank details and ledger data", "API credentials"],
            "logging": "Run events record ids, counts and labels only; document and email text is never written to application logs."}


@router.get("/usage")
def usage(ctx: Ctx = Depends(require("ai.use"))):
    return runner.usage_summary(ctx)


@router.post("/runs", status_code=201)
def start(body: RunStart, sync: bool = Query(False), ctx: Ctx = Depends(require("ai.use"))):
    _sync_allowed(sync)
    run = runner.start_run(ctx, body.agent_type, matter_id=body.matter_id, contact_id=body.contact_id, input=body.input, idempotency_key=body.idempotency_key, enqueue=not sync)
    ctx.db.commit()
    if sync and run.status == "queued":
        runner.process_run(ctx.db, run.id)
        run = ctx.db.get(AgentRun, run.id)
    return detail(ctx, run)


@router.get("/runs", response_model=Page[dict])
def list_runs(agent_type: str | None = None, status: str | None = None, matter_id: str | None = None, mine: bool = False, needs_review: bool = False,
              page: PageParams = Depends(), ctx: Ctx = Depends(require("ai.use"))):
    stmt = select(AgentRun).where(runner.runs_filter(ctx))
    if agent_type:
        stmt = stmt.where(AgentRun.agent_type == agent_type)
    if status:
        stmt = stmt.where(AgentRun.status == status)
    if matter_id:
        stmt = stmt.where(AgentRun.matter_id == matter_id)
    if mine:
        stmt = stmt.where(AgentRun.requested_by == ctx.user.id)
    if needs_review:
        stmt = stmt.where(AgentRun.status == "awaiting_review")
    rows, total = paginate(ctx.db, stmt.order_by(AgentRun.created_at.desc()), page)
    names = _names(ctx.db, [r.requested_by for r in rows])
    mids = {r.matter_id for r in rows if r.matter_id}
    refs = {m.id: m.reference for m in ctx.db.execute(select(Matter).where(Matter.id.in_(mids))).scalars()} if mids else {}
    counts = {}
    if rows:
        for rid, st in ctx.db.execute(select(AgentProposedAction.run_id, AgentProposedAction.status).where(AgentProposedAction.run_id.in_([r.id for r in rows]))).all():
            c = counts.setdefault(rid, [0, 0]); c[0] += 1; c[1] += st == "proposed"
    return Page(items=[_summary(r, names, refs, counts.get(r.id, [0, 0])[1], counts.get(r.id, [0, 0])[0]) for r in rows], total=total, limit=page.limit, offset=page.offset)


@router.get("/runs/{run_id}")
def get_run(run_id: str, ctx: Ctx = Depends(require("ai.use"))):
    return detail(ctx, runner.visible_run(ctx, run_id))


@router.post("/runs/{run_id}/review")
def review(run_id: str, body: ReviewIn, ctx: Ctx = Depends(require("ai.review"))):
    _sync_allowed(body.execute)
    run = runner.review_run(ctx, run_id, [d.model_dump(mode="json") for d in body.decisions], execute=body.execute)
    return detail(ctx, run)


@router.patch("/runs/{run_id}/actions/{action_id}")
def edit_action(run_id: str, action_id: str, body: ActionEdit, ctx: Ctx = Depends(require("ai.review"))):
    runner.edit_action(ctx, run_id, action_id, body.params, body.expected_version)
    return detail(ctx, runner.visible_run(ctx, run_id))


@router.post("/runs/{run_id}/cancel")
def cancel(run_id: str, ctx: Ctx = Depends(require("ai.use"))):
    return detail(ctx, runner.cancel_run(ctx, run_id))


@router.post("/runs/{run_id}/retry")
def retry(run_id: str, sync: bool = Query(False), ctx: Ctx = Depends(require("ai.use"))):
    _sync_allowed(sync)
    run = runner.retry_run(ctx, run_id, enqueue=not sync)
    ctx.db.commit()
    if sync:
        run = runner.process_run(ctx.db, run.id) if run.status == "queued" else runner.execute_run(ctx.db, run.id)
    return detail(ctx, run)
