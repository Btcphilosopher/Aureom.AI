from __future__ import annotations

from fastapi import APIRouter, Depends

from app.deps import Ctx, get_ctx
from app.integrations import base

router = APIRouter(prefix="/integrations", tags=["integrations"])


@router.get("")
def list_integrations(ctx: Ctx = Depends(get_ctx)):
    """Every external dependency, its current mode (mock/live/unavailable) and what data would leave the application if live."""
    infos = sorted(base.all_infos(), key=lambda i: (i.category, i.name))
    return {"items": [i.to_dict() for i in infos],
            "note": "Mock implementations are clearly labelled and produce SIMULATED results. 'unavailable' integrations return HTTP 503 integration_unavailable."}


@router.get("/{key}")
def get_integration(key: str, ctx: Ctx = Depends(get_ctx)):
    return base.get(key).info().to_dict()
