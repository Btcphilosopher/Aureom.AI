from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, or_, select

from app.deps import Ctx, get_ctx
from app.errors import NotFound, PermissionDenied
from app.models import KnowledgeItem
from app.pagination import Page, PageParams, paginate
from app.schemas.agents import KnowledgeApproval, KnowledgeIn, KnowledgePatch

router = APIRouter(prefix="/knowledge", tags=["knowledge"])


def _read(ctx: Ctx = Depends(get_ctx)) -> Ctx:
    if not (ctx.has("ai.use") or ctx.has("knowledge.manage")):
        raise PermissionDenied("Your role cannot read the knowledge base.", details={"required": ["ai.use"]})
    return ctx


def _out(k: KnowledgeItem, include_body: bool = True, **extra) -> dict:
    d = {"id": str(k.id), "title": k.title, "kind": k.kind, "practice_area": k.practice_area, "source_ref": k.source_ref, "effective_date": k.effective_date,
         "last_reviewed": k.last_reviewed, "approved": k.approved, "approved_by": str(k.approved_by) if k.approved_by else None, "updated_at": k.updated_at}
    if include_body:
        d["body"] = k.body
    d.update(extra)
    return d


def _get(ctx: Ctx, kid: str) -> KnowledgeItem:
    try:
        k = ctx.db.get(KnowledgeItem, uuid.UUID(kid))
    except ValueError:
        k = None
    if not k or k.firm_id != ctx.firm_id or (not k.approved and not ctx.has("knowledge.manage")):
        raise NotFound("Knowledge item not found.")
    return k


@router.get("/search")
def search(q: str = Query(..., min_length=2), practice_area: str | None = None, kind: str | None = None, limit: int = Query(10, ge=1, le=50), ctx: Ctx = Depends(_read)):
    """APPROVED items only (even for managers): this is what the knowledge agent may rely on."""
    import re

    terms = re.findall(r"[A-Za-z0-9]{3,}", q)[:12]
    rows = []
    for tsq in [func.websearch_to_tsquery("english", q)] + ([func.to_tsquery("english", " | ".join(terms))] if terms else []):
        stmt = select(KnowledgeItem, func.ts_headline("english", KnowledgeItem.body, tsq, "MaxFragments=1,MinWords=8,MaxWords=35"), func.ts_rank(KnowledgeItem.tsv, tsq)) \
            .where(KnowledgeItem.firm_id == ctx.firm_id, KnowledgeItem.approved.is_(True), KnowledgeItem.tsv.op("@@")(tsq))
        if practice_area:
            stmt = stmt.where(or_(KnowledgeItem.practice_area == practice_area, KnowledgeItem.practice_area.is_(None)))
        if kind:
            stmt = stmt.where(KnowledgeItem.kind == kind)
        rows = ctx.db.execute(stmt.order_by(func.ts_rank(KnowledgeItem.tsv, tsq).desc()).limit(limit)).all()
        if rows:
            break
    ctx.audit("knowledge.search", "knowledge", None, "Knowledge base searched", details={"results": len(rows)})
    return {"query": q, "results": [_out(k, include_body=False, snippet=snip, rank=float(rank)) for k, snip, rank in rows],
            "notice": "Approved internal materials only. Check effective and last-reviewed dates; this is not legal authority."}


@router.get("", response_model=Page[dict])
def list_items(practice_area: str | None = None, kind: str | None = None, approved: bool | None = None, page: PageParams = Depends(), ctx: Ctx = Depends(_read)):
    stmt = select(KnowledgeItem).where(KnowledgeItem.firm_id == ctx.firm_id)
    if not ctx.has("knowledge.manage"):
        stmt = stmt.where(KnowledgeItem.approved.is_(True))
    elif approved is not None:
        stmt = stmt.where(KnowledgeItem.approved.is_(approved))
    if practice_area:
        stmt = stmt.where(KnowledgeItem.practice_area == practice_area)
    if kind:
        stmt = stmt.where(KnowledgeItem.kind == kind)
    rows, total = paginate(ctx.db, stmt.order_by(KnowledgeItem.title), page)
    return Page(items=[_out(k, include_body=False) for k in rows], total=total, limit=page.limit, offset=page.offset)


@router.post("", status_code=201)
def create(body: KnowledgeIn, ctx: Ctx = Depends(get_ctx)):
    ctx.require("knowledge.manage")
    k = KnowledgeItem(firm_id=ctx.firm_id, **body.model_dump(), approved=False)
    ctx.db.add(k); ctx.db.flush()
    ctx.audit("knowledge.created", "knowledge", k.id, f"Knowledge item created (unapproved): {k.title}")
    return _out(k)


@router.get("/{kid}")
def get_item(kid: str, ctx: Ctx = Depends(_read)):
    return _out(_get(ctx, kid))


@router.patch("/{kid}")
def update(kid: str, body: KnowledgePatch, ctx: Ctx = Depends(get_ctx)):
    ctx.require("knowledge.manage")
    k = _get(ctx, kid)
    data = body.model_dump(exclude_unset=True)
    for f, v in data.items():
        setattr(k, f, v)
    reset = k.approved and bool(set(data) & {"title", "body", "kind", "effective_date"})
    if reset:  # content changed: approval no longer applies
        k.approved, k.approved_by = False, None
    ctx.db.flush()
    ctx.audit("knowledge.updated", "knowledge", k.id, f"Knowledge item updated: {k.title}", details={"fields": sorted(data), "approval_reset": reset})
    return _out(k)


@router.post("/{kid}/approval")
def approval(kid: str, body: KnowledgeApproval, ctx: Ctx = Depends(get_ctx)):
    ctx.require("knowledge.manage")
    k = _get(ctx, kid)
    k.approved = body.approved
    k.approved_by = ctx.user.id if body.approved else None
    if body.approved and not k.last_reviewed:
        k.last_reviewed = datetime.now(timezone.utc).date()
    ctx.db.flush()
    ctx.audit("knowledge.approved" if body.approved else "knowledge.unapproved", "knowledge", k.id, f"Knowledge item {'approved' if body.approved else 'withdrawn'}: {k.title}")
    return _out(k)


@router.delete("/{kid}", status_code=204)
def delete(kid: str, ctx: Ctx = Depends(get_ctx)):
    ctx.require("knowledge.manage")
    k = _get(ctx, kid)
    ctx.audit("knowledge.deleted", "knowledge", k.id, f"Knowledge item deleted: {k.title}")
    ctx.db.delete(k)
