"""Global search. Every group is filtered by role permission AND matter visibility (restricted matters and ethical walls
never appear - not in titles, snippets or counts)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy import and_, func, or_, select

from app.deps import Ctx, get_ctx
from app.models import (Contact, Correspondence, Document, DocumentChunk, DocumentVersion, KnowledgeItem, Matter, Task)
from app.permissions import matter_clause

router = APIRouter(prefix="/search", tags=["search"])


def _like(q: str) -> str:
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


@router.get("")
def global_search(q: str = Query(..., min_length=2, max_length=120), limit: int = Query(6, ge=1, le=20), ctx: Ctx = Depends(get_ctx)):
    db, groups = ctx.db, []
    if ctx.role_key == "client":
        return {"q": q, "groups": []}
    pat = _like(q.strip())
    vis = matter_clause(ctx)

    if ctx.has("matters.read"):
        rows = db.execute(select(Matter, Contact.display_name).join(Contact, Contact.id == Matter.client_id)
                          .where(vis, or_(Matter.reference.ilike(pat), Matter.title.ilike(pat), Contact.display_name.ilike(pat)))
                          .order_by(Matter.opened_at.desc().nullslast()).limit(limit)).all()
        groups.append({"type": "matter", "label": "Matters", "items": [
            {"id": str(m.id), "title": f"{m.reference} · {m.title}", "subtitle": f"{cn} · {m.status}", "href": f"/matters/{m.id}", "type": "matter"} for m, cn in rows]})

    if ctx.has("clients.read"):
        rows = db.execute(select(Contact).where(Contact.firm_id == ctx.firm_id, Contact.status != "merged",
                                                or_(Contact.display_name.ilike(pat), Contact.client_ref.ilike(pat), Contact.email.ilike(pat),
                                                    func.array_to_string(Contact.aliases, " ").ilike(pat)))
                          .order_by(Contact.display_name).limit(limit)).scalars().all()
        groups.append({"type": "client", "label": "Clients & contacts", "items": [
            {"id": str(c.id), "title": c.display_name, "subtitle": f"{c.kind} · {c.client_ref or c.status}", "href": f"/clients/{c.id}", "type": "client"} for c in rows]})

    if ctx.has("documents.read"):
        ts = func.websearch_to_tsquery("english", q)
        rows = db.execute(
            select(Document, DocumentChunk.page, DocumentChunk.paragraph,
                   func.ts_headline("english", DocumentChunk.text, ts, "MaxFragments=1,MaxWords=18,MinWords=8,StartSel=«,StopSel=»"))
            .join(DocumentChunk, and_(DocumentChunk.document_id == Document.id, DocumentChunk.version_id == Document.current_version_id))
            .where(Document.firm_id == ctx.firm_id, Document.matter_id.in_(select(Matter.id).where(vis)), or_(DocumentChunk.tsv.op("@@")(ts), Document.title.ilike(pat)))
            .order_by(func.ts_rank(DocumentChunk.tsv, ts).desc()).limit(limit * 3)).all()
        seen, items = set(), []
        for d, page, para, snip in rows:
            if d.id in seen:
                continue
            seen.add(d.id)
            items.append({"id": str(d.id), "title": d.title, "subtitle": f"{d.doc_type} · v{d.current_version_no} · p.{page} ¶{para}", "snippet": snip,
                          "href": f"/documents/{d.id}", "type": "document"})
        # title-only matches (e.g. documents whose text is not yet indexed)
        if len(items) < limit:
            for d in db.execute(select(Document).where(Document.firm_id == ctx.firm_id, Document.matter_id.in_(select(Matter.id).where(vis)),
                                                       Document.title.ilike(pat)).limit(limit)).scalars():
                if d.id not in seen:
                    seen.add(d.id)
                    items.append({"id": str(d.id), "title": d.title, "subtitle": f"{d.doc_type} · v{d.current_version_no}", "href": f"/documents/{d.id}", "type": "document"})
        groups.append({"type": "document", "label": "Documents (full text)", "items": items[:limit]})

    if ctx.has("correspondence.read"):
        ts = func.websearch_to_tsquery("english", q)
        rows = db.execute(select(Correspondence).where(Correspondence.firm_id == ctx.firm_id,
                                                       or_(Correspondence.matter_id.is_(None), Correspondence.matter_id.in_(select(Matter.id).where(vis))),
                                                       or_(Correspondence.tsv.op("@@")(ts), Correspondence.subject.ilike(pat)))
                          .order_by(Correspondence.created_at.desc()).limit(limit)).scalars().all()
        groups.append({"type": "correspondence", "label": "Correspondence", "items": [
            {"id": str(c.id), "title": c.subject, "subtitle": f"{c.direction} · {c.from_addr}", "href": f"/correspondence/{c.id}", "type": "correspondence"} for c in rows]})

    if ctx.has("tasks.read"):
        rows = db.execute(select(Task).where(Task.firm_id == ctx.firm_id, Task.title.ilike(pat),
                                             or_(and_(Task.matter_id.is_(None), or_(Task.assignee_id == ctx.user.id, Task.created_by == ctx.user.id)),
                                                 Task.matter_id.in_(select(Matter.id).where(vis)))).order_by(Task.due_at.nullslast()).limit(limit)).scalars().all()
        groups.append({"type": "task", "label": "Tasks", "items": [{"id": str(t.id), "title": t.title, "subtitle": t.status, "href": f"/tasks/{t.id}", "type": "task"} for t in rows]})

    if ctx.has("ai.use") or ctx.has("knowledge.manage"):
        ts = func.websearch_to_tsquery("english", q)
        rows = db.execute(select(KnowledgeItem).where(KnowledgeItem.firm_id == ctx.firm_id, KnowledgeItem.approved.is_(True),
                                                      or_(KnowledgeItem.tsv.op("@@")(ts), KnowledgeItem.title.ilike(pat))).limit(limit)).scalars().all()
        groups.append({"type": "knowledge", "label": "Approved knowledge", "items": [
            {"id": str(k.id), "title": k.title, "subtitle": f"{k.kind} · effective {k.effective_date:%d %b %Y}", "href": f"/ai/knowledge?item={k.id}", "type": "knowledge"} for k in rows]})

    return {"q": q, "groups": [g for g in groups if g["items"]]}
