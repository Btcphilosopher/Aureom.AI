"""Router registry. Each domain exposes `router` in app/api/<name>.py. Mounted under /api/v1."""
from __future__ import annotations

import importlib
import logging

from fastapi import APIRouter

log = logging.getLogger("aureom.api")

ROUTER_MODULES = [
    "auth", "home", "search", "approvals", "notifications",
    "clients", "conflicts", "matters",
    "documents", "correspondence", "tasks", "diary",
    "time_billing", "ledger", "reports",
    "agents", "knowledge", "portal", "admin", "integrations",
]


def build_router() -> APIRouter:
    root = APIRouter()
    for name in ROUTER_MODULES:
        try:
            mod = importlib.import_module(f"app.api.{name}")
        except ModuleNotFoundError as e:
            if e.name != f"app.api.{name}":
                raise
            log.warning("api module %s not present yet", name)
            continue
        root.include_router(mod.router)
    return root
