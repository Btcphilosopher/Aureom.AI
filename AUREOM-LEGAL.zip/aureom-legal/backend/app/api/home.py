"""Personalised dashboard. Every card returns `href` (+ filters) that opens the underlying records, and financial metrics
state their reporting period, filters and calculation basis. Content is limited by role permission and matter visibility."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, Query
from sqlalchemy import and_, exists, func, or_, select

from app.deps import Ctx, get_ctx
from app.models import (AgentRun, Approval, BankStatementLine, ConflictSearch, Contact, Correspondence, Deadline, Document, DocumentVersion, Expense,
                        Invoice, Matter, MatterMember, OnboardingRecord, Payment, Task, TimeEntry)
from app.permissions import matter_clause

router = APIRouter(prefix="/home", tags=["home"])


def _period(period: str, today: date) -> tuple[date, date, str]:
    if period == "30d":
        return today - timedelta(days=29), today, "Last 30 days"
    if period == "quarter":
        q0 = date(today.year, 3 * ((today.month - 1) // 3) + 1, 1)
        return q0, today, "Quarter to date"
    if period == "ytd":
        return date(today.year, 1, 1), today, "Year to date"
    return today.replace(day=1), today, "Month to date"


def _mine_clause(ctx: Ctx):
    return or_(Matter.responsible_partner_id == ctx.user.id, Matter.fee_earner_id == ctx.user.id,
               exists().where(MatterMember.matter_id == Matter.id, MatterMember.user_id == ctx.user.id, MatterMember.access == "allow"))


def _dec(v) -> str:
    return str((v or Decimal("0")).quantize(Decimal("0.01")))


@router.get("")
def home(scope: str = Query("mine", pattern="^(mine|firm)$"), period: str = Query("month", pattern="^(month|quarter|ytd|30d)$"),
         office_id: str | None = None, ctx: Ctx = Depends(get_ctx)):
    db, today = ctx.db, date.today()
    now = datetime.now(timezone.utc)
    if ctx.role_key == "client":
        return {"role": "client", "redirect": "/portal"}
    if scope == "firm" and not (ctx.has("reports.read") or ctx.has("matters.approve")):
        scope = "mine"
    base = [matter_clause(ctx)]
    if scope == "mine":
        base.append(_mine_clause(ctx))
    if office_id:
        base.append(Matter.office_id == office_id)
    scoped_ids = select(Matter.id).where(*base)
    out: dict = {"generated_at": now, "scope": scope, "office_id": office_id, "as_of": today,
                 "user": {"name": ctx.user.name, "role": ctx.role_key}}

    # --- My active matters
    if ctx.has("matters.read"):
        rows = db.execute(select(Matter, Contact.display_name).join(Contact, Contact.id == Matter.client_id)
                          .where(*base, Matter.status.in_(["open", "paused"])).order_by(Matter.target_date.nullslast(), Matter.reference).limit(8)).all()
        total = db.execute(select(func.count()).select_from(Matter).where(*base, Matter.status.in_(["open", "paused"]))).scalar_one()
        out["matters"] = {"count": total, "href": "/matters?status=open" + ("&mine=1" if scope == "mine" else ""), "items": [
            {"id": str(m.id), "reference": m.reference, "title": m.title, "client": cn, "stage": m.stage, "status": m.status, "practice_area": m.practice_area,
             "restricted": m.access_level == "restricted", "target_date": m.target_date, "href": f"/matters/{m.id}"} for m, cn in rows]}

    # --- Tasks
    if ctx.has("tasks.read"):
        mine = [Task.firm_id == ctx.firm_id, Task.assignee_id == ctx.user.id, Task.status.in_(["open", "in_progress", "blocked"]),
                or_(Task.matter_id.is_(None), Task.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))]
        rows = db.execute(select(Task).where(*mine).order_by(Task.due_at.nullslast()).limit(8)).scalars().all()
        total = db.execute(select(func.count()).select_from(Task).where(*mine)).scalar_one()
        overdue = db.execute(select(func.count()).select_from(Task).where(*mine, Task.due_at < now)).scalar_one()
        refs = {m.id: m.reference for m in db.execute(select(Matter).where(Matter.id.in_([t.matter_id for t in rows if t.matter_id]))).scalars()} if rows else {}
        out["tasks"] = {"count": total, "overdue": overdue, "href": "/tasks?assignee=me&status=open", "items": [
            {"id": str(t.id), "title": t.title, "due_at": t.due_at, "priority": t.priority, "status": t.status, "matter_reference": refs.get(t.matter_id),
             "overdue": bool(t.due_at and t.due_at < now), "href": f"/tasks/{t.id}"} for t in rows]}

        # --- Deadlines requiring attention (suggested awaiting confirmation, or confirmed due soon)
        dl = [Deadline.firm_id == ctx.firm_id, Deadline.matter_id.in_(scoped_ids),
              or_(Deadline.status == "suggested", and_(Deadline.status == "confirmed", Deadline.due_date <= today + timedelta(days=14)))]
        rows = db.execute(select(Deadline, Matter.reference).join(Matter, Matter.id == Deadline.matter_id).where(*dl).order_by(Deadline.due_date).limit(8)).all()
        total = db.execute(select(func.count()).select_from(Deadline).where(*dl)).scalar_one()
        out["deadlines"] = {"count": total, "href": "/tasks/deadlines?needs_attention=1", "items": [
            {"id": str(d.id), "title": d.title, "due_date": d.due_date, "status": d.status, "origin": d.origin, "matter_reference": ref,
             "days_left": (d.due_date - today).days, "needs_confirmation": d.status == "suggested", "href": f"/tasks/deadlines/{d.id}"} for d, ref in rows]}

    # --- Documents awaiting review / signature
    if ctx.has("documents.read"):
        cond = [Document.firm_id == ctx.firm_id, Document.matter_id.in_(scoped_ids), Document.status.in_(["in_review", "signature_requested"])]
        rows = db.execute(select(Document, Matter.reference).join(Matter, Matter.id == Document.matter_id).where(*cond).order_by(Document.updated_at.desc()).limit(8)).all()
        counts = dict(db.execute(select(Document.status, func.count()).where(*cond).group_by(Document.status)).all())
        out["documents"] = {"awaiting_review": counts.get("in_review", 0), "awaiting_signature": counts.get("signature_requested", 0),
                            "href": "/documents?status=in_review", "items": [
            {"id": str(d.id), "title": d.title, "status": d.status, "matter_reference": ref, "version_no": d.current_version_no, "href": f"/documents/{d.id}"} for d, ref in rows]}

    # --- Recent correspondence
    if ctx.has("correspondence.read"):
        cond = [Correspondence.firm_id == ctx.firm_id, Correspondence.matter_id.in_(scoped_ids)]
        rows = db.execute(select(Correspondence).where(*cond).order_by(Correspondence.created_at.desc()).limit(6)).scalars().all()
        unfiled = db.execute(select(func.count()).select_from(Correspondence).where(Correspondence.firm_id == ctx.firm_id, Correspondence.matter_id.is_(None),
                                                                                    Correspondence.direction == "inbound")).scalar_one()
        out["correspondence"] = {"unfiled": unfiled, "href": "/correspondence", "items": [
            {"id": str(c.id), "subject": c.subject, "direction": c.direction, "status": c.status, "from": c.from_addr,
             "at": c.sent_at or c.received_at or c.created_at, "href": f"/correspondence/{c.id}"} for c in rows]}

    # --- AI drafts awaiting human review (own runs; reviewers see runs on matters they can see)
    if ctx.has("ai.use") or ctx.has("ai.review"):
        cond = [AgentRun.firm_id == ctx.firm_id, AgentRun.status == "awaiting_review",
                or_(AgentRun.matter_id.is_(None), AgentRun.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))]
        if scope == "mine" or not ctx.has("ai.review"):
            cond.append(AgentRun.requested_by == ctx.user.id)
        rows = db.execute(select(AgentRun, Matter.reference).outerjoin(Matter, Matter.id == AgentRun.matter_id).where(*cond).order_by(AgentRun.created_at.desc()).limit(6)).all()
        total = db.execute(select(func.count()).select_from(AgentRun).where(*cond)).scalar_one()
        out["ai_drafts"] = {"count": total, "href": "/ai/runs?status=awaiting_review", "items": [
            {"id": str(r.id), "agent_type": r.agent_type, "matter_reference": ref, "created_at": r.created_at, "href": f"/ai/runs/{r.id}"} for r, ref in rows]}

    # --- Approvals waiting for me
    perms = list(ctx.perms)
    ap = db.execute(select(func.count()).select_from(Approval).where(Approval.firm_id == ctx.firm_id, Approval.status == "pending", Approval.requested_by != ctx.user.id,
                                                                     or_(Approval.required_permission.is_(None), Approval.required_permission.in_(perms)),
                                                                     or_(Approval.matter_id.is_(None), Approval.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))).scalar_one()
    out["approvals"] = {"count": ap, "href": "/approvals"}

    # --- Financial metrics (permission-gated; basis stated)
    if ctx.has("billing.read") or ctx.has("reports.financial"):
        fscope = scope if ctx.has("reports.financial") else "mine"
        fbase = [matter_clause(ctx)] + ([_mine_clause(ctx)] if fscope == "mine" else []) + ([Matter.office_id == office_id] if office_id else [])
        fids = select(Matter.id).where(*fbase)
        d0, d1, label = _period(period, today)
        wip_t = db.execute(select(func.coalesce(func.sum(TimeEntry.amount), 0)).where(TimeEntry.firm_id == ctx.firm_id, TimeEntry.matter_id.in_(fids), TimeEntry.billable.is_(True),
                                                                                        TimeEntry.status.in_(["submitted", "approved"]), TimeEntry.invoice_line_id.is_(None))).scalar_one()
        wip_e = db.execute(select(func.coalesce(func.sum(Expense.amount), 0)).where(Expense.firm_id == ctx.firm_id, Expense.matter_id.in_(fids), Expense.billable.is_(True),
                                                                                   Expense.status == "approved", Expense.invoice_line_id.is_(None))).scalar_one()
        draft_inv = db.execute(select(Invoice).where(Invoice.firm_id == ctx.firm_id, Invoice.matter_id.in_(fids), Invoice.status.in_(["draft", "pending_approval"]))
                               .order_by(Invoice.created_at.desc())).scalars().all()
        billed = db.execute(select(func.coalesce(func.sum(Invoice.total), 0)).where(Invoice.firm_id == ctx.firm_id, Invoice.matter_id.in_(fids), Invoice.kind == "invoice",
                                                                                      Invoice.status.in_(["issued", "partially_paid", "paid"]),
                                                                                      func.date(Invoice.issued_at) >= d0, func.date(Invoice.issued_at) <= d1)).scalar_one()
        credits = db.execute(select(func.coalesce(func.sum(Invoice.total), 0)).where(Invoice.firm_id == ctx.firm_id, Invoice.matter_id.in_(fids), Invoice.kind == "credit_note",
                                                                                       Invoice.status.in_(["issued", "partially_paid", "paid"]),
                                                                                       func.date(Invoice.issued_at) >= d0, func.date(Invoice.issued_at) <= d1)).scalar_one()
        cash = db.execute(select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.firm_id == ctx.firm_id, Payment.ledger == "office", Payment.received_on >= d0,
                                                                                    Payment.received_on <= d1, or_(Payment.matter_id.is_(None), Payment.matter_id.in_(fids)))).scalar_one() \
            if fscope == "firm" else None
        metrics = [
            {"key": "wip", "label": "Unbilled time & expenses (WIP)", "value": _dec(Decimal(wip_t) + Decimal(wip_e)), "currency": "GBP", "href": "/billing?tab=wip",
             "basis": "Billable time that is submitted/approved and not yet on an invoice, at recorded rates, plus approved billable expenses. Draft entries are excluded. As at today."},
            {"key": "billed", "label": "Billed in period (net of credit notes)", "value": _dec(Decimal(billed) - Decimal(credits)), "currency": "GBP", "href": "/billing?tab=invoices",
             "basis": f"Invoices issued {d0:%d %b} – {d1:%d %b %Y} (VAT-inclusive totals) less credit notes issued in the period. Billed amounts are not recognised revenue."},
        ]
        if cash is not None:
            metrics.append({"key": "cash", "label": "Cash received in period (office account)", "value": _dec(Decimal(cash)), "currency": "GBP", "href": "/ledger/receipts",
                            "basis": "Receipts recorded to the office ledger in the period, regardless of allocation. Receipt of money is not earned revenue."})
        out["financial"] = {"period": {"from": d0, "to": d1, "label": label, "key": period}, "filters": {"scope": fscope, "office_id": office_id, "currency": "GBP"},
                            "basis_note": "Figures use only records visible to you. Money values are exact decimals (GBP).", "metrics": metrics,
                            "draft_invoices": {"count": len(draft_inv), "total": _dec(sum((i.total for i in draft_inv), Decimal("0"))), "href": "/billing?tab=invoices&status=draft",
                                               "items": [{"id": str(i.id), "status": i.status, "total": _dec(i.total), "href": f"/billing/invoices/{i.id}"} for i in draft_inv[:5]]}}

    # --- Exceptions
    exc: list[dict] = []

    def add(key, label, count, href, severity="warning", items=None):
        if count:
            exc.append({"key": key, "label": label, "count": count, "href": href, "severity": severity, "items": items or []})

    if ctx.has("documents.read") and ctx.has("matters.read"):
        has_eng = exists().where(Document.matter_id == Matter.id, Document.doc_type == "engagement_letter")
        rows = db.execute(select(Matter).where(*base, Matter.status == "open", ~has_eng).limit(5)).scalars().all()
        n = db.execute(select(func.count()).select_from(Matter).where(*base, Matter.status == "open", ~has_eng)).scalar_one()
        add("missing_documents", "Open matters with no engagement letter on file", n, "/matters?missing=engagement_letter",
            items=[{"label": f"{m.reference} · {m.title}", "href": f"/matters/{m.id}"} for m in rows])
        bad = db.execute(select(func.count()).select_from(DocumentVersion).join(Document, Document.id == DocumentVersion.document_id)
                         .where(Document.firm_id == ctx.firm_id, Document.matter_id.in_(scoped_ids), DocumentVersion.scan_status.in_(["infected", "error"]))).scalar_one()
        add("scan_failures", "Document versions that failed malware scanning", bad, "/documents?scan=failed", "danger")
    if ctx.has("ledger.read") or ctx.has("billing.read"):
        n = db.execute(select(func.count()).select_from(Payment).where(Payment.firm_id == ctx.firm_id, Payment.ledger == "office", Payment.status.in_(["received_unallocated", "partially_allocated"]),
                                                                       or_(Payment.matter_id.is_(None), Payment.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))).scalar_one()
        add("unallocated_receipts", "Office receipts not fully allocated to an invoice", n, "/ledger/receipts?status=unallocated")
    if ctx.has("ledger.reconcile"):
        n = db.execute(select(func.count()).select_from(BankStatementLine).where(BankStatementLine.firm_id == ctx.firm_id, BankStatementLine.status == "unmatched")).scalar_one()
        add("unmatched_bank_lines", "Bank statement lines not yet matched", n, "/ledger/reconciliation")
    if ctx.has("clients.read"):
        inc = exists().where(OnboardingRecord.contact_id == Contact.id, OnboardingRecord.status == "approved")
        n = db.execute(select(func.count()).select_from(Contact).where(Contact.firm_id == ctx.firm_id, Contact.status.in_(["prospect", "active"]), Contact.is_client.is_(True) | (Contact.status == "prospect"), ~inc)).scalar_one()
        rows = db.execute(select(Contact).where(Contact.firm_id == ctx.firm_id, Contact.status.in_(["prospect", "active"]), Contact.is_client.is_(True) | (Contact.status == "prospect"), ~inc).limit(5)).scalars().all()
        add("incomplete_onboarding", "Clients/prospects with incomplete onboarding", n, "/clients?onboarding=incomplete", items=[{"label": c.display_name, "href": f"/clients/{c.id}"} for c in rows])
    if ctx.has("conflicts.review"):
        n = db.execute(select(func.count()).select_from(ConflictSearch).where(ConflictSearch.firm_id == ctx.firm_id, ConflictSearch.status == "pending_review")).scalar_one()
        add("conflicts_pending", "Conflict searches awaiting human review", n, "/clients/conflicts?status=pending_review", "danger")
    out["exceptions"] = exc
    return out
