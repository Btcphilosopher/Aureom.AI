"""Time, expenses, rate cards and invoices.
Mounted at /api/v1: time entries & expenses under /time/*, rate cards and invoices (incl. credit notes) under /billing/*."""
from __future__ import annotations

import uuid
from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select

from app.deps import Ctx, get_ctx, require
from app.errors import NotFound
from app.models import Approval, Expense, Invoice, Matter, RateCard, RateCardEntry, TimeEntry, User
from app.pagination import Page, PageParams, paginate
from app.permissions import matter_clause
from app.schemas.billing import (CreditNoteIn, DecideIn, ExpenseIn, ExpenseOut, ExpensePatch, InvoiceDraftIn, InvoiceLineOut, InvoiceOut, InvoicePatch,
                                 RateCardIn, RateCardOut, RateEntryIn, RateEntryOut, ReasonIn, TimeEntryIn, TimeEntryOut, TimeEntryPatch, TimerStartIn, TimerStopIn)
from app.schemas.ledger import jsonable
from app.services import billing as svc
from app.services import ledger as led
from app.services.matter_finance import unbilled_wip

time_router = APIRouter(prefix="/time", tags=["time & expenses"])
billing_router = APIRouter(prefix="/billing", tags=["billing"])
router = APIRouter()


def _te(ctx: Ctx, te: TimeEntry) -> TimeEntryOut:
    out = TimeEntryOut.model_validate(te)
    m, u = ctx.db.get(Matter, te.matter_id), ctx.db.get(User, te.user_id)
    out.matter_reference, out.user_name = (m.reference if m else None), (u.name if u else None)
    return out


# ------------------------------------------------------------------ time entries
@time_router.get("/entries", response_model=Page[TimeEntryOut])
def list_entries(matter_id: uuid.UUID | None = None, user_id: uuid.UUID | None = None, mine: bool = False, status: str | None = None,
                 unbilled: bool = False, date_from: date | None = None, date_to: date | None = None, p: PageParams = Depends(),
                 ctx: Ctx = Depends(require("time.write"))):
    stmt = svc.time_entry_query(ctx)
    if matter_id: stmt = stmt.where(TimeEntry.matter_id == matter_id)
    if mine: stmt = stmt.where(TimeEntry.user_id == ctx.user.id)
    elif user_id: stmt = stmt.where(TimeEntry.user_id == user_id)
    if status: stmt = stmt.where(TimeEntry.status == status)
    if unbilled: stmt = stmt.where(TimeEntry.status.in_(("draft", "submitted", "approved")), TimeEntry.billable.is_(True), TimeEntry.timer_started_at.is_(None))
    if date_from: stmt = stmt.where(TimeEntry.work_date >= date_from)
    if date_to: stmt = stmt.where(TimeEntry.work_date <= date_to)
    rows, total = paginate(ctx.db, stmt.order_by(TimeEntry.work_date.desc(), TimeEntry.created_at.desc(), TimeEntry.id), p)
    return Page(items=[_te(ctx, r) for r in rows], total=total, limit=p.limit, offset=p.offset)


@time_router.post("/entries", response_model=TimeEntryOut, status_code=201)
def create_entry(body: TimeEntryIn, ctx: Ctx = Depends(require("time.write"))):
    return _te(ctx, svc.create_time_entry(ctx, **body.model_dump()))


@time_router.patch("/entries/{entry_id}", response_model=TimeEntryOut)
def patch_entry(entry_id: uuid.UUID, body: TimeEntryPatch, ctx: Ctx = Depends(require("time.write"))):
    return _te(ctx, svc.update_time_entry(ctx, entry_id, **body.model_dump(exclude_unset=True)))


@time_router.delete("/entries/{entry_id}", status_code=204)
def delete_entry(entry_id: uuid.UUID, ctx: Ctx = Depends(require("time.write"))):
    svc.delete_time_entry(ctx, entry_id)


@time_router.post("/entries/{entry_id}/submit", response_model=TimeEntryOut)
def submit_entry(entry_id: uuid.UUID, ctx: Ctx = Depends(require("time.write"))):
    return _te(ctx, svc.submit_time_entry(ctx, entry_id))


@time_router.post("/entries/{entry_id}/approve", response_model=TimeEntryOut)
def approve_entry(entry_id: uuid.UUID, ctx: Ctx = Depends(require("billing.write"))):
    return _te(ctx, svc.approve_time_entry(ctx, entry_id))


@time_router.post("/entries/{entry_id}/write-off", response_model=TimeEntryOut)
def writeoff_entry(entry_id: uuid.UUID, body: ReasonIn, ctx: Ctx = Depends(require("billing.write"))):
    return _te(ctx, svc.write_off_time_entry(ctx, entry_id, body.reason))


# ------------------------------------------------------------------ timer
@time_router.get("/timer", response_model=TimeEntryOut | None)
def get_timer(ctx: Ctx = Depends(require("time.write"))):
    te = svc.running_timer(ctx)
    return _te(ctx, te) if te else None


@time_router.post("/timer/start", response_model=TimeEntryOut, status_code=201)
def timer_start(body: TimerStartIn, ctx: Ctx = Depends(require("time.write"))):
    return _te(ctx, svc.start_timer(ctx, body.matter_id, body.narrative, body.billable))


@time_router.post("/timer/stop", response_model=TimeEntryOut)
def timer_stop(body: TimerStopIn, ctx: Ctx = Depends(require("time.write"))):
    return _te(ctx, svc.stop_timer(ctx, body.narrative))


# ------------------------------------------------------------------ expenses
@time_router.get("/expenses", response_model=Page[ExpenseOut])
def list_expenses(matter_id: uuid.UUID | None = None, status: str | None = None, p: PageParams = Depends(), ctx: Ctx = Depends(require("time.write"))):
    stmt = svc.expense_query(ctx)
    if matter_id: stmt = stmt.where(Expense.matter_id == matter_id)
    if status: stmt = stmt.where(Expense.status == status)
    rows, total = paginate(ctx.db, stmt.order_by(Expense.expense_date.desc(), Expense.id), p)
    return Page(items=[ExpenseOut.model_validate(r) for r in rows], total=total, limit=p.limit, offset=p.offset)


@time_router.post("/expenses", response_model=ExpenseOut, status_code=201)
def create_expense(body: ExpenseIn, ctx: Ctx = Depends(require("time.write"))):
    return ExpenseOut.model_validate(svc.create_expense(ctx, **body.model_dump()))


@time_router.patch("/expenses/{expense_id}", response_model=ExpenseOut)
def patch_expense(expense_id: uuid.UUID, body: ExpensePatch, ctx: Ctx = Depends(require("time.write"))):
    return ExpenseOut.model_validate(svc.update_expense(ctx, expense_id, **body.model_dump(exclude_unset=True)))


@time_router.post("/expenses/{expense_id}/approve", response_model=ExpenseOut)
def approve_expense(expense_id: uuid.UUID, ctx: Ctx = Depends(require("billing.write"))):
    return ExpenseOut.model_validate(svc.approve_expense(ctx, expense_id))


@time_router.post("/expenses/{expense_id}/write-off", response_model=ExpenseOut)
def writeoff_expense(expense_id: uuid.UUID, body: ReasonIn, ctx: Ctx = Depends(require("billing.write"))):
    return ExpenseOut.model_validate(svc.write_off_expense(ctx, expense_id, body.reason))


# ------------------------------------------------------------------ dashboard & budget
@time_router.get("/home-summary")
def home_summary(ctx: Ctx = Depends(get_ctx)):
    return jsonable(svc.home_summary(ctx))


@time_router.get("/matters/{matter_id}/budget")
def matter_budget(matter_id: uuid.UUID, ctx: Ctx = Depends(require("billing.read"))):
    from decimal import Decimal
    from sqlalchemy import func
    m = led.get_matter_for(ctx, matter_id)
    wip = unbilled_wip(ctx.db, m.id)
    billed = ctx.db.execute(select(func.coalesce(func.sum(Invoice.subtotal), 0)).where(Invoice.matter_id == m.id, Invoice.kind == "invoice",
                                                                                      Invoice.status.in_(("issued", "partially_paid", "paid")))).scalar_one()
    used = wip["time"] + wip["expenses"] + Decimal(billed)
    pct = (used * 100 / m.budget_amount).quantize(Decimal("0.1")) if m.budget_amount else None
    return jsonable({"matter_id": m.id, "currency": m.currency, "budget": m.budget_amount, "unbilled_wip": wip["time"] + wip["expenses"], "billed_net": Decimal(billed),
                     "used": used, "used_pct": pct, "over_budget": bool(m.budget_amount and used > m.budget_amount),
                     "basis": "Used = unbilled WIP (time + expenses, net) + net of invoices issued. Budget is the matter's budget_amount."})


# ------------------------------------------------------------------ rate cards
def _rc(ctx: Ctx, rc: RateCard) -> RateCardOut:
    entries = ctx.db.execute(select(RateCardEntry).where(RateCardEntry.rate_card_id == rc.id).order_by(RateCardEntry.grade)).scalars().all()
    return RateCardOut(id=rc.id, name=rc.name, currency=rc.currency, is_default=rc.is_default, is_active=rc.is_active,
                       entries=[RateEntryOut.model_validate(e) for e in entries])


@billing_router.get("/rate-cards", response_model=list[RateCardOut])
def list_rate_cards(ctx: Ctx = Depends(get_ctx)):
    if not (ctx.has("billing.read") or ctx.has("time.write") or ctx.has("admin.settings")):
        ctx.require("billing.read")
    return [_rc(ctx, r) for r in ctx.db.execute(select(RateCard).where(RateCard.firm_id == ctx.firm_id).order_by(RateCard.name)).scalars()]


@billing_router.post("/rate-cards", response_model=RateCardOut, status_code=201)
def create_rate_card(body: RateCardIn, ctx: Ctx = Depends(get_ctx)):
    return _rc(ctx, svc.create_rate_card(ctx, name=body.name, currency=body.currency, is_default=body.is_default, entries=[e.model_dump() for e in body.entries]))


@billing_router.put("/rate-cards/{rate_card_id}/entries", response_model=RateCardOut)
def put_rate_entries(rate_card_id: uuid.UUID, body: list[RateEntryIn], ctx: Ctx = Depends(get_ctx)):
    svc.set_rate_card_entries(ctx, rate_card_id, [e.model_dump() for e in body])
    return _rc(ctx, ctx.db.get(RateCard, rate_card_id))


# ------------------------------------------------------------------ invoices
def _invoice_out(ctx: Ctx, inv: Invoice, with_lines: bool = True) -> InvoiceOut:
    m = ctx.db.get(Matter, inv.matter_id)
    ap = ctx.db.get(Approval, inv.approval_id) if inv.approval_id else None
    lines = svc.invoice_lines(ctx.db, inv.id) if with_lines else []
    return InvoiceOut(id=inv.id, matter_id=inv.matter_id, matter_reference=m.reference if m else None, client_id=inv.client_id, payer_id=inv.payer_id,
                      kind=inv.kind, credit_for_invoice_id=inv.credit_for_invoice_id, number=inv.number, status=inv.status, currency=inv.currency,
                      subtotal=inv.subtotal, vat_amount=inv.vat_amount, total=inv.total, amount_paid=inv.amount_paid,
                      outstanding=led.invoice_outstanding(ctx.db, inv) if inv.status in ("issued", "partially_paid", "paid") else inv.total if inv.kind == "invoice" else inv.total,
                      issued_at=inv.issued_at, due_date=inv.due_date, narrative=inv.narrative, approval_id=inv.approval_id,
                      approval_status=ap.status if ap else None, version=inv.version, lines=[InvoiceLineOut.model_validate(l) for l in lines])


def _inv(ctx: Ctx, invoice_id: uuid.UUID) -> Invoice:
    inv = ctx.db.execute(select(Invoice).where(Invoice.id == invoice_id, Invoice.firm_id == ctx.firm_id)).scalar_one_or_none()
    if not inv:
        raise NotFound("Invoice not found.")
    led.get_matter_for(ctx, inv.matter_id)
    return inv


@billing_router.get("/invoices", response_model=Page[InvoiceOut])
def list_invoices(matter_id: uuid.UUID | None = None, status: str | None = None, kind: str | None = None, p: PageParams = Depends(),
                  ctx: Ctx = Depends(require("billing.read"))):
    stmt = select(Invoice).where(Invoice.firm_id == ctx.firm_id, Invoice.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))
    if matter_id: stmt = stmt.where(Invoice.matter_id == matter_id)
    if status: stmt = stmt.where(Invoice.status == status)
    if kind: stmt = stmt.where(Invoice.kind == kind)
    rows, total = paginate(ctx.db, stmt.order_by(Invoice.created_at.desc(), Invoice.id), p)
    return Page(items=[_invoice_out(ctx, r, with_lines=False) for r in rows], total=total, limit=p.limit, offset=p.offset)


@billing_router.get("/invoices/{invoice_id}", response_model=InvoiceOut)
def get_invoice(invoice_id: uuid.UUID, ctx: Ctx = Depends(require("billing.read"))):
    return _invoice_out(ctx, _inv(ctx, invoice_id))


@billing_router.get("/matters/{matter_id}/unbilled")
def unbilled(matter_id: uuid.UUID, ctx: Ctx = Depends(require("billing.write"))):
    """Candidate time entries and expenses for a new draft invoice."""
    m = led.get_matter_for(ctx, matter_id)
    t = ctx.db.execute(select(TimeEntry).where(TimeEntry.matter_id == m.id, TimeEntry.status.in_(("submitted", "approved")), TimeEntry.billable.is_(True),
                                               TimeEntry.invoice_line_id.is_(None)).order_by(TimeEntry.work_date)).scalars().all()
    e = ctx.db.execute(select(Expense).where(Expense.matter_id == m.id, Expense.status.in_(("draft", "approved")), Expense.billable.is_(True),
                                             Expense.invoice_line_id.is_(None)).order_by(Expense.expense_date)).scalars().all()
    return jsonable({"matter_id": m.id, "time_entries": [_te(ctx, x) for x in t], "expenses": [ExpenseOut.model_validate(x) for x in e],
                     "fee_arrangement": m.fee_arrangement, "fixed_fee_amount": m.fixed_fee_amount, "currency": m.currency})


@billing_router.post("/invoices", response_model=InvoiceOut, status_code=201)
def create_invoice(body: InvoiceDraftIn, ctx: Ctx = Depends(require("billing.write"))):
    data = body.model_dump()
    data["adjustments"] = [a for a in data["adjustments"]]
    for a in data["adjustments"]:
        if a.get("vat_rate") is None: a.pop("vat_rate", None)
    return _invoice_out(ctx, svc.create_draft_invoice(ctx, **data))


@billing_router.patch("/invoices/{invoice_id}", response_model=InvoiceOut)
def patch_invoice(invoice_id: uuid.UUID, body: InvoicePatch, ctx: Ctx = Depends(require("billing.write"))):
    data = body.model_dump(exclude_unset=True)
    if "add_adjustments" in data:
        for a in data["add_adjustments"]:
            if a.get("vat_rate") is None: a.pop("vat_rate", None)
    return _invoice_out(ctx, svc.update_draft_invoice(ctx, invoice_id, **data))


@billing_router.post("/invoices/{invoice_id}/submit", response_model=InvoiceOut)
def submit_invoice(invoice_id: uuid.UUID, ctx: Ctx = Depends(require("billing.write"))):
    svc.submit_invoice_for_approval(ctx, invoice_id)
    return _invoice_out(ctx, _inv(ctx, invoice_id))


@billing_router.post("/invoices/{invoice_id}/decision", response_model=InvoiceOut)
def decide_invoice(invoice_id: uuid.UUID, body: DecideIn, ctx: Ctx = Depends(require("billing.approve"))):
    """Partner approves or rejects the exact invoice content (four-eyes: not the person who submitted it)."""
    return _invoice_out(ctx, svc.decide_invoice(ctx, invoice_id, approve=body.approve, note=body.note))


@billing_router.post("/invoices/{invoice_id}/issue", response_model=InvoiceOut)
def issue_invoice(invoice_id: uuid.UUID, ctx: Ctx = Depends(require("billing.issue"))):
    return _invoice_out(ctx, svc.issue_invoice(ctx, invoice_id))


@billing_router.post("/invoices/{invoice_id}/void", response_model=InvoiceOut)
def void_invoice(invoice_id: uuid.UUID, body: ReasonIn, ctx: Ctx = Depends(require("billing.write"))):
    return _invoice_out(ctx, svc.void_draft_invoice(ctx, invoice_id, body.reason))


@billing_router.post("/invoices/{invoice_id}/credit-note", response_model=InvoiceOut, status_code=201)
def credit_note(invoice_id: uuid.UUID, body: CreditNoteIn, ctx: Ctx = Depends(require("billing.write"))):
    lines = [l.model_dump() for l in body.lines]
    for l in lines:
        if l.get("vat_rate") is None: l.pop("vat_rate", None)
    return _invoice_out(ctx, svc.create_credit_note(ctx, invoice_id, full=body.full, lines=lines, narrative=body.narrative))


router.include_router(time_router)
router.include_router(billing_router)
