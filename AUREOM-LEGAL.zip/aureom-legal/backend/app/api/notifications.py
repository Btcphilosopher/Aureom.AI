from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func, select, update

from app.deps import Ctx, get_ctx
from app.errors import NotFound
from app.models import Notification

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("")
def list_notifications(limit: int = 30, ctx: Ctx = Depends(get_ctx)):
    rows = ctx.db.execute(select(Notification).where(Notification.user_id == ctx.user.id).order_by(Notification.created_at.desc()).limit(min(limit, 100))).scalars().all()
    unread = ctx.db.execute(select(func.count()).select_from(Notification).where(Notification.user_id == ctx.user.id, Notification.read_at.is_(None))).scalar_one()
    return {"unread": unread, "items": [{"id": str(n.id), "kind": n.kind, "title": n.title, "body": n.body, "link": n.link,
                                         "read_at": n.read_at, "created_at": n.created_at} for n in rows]}


@router.post("/read-all")
def read_all(ctx: Ctx = Depends(get_ctx)):
    ctx.db.execute(update(Notification).where(Notification.user_id == ctx.user.id, Notification.read_at.is_(None)).values(read_at=datetime.now(timezone.utc)))
    return {"ok": True}


@router.post("/{notification_id}/read")
def read_one(notification_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    n = ctx.db.get(Notification, notification_id)
    if not n or n.user_id != ctx.user.id:
        raise NotFound("Notification not found.")
    n.read_at = n.read_at or datetime.now(timezone.utc)
    return {"ok": True}
