from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query, Response

from app.deps import Ctx, require
from app.errors import NotFound
from app.integrations import base as integrations
from app.models import ContactMerge
from app.pagination import PageParams, paginate
from app.schemas import contacts as S
from app.services import contacts as svc
from app.services import duplicates as dup
from app.services import onboarding as ob
from sqlalchemy import select

router = APIRouter(prefix="/clients", tags=["clients"])


@router.get("")
def list_clients(q: str | None = None, kind: str | None = None, status: str | None = None, is_client: bool | None = None,
                 responsible_user_id: uuid.UUID | None = None, include_merged: bool = False, onboarding: str | None = None, page: PageParams = Depends(),
                 ctx: Ctx = Depends(require("clients.read"))):
    stmt = svc.list_contacts(ctx, q=q, kind=kind, status=status, is_client=is_client, responsible_user_id=responsible_user_id, include_merged=include_merged)
    if onboarding == "incomplete":  # clients/prospects without an approved onboarding record (dashboard exception)
        from sqlalchemy import exists
        from app.models import Contact, OnboardingRecord
        stmt = stmt.where(Contact.status.in_(["prospect", "active"]), Contact.is_client.is_(True) | (Contact.status == "prospect"),
                          ~exists().where(OnboardingRecord.contact_id == Contact.id, OnboardingRecord.status == "approved"))
    rows, total = paginate(ctx.db, stmt, page)
    names = svc.user_names(ctx, [r.responsible_user_id for r in rows])
    return {"items": [svc.contact_out(r, names) for r in rows], "total": total, "limit": page.limit, "offset": page.offset}


@router.post("", status_code=201)
def create_client(body: S.ContactCreate, ctx: Ctx = Depends(require("clients.write"))):
    data = body.model_dump()
    addresses = data.pop("addresses")
    c = svc.create_contact(ctx, addresses=addresses, **data)
    return svc.contact_detail(ctx, c)


# --- static paths first (before /{contact_id})
@router.get("/duplicates")
def duplicates(threshold: float = Query(0.6, ge=0.3, le=1.0), ctx: Ctx = Depends(require("clients.read"))):
    return {"items": dup.find_duplicates(ctx, threshold),
            "basis": "Scored on normalised names/aliases, date of birth, email, telephone, company number and shared postcodes. Candidates need human review before any merge."}


@router.get("/merges")
def list_merges(status: str | None = None, page: PageParams = Depends(), ctx: Ctx = Depends(require("clients.read"))):
    stmt = select(ContactMerge).where(ContactMerge.firm_id == ctx.firm_id)
    if status:
        stmt = stmt.where(ContactMerge.status == status)
    rows, total = paginate(ctx.db, stmt.order_by(ContactMerge.created_at.desc()), page)
    names = svc.user_names(ctx, {r.requested_by for r in rows} | {r.reviewed_by for r in rows})
    return {"items": [dup.merge_out(r, names) for r in rows], "total": total, "limit": page.limit, "offset": page.offset}


@router.post("/merges", status_code=201)
def propose_merge(body: S.MergeProposeIn, ctx: Ctx = Depends(require("clients.write"))):
    mg = dup.propose_merge(ctx, body.survivor_id, body.merged_id, body.field_choices, body.reason)
    return dup.merge_out(mg, svc.user_names(ctx, [mg.requested_by]))


@router.post("/merges/{merge_id}/complete")
def complete_merge(merge_id: uuid.UUID, body: S.MergeDecisionIn | None = None, ctx: Ctx = Depends(require("clients.merge"))):
    mg = dup.complete_merge(ctx, merge_id, body.note if body else None)
    return dup.merge_out(mg, svc.user_names(ctx, [mg.requested_by, mg.reviewed_by]))


@router.post("/merges/{merge_id}/reject")
def reject_merge(merge_id: uuid.UUID, body: S.MergeDecisionIn | None = None, ctx: Ctx = Depends(require("clients.merge"))):
    mg = dup.reject_merge(ctx, merge_id, body.note if body else None)
    return dup.merge_out(mg, svc.user_names(ctx, [mg.requested_by, mg.reviewed_by]))


@router.get("/lookup/companies-house")
def companies_house(number: str, ctx: Ctx = Depends(require("clients.read"))):
    """Demonstrates the integration-unavailable state: the provider is not configured, so this returns HTTP 503."""
    return integrations.get_available("companies_house").lookup(number)


@router.get("/{contact_id}")
def get_client(contact_id: uuid.UUID, ctx: Ctx = Depends(require("clients.read"))):
    return svc.contact_detail(ctx, svc.get_contact(ctx, contact_id))


@router.patch("/{contact_id}")
def patch_client(contact_id: uuid.UUID, body: S.ContactPatch, ctx: Ctx = Depends(require("clients.write"))):
    c = svc.get_contact(ctx, contact_id)
    data = body.model_dump(exclude_unset=True)
    ev = data.pop("expected_version")
    svc.update_contact(ctx, c, data, ev)
    return svc.contact_detail(ctx, c)


# --- addresses
@router.post("/{contact_id}/addresses", status_code=201)
def add_address(contact_id: uuid.UUID, body: S.AddressIn, ctx: Ctx = Depends(require("clients.write"))):
    c = svc.get_contact(ctx, contact_id)
    a = svc.add_address(ctx, c, body.model_dump())
    return {"id": str(a.id)}


@router.patch("/{contact_id}/addresses/{address_id}")
def patch_address(contact_id: uuid.UUID, address_id: uuid.UUID, body: S.AddressPatch, ctx: Ctx = Depends(require("clients.write"))):
    c = svc.get_contact(ctx, contact_id)
    svc.update_address(ctx, c, address_id, body.model_dump(exclude_unset=True))
    return {"ok": True}


@router.delete("/{contact_id}/addresses/{address_id}", status_code=204)
def delete_address(contact_id: uuid.UUID, address_id: uuid.UUID, ctx: Ctx = Depends(require("clients.write"))):
    svc.delete_address(ctx, svc.get_contact(ctx, contact_id), address_id)
    return Response(status_code=204)


# --- relationships
@router.post("/{contact_id}/relationships", status_code=201)
def add_relationship(contact_id: uuid.UUID, body: S.RelationshipIn, ctx: Ctx = Depends(require("clients.write"))):
    r = svc.add_relationship(ctx, svc.get_contact(ctx, contact_id), body.model_dump())
    return {"id": str(r.id)}


@router.patch("/{contact_id}/relationships/{rid}")
def patch_relationship(contact_id: uuid.UUID, rid: uuid.UUID, body: S.RelationshipPatch, ctx: Ctx = Depends(require("clients.write"))):
    svc.update_relationship(ctx, svc.get_contact(ctx, contact_id), rid, body.model_dump(exclude_unset=True))
    return {"ok": True}


@router.delete("/{contact_id}/relationships/{rid}", status_code=204)
def delete_relationship(contact_id: uuid.UUID, rid: uuid.UUID, ctx: Ctx = Depends(require("clients.write"))):
    svc.delete_relationship(ctx, svc.get_contact(ctx, contact_id), rid)
    return Response(status_code=204)


# --- onboarding (simulated checks)
@router.get("/{contact_id}/onboarding")
def get_onboarding(contact_id: uuid.UUID, ctx: Ctx = Depends(require("clients.read"))):
    return ob.onboarding_out(ctx, svc.get_contact(ctx, contact_id))


@router.post("/{contact_id}/onboarding", status_code=201)
def start_onboarding(contact_id: uuid.UUID, ctx: Ctx = Depends(require("onboarding.manage"))):
    c = svc.get_contact(ctx, contact_id)
    ob.get_or_create(ctx, c)
    return ob.onboarding_out(ctx, c)


@router.put("/{contact_id}/onboarding/form")
def submit_form(contact_id: uuid.UUID, body: S.IntakeFormIn, ctx: Ctx = Depends(require("onboarding.manage"))):
    c = svc.get_contact(ctx, contact_id)
    ob.submit_form(ctx, c, body.form)
    return ob.onboarding_out(ctx, c)


@router.post("/{contact_id}/onboarding/checks", status_code=201)
def run_check(contact_id: uuid.UUID, body: S.CheckRunIn, ctx: Ctx = Depends(require("onboarding.manage"))):
    c = svc.get_contact(ctx, contact_id)
    ob.run_check(ctx, c, body.check_type)
    return ob.onboarding_out(ctx, c)


@router.post("/{contact_id}/onboarding/checks/{check_id}/review")
def review_check(contact_id: uuid.UUID, check_id: uuid.UUID, body: S.CheckReviewIn, ctx: Ctx = Depends(require("onboarding.approve"))):
    c = svc.get_contact(ctx, contact_id)
    ob.review_check(ctx, c, check_id, body.decision, body.note)
    return ob.onboarding_out(ctx, c)


@router.post("/{contact_id}/onboarding/checks/{check_id}/waive")
def waive_check(contact_id: uuid.UUID, check_id: uuid.UUID, body: S.CheckWaiveIn, ctx: Ctx = Depends(require("onboarding.approve"))):
    c = svc.get_contact(ctx, contact_id)
    ob.waive_check(ctx, c, check_id, body.reason)
    return ob.onboarding_out(ctx, c)


@router.post("/{contact_id}/onboarding/submit")
def submit_onboarding(contact_id: uuid.UUID, ctx: Ctx = Depends(require("onboarding.manage"))):
    c = svc.get_contact(ctx, contact_id)
    ob.submit_for_review(ctx, c)
    return ob.onboarding_out(ctx, c)


@router.post("/{contact_id}/onboarding/approve")
def approve_onboarding(contact_id: uuid.UUID, body: S.OnboardingDecisionIn | None = None, ctx: Ctx = Depends(require("onboarding.approve"))):
    c = svc.get_contact(ctx, contact_id)
    ob.approve(ctx, c, body.note if body else None, body.risk_level if body else None)
    return {"onboarding": ob.onboarding_out(ctx, c), "contact": svc.contact_out(c)}


@router.post("/{contact_id}/onboarding/reject")
def reject_onboarding(contact_id: uuid.UUID, body: S.OnboardingDecisionIn | None = None, ctx: Ctx = Depends(require("onboarding.approve"))):
    c = svc.get_contact(ctx, contact_id)
    ob.reject(ctx, c, body.note if body else None)
    return ob.onboarding_out(ctx, c)
