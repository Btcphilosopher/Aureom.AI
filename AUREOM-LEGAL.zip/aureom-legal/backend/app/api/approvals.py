"""Approvals inbox. Decisions are made through the owning domain's endpoint (so the approved action executes with
its own validation); this router gives a single place to see what is waiting and where to act."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from sqlalchemy import and_, or_, select

from app.deps import Ctx, get_ctx
from app.errors import NotFound
from app.models import Approval, User
from app.pagination import PageParams, paginate
from app.permissions import matter_clause

router = APIRouter(prefix="/approvals", tags=["approvals"])

HREFS = {
    "matter_transition": lambda a: f"/matters/{a.matter_id or a.subject_id}",
    "invoice_issue": lambda a: f"/billing/invoices/{a.subject_id}",
    "invoice_approval": lambda a: f"/billing/invoices/{a.subject_id}",
    "journal_post": lambda a: f"/ledger/journals/{a.subject_id}",
    "payment_allocation": lambda a: "/ledger/receipts",
    "client_funds_transfer": lambda a: "/ledger/transfers",
    "revenue_recognition": lambda a: "/ledger/revenue",
    "reconciliation_signoff": lambda a: "/ledger/reconciliation",
    "document_export": lambda a: f"/documents/exports/{a.subject_id}",
    "document_approval": lambda a: f"/documents/{a.subject_id}",
    "correspondence_send": lambda a: f"/correspondence/{a.subject_id}",
    "conflict_decision": lambda a: f"/clients/conflicts/{a.subject_id}",
}


def _row(a: Approval, names: dict) -> dict:
    return {"id": str(a.id), "kind": a.kind, "status": a.status, "subject_type": a.subject_type, "subject_id": str(a.subject_id) if a.subject_id else None,
            "matter_id": str(a.matter_id) if a.matter_id else None, "requested_by": str(a.requested_by), "requested_by_name": names.get(a.requested_by),
            "decided_by": str(a.decided_by) if a.decided_by else None, "decided_by_name": names.get(a.decided_by),
            "decided_at": a.decided_at, "decision_note": a.decision_note, "payload": a.payload, "payload_hash": a.payload_hash,
            "required_permission": a.required_permission, "created_at": a.created_at,
            "href": HREFS.get(a.kind, lambda _: None)(a)}


def _visible(ctx: Ctx):
    """Approvals tied to a matter are shown only if the matter is visible to the viewer."""
    from app.models import Matter
    return or_(Approval.matter_id.is_(None), Approval.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))


@router.get("")
def list_approvals(scope: str = "waiting_for_me", status: str | None = None, ctx: Ctx = Depends(get_ctx), page: PageParams = Depends()):
    """scope: waiting_for_me (pending, I hold the permission, not my own request) | requested_by_me | all (audit.read)."""
    stmt = select(Approval).where(Approval.firm_id == ctx.firm_id, _visible(ctx))
    if scope == "requested_by_me":
        stmt = stmt.where(Approval.requested_by == ctx.user.id)
    elif scope == "all":
        ctx.require("audit.read")
    else:
        perms = list(ctx.perms)
        stmt = stmt.where(Approval.status == "pending", Approval.requested_by != ctx.user.id,
                          or_(Approval.required_permission.is_(None), Approval.required_permission.in_(perms)))
    if status:
        stmt = stmt.where(Approval.status == status)
    rows, total = paginate(ctx.db, stmt.order_by(Approval.created_at.desc()), page)
    ids = {r.requested_by for r in rows} | {r.decided_by for r in rows if r.decided_by}
    names = {u.id: u.name for u in ctx.db.execute(select(User).where(User.id.in_(ids))).scalars()} if ids else {}
    return {"items": [_row(a, names) for a in rows], "total": total, "limit": page.limit, "offset": page.offset}


@router.get("/{approval_id}")
def get_approval(approval_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    a = ctx.db.execute(select(Approval).where(Approval.id == approval_id, Approval.firm_id == ctx.firm_id, _visible(ctx))).scalar_one_or_none()
    if not a:
        raise NotFound("Approval not found.")
    names = {u.id: u.name for u in ctx.db.execute(select(User).where(User.id.in_([a.requested_by, a.decided_by or a.requested_by]))).scalars()}
    return _row(a, names)
