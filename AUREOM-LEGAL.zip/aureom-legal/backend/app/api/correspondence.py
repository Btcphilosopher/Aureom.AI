from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy import exists, func, select

from app.deps import Ctx, get_ctx, require
from app.models import Correspondence, CorrespondenceAttachment, Matter, User
from app.pagination import Page, PageParams
from app.schemas import correspondence as S
from app.services import correspondence as svc
from app.services import documents as docs

router = APIRouter(prefix="/correspondence", tags=["correspondence"])


def _ref(db, matter_id) -> str | None:
    if not matter_id:
        return None
    m = db.get(Matter, matter_id)
    return m.reference if m else None


def _out(ctx: Ctx, c: Correspondence) -> S.CorrespondenceOut:
    o = S.CorrespondenceOut.model_validate(c)
    o.matter_reference = _ref(ctx.db, c.matter_id)
    o.attachments = [S.AttachmentOut.model_validate(a) for a in svc.attachments_of(ctx.db, c.id)]
    o.simulated = bool((c.meta or {}).get("simulated"))
    o.untrusted_content = bool((c.meta or {}).get("untrusted_content"))
    return o


# ---- static routes first
@router.post("/sync")
def sync(ctx: Ctx = Depends(require("correspondence.write"))):
    """Pull new messages from the configured mailbox provider (a SIMULATED mailbox in this build). Idempotent."""
    return svc.sync_inbox(ctx)


@router.get("/matter-notes", response_model=list[S.NoteOut])
def matter_notes(matter_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.read"))):
    return _notes_out(ctx, svc.list_notes(ctx, matter_id=matter_id))


@router.post("/matter-notes", response_model=S.NoteOut, status_code=201)
def add_matter_note(body: S.NoteIn, ctx: Ctx = Depends(require("correspondence.write"))):
    n = svc.add_note(ctx, body=body.body, matter_id=body.matter_id)
    return _notes_out(ctx, [n])[0]


@router.get("/client-view", response_model=list[S.ClientVisibleCorrespondence])
def client_view(matter_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.read"))):
    """Preview of exactly what an authorised client would see for a matter (no drafts, notes or approval data)."""
    docs._load_matter(ctx, matter_id)
    out = []
    for c in svc.client_visible_items(ctx.db, ctx.firm_id, matter_id):
        atts = [a.filename for a in svc.attachments_of(ctx.db, c.id)]
        out.append(S.ClientVisibleCorrespondence(id=c.id, direction=c.direction, from_addr=c.from_addr, to_addrs=c.to_addrs, subject=c.subject,
                                                 body_text=c.body_text, date=c.sent_at or c.received_at, attachments=atts))
    return out


def _notes_out(ctx: Ctx, notes) -> list[S.NoteOut]:
    names = {u.id: u.name for u in ctx.db.execute(select(User).where(User.id.in_({n.author_id for n in notes}))).scalars()} if notes else {}
    out = []
    for n in notes:
        o = S.NoteOut.model_validate(n)
        o.author_name = names.get(n.author_id)
        out.append(o)
    return out


@router.get("", response_model=Page[S.CorrespondenceListItem])
def list_correspondence(matter_id: uuid.UUID | None = None, status: str | None = None, direction: str | None = None, unfiled: bool | None = None,
                        is_read: bool | None = None, q: str | None = None, page: PageParams = Depends(), ctx: Ctx = Depends(require("correspondence.read"))):
    stmt = select(Correspondence, Matter.reference).outerjoin(Matter, Matter.id == Correspondence.matter_id).where(svc.visible_clause(ctx))
    if matter_id:
        stmt = stmt.where(Correspondence.matter_id == matter_id)
    if status:
        stmt = stmt.where(Correspondence.status == status)
    if direction:
        stmt = stmt.where(Correspondence.direction == direction)
    if unfiled is True:
        stmt = stmt.where(Correspondence.matter_id.is_(None))
    elif unfiled is False:
        stmt = stmt.where(Correspondence.matter_id.is_not(None))
    if is_read is not None:
        stmt = stmt.where(Correspondence.is_read == is_read)
    if q:
        stmt = stmt.where(Correspondence.tsv.op("@@")(func.websearch_to_tsquery("english", q)))
    total = ctx.db.execute(select(func.count()).select_from(stmt.order_by(None).subquery())).scalar_one()
    rows = ctx.db.execute(stmt.order_by(func.coalesce(Correspondence.received_at, Correspondence.sent_at, Correspondence.created_at).desc(), Correspondence.id)
                          .limit(page.limit).offset(page.offset)).all()
    with_att = set(ctx.db.execute(select(CorrespondenceAttachment.correspondence_id).where(
        CorrespondenceAttachment.correspondence_id.in_([c.id for c, _ in rows]))).scalars()) if rows else set()
    items = [S.CorrespondenceListItem(id=c.id, matter_id=c.matter_id, matter_reference=ref, direction=c.direction, status=c.status, from_addr=c.from_addr,
                                      to_addrs=c.to_addrs, subject=c.subject, preview=" ".join(c.body_text.split())[:180], client_visible=c.client_visible,
                                      is_read=c.is_read, has_attachments=c.id in with_att, received_at=c.received_at, sent_at=c.sent_at, created_at=c.created_at)
             for c, ref in rows]
    return Page(items=items, total=total, limit=page.limit, offset=page.offset)


@router.post("", response_model=S.CorrespondenceOut, status_code=201)
def create_draft(body: S.DraftIn, ctx: Ctx = Depends(require("correspondence.write"))):
    c = svc.create_draft(ctx, matter_id=body.matter_id, subject=body.subject, body_text=body.body_text, to_addrs=body.to_addrs, cc_addrs=body.cc_addrs,
                         reply_to_id=body.reply_to_id, client_visible=body.client_visible, attachment_document_ids=body.attachment_document_ids)
    return _out(ctx, c)


@router.get("/{corr_id}", response_model=S.CorrespondenceOut)
def get_one(corr_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.read"))):
    return _out(ctx, svc.get(ctx, corr_id))


@router.post("/{corr_id}/read", response_model=S.CorrespondenceOut)
def mark_read(corr_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.read"))):
    c = svc.get(ctx, corr_id)
    c.is_read = True
    return _out(ctx, c)


@router.patch("/{corr_id}", response_model=S.CorrespondenceOut)
def edit_draft(corr_id: uuid.UUID, body: S.DraftPatch, ctx: Ctx = Depends(require("correspondence.write"))):
    data = body.model_dump(exclude_unset=True)
    exp = data.pop("expected_version")
    return _out(ctx, svc.update_draft(ctx, corr_id, data, exp))


@router.post("/{corr_id}/file")
def file_to_matter(corr_id: uuid.UUID, body: S.FileIn, ctx: Ctx = Depends(require("correspondence.write"))):
    return svc.file_to_matter(ctx, corr_id, body.matter_id)


@router.get("/{corr_id}/notes", response_model=list[S.NoteOut])
def list_notes(corr_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.read"))):
    return _notes_out(ctx, svc.list_notes(ctx, correspondence_id=corr_id))


@router.post("/{corr_id}/notes", response_model=S.NoteOut, status_code=201)
def add_note(corr_id: uuid.UUID, body: S.NoteIn, ctx: Ctx = Depends(require("correspondence.write"))):
    n = svc.add_note(ctx, body=body.body, correspondence_id=corr_id)
    return _notes_out(ctx, [n])[0]


@router.post("/{corr_id}/request-approval", response_model=S.CorrespondenceOut)
def request_approval(corr_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.write"))):
    return _out(ctx, svc.request_approval(ctx, corr_id))


@router.post("/{corr_id}/approve", response_model=S.CorrespondenceOut)
def approve(corr_id: uuid.UUID, body: S.DecisionIn, ctx: Ctx = Depends(require("correspondence.approve"))):
    return _out(ctx, svc.decide(ctx, corr_id, body.approve, body.note))


@router.post("/{corr_id}/send", response_model=S.CorrespondenceOut)
def send(corr_id: uuid.UUID, ctx: Ctx = Depends(require("correspondence.write"))):
    """Sends via the e-mail provider (SIMULATED in this build). Refused unless the exact current content is approved."""
    return _out(ctx, svc.send(ctx, corr_id))
