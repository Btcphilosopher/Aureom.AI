from __future__ import annotations

import uuid
from datetime import date, datetime, time, timedelta, timezone

from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy import func, select

from app.deps import Ctx, require
from app.errors import NotFound, PermissionDenied, ValidationFailed
from app.integrations import base as integrations
from app.models import BusinessCalendar, CalendarHoliday, Deadline, DeadlineRule, DiaryEvent, Matter, User
from app.pagination import Page, PageParams, paginate
from app.schemas.diary import *  # noqa: F401,F403
from app.schemas.diary import (CalendarIn, CalendarOut, CalendarUpdate, DeadlineCalculateIn, DeadlineConfirmIn, DeadlineManualCreate, DeadlineOut,
                               DeadlineRejectIn, DeadlineUpdate, EventCreate, EventOut, EventUpdate, FeedItem, HolidayImportIn, HolidayIn, HolidayOut,
                               RuleIn, RuleOut, RuleUpdate)
from app.services import business_calendar as bc
from app.services import deadlines as dl
from app.services import diary as svc
from app.services.tasks import LOCAL_TZ

router = APIRouter(prefix="/diary", tags=["diary"])


def _admin(ctx: Ctx) -> None:
    """Calendars, holidays and deadline rules are firm configuration: administrators (admin.settings) or
    partners/compliance (matters.approve)."""
    if not (ctx.has("admin.settings") or ctx.has("matters.approve")):
        raise PermissionDenied("Managing calendars and deadline rules needs administrator or partner permissions.", details={"required": ["admin.settings", "matters.approve"]})


# ------------------------------------------------------------------ feed / ICS
@router.get("/feed", response_model=list[FeedItem])
def feed(from_: date = Query(..., alias="from"), to: date = Query(...), scope: str = Query("mine", pattern="^(mine|all)$"),
         ctx: Ctx = Depends(require("tasks.read"))):
    return [FeedItem(**{k: v for k, v in it.items() if k in FeedItem.model_fields}) for it in svc.feed(ctx, from_, to, scope)]


@router.get("/ics")
def ics(from_: date = Query(..., alias="from"), to: date = Query(...), scope: str = Query("mine", pattern="^(mine|all)$"),
        ctx: Ctx = Depends(require("tasks.read"))):
    provider = integrations.get_available("calendar")
    items = svc.ics_items(ctx, from_, to, scope)
    ctx.audit("diary.ics_export", "diary", None, f"Diary exported as ICS ({len(items)} items)", details={"from": from_.isoformat(), "to": to.isoformat(), "scope": scope})
    body = provider.render_ics(items, calname=f"AUREOM LEGAL - {ctx.user.name} (demonstration)")
    return Response(body, media_type="text/calendar; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="aureom-diary.ics"'})


# ------------------------------------------------------------------ events
def _event_out(ctx: Ctx, rows: list[DiaryEvent]) -> list[EventOut]:
    mids = {e.matter_id for e in rows if e.matter_id}
    refs = dict(ctx.db.execute(select(Matter.id, Matter.reference).where(Matter.id.in_(mids))).all()) if mids else {}
    uids = {e.owner_id for e in rows}
    names = dict(ctx.db.execute(select(User.id, User.name).where(User.id.in_(uids))).all()) if uids else {}
    return [EventOut(id=e.id, matter_id=e.matter_id, matter_reference=refs.get(e.matter_id), title=e.title, kind=e.kind, start_at=e.start_at, end_at=e.end_at,
                     location=e.location, attendee_ids=list(e.attendee_ids or []), owner_id=e.owner_id, owner_name=names.get(e.owner_id),
                     description=e.description, external_calendar_ref=e.external_calendar_ref, version=e.version) for e in rows]


@router.get("/events", response_model=Page[EventOut])
def list_events(from_: date = Query(..., alias="from"), to: date = Query(...), scope: str = Query("mine", pattern="^(mine|all)$"),
                matter_id: uuid.UUID | None = None, user_id: uuid.UUID | None = None, params: PageParams = Depends(),
                ctx: Ctx = Depends(require("tasks.read"))):
    lo, hi = svc._day_bounds(from_, to)
    stmt = select(DiaryEvent).where(svc.event_clause(ctx, scope), DiaryEvent.start_at >= lo, DiaryEvent.start_at < hi)
    if matter_id:
        stmt = stmt.where(DiaryEvent.matter_id == matter_id)
    if user_id:
        stmt = stmt.where((DiaryEvent.owner_id == user_id) | DiaryEvent.attendee_ids.contains([user_id]))
    rows, total = paginate(ctx.db, stmt.order_by(DiaryEvent.start_at), params)
    return Page[EventOut](items=_event_out(ctx, rows), total=total, limit=params.limit, offset=params.offset)


@router.post("/events", response_model=EventOut, status_code=201)
def create_event(body: EventCreate, ctx: Ctx = Depends(require("tasks.write"))):
    return _event_out(ctx, [svc.create_event(ctx, **body.model_dump())])[0]


@router.get("/events/{event_id}", response_model=EventOut)
def get_event(event_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.read"))):
    return _event_out(ctx, [svc.get_event(ctx, event_id)])[0]


@router.patch("/events/{event_id}", response_model=EventOut)
def patch_event(event_id: uuid.UUID, body: EventUpdate, ctx: Ctx = Depends(require("tasks.write"))):
    e = svc.get_event(ctx, event_id)
    svc.update_event(ctx, e, body.model_dump(exclude_unset=True, exclude={"expected_version"}), body.expected_version)
    return _event_out(ctx, [e])[0]


@router.delete("/events/{event_id}", status_code=204)
def delete_event(event_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    svc.delete_event(ctx, svc.get_event(ctx, event_id))


@router.post("/events/{event_id}/sync")
def sync_event(event_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    e = svc.get_event(ctx, event_id)
    provider = integrations.get_available("calendar")
    res = provider.sync_event(ctx.db, ctx.firm_id, e.id, e.title)
    ctx.audit("diary.sync_simulated", "diary_event", e.id, "Calendar sync requested (simulated)", matter_id=e.matter_id)
    return {**res, "provider": provider.info().to_dict()}


# ------------------------------------------------------------------ business calendars
def _cal_out(db, c: BusinessCalendar) -> CalendarOut:
    n = db.execute(select(func.count()).select_from(CalendarHoliday).where(CalendarHoliday.calendar_id == c.id)).scalar_one()
    return CalendarOut(id=c.id, name=c.name, jurisdiction=c.jurisdiction, timezone=c.timezone, weekend_days=list(c.weekend_days or []),
                       is_default=c.is_default, source_note=c.source_note, holiday_count=n)


def _check_weekend(days: list[int]) -> list[int]:
    if any(d < 0 or d > 6 for d in days) or len(set(days)) > 3:
        raise ValidationFailed("Weekend days must be weekday numbers 0 (Mon) - 6 (Sun), at most three.")
    return sorted(set(days))


def _single_default(ctx: Ctx, keep: BusinessCalendar) -> None:
    for c in ctx.db.execute(select(BusinessCalendar).where(BusinessCalendar.firm_id == ctx.firm_id, BusinessCalendar.id != keep.id, BusinessCalendar.is_default)).scalars():
        c.is_default = False


@router.get("/calendars", response_model=list[CalendarOut])
def list_calendars(ctx: Ctx = Depends(require("tasks.read"))):
    return [_cal_out(ctx.db, c) for c in ctx.db.execute(select(BusinessCalendar).where(BusinessCalendar.firm_id == ctx.firm_id).order_by(BusinessCalendar.name)).scalars()]


@router.post("/calendars", response_model=CalendarOut, status_code=201)
def create_calendar(body: CalendarIn, ctx: Ctx = Depends(require("tasks.read"))):
    _admin(ctx)
    c = BusinessCalendar(firm_id=ctx.firm_id, name=body.name, jurisdiction=body.jurisdiction, timezone=bc.validate_timezone(body.timezone),
                         weekend_days=_check_weekend(body.weekend_days), is_default=body.is_default, source_note=body.source_note)
    ctx.db.add(c)
    ctx.db.flush()
    if body.is_default:
        _single_default(ctx, c)
    ctx.audit("calendar.created", "business_calendar", c.id, f"Business calendar created: {c.name}")
    return _cal_out(ctx.db, c)


@router.patch("/calendars/{calendar_id}", response_model=CalendarOut)
def update_calendar(calendar_id: uuid.UUID, body: CalendarUpdate, ctx: Ctx = Depends(require("tasks.read"))):
    _admin(ctx)
    c = bc.get_calendar(ctx.db, ctx.firm_id, calendar_id)
    ch = body.model_dump(exclude_unset=True)
    if "timezone" in ch:
        bc.validate_timezone(ch["timezone"])
    if "weekend_days" in ch:
        ch["weekend_days"] = _check_weekend(ch["weekend_days"])
    for k, v in ch.items():
        setattr(c, k, v)
    ctx.db.flush()
    if c.is_default:
        _single_default(ctx, c)
    ctx.audit("calendar.updated", "business_calendar", c.id, f"Business calendar updated: {c.name}", details={"fields": sorted(ch)})
    return _cal_out(ctx.db, c)


@router.get("/calendars/{calendar_id}/holidays", response_model=list[HolidayOut])
def list_holidays(calendar_id: uuid.UUID, year: int | None = None, ctx: Ctx = Depends(require("tasks.read"))):
    c = bc.get_calendar(ctx.db, ctx.firm_id, calendar_id)
    stmt = select(CalendarHoliday).where(CalendarHoliday.calendar_id == c.id)
    if year:
        stmt = stmt.where(CalendarHoliday.holiday_date >= date(year, 1, 1), CalendarHoliday.holiday_date <= date(year, 12, 31))
    return [HolidayOut(id=h.id, date=h.holiday_date, name=h.name) for h in ctx.db.execute(stmt.order_by(CalendarHoliday.holiday_date)).scalars()]


@router.post("/calendars/{calendar_id}/holidays", response_model=HolidayOut, status_code=201)
def add_holiday(calendar_id: uuid.UUID, body: HolidayIn, ctx: Ctx = Depends(require("tasks.read"))):
    _admin(ctx)
    c = bc.get_calendar(ctx.db, ctx.firm_id, calendar_id)
    if ctx.db.execute(select(CalendarHoliday.id).where(CalendarHoliday.calendar_id == c.id, CalendarHoliday.holiday_date == body.date)).first():
        raise ValidationFailed("That date is already a holiday in this calendar.")
    h = CalendarHoliday(firm_id=ctx.firm_id, calendar_id=c.id, holiday_date=body.date, name=body.name)
    ctx.db.add(h)
    ctx.db.flush()
    ctx.audit("calendar.holiday_added", "business_calendar", c.id, f"Holiday added: {body.name} {body.date}")
    return HolidayOut(id=h.id, date=h.holiday_date, name=h.name)


@router.delete("/calendars/{calendar_id}/holidays/{holiday_id}", status_code=204)
def remove_holiday(calendar_id: uuid.UUID, holiday_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.read"))):
    _admin(ctx)
    c = bc.get_calendar(ctx.db, ctx.firm_id, calendar_id)
    h = ctx.db.get(CalendarHoliday, holiday_id)
    if not h or h.calendar_id != c.id:
        raise NotFound("Holiday not found.")
    ctx.audit("calendar.holiday_removed", "business_calendar", c.id, f"Holiday removed: {h.name} {h.holiday_date}")
    ctx.db.delete(h)


@router.post("/calendars/{calendar_id}/holidays/import", response_model=dict)
def import_holidays(calendar_id: uuid.UUID, body: HolidayImportIn, ctx: Ctx = Depends(require("tasks.read"))):
    """Bulk input of bank-holiday data. The source note records where the data came from and who loaded it."""
    _admin(ctx)
    c = bc.get_calendar(ctx.db, ctx.firm_id, calendar_id)
    existing = set(ctx.db.execute(select(CalendarHoliday.holiday_date).where(CalendarHoliday.calendar_id == c.id)).scalars())
    added = 0
    for h in body.holidays:
        if h.date not in existing:
            ctx.db.add(CalendarHoliday(firm_id=ctx.firm_id, calendar_id=c.id, holiday_date=h.date, name=h.name))
            existing.add(h.date)
            added += 1
    if body.source_note:
        c.source_note = f"{body.source_note} (loaded by {ctx.user.name} on {date.today().isoformat()})"
    ctx.db.flush()
    ctx.audit("calendar.holidays_imported", "business_calendar", c.id, f"Holidays imported: {added} new", details={"added": added, "submitted": len(body.holidays)})
    return {"added": added, "skipped_existing": len(body.holidays) - added}


# ------------------------------------------------------------------ deadline rules
def _rule_out(r: DeadlineRule) -> RuleOut:
    return RuleOut(id=r.id, key=r.key, name=r.name, jurisdiction=r.jurisdiction, offset_days=r.offset_days, day_type=r.day_type, direction=r.direction,
                   roll_convention=r.roll_convention, description=r.description, source_note=r.source_note, is_active=r.is_active)


@router.get("/deadline-rules", response_model=list[RuleOut])
def list_rules(active_only: bool = False, ctx: Ctx = Depends(require("tasks.read"))):
    stmt = select(DeadlineRule).where(DeadlineRule.firm_id == ctx.firm_id).order_by(DeadlineRule.name)
    if active_only:
        stmt = stmt.where(DeadlineRule.is_active)
    return [_rule_out(r) for r in ctx.db.execute(stmt).scalars()]


@router.post("/deadline-rules", response_model=RuleOut, status_code=201)
def create_rule(body: RuleIn, ctx: Ctx = Depends(require("tasks.read"))):
    _admin(ctx)
    if ctx.db.execute(select(DeadlineRule.id).where(DeadlineRule.firm_id == ctx.firm_id, DeadlineRule.key == body.key)).first():
        raise ValidationFailed("A rule with that key already exists.")
    r = DeadlineRule(firm_id=ctx.firm_id, **body.model_dump())
    ctx.db.add(r)
    ctx.db.flush()
    ctx.audit("deadline_rule.created", "deadline_rule", r.id, f"Deadline rule created: {r.key}")
    return _rule_out(r)


@router.patch("/deadline-rules/{rule_id}", response_model=RuleOut)
def update_rule(rule_id: uuid.UUID, body: RuleUpdate, ctx: Ctx = Depends(require("tasks.read"))):
    _admin(ctx)
    r = ctx.db.get(DeadlineRule, rule_id)
    if not r or r.firm_id != ctx.firm_id:
        raise NotFound("Deadline rule not found.")
    ch = body.model_dump(exclude_unset=True)
    for k, v in ch.items():
        setattr(r, k, v)
    ctx.db.flush()
    ctx.audit("deadline_rule.updated", "deadline_rule", r.id, f"Deadline rule updated: {r.key}", details={"fields": sorted(ch)})
    return _rule_out(r)


# ------------------------------------------------------------------ deadlines
def _deadline_out(ctx: Ctx, rows: list[Deadline]) -> list[DeadlineOut]:
    mids = {d.matter_id for d in rows}
    refs = dict(ctx.db.execute(select(Matter.id, Matter.reference).where(Matter.id.in_(mids))).all()) if mids else {}
    uids = {d.confirmed_by for d in rows if d.confirmed_by}
    names = dict(ctx.db.execute(select(User.id, User.name).where(User.id.in_(uids))).all()) if uids else {}
    cids = {d.calendar_id for d in rows if d.calendar_id}
    cals = dict(ctx.db.execute(select(BusinessCalendar.id, BusinessCalendar.name).where(BusinessCalendar.id.in_(cids))).all()) if cids else {}
    return [DeadlineOut(
        id=d.id, matter_id=d.matter_id, matter_reference=refs.get(d.matter_id), title=d.title, due_date=d.due_date, due_time=d.due_time, timezone=d.timezone,
        origin=d.origin, status=d.status, authoritative=dl.is_authoritative(d), label=dl.label_for(d, names.get(d.confirmed_by)), jurisdiction=d.jurisdiction,
        rule_key=d.rule_key, calendar_id=d.calendar_id, calendar_name=cals.get(d.calendar_id), trigger_date=d.trigger_date, assumptions=d.assumptions,
        calculation=d.calculation or {}, source_document_id=d.source_document_id, source_version_id=d.source_version_id, source_passage=d.source_passage,
        source_ref=d.source_ref or {}, agent_run_id=d.agent_run_id, suggested_by=d.suggested_by, reviewer_id=d.reviewer_id, confirmed_by=d.confirmed_by,
        confirmed_by_name=names.get(d.confirmed_by), confirmed_at=d.confirmed_at, review_note=d.review_note, version=d.version) for d in rows]


@router.get("/deadlines", response_model=Page[DeadlineOut])
def list_deadlines(matter_id: uuid.UUID | None = None, status: str | None = None, origin: str | None = None, due_from: date | None = None,
                   due_to: date | None = None, needs_attention: bool = False, days: int = Query(14, ge=1, le=365),
                   params: PageParams = Depends(), ctx: Ctx = Depends(require("tasks.read"))):
    from sqlalchemy import and_, or_
    stmt = select(Deadline).where(dl.deadline_clause(ctx))
    if matter_id:
        stmt = stmt.where(Deadline.matter_id == matter_id)
    if status:
        stmt = stmt.where(Deadline.status.in_(status.split(",")))
    if origin:
        stmt = stmt.where(Deadline.origin == origin)
    if due_from:
        stmt = stmt.where(Deadline.due_date >= due_from)
    if due_to:
        stmt = stmt.where(Deadline.due_date <= due_to)
    if needs_attention:
        stmt = stmt.where(or_(Deadline.status == "suggested", and_(Deadline.status == "confirmed", Deadline.due_date <= date.today() + timedelta(days=days))))
    rows, total = paginate(ctx.db, stmt.order_by(Deadline.due_date, Deadline.created_at), params)
    return Page[DeadlineOut](items=_deadline_out(ctx, rows), total=total, limit=params.limit, offset=params.offset)


@router.post("/deadlines", response_model=DeadlineOut, status_code=201)
def create_deadline(body: DeadlineManualCreate, ctx: Ctx = Depends(require("tasks.write"))):
    d = dl.create_manual(ctx, matter_id=body.matter_id, title=body.title, due_date=body.due_date, due_time=body.due_time, timezone_name=body.timezone,
                         jurisdiction=body.jurisdiction, assumptions=body.assumptions, reviewer_id=body.reviewer_id)
    if body.create_task and dl.is_authoritative(d):
        dl._task_for_deadline(ctx, d)
    return _deadline_out(ctx, [d])[0]


@router.post("/deadlines/calculate", response_model=DeadlineOut, status_code=201)
def calculate_deadline(body: DeadlineCalculateIn, ctx: Ctx = Depends(require("tasks.write"))):
    """Creates an UNCONFIRMED suggestion with its full calculation record. It is not authoritative until confirmed."""
    return _deadline_out(ctx, [dl.calculate(ctx, **body.model_dump())])[0]


@router.get("/deadlines/{deadline_id}", response_model=DeadlineOut)
def get_deadline(deadline_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.read"))):
    return _deadline_out(ctx, [dl.get_deadline(ctx, deadline_id)])[0]


@router.patch("/deadlines/{deadline_id}", response_model=DeadlineOut)
def patch_deadline(deadline_id: uuid.UUID, body: DeadlineUpdate, ctx: Ctx = Depends(require("tasks.write"))):
    d = dl.update(ctx, deadline_id, body.model_dump(exclude_unset=True, exclude={"expected_version"}), body.expected_version)
    return _deadline_out(ctx, [d])[0]


@router.post("/deadlines/{deadline_id}/confirm", response_model=DeadlineOut)
def confirm_deadline(deadline_id: uuid.UUID, body: DeadlineConfirmIn, ctx: Ctx = Depends(require("deadlines.confirm"))):
    d = dl.confirm(ctx, deadline_id, review_note=body.review_note, adjusted_due_date=body.adjusted_due_date,
                   adjustment_reason=body.adjustment_reason, create_task=body.create_task, expected_version=body.expected_version)
    return _deadline_out(ctx, [d])[0]


@router.post("/deadlines/{deadline_id}/reject", response_model=DeadlineOut)
def reject_deadline(deadline_id: uuid.UUID, body: DeadlineRejectIn, ctx: Ctx = Depends(require("deadlines.confirm"))):
    return _deadline_out(ctx, [dl.reject(ctx, deadline_id, body.review_note)])[0]
