from __future__ import annotations

import uuid
from datetime import date

from fastapi import APIRouter, Depends
from fastapi.responses import PlainTextResponse

from app.deps import Ctx, get_ctx
from app.schemas.ledger import jsonable
from app.schemas.reports import ReportOut
from app.services import reports as svc

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("", summary="Catalogue of reports and the permission each needs")
def catalogue(ctx: Ctx = Depends(get_ctx)):
    return [{"name": n, "financial": n in svc.FINANCIAL, "permitted": ctx.has("reports.financial" if n in svc.FINANCIAL else "reports.read")} for n in svc.REPORTS]


def _params(date_from: date | None = None, date_to: date | None = None, as_of: date | None = None, matter_id: uuid.UUID | None = None,
            practice_area: str | None = None, office_id: uuid.UUID | None = None, fee_earner_id: uuid.UUID | None = None) -> dict:
    return dict(date_from=date_from, date_to=date_to, as_of=as_of, matter_id=matter_id, practice_area=practice_area, office_id=office_id, fee_earner_id=fee_earner_id)


@router.get("/{name}.csv", response_class=PlainTextResponse, summary="CSV export (audited as a sensitive export)")
def report_csv(name: str, params: dict = Depends(_params), ctx: Ctx = Depends(get_ctx)):
    rep = svc.run(ctx, name, **params)
    ctx.audit("report.exported", "report", None, f"Report '{name}' exported as CSV", details={"report": name, "rows": len(rep["rows"]), "filters": {k: str(v) for k, v in rep["filters"].items()}})
    return PlainTextResponse(svc.to_csv(rep), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})


@router.get("/{name}", response_model=ReportOut)
def report(name: str, params: dict = Depends(_params), ctx: Ctx = Depends(get_ctx)):
    return jsonable(svc.run(ctx, name, **params))
