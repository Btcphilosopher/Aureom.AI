"""Authorised-client portal: a deliberately narrow, read-only view. Clients only see matters on which their contact is the
client party, documents flagged client-visible (and scanned clean), client-visible correspondence and issued invoices.
Internal notes, other parties' details, time records and AI activity are never exposed."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy import select

from app.deps import Ctx, require
from app.errors import NotFound
from app.models import Correspondence, Document, DocumentVersion, Invoice, Matter, User
from app.permissions import can_access_matter, matter_clause
from app.storage import get_storage

router = APIRouter(prefix="/portal", tags=["client portal"])


def _matter(ctx: Ctx, matter_id: uuid.UUID) -> Matter:
    m = ctx.db.execute(select(Matter).where(Matter.id == matter_id, matter_clause(ctx))).scalar_one_or_none()
    if not m:
        raise NotFound("Matter not found.")
    return m


@router.get("/matters")
def my_matters(ctx: Ctx = Depends(require("portal.read"))):
    rows = ctx.db.execute(select(Matter).where(matter_clause(ctx)).order_by(Matter.opened_at.desc().nullslast())).scalars().all()
    return {"items": [{"id": str(m.id), "reference": m.reference, "title": m.title, "status": m.status, "stage": m.stage, "opened_at": m.opened_at} for m in rows]}


@router.get("/matters/{matter_id}")
def matter(matter_id: uuid.UUID, ctx: Ctx = Depends(require("portal.read"))):
    m = _matter(ctx, matter_id)
    users = {u.id: u.name for u in ctx.db.execute(select(User).where(User.id.in_([m.responsible_partner_id, m.fee_earner_id]))).scalars()}
    return {"id": str(m.id), "reference": m.reference, "title": m.title, "description": m.description, "status": m.status, "stage": m.stage,
            "opened_at": m.opened_at, "target_date": m.target_date, "responsible_partner": users.get(m.responsible_partner_id), "fee_earner": users.get(m.fee_earner_id)}


@router.get("/matters/{matter_id}/documents")
def documents(matter_id: uuid.UUID, ctx: Ctx = Depends(require("portal.read"))):
    m = _matter(ctx, matter_id)
    rows = ctx.db.execute(select(Document, DocumentVersion).join(DocumentVersion, DocumentVersion.id == Document.current_version_id)
                          .where(Document.matter_id == m.id, Document.client_visible.is_(True), DocumentVersion.scan_status == "clean")
                          .order_by(Document.created_at.desc())).all()
    return {"items": [{"id": str(d.id), "title": d.title, "doc_type": d.doc_type, "status": d.status, "version_no": v.version_no,
                       "filename": v.original_filename, "size_bytes": v.size_bytes, "updated_at": d.updated_at} for d, v in rows]}


@router.get("/documents/{document_id}/download")
def download(document_id: uuid.UUID, ctx: Ctx = Depends(require("portal.read"))):
    d = ctx.db.get(Document, document_id)
    if not d or d.firm_id != ctx.firm_id or not d.client_visible or not d.matter_id:
        raise NotFound("Document not found.")
    m = ctx.db.get(Matter, d.matter_id)
    if not can_access_matter(ctx, m):
        raise NotFound("Document not found.")
    v = ctx.db.get(DocumentVersion, d.current_version_id)
    if not v or v.scan_status != "clean":
        raise NotFound("Document is not available (not yet scanned).")
    ctx.audit("portal.document_download", "document", d.id, f"Client downloaded {d.title}", matter_id=m.id, details={"version_no": v.version_no})
    return Response(get_storage().get(v.storage_key), media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{v.original_filename.replace(chr(34), "")}"', "X-Content-Type-Options": "nosniff",
                             "Content-Security-Policy": "sandbox; default-src 'none'"})


@router.get("/matters/{matter_id}/correspondence")
def correspondence(matter_id: uuid.UUID, ctx: Ctx = Depends(require("portal.read"))):
    m = _matter(ctx, matter_id)
    rows = ctx.db.execute(select(Correspondence).where(Correspondence.matter_id == m.id, Correspondence.client_visible.is_(True),
                                                       Correspondence.status.in_(["sent", "filed", "received"])).order_by(Correspondence.created_at.desc())).scalars().all()
    return {"items": [{"id": str(c.id), "subject": c.subject, "direction": c.direction, "body_text": c.body_text, "sent_at": c.sent_at or c.received_at} for c in rows]}


@router.get("/matters/{matter_id}/invoices")
def invoices(matter_id: uuid.UUID, ctx: Ctx = Depends(require("portal.read"))):
    m = _matter(ctx, matter_id)
    rows = ctx.db.execute(select(Invoice).where(Invoice.matter_id == m.id, Invoice.status.in_(["issued", "partially_paid", "paid"])).order_by(Invoice.issued_at.desc())).scalars().all()
    return {"items": [{"id": str(i.id), "number": i.number, "kind": i.kind, "status": i.status, "currency": i.currency, "total": i.total,
                       "amount_paid": i.amount_paid, "issued_at": i.issued_at, "due_date": i.due_date} for i in rows]}
