from __future__ import annotations

import uuid
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, Form, Query, Response, UploadFile
from sqlalchemy import and_, exists, func, or_, select

from app.config import get_settings
from app.deps import Ctx, get_ctx, require
from app.errors import InvalidState, NotFound, PermissionDenied, ValidationFailed
from app.models import (Document, DocumentChunk, DocumentTemplate, DocumentVersion, ExportRequest, Folder, Matter, SignatureRequest, User)
from app.pagination import Page, PageParams
from app.permissions import can_preview, matter_clause, visible_matter_ids
from app.schemas import documents as S
from app.services import doc_compare, doc_templates, export_jobs
from app.services import documents as svc
from app.services import filetypes
from app.storage import get_storage

router = APIRouter(prefix="/documents", tags=["documents"])
FTS_OPTS = "StartSel=⟦, StopSel=⟧, MaxWords=35, MinWords=12"


# ------------------------------------------------------------------------- helpers
def _authors(db, versions) -> dict:
    ids = {v.author_id for v in versions}
    return {u.id: u.name for u in db.execute(select(User).where(User.id.in_(ids))).scalars()} if ids else {}


def _vout(v: DocumentVersion, names: dict) -> S.VersionOut:
    o = S.VersionOut.model_validate(v)
    o.author_name = names.get(v.author_id)
    return o


def _doc_out(db, d: Document, matter: tuple | None = None, current: DocumentVersion | None = None):
    o = S.DocumentOut.model_validate(d)
    if matter is None and d.matter_id:
        m = db.get(Matter, d.matter_id)
        matter = (m.reference, m.title) if m else None
    if matter:
        o.matter_reference, o.matter_title = matter
    if current is None and d.current_version_id:
        current = db.get(DocumentVersion, d.current_version_id)
    if current:
        o.current = _vout(current, _authors(db, [current]))
    return o


def _detail(ctx: Ctx, d: Document) -> S.DocumentDetail:
    versions = ctx.db.execute(select(DocumentVersion).where(DocumentVersion.document_id == d.id).order_by(DocumentVersion.version_no.desc())).scalars().all()
    names = _authors(ctx.db, versions)
    out = S.DocumentDetail(**_doc_out(ctx.db, d).model_dump(), versions=[_vout(v, names) for v in versions], meta=d.meta or {})
    srs = ctx.db.execute(select(SignatureRequest).where(SignatureRequest.document_id == d.id).order_by(SignatureRequest.created_at.desc())).scalars().all()
    out.signature_requests = [{"id": str(s.id), "version_id": str(s.version_id), "provider": s.provider, "simulated": s.is_simulated, "status": s.status,
                               "external_ref": s.external_ref, "signers": s.signers, "created_at": s.created_at.isoformat()} for s in srs]
    return out


def _read_upload(file: UploadFile) -> bytes:
    limit = get_settings().max_upload_bytes
    data = file.file.read(limit + 1)
    if len(data) > limit:
        raise ValidationFailed(f"The file exceeds the {limit // (1024 * 1024)} MB limit.", code="file_too_large")
    return data


def _uuid(v: str | None) -> uuid.UUID | None:
    if not v:
        return None
    try:
        return uuid.UUID(v)
    except ValueError:
        raise ValidationFailed("Invalid identifier.")


def _hdr_filename(name: str) -> str:
    ascii_name = filetypes.sanitise_filename(name).encode("ascii", "replace").decode().replace('"', "")
    return f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(name)}"


# ------------------------------------------------------------------------- search (static routes before /{id})
@router.get("/search", response_model=Page[S.SearchHit])
def search(q: str = Query(min_length=2), matter_id: uuid.UUID | None = None, page: PageParams = Depends(), ctx: Ctx = Depends(require("documents.read"))):
    """Full-text search over extracted text of CURRENT versions, only in documents the user may see."""
    tsq = func.websearch_to_tsquery("english", q)
    base = (select(DocumentChunk, Document, Matter.reference, DocumentVersion.version_no,
                   func.ts_headline("english", DocumentChunk.text, tsq, FTS_OPTS).label("snip"), func.ts_rank(DocumentChunk.tsv, tsq).label("rank"))
            .join(Document, Document.id == DocumentChunk.document_id)
            .join(DocumentVersion, and_(DocumentVersion.id == DocumentChunk.version_id, DocumentVersion.id == Document.current_version_id))
            .outerjoin(Matter, Matter.id == Document.matter_id)
            .where(svc.visible_document_clause(ctx), DocumentChunk.tsv.op("@@")(tsq), DocumentVersion.scan_status == "clean"))
    if matter_id:
        base = base.where(Document.matter_id == matter_id)
    total = ctx.db.execute(select(func.count()).select_from(base.order_by(None).subquery())).scalar_one()
    rows = ctx.db.execute(base.order_by(func.ts_rank(DocumentChunk.tsv, tsq).desc(), Document.title, DocumentChunk.ordinal).limit(page.limit).offset(page.offset)).all()
    items = [S.SearchHit(document_id=d.id, title=d.title, doc_type=d.doc_type, matter_id=d.matter_id, matter_reference=ref, version_id=c.version_id,
                         version_no=vno, page=c.page, paragraph=c.paragraph, chunk_id=c.id, is_ocr=c.is_ocr, snippet=snip, rank=float(rank))
             for c, d, ref, vno, snip, rank in rows]
    return Page(items=items, total=total, limit=page.limit, offset=page.offset)


# ------------------------------------------------------------------------- folders
@router.get("/folders", response_model=list[S.FolderOut])
def list_folders(matter_id: uuid.UUID, ctx: Ctx = Depends(require("documents.read"))):
    svc._load_matter(ctx, matter_id)
    return ctx.db.execute(select(Folder).where(Folder.firm_id == ctx.firm_id, Folder.matter_id == matter_id).order_by(Folder.name)).scalars().all()


@router.post("/folders", response_model=S.FolderOut, status_code=201)
def create_folder(body: S.FolderIn, ctx: Ctx = Depends(require("documents.write"))):
    svc._load_matter(ctx, body.matter_id)
    if body.parent_id:
        p = ctx.db.get(Folder, body.parent_id)
        if not p or p.firm_id != ctx.firm_id or p.matter_id != body.matter_id:
            raise ValidationFailed("Parent folder is not in this matter.")
    f = Folder(firm_id=ctx.firm_id, matter_id=body.matter_id, parent_id=body.parent_id, name=body.name.strip())
    ctx.db.add(f); ctx.db.flush()
    ctx.audit("folder.created", "folder", f.id, f"Folder '{f.name}' created", matter_id=body.matter_id)
    return f


def _folder(ctx: Ctx, fid: uuid.UUID) -> Folder:
    f = ctx.db.get(Folder, fid)
    if not f or f.firm_id != ctx.firm_id or not f.matter_id:
        raise NotFound("Folder not found.")
    svc._load_matter(ctx, f.matter_id)
    return f


@router.patch("/folders/{folder_id}", response_model=S.FolderOut)
def rename_folder(folder_id: uuid.UUID, body: S.FolderPatch, ctx: Ctx = Depends(require("documents.write"))):
    f = _folder(ctx, folder_id)
    f.name = body.name.strip()
    ctx.audit("folder.renamed", "folder", f.id, f"Folder renamed to '{f.name}'", matter_id=f.matter_id)
    return f


@router.delete("/folders/{folder_id}", status_code=204)
def delete_folder(folder_id: uuid.UUID, ctx: Ctx = Depends(require("documents.write"))):
    f = _folder(ctx, folder_id)
    busy = ctx.db.execute(select(exists().where(Document.folder_id == f.id))).scalar() or ctx.db.execute(select(exists().where(Folder.parent_id == f.id))).scalar()
    if busy:
        raise InvalidState("Only empty folders can be deleted.", code="folder_not_empty")
    ctx.audit("folder.deleted", "folder", f.id, f"Folder '{f.name}' deleted", matter_id=f.matter_id)
    ctx.db.delete(f)
    return Response(status_code=204)


# ------------------------------------------------------------------------- templates
@router.get("/templates", response_model=list[S.TemplateOut])
def list_templates(approved_only: bool = False, ctx: Ctx = Depends(get_ctx)):
    if not (ctx.has("documents.read") or ctx.has("documents.templates")):
        ctx.require("documents.read")
    stmt = select(DocumentTemplate).where(DocumentTemplate.firm_id == ctx.firm_id).order_by(DocumentTemplate.name)
    if approved_only:
        stmt = stmt.where(DocumentTemplate.approved.is_(True))
    return ctx.db.execute(stmt).scalars().all()


@router.post("/templates", response_model=S.TemplateOut, status_code=201)
def create_template(body: S.TemplateIn, ctx: Ctx = Depends(require("documents.templates"))):
    keys = doc_templates.placeholders(body.body)
    t = DocumentTemplate(firm_id=ctx.firm_id, name=body.name.strip(), doc_type=body.doc_type, practice_area=body.practice_area, body=body.body,
                         fields=[f.model_dump() for f in body.fields], approved=False)
    ctx.db.add(t); ctx.db.flush()
    ctx.audit("template.created", "document_template", t.id, f"Template '{t.name}' created", details={"placeholders": keys})
    return t


@router.get("/templates/{template_id}", response_model=S.TemplateOut)
def get_template(template_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    return doc_templates.get_template(ctx, template_id)


@router.patch("/templates/{template_id}", response_model=S.TemplateOut)
def update_template(template_id: uuid.UUID, body: S.TemplatePatch, ctx: Ctx = Depends(require("documents.templates"))):
    t = doc_templates.get_template(ctx, template_id)
    changed = False
    for k in ("name", "doc_type", "practice_area", "body"):
        v = getattr(body, k)
        if v is not None and v != getattr(t, k):
            setattr(t, k, v); changed = True
    if body.fields is not None:
        t.fields = [f.model_dump() for f in body.fields]; changed = True
    if changed:  # content changed: approval no longer applies
        t.approved, t.approved_by, t.template_version = False, None, t.template_version + 1
    ctx.audit("template.updated", "document_template", t.id, f"Template '{t.name}' updated (v{t.template_version}); approval reset")
    return t


@router.post("/templates/{template_id}/approve", response_model=S.TemplateOut)
def approve_template(template_id: uuid.UUID, ctx: Ctx = Depends(require("documents.templates", "documents.approve"))):
    t = doc_templates.get_template(ctx, template_id)
    t.approved, t.approved_by = True, ctx.user.id
    ctx.audit("template.approved", "document_template", t.id, f"Template '{t.name}' v{t.template_version} approved for use")
    return t


@router.post("/templates/{template_id}/preview")
def preview_template(template_id: uuid.UUID, body: S.TemplateRenderIn, ctx: Ctx = Depends(get_ctx)):
    """Previewed field substitution. Nothing is stored. Shows which fields are missing."""
    t = doc_templates.get_template(ctx, template_id)
    out = doc_templates.render(t, ctx, body.matter_id, body.custom)
    return {"template_id": str(t.id), "template_version": t.template_version, "approved": t.approved, **out}


@router.post("/templates/{template_id}/generate", response_model=S.DocumentDetail, status_code=201)
def generate_from_template(template_id: uuid.UUID, body: S.TemplateRenderIn, ctx: Ctx = Depends(require("documents.write"))):
    if not body.matter_id:
        raise ValidationFailed("matter_id is required to generate a document.")
    doc, _ = doc_templates.generate(ctx, template_id, body.matter_id, body.custom, body.title, body.allow_incomplete)
    svc.process_version_inline(ctx.db, doc.current_version_id)  # small text file: scan/extract synchronously so it is immediately usable
    return _detail(ctx, doc)


# ------------------------------------------------------------------------- exports
@router.get("/exports", response_model=list[S.ExportOut])
def list_exports(ctx: Ctx = Depends(require("documents.export"))):
    stmt = select(ExportRequest).where(ExportRequest.firm_id == ctx.firm_id, ExportRequest.matter_id.in_(visible_matter_ids(ctx)))
    if not ctx.has("documents.export_approve"):
        stmt = stmt.where(ExportRequest.requested_by == ctx.user.id)
    return ctx.db.execute(stmt.order_by(ExportRequest.created_at.desc()).limit(100)).scalars().all()


@router.post("/exports", response_model=S.ExportOut, status_code=201)
def request_export(body: S.ExportIn, ctx: Ctx = Depends(require("documents.export"))):
    return export_jobs.request_export(ctx, body.matter_id, body.document_ids, body.reason)


@router.get("/exports/{export_id}", response_model=S.ExportOut)
def get_export(export_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    ctx.require("documents.export")
    return export_jobs.get_export(ctx, export_id)


@router.post("/exports/{export_id}/decision", response_model=S.ExportOut)
def decide_export(export_id: uuid.UUID, body: S.ExportDecision, ctx: Ctx = Depends(require("documents.export_approve"))):
    return export_jobs.decide_export(ctx, export_id, body.approve, body.note)


@router.get("/exports/{export_id}/download")
def download_export(export_id: uuid.UUID, ctx: Ctx = Depends(require("documents.export"))):
    er, data = export_jobs.download_export(ctx, export_id)
    return Response(content=data, media_type="application/zip", headers={
        "Content-Disposition": f'attachment; filename="export-{er.id.hex[:8]}.zip"', "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox", "Cache-Control": "no-store"})


# ------------------------------------------------------------------------- signature (mock completion)
@router.post("/signature-requests/{sr_id}/simulate-complete")
def simulate_complete(sr_id: uuid.UUID, ctx: Ctx = Depends(require("documents.sign"))):
    """SIMULATED: stands in for the e-signature provider's completion webhook. Only available while the provider is a mock."""
    sr, v = svc.simulate_signature_complete(ctx, sr_id)
    return {"signature_request_id": str(sr.id), "status": sr.status, "simulated": True, "signed_version_no": v.version_no,
            "notice": "This is a SIMULATED signature with no legal effect."}


# ------------------------------------------------------------------------- list / upload / detail
@router.get("", response_model=Page[S.DocumentOut])
def list_documents(matter_id: uuid.UUID | None = None, contact_id: uuid.UUID | None = None, folder_id: uuid.UUID | None = None, doc_type: str | None = None,
                   tag: str | None = None, status: str | None = None, client_visible: bool | None = None, q: str | None = None,
                   scan: str | None = None, page: PageParams = Depends(), ctx: Ctx = Depends(require("documents.read"))):
    stmt = (select(Document, Matter.reference, Matter.title).outerjoin(Matter, Matter.id == Document.matter_id).where(svc.visible_document_clause(ctx)))
    for col, val in ((Document.matter_id, matter_id), (Document.contact_id, contact_id), (Document.folder_id, folder_id), (Document.doc_type, doc_type),
                     (Document.status, status), (Document.client_visible, client_visible)):
        if val is not None:
            stmt = stmt.where(col == val)
    if tag:
        stmt = stmt.where(Document.tags.any(tag))
    if scan:  # 'failed' = infected or scanner error; otherwise an exact scan_status
        wanted = ["infected", "error"] if scan == "failed" else [scan]
        stmt = stmt.where(exists().where(DocumentVersion.document_id == Document.id, DocumentVersion.scan_status.in_(wanted)))
    if q:
        tsq = func.websearch_to_tsquery("english", q)
        hit = exists().where(DocumentChunk.document_id == Document.id, DocumentChunk.version_id == Document.current_version_id, DocumentChunk.tsv.op("@@")(tsq))
        stmt = stmt.where(or_(Document.title.ilike(f"%{q}%"), hit))
    total = ctx.db.execute(select(func.count()).select_from(stmt.order_by(None).subquery())).scalar_one()
    rows = ctx.db.execute(stmt.order_by(Document.updated_at.desc(), Document.id).limit(page.limit).offset(page.offset)).all()
    vers = {v.id: v for v in ctx.db.execute(select(DocumentVersion).where(DocumentVersion.id.in_([d.current_version_id for d, *_ in rows if d.current_version_id]))).scalars()} if rows else {}
    names = _authors(ctx.db, vers.values())
    items = []
    for d, ref, title in rows:
        o = S.DocumentOut.model_validate(d)
        o.matter_reference, o.matter_title = ref, title
        if d.current_version_id in vers:
            o.current = _vout(vers[d.current_version_id], names)
        items.append(o)
    return Page(items=items, total=total, limit=page.limit, offset=page.offset)


@router.post("", response_model=S.DocumentDetail, status_code=201)
def upload(file: UploadFile = File(...), matter_id: str | None = Form(None), contact_id: str | None = Form(None), title: str | None = Form(None),
           doc_type: str = Form("other"), folder_id: str | None = Form(None), tags: str = Form(""), client_visible: bool = Form(False),
           change_note: str | None = Form(None), ctx: Ctx = Depends(require("documents.write"))):
    """Multipart upload (drag-and-drop). The file is validated by extension AND content, stored write-once, then scanned/OCR'd/indexed by the worker."""
    data = _read_upload(file)
    doc, _ = svc.upload_document(ctx, matter_id=_uuid(matter_id), contact_id=_uuid(contact_id), title=(title or file.filename or "Untitled"), doc_type=doc_type,
                                 filename=file.filename or "file", content=data, folder_id=_uuid(folder_id), client_visible=client_visible,
                                 tags=[t for t in tags.split(",") if t.strip()], change_note=change_note)
    return _detail(ctx, doc)


@router.get("/{document_id}", response_model=S.DocumentDetail)
def get_document(document_id: uuid.UUID, ctx: Ctx = Depends(require("documents.read"))):
    return _detail(ctx, svc.get_document(ctx, document_id))


@router.patch("/{document_id}", response_model=S.DocumentDetail)
def patch_document(document_id: uuid.UUID, body: S.DocumentPatch, ctx: Ctx = Depends(require("documents.write"))):
    data = body.model_dump(exclude_unset=True)
    exp = data.pop("expected_version")
    return _detail(ctx, svc.update_metadata(ctx, document_id, data, exp))


@router.post("/{document_id}/versions", response_model=S.DocumentDetail, status_code=201)
def add_version(document_id: uuid.UUID, file: UploadFile = File(...), change_note: str | None = Form(None), ctx: Ctx = Depends(require("documents.write"))):
    doc = svc.get_document(ctx, document_id, write=True)
    data = _read_upload(file)
    doc, _ = svc.upload_document(ctx, document_id=doc.id, title=doc.title, doc_type=doc.doc_type, filename=file.filename or "file", content=data, change_note=change_note)
    return _detail(ctx, doc)


def _gate(ctx: Ctx, document_id: uuid.UUID, version_no: int):
    doc = svc.get_document(ctx, document_id)
    m = svc.matter_for(ctx, doc)
    if m is not None and not can_preview(ctx, m):
        raise PermissionDenied("Preview is not permitted for this matter.")
    v = svc.get_version(ctx, doc, version_no)
    return doc, m, v


@router.get("/{document_id}/versions/{version_no}/preview")
def preview(document_id: uuid.UUID, version_no: int, ctx: Ctx = Depends(require("documents.read"))):
    """SAFE preview: extracted plain text with page/paragraph references. The original file is never rendered in the browser."""
    doc, m, v = _gate(ctx, document_id, version_no)
    svc.assert_servable(v)
    chunks = ctx.db.execute(select(DocumentChunk).where(DocumentChunk.version_id == v.id).order_by(DocumentChunk.ordinal)).scalars().all()
    pages: dict[int, list] = {}
    for c in chunks:
        pages.setdefault(c.page, []).append({"paragraph": c.paragraph, "chunk_id": str(c.id), "ordinal": c.ordinal, "text": c.text, "is_ocr": c.is_ocr})
    ctx.audit("document.previewed", "document", doc.id, f"Preview of '{doc.title}' v{v.version_no}", matter_id=doc.matter_id)
    return {"document_id": str(doc.id), "title": doc.title, "version_id": str(v.id), "version_no": v.version_no, "sha256": v.sha256,
            "content_type": v.content_type, "filename": v.original_filename, "scan_status": v.scan_status, "ocr_status": v.ocr_status,
            "simulated_ocr": v.ocr_status == "simulated", "render": "text",
            "notice": "Text-only preview of extracted content. The original file is not rendered. Download is available subject to permissions.",
            "text_available": bool(chunks), "pages": [{"page": p, "paragraphs": ps} for p, ps in sorted(pages.items())]}


@router.get("/{document_id}/versions/{version_no}/download")
def download(document_id: uuid.UUID, version_no: int, inline: bool = False, ctx: Ctx = Depends(require("documents.read"))):
    """Original bytes, served as an attachment with nosniff + sandbox CSP. Blocked unless scan is clean, the matter permits export, and the user may preview."""
    doc, m, v = _gate(ctx, document_id, version_no)
    if m is not None and not m.exports_allowed:
        raise PermissionDenied("Downloads and exports are disabled for this matter.", code="export_blocked")
    svc.assert_servable(v)
    data = get_storage().get(v.storage_key)
    ext = filetypes.extension(v.original_filename)
    is_image = ext in filetypes.IMAGE_TYPES
    disp = ("inline" if (inline and is_image) else "attachment")
    headers = {"Content-Disposition": _hdr_filename(v.original_filename) if disp == "attachment" else "inline",
               "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; sandbox", "Cache-Control": "no-store",
               "X-Document-SHA256": v.sha256}
    ctx.audit("document.downloaded", "document", doc.id, f"Original of '{doc.title}' v{v.version_no} downloaded", matter_id=doc.matter_id,
              details={"version_no": v.version_no, "sha256": v.sha256, "inline": disp == "inline"})
    return Response(content=data, media_type=v.content_type if is_image else "application/octet-stream", headers=headers)


@router.get("/{document_id}/compare")
def compare(document_id: uuid.UUID, from_: int = Query(alias="from"), to: int = Query(), ctx: Ctx = Depends(require("documents.read"))):
    return doc_compare.compare(ctx, document_id, from_, to)


@router.post("/{document_id}/review-request", response_model=S.DocumentDetail)
def review_request(document_id: uuid.UUID, ctx: Ctx = Depends(require("documents.write"))):
    return _detail(ctx, svc.request_review(ctx, document_id))


@router.post("/{document_id}/approve", response_model=S.DocumentDetail)
def approve(document_id: uuid.UUID, body: S.ReviewDecision, ctx: Ctx = Depends(require("documents.approve"))):
    return _detail(ctx, svc.decide_review(ctx, document_id, approve=body.approve, note=body.note))


@router.post("/{document_id}/signature-request")
def signature_request(document_id: uuid.UUID, body: S.SignatureIn, ctx: Ctx = Depends(require("documents.sign"))):
    sr = svc.request_signature(ctx, document_id, [s.model_dump() for s in body.signers])
    return {"id": str(sr.id), "status": sr.status, "provider": sr.provider, "simulated": sr.is_simulated, "external_ref": sr.external_ref, "signers": sr.signers,
            "notice": "SIMULATED e-signature provider: no envelope was sent." if sr.is_simulated else ""}


@router.post("/{document_id}/supersede", response_model=S.DocumentDetail)
def supersede(document_id: uuid.UUID, body: S.SupersedeIn, ctx: Ctx = Depends(require("documents.approve"))):
    return _detail(ctx, svc.supersede(ctx, document_id, body.note))


@router.post("/{document_id}/legal-hold", response_model=S.DocumentDetail)
def legal_hold(document_id: uuid.UUID, body: S.HoldIn, ctx: Ctx = Depends(require("matters.approve"))):
    return _detail(ctx, svc.set_legal_hold(ctx, document_id, body.hold, body.reason))


@router.post("/{document_id}/retention", response_model=S.DocumentDetail)
def retention(document_id: uuid.UUID, body: S.RetentionIn, ctx: Ctx = Depends(require("matters.approve"))):
    return _detail(ctx, svc.set_retention(ctx, document_id, body.retention_until))
