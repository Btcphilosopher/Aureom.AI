from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends

from app.deps import Ctx, require
from app.models import ConflictMatch
from app.pagination import PageParams, paginate
from app.schemas import conflicts as S
from app.services import conflicts as svc
from app.services.contacts import user_names

router = APIRouter(prefix="/conflicts", tags=["conflicts"])


@router.post("/searches", status_code=201)
def run_search(body: S.ConflictSearchIn, ctx: Ctx = Depends(require("conflicts.run"))):
    s = svc.run_search(ctx, terms=body.terms, subject_contact_id=body.subject_contact_id, matter_id=body.matter_id)
    return svc.search_out(ctx, s)


@router.get("/searches")
def list_searches(status: str | None = None, subject_contact_id: uuid.UUID | None = None, matter_id: uuid.UUID | None = None,
                  page: PageParams = Depends(), ctx: Ctx = Depends(require("conflicts.run"))):
    rows, total = paginate(ctx.db, svc.list_searches(ctx, status=status, subject_contact_id=subject_contact_id, matter_id=matter_id), page)
    names = user_names(ctx, {r.requested_by for r in rows} | {r.reviewed_by for r in rows})
    items = [{"id": str(r.id), "status": r.status, "terms": r.terms, "match_count": r.match_count, "subject_contact_id": str(r.subject_contact_id) if r.subject_contact_id else None,
              "matter_id": str(r.matter_id) if r.matter_id else None, "requested_by_name": names.get(r.requested_by), "reviewed_by_name": names.get(r.reviewed_by),
              "created_at": r.created_at.isoformat(), "version": r.version} for r in rows]
    return {"items": items, "total": total, "limit": page.limit, "offset": page.offset}


@router.get("/searches/{search_id}")
def get_search(search_id: uuid.UUID, ctx: Ctx = Depends(require("conflicts.run"))):
    return svc.search_out(ctx, svc.get_search(ctx, search_id))


@router.patch("/matches/{match_id}")
def review_match(match_id: uuid.UUID, body: S.MatchReviewIn, ctx: Ctx = Depends(require("conflicts.review"))):
    m = svc.review_match(ctx, match_id, body.disposition, body.note)
    return svc.search_out(ctx, svc.get_search(ctx, m.search_id))


@router.post("/searches/{search_id}/decision")
def decide(search_id: uuid.UUID, body: S.SearchDecisionIn, ctx: Ctx = Depends(require("conflicts.review"))):
    s = svc.decide_search(ctx, search_id, body.decision, body.note, body.expected_version)
    return svc.search_out(ctx, s)
