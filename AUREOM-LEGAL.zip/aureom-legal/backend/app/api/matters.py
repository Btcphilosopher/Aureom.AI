from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query, Response

from sqlalchemy import select

from app.deps import Ctx, get_ctx, require
from app.errors import NotFound, PermissionDenied
from app.models import MatterTemplate, Office
from app.pagination import PageParams, paginate
from app.schemas import matters as S
from app.services import matters as svc
from app.services.contacts import user_names

router = APIRouter(prefix="/matters", tags=["matters"])


@router.get("")
def list_matters(status: str | None = None, practice_area: str | None = None, office_id: uuid.UUID | None = None, partner_id: uuid.UUID | None = None,
                 fee_earner_id: uuid.UUID | None = None, client_id: uuid.UUID | None = None, q: str | None = None, mine: bool = False, missing: str | None = None,
                 page: PageParams = Depends(), ctx: Ctx = Depends(require("matters.read"))):
    """Restricted / ethical-wall matters the caller cannot access are excluded from items AND from the total."""
    stmt = svc.list_stmt(ctx, status=status, practice_area=practice_area, office_id=office_id, partner_id=partner_id,
                         fee_earner_id=fee_earner_id, client_id=client_id, q=q, mine=mine)
    if missing:  # e.g. missing=engagement_letter: open matters with no document of that type on file (dashboard exception)
        from sqlalchemy import exists
        from app.models import Document, Matter
        stmt = stmt.where(Matter.status == "open", ~exists().where(Document.matter_id == Matter.id, Document.doc_type == missing))
    rows, total = paginate(ctx.db, stmt, page)
    return {"items": svc.matter_list_items(ctx, rows), "total": total, "limit": page.limit, "offset": page.offset}


@router.post("", status_code=201)
def create_matter(body: S.MatterCreate, ctx: Ctx = Depends(require("matters.create"))):
    m = svc.create_matter(ctx, **body.model_dump())
    return svc.matter_detail(ctx, m)


# ------------------------------------------------------------------ templates (before /{matter_id})
def _tpl_read(ctx: Ctx = Depends(get_ctx)) -> Ctx:
    if not (ctx.has("matters.read") or ctx.has("admin.settings")):
        raise PermissionDenied("Viewing matter templates needs matter or administrator access.")
    return ctx


@router.get("/templates")
def list_templates(include_inactive: bool = False, ctx: Ctx = Depends(_tpl_read)):
    stmt = select(MatterTemplate).where(MatterTemplate.firm_id == ctx.firm_id).order_by(MatterTemplate.practice_area, MatterTemplate.name)
    if not include_inactive:
        stmt = stmt.where(MatterTemplate.is_active.is_(True))
    return {"items": [svc._tpl_out(t) for t in ctx.db.execute(stmt).scalars()]}


@router.post("/templates", status_code=201)
def create_template(body: S.TemplateIn, ctx: Ctx = Depends(get_ctx)):
    return svc._tpl_out(svc.save_template(ctx, body.model_dump()))


def _get_tpl(ctx: Ctx, tid: uuid.UUID) -> MatterTemplate:
    t = ctx.db.get(MatterTemplate, tid)
    if not t or t.firm_id != ctx.firm_id:
        raise NotFound("Template not found.")
    return t


@router.get("/templates/{template_id}")
def get_template(template_id: uuid.UUID, ctx: Ctx = Depends(_tpl_read)):
    return svc._tpl_out(_get_tpl(ctx, template_id))


@router.put("/templates/{template_id}")
def update_template(template_id: uuid.UUID, body: S.TemplateIn, ctx: Ctx = Depends(get_ctx)):
    return svc._tpl_out(svc.save_template(ctx, body.model_dump(), _get_tpl(ctx, template_id)))


@router.delete("/templates/{template_id}", status_code=204)
def deactivate_template(template_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    svc.template_write_allowed(ctx)
    t = _get_tpl(ctx, template_id)
    t.is_active = False
    ctx.audit("matter_template.deactivated", "matter_template", t.id, f"Matter template deactivated: {t.name}")
    return Response(status_code=204)


# ------------------------------------------------------------------ matter by id
@router.get("/{matter_id}")
def get_matter(matter_id: uuid.UUID, ctx: Ctx = Depends(require("matters.read"))):
    return svc.matter_detail(ctx, svc.get_matter(ctx, matter_id))


@router.patch("/{matter_id}")
def patch_matter(matter_id: uuid.UUID, body: S.MatterPatch, ctx: Ctx = Depends(require("matters.write"))):
    m = svc.get_matter(ctx, matter_id)
    data = body.model_dump(exclude_unset=True)
    ev = data.pop("expected_version")
    svc.update_matter(ctx, m, data, ev)
    return svc.matter_detail(ctx, m)


@router.get("/{matter_id}/summary")
def matter_summary(matter_id: uuid.UUID, ctx: Ctx = Depends(require("matters.read"))):
    return svc.summary(ctx, svc.get_matter(ctx, matter_id))


@router.get("/{matter_id}/activity")
def matter_activity(matter_id: uuid.UUID, page: PageParams = Depends(), ctx: Ctx = Depends(require("matters.read"))):
    m = svc.get_matter(ctx, matter_id)
    rows, total = paginate(ctx.db, svc.activity(ctx, m), page)
    names = user_names(ctx, {r.actor_user_id for r in rows})
    return {"items": [{"id": r.id, "at": r.occurred_at.isoformat(), "action": r.action, "summary": r.summary, "actor": names.get(r.actor_user_id) or r.actor_type,
                       "actor_type": r.actor_type, "entity_type": r.entity_type, "details": r.details} for r in rows],
            "total": total, "limit": page.limit, "offset": page.offset}


@router.post("/{matter_id}/stage")
def change_stage(matter_id: uuid.UUID, body: S.StageIn, ctx: Ctx = Depends(require("matters.write"))):
    m = svc.get_matter(ctx, matter_id)
    svc.set_stage(ctx, m, body.stage, body.expected_version)
    return svc.matter_detail(ctx, m)


# ------------------------------------------------------------------ parties
@router.post("/{matter_id}/parties", status_code=201)
def add_party(matter_id: uuid.UUID, body: S.PartyIn, ctx: Ctx = Depends(require("matters.write"))):
    m = svc.get_matter(ctx, matter_id)
    p = svc.add_party(ctx, m, body.contact_id, body.role, body.notes)
    return {"id": str(p.id)}


@router.delete("/{matter_id}/parties/{party_id}", status_code=204)
def remove_party(matter_id: uuid.UUID, party_id: uuid.UUID, ctx: Ctx = Depends(require("matters.write"))):
    svc.remove_party(ctx, svc.get_matter(ctx, matter_id), party_id)
    return Response(status_code=204)


# ------------------------------------------------------------------ access control / ethical walls
@router.post("/{matter_id}/members", status_code=201)
def add_member(matter_id: uuid.UUID, body: S.MemberIn, ctx: Ctx = Depends(require("matters.access_admin"))):
    m = svc.get_matter(ctx, matter_id)
    mm = svc.add_member(ctx, m, user_id=body.user_id, team_id=body.team_id, access=body.access, member_role=body.member_role, reason=body.reason)
    return {"id": str(mm.id)}


@router.delete("/{matter_id}/members/{member_id}", status_code=204)
def remove_member(matter_id: uuid.UUID, member_id: uuid.UUID, reason: str | None = None, ctx: Ctx = Depends(require("matters.access_admin"))):
    svc.remove_member(ctx, svc.get_matter(ctx, matter_id), member_id, reason)
    return Response(status_code=204)


@router.put("/{matter_id}/access")
def set_access(matter_id: uuid.UUID, body: S.AccessIn, ctx: Ctx = Depends(require("matters.access_admin"))):
    m = svc.get_matter(ctx, matter_id)
    svc.set_access(ctx, m, access_level=body.access_level, ethical_wall=body.ethical_wall, exports_allowed=body.exports_allowed,
                   ai_retrieval_allowed=body.ai_retrieval_allowed, reason=body.reason, expected_version=body.expected_version)
    return svc.matter_detail(ctx, m)


# ------------------------------------------------------------------ checklist, legal hold, retention
@router.post("/{matter_id}/checklist", status_code=201)
def add_checklist_item(matter_id: uuid.UUID, body: S.ChecklistAddIn, ctx: Ctx = Depends(require("matters.write"))):
    it = svc.add_checklist_item(ctx, svc.get_matter(ctx, matter_id), body.phase, body.label, body.required)
    return {"id": str(it.id)}


@router.post("/{matter_id}/checklist/{item_id}")
def toggle_checklist(matter_id: uuid.UUID, item_id: uuid.UUID, body: S.ChecklistToggleIn, ctx: Ctx = Depends(require("matters.write"))):
    m = svc.get_matter(ctx, matter_id)
    svc.toggle_checklist(ctx, m, item_id, body.completed, body.note)
    return svc.matter_detail(ctx, m)["checklist"]


@router.post("/{matter_id}/legal-hold")
def legal_hold(matter_id: uuid.UUID, body: S.LegalHoldIn, ctx: Ctx = Depends(require("matters.approve"))):
    m = svc.get_matter(ctx, matter_id)
    svc.set_legal_hold(ctx, m, body.active, body.reason)
    return svc.matter_detail(ctx, m)


@router.put("/{matter_id}/retention")
def retention(matter_id: uuid.UUID, body: S.RetentionIn, ctx: Ctx = Depends(require("matters.write"))):
    m = svc.get_matter(ctx, matter_id)
    svc.set_retention(ctx, m, body.policy_key)
    return svc.matter_detail(ctx, m)


# ------------------------------------------------------------------ state machine
@router.get("/{matter_id}/transitions/available")
def transitions_available(matter_id: uuid.UUID, ctx: Ctx = Depends(require("matters.read"))):
    m = svc.get_matter(ctx, matter_id)
    return {"status": m.status, "version": m.version, "transitions": svc.available_transitions(ctx, m)}


@router.post("/{matter_id}/transitions")
def transition(matter_id: uuid.UUID, body: S.TransitionIn, response: Response, ctx: Ctx = Depends(require("matters.transition"))):
    m = svc.get_matter(ctx, matter_id, for_update=True)
    m, ap, executed = svc.request_transition(ctx, m, body.to_status, body.reason, body.expected_version, body.retention_policy_key)
    if not executed:
        response.status_code = 202
    return {"executed": executed, "approval_id": str(ap.id), "approval_status": ap.status, "matter": svc.matter_detail(ctx, m)}


@router.post("/{matter_id}/transitions/{approval_id}/decide")
def decide_transition(matter_id: uuid.UUID, approval_id: uuid.UUID, body: S.TransitionDecisionIn, ctx: Ctx = Depends(require("matters.approve"))):
    m = svc.get_matter(ctx, matter_id, for_update=True)
    m, ap, executed = svc.decide_transition(ctx, m, approval_id, body.approve, body.note)
    return {"executed": executed, "approval_id": str(ap.id), "approval_status": ap.status, "matter": svc.matter_detail(ctx, m)}


# ------------------------------------------------------------------ chronology
@router.get("/{matter_id}/chronology")
def chronology(matter_id: uuid.UUID, include_rejected: bool = False, ctx: Ctx = Depends(require("matters.read"))):
    return {"items": svc.list_chronology(ctx, svc.get_matter(ctx, matter_id), include_rejected),
            "note": "Explicit dates are stated in a source; inferred dates are estimates that need human confirmation."}


@router.post("/{matter_id}/chronology", status_code=201)
def add_chronology(matter_id: uuid.UUID, body: S.ChronologyIn, ctx: Ctx = Depends(require("matters.write"))):
    e = svc.add_chronology(ctx, svc.get_matter(ctx, matter_id), body.model_dump())
    return {"id": str(e.id), "version": e.version}


@router.patch("/{matter_id}/chronology/{entry_id}")
def patch_chronology(matter_id: uuid.UUID, entry_id: uuid.UUID, body: S.ChronologyPatch, ctx: Ctx = Depends(require("matters.write"))):
    data = body.model_dump(exclude_unset=True)
    ev = data.pop("expected_version")
    e = svc.update_chronology(ctx, svc.get_matter(ctx, matter_id), entry_id, data, ev)
    return {"id": str(e.id), "version": e.version, "status": e.status}


@router.delete("/{matter_id}/chronology/{entry_id}", status_code=204)
def delete_chronology(matter_id: uuid.UUID, entry_id: uuid.UUID, ctx: Ctx = Depends(require("matters.write"))):
    svc.reject_chronology(ctx, svc.get_matter(ctx, matter_id), entry_id)
    return Response(status_code=204)
