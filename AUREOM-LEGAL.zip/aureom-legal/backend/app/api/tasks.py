from __future__ import annotations

import uuid
from datetime import date, datetime, time, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select

from app.deps import Ctx, require
from app.models import Matter, Task, TaskDependency, User
from app.pagination import Page, PageParams, paginate
from app.schemas.tasks import BlockerOut, DependencyIn, TaskCreate, TaskOut, TaskUpdate
from app.services import tasks as svc
from app.services.tasks import LOCAL_TZ

router = APIRouter(prefix="/tasks", tags=["tasks"])


def hydrate(ctx: Ctx, rows: list[Task]) -> list[TaskOut]:
    db = ctx.db
    mids = {t.matter_id for t in rows if t.matter_id}
    uids = {x for t in rows for x in (t.assignee_id,) if x}
    matters = {m.id: m for m in db.execute(select(Matter).where(Matter.id.in_(mids))).scalars()} if mids else {}
    users = {u.id: u.name for u in db.execute(select(User).where(User.id.in_(uids))).scalars()} if uids else {}
    blockers: dict[uuid.UUID, list[Task]] = {}
    if rows:
        q = (select(TaskDependency.task_id, Task).join(Task, Task.id == TaskDependency.depends_on_task_id)
             .where(TaskDependency.task_id.in_([t.id for t in rows]), Task.status.not_in(("done", "cancelled"))))
        for tid, dep in db.execute(q).all():
            blockers.setdefault(tid, []).append(dep)
    now = datetime.now(timezone.utc)
    out = []
    for t in rows:
        m = matters.get(t.matter_id)
        out.append(TaskOut(
            id=t.id, matter_id=t.matter_id, matter_reference=m.reference if m else None, matter_title=m.title if m else None, title=t.title,
            description=t.description, assignee_id=t.assignee_id, assignee_name=users.get(t.assignee_id), created_by=t.created_by, due_at=t.due_at,
            status=t.status, priority=t.priority, completed_at=t.completed_at, recurrence=t.recurrence,
            reminder_offsets_minutes=list(t.reminder_offsets_minutes or []), escalate_to_id=t.escalate_to_id, escalate_after_hours=t.escalate_after_hours,
            escalated_at=t.escalated_at, deadline_id=t.deadline_id, source=t.source, agent_run_id=t.agent_run_id, version=t.version,
            is_overdue=bool(t.due_at and t.due_at < now and t.status in svc.OPEN_STATES),
            blocked_by=[BlockerOut(id=b.id, title=b.title, status=b.status) for b in blockers.get(t.id, [])], created_at=t.created_at))
    return out


@router.get("", response_model=Page[TaskOut])
def list_tasks(mine: bool = False, assignee_id: uuid.UUID | None = None, matter_id: uuid.UUID | None = None, status: str | None = None,
               due_from: date | None = None, due_to: date | None = None, overdue: bool = False, open_only: bool = False,
               q: str | None = Query(None, max_length=100), params: PageParams = Depends(), ctx: Ctx = Depends(require("tasks.read"))):
    stmt = select(Task).where(svc.task_clause(ctx))
    if mine:
        stmt = stmt.where(Task.assignee_id == ctx.user.id)
    if assignee_id:
        stmt = stmt.where(Task.assignee_id == assignee_id)
    if matter_id:
        stmt = stmt.where(Task.matter_id == matter_id)
    if status:
        stmt = stmt.where(Task.status.in_(status.split(",")))
    if open_only:
        stmt = stmt.where(Task.status.in_(svc.OPEN_STATES))
    if due_from:
        stmt = stmt.where(Task.due_at >= datetime.combine(due_from, time.min, tzinfo=LOCAL_TZ))
    if due_to:
        stmt = stmt.where(Task.due_at < datetime.combine(due_to, time.max, tzinfo=LOCAL_TZ))
    if overdue:
        stmt = stmt.where(Task.due_at < datetime.now(timezone.utc), Task.status.in_(svc.OPEN_STATES))
    if q:
        stmt = stmt.where(Task.title.ilike(f"%{q}%"))
    stmt = stmt.order_by(Task.due_at.asc().nulls_last(), Task.created_at.desc())
    rows, total = paginate(ctx.db, stmt, params)
    return Page[TaskOut](items=hydrate(ctx, rows), total=total, limit=params.limit, offset=params.offset)


@router.post("", response_model=TaskOut, status_code=201)
def create(body: TaskCreate, ctx: Ctx = Depends(require("tasks.write"))):
    t = svc.create_task(ctx, **body.model_dump(exclude={"recurrence"}), recurrence=body.recurrence.model_dump() if body.recurrence else None)
    return hydrate(ctx, [t])[0]


@router.get("/{task_id}", response_model=TaskOut)
def get(task_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.read"))):
    return hydrate(ctx, [svc.get_task(ctx, task_id)])[0]


@router.patch("/{task_id}", response_model=TaskOut)
def patch(task_id: uuid.UUID, body: TaskUpdate, ctx: Ctx = Depends(require("tasks.write"))):
    t = svc.get_task(ctx, task_id)
    changes = body.model_dump(exclude_unset=True, exclude={"expected_version"})
    if "recurrence" in changes and changes["recurrence"] is not None:
        changes["recurrence"] = body.recurrence.model_dump()
    svc.update_task(ctx, t, changes, body.expected_version)
    return hydrate(ctx, [t])[0]


@router.post("/{task_id}/start", response_model=TaskOut)
def start(task_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    return hydrate(ctx, [svc.start_task(ctx, svc.get_task(ctx, task_id))])[0]


@router.post("/{task_id}/complete", response_model=dict)
def complete(task_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    t, nxt = svc.complete_task(ctx, svc.get_task(ctx, task_id))
    return {"task": hydrate(ctx, [t])[0], "next_occurrence": hydrate(ctx, [nxt])[0] if nxt else None}


@router.post("/{task_id}/reopen", response_model=TaskOut)
def reopen(task_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    return hydrate(ctx, [svc.reopen_task(ctx, svc.get_task(ctx, task_id))])[0]


@router.post("/{task_id}/cancel", response_model=TaskOut)
def cancel(task_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    return hydrate(ctx, [svc.cancel_task(ctx, svc.get_task(ctx, task_id))])[0]


@router.get("/{task_id}/dependencies", response_model=dict)
def dependencies(task_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.read"))):
    t = svc.get_task(ctx, task_id)
    deps = list(ctx.db.execute(select(Task).join(TaskDependency, TaskDependency.depends_on_task_id == Task.id).where(TaskDependency.task_id == t.id)).scalars())
    dependents = list(ctx.db.execute(select(Task).join(TaskDependency, TaskDependency.task_id == Task.id).where(TaskDependency.depends_on_task_id == t.id)).scalars())
    visible = {x for x in ctx.db.execute(select(Task.id).where(svc.task_clause(ctx), Task.id.in_([x.id for x in deps + dependents]))).scalars()} if (deps or dependents) else set()
    return {"depends_on": hydrate(ctx, [d for d in deps if d.id in visible]), "required_by": hydrate(ctx, [d for d in dependents if d.id in visible]),
            "blocked_by": [{"id": str(b.id), "title": b.title, "status": b.status} for b in svc.blockers(ctx.db, t.id)]}


@router.post("/{task_id}/dependencies", status_code=201, response_model=dict)
def add_dependency(task_id: uuid.UUID, body: DependencyIn, ctx: Ctx = Depends(require("tasks.write"))):
    t = svc.get_task(ctx, task_id)
    svc.add_dependency(ctx, t, body.depends_on_task_id)
    return {"ok": True, "blocked_by": [{"id": str(b.id), "title": b.title, "status": b.status} for b in svc.blockers(ctx.db, t.id)]}


@router.delete("/{task_id}/dependencies/{depends_on_id}", status_code=204)
def remove_dependency(task_id: uuid.UUID, depends_on_id: uuid.UUID, ctx: Ctx = Depends(require("tasks.write"))):
    svc.remove_dependency(ctx, svc.get_task(ctx, task_id), depends_on_id)
