from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app import audit
from app.config import get_settings
from app.db.session import bind_firm
from app.deps import Ctx, get_ctx, get_db
from app.errors import IntegrationUnavailable, NotFound, Unauthenticated, ValidationFailed
from app.models import Firm, Office, Role, User, UserSession
from app.permissions import permissions_for
from app.security import new_token, sha256_hex, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginIn(BaseModel):
    email: str
    password: str


class DemoLoginIn(BaseModel):
    email: str


def _start_session(db: Session, request: Request, response: Response, user: User) -> dict:
    s = get_settings()
    token, csrf = new_token(), new_token()
    now = datetime.now(timezone.utc)
    db.add(UserSession(user_id=user.id, firm_id=user.firm_id, token_hash=sha256_hex(token), csrf_token=csrf,
                       expires_at=now + timedelta(minutes=s.session_ttl_minutes),
                       ip=request.client.host if request.client else None, user_agent=(request.headers.get("user-agent") or "")[:300],
                       active_office_id=user.office_id))
    user.last_login_at, user.failed_logins, user.locked_until = now, 0, None
    db.flush()
    bind_firm(db, user.firm_id)
    audit.log(db, firm_id=user.firm_id, action="auth.login", entity_type="user", entity_id=user.id, summary=f"{user.name} signed in",
              actor_user_id=user.id, ip=request.client.host if request.client else None)
    response.set_cookie(s.session_cookie_name, token, httponly=True, samesite="lax", secure=s.cookie_secure,
                        max_age=s.session_ttl_minutes * 60, path="/")
    return {"csrf_token": csrf}


def _me(db: Session, user: User, csrf: str, active_office_id) -> dict:
    s = get_settings()
    role = db.get(Role, user.role_id)
    firm = db.get(Firm, user.firm_id)
    bind_firm(db, user.firm_id)
    offices = db.execute(select(Office).where(Office.firm_id == user.firm_id).order_by(Office.name)).scalars().all()
    return {
        "user": {"id": str(user.id), "name": user.name, "initials": user.initials, "email": user.email, "job_title": user.job_title,
                 "office_id": str(user.office_id) if user.office_id else None, "team_id": str(user.team_id) if user.team_id else None,
                 "contact_id": str(user.contact_id) if user.contact_id else None},
        "role": {"key": role.key, "name": role.name},
        "permissions": sorted(permissions_for(role.key, role.permissions)),
        "firm": {"id": str(firm.id), "name": firm.name, "data_residency": firm.data_residency},
        "offices": [{"id": str(o.id), "name": o.name, "city": o.city} for o in offices],
        "active_office_id": str(active_office_id) if active_office_id else None,
        "csrf_token": csrf,
        "demo_mode": s.demo_mode,
        "environment": s.env,
    }


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == body.email.strip().lower())).scalar_one_or_none()
    now = datetime.now(timezone.utc)
    if user and user.locked_until and user.locked_until > now:
        raise Unauthenticated("Too many failed attempts. Try again later.", code="account_locked")
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        if user:
            user.failed_logins += 1
            if user.failed_logins >= 5:
                user.locked_until = now + timedelta(minutes=15)
            bind_firm(db, user.firm_id)
            audit.log(db, firm_id=user.firm_id, action="auth.login_failed", entity_type="user", entity_id=user.id, summary="Failed sign-in attempt",
                      actor_user_id=user.id, ip=request.client.host if request.client else None)
            db.commit()
        raise Unauthenticated("Incorrect email or password.", code="invalid_credentials")
    out = _start_session(db, request, response, user)
    return _me(db, user, out["csrf_token"], user.office_id)


@router.post("/demo-login")
def demo_login(body: DemoLoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    """Persona picker for the demonstration. Disabled unless DEMO_MODE=true; never enable in production."""
    if not get_settings().demo_mode:
        raise NotFound("Not found.")
    user = db.execute(select(User).where(User.email == body.email.strip().lower())).scalar_one_or_none()
    if not user or not user.is_active:
        raise Unauthenticated("Unknown demo user.")
    out = _start_session(db, request, response, user)
    return _me(db, user, out["csrf_token"], user.office_id)


@router.get("/personas")
def personas(db: Session = Depends(get_db)):
    if not get_settings().demo_mode:
        raise NotFound("Not found.")
    rows = db.execute(select(User, Role.name).join(Role, Role.id == User.role_id).where(User.is_active.is_(True)).order_by(User.name)).all()
    return [{"email": u.email, "name": u.name, "role": rn, "job_title": u.job_title} for u, rn in rows]


@router.get("/me")
def me(request: Request, ctx: Ctx = Depends(get_ctx)):
    return _me(ctx.db, ctx.user, ctx.session.csrf_token, ctx.session.active_office_id)


class OfficeIn(BaseModel):
    office_id: str | None = None


@router.post("/office")
def set_office(body: OfficeIn, ctx: Ctx = Depends(get_ctx)):
    """Office/team selector: a UI filter preference stored on the session; it never widens access."""
    import uuid

    if body.office_id:
        office = ctx.db.get(Office, uuid.UUID(body.office_id))
        if not office or office.firm_id != ctx.firm_id:
            raise NotFound("Office not found.")
    ctx.session.active_office_id = uuid.UUID(body.office_id) if body.office_id else None
    return {"active_office_id": body.office_id}


@router.post("/logout")
def logout(request: Request, response: Response, ctx: Ctx = Depends(get_ctx)):
    ctx.session.revoked_at = datetime.now(timezone.utc)
    ctx.audit("auth.logout", "user", ctx.user.id, f"{ctx.user.name} signed out")
    response.delete_cookie(get_settings().session_cookie_name, path="/")
    return {"ok": True}


@router.get("/sso/start")
def sso_start():
    """SSO boundary: an OIDC provider adapter plugs in here. Not configured in this build."""
    from app.integrations import base

    base.get_available("sso")  # raises IntegrationUnavailable with a clear message when not configured
    raise IntegrationUnavailable("SSO callback handling is not implemented in this build.")


@router.get("/directory")
def directory(ctx: Ctx = Depends(get_ctx)):
    """Minimal staff/team/office/retention directory for pickers (assignees, partners, teams). Names and roles only -
    no contact details. Available to every staff user; not available to authorised clients."""
    from app.models import RetentionPolicy, Team
    if ctx.role_key == "client":
        raise NotFound("Not found.")
    db = ctx.db
    users = db.execute(select(User, Role.key).join(Role, Role.id == User.role_id).where(User.firm_id == ctx.firm_id, User.is_active.is_(True), Role.key != "client").order_by(User.name)).all()
    return {
        "users": [{"id": str(u.id), "name": u.name, "initials": u.initials, "role_key": rk, "job_title": u.job_title, "team_id": str(u.team_id) if u.team_id else None,
                   "office_id": str(u.office_id) if u.office_id else None} for u, rk in users],
        "teams": [{"id": str(t.id), "name": t.name, "practice_area": t.practice_area} for t in db.execute(select(Team).where(Team.firm_id == ctx.firm_id).order_by(Team.name)).scalars()],
        "offices": [{"id": str(o.id), "name": o.name, "city": o.city} for o in db.execute(select(Office).where(Office.firm_id == ctx.firm_id).order_by(Office.name)).scalars()],
        "retention_policies": [{"key": r.key, "name": r.name, "years": r.years} for r in db.execute(select(RetentionPolicy).where(RetentionPolicy.firm_id == ctx.firm_id, RetentionPolicy.is_active.is_(True)).order_by(RetentionPolicy.key)).scalars()],
    }
