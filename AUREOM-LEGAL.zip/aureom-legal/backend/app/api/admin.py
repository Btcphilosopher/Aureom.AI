"""Administration: users, roles, offices/teams, firm settings, retention, audit log, system information.
Permission changes and sensitive exports are audited. Administrators cannot read matter content (no matters.read)."""
from __future__ import annotations

import csv
import io
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select, update

from app import audit as audit_mod
from app.config import get_settings
from app.deps import Ctx, require
from app.errors import InvalidState, NotFound, ValidationFailed, VersionConflict
from app.models import AuditEvent, Firm, Job, Office, RetentionPolicy, Role, Team, User, UserSession
from app.pagination import PageParams, paginate
from app.permissions import P, ROLE_PERMISSIONS
from app.security import hash_password
from app.storage import get_storage

router = APIRouter(prefix="/admin", tags=["administration"])


# ----------------------------------------------------------------------------- users
class UserIn(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    name: str = Field(min_length=2, max_length=160)
    role_key: str
    job_title: str | None = None
    office_id: uuid.UUID | None = None
    team_id: uuid.UUID | None = None
    grade: str | None = None
    password: str | None = Field(default=None, min_length=12)


class UserPatch(BaseModel):
    expected_version: int
    name: str | None = None
    role_key: str | None = None
    job_title: str | None = None
    office_id: uuid.UUID | None = None
    team_id: uuid.UUID | None = None
    grade: str | None = None
    is_active: bool | None = None


def _user_dict(u: User, role: Role | None, office: Office | None = None, team: Team | None = None) -> dict:
    return {"id": str(u.id), "email": u.email, "name": u.name, "initials": u.initials, "job_title": u.job_title, "role_key": role.key if role else None,
            "role_name": role.name if role else None, "office_id": str(u.office_id) if u.office_id else None, "office": office.name if office else None,
            "team_id": str(u.team_id) if u.team_id else None, "team": team.name if team else None, "grade": u.grade, "is_active": u.is_active,
            "has_password": bool(u.password_hash), "sso_subject": u.sso_subject, "last_login_at": u.last_login_at, "version": u.version}


def _role(ctx: Ctx, key: str) -> Role:
    r = ctx.db.execute(select(Role).where(Role.firm_id == ctx.firm_id, Role.key == key)).scalar_one_or_none()
    if not r:
        raise ValidationFailed(f"Unknown role '{key}'.")
    return r


@router.get("/users")
def list_users(q: str | None = None, ctx: Ctx = Depends(require("admin.users")), page: PageParams = Depends()):
    stmt = select(User).where(User.firm_id == ctx.firm_id)
    if q:
        stmt = stmt.where(User.name.ilike(f"%{q}%") | User.email.ilike(f"%{q}%"))
    rows, total = paginate(ctx.db, stmt.order_by(User.name), page)
    roles = {r.id: r for r in ctx.db.execute(select(Role).where(Role.firm_id == ctx.firm_id)).scalars()}
    offices = {o.id: o for o in ctx.db.execute(select(Office).where(Office.firm_id == ctx.firm_id)).scalars()}
    teams = {t.id: t for t in ctx.db.execute(select(Team).where(Team.firm_id == ctx.firm_id)).scalars()}
    return {"items": [_user_dict(u, roles.get(u.role_id), offices.get(u.office_id), teams.get(u.team_id)) for u in rows], "total": total, "limit": page.limit, "offset": page.offset}


@router.post("/users", status_code=201)
def create_user(body: UserIn, ctx: Ctx = Depends(require("admin.users"))):
    email = body.email.strip().lower()
    if ctx.db.execute(select(User.id).where(User.email == email)).first():
        raise ValidationFailed("A user with this email already exists.", code="duplicate_email")
    role = _role(ctx, body.role_key)
    initials = "".join(w[0] for w in body.name.split()[:2]).upper()
    u = User(firm_id=ctx.firm_id, email=email, name=body.name, initials=initials, job_title=body.job_title, role_id=role.id, office_id=body.office_id,
             team_id=body.team_id, grade=body.grade, password_hash=hash_password(body.password) if body.password else None)
    ctx.db.add(u)
    ctx.db.flush()
    ctx.audit("admin.user_created", "user", u.id, f"User {u.name} created with role {role.key}", details={"role": role.key})
    return _user_dict(u, role)


@router.patch("/users/{user_id}")
def update_user(user_id: uuid.UUID, body: UserPatch, ctx: Ctx = Depends(require("admin.users"))):
    u = ctx.db.get(User, user_id)
    if not u or u.firm_id != ctx.firm_id:
        raise NotFound("User not found.")
    if u.version != body.expected_version:
        raise VersionConflict("This user was changed by someone else.")
    changes: dict = {}
    if body.role_key and _role(ctx, body.role_key).id != u.role_id:
        old = ctx.db.get(Role, u.role_id)
        new = _role(ctx, body.role_key)
        if u.id == ctx.user.id:
            raise InvalidState("You cannot change your own role.")
        u.role_id = new.id
        changes["role"] = {"from": old.key, "to": new.key}
        ctx.audit("admin.permission_change", "user", u.id, f"Role of {u.name} changed {old.key} → {new.key}", details=changes["role"])
    for f in ("name", "job_title", "office_id", "team_id", "grade"):
        v = getattr(body, f)
        if v is not None and v != getattr(u, f):
            setattr(u, f, v)
            changes[f] = str(v)
    if body.is_active is not None and body.is_active != u.is_active:
        if u.id == ctx.user.id:
            raise InvalidState("You cannot deactivate yourself.")
        u.is_active = body.is_active
        changes["is_active"] = body.is_active
        if not body.is_active:
            ctx.db.execute(update(UserSession).where(UserSession.user_id == u.id, UserSession.revoked_at.is_(None)).values(revoked_at=datetime.now(timezone.utc)))
        ctx.audit("admin.user_activation", "user", u.id, f"User {u.name} {'activated' if body.is_active else 'deactivated'}")
    ctx.audit("admin.user_updated", "user", u.id, f"User {u.name} updated", details={"fields": list(changes)})
    ctx.db.flush()
    return _user_dict(u, ctx.db.get(Role, u.role_id))


class PasswordIn(BaseModel):
    password: str = Field(min_length=12)


@router.post("/users/{user_id}/reset-password")
def reset_password(user_id: uuid.UUID, body: PasswordIn, ctx: Ctx = Depends(require("admin.users"))):
    u = ctx.db.get(User, user_id)
    if not u or u.firm_id != ctx.firm_id:
        raise NotFound("User not found.")
    u.password_hash = hash_password(body.password)
    u.failed_logins, u.locked_until = 0, None
    ctx.db.execute(update(UserSession).where(UserSession.user_id == u.id, UserSession.revoked_at.is_(None)).values(revoked_at=datetime.now(timezone.utc)))
    ctx.audit("admin.password_reset", "user", u.id, f"Password reset for {u.name}; sessions revoked")
    return {"ok": True}


# ----------------------------------------------------------------------------- roles
@router.get("/roles")
def list_roles(ctx: Ctx = Depends(require("admin.users"))):
    roles = ctx.db.execute(select(Role).where(Role.firm_id == ctx.firm_id).order_by(Role.name)).scalars().all()
    counts = dict(ctx.db.execute(select(User.role_id, func.count()).where(User.firm_id == ctx.firm_id).group_by(User.role_id)).all())
    return {"catalogue": sorted(P), "defaults": {k: sorted(v) for k, v in ROLE_PERMISSIONS.items()},
            "items": [{"id": str(r.id), "key": r.key, "name": r.name, "permissions": sorted(r.permissions), "users": counts.get(r.id, 0)} for r in roles]}


class RolePatch(BaseModel):
    permissions: list[str]
    reason: str = Field(min_length=5)


@router.put("/roles/{role_id}")
def update_role(role_id: uuid.UUID, body: RolePatch, ctx: Ctx = Depends(require("admin.users"))):
    r = ctx.db.get(Role, role_id)
    if not r or r.firm_id != ctx.firm_id:
        raise NotFound("Role not found.")
    unknown = [p for p in body.permissions if p not in P]
    if unknown:
        raise ValidationFailed(f"Unknown permissions: {', '.join(unknown)}")
    if r.key == "admin" and "admin.users" not in body.permissions:
        raise InvalidState("The administrator role must keep admin.users.")
    before, after = set(r.permissions), set(body.permissions)
    r.permissions = sorted(after)
    ctx.audit("admin.role_permissions_changed", "role", r.id, f"Permissions of role {r.key} changed", details={"added": sorted(after - before), "removed": sorted(before - after), "reason": body.reason})
    return {"id": str(r.id), "key": r.key, "permissions": r.permissions}


# ----------------------------------------------------------------------------- offices & teams
class OfficeIn(BaseModel):
    name: str
    city: str
    address: str | None = None
    timezone: str = "Europe/London"


@router.get("/offices")
def offices(ctx: Ctx = Depends(require("admin.settings"))):
    rows = ctx.db.execute(select(Office).where(Office.firm_id == ctx.firm_id).order_by(Office.name)).scalars().all()
    return {"items": [{"id": str(o.id), "name": o.name, "city": o.city, "address": o.address, "timezone": o.timezone} for o in rows]}


@router.post("/offices", status_code=201)
def create_office(body: OfficeIn, ctx: Ctx = Depends(require("admin.settings"))):
    o = Office(firm_id=ctx.firm_id, **body.model_dump())
    ctx.db.add(o); ctx.db.flush()
    ctx.audit("admin.office_created", "office", o.id, f"Office {o.name} created")
    return {"id": str(o.id), "name": o.name}


class TeamIn(BaseModel):
    name: str
    practice_area: str | None = None
    office_id: uuid.UUID | None = None


@router.get("/teams")
def teams(ctx: Ctx = Depends(require("admin.settings"))):
    rows = ctx.db.execute(select(Team).where(Team.firm_id == ctx.firm_id).order_by(Team.name)).scalars().all()
    return {"items": [{"id": str(t.id), "name": t.name, "practice_area": t.practice_area, "office_id": str(t.office_id) if t.office_id else None} for t in rows]}


@router.post("/teams", status_code=201)
def create_team(body: TeamIn, ctx: Ctx = Depends(require("admin.settings"))):
    t = Team(firm_id=ctx.firm_id, **body.model_dump())
    ctx.db.add(t); ctx.db.flush()
    ctx.audit("admin.team_created", "team", t.id, f"Team {t.name} created")
    return {"id": str(t.id), "name": t.name}


# ----------------------------------------------------------------------------- firm settings
@router.get("/settings")
def get_firm_settings(ctx: Ctx = Depends(require("admin.settings"))):
    f = ctx.db.get(Firm, ctx.firm_id)
    return {"name": f.name, "slug": f.slug, "data_residency": f.data_residency, "settings": f.settings}


class SettingsPatch(BaseModel):
    settings: dict
    reason: str = Field(min_length=5)
    data_residency: str | None = None


_ALLOWED_TOP = {"onboarding_check_types", "onboarding_required_checks", "client_reference_prefix", "vat_rate", "ai", "finance", "retention", "time"}


@router.put("/settings")
def put_firm_settings(body: SettingsPatch, ctx: Ctx = Depends(require("admin.settings"))):
    f = ctx.db.get(Firm, ctx.firm_id)
    bad = set(body.settings) - _ALLOWED_TOP
    if bad:
        raise ValidationFailed(f"Unknown settings: {', '.join(sorted(bad))}")
    ai = body.settings.get("ai")
    if ai is not None and ai.get("train_on_matter_content"):
        raise ValidationFailed("Training on matter content cannot be enabled in this build.", code="not_permitted")
    new = {**f.settings, **body.settings}
    ctx.audit("admin.settings_changed", "firm", f.id, "Firm settings changed", details={"keys": sorted(body.settings), "reason": body.reason})
    f.settings = new
    if body.data_residency and body.data_residency != f.data_residency:
        ctx.audit("admin.data_residency_changed", "firm", f.id, f"Data residency {f.data_residency} → {body.data_residency}", details={"reason": body.reason})
        f.data_residency = body.data_residency
    ctx.db.flush()
    return {"settings": f.settings, "data_residency": f.data_residency}


# ----------------------------------------------------------------------------- retention
class RetentionIn(BaseModel):
    key: str
    name: str
    years: int = Field(ge=1, le=100)
    description: str | None = None
    action_at_expiry: str = "review"


@router.get("/retention")
def retention(ctx: Ctx = Depends(require("admin.settings"))):
    rows = ctx.db.execute(select(RetentionPolicy).where(RetentionPolicy.firm_id == ctx.firm_id).order_by(RetentionPolicy.key)).scalars().all()
    return {"items": [{"id": str(r.id), "key": r.key, "name": r.name, "years": r.years, "description": r.description, "action_at_expiry": r.action_at_expiry, "is_active": r.is_active} for r in rows],
            "note": "Retention periods are configurable defaults for demonstration and must be set by the firm's COLP/compliance function. Legal holds always override retention expiry."}


@router.post("/retention", status_code=201)
def upsert_retention(body: RetentionIn, ctx: Ctx = Depends(require("admin.settings"))):
    r = ctx.db.execute(select(RetentionPolicy).where(RetentionPolicy.firm_id == ctx.firm_id, RetentionPolicy.key == body.key)).scalar_one_or_none()
    if r:
        r.name, r.years, r.description, r.action_at_expiry = body.name, body.years, body.description, body.action_at_expiry
    else:
        r = RetentionPolicy(firm_id=ctx.firm_id, **body.model_dump())
        ctx.db.add(r)
    ctx.db.flush()
    ctx.audit("admin.retention_policy_saved", "retention_policy", r.id, f"Retention policy {r.key}: {r.years} years")
    return {"id": str(r.id), "key": r.key}


# ----------------------------------------------------------------------------- audit log
def _audit_stmt(ctx: Ctx, action: str | None, entity_type: str | None, actor: uuid.UUID | None, matter_id: uuid.UUID | None, since: datetime | None):
    stmt = select(AuditEvent).where(AuditEvent.firm_id == ctx.firm_id)
    if action:
        stmt = stmt.where(AuditEvent.action.ilike(f"{action}%"))
    if entity_type:
        stmt = stmt.where(AuditEvent.entity_type == entity_type)
    if actor:
        stmt = stmt.where(AuditEvent.actor_user_id == actor)
    if matter_id:
        stmt = stmt.where(AuditEvent.matter_id == matter_id)
    if since:
        stmt = stmt.where(AuditEvent.occurred_at >= since)
    return stmt


def _ev(e: AuditEvent, names: dict) -> dict:
    return {"id": e.id, "occurred_at": e.occurred_at, "actor_user_id": str(e.actor_user_id) if e.actor_user_id else None, "actor": names.get(e.actor_user_id, e.actor_type),
            "actor_type": e.actor_type, "action": e.action, "entity_type": e.entity_type, "entity_id": e.entity_id,
            "matter_id": str(e.matter_id) if e.matter_id else None, "summary": e.summary, "details": e.details, "hash": e.hash[:12]}


@router.get("/audit")
def audit_log(action: str | None = None, entity_type: str | None = None, actor: uuid.UUID | None = None, matter_id: uuid.UUID | None = None,
              since: datetime | None = None, ctx: Ctx = Depends(require("audit.read")), page: PageParams = Depends()):
    """Matter-linked events on restricted/walled matters the viewer cannot access are excluded (summaries could reveal them)."""
    from app.models import Matter
    from app.permissions import matter_clause
    stmt = _audit_stmt(ctx, action, entity_type, actor, matter_id, since)
    stmt = stmt.where((AuditEvent.matter_id.is_(None)) | AuditEvent.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))
                      | AuditEvent.matter_id.in_(select(Matter.id).where(Matter.firm_id == ctx.firm_id, Matter.access_level == "standard", Matter.ethical_wall.is_(False))))
    rows, total = paginate(ctx.db, stmt.order_by(AuditEvent.id.desc()), page)
    names = {u.id: u.name for u in ctx.db.execute(select(User).where(User.firm_id == ctx.firm_id)).scalars()}
    return {"items": [_ev(e, names) for e in rows], "total": total, "limit": page.limit, "offset": page.offset}


@router.get("/audit/verify")
def audit_verify(ctx: Ctx = Depends(require("audit.read"))):
    res = audit_mod.verify_chain(ctx.db, ctx.firm_id)
    ctx.audit("admin.audit_verified", "audit", None, f"Audit chain verification: {'ok' if res['ok'] else 'FAILED'}", details=res)
    return res


@router.get("/audit.csv")
def audit_csv(action: str | None = None, entity_type: str | None = None, since: datetime | None = None, ctx: Ctx = Depends(require("audit.read"))):
    stmt = _audit_stmt(ctx, action, entity_type, None, None, since).where(AuditEvent.matter_id.is_(None)).order_by(AuditEvent.id.desc()).limit(5000)
    rows = ctx.db.execute(stmt).scalars().all()
    ctx.audit("export.audit_log", "audit", None, f"Audit log exported ({len(rows)} non-matter events)", details={"rows": len(rows)})
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["id", "occurred_at", "actor_type", "action", "entity_type", "entity_id", "summary", "hash"])
    for e in rows:
        w.writerow([e.id, e.occurred_at.isoformat(), e.actor_type, e.action, e.entity_type, e.entity_id, e.summary, e.hash])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=audit.csv"})


# ----------------------------------------------------------------------------- system
@router.get("/system")
def system(ctx: Ctx = Depends(require("admin.settings"))):
    s = get_settings()
    f = ctx.db.get(Firm, ctx.firm_id)
    jobs = dict(ctx.db.execute(select(Job.status, func.count()).where(Job.firm_id == ctx.firm_id).group_by(Job.status)).all())
    return {"environment": s.env, "demo_mode": s.demo_mode, "storage": get_storage().status(), "data_residency": f.data_residency,
            "configured_residency": s.data_residency, "session_ttl_minutes": s.session_ttl_minutes, "cookie_secure": s.cookie_secure,
            "ai_provider": s.ai_provider, "sso_configured": bool(s.sso_issuer), "jobs": jobs,
            "max_upload_mb": s.max_upload_bytes // (1024 * 1024),
            "backup": {"doc": "docs/BACKUP_RESTORE.md", "summary": "Back up PostgreSQL (pg_dump / PITR) and the object-storage bucket together; test restores regularly. Audit-chain verification is available after restore."},
            "warnings": ([] if s.env == "production" else ["Non-production environment: demonstration defaults are active."]) +
                        (["DEMO_MODE is on: the persona picker bypasses passwords. Disable before any real use."] if s.demo_mode else []) +
                        (["SECRET_KEY is the default value."] if s.secret_key == "change-me-in-production" else [])}
