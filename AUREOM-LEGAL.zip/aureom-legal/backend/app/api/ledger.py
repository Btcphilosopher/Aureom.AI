"""Ledgers (office / client), journals, bank feed, receipts, allocation, client-money transfers, revenue recognition, reconciliation.
Every posting requires a human authorisation; AI agents have no access to any of these endpoints."""
from __future__ import annotations

import uuid
from datetime import date

from fastapi import APIRouter, Depends, Response
from sqlalchemy import or_, select

from app.deps import Ctx, require
from app.errors import NotFound, ValidationFailed
from app.models import Approval, BankStatementLine, Journal, JournalLine, LedgerAccount, Matter, Payment, Reconciliation, RevenueRecognition
from app.pagination import Page, PageParams, paginate
from app.permissions import matter_clause
from app.schemas.ledger import (AccountOut, AllocateIn, BankLineOut, BankSyncIn, DecideIn, JournalIn, JournalLineOut, JournalOut, MatchIn, PaymentOut, ReceiptIn,
                                ReconIn, ReverseIn, RevRecIn, TransferIn, jsonable)
from app.services import ledger as led
from app.services import reconciliation as rec

router = APIRouter(prefix="/ledger", tags=["ledger"])


def _journal_out(ctx: Ctx, j: Journal, with_lines: bool = True) -> JournalOut:
    lines = led.journal_lines(ctx.db, j.id)
    accts = {a.id: a for a in ctx.db.execute(select(LedgerAccount).where(LedgerAccount.id.in_([l.account_id for l in lines] or [uuid.uuid4()]))).scalars()}
    ap = ctx.db.get(Approval, j.approval_id) if j.approval_id else None
    out_lines = []
    for l in lines:
        o = JournalLineOut.model_validate(l)
        o.account_code, o.account_name = accts[l.account_id].code, accts[l.account_id].name
        out_lines.append(o)
    return JournalOut(id=j.id, ledger=j.ledger, reference=j.reference, description=j.description, effective_date=j.effective_date, currency=j.currency,
                      status=j.status, matter_id=j.matter_id, source_type=j.source_type, prepared_by=j.prepared_by, posted_by=j.posted_by, posted_at=j.posted_at,
                      approval_id=j.approval_id, approval_status=ap.status if ap else None, reverses_journal_id=j.reverses_journal_id,
                      total=sum((l.debit for l in lines), 0) or 0, version=j.version, lines=out_lines if with_lines else [])


def _payment_out(p: Payment) -> PaymentOut:
    o = PaymentOut.model_validate(p)
    o.unallocated_amount = p.amount - p.allocated_amount
    return o


# ------------------------------------------------------------------ accounts & balances
@router.get("/accounts", response_model=list[AccountOut])
def accounts(ledger: str | None = None, ctx: Ctx = Depends(require("ledger.read"))):
    stmt = select(LedgerAccount).where(LedgerAccount.firm_id == ctx.firm_id)
    if ledger: stmt = stmt.where(LedgerAccount.ledger == ledger)
    out = []
    for a in ctx.db.execute(stmt.order_by(LedgerAccount.ledger, LedgerAccount.code)).scalars():
        if a.matter_id and not led._matter_ok(ctx, a.matter_id):
            continue
        o = AccountOut.model_validate(a)
        o.balance = led.account_balance(ctx.db, a)
        out.append(o)
    return out


@router.get("/accounts/{account_id}/lines", response_model=Page[JournalLineOut])
def account_lines(account_id: uuid.UUID, p: PageParams = Depends(), ctx: Ctx = Depends(require("ledger.read"))):
    a = ctx.db.get(LedgerAccount, account_id)
    if not a or a.firm_id != ctx.firm_id:
        raise NotFound("Account not found.")
    stmt = (select(JournalLine).join(Journal, Journal.id == JournalLine.journal_id)
            .where(JournalLine.account_id == a.id, Journal.status.in_(("posted", "reversed")),
                   or_(Journal.matter_id.is_(None), Journal.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))).order_by(Journal.effective_date.desc(), JournalLine.id))
    rows, total = paginate(ctx.db, stmt, p)
    return Page(items=[JournalLineOut.model_validate(r) for r in rows], total=total, limit=p.limit, offset=p.offset)


@router.get("/trial-balance")
def trial_balance(ledger: str = "office", as_of: date | None = None, ctx: Ctx = Depends(require("ledger.read"))):
    return jsonable(led.trial_balance(ctx, ledger, as_of))


@router.get("/matters/{matter_id}/client-balance")
def matter_client_balance(matter_id: uuid.UUID, ctx: Ctx = Depends(require("ledger.read"))):
    from app.services.matter_finance import client_balance
    m = led.get_matter_for(ctx, matter_id)
    return jsonable({"matter_id": m.id, "currency": m.currency, "balance": client_balance(ctx.db, m.id), "basis": "Posted client-ledger credits less debits on the matter's client account."})


# ------------------------------------------------------------------ journals
@router.get("/journals", response_model=Page[JournalOut])
def list_journals(ledger: str | None = None, status: str | None = None, matter_id: uuid.UUID | None = None, source_type: str | None = None,
                  p: PageParams = Depends(), ctx: Ctx = Depends(require("ledger.read"))):
    stmt = select(Journal).where(Journal.firm_id == ctx.firm_id, or_(Journal.matter_id.is_(None), Journal.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))
    if ledger: stmt = stmt.where(Journal.ledger == ledger)
    if status: stmt = stmt.where(Journal.status == status)
    if matter_id: stmt = stmt.where(Journal.matter_id == matter_id)
    if source_type: stmt = stmt.where(Journal.source_type == source_type)
    rows, total = paginate(ctx.db, stmt.order_by(Journal.created_at.desc(), Journal.id), p)
    return Page(items=[_journal_out(ctx, j, with_lines=False) for j in rows], total=total, limit=p.limit, offset=p.offset)


@router.get("/journals/{journal_id}", response_model=JournalOut)
def get_journal(journal_id: uuid.UUID, ctx: Ctx = Depends(require("ledger.read"))):
    return _journal_out(ctx, led._get_journal(ctx, journal_id))


@router.post("/journals", response_model=JournalOut, status_code=201)
def create_journal(body: JournalIn, ctx: Ctx = Depends(require("ledger.post"))):
    lines = [l.model_dump() for l in body.lines]
    j = led.create_journal(ctx, ledger=body.ledger, reference=body.reference, description=body.description, effective_date=body.effective_date, lines=lines,
                           source_type="manual", matter_id=body.matter_id, currency=body.currency, submit=body.submit)
    return _journal_out(ctx, j)


@router.post("/journals/{journal_id}/submit", response_model=JournalOut)
def submit_journal(journal_id: uuid.UUID, ctx: Ctx = Depends(require("ledger.post"))):
    led.submit_for_approval(ctx, journal_id)
    return _journal_out(ctx, led._get_journal(ctx, journal_id))


@router.post("/journals/{journal_id}/decision", response_model=JournalOut)
def decide_journal(journal_id: uuid.UUID, body: DecideIn, ctx: Ctx = Depends(require("ledger.approve"))):
    j = led._get_journal(ctx, journal_id)
    if not j.approval_id:
        raise ValidationFailed("This journal has not been submitted for approval.")
    led.decide_approval(ctx, j.approval_id, approve=body.approve, note=body.note)
    return _journal_out(ctx, led._get_journal(ctx, journal_id))


@router.post("/journals/{journal_id}/post", response_model=JournalOut)
def post_journal(journal_id: uuid.UUID, ctx: Ctx = Depends(require("ledger.post"))):
    return _journal_out(ctx, led.post_journal(ctx, journal_id))


@router.post("/journals/{journal_id}/reverse", response_model=JournalOut, status_code=201)
def reverse_journal(journal_id: uuid.UUID, body: ReverseIn, ctx: Ctx = Depends(require("ledger.post"))):
    return _journal_out(ctx, led.reverse_journal(ctx, journal_id, body.reason))


@router.post("/approvals/{approval_id}/decision")
def decide_finance_approval(approval_id: uuid.UUID, body: DecideIn, ctx: Ctx = Depends(require("ledger.approve"))):
    """Authorise or reject a ledger action (journal, receipt allocation, client-money transfer, revenue recognition). Four-eyes applies."""
    ap = led.decide_approval(ctx, approval_id, approve=body.approve, note=body.note)
    return {"id": ap.id, "kind": ap.kind, "status": ap.status, "decided_by": ap.decided_by, "decided_at": ap.decided_at, "payload_hash": ap.payload_hash}


# ------------------------------------------------------------------ bank feed & receipts
@router.post("/bank-feed/sync")
def bank_sync(body: BankSyncIn, ctx: Ctx = Depends(require("ledger.post"))):
    return jsonable(rec.sync_bank_feed(ctx, body.ledger))


@router.get("/bank-lines", response_model=Page[BankLineOut])
def bank_lines(ledger: str | None = None, status: str | None = None, unrecorded: bool = False, p: PageParams = Depends(), ctx: Ctx = Depends(require("ledger.read"))):
    stmt = select(BankStatementLine).where(BankStatementLine.firm_id == ctx.firm_id)
    if ledger: stmt = stmt.where(BankStatementLine.ledger == ledger)
    if status: stmt = stmt.where(BankStatementLine.status == status)
    if unrecorded: stmt = stmt.where(BankStatementLine.payment_id.is_(None), BankStatementLine.amount > 0)
    rows, total = paginate(ctx.db, stmt.order_by(BankStatementLine.txn_date.desc(), BankStatementLine.id), p)
    return Page(items=[BankLineOut.model_validate(r) for r in rows], total=total, limit=p.limit, offset=p.offset)


@router.get("/payments", response_model=Page[PaymentOut])
def list_payments(status: str | None = None, ledger: str | None = None, p: PageParams = Depends(), ctx: Ctx = Depends(require("ledger.read"))):
    stmt = select(Payment).where(Payment.firm_id == ctx.firm_id, or_(Payment.matter_id.is_(None), Payment.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))
    if status: stmt = stmt.where(Payment.status == status)
    if ledger: stmt = stmt.where(Payment.ledger == ledger)
    rows, total = paginate(ctx.db, stmt.order_by(Payment.received_on.desc(), Payment.id), p)
    return Page(items=[_payment_out(r) for r in rows], total=total, limit=p.limit, offset=p.offset)


@router.post("/payments", response_model=PaymentOut, status_code=201)
def record_receipt(body: ReceiptIn, ctx: Ctx = Depends(require("ledger.post"))):
    """Record a bank receipt (creates a payment + draft journal awaiting authorisation). Not revenue."""
    return _payment_out(rec.record_receipt(ctx, body.bank_line_id, matter_id=body.matter_id, received_from_id=body.received_from_id, reference=body.reference))


@router.post("/payments/{payment_id}/allocate")
def allocate(payment_id: uuid.UUID, body: AllocateIn, response: Response, ctx: Ctx = Depends(require("ledger.post"))):
    """Without approval_id: requests authorisation (202, returns the approval). With an approved approval_id: executes atomically (200)."""
    allocs = [{"invoice_id": str(a.invoice_id), "amount": a.amount} for a in body.allocations]
    if not body.approval_id:
        ap = led.request_allocation(ctx, payment_id, allocs)
        response.status_code = 202
        return {"status": "approval_requested", "approval_id": ap.id, "payload_hash": ap.payload_hash,
                "message": "A different person with ledger.approve must authorise this allocation before it is applied."}
    res = led.execute_allocation(ctx, payment_id, allocs, body.approval_id)
    return {"status": "allocated", "payment": _payment_out(res["payment"]), "journal_id": res["journal"].id}


@router.post("/client-transfers")
def client_transfer(body: TransferIn, response: Response, ctx: Ctx = Depends(require("ledger.post"))):
    """Move client money to office account to settle an issued invoice. Requires separate human authorisation (four-eyes)."""
    if not body.approval_id:
        ap = led.request_client_transfer(ctx, body.invoice_id, body.amount)
        response.status_code = 202
        return {"status": "approval_requested", "approval_id": ap.id, "payload_hash": ap.payload_hash}
    res = led.execute_client_transfer(ctx, body.invoice_id, body.amount, body.approval_id)
    return {"status": "transferred", "client_journal_id": res["client_journal"].id, "office_journal_id": res["office_journal"].id, "invoice_status": res["invoice"].status}


# ------------------------------------------------------------------ revenue recognition
@router.post("/revenue-recognition", response_model=JournalOut, status_code=201)
def recognise(body: RevRecIn, ctx: Ctx = Depends(require("ledger.post"))):
    """Creates the draft recognition journal + approval request. Revenue is recognised only when that journal is authorised and posted."""
    return _journal_out(ctx, led.request_revenue_recognition(ctx, body.invoice_id, body.amount, body.basis, body.recognised_on))


@router.get("/revenue-recognition")
def list_recognitions(ctx: Ctx = Depends(require("ledger.read"))):
    rows = ctx.db.execute(select(RevenueRecognition).where(RevenueRecognition.firm_id == ctx.firm_id,
                                                           RevenueRecognition.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))).order_by(RevenueRecognition.created_at.desc())).scalars()
    return [jsonable({"id": r.id, "invoice_id": r.invoice_id, "matter_id": r.matter_id, "amount": r.amount, "basis": r.basis, "recognised_on": r.recognised_on}) for r in rows]


# ------------------------------------------------------------------ reconciliation
def _recon_view(ctx: Ctx, r: Reconciliation, detail: bool = True) -> dict:
    out = {"id": r.id, "ledger": r.ledger, "bank_account_id": r.bank_account_id, "period_end": r.period_end, "statement_balance": r.statement_balance,
           "ledger_balance": r.ledger_balance, "difference": r.difference, "status": r.status, "prepared_by": r.prepared_by, "signed_off_by": r.signed_off_by,
           "signed_off_at": r.signed_off_at, "notes": r.notes}
    if detail and r.status == "draft":
        pos = rec._position(ctx.db, r)
        out.update(ledger_balance=pos["ledger_balance"], difference=pos["difference"], can_sign_off=pos["can_sign_off"],
                   unmatched_statement_lines=[BankLineOut.model_validate(x) for x in pos["unmatched_statement_lines"]],
                   unreconciled_journal_lines=[{"journal_line_id": jl.id, "journal_id": j.id, "reference": j.reference, "effective_date": j.effective_date,
                                                "debit": jl.debit, "credit": jl.credit} for jl, j in pos["unreconciled_journal_lines"]],
                   suggestions=rec.suggest_matches(ctx.db, ctx.firm_id, r.bank_account_id, r.period_end))
    return jsonable(out)


@router.get("/reconciliations")
def list_recs(p: PageParams = Depends(), ctx: Ctx = Depends(require("ledger.read"))):
    rows, total = paginate(ctx.db, select(Reconciliation).where(Reconciliation.firm_id == ctx.firm_id).order_by(Reconciliation.period_end.desc(), Reconciliation.id), p)
    return {"items": [_recon_view(ctx, r, detail=False) for r in rows], "total": total, "limit": p.limit, "offset": p.offset}


@router.post("/reconciliations", status_code=201)
def create_rec(body: ReconIn, ctx: Ctx = Depends(require("ledger.reconcile"))):
    r = rec.create_reconciliation(ctx, bank_account_id=body.bank_account_id, period_end=body.period_end, statement_balance=body.statement_balance, notes=body.notes)
    return _recon_view(ctx, r)


@router.get("/reconciliations/{rec_id}")
def get_rec(rec_id: uuid.UUID, ctx: Ctx = Depends(require("ledger.read"))):
    r = ctx.db.get(Reconciliation, rec_id)
    if not r or r.firm_id != ctx.firm_id:
        raise NotFound("Reconciliation not found.")
    return _recon_view(ctx, r)


@router.post("/reconciliations/{rec_id}/match")
def match(rec_id: uuid.UUID, body: MatchIn, ctx: Ctx = Depends(require("ledger.reconcile"))):
    r = ctx.db.get(Reconciliation, rec_id)
    if not r or r.firm_id != ctx.firm_id:
        raise NotFound("Reconciliation not found.")
    pairs = [p.model_dump() for p in body.pairs]
    if body.apply_suggestions:
        pairs += [{"bank_line_id": s["bank_line_id"], "journal_line_id": s["journal_line_id"]} for s in rec.suggest_matches(ctx.db, ctx.firm_id, r.bank_account_id, r.period_end)]
    n = rec.match_lines(ctx, pairs)
    rec.refresh(ctx, r)
    return {"matched": n, **_recon_view(ctx, r)}


@router.post("/reconciliations/{rec_id}/sign-off")
def sign_off(rec_id: uuid.UUID, ctx: Ctx = Depends(require("ledger.reconcile"))):
    return _recon_view(ctx, rec.sign_off(ctx, rec_id), detail=False)
