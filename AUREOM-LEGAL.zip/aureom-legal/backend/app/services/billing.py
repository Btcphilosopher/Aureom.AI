"""Time, expenses, rate cards, invoices, credit notes.

PROFESSIONAL / REGULATORY REVIEW REQUIRED BEFORE REAL USE
---------------------------------------------------------
This module is a DEMONSTRATION on synthetic data. It is not certified or approved against any accounting or
regulatory regime and must not be used for real client money or statutory accounts until it has been reviewed by the
firm's COLP/COFA, its accountants and (where relevant) its regulator's accounts rules (for England & Wales: the SRA
Accounts Rules), VAT advisers, and its insurers. Open points for that review include: the chart of accounts;
treatment of disbursements (here expense recharges are included in "fees billed - not yet recognised" for simplicity);
VAT treatment; bill delivery / client-money transfer timing and consent; interest; negative-balance and residual-balance
procedures; reconciliation frequency and sign-off evidence; segregation of duties; retention of records; and the
authorisation matrix. Nothing here asserts compliance.

Authorisation model chosen for invoices
---------------------------------------
Invoice approval (approvals kind "invoice_issue", four-eyes: approver != requester, needs billing.approve) bound to a
hash of the exact invoice content (lines, totals, recipients, narrative) is ALSO the authorisation for the issue
journal. `issue_invoice` (needs billing.issue) verifies that approval, then creates and posts the issue journal
(Dr debtors; Cr fees billed-not-yet-recognised for net; Cr VAT output) in the same transaction. Issuing an invoice
never recognises revenue and never records cash.
"""
from __future__ import annotations

import math
import uuid
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.errors import InvalidState, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.models import (Approval, Expense, Firm, Invoice, InvoiceLine, Journal, Matter, RateCard, RateCardEntry, TimeEntry, User)
from app.money import ZERO, D, q, time_amount, vat
from app.permissions import matter_clause
from app.services import approvals, ledger as led
from app.services.ledger import get_matter_for, invoice_outstanding, require_human


def _firm_setting(db: Session, firm_id, key: str, default):
    firm = db.get(Firm, firm_id)
    return (firm.settings or {}).get(key, default) if firm else default


def _check_version(obj, expected: int | None) -> None:
    if expected is not None and obj.version != expected:
        raise VersionConflict("This record was changed by someone else. Reload and try again.", details={"current_version": obj.version})


def _load(ctx: Ctx, model, id_, what: str, lock: bool = False):
    stmt = select(model).where(model.id == id_, model.firm_id == ctx.firm_id)
    if lock:
        stmt = stmt.with_for_update().execution_options(populate_existing=True)
    obj = ctx.db.execute(stmt).scalar_one_or_none()
    if not obj:
        raise NotFound(f"{what} not found.")
    if getattr(obj, "matter_id", None):
        get_matter_for(ctx, obj.matter_id)
    return obj


# ------------------------------------------------------------------------------------------ rate cards
def resolve_rate(db: Session, matter: Matter, user: User) -> Decimal | None:
    card_id = matter.rate_card_id
    if not card_id:
        card_id = db.execute(select(RateCard.id).where(RateCard.firm_id == matter.firm_id, RateCard.is_default.is_(True),
                                                       RateCard.is_active.is_(True))).scalars().first()
    if not card_id:
        return None
    entries = db.execute(select(RateCardEntry).where(RateCardEntry.rate_card_id == card_id)).scalars().all()
    for e in entries:
        if e.user_id == user.id:
            return q(e.hourly_rate)
    for e in entries:
        if e.user_id is None and user.grade and e.grade == user.grade:
            return q(e.hourly_rate)
    return None


def create_rate_card(ctx: Ctx, *, name: str, currency: str = "GBP", is_default: bool = False, entries: list[dict] | None = None) -> RateCard:
    if not (ctx.has("billing.write") or ctx.has("admin.settings")):
        ctx.require("billing.write")
    if is_default:
        ctx.db.execute(update(RateCard).where(RateCard.firm_id == ctx.firm_id).values(is_default=False))
    rc = RateCard(firm_id=ctx.firm_id, name=name, currency=currency, is_default=is_default)
    ctx.db.add(rc)
    ctx.db.flush()
    set_rate_card_entries(ctx, rc.id, entries or [])
    ctx.audit("rate_card.created", "rate_card", rc.id, f"Rate card '{name}' created")
    return rc


def set_rate_card_entries(ctx: Ctx, rate_card_id: uuid.UUID, entries: list[dict]) -> list[RateCardEntry]:
    if not (ctx.has("billing.write") or ctx.has("admin.settings")):
        ctx.require("billing.write")
    rc = _load(ctx, RateCard, rate_card_id, "Rate card")
    for old in ctx.db.execute(select(RateCardEntry).where(RateCardEntry.rate_card_id == rc.id)).scalars():
        ctx.db.delete(old)
    ctx.db.flush()
    out = []
    for e in entries:
        r = RateCardEntry(firm_id=ctx.firm_id, rate_card_id=rc.id, grade=e["grade"], user_id=e.get("user_id"), hourly_rate=q(D(e["hourly_rate"])))
        ctx.db.add(r)
        out.append(r)
    ctx.db.flush()
    ctx.audit("rate_card.entries_set", "rate_card", rc.id, f"Rate card '{rc.name}' rates updated", details={"entries": len(out)})
    return out


# ------------------------------------------------------------------------------------------ time entries
def _entry_matter(ctx: Ctx, matter_id) -> Matter:
    m = get_matter_for(ctx, matter_id)
    if m.status not in ("open", "paused"):
        raise InvalidState(f"Time and expenses cannot be recorded on a {m.status} matter.")
    return m


def create_time_entry(ctx: Ctx, *, matter_id: uuid.UUID, work_date: date, minutes: int, narrative: str = "", billable: bool = True,
                      rate: Decimal | None = None, user_id: uuid.UUID | None = None, source: str = "manual",
                      agent_run_id: uuid.UUID | None = None) -> TimeEntry:
    ctx.require("time.write")
    matter = _entry_matter(ctx, matter_id)
    owner = ctx.user
    if user_id and user_id != ctx.user.id:
        ctx.require("billing.write")
        owner = ctx.db.get(User, user_id)
        if not owner or owner.firm_id != ctx.firm_id:
            raise NotFound("User not found.")
    if rate is not None:
        ctx.require("billing.write")
    if minutes < 0 or minutes > 24 * 60:
        raise ValidationFailed("Minutes must be between 0 and 1440.")
    use_rate = ZERO
    if billable:
        use_rate = q(D(rate)) if rate is not None else resolve_rate(ctx.db, matter, owner)
        if use_rate is None:
            raise ValidationFailed("No hourly rate is configured for this fee earner on this matter. Add a rate card entry or enter a rate.", code="no_rate")
    te = TimeEntry(firm_id=ctx.firm_id, matter_id=matter.id, user_id=owner.id, work_date=work_date, minutes=minutes, narrative=narrative or "",
                   rate=use_rate, amount=time_amount(minutes, use_rate), currency=matter.currency, billable=billable, status="draft",
                   source=source, agent_run_id=agent_run_id)
    ctx.db.add(te)
    ctx.db.flush()
    ctx.audit("time.created", "time_entry", te.id, f"Time entry recorded ({minutes} min)", matter_id=matter.id, details={"minutes": minutes, "source": source})
    return te


def _own_or_write(ctx: Ctx, entry) -> None:
    if entry.user_id != ctx.user.id:
        ctx.require("billing.write")


def update_time_entry(ctx: Ctx, entry_id: uuid.UUID, *, expected_version: int | None = None, **fields) -> TimeEntry:
    te = _load(ctx, TimeEntry, entry_id, "Time entry", lock=True)
    _check_version(te, expected_version)
    _own_or_write(ctx, te)
    if te.status not in ("draft", "submitted") or te.invoice_line_id:
        raise InvalidState(f"A {te.status} time entry cannot be edited.")
    if te.timer_started_at:
        raise InvalidState("Stop the running timer first.")
    for k in ("work_date", "narrative", "billable"):
        if fields.get(k) is not None:
            setattr(te, k, fields[k])
    if fields.get("minutes") is not None:
        if not 0 <= fields["minutes"] <= 1440:
            raise ValidationFailed("Minutes must be between 0 and 1440.")
        te.minutes = fields["minutes"]
    if fields.get("rate") is not None:
        ctx.require("billing.write")
        te.rate = q(D(fields["rate"]))
    if not te.billable:
        te.rate = ZERO
    elif te.rate == ZERO and fields.get("billable"):
        r = resolve_rate(ctx.db, ctx.db.get(Matter, te.matter_id), ctx.db.get(User, te.user_id))
        if r is None:
            raise ValidationFailed("No hourly rate is configured; enter a rate.", code="no_rate")
        te.rate = r
    te.amount = time_amount(te.minutes, te.rate)
    ctx.db.flush()
    ctx.audit("time.updated", "time_entry", te.id, "Time entry updated", matter_id=te.matter_id, details={"minutes": te.minutes})
    return te


def submit_time_entry(ctx: Ctx, entry_id: uuid.UUID) -> TimeEntry:
    te = _load(ctx, TimeEntry, entry_id, "Time entry", lock=True)
    _own_or_write(ctx, te)
    if te.status != "draft":
        raise InvalidState(f"Only draft time can be submitted (this is {te.status}).")
    if te.timer_started_at:
        raise InvalidState("Stop the running timer first.")
    if te.minutes <= 0:
        raise ValidationFailed("Time must be greater than zero.")
    if te.billable and len((te.narrative or "").strip()) < 3:
        raise ValidationFailed("A narrative is required before billable time is submitted; it has not been invented for you.", code="narrative_required")
    te.status = "submitted"
    ctx.db.flush()
    ctx.audit("time.submitted", "time_entry", te.id, "Time submitted", matter_id=te.matter_id)
    return te


def approve_time_entry(ctx: Ctx, entry_id: uuid.UUID) -> TimeEntry:
    ctx.require("billing.write")
    te = _load(ctx, TimeEntry, entry_id, "Time entry", lock=True)
    if te.status != "submitted":
        raise InvalidState(f"Only submitted time can be approved (this is {te.status}).")
    te.status = "approved"
    ctx.db.flush()
    ctx.audit("time.approved", "time_entry", te.id, "Time approved", matter_id=te.matter_id)
    return te


def write_off_time_entry(ctx: Ctx, entry_id: uuid.UUID, reason: str) -> TimeEntry:
    ctx.require("billing.write")
    if not reason or len(reason.strip()) < 3:
        raise ValidationFailed("A reason is required to write off time.")
    te = _load(ctx, TimeEntry, entry_id, "Time entry", lock=True)
    if te.status in ("billed", "written_off") or te.invoice_line_id:
        raise InvalidState(f"A {te.status} time entry cannot be written off.")
    te.status = "written_off"
    ctx.db.flush()
    ctx.audit("time.written_off", "time_entry", te.id, "Time written off", matter_id=te.matter_id, details={"reason": reason.strip()[:300], "amount": str(te.amount)})
    return te


def delete_time_entry(ctx: Ctx, entry_id: uuid.UUID) -> None:
    te = _load(ctx, TimeEntry, entry_id, "Time entry", lock=True)
    _own_or_write(ctx, te)
    if te.status != "draft" or te.invoice_line_id:
        raise InvalidState("Only draft time entries can be deleted.")
    ctx.db.delete(te)
    ctx.db.flush()
    ctx.audit("time.deleted", "time_entry", entry_id, "Draft time entry deleted", matter_id=te.matter_id)


def time_entry_query(ctx: Ctx):
    """Time entries the user may see: within visible matters; own entries always; everyone's if billing.read / time.read_all."""
    stmt = select(TimeEntry).where(TimeEntry.firm_id == ctx.firm_id, TimeEntry.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))
    if not (ctx.has("time.read_all") or ctx.has("billing.read")):
        stmt = stmt.where(TimeEntry.user_id == ctx.user.id)
    return stmt


# ------------------------------------------------------------------------------------------ timers
def running_timer(ctx: Ctx) -> TimeEntry | None:
    return ctx.db.execute(select(TimeEntry).where(TimeEntry.firm_id == ctx.firm_id, TimeEntry.user_id == ctx.user.id,
                                                  TimeEntry.timer_started_at.is_not(None))).scalars().first()


def start_timer(ctx: Ctx, matter_id: uuid.UUID, narrative: str = "", billable: bool = True) -> TimeEntry:
    ctx.require("time.write")
    matter = _entry_matter(ctx, matter_id)
    if running_timer(ctx):
        raise InvalidState("A timer is already running. Stop it before starting another.", code="timer_running")
    rate = ZERO
    if billable:
        rate = resolve_rate(ctx.db, matter, ctx.user)
        if rate is None:
            raise ValidationFailed("No hourly rate is configured for you on this matter.", code="no_rate")
    te = TimeEntry(firm_id=ctx.firm_id, matter_id=matter.id, user_id=ctx.user.id, work_date=date.today(), minutes=0, narrative=narrative,
                   rate=rate, amount=ZERO, currency=matter.currency, billable=billable, status="draft", source="timer",
                   timer_started_at=datetime.now(timezone.utc))
    try:
        with ctx.db.begin_nested():
            ctx.db.add(te)
            ctx.db.flush()
    except IntegrityError:
        raise InvalidState("A timer is already running. Stop it before starting another.", code="timer_running")
    ctx.audit("time.timer_started", "time_entry", te.id, "Timer started", matter_id=matter.id)
    return te


def stop_timer(ctx: Ctx, narrative: str | None = None, now: datetime | None = None) -> TimeEntry:
    te = running_timer(ctx)
    if not te:
        raise InvalidState("No timer is running.", code="no_timer")
    now = now or datetime.now(timezone.utc)
    seconds = max(0, (now - te.timer_started_at).total_seconds())
    minutes = max(1, math.ceil(seconds / 60))
    unit = int(_firm_setting(ctx.db, ctx.firm_id, "time_unit_minutes", 1) or 1)
    if unit > 1:
        minutes = math.ceil(minutes / unit) * unit
    te.minutes, te.timer_started_at = minutes, None
    if narrative is not None:
        te.narrative = narrative
    te.amount = time_amount(minutes, te.rate)
    ctx.db.flush()
    ctx.audit("time.timer_stopped", "time_entry", te.id, f"Timer stopped ({minutes} min)", matter_id=te.matter_id, details={"minutes": minutes, "unit": unit})
    return te


# ------------------------------------------------------------------------------------------ expenses
def create_expense(ctx: Ctx, *, matter_id: uuid.UUID, expense_date: date, description: str, amount: Decimal, vat_rate: Decimal = Decimal("0"),
                   billable: bool = True) -> Expense:
    ctx.require("time.write")
    matter = _entry_matter(ctx, matter_id)
    amount = q(D(amount))
    if amount < 0:
        raise ValidationFailed("Expense amount cannot be negative.")
    e = Expense(firm_id=ctx.firm_id, matter_id=matter.id, user_id=ctx.user.id, expense_date=expense_date, description=description[:300],
                amount=amount, vat_rate=D(vat_rate), currency=matter.currency, billable=billable, status="draft")
    ctx.db.add(e)
    ctx.db.flush()
    ctx.audit("expense.created", "expense", e.id, "Expense recorded", matter_id=matter.id, details={"amount": str(amount)})
    return e


def update_expense(ctx: Ctx, expense_id: uuid.UUID, *, expected_version: int | None = None, **fields) -> Expense:
    e = _load(ctx, Expense, expense_id, "Expense", lock=True)
    _check_version(e, expected_version)
    if e.user_id != ctx.user.id:
        ctx.require("billing.write")
    if e.status not in ("draft", "approved") or e.invoice_line_id:
        raise InvalidState(f"A {e.status} expense cannot be edited.")
    for k in ("expense_date", "description", "billable"):
        if fields.get(k) is not None:
            setattr(e, k, fields[k])
    if fields.get("amount") is not None:
        e.amount = q(D(fields["amount"]))
    if fields.get("vat_rate") is not None:
        e.vat_rate = D(fields["vat_rate"])
    ctx.db.flush()
    ctx.audit("expense.updated", "expense", e.id, "Expense updated", matter_id=e.matter_id)
    return e


def approve_expense(ctx: Ctx, expense_id: uuid.UUID) -> Expense:
    ctx.require("billing.write")
    e = _load(ctx, Expense, expense_id, "Expense", lock=True)
    if e.status != "draft":
        raise InvalidState(f"Only draft expenses can be approved (this is {e.status}).")
    e.status = "approved"
    ctx.db.flush()
    ctx.audit("expense.approved", "expense", e.id, "Expense approved", matter_id=e.matter_id)
    return e


def write_off_expense(ctx: Ctx, expense_id: uuid.UUID, reason: str) -> Expense:
    ctx.require("billing.write")
    if not reason or len(reason.strip()) < 3:
        raise ValidationFailed("A reason is required to write off an expense.")
    e = _load(ctx, Expense, expense_id, "Expense", lock=True)
    if e.status in ("billed", "written_off") or e.invoice_line_id:
        raise InvalidState(f"A {e.status} expense cannot be written off.")
    e.status = "written_off"
    ctx.db.flush()
    ctx.audit("expense.written_off", "expense", e.id, "Expense written off", matter_id=e.matter_id, details={"reason": reason.strip()[:300]})
    return e


def expense_query(ctx: Ctx):
    stmt = select(Expense).where(Expense.firm_id == ctx.firm_id, Expense.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))
    if not (ctx.has("time.read_all") or ctx.has("billing.read")):
        stmt = stmt.where(Expense.user_id == ctx.user.id)
    return stmt


# ------------------------------------------------------------------------------------------ invoices
def invoice_lines(db: Session, invoice_id: uuid.UUID) -> list[InvoiceLine]:
    return list(db.execute(select(InvoiceLine).where(InvoiceLine.invoice_id == invoice_id).order_by(InvoiceLine.id)).scalars())


def invoice_payload(inv: Invoice, lines: list[InvoiceLine]) -> dict:
    """Canonical content an invoice approval binds to."""
    ls = [{"type": l.line_type, "description": l.description, "qty": str(l.quantity), "unit": str(q(l.unit_amount)), "amount": str(q(l.amount)),
           "vat_rate": str(l.vat_rate), "vat": str(q(l.vat_amount)), "time_entry_id": str(l.time_entry_id) if l.time_entry_id else None,
           "expense_id": str(l.expense_id) if l.expense_id else None} for l in lines]
    ls.sort(key=lambda x: (x["type"], x["description"], x["amount"], x["time_entry_id"] or "", x["expense_id"] or ""))
    return {"kind": inv.kind, "matter_id": str(inv.matter_id), "client_id": str(inv.client_id), "payer_id": str(inv.payer_id) if inv.payer_id else None,
            "currency": inv.currency, "credit_for": str(inv.credit_for_invoice_id) if inv.credit_for_invoice_id else None, "narrative": inv.narrative or "",
            "lines": ls, "subtotal": str(q(inv.subtotal)), "vat": str(q(inv.vat_amount)), "total": str(q(inv.total))}


def _recalc(db: Session, inv: Invoice) -> list[InvoiceLine]:
    lines = invoice_lines(db, inv.id)
    inv.subtotal = q(sum((q(l.amount) for l in lines), ZERO))
    inv.vat_amount = q(sum((q(l.vat_amount) for l in lines), ZERO))
    inv.total = q(inv.subtotal + inv.vat_amount)
    db.flush()
    return lines


def _reset_approval(ctx: Ctx, inv: Invoice) -> None:
    """Any content change after submission invalidates the approval (and returns the invoice to draft)."""
    if inv.approval_id:
        ap = ctx.db.get(Approval, inv.approval_id)
        if ap and ap.status in ("pending", "approved"):
            ap.status = "superseded"
    inv.approval_id, inv.approved_hash = None, None
    if inv.status == "pending_approval":
        inv.status = "draft"


def _vat_rate(ctx: Ctx) -> Decimal:
    return D(_firm_setting(ctx.db, ctx.firm_id, "vat_rate", "20.00"))


def _add_time_line(ctx: Ctx, inv: Invoice, te: TimeEntry, rate: Decimal) -> None:
    hours = (Decimal(te.minutes) / Decimal(60)).quantize(Decimal("0.01"))
    desc = f"{te.work_date.isoformat()} - {te.narrative}".strip()
    line = InvoiceLine(firm_id=ctx.firm_id, invoice_id=inv.id, line_type="time", description=desc, quantity=hours, unit_amount=q(te.rate),
                       amount=q(te.amount), vat_rate=rate, vat_amount=vat(te.amount, rate), time_entry_id=te.id)
    ctx.db.add(line)
    ctx.db.flush()
    te.invoice_line_id = line.id


def _add_expense_line(ctx: Ctx, inv: Invoice, e: Expense) -> None:
    line = InvoiceLine(firm_id=ctx.firm_id, invoice_id=inv.id, line_type="expense", description=f"{e.expense_date.isoformat()} - {e.description}",
                       quantity=Decimal("1"), unit_amount=q(e.amount), amount=q(e.amount), vat_rate=e.vat_rate, vat_amount=vat(e.amount, e.vat_rate), expense_id=e.id)
    ctx.db.add(line)
    ctx.db.flush()
    e.invoice_line_id = line.id


def _select_unbilled(ctx: Ctx, matter_id, time_ids, expense_ids) -> tuple[list[TimeEntry], list[Expense]]:
    tes, exps = [], []
    if time_ids:
        tes = list(ctx.db.execute(select(TimeEntry).where(TimeEntry.id.in_(time_ids), TimeEntry.firm_id == ctx.firm_id).with_for_update()
                                  .execution_options(populate_existing=True)).scalars())
        if len(tes) != len(set(time_ids)):
            raise NotFound("One or more time entries were not found.")
        for t in tes:
            if t.matter_id != matter_id or t.status not in ("submitted", "approved") or not t.billable or t.invoice_line_id or t.timer_started_at:
                raise InvalidState(f"Time entry {t.work_date} ({t.status}) is not available to bill: it must be submitted/approved, billable, on this matter and not already on an invoice.",
                                   code="time_not_billable")
    if expense_ids:
        exps = list(ctx.db.execute(select(Expense).where(Expense.id.in_(expense_ids), Expense.firm_id == ctx.firm_id).with_for_update()
                                   .execution_options(populate_existing=True)).scalars())
        if len(exps) != len(set(expense_ids)):
            raise NotFound("One or more expenses were not found.")
        for e in exps:
            if e.matter_id != matter_id or e.status not in ("draft", "approved") or not e.billable or e.invoice_line_id:
                raise InvalidState(f"Expense '{e.description}' ({e.status}) is not available to bill.", code="expense_not_billable")
    return tes, exps


def _add_adjustments(ctx: Ctx, inv: Invoice, adjustments: list[dict]) -> None:
    for a in adjustments:
        amount = q(D(a["amount"]))
        rate = D(a.get("vat_rate", _vat_rate(ctx)))
        ctx.db.add(InvoiceLine(firm_id=ctx.firm_id, invoice_id=inv.id, line_type="adjustment", description=a["description"][:500], quantity=Decimal("1"),
                               unit_amount=amount, amount=amount, vat_rate=rate, vat_amount=vat(amount, rate)))
    ctx.db.flush()


def create_draft_invoice(ctx: Ctx, *, matter_id: uuid.UUID, time_entry_ids: list[uuid.UUID] | None = None, expense_ids: list[uuid.UUID] | None = None,
                         include_fixed_fee: bool = False, fixed_fee_amount: Decimal | None = None, adjustments: list[dict] | None = None,
                         payer_id: uuid.UUID | None = None, narrative: str | None = None, due_days: int = 30) -> Invoice:
    ctx.require("billing.write")
    require_human(ctx, "invoice creation")
    matter = get_matter_for(ctx, matter_id)
    if matter.status not in ("open", "paused", "closed"):
        raise InvalidState("Invoices can only be raised on opened matters.")
    tes, exps = _select_unbilled(ctx, matter.id, time_entry_ids or [], expense_ids or [])
    inv = Invoice(firm_id=ctx.firm_id, matter_id=matter.id, client_id=matter.client_id, payer_id=payer_id, kind="invoice", status="draft",
                  currency=matter.currency, narrative=narrative, created_by=ctx.user.id, due_date=date.today() + timedelta(days=due_days))
    ctx.db.add(inv)
    ctx.db.flush()
    rate = _vat_rate(ctx)
    for t in tes:
        _add_time_line(ctx, inv, t, rate)
    for e in exps:
        _add_expense_line(ctx, inv, e)
    fixed = q(D(fixed_fee_amount)) if fixed_fee_amount is not None else (matter.fixed_fee_amount if include_fixed_fee else None)
    if include_fixed_fee and fixed is None:
        raise ValidationFailed("This matter has no fixed fee amount; supply fixed_fee_amount.")
    if include_fixed_fee:
        ctx.db.add(InvoiceLine(firm_id=ctx.firm_id, invoice_id=inv.id, line_type="fixed", description=f"Fixed fee - {matter.title}"[:500], quantity=Decimal("1"),
                               unit_amount=q(fixed), amount=q(fixed), vat_rate=rate, vat_amount=vat(fixed, rate)))
    _add_adjustments(ctx, inv, adjustments or [])
    lines = _recalc(ctx.db, inv)
    if not lines:
        raise ValidationFailed("An invoice needs at least one line (time, expenses, a fixed fee or an adjustment).")
    if inv.subtotal < 0:
        raise ValidationFailed("Invoice total cannot be negative; use a credit note instead.")
    ctx.audit("invoice.draft_created", "invoice", inv.id, "Draft invoice created", matter_id=matter.id, details={"lines": len(lines), "total": str(inv.total)})
    return inv


def update_draft_invoice(ctx: Ctx, invoice_id: uuid.UUID, *, expected_version: int | None = None, narrative: str | None = None, due_date: date | None = None,
                         payer_id: uuid.UUID | None = None, add_time_entry_ids: list[uuid.UUID] | None = None, add_expense_ids: list[uuid.UUID] | None = None,
                         remove_line_ids: list[uuid.UUID] | None = None, add_adjustments: list[dict] | None = None) -> Invoice:
    ctx.require("billing.write")
    require_human(ctx, "invoice editing")
    inv = _load(ctx, Invoice, invoice_id, "Invoice", lock=True)
    _check_version(inv, expected_version)
    if inv.status not in ("draft", "pending_approval"):
        raise InvalidState(f"A {inv.status} invoice cannot be edited.")
    rate = _vat_rate(ctx)
    if inv.kind == "invoice":
        tes, exps = _select_unbilled(ctx, inv.matter_id, add_time_entry_ids or [], add_expense_ids or [])
        for t in tes:
            _add_time_line(ctx, inv, t, rate)
        for e in exps:
            _add_expense_line(ctx, inv, e)
    for lid in remove_line_ids or []:
        l = ctx.db.get(InvoiceLine, lid)
        if not l or l.invoice_id != inv.id:
            raise NotFound("Invoice line not found.")
        if l.time_entry_id:
            ctx.db.execute(update(TimeEntry).where(TimeEntry.id == l.time_entry_id).values(invoice_line_id=None))
        if l.expense_id:
            ctx.db.execute(update(Expense).where(Expense.id == l.expense_id).values(invoice_line_id=None))
        ctx.db.delete(l)
    ctx.db.flush()
    _add_adjustments(ctx, inv, add_adjustments or [])
    if narrative is not None:
        inv.narrative = narrative
    if due_date is not None:
        inv.due_date = due_date
    if payer_id is not None:
        inv.payer_id = payer_id
    _reset_approval(ctx, inv)
    lines = _recalc(ctx.db, inv)
    if inv.subtotal < 0:
        raise ValidationFailed("Invoice total cannot be negative.")
    ctx.audit("invoice.draft_updated", "invoice", inv.id, "Draft invoice edited (any prior approval withdrawn)", matter_id=inv.matter_id, details={"lines": len(lines), "total": str(inv.total)})
    return inv


def void_draft_invoice(ctx: Ctx, invoice_id: uuid.UUID, reason: str) -> Invoice:
    ctx.require("billing.write")
    inv = _load(ctx, Invoice, invoice_id, "Invoice", lock=True)
    if inv.status not in ("draft", "pending_approval"):
        raise InvalidState("Only unissued invoices can be voided; issued invoices are corrected with a credit note.")
    for l in invoice_lines(ctx.db, inv.id):
        if l.time_entry_id:
            ctx.db.execute(update(TimeEntry).where(TimeEntry.id == l.time_entry_id).values(invoice_line_id=None))
        if l.expense_id:
            ctx.db.execute(update(Expense).where(Expense.id == l.expense_id).values(invoice_line_id=None))
    _reset_approval(ctx, inv)
    inv.status = "void"
    ctx.db.flush()
    ctx.audit("invoice.voided", "invoice", inv.id, "Unissued invoice voided", matter_id=inv.matter_id, details={"reason": (reason or "")[:300]})
    return inv


def submit_invoice_for_approval(ctx: Ctx, invoice_id: uuid.UUID) -> Approval:
    ctx.require("billing.write")
    require_human(ctx, "invoice submission")
    inv = _load(ctx, Invoice, invoice_id, "Invoice", lock=True)
    if inv.status != "draft":
        raise InvalidState(f"Only draft invoices can be submitted (this is {inv.status}).")
    lines = invoice_lines(ctx.db, inv.id)
    if not lines or inv.total <= 0:
        raise ValidationFailed("An invoice must have lines and a positive total before approval.")
    payload = invoice_payload(inv, lines)
    ap = approvals.request_approval(ctx, kind="invoice_issue", subject_type="invoice", subject_id=inv.id, payload=payload, matter_id=inv.matter_id,
                                    required_permission="billing.approve")
    inv.status, inv.approval_id, inv.approved_hash = "pending_approval", ap.id, ap.payload_hash
    ctx.db.flush()
    return ap


def decide_invoice(ctx: Ctx, invoice_id: uuid.UUID, *, approve: bool, note: str | None = None) -> Invoice:
    require_human(ctx, "invoice approval")
    inv = _load(ctx, Invoice, invoice_id, "Invoice", lock=True)
    if inv.status != "pending_approval" or not inv.approval_id:
        raise InvalidState("This invoice is not awaiting approval.")
    approvals.decide(ctx, inv.approval_id, approve=approve, note=note)
    if not approve:
        inv.status = "draft"
    ctx.db.flush()
    return inv


def _next_number(db: Session, firm_id, prefix: str, year: int) -> str:
    from sqlalchemy import text
    db.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": f"invnum:{firm_id}:{prefix}"})
    n = db.execute(select(func.count(Invoice.id)).where(Invoice.firm_id == firm_id, Invoice.number.like(f"{prefix}-{year}-%"))).scalar_one()
    return f"{prefix}-{year}-{n + 1:04d}"


def issue_invoice(ctx: Ctx, invoice_id: uuid.UUID) -> Invoice:
    """Issue an approved invoice or credit note: number, lock WIP as billed, post the issue journal. NOT revenue, NOT cash."""
    ctx.require("billing.issue")
    require_human(ctx, "invoice issue")
    inv = _load(ctx, Invoice, invoice_id, "Invoice", lock=True)
    if inv.status != "pending_approval" or not inv.approval_id:
        raise InvalidState("Only an invoice that has been submitted and approved can be issued.", code="approval_required")
    lines = invoice_lines(ctx.db, inv.id)
    ap = approvals.assert_approved(ctx, inv.approval_id, kind="invoice_issue", payload=invoice_payload(inv, lines), subject_id=inv.id)
    original = None
    if inv.kind == "credit_note":
        original = ctx.db.execute(select(Invoice).where(Invoice.id == inv.credit_for_invoice_id).with_for_update().execution_options(populate_existing=True)).scalar_one()
        if original.status not in ("issued", "partially_paid", "paid"):
            raise InvalidState("The invoice being credited is not issued.")
        if q(inv.total) > invoice_outstanding(ctx.db, original) - Decimal("0.00"):
            raise InvalidState("Credit note exceeds the outstanding balance of the invoice it credits.", code="credit_exceeds_outstanding")
    # WIP must still be unbilled
    for l in lines:
        if l.time_entry_id:
            te = ctx.db.execute(select(TimeEntry).where(TimeEntry.id == l.time_entry_id).with_for_update().execution_options(populate_existing=True)).scalar_one()
            if te.status not in ("submitted", "approved"):
                raise InvalidState("A time entry on this invoice has since been billed or written off.", code="time_not_billable")
        if l.expense_id:
            ex = ctx.db.execute(select(Expense).where(Expense.id == l.expense_id).with_for_update().execution_options(populate_existing=True)).scalar_one()
            if ex.status not in ("draft", "approved"):
                raise InvalidState("An expense on this invoice has since been billed or written off.", code="expense_not_billable")
    now = datetime.now(timezone.utc)
    prefix = "INV" if inv.kind == "invoice" else "CN"
    inv.number = _next_number(ctx.db, ctx.firm_id, prefix, now.year)
    debtors = led.system_account(ctx.db, ctx.firm_id, "debtors", "office")
    unrec = led.system_account(ctx.db, ctx.firm_id, "fees_billed_unrecognised", "office")
    vat_acct = led.system_account(ctx.db, ctx.firm_id, "vat_output", "office")
    net, vat_amt, total = q(inv.subtotal), q(inv.vat_amount), q(inv.total)
    jl: list[dict] = []
    if inv.kind == "invoice":
        jl.append({"account_id": debtors.id, "debit": total, "matter_id": inv.matter_id, "narrative": inv.number})
        jl.append({"account_id": unrec.id, "credit": net, "matter_id": inv.matter_id, "narrative": inv.number})
        if vat_amt > 0:
            jl.append({"account_id": vat_acct.id, "credit": vat_amt, "matter_id": inv.matter_id, "narrative": inv.number})
    else:
        # credit note: reverse the effect. Portion that exceeds still-unrecognised fees debits recognised fee income.
        remaining = max(ZERO, led.recognisable_remaining(ctx.db, original))
        from_unrec = min(net, remaining)
        from_income = net - from_unrec
        if from_unrec > 0:
            jl.append({"account_id": unrec.id, "debit": from_unrec, "matter_id": inv.matter_id, "narrative": inv.number})
        if from_income > 0:
            jl.append({"account_id": led.system_account(ctx.db, ctx.firm_id, "fee_income", "office").id, "debit": from_income, "matter_id": inv.matter_id,
                       "narrative": f"{inv.number} (recognised fees credited)"})
        if vat_amt > 0:
            jl.append({"account_id": vat_acct.id, "debit": vat_amt, "matter_id": inv.matter_id, "narrative": inv.number})
        jl.append({"account_id": debtors.id, "credit": total, "matter_id": inv.matter_id, "narrative": inv.number})
    j = led.create_journal(ctx, ledger="office", reference=inv.number, description=f"{'Invoice' if inv.kind == 'invoice' else 'Credit note'} {inv.number} issued",
                           effective_date=now.date(), lines=jl, source_type="invoice_issue", source_id=inv.id, matter_id=inv.matter_id, currency=inv.currency)
    j.status = "pending_approval"
    ctx.db.flush()
    led._post(ctx, j, ap)  # authorised by the invoice approval verified above
    inv.status, inv.issued_at, inv.issued_by, inv.issue_journal_id = "issued", now, ctx.user.id, j.id
    if not inv.due_date:
        inv.due_date = now.date() + timedelta(days=30)
    if inv.kind == "invoice":
        for l in lines:
            if l.time_entry_id:
                ctx.db.execute(update(TimeEntry).where(TimeEntry.id == l.time_entry_id).values(status="billed"))
            if l.expense_id:
                ctx.db.execute(update(Expense).where(Expense.id == l.expense_id).values(status="billed"))
    ctx.db.flush()
    ctx.audit("invoice.issued", "invoice", inv.id, f"{'Invoice' if inv.kind == 'invoice' else 'Credit note'} {inv.number} issued", matter_id=inv.matter_id,
              details={"number": inv.number, "total": str(total), "approval_id": str(ap.id), "journal_id": str(j.id), "revenue_recognised": False})
    return inv


def create_credit_note(ctx: Ctx, invoice_id: uuid.UUID, *, full: bool = False, lines: list[dict] | None = None, narrative: str | None = None) -> Invoice:
    ctx.require("billing.write")
    require_human(ctx, "credit note creation")
    orig = _load(ctx, Invoice, invoice_id, "Invoice", lock=True)
    if orig.kind != "invoice" or orig.status not in ("issued", "partially_paid", "paid"):
        raise InvalidState("A credit note can only reference an issued invoice.")
    cn = Invoice(firm_id=ctx.firm_id, matter_id=orig.matter_id, client_id=orig.client_id, payer_id=orig.payer_id, kind="credit_note", status="draft",
                 credit_for_invoice_id=orig.id, currency=orig.currency, narrative=narrative, created_by=ctx.user.id)
    ctx.db.add(cn)
    ctx.db.flush()
    if full:
        for l in invoice_lines(ctx.db, orig.id):
            ctx.db.add(InvoiceLine(firm_id=ctx.firm_id, invoice_id=cn.id, line_type="adjustment", description=f"Credit: {l.description}"[:500], quantity=l.quantity,
                                   unit_amount=l.unit_amount, amount=l.amount, vat_rate=l.vat_rate, vat_amount=l.vat_amount))
    for l in lines or []:
        amount = q(D(l["amount"]))
        if amount <= 0:
            raise ValidationFailed("Credit note line amounts are entered as positive amounts.")
        rate = D(l.get("vat_rate", _vat_rate(ctx)))
        ctx.db.add(InvoiceLine(firm_id=ctx.firm_id, invoice_id=cn.id, line_type="adjustment", description=l["description"][:500], quantity=Decimal("1"),
                               unit_amount=amount, amount=amount, vat_rate=rate, vat_amount=vat(amount, rate)))
    ctx.db.flush()
    _recalc(ctx.db, cn)
    if cn.total <= 0:
        raise ValidationFailed("A credit note needs at least one line with a positive amount.")
    committed = led.credited_total(ctx.db, orig.id, issued_only=False, exclude=cn.id)
    available = q(orig.total) - q(orig.amount_paid) - committed
    if q(cn.total) > available:
        raise InvalidState(f"Credit note total {cn.total} exceeds what can still be credited on {orig.number} ({available}).", code="credit_exceeds_outstanding")
    ctx.audit("credit_note.draft_created", "invoice", cn.id, f"Draft credit note for {orig.number}", matter_id=orig.matter_id, details={"total": str(cn.total)})
    return cn


# ------------------------------------------------------------------------------------------ dashboard
def home_summary(ctx: Ctx) -> dict:
    """Unbilled time and draft invoices for the dashboard, subject to permissions. Calculation basis is stated."""
    out: dict = {"currency": "GBP", "generated_at": datetime.now(timezone.utc),
                 "basis": "Unbilled time = billable time entries in draft/submitted/approved status not yet on an issued invoice, valued at the recorded rate. It is work in progress, not revenue."}
    if not ctx.has("time.write") and not ctx.has("billing.read"):
        out["unbilled_time"], out["draft_invoices"] = None, None
        out["permitted"] = False
        return out
    out["permitted"] = True
    scope_all = ctx.has("time.read_all") or ctx.has("billing.read")
    q_t = (select(func.coalesce(func.sum(TimeEntry.amount), 0), func.coalesce(func.sum(TimeEntry.minutes), 0), func.count(TimeEntry.id))
           .where(TimeEntry.firm_id == ctx.firm_id, TimeEntry.billable.is_(True), TimeEntry.status.in_(("draft", "submitted", "approved")),
                  TimeEntry.timer_started_at.is_(None), TimeEntry.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))
    if not scope_all:
        q_t = q_t.where(TimeEntry.user_id == ctx.user.id)
    amt, mins, n = ctx.db.execute(q_t).one()
    out["unbilled_time"] = {"amount": q(Decimal(amt)), "hours": (Decimal(mins) / 60).quantize(Decimal("0.1")), "entries": n,
                            "scope": "all visible matters" if scope_all else "your own time", "href": "/time-billing?tab=time&status=unbilled"}
    if ctx.has("billing.read"):
        row = ctx.db.execute(select(func.count(Invoice.id), func.coalesce(func.sum(Invoice.total), 0)).where(
            Invoice.firm_id == ctx.firm_id, Invoice.kind == "invoice", Invoice.status.in_(("draft", "pending_approval")),
            Invoice.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))).one()
        out["draft_invoices"] = {"count": row[0], "total": q(Decimal(row[1])), "href": "/time-billing?tab=invoices&status=draft"}
    else:
        out["draft_invoices"] = None
    return out
