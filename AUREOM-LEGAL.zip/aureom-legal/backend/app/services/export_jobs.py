"""Controlled export of matter documents: request -> four-eyes approval -> worker builds zip + manifest -> time-limited audited download."""
from __future__ import annotations

import io
import json
import uuid
import zipfile
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app import audit
from app.deps import Ctx
from app.errors import InvalidState, NotFound, PermissionDenied, ValidationFailed
from app.models import Approval, Document, DocumentVersion, ExportRequest, Matter
from app.permissions import can_export
from app.security import canonical_hash, sha256_hex
from app.services import approvals as approvals_svc
from app.services import documents as docs
from app.services import filetypes
from app.services.jobs import enqueue, job_handler
from app.services.notify import notify
from app.storage import get_storage

EXPORT_TTL = timedelta(hours=24)


def _payload(db, matter_id, document_ids: list[uuid.UUID]) -> dict:
    vers = {}
    for did in sorted(document_ids, key=str):
        d = db.get(Document, did)
        v = db.get(DocumentVersion, d.current_version_id)
        vers[str(did)] = {"version_no": v.version_no, "sha256": v.sha256}
    return {"matter_id": str(matter_id), "documents": vers}


def request_export(ctx: Ctx, matter_id: uuid.UUID, document_ids: list[uuid.UUID], reason: str) -> ExportRequest:
    ctx.require("documents.export")
    m = docs._load_matter(ctx, matter_id)
    if not can_export(ctx, m):
        raise PermissionDenied("Exports are disabled for this matter.", code="export_blocked")
    if not reason or len(reason.strip()) < 5:
        raise ValidationFailed("A reason for the export is required.")
    if not document_ids:
        raise ValidationFailed("Select at least one document.")
    ids = list(dict.fromkeys(document_ids))
    for did in ids:
        d = ctx.db.get(Document, did)
        if not d or d.firm_id != ctx.firm_id or d.matter_id != matter_id:
            raise ValidationFailed("All documents must belong to the selected matter.", code="export_scope")
        docs.assert_servable(ctx.db.get(DocumentVersion, d.current_version_id))
    er = ExportRequest(firm_id=ctx.firm_id, matter_id=matter_id, requested_by=ctx.user.id, document_ids=[str(i) for i in ids], reason=reason.strip(),
                       status="pending_approval")
    ctx.db.add(er)
    ctx.db.flush()
    ap = approvals_svc.request_approval(ctx, kind="document_export", subject_type="export_request", subject_id=er.id, matter_id=matter_id,
                                        payload=_payload(ctx.db, matter_id, ids), required_permission="documents.export_approve")
    er.approval_id = ap.id
    ctx.audit("document.export_requested", "export_request", er.id, f"Export of {len(ids)} document(s) requested from {m.reference}", matter_id=matter_id,
              details={"count": len(ids)})
    return er


def get_export(ctx: Ctx, export_id: uuid.UUID) -> ExportRequest:
    er = ctx.db.get(ExportRequest, export_id)
    if not er or er.firm_id != ctx.firm_id:
        raise NotFound("Export not found.")
    docs._load_matter(ctx, er.matter_id)  # matter visibility still applies
    if er.requested_by != ctx.user.id and not ctx.has("documents.export_approve"):
        raise PermissionDenied("This export belongs to another user.")
    return er


def decide_export(ctx: Ctx, export_id: uuid.UUID, approve: bool, note: str | None) -> ExportRequest:
    ctx.require("documents.export_approve")
    er = get_export(ctx, export_id)
    if er.status != "pending_approval":
        raise InvalidState(f"Export is already '{er.status}'.")
    if approve and er.requested_by == ctx.user.id:
        raise PermissionDenied("Four-eyes control: you cannot approve your own export request.", code="four_eyes_required")
    ap = ctx.db.get(Approval, er.approval_id)
    approvals_svc.decide(ctx, ap.id, approve=approve, note=note)
    if approve:
        m = ctx.db.get(Matter, er.matter_id)
        if not can_export(ctx, m) and not (m.exports_allowed and ctx.has("documents.export_approve")):
            raise PermissionDenied("Exports are disabled for this matter.", code="export_blocked")
        er.status = "approved"
        enqueue(ctx.db, firm_id=ctx.firm_id, kind="build_export", payload={"export_id": str(er.id)}, idempotency_key=f"export:{er.id}")
    else:
        er.status = "rejected"
    ctx.db.flush()
    return er


@job_handler("build_export")
def build_export(db, job):
    er = db.get(ExportRequest, uuid.UUID(job.payload["export_id"]))
    if er.status not in ("approved", "building"):
        return {"skipped": er.status}
    ap = db.get(Approval, er.approval_id)
    ids = [uuid.UUID(i) for i in er.document_ids]
    if ap.status != "approved" or ap.payload_hash != canonical_hash(_payload(db, er.matter_id, ids)):
        er.status, er.error = "failed", "Documents changed after approval; a new export request and approval are required."
        return {"failed": "stale_approval"}
    er.status = "building"
    db.flush()
    m = db.get(Matter, er.matter_id)
    buf, manifest = io.BytesIO(), []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        used: set[str] = set()
        for did in ids:
            d = db.get(Document, did)
            v = db.get(DocumentVersion, d.current_version_id)
            if v.scan_status != "clean":
                er.status, er.error = "failed", f"'{d.title}' is not scanned clean."
                return {"failed": "scan"}
            data = get_storage().get(v.storage_key)
            name = filetypes.sanitise_filename(v.original_filename)
            if name in used:
                name = f"{v.version_no}-{d.id.hex[:6]}-{name}"
            used.add(name)
            z.writestr(name, data)
            manifest.append({"document_id": str(d.id), "title": d.title, "file": name, "version_no": v.version_no, "sha256": v.sha256, "size_bytes": v.size_bytes})
        z.writestr("MANIFEST.json", json.dumps({"export_id": str(er.id), "matter_reference": m.reference, "requested_by": str(er.requested_by),
                                                "generated_at": datetime.now(timezone.utc).isoformat(), "reason": er.reason, "documents": manifest}, indent=2))
    data = buf.getvalue()
    key = f"{er.firm_id}/exports/{er.id}.zip"
    get_storage().put(key, data, "application/zip")
    er.storage_key, er.sha256, er.status = key, sha256_hex(data), "ready"
    er.expires_at = datetime.now(timezone.utc) + EXPORT_TTL
    audit.log(db, firm_id=er.firm_id, action="document.export_built", entity_type="export_request", entity_id=er.id, matter_id=er.matter_id,
              summary=f"Export package built for {m.reference}", actor_type="system", details={"documents": len(ids), "sha256": er.sha256})
    notify(db, firm_id=er.firm_id, user_id=er.requested_by, kind="export_ready", title=f"Your export for {m.reference} is ready",
           link=f"/documents?export={er.id}", matter_id=er.matter_id)
    return {"documents": len(ids), "sha256": er.sha256}


def download_export(ctx: Ctx, export_id: uuid.UUID) -> tuple[ExportRequest, bytes]:
    er = get_export(ctx, export_id)
    if er.requested_by != ctx.user.id:
        raise PermissionDenied("Only the requester can download the export.")
    m = ctx.db.get(Matter, er.matter_id)
    if not can_export(ctx, m):
        raise PermissionDenied("Exports are not permitted for this matter.", code="export_blocked")
    if er.status != "ready":
        raise InvalidState(f"Export is '{er.status}', not ready.")
    if er.expires_at and er.expires_at < datetime.now(timezone.utc):
        er.status = "expired"
        ctx.db.flush()
        raise InvalidState("This export has expired; request a new one.", code="export_expired")
    data = get_storage().get(er.storage_key)
    er.download_count += 1
    ctx.audit("document.export_downloaded", "export_request", er.id, f"Export package downloaded ({m.reference})", matter_id=er.matter_id,
              details={"sha256": er.sha256, "documents": len(er.document_ids)})
    return er, data
