"""Correspondence: demonstration inbox, filing, drafts, approval-bound sending, internal notes.
E-mail bodies are UNTRUSTED text: stored and rendered as plain text only. Internal notes live in their own table and are
never part of any client-visible or outgoing representation."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import and_, false, func, or_, select

from app.deps import Ctx
from app.errors import ApprovalRequired, InvalidState, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.integrations import base as integrations
from app.integrations.email import OutboundEmail
from app.models import Approval, Correspondence, CorrespondenceAttachment, Document, DocumentVersion, IntegrationEvent, InternalNote, Matter
from app.permissions import can_access_matter, visible_matter_ids
from app.security import canonical_hash, sha256_hex
from app.services import approvals as approvals_svc
from app.services import documents as docs
from app.services import filetypes
from app.storage import get_storage


# ----------------------------------------------------------------------------------- access
def visible_clause(ctx: Ctx):
    if not ctx.has("correspondence.read") or ctx.role_key == "client":
        return false()
    return and_(Correspondence.firm_id == ctx.firm_id, or_(
        Correspondence.matter_id.in_(visible_matter_ids(ctx)),
        and_(Correspondence.matter_id.is_(None), or_(Correspondence.direction == "inbound", Correspondence.created_by == ctx.user.id))))


def get(ctx: Ctx, corr_id: uuid.UUID, *, write: bool = False, lock: bool = False) -> Correspondence:
    ctx.require("correspondence.write" if write else "correspondence.read")
    stmt = select(Correspondence).where(Correspondence.id == corr_id, Correspondence.firm_id == ctx.firm_id)
    if lock:
        stmt = stmt.with_for_update()
    c = ctx.db.execute(stmt).scalar_one_or_none()
    if not c:
        raise NotFound("Correspondence not found.")
    if c.matter_id:
        docs._load_matter(ctx, c.matter_id)
    elif c.direction == "outbound" and c.created_by != ctx.user.id:
        raise PermissionDenied("This draft belongs to another user.")
    return c


def attachments_of(db, corr_id) -> list[CorrespondenceAttachment]:
    return list(db.execute(select(CorrespondenceAttachment).where(CorrespondenceAttachment.correspondence_id == corr_id)
                           .order_by(CorrespondenceAttachment.filename)).scalars())


# ----------------------------------------------------------------------------------- inbound
def create_inbound(ctx: Ctx, *, from_addr: str, to_addrs: list[str], subject: str, body_text: str, received_at: datetime | None = None,
                   external_ref: str | None = None, matter_id: uuid.UUID | None = None, cc_addrs: list[str] | None = None,
                   thread_id: str | None = None, attachments: list[tuple[str, str, bytes]] | None = None,
                   client_visible: bool = False) -> tuple[Correspondence, bool]:
    """Record an inbound message (idempotent on external_ref). Returns (row, created). Attachments are (filename, content_type, bytes)."""
    ctx.require("correspondence.write")
    db = ctx.db
    if external_ref:
        ex = db.execute(select(Correspondence).where(Correspondence.firm_id == ctx.firm_id, Correspondence.external_ref == external_ref)).scalar_one_or_none()
        if ex:
            return ex, False
    if matter_id:
        docs._load_matter(ctx, matter_id)
    c = Correspondence(firm_id=ctx.firm_id, matter_id=matter_id, thread_id=thread_id, direction="inbound", channel="email", from_addr=from_addr[:254],
                       to_addrs=to_addrs, cc_addrs=cc_addrs or [], subject=subject[:500], body_text=body_text, status="filed" if matter_id else "received",
                       client_visible=client_visible, received_at=received_at or datetime.now(timezone.utc), external_ref=external_ref,
                       filed_by=ctx.user.id if matter_id else None, meta={"untrusted_content": True})
    db.add(c)
    db.flush()
    scanner = integrations.get("malware")
    for fn, ctype, data in attachments or []:
        fn = filetypes.sanitise_filename(fn)
        att = CorrespondenceAttachment(firm_id=ctx.firm_id, correspondence_id=c.id, filename=fn, content_type=ctype, size_bytes=len(data))
        try:
            _, real_type = filetypes.sniff(fn, data)
            att.content_type = real_type
            res = scanner.scan(data, fn)  # type: ignore[attr-defined]
            att.scan_status = res.status
            if res.status == "clean":
                key = f"{ctx.firm_id}/inbox/{c.id}/{sha256_hex(data)}-{uuid.uuid4().hex[:6]}"
                get_storage().put(key, data, real_type)
                att.storage_key = key
        except ValidationFailed:
            att.scan_status = "blocked"  # disallowed type: never stored
        db.add(att)
    db.flush()
    ctx.audit("correspondence.received", "correspondence", c.id, "Inbound e-mail recorded", matter_id=matter_id,
              details={"attachments": len(attachments or []), "external_ref": external_ref})
    return c, True


def sync_inbox(ctx: Ctx) -> dict:
    ctx.require("correspondence.write")
    provider = integrations.get_available("email")
    info = provider.info()
    created = skipped = 0
    for m in provider.fetch_inbound():  # type: ignore[attr-defined]
        _, was_new = create_inbound(ctx, from_addr=m.from_addr, to_addrs=m.to_addrs, cc_addrs=m.cc_addrs, subject=m.subject, body_text=m.body_text,
                                    received_at=m.received_at, external_ref=f"{info.provider}:{m.external_id}", thread_id=m.thread_id,
                                    attachments=[(a.filename, a.content_type, a.data) for a in m.attachments])
        created += was_new
        skipped += (not was_new)
    ctx.audit("correspondence.synced", "mailbox", None, f"Mailbox sync ({info.provider}): {created} new", details={"created": created, "skipped": skipped, "mode": info.mode})
    return {"created": created, "skipped": skipped, "provider": info.provider, "mode": info.mode,
            "notice": "SIMULATED mailbox: these are synthetic demonstration e-mails." if info.mode == "mock" else ""}


def file_to_matter(ctx: Ctx, corr_id: uuid.UUID, matter_id: uuid.UUID) -> dict:
    ctx.require("correspondence.write")
    c = get(ctx, corr_id, write=True, lock=True)
    if c.matter_id and c.matter_id != matter_id and c.status in ("sent",):
        raise InvalidState("A sent message cannot be re-filed.")
    matter = docs._load_matter(ctx, matter_id)
    c.matter_id, c.status = matter.id, ("filed" if c.direction == "inbound" else c.status)
    c.filed_by = ctx.user.id
    for n in ctx.db.execute(select(InternalNote).where(InternalNote.correspondence_id == c.id, InternalNote.matter_id.is_(None))).scalars():
        n.matter_id = matter.id
    filed, skipped = [], []
    for att in attachments_of(ctx.db, c.id):
        if att.document_id:
            continue
        if att.scan_status != "clean" or not att.storage_key:
            skipped.append({"filename": att.filename, "reason": f"scan_status={att.scan_status}"})
            continue
        if not ctx.has("documents.write"):
            skipped.append({"filename": att.filename, "reason": "no documents.write permission"})
            continue
        data = get_storage().get(att.storage_key)
        doc, _ = docs.upload_document(ctx, matter_id=matter.id, title=att.filename, doc_type="email_attachment", filename=att.filename, content=data,
                                      source="email_attachment", change_note=f"Attachment of e-mail '{c.subject[:80]}'")
        att.document_id = doc.id
        filed.append({"filename": att.filename, "document_id": str(doc.id)})
    ctx.audit("correspondence.filed", "correspondence", c.id, f"E-mail filed to {matter.reference}", matter_id=matter.id,
              details={"documents_created": len(filed), "skipped": len(skipped)})
    return {"filed_documents": filed, "skipped_attachments": skipped}


# ----------------------------------------------------------------------------------- drafts & sending
def content_hash(db, c: Correspondence) -> str:
    atts = []
    for a in attachments_of(db, c.id):
        sha = None
        if a.document_id:
            d = db.get(Document, a.document_id)
            v = db.get(DocumentVersion, d.current_version_id) if d and d.current_version_id else None
            sha = v.sha256 if v else None
        atts.append({"document_id": str(a.document_id) if a.document_id else None, "filename": a.filename, "sha256": sha})
    return canonical_hash({"matter_id": str(c.matter_id) if c.matter_id else None, "to": sorted(c.to_addrs), "cc": sorted(c.cc_addrs or []),
                           "subject": c.subject, "body": c.body_text, "attachments": atts, "client_visible": c.client_visible})


def _approval_payload(db, c: Correspondence) -> dict:
    return {"content_hash": content_hash(db, c), "recipient_count": len(c.to_addrs) + len(c.cc_addrs or []), "matter_id": str(c.matter_id) if c.matter_id else None}


def _validate_addrs(addrs: list[str]) -> list[str]:
    out = [a.strip() for a in addrs if a and a.strip()]
    if any("@" not in a or " " in a.split("<")[-1].strip(">") for a in out):
        raise ValidationFailed("Invalid e-mail address.")
    return out


def create_draft(ctx: Ctx, *, matter_id: uuid.UUID | None, subject: str, body_text: str, to_addrs: list[str], cc_addrs: list[str] | None = None,
                 reply_to_id: uuid.UUID | None = None, client_visible: bool = False, agent_run_id: uuid.UUID | None = None,
                 attachment_document_ids: list[uuid.UUID] | None = None) -> Correspondence:
    ctx.require("correspondence.write")
    if matter_id:
        docs._load_matter(ctx, matter_id)
    thread = None
    if reply_to_id:
        parent = get(ctx, reply_to_id)
        thread = parent.thread_id
        matter_id = matter_id or parent.matter_id
    if not subject.strip():
        raise ValidationFailed("A subject is required.")
    c = Correspondence(firm_id=ctx.firm_id, matter_id=matter_id, thread_id=thread, direction="outbound", channel="email", from_addr=ctx.user.email,
                       to_addrs=_validate_addrs(to_addrs), cc_addrs=_validate_addrs(cc_addrs or []), subject=subject.strip()[:500], body_text=body_text,
                       status="draft", client_visible=client_visible, created_by=ctx.user.id, agent_run_id=agent_run_id)
    ctx.db.add(c)
    ctx.db.flush()
    for did in attachment_document_ids or []:
        d = docs.get_document(ctx, did)
        if matter_id and d.matter_id != matter_id:
            raise ValidationFailed("Attachments must belong to the same matter.")
        v = ctx.db.get(DocumentVersion, d.current_version_id)
        ctx.db.add(CorrespondenceAttachment(firm_id=ctx.firm_id, correspondence_id=c.id, document_id=d.id, filename=v.original_filename,
                                            content_type=v.content_type, size_bytes=v.size_bytes, scan_status=v.scan_status))
    ctx.db.flush()
    ctx.audit("correspondence.draft_created", "correspondence", c.id, "Draft message created", matter_id=matter_id,
              details={"agent_run_id": str(agent_run_id) if agent_run_id else None, "recipients": len(c.to_addrs)})
    return c


def update_draft(ctx: Ctx, corr_id: uuid.UUID, data: dict, expected_version: int) -> Correspondence:
    c = get(ctx, corr_id, write=True, lock=True)
    if c.direction != "outbound" or c.status not in ("draft", "pending_approval", "approved"):
        raise InvalidState("Only unsent drafts can be edited.")
    if c.version != expected_version:
        raise VersionConflict("This draft was changed by someone else. Reload and try again.", details={"current_version": c.version})
    before = content_hash(ctx.db, c)
    for k in ("subject", "body_text", "client_visible"):
        if data.get(k) is not None:
            setattr(c, k, data[k])
    if data.get("to_addrs") is not None:
        c.to_addrs = _validate_addrs(data["to_addrs"])
    if data.get("cc_addrs") is not None:
        c.cc_addrs = _validate_addrs(data["cc_addrs"])
    if data.get("matter_id") is not None and data["matter_id"] != c.matter_id:
        docs._load_matter(ctx, data["matter_id"])
        c.matter_id = data["matter_id"]
    ctx.db.flush()
    invalidated = False
    if content_hash(ctx.db, c) != before and c.status in ("pending_approval", "approved"):
        for ap in ctx.db.execute(select(Approval).where(Approval.subject_type == "correspondence", Approval.subject_id == c.id,
                                                        Approval.status.in_(["pending", "approved"]))).scalars():
            ap.status = "superseded"
        c.status, c.approval_id, c.approved_hash, invalidated = "draft", None, None, True
    ctx.audit("correspondence.draft_edited", "correspondence", c.id, "Draft message edited", matter_id=c.matter_id, details={"approval_invalidated": invalidated})
    return c


def request_approval(ctx: Ctx, corr_id: uuid.UUID) -> Correspondence:
    c = get(ctx, corr_id, write=True, lock=True)
    if c.direction != "outbound" or c.status != "draft":
        raise InvalidState(f"Only drafts can be submitted for approval (status is '{c.status}').")
    if not c.to_addrs:
        raise ValidationFailed("Add at least one recipient before requesting approval.")
    ap = approvals_svc.request_approval(ctx, kind="correspondence_send", subject_type="correspondence", subject_id=c.id, matter_id=c.matter_id,
                                        payload=_approval_payload(ctx.db, c), required_permission="correspondence.approve")
    c.status, c.approval_id = "pending_approval", ap.id
    ctx.audit("correspondence.approval_requested", "correspondence", c.id, "Approval requested to send message", matter_id=c.matter_id)
    return c


def decide(ctx: Ctx, corr_id: uuid.UUID, approve: bool, note: str | None) -> Correspondence:
    ctx.require("correspondence.approve")
    c = get(ctx, corr_id, write=True, lock=True)
    if c.status != "pending_approval":
        raise InvalidState(f"Message is '{c.status}', not awaiting approval.")
    ap = ctx.db.get(Approval, c.approval_id)
    if approve and ap.payload_hash != canonical_hash(_approval_payload(ctx.db, c)):
        ap.status = "superseded"
        c.status, c.approval_id = "draft", None
        ctx.db.flush()
        raise ApprovalRequired("The message changed after approval was requested; request approval again.", code="approval_stale")
    approvals_svc.decide(ctx, ap.id, approve=approve, note=note)
    if approve:
        c.status, c.approved_hash = "approved", content_hash(ctx.db, c)
    else:
        c.status, c.approval_id = "draft", None
    return c


def send(ctx: Ctx, corr_id: uuid.UUID) -> Correspondence:
    ctx.require("correspondence.write")
    c = get(ctx, corr_id, write=True, lock=True)  # row lock: concurrent duplicate sends serialise here
    if c.status == "sent":
        raise InvalidState("This message has already been sent.", code="already_sent")
    if c.status != "approved":
        raise ApprovalRequired("This message must be approved before it can be sent.")
    approvals_svc.assert_approved(ctx, c.approval_id, kind="correspondence_send", payload=_approval_payload(ctx.db, c), subject_id=c.id)
    provider = integrations.get_available("email")
    info = provider.info()
    atts = []
    for a in attachments_of(ctx.db, c.id):
        if a.document_id:
            d = ctx.db.get(Document, a.document_id)
            v = ctx.db.get(DocumentVersion, d.current_version_id)
            docs.assert_servable(v)
            atts.append((a.filename, get_storage().get(v.storage_key)))
    res = provider.send(OutboundEmail(to_addrs=c.to_addrs, cc_addrs=c.cc_addrs or [], subject=c.subject, body_text=c.body_text, attachments=atts))  # type: ignore[attr-defined]
    c.status, c.sent_at, c.external_ref = "sent", datetime.now(timezone.utc), res.message_id
    c.meta = {**(c.meta or {}), "simulated": info.mode == "mock", "provider": info.provider}
    ctx.db.add(IntegrationEvent(firm_id=ctx.firm_id, integration="email", provider=info.provider, mode=info.mode, kind="send",
                                payload={"correspondence_id": str(c.id), "recipients": len(c.to_addrs) + len(c.cc_addrs or []), "message_id": res.message_id,
                                         "attachments": len(atts)}, status="ok"))
    ctx.audit("correspondence.sent", "correspondence", c.id, f"Message sent via {info.provider}" + (" (SIMULATED)" if info.mode == "mock" else ""),
              matter_id=c.matter_id, details={"recipients": len(c.to_addrs), "approval_id": str(c.approval_id), "simulated": info.mode == "mock"})
    ctx.db.flush()
    return c


# ----------------------------------------------------------------------------------- internal notes & client view
def add_note(ctx: Ctx, *, body: str, matter_id: uuid.UUID | None = None, correspondence_id: uuid.UUID | None = None) -> InternalNote:
    ctx.require("correspondence.write")
    if not body.strip():
        raise ValidationFailed("A note cannot be empty.")
    if correspondence_id:
        c = get(ctx, correspondence_id)
        matter_id = matter_id or c.matter_id
    elif matter_id:
        docs._load_matter(ctx, matter_id)
    else:
        raise ValidationFailed("A note must be attached to a matter or a message.")
    n = InternalNote(firm_id=ctx.firm_id, matter_id=matter_id, correspondence_id=correspondence_id, author_id=ctx.user.id, body=body.strip())
    ctx.db.add(n)
    ctx.db.flush()
    ctx.audit("note.added", "internal_note", n.id, "Internal note added", matter_id=matter_id)
    return n


def list_notes(ctx: Ctx, *, matter_id: uuid.UUID | None = None, correspondence_id: uuid.UUID | None = None) -> list[InternalNote]:
    ctx.require("correspondence.read")
    stmt = select(InternalNote).where(InternalNote.firm_id == ctx.firm_id).order_by(InternalNote.created_at.desc())
    if correspondence_id:
        get(ctx, correspondence_id)
        stmt = stmt.where(InternalNote.correspondence_id == correspondence_id)
    elif matter_id:
        docs._load_matter(ctx, matter_id)
        stmt = stmt.where(InternalNote.matter_id == matter_id)
    else:
        raise ValidationFailed("matter_id or correspondence id is required.")
    return list(ctx.db.execute(stmt).scalars())


def client_visible_items(db, firm_id, matter_id) -> list[Correspondence]:
    """What an authorised client may see: only client-visible messages that have actually been sent (outbound) or received (inbound).
    No drafts, no internal notes, no approval data. Used by the staff 'client view' preview and by the client portal."""
    return list(db.execute(select(Correspondence).where(
        Correspondence.firm_id == firm_id, Correspondence.matter_id == matter_id, Correspondence.client_visible.is_(True),
        or_(Correspondence.status == "sent", and_(Correspondence.direction == "inbound", Correspondence.status.in_(["filed", "received"])))
    ).order_by(func.coalesce(Correspondence.sent_at, Correspondence.received_at).desc())).scalars())
