"""Matter management: creation from templates, access control (restricted / ethical walls), the explicit state machine,
checklists, legal hold, retention and chronology."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, select, text, update

from app import enums
from app.deps import Ctx
from app.errors import (ApprovalRequired, InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed, VersionConflict)
from app.models import (Approval, AuditEvent, ChronologyEntry, Contact, Deadline, Document, Expense, Firm, JournalLine, LedgerAccount, Journal, Matter,
                        MatterChecklistItem, MatterMember, MatterParty, MatterStateEvent, MatterTemplate, Office, RetentionPolicy, Task, Team, TimeEntry, User)
from app.permissions import can_access_matter, matter_clause
from app.services import approvals as approvals_svc
from app.services import conflicts as conflicts_svc
from app.services.contacts import user_names
from app.services.notify import notify

AREA3 = {"commercial": "COM", "property": "PRO", "litigation": "LIT", "employment": "EMP", "private_client": "PVC", "corporate": "COR"}
PATCHABLE = ["title", "description", "matter_type", "office_id", "team_id", "responsible_partner_id", "fee_earner_id", "jurisdiction", "target_date",
             "fee_arrangement", "fixed_fee_amount", "budget_amount", "custom_fields", "conflict_search_id"]


# --------------------------------------------------------------------------- lookup & access
def get_matter(ctx: Ctx, matter_id: uuid.UUID, *, for_update: bool = False) -> Matter:
    """404 for unknown/other-firm ids, 403 `matter_access_denied` for matters in this firm the user may not access."""
    stmt = select(Matter).where(Matter.id == matter_id)
    if for_update:
        stmt = stmt.with_for_update()
    m = ctx.db.execute(stmt).scalar_one_or_none()
    if not m or m.firm_id != ctx.firm_id:
        raise NotFound("Matter not found.")
    if not can_access_matter(ctx, m):
        raise MatterAccessDenied("You do not have access to this matter.")
    return m


def _check_version(m: Matter, expected: int) -> None:
    if m.version != expected:
        raise VersionConflict("This matter was changed by someone else. Reload and try again.")


def _staff(ctx: Ctx, uid: uuid.UUID | None, label: str) -> User:
    u = ctx.db.get(User, uid) if uid else None
    if not u or u.firm_id != ctx.firm_id or not u.is_active:
        raise ValidationFailed(f"{label} not found in this firm.")
    return u


def _add_years(d: date, years: int) -> date:
    try:
        return d.replace(year=d.year + years)
    except ValueError:  # 29 Feb
        return d.replace(year=d.year + years, day=28)


def compute_retention_until(ctx: Ctx, policy_key: str | None, closed_at: date | None) -> date | None:
    if not policy_key or not closed_at:
        return None
    pol = ctx.db.execute(select(RetentionPolicy).where(RetentionPolicy.firm_id == ctx.firm_id, RetentionPolicy.key == policy_key, RetentionPolicy.is_active.is_(True))).scalar_one_or_none()
    if not pol:
        raise ValidationFailed(f"Retention policy '{policy_key}' not found or inactive.")
    return _add_years(closed_at, pol.years)


# --------------------------------------------------------------------------- creation
def _next_reference(ctx: Ctx, practice_area: str) -> str:
    firm = ctx.db.get(Firm, ctx.firm_id)
    prefix = (firm.settings or {}).get("client_reference_prefix", "PCS")
    year = date.today().year
    ctx.db.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": f"matterref:{ctx.firm_id}"})
    stem = f"{prefix}-{AREA3.get(practice_area, 'GEN')}-{year}-"
    refs = ctx.db.execute(select(Matter.reference).where(Matter.firm_id == ctx.firm_id, Matter.reference.like(stem + "%"))).scalars().all()
    nums = [int(r[len(stem):]) for r in refs if r[len(stem):].isdigit()]
    return f"{stem}{(max(nums) if nums else 0) + 1:04d}"


def create_matter(ctx: Ctx, *, title: str, client_id: uuid.UUID, responsible_partner_id: uuid.UUID, template_id: uuid.UUID | None = None,
                  fee_earner_id: uuid.UUID | None = None, matter_type: str | None = None, practice_area: str | None = None, description: str | None = None,
                  office_id: uuid.UUID | None = None, team_id: uuid.UUID | None = None, jurisdiction: str = "england_and_wales", target_date: date | None = None,
                  fee_arrangement: str | None = None, fixed_fee_amount: Decimal | None = None, budget_amount: Decimal | None = None,
                  retention_policy_key: str | None = None, access_level: str = "standard", custom_fields: dict | None = None,
                  conflict_search_id: uuid.UUID | None = None) -> Matter:
    """Creates a PROSPECTIVE matter (opening requires the explicit state transition)."""
    ctx.require("matters.create")
    db = ctx.db
    client = db.get(Contact, client_id)
    if not client or client.firm_id != ctx.firm_id or client.status == "merged":
        raise ValidationFailed("Client contact not found.")
    partner = _staff(ctx, responsible_partner_id, "Responsible partner")
    fee_earner = _staff(ctx, fee_earner_id or ctx.user.id, "Fee earner")
    tpl = None
    if template_id:
        tpl = db.get(MatterTemplate, template_id)
        if not tpl or tpl.firm_id != ctx.firm_id or not tpl.is_active:
            raise ValidationFailed("Matter template not found or inactive.")
    practice_area = practice_area or (tpl.practice_area if tpl else None)
    if practice_area not in enums.PRACTICE_AREAS:
        raise ValidationFailed("A valid practice area (or template) is required.", details={"allowed": enums.PRACTICE_AREAS})
    if access_level == "restricted":
        ctx.require("matters.access_admin")
    office = office_id or partner.office_id or ctx.user.office_id
    if not office or not db.get(Office, office) or db.get(Office, office).firm_id != ctx.firm_id:
        raise ValidationFailed("An office is required.")
    if team_id:
        t = db.get(Team, team_id)
        if not t or t.firm_id != ctx.firm_id:
            raise ValidationFailed("Team not found.")
    if retention_policy_key is None and tpl:
        retention_policy_key = tpl.default_retention_key
    m = Matter(firm_id=ctx.firm_id, reference=_next_reference(ctx, practice_area), title=title, matter_type=matter_type or (tpl.matter_type if tpl else "General"),
               practice_area=practice_area, description=description, client_id=client.id, office_id=office, team_id=team_id or partner.team_id,
               responsible_partner_id=partner.id, fee_earner_id=fee_earner.id, jurisdiction=jurisdiction, status="prospective",
               stage=(tpl.stages[0]["key"] if tpl and tpl.stages else None), target_date=target_date, template_id=tpl.id if tpl else None,
               access_level=access_level, fee_arrangement=fee_arrangement or (tpl.default_fee_arrangement if tpl else "hourly"),
               fixed_fee_amount=fixed_fee_amount, budget_amount=budget_amount, retention_policy_key=retention_policy_key,
               custom_fields=custom_fields or {}, conflict_search_id=None)
    db.add(m)
    db.flush()
    db.add(MatterParty(firm_id=ctx.firm_id, matter_id=m.id, contact_id=client.id, role="client"))
    if access_level == "restricted":
        for uid in {partner.id, fee_earner.id, ctx.user.id}:
            db.add(MatterMember(firm_id=ctx.firm_id, matter_id=m.id, user_id=uid, access="allow", member_role="lead" if uid == partner.id else "team",
                                reason="Initial access list on creation of restricted matter", added_by=ctx.user.id))
    if tpl:
        for i, it in enumerate(tpl.opening_checklist):
            db.add(MatterChecklistItem(firm_id=ctx.firm_id, matter_id=m.id, phase="opening", label=it["label"], required=it.get("required", True), position=i))
        for i, it in enumerate(tpl.closing_checklist):
            db.add(MatterChecklistItem(firm_id=ctx.firm_id, matter_id=m.id, phase="closing", label=it["label"], required=it.get("required", True), position=i))
        for t in tpl.default_tasks:
            db.add(Task(firm_id=ctx.firm_id, matter_id=m.id, title=t["title"], assignee_id=fee_earner.id, created_by=ctx.user.id,
                        due_at=datetime.now(timezone.utc) + timedelta(days=int(t.get("due_in_days", 7))), source="template"))
    db.flush()
    if conflict_search_id:
        link_conflict_search(ctx, m, conflict_search_id)
    ctx.audit("matter.created", "matter", m.id, f"Matter {m.reference} created (prospective)", matter_id=m.id,
              details={"reference": m.reference, "practice_area": practice_area, "access_level": access_level, "template": tpl.name if tpl else None})
    return m


def link_conflict_search(ctx: Ctx, m: Matter, search_id: uuid.UUID) -> None:
    s = conflicts_svc.get_search(ctx, search_id)
    m.conflict_search_id = s.id
    ctx.db.flush()


def update_matter(ctx: Ctx, matter: Matter, data: dict, expected_version: int) -> Matter:
    ctx.require("matters.write")
    _check_version(matter, expected_version)
    if matter.status == "closed":
        raise InvalidState("A closed matter cannot be edited; reopen it first.", code="matter_closed")
    changed = []
    for k in PATCHABLE:
        if k in data and (data[k] is not None or k in ("target_date", "team_id", "description")):
            v = data[k]
            if getattr(matter, k) == v:
                continue
            if k == "responsible_partner_id":
                _staff(ctx, v, "Responsible partner")
            elif k == "fee_earner_id":
                _staff(ctx, v, "Fee earner")
            elif k == "office_id" and (not ctx.db.get(Office, v) or ctx.db.get(Office, v).firm_id != ctx.firm_id):
                raise ValidationFailed("Office not found.")
            elif k == "conflict_search_id":
                conflicts_svc.get_search(ctx, v)
            setattr(matter, k, v)
            changed.append(k)
    ctx.db.flush()
    ctx.audit("matter.updated", "matter", matter.id, f"Matter {matter.reference} updated", matter_id=matter.id, details={"fields": changed})
    return matter


def set_stage(ctx: Ctx, matter: Matter, stage: str, expected_version: int) -> Matter:
    ctx.require("matters.write")
    _check_version(matter, expected_version)
    if matter.status == "closed":
        raise InvalidState("A closed matter's stage cannot be changed.", code="matter_closed")
    if matter.template_id:
        tpl = ctx.db.get(MatterTemplate, matter.template_id)
        keys = [s["key"] for s in (tpl.stages or [])]
        if keys and stage not in keys:
            raise ValidationFailed("Stage is not defined in this matter's template.", details={"allowed": keys})
    prev, matter.stage = matter.stage, stage
    ctx.db.flush()
    ctx.audit("matter.stage_changed", "matter", matter.id, f"Stage changed to {stage}", matter_id=matter.id, details={"from": prev, "to": stage})
    return matter


# --------------------------------------------------------------------------- parties
def add_party(ctx: Ctx, matter: Matter, contact_id: uuid.UUID, role: str, notes: str | None) -> MatterParty:
    ctx.require("matters.write")
    c = ctx.db.get(Contact, contact_id)
    if not c or c.firm_id != ctx.firm_id or c.status == "merged":
        raise ValidationFailed("Contact not found.")
    if role not in enums.PARTY_ROLES:
        raise ValidationFailed("Unknown party role.", details={"allowed": enums.PARTY_ROLES})
    if ctx.db.execute(select(MatterParty.id).where(MatterParty.matter_id == matter.id, MatterParty.contact_id == c.id, MatterParty.role == role)).first():
        raise ValidationFailed("That contact already holds this role on the matter.", code="duplicate_party")
    p = MatterParty(firm_id=ctx.firm_id, matter_id=matter.id, contact_id=c.id, role=role, notes=notes)
    ctx.db.add(p)
    ctx.db.flush()
    ctx.audit("matter.party_added", "matter", matter.id, f"{c.display_name} added as {role}", matter_id=matter.id, details={"contact": str(c.id), "role": role})
    return p


def remove_party(ctx: Ctx, matter: Matter, party_id: uuid.UUID) -> None:
    ctx.require("matters.write")
    p = ctx.db.get(MatterParty, party_id)
    if not p or p.matter_id != matter.id or p.firm_id != ctx.firm_id:
        raise NotFound("Party not found.")
    if p.role == "client" and p.contact_id == matter.client_id:
        raise InvalidState("The matter's client cannot be removed; change the client instead.", code="client_party_required")
    ctx.db.delete(p)
    ctx.audit("matter.party_removed", "matter", matter.id, "Party removed", matter_id=matter.id, details={"contact": str(p.contact_id), "role": p.role})


# --------------------------------------------------------------------------- access control
def add_member(ctx: Ctx, matter: Matter, *, user_id=None, team_id=None, access: str = "allow", member_role: str | None = None, reason: str) -> MatterMember:
    ctx.require("matters.access_admin")
    if bool(user_id) == bool(team_id):
        raise ValidationFailed("Provide exactly one of user_id or team_id.")
    if team_id and access != "deny":
        raise ValidationFailed("Teams can only be added as ethical-wall exclusions (deny).")
    if user_id:
        _staff(ctx, user_id, "User")
    else:
        t = ctx.db.get(Team, team_id)
        if not t or t.firm_id != ctx.firm_id:
            raise ValidationFailed("Team not found.")
    existing = ctx.db.execute(select(MatterMember).where(MatterMember.matter_id == matter.id, MatterMember.user_id == user_id, MatterMember.team_id == team_id,
                                                         MatterMember.access == access)).scalars().first()
    if existing:
        raise ValidationFailed("That access entry already exists.", code="duplicate_member")
    mm = MatterMember(firm_id=ctx.firm_id, matter_id=matter.id, user_id=user_id, team_id=team_id, access=access, member_role=member_role, reason=reason, added_by=ctx.user.id)
    ctx.db.add(mm)
    ctx.db.flush()
    ctx.audit("matter.access_changed", "matter", matter.id, f"Access {access} entry added", matter_id=matter.id,
              details={"change": "add", "access": access, "user_id": str(user_id) if user_id else None, "team_id": str(team_id) if team_id else None, "reason": reason})
    return mm


def remove_member(ctx: Ctx, matter: Matter, member_id: uuid.UUID, reason: str | None = None) -> None:
    ctx.require("matters.access_admin")
    mm = ctx.db.get(MatterMember, member_id)
    if not mm or mm.matter_id != matter.id or mm.firm_id != ctx.firm_id:
        raise NotFound("Access entry not found.")
    if mm.access == "allow" and mm.user_id == ctx.user.id and matter.access_level == "restricted" \
            and matter.responsible_partner_id != ctx.user.id and matter.fee_earner_id != ctx.user.id:
        raise InvalidState("You cannot remove your own access to a restricted matter.")
    ctx.db.delete(mm)
    ctx.audit("matter.access_changed", "matter", matter.id, f"Access {mm.access} entry removed", matter_id=matter.id,
              details={"change": "remove", "access": mm.access, "user_id": str(mm.user_id) if mm.user_id else None,
                       "team_id": str(mm.team_id) if mm.team_id else None, "reason": reason})


def set_access(ctx: Ctx, matter: Matter, *, access_level: str, ethical_wall: bool, exports_allowed: bool, ai_retrieval_allowed: bool, reason: str,
               expected_version: int) -> Matter:
    ctx.require("matters.access_admin")
    _check_version(matter, expected_version)
    if ethical_wall and access_level != "restricted":
        raise ValidationFailed("An ethical wall requires the matter to be restricted.")
    before = {"access_level": matter.access_level, "ethical_wall": matter.ethical_wall, "exports_allowed": matter.exports_allowed, "ai": matter.ai_retrieval_allowed}
    if access_level == "restricted" and matter.access_level == "standard":
        for uid in {matter.responsible_partner_id, matter.fee_earner_id, ctx.user.id}:
            if not ctx.db.execute(select(MatterMember.id).where(MatterMember.matter_id == matter.id, MatterMember.user_id == uid, MatterMember.access == "allow")).first():
                ctx.db.add(MatterMember(firm_id=ctx.firm_id, matter_id=matter.id, user_id=uid, access="allow", reason="Added when matter was restricted", added_by=ctx.user.id))
    matter.access_level, matter.ethical_wall = access_level, ethical_wall
    matter.exports_allowed, matter.ai_retrieval_allowed = exports_allowed, ai_retrieval_allowed
    ctx.db.flush()
    ctx.audit("matter.access_changed", "matter", matter.id, f"Matter access settings changed ({access_level}{', ethical wall' if ethical_wall else ''})", matter_id=matter.id,
              details={"change": "settings", "before": before, "after": {"access_level": access_level, "ethical_wall": ethical_wall, "exports_allowed": exports_allowed,
                                                                         "ai": ai_retrieval_allowed}, "reason": reason})
    return matter


# --------------------------------------------------------------------------- checklist, legal hold, retention
def toggle_checklist(ctx: Ctx, matter: Matter, item_id: uuid.UUID, completed: bool, note: str | None) -> MatterChecklistItem:
    ctx.require("matters.write")
    it = ctx.db.get(MatterChecklistItem, item_id)
    if not it or it.matter_id != matter.id or it.firm_id != ctx.firm_id:
        raise NotFound("Checklist item not found.")
    it.completed_at = datetime.now(timezone.utc) if completed else None
    it.completed_by = ctx.user.id if completed else None
    if note is not None:
        it.note = note
    ctx.db.flush()
    ctx.audit("matter.checklist_updated", "matter", matter.id, f"Checklist item {'completed' if completed else 'reopened'}: {it.label[:80]}", matter_id=matter.id)
    return it


def add_checklist_item(ctx: Ctx, matter: Matter, phase: str, label: str, required: bool) -> MatterChecklistItem:
    ctx.require("matters.write")
    pos = ctx.db.execute(select(func.coalesce(func.max(MatterChecklistItem.position), -1) + 1).where(MatterChecklistItem.matter_id == matter.id, MatterChecklistItem.phase == phase)).scalar_one()
    it = MatterChecklistItem(firm_id=ctx.firm_id, matter_id=matter.id, phase=phase, label=label, required=required, position=pos)
    ctx.db.add(it)
    ctx.db.flush()
    ctx.audit("matter.checklist_item_added", "matter", matter.id, f"Checklist item added ({phase})", matter_id=matter.id)
    return it


def set_legal_hold(ctx: Ctx, matter: Matter, active: bool, reason: str) -> Matter:
    ctx.require("matters.approve")
    matter.legal_hold = active
    matter.legal_hold_reason = reason if active else None
    ctx.db.execute(update(Document).where(Document.matter_id == matter.id).values(legal_hold=active))
    ctx.db.flush()
    ctx.audit("matter.legal_hold_set" if active else "matter.legal_hold_cleared", "matter", matter.id,
              f"Legal hold {'applied' if active else 'released'} on {matter.reference}", matter_id=matter.id, details={"reason": reason})
    return matter


def set_retention(ctx: Ctx, matter: Matter, policy_key: str) -> Matter:
    ctx.require("matters.write")
    until = compute_retention_until(ctx, policy_key, matter.closed_at)
    matter.retention_policy_key, matter.retention_until = policy_key, until
    ctx.db.flush()
    ctx.audit("matter.retention_set", "matter", matter.id, f"Retention policy set: {policy_key}", matter_id=matter.id,
              details={"policy": policy_key, "retention_until": until.isoformat() if until else None})
    return matter


# --------------------------------------------------------------------------- finance helpers (lazy / graceful)
def wip(db, matter_id: uuid.UUID) -> dict:
    try:
        from app.services.matter_finance import unbilled_wip
        return unbilled_wip(db, matter_id)
    except ModuleNotFoundError:
        pass
    t = db.execute(select(func.coalesce(func.sum(TimeEntry.amount), 0), func.count(TimeEntry.id)).where(
        TimeEntry.matter_id == matter_id, TimeEntry.billable.is_(True), TimeEntry.invoice_line_id.is_(None), TimeEntry.status.in_(["draft", "submitted", "approved"]))).one()
    e = db.execute(select(func.coalesce(func.sum(Expense.amount), 0), func.count(Expense.id)).where(
        Expense.matter_id == matter_id, Expense.billable.is_(True), Expense.invoice_line_id.is_(None), Expense.status.in_(["draft", "approved"]))).one()
    return {"time": Decimal(t[0]), "expenses": Decimal(e[0]), "count": t[1] + e[1]}


def client_balance(db, matter_id: uuid.UUID) -> Decimal:
    try:
        from app.services.matter_finance import client_balance as cb
        return Decimal(cb(db, matter_id))
    except ModuleNotFoundError:
        pass
    r = db.execute(select(func.coalesce(func.sum(JournalLine.credit - JournalLine.debit), 0)).select_from(JournalLine)
                   .join(Journal, Journal.id == JournalLine.journal_id).join(LedgerAccount, LedgerAccount.id == JournalLine.account_id)
                   .where(LedgerAccount.matter_id == matter_id, LedgerAccount.ledger == "client", Journal.status.in_(["posted", "reversed"]))).scalar_one()
    return Decimal(r)


# --------------------------------------------------------------------------- state machine
def transition_blockers(ctx: Ctx, m: Matter, to_status: str, retention_key: str | None = None) -> list[dict]:
    db, b = ctx.db, []
    items = db.execute(select(MatterChecklistItem).where(MatterChecklistItem.matter_id == m.id)).scalars().all()
    if m.status == "prospective" and to_status == "open":
        s = conflicts_svc.cleared_search_for_matter(ctx, m)
        if not s:
            b.append({"code": "conflict_not_cleared", "message": "A conflict search linked to this matter or its client must be cleared by an authorised human reviewer."})
        from app.services import onboarding as ob
        client = db.get(Contact, m.client_id)
        rec = ob.get_record(ctx, client)
        if not rec or rec.status != "approved":
            b.append({"code": "onboarding_incomplete", "message": "Client onboarding has not been approved."})
        for it in items:
            if it.phase == "opening" and it.required and not it.completed_at:
                b.append({"code": "opening_checklist", "message": f"Required opening item outstanding: {it.label}"})
        if m.template_id:
            tpl = db.get(MatterTemplate, m.template_id)
            for f in tpl.required_fields or []:
                v = getattr(m, f, None) if hasattr(Matter, f) else (m.custom_fields or {}).get(f)
                if v in (None, "", [], {}):
                    b.append({"code": "required_field_missing", "message": f"Required information missing: {f}", "field": f})
    if to_status == "closed":
        for it in items:
            if it.phase == "closing" and it.required and not it.completed_at:
                b.append({"code": "closing_checklist", "message": f"Required closing item outstanding: {it.label}"})
        if m.legal_hold:
            b.append({"code": "legal_hold", "message": "The matter is under legal hold and cannot be closed."})
        w = wip(db, m.id)
        if w["count"] > 0 or Decimal(w["time"]) + Decimal(w["expenses"]) > 0:
            b.append({"code": "unbilled_wip", "message": f"Unbilled time/expenses remain ({w['count']} entries).", "amount": str(Decimal(w['time']) + Decimal(w['expenses']))})
        bal = client_balance(db, m.id)
        if bal != 0:
            b.append({"code": "client_balance", "message": f"Client ledger balance is {bal} GBP; it must be zero before closure.", "amount": str(bal)})
        key = retention_key or m.retention_policy_key
        if not key:
            b.append({"code": "retention_policy_missing", "message": "Choose a retention policy before closing."})
        elif not db.execute(select(RetentionPolicy.id).where(RetentionPolicy.firm_id == ctx.firm_id, RetentionPolicy.key == key, RetentionPolicy.is_active.is_(True))).first():
            b.append({"code": "retention_policy_invalid", "message": f"Retention policy '{key}' not found."})
    return b


def _payload(m: Matter, to_status: str, reason: str | None, retention_key: str | None) -> dict:
    return {"matter_id": str(m.id), "from": m.status, "to": to_status, "matter_version": m.version, "reason": reason or "", "retention_policy_key": retention_key or ""}


def _validate_request(m: Matter, to_status: str, reason: str | None) -> None:
    allowed = enums.MATTER_TRANSITIONS.get(m.status, [])
    if to_status not in allowed:
        raise InvalidState(f"A {m.status} matter cannot move to {to_status}. Allowed: {', '.join(allowed) or 'none'}.", code="invalid_transition",
                           details={"from": m.status, "to": to_status, "allowed": allowed})
    needs_reason = (m.status == "open" and to_status == "paused") or (m.status == "closed" and to_status == "open")
    if needs_reason and not (reason or "").strip():
        raise ValidationFailed("A reason is required for this transition.", code="reason_required")


def request_transition(ctx: Ctx, matter: Matter, to_status: str, reason: str | None, expected_version: int, retention_key: str | None = None) -> tuple[Matter, Approval, bool]:
    """Returns (matter, approval, executed). Users with matters.approve execute immediately (an approved approval is still recorded);
    others create a pending approval for a partner."""
    ctx.require("matters.transition")
    _check_version(matter, expected_version)
    _validate_request(matter, to_status, reason)
    blockers = transition_blockers(ctx, matter, to_status, retention_key)
    if blockers:
        raise ValidationFailed("This transition is blocked.", code="transition_blocked", details={"blockers": blockers})
    payload = _payload(matter, to_status, reason, retention_key)
    ap = approvals_svc.request_approval(ctx, kind="matter_transition", subject_type="matter", subject_id=matter.id, payload=payload, matter_id=matter.id,
                                        required_permission="matters.approve", note=reason)
    if ctx.has("matters.approve"):
        approvals_svc.decide(ctx, ap.id, approve=True, note="Self-approved by authorised partner at request time")
        _execute(ctx, matter, ap)
        return matter, ap, True
    notify(ctx.db, firm_id=ctx.firm_id, user_id=matter.responsible_partner_id, kind="approval", title=f"Approval needed: {matter.reference} -> {to_status}",
           body=f"{ctx.user.name} requested this transition.", link=f"/matters/{matter.id}", matter_id=matter.id)
    return matter, ap, False


def decide_transition(ctx: Ctx, matter: Matter, approval_id: uuid.UUID, approve: bool, note: str | None) -> tuple[Matter, Approval, bool]:
    ap = ctx.db.get(Approval, approval_id)
    if not ap or ap.firm_id != ctx.firm_id or ap.subject_id != matter.id or ap.kind != "matter_transition":
        raise NotFound("Approval not found for this matter.")
    ap = approvals_svc.decide(ctx, approval_id, approve=approve, note=note)
    if not approve:
        notify(ctx.db, firm_id=ctx.firm_id, user_id=ap.requested_by, kind="approval", title=f"Transition rejected: {matter.reference}", body=note, link=f"/matters/{matter.id}", matter_id=matter.id)
        return matter, ap, False
    _execute(ctx, matter, ap)
    return matter, ap, True


def _execute(ctx: Ctx, m: Matter, ap: Approval) -> None:
    p = ap.payload
    to_status, reason, rkey = p["to"], p.get("reason") or None, p.get("retention_policy_key") or None
    # approval is bound to the exact request: the matter must still be in the state/version that was approved
    approvals_svc.assert_approved(ctx, ap.id, kind="matter_transition", payload={**p, "matter_version": m.version}, subject_id=m.id)
    _validate_request(m, to_status, reason)
    blockers = transition_blockers(ctx, m, to_status, rkey)  # re-validated at execution time
    if blockers:
        raise ValidationFailed("This transition is blocked.", code="transition_blocked", details={"blockers": blockers})
    prev = m.status
    today = date.today()
    if to_status == "open":
        if prev == "prospective":
            m.opened_at = m.opened_at or today
            s = conflicts_svc.cleared_search_for_matter(ctx, m)
            if s and not m.conflict_search_id:
                m.conflict_search_id = s.id
        else:
            m.closed_at = None
            m.retention_until = None
    elif to_status == "closed":
        m.closed_at = today
        if rkey:
            m.retention_policy_key = rkey
        m.retention_until = compute_retention_until(ctx, m.retention_policy_key, today)
    m.status = to_status
    ctx.db.flush()
    ctx.db.add(MatterStateEvent(firm_id=ctx.firm_id, matter_id=m.id, from_status=prev, to_status=to_status, actor_id=ctx.user.id, approval_id=ap.id, reason=reason))
    ctx.db.flush()
    ctx.audit("matter.state_changed", "matter", m.id, f"Matter {m.reference}: {prev} -> {to_status}", matter_id=m.id,
              details={"from": prev, "to": to_status, "approval": str(ap.id), "requested_by": str(ap.requested_by), "reason": reason})
    if ap.requested_by != ctx.user.id:
        notify(ctx.db, firm_id=ctx.firm_id, user_id=ap.requested_by, kind="approval", title=f"Approved: {m.reference} is now {to_status}", link=f"/matters/{m.id}", matter_id=m.id)


def open_matter(ctx: Ctx, matter_id: uuid.UUID, reason: str | None = None) -> Matter:
    """Convenience for seed/tests: transition prospective -> open (caller needs matters.transition + matters.approve to execute immediately)."""
    m = get_matter(ctx, matter_id)
    m, ap, done = request_transition(ctx, m, "open", reason, m.version)
    if not done:
        raise ApprovalRequired("Opening needs partner approval.", details={"approval_id": str(ap.id)})
    return m


def available_transitions(ctx: Ctx, m: Matter) -> list[dict]:
    out = []
    for to in enums.MATTER_TRANSITIONS.get(m.status, []):
        bl = transition_blockers(ctx, m, to)
        out.append({"to_status": to, "allowed": not bl, "blockers": bl, "reason_required": (m.status, to) in {("open", "paused"), ("closed", "open")},
                    "needs_approval_from_partner": not ctx.has("matters.approve"), "can_request": ctx.has("matters.transition")})
    return out


# --------------------------------------------------------------------------- templates
def _tpl_out(t: MatterTemplate) -> dict:
    return {"id": str(t.id), "name": t.name, "practice_area": t.practice_area, "matter_type": t.matter_type, "description": t.description, "stages": t.stages,
            "opening_checklist": t.opening_checklist, "closing_checklist": t.closing_checklist, "required_fields": t.required_fields,
            "default_fee_arrangement": t.default_fee_arrangement, "default_retention_key": t.default_retention_key, "default_tasks": t.default_tasks,
            "is_active": t.is_active, "created_at": t.created_at.isoformat()}


def template_write_allowed(ctx: Ctx) -> None:
    if not (ctx.has("matters.approve") or ctx.has("admin.settings")):
        raise PermissionDenied("Managing matter templates needs partner or administrator permissions.", details={"required": ["matters.approve", "admin.settings"]})


def save_template(ctx: Ctx, data: dict, template: MatterTemplate | None = None) -> MatterTemplate:
    template_write_allowed(ctx)
    if data["practice_area"] not in enums.PRACTICE_AREAS:
        raise ValidationFailed("Unknown practice area.", details={"allowed": enums.PRACTICE_AREAS})
    if data.get("default_retention_key") and not ctx.db.execute(select(RetentionPolicy.id).where(RetentionPolicy.firm_id == ctx.firm_id, RetentionPolicy.key == data["default_retention_key"])).first():
        raise ValidationFailed("Default retention policy not found.")
    if template is None:
        template = MatterTemplate(firm_id=ctx.firm_id, name=data["name"], practice_area=data["practice_area"], matter_type=data["matter_type"])
        ctx.db.add(template)
    for k, v in data.items():
        setattr(template, k, v)
    ctx.db.flush()
    ctx.audit("matter_template.saved", "matter_template", template.id, f"Matter template saved: {template.name}")
    return template


# --------------------------------------------------------------------------- chronology
def _chron_out(e: ChronologyEntry, names: dict) -> dict:
    return {"id": str(e.id), "event_date": e.event_date.isoformat() if e.event_date else None, "date_text": e.date_text, "date_basis": e.date_basis,
            "description": e.description, "source": e.source, "origin": e.origin, "status": e.status, "agent_run_id": str(e.agent_run_id) if e.agent_run_id else None,
            "created_by": names.get(e.created_by), "edited_by": names.get(e.edited_by), "version": e.version, "updated_at": e.updated_at.isoformat()}


def list_chronology(ctx: Ctx, matter: Matter, include_rejected: bool = False) -> list[dict]:
    stmt = select(ChronologyEntry).where(ChronologyEntry.matter_id == matter.id)
    if not include_rejected:
        stmt = stmt.where(ChronologyEntry.status != "rejected")
    rows = ctx.db.execute(stmt.order_by(ChronologyEntry.event_date.asc().nulls_last(), ChronologyEntry.created_at)).scalars().all()
    names = user_names(ctx, {r.created_by for r in rows} | {r.edited_by for r in rows})
    return [_chron_out(r, names) for r in rows]


def add_chronology(ctx: Ctx, matter: Matter, data: dict) -> ChronologyEntry:
    ctx.require("matters.write")
    if data.get("event_date") is None and data.get("date_basis", "explicit") == "explicit" and not data.get("date_text"):
        raise ValidationFailed("An explicit date needs event_date or date_text; mark undated entries as inferred.")
    e = ChronologyEntry(firm_id=ctx.firm_id, matter_id=matter.id, origin="manual", status="accepted", created_by=ctx.user.id, **data)
    ctx.db.add(e)
    ctx.db.flush()
    ctx.audit("chronology.added", "matter", matter.id, "Chronology entry added", matter_id=matter.id, details={"entry": str(e.id)})
    return e


def _get_entry(ctx: Ctx, matter: Matter, entry_id: uuid.UUID) -> ChronologyEntry:
    e = ctx.db.get(ChronologyEntry, entry_id)
    if not e or e.matter_id != matter.id or e.firm_id != ctx.firm_id:
        raise NotFound("Chronology entry not found.")
    return e


def update_chronology(ctx: Ctx, matter: Matter, entry_id: uuid.UUID, data: dict, expected_version: int) -> ChronologyEntry:
    ctx.require("matters.write")
    e = _get_entry(ctx, matter, entry_id)
    if e.version != expected_version:
        raise VersionConflict("This entry was changed by someone else.")
    before = {k: str(getattr(e, k)) for k in data}
    for k, v in data.items():
        if v is not None or k in ("event_date", "date_text"):
            setattr(e, k, v)
    e.status, e.edited_by = "edited", ctx.user.id
    ctx.db.flush()
    ctx.audit("chronology.edited", "matter", matter.id, "Chronology entry edited by a human", matter_id=matter.id, details={"entry": str(e.id), "fields": list(before)})
    return e


def reject_chronology(ctx: Ctx, matter: Matter, entry_id: uuid.UUID) -> ChronologyEntry:
    ctx.require("matters.write")
    e = _get_entry(ctx, matter, entry_id)
    e.status, e.edited_by = "rejected", ctx.user.id
    ctx.db.flush()
    ctx.audit("chronology.rejected", "matter", matter.id, "Chronology entry removed from timeline (kept in history)", matter_id=matter.id, details={"entry": str(e.id)})
    return e


# --------------------------------------------------------------------------- serialisation
def list_stmt(ctx: Ctx, *, status=None, practice_area=None, office_id=None, partner_id=None, fee_earner_id=None, client_id=None, q=None, mine=False):
    stmt = select(Matter).where(matter_clause(ctx))
    if status:
        stmt = stmt.where(Matter.status == status)
    if practice_area:
        stmt = stmt.where(Matter.practice_area == practice_area)
    if office_id:
        stmt = stmt.where(Matter.office_id == office_id)
    if partner_id:
        stmt = stmt.where(Matter.responsible_partner_id == partner_id)
    if fee_earner_id:
        stmt = stmt.where(Matter.fee_earner_id == fee_earner_id)
    if client_id:
        stmt = stmt.where(Matter.client_id == client_id)
    if mine:
        stmt = stmt.where((Matter.responsible_partner_id == ctx.user.id) | (Matter.fee_earner_id == ctx.user.id))
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(Matter.title.ilike(like) | Matter.reference.ilike(like) | Matter.client_id.in_(select(Contact.id).where(Contact.firm_id == ctx.firm_id, Contact.display_name.ilike(like))))
    return stmt.order_by(Matter.opened_at.desc().nulls_first(), Matter.reference.desc())


def matter_list_items(ctx: Ctx, rows: list[Matter]) -> list[dict]:
    names = user_names(ctx, {r.responsible_partner_id for r in rows} | {r.fee_earner_id for r in rows})
    cl = {c.id: c for c in ctx.db.execute(select(Contact).where(Contact.id.in_({r.client_id for r in rows}))).scalars()} if rows else {}
    off = {o.id: o for o in ctx.db.execute(select(Office).where(Office.firm_id == ctx.firm_id)).scalars()}
    return [{
        "id": str(m.id), "reference": m.reference, "title": m.title, "status": m.status, "stage": m.stage, "practice_area": m.practice_area, "matter_type": m.matter_type,
        "client": {"id": str(m.client_id), "name": cl[m.client_id].display_name if m.client_id in cl else None},
        "responsible_partner": {"id": str(m.responsible_partner_id), "name": names.get(m.responsible_partner_id)},
        "fee_earner": {"id": str(m.fee_earner_id), "name": names.get(m.fee_earner_id)},
        "office": {"id": str(m.office_id), "name": off[m.office_id].name if m.office_id in off else None},
        "opened_at": m.opened_at.isoformat() if m.opened_at else None, "target_date": m.target_date.isoformat() if m.target_date else None,
        "access_level": m.access_level, "ethical_wall": m.ethical_wall, "legal_hold": m.legal_hold, "version": m.version,
    } for m in rows]


def matter_detail(ctx: Ctx, m: Matter) -> dict:
    db = ctx.db
    parties = db.execute(select(MatterParty, Contact).join(Contact, Contact.id == MatterParty.contact_id).where(MatterParty.matter_id == m.id).order_by(MatterParty.created_at)).all()
    members = db.execute(select(MatterMember).where(MatterMember.matter_id == m.id).order_by(MatterMember.created_at)).scalars().all()
    teams = {t.id: t for t in db.execute(select(Team).where(Team.firm_id == ctx.firm_id)).scalars()}
    items = db.execute(select(MatterChecklistItem).where(MatterChecklistItem.matter_id == m.id).order_by(MatterChecklistItem.phase, MatterChecklistItem.position)).scalars().all()
    tpl = db.get(MatterTemplate, m.template_id) if m.template_id else None
    names = user_names(ctx, {m.responsible_partner_id, m.fee_earner_id} | {x.user_id for x in members} | {x.completed_by for x in items})
    pending = db.execute(select(Approval).where(Approval.subject_id == m.id, Approval.kind == "matter_transition", Approval.status == "pending")).scalars().first()
    base = matter_list_items(ctx, [m])[0]
    financial = None
    if ctx.has("billing.read") or ctx.has("ledger.read"):
        w = wip(db, m.id)
        financial = {"fee_arrangement": m.fee_arrangement, "fixed_fee_amount": str(m.fixed_fee_amount) if m.fixed_fee_amount is not None else None,
                     "budget_amount": str(m.budget_amount) if m.budget_amount is not None else None, "currency": m.currency,
                     "unbilled_time": str(w["time"]), "unbilled_expenses": str(w["expenses"]), "unbilled_entries": w["count"],
                     "client_balance": str(client_balance(db, m.id)),
                     "basis": "Unbilled = billable time and expenses not yet on an issued invoice line. Client balance = posted client-ledger credits less debits for this matter."}
    base.update({
        "description": m.description, "jurisdiction": m.jurisdiction, "closed_at": m.closed_at.isoformat() if m.closed_at else None, "team_id": str(m.team_id) if m.team_id else None,
        "exports_allowed": m.exports_allowed, "ai_retrieval_allowed": m.ai_retrieval_allowed, "fee_arrangement": m.fee_arrangement, "currency": m.currency,
        "retention_policy_key": m.retention_policy_key, "retention_until": m.retention_until.isoformat() if m.retention_until else None,
        "legal_hold": m.legal_hold, "legal_hold_reason": m.legal_hold_reason, "conflict_search_id": str(m.conflict_search_id) if m.conflict_search_id else None,
        "custom_fields": m.custom_fields,
        "template": {"id": str(tpl.id), "name": tpl.name, "stages": tpl.stages, "required_fields": tpl.required_fields} if tpl else None,
        "parties": [{"id": str(p.id), "role": p.role, "notes": p.notes, "contact": {"id": str(c.id), "name": c.display_name, "kind": c.kind, "status": c.status}} for p, c in parties],
        "members": [{"id": str(x.id), "access": x.access, "member_role": x.member_role, "reason": x.reason,
                     "user": {"id": str(x.user_id), "name": names.get(x.user_id)} if x.user_id else None,
                     "team": {"id": str(x.team_id), "name": teams[x.team_id].name if x.team_id in teams else None} if x.team_id else None} for x in members],
        "checklist": [{"id": str(i.id), "phase": i.phase, "label": i.label, "required": i.required, "completed": i.completed_at is not None,
                       "completed_at": i.completed_at.isoformat() if i.completed_at else None, "completed_by": names.get(i.completed_by), "note": i.note} for i in items],
        "financial": financial,
        "pending_transition": {"approval_id": str(pending.id), "to_status": pending.payload.get("to"), "requested_by": str(pending.requested_by), "reason": pending.payload.get("reason")} if pending else None,
        "state_history": state_history(ctx, m),
    })
    return base


def state_history(ctx: Ctx, m: Matter) -> list[dict]:
    rows = ctx.db.execute(select(MatterStateEvent, Approval).outerjoin(Approval, Approval.id == MatterStateEvent.approval_id)
                          .where(MatterStateEvent.matter_id == m.id).order_by(MatterStateEvent.created_at)).all()
    names = user_names(ctx, {e.actor_id for e, _ in rows} | {a.requested_by for _, a in rows if a} | {a.decided_by for _, a in rows if a})
    return [{"from": e.from_status, "to": e.to_status, "actor": names.get(e.actor_id), "reason": e.reason, "at": e.created_at.isoformat(),
             "requested_by": names.get(a.requested_by) if a else None, "approved_by": names.get(a.decided_by) if a else None} for e, a in rows]


def activity(ctx: Ctx, matter: Matter):
    return select(AuditEvent).where(AuditEvent.firm_id == ctx.firm_id, AuditEvent.matter_id == matter.id).order_by(AuditEvent.id.desc())


def summary(ctx: Ctx, m: Matter) -> dict:
    db = ctx.db
    today = date.today()
    out: dict = {"matter_id": str(m.id), "reference": m.reference}
    out["documents"] = db.execute(select(func.count(Document.id)).where(Document.matter_id == m.id)).scalar_one() if ctx.has("documents.read") else None
    out["open_tasks"] = db.execute(select(func.count(Task.id)).where(Task.matter_id == m.id, Task.status.in_(["open", "in_progress", "blocked"]))).scalar_one() if ctx.has("tasks.read") else None
    out["upcoming_deadlines"] = db.execute(select(func.count(Deadline.id)).where(Deadline.matter_id == m.id, Deadline.status == "confirmed", Deadline.due_date >= today,
                                                                              Deadline.due_date <= today + timedelta(days=30))).scalar_one() if ctx.has("tasks.read") else None
    out["suggested_deadlines_unconfirmed"] = db.execute(select(func.count(Deadline.id)).where(Deadline.matter_id == m.id, Deadline.status == "suggested")).scalar_one() if ctx.has("tasks.read") else None
    if ctx.has("billing.read") or ctx.has("ledger.read"):
        w = wip(db, m.id)
        out.update({"unbilled_wip": str(Decimal(w["time"]) + Decimal(w["expenses"])), "unbilled_entries": w["count"], "client_balance": str(client_balance(db, m.id)), "currency": m.currency,
                    "basis": "Unbilled = billable time and expenses not yet billed; client balance = posted client-ledger credits less debits."})
    else:
        out.update({"unbilled_wip": None, "client_balance": None})
    out["outstanding_required_checklist_items"] = db.execute(select(func.count(MatterChecklistItem.id)).where(
        MatterChecklistItem.matter_id == m.id, MatterChecklistItem.required.is_(True), MatterChecklistItem.completed_at.is_(None))).scalar_one()
    return out
