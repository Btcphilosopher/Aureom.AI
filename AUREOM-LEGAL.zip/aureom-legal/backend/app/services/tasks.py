"""Tasks: assignment, dependencies, recurrence. Visibility = matter visibility for matter tasks; assignee/creator otherwise."""
from __future__ import annotations

import calendar as _cal
import uuid
from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.errors import InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.models import Matter, Role, Task, TaskDependency, User
from app.permissions import can_access_matter, visible_matter_ids
from app.services.notify import notify

LOCAL_TZ = ZoneInfo("Europe/London")
OPEN_STATES = ("open", "in_progress", "blocked")


def aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    return dt.replace(tzinfo=LOCAL_TZ) if dt.tzinfo is None else dt


def task_clause(ctx: Ctx):
    own = or_(Task.assignee_id == ctx.user.id, Task.created_by == ctx.user.id)
    return and_(Task.firm_id == ctx.firm_id,
                or_(and_(Task.matter_id.is_not(None), Task.matter_id.in_(visible_matter_ids(ctx))),
                    and_(Task.matter_id.is_(None), own)))


def get_task(ctx: Ctx, task_id: uuid.UUID) -> Task:
    ctx.require("tasks.read")
    t = ctx.db.get(Task, task_id)
    if not t or t.firm_id != ctx.firm_id:
        raise NotFound("Task not found.")
    if t.matter_id:
        m = ctx.db.get(Matter, t.matter_id)
        if not m or not can_access_matter(ctx, m):
            raise MatterAccessDenied("You do not have access to the matter this task belongs to.")
    elif ctx.user.id not in (t.assignee_id, t.created_by):
        raise NotFound("Task not found.")
    return t


def _staff_user(ctx: Ctx, user_id: uuid.UUID | None, what: str) -> User | None:
    if user_id is None:
        return None
    u = ctx.db.get(User, user_id)
    if not u or u.firm_id != ctx.firm_id or not u.is_active:
        raise ValidationFailed(f"{what} must be an active user of this firm.")
    role = ctx.db.get(Role, u.role_id)
    if role.key == "client":
        raise ValidationFailed(f"{what} cannot be a client user.")
    return u


def _validate_recurrence(rec: dict | None, due_at) -> dict | None:
    if not rec:
        return None
    if due_at is None:
        raise ValidationFailed("A recurring task needs a due date.")
    out = {"freq": rec["freq"], "interval": int(rec.get("interval", 1))}
    if rec.get("until"):
        out["until"] = rec["until"].isoformat() if isinstance(rec["until"], date) else str(rec["until"])
    return out


def _check_offsets(offsets: list[int]) -> list[int]:
    if any(o < 0 or o > 60 * 24 * 365 for o in offsets):
        raise ValidationFailed("Reminder offsets must be between 0 minutes and one year.")
    return sorted(set(offsets), reverse=True)


def create_task(ctx: Ctx, *, title: str, matter_id: uuid.UUID | None = None, description: str | None = None,
                assignee_id: uuid.UUID | None = None, due_at: datetime | None = None, priority: str = "normal",
                recurrence: dict | None = None, reminder_offsets_minutes: list[int] | None = None,
                escalate_to_id: uuid.UUID | None = None, escalate_after_hours: int | None = None,
                source: str = "manual", agent_run_id: uuid.UUID | None = None, deadline_id: uuid.UUID | None = None,
                depends_on: list[uuid.UUID] | None = None, notify_assignee: bool = True) -> Task:
    ctx.require("tasks.write")
    if matter_id:
        m = ctx.db.get(Matter, matter_id)
        if not m or m.firm_id != ctx.firm_id:
            raise NotFound("Matter not found.")
        if not can_access_matter(ctx, m):
            raise MatterAccessDenied("You do not have access to this matter.")
    _staff_user(ctx, assignee_id, "Assignee")
    _staff_user(ctx, escalate_to_id, "Escalation contact")
    if escalate_to_id and not escalate_after_hours:
        raise ValidationFailed("Escalation needs 'escalate_after_hours'.")
    due_at = aware(due_at)
    t = Task(firm_id=ctx.firm_id, matter_id=matter_id, title=title, description=description, assignee_id=assignee_id,
             created_by=ctx.user.id, due_at=due_at, priority=priority, recurrence=_validate_recurrence(recurrence, due_at),
             reminder_offsets_minutes=_check_offsets(reminder_offsets_minutes or []), escalate_to_id=escalate_to_id,
             escalate_after_hours=escalate_after_hours, source=source, agent_run_id=agent_run_id, deadline_id=deadline_id)
    ctx.db.add(t)
    ctx.db.flush()
    for dep in depends_on or []:
        add_dependency(ctx, t, dep)
    ctx.audit("task.created", "task", t.id, f"Task created: {title[:120]}", matter_id=matter_id, details={"source": source, "assignee": str(assignee_id) if assignee_id else None})
    if assignee_id and assignee_id != ctx.user.id and notify_assignee:
        notify(ctx.db, firm_id=ctx.firm_id, user_id=assignee_id, kind="task_assigned", title=f"Task assigned: {title[:150]}",
               body=f"Assigned by {ctx.user.name}", link=f"/tasks/{t.id}", matter_id=matter_id)
    return t


def update_task(ctx: Ctx, task: Task, changes: dict, expected_version: int) -> Task:
    ctx.require("tasks.write")
    if task.version != expected_version:
        raise VersionConflict("This task was changed by someone else. Reload and try again.", details={"current_version": task.version})
    if task.status in ("done", "cancelled"):
        raise InvalidState(f"A {task.status} task cannot be edited. Reopen it first.")
    old_assignee = task.assignee_id
    if "assignee_id" in changes:
        _staff_user(ctx, changes["assignee_id"], "Assignee")
    if changes.get("escalate_to_id"):
        _staff_user(ctx, changes["escalate_to_id"], "Escalation contact")
    for k in ("title", "description", "assignee_id", "priority", "escalate_to_id", "escalate_after_hours"):
        if k in changes:
            setattr(task, k, changes[k])
    if "due_at" in changes:
        task.due_at = aware(changes["due_at"])
        task.last_reminded_at, task.escalated_at = None, None  # a new due date re-arms reminders
    if "recurrence" in changes:
        task.recurrence = _validate_recurrence(changes["recurrence"], task.due_at)
    if "reminder_offsets_minutes" in changes:
        task.reminder_offsets_minutes = _check_offsets(changes["reminder_offsets_minutes"] or [])
        task.last_reminded_at = None
    ctx.db.flush()
    ctx.audit("task.updated", "task", task.id, f"Task updated: {task.title[:120]}", matter_id=task.matter_id, details={"fields": sorted(changes)})
    if "assignee_id" in changes and task.assignee_id and task.assignee_id != old_assignee and task.assignee_id != ctx.user.id:
        notify(ctx.db, firm_id=ctx.firm_id, user_id=task.assignee_id, kind="task_assigned", title=f"Task assigned: {task.title[:150]}",
               body=f"Assigned by {ctx.user.name}", link=f"/tasks/{task.id}", matter_id=task.matter_id)
    return task


# ------------------------------------------------------------------ dependencies
def blockers(db: Session, task_id: uuid.UUID) -> list[Task]:
    """Dependencies that are neither done nor cancelled (a cancelled prerequisite no longer blocks)."""
    return list(db.execute(select(Task).join(TaskDependency, TaskDependency.depends_on_task_id == Task.id)
                           .where(TaskDependency.task_id == task_id, Task.status.not_in(("done", "cancelled")))).scalars())


def _reaches(db: Session, start: uuid.UUID, target: uuid.UUID) -> bool:
    seen, stack = set(), [start]
    while stack:
        cur = stack.pop()
        if cur == target:
            return True
        if cur in seen:
            continue
        seen.add(cur)
        stack.extend(db.execute(select(TaskDependency.depends_on_task_id).where(TaskDependency.task_id == cur)).scalars())
    return False


def add_dependency(ctx: Ctx, task: Task, depends_on_id: uuid.UUID) -> TaskDependency:
    ctx.require("tasks.write")
    if depends_on_id == task.id:
        raise ValidationFailed("A task cannot depend on itself.")
    other = get_task(ctx, depends_on_id)
    if _reaches(ctx.db, depends_on_id, task.id):
        raise ValidationFailed("That dependency would create a cycle.", code="dependency_cycle")
    existing = ctx.db.execute(select(TaskDependency).where(TaskDependency.task_id == task.id, TaskDependency.depends_on_task_id == other.id)).scalar_one_or_none()
    if existing:
        return existing
    dep = TaskDependency(firm_id=ctx.firm_id, task_id=task.id, depends_on_task_id=other.id)
    ctx.db.add(dep)
    ctx.db.flush()
    ctx.audit("task.dependency_added", "task", task.id, "Task dependency added", matter_id=task.matter_id, details={"depends_on": str(other.id)})
    return dep


def remove_dependency(ctx: Ctx, task: Task, depends_on_id: uuid.UUID) -> None:
    ctx.require("tasks.write")
    dep = ctx.db.execute(select(TaskDependency).where(TaskDependency.task_id == task.id, TaskDependency.depends_on_task_id == depends_on_id)).scalar_one_or_none()
    if not dep:
        raise NotFound("Dependency not found.")
    ctx.db.delete(dep)
    ctx.db.flush()
    ctx.audit("task.dependency_removed", "task", task.id, "Task dependency removed", matter_id=task.matter_id)


def _assert_unblocked(db: Session, task: Task, action: str) -> None:
    b = blockers(db, task.id)
    if b:
        raise InvalidState(f"Cannot {action} this task until its prerequisites are done.", code="task_blocked",
                           details={"blocked_by": [{"id": str(x.id), "title": x.title, "status": x.status} for x in b]})


# ------------------------------------------------------------------ lifecycle
def add_months(d: datetime, months: int) -> datetime:
    m = d.month - 1 + months
    y, mo = d.year + m // 12, m % 12 + 1
    return d.replace(year=y, month=mo, day=min(d.day, _cal.monthrange(y, mo)[1]))


def next_due(due: datetime, rec: dict) -> datetime:
    """Wall-clock arithmetic in Europe/London so a 09:00 task stays at 09:00 across DST changes."""
    local = due.astimezone(LOCAL_TZ).replace(tzinfo=None)
    n = int(rec.get("interval", 1))
    from datetime import timedelta
    if rec["freq"] == "daily":
        nxt = local + timedelta(days=n)
    elif rec["freq"] == "weekly":
        nxt = local + timedelta(weeks=n)
    else:
        nxt = add_months(local, n)
    return nxt.replace(tzinfo=LOCAL_TZ).astimezone(timezone.utc)


def start_task(ctx: Ctx, task: Task) -> Task:
    ctx.require("tasks.write")
    if task.status not in ("open", "blocked"):
        raise InvalidState(f"A {task.status} task cannot be started.")
    _assert_unblocked(ctx.db, task, "start")
    task.status = "in_progress"
    ctx.audit("task.started", "task", task.id, "Task started", matter_id=task.matter_id)
    return task


def complete_task(ctx: Ctx, task: Task) -> tuple[Task, Task | None]:
    ctx.require("tasks.write")
    if task.status in ("done", "cancelled"):
        raise InvalidState(f"This task is already {task.status}.")
    _assert_unblocked(ctx.db, task, "complete")
    task.status, task.completed_at = "done", datetime.now(timezone.utc)
    nxt = None
    rec = task.recurrence
    if rec and task.due_at and not rec.get("next_task_id"):
        due = next_due(task.due_at, rec)
        until = date.fromisoformat(rec["until"]) if rec.get("until") else None
        if until is None or due.astimezone(LOCAL_TZ).date() <= until:
            clean = {k: v for k, v in rec.items() if k != "next_task_id"}
            nxt = Task(firm_id=ctx.firm_id, matter_id=task.matter_id, title=task.title, description=task.description,
                       assignee_id=task.assignee_id, created_by=task.created_by, due_at=due, priority=task.priority, recurrence=clean,
                       reminder_offsets_minutes=list(task.reminder_offsets_minutes or []), escalate_to_id=task.escalate_to_id,
                       escalate_after_hours=task.escalate_after_hours, source=task.source)
            ctx.db.add(nxt)
            ctx.db.flush()
            task.recurrence = {**rec, "next_task_id": str(nxt.id)}  # exactly-once marker (survives reopen/complete cycles)
            ctx.audit("task.recurrence_spawned", "task", nxt.id, "Next occurrence of recurring task created", matter_id=task.matter_id, details={"from": str(task.id)})
    ctx.db.flush()
    ctx.audit("task.completed", "task", task.id, f"Task completed: {task.title[:120]}", matter_id=task.matter_id)
    return task, nxt


def reopen_task(ctx: Ctx, task: Task) -> Task:
    ctx.require("tasks.write")
    if task.status not in ("done", "cancelled"):
        raise InvalidState("Only completed or cancelled tasks can be reopened.")
    task.status, task.completed_at = "open", None
    task.escalated_at = None
    ctx.audit("task.reopened", "task", task.id, "Task reopened", matter_id=task.matter_id)
    return task


def cancel_task(ctx: Ctx, task: Task) -> Task:
    ctx.require("tasks.write")
    if task.status in ("done", "cancelled"):
        raise InvalidState(f"This task is already {task.status}.")
    task.status = "cancelled"
    ctx.audit("task.cancelled", "task", task.id, "Task cancelled", matter_id=task.matter_id)
    return task


def my_open_tasks(ctx: Ctx, limit: int = 10) -> list[Task]:
    """For the home dashboard."""
    return list(ctx.db.execute(select(Task).where(task_clause(ctx), Task.assignee_id == ctx.user.id, Task.status.in_(OPEN_STATES))
                               .order_by(Task.due_at.asc().nulls_last()).limit(limit)).scalars())
