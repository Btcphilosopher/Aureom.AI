"""Financial and operational reports. Every report states its period, filters, currency and calculation basis.
Cash received, invoices billed and recognised revenue are SEPARATE measures; none is inferred from another."""
from __future__ import annotations

import csv
import io
import uuid
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import func, or_, select

from app.deps import Ctx
from app.errors import NotFound, PermissionDenied, ValidationFailed
from app.models import (Expense, Invoice, Journal, JournalLine, LedgerAccount, Matter, Payment, Reconciliation, RevenueRecognition, TimeEntry, User)
from app.money import ZERO, q
from app.permissions import matter_clause
from app.services import ledger as led
from app.services.matter_finance import client_balance

FINANCIAL = {"billing", "cash-received", "recognised-revenue", "aged-debtors", "client-money"}
REPORTS = ["wip", "billing", "cash-received", "recognised-revenue", "aged-debtors", "client-money", "utilisation"]


def _meta(name: str, title: str, *, date_from=None, date_to=None, as_of=None, filters: dict | None = None, basis: str, currency="GBP") -> dict:
    return {"report": name, "title": title, "period": {"from": date_from, "to": date_to, "as_of": as_of}, "filters": filters or {}, "basis": basis,
            "currency": currency, "generated_at": datetime.now(timezone.utc), "rows": [], "totals": {}}


def _visible_matters(ctx: Ctx, practice_area=None, office_id=None, matter_id=None):
    stmt = select(Matter).where(matter_clause(ctx))
    if practice_area:
        stmt = stmt.where(Matter.practice_area == practice_area)
    if office_id:
        stmt = stmt.where(Matter.office_id == office_id)
    if matter_id:
        stmt = stmt.where(Matter.id == matter_id)
    return stmt


def _need(ctx: Ctx, name: str) -> None:
    ctx.require("reports.financial" if name in FINANCIAL else "reports.read")


def run(ctx: Ctx, name: str, **p) -> dict:
    if name not in REPORTS:
        raise NotFound("Unknown report.")
    _need(ctx, name)
    return {"wip": wip, "billing": billing, "cash-received": cash_received, "recognised-revenue": recognised_revenue, "aged-debtors": aged_debtors,
            "client-money": client_money, "utilisation": utilisation}[name](ctx, **p)


def _clean(**p):
    return {k: v for k, v in p.items() if v is not None}


def wip(ctx: Ctx, *, matter_id=None, practice_area=None, office_id=None, fee_earner_id=None, **_) -> dict:
    own_only = not ctx.has("reports.financial")
    r = _meta("wip", "Work in progress (unbilled)", as_of=date.today(), filters=_clean(matter_id=matter_id, practice_area=practice_area, office_id=office_id,
              fee_earner_id=fee_earner_id, scope="own matters only" if own_only else "all visible matters"),
              basis="Billable time (draft/submitted/approved) and expenses (draft/approved) not yet on an issued invoice, at recorded rates and net of VAT. Work in progress is not revenue and has not been billed.")
    mstmt = _visible_matters(ctx, practice_area, office_id, matter_id)
    if own_only:
        mstmt = mstmt.where(or_(Matter.responsible_partner_id == ctx.user.id, Matter.fee_earner_id == ctx.user.id))
    matters = {m.id: m for m in ctx.db.execute(mstmt).scalars()}
    if not matters:
        return r
    t = select(TimeEntry.matter_id, TimeEntry.user_id, func.sum(TimeEntry.amount), func.sum(TimeEntry.minutes)).where(
        TimeEntry.matter_id.in_(list(matters)), TimeEntry.billable.is_(True), TimeEntry.status.in_(("draft", "submitted", "approved")), TimeEntry.timer_started_at.is_(None))
    if fee_earner_id:
        t = t.where(TimeEntry.user_id == fee_earner_id)
    per_m: dict = defaultdict(lambda: {"time": ZERO, "hours": Decimal(0), "expenses": ZERO})
    per_u: dict = defaultdict(lambda: {"time": ZERO, "hours": Decimal(0)})
    for mid, uid, amt, mins in ctx.db.execute(t.group_by(TimeEntry.matter_id, TimeEntry.user_id)):
        per_m[mid]["time"] += q(Decimal(amt)); per_m[mid]["hours"] += Decimal(mins) / 60
        per_u[uid]["time"] += q(Decimal(amt)); per_u[uid]["hours"] += Decimal(mins) / 60
    if not fee_earner_id:
        for mid, amt in ctx.db.execute(select(Expense.matter_id, func.sum(Expense.amount)).where(
                Expense.matter_id.in_(list(matters)), Expense.billable.is_(True), Expense.status.in_(("draft", "approved"))).group_by(Expense.matter_id)):
            per_m[mid]["expenses"] += q(Decimal(amt))
    users = {u.id: u.name for u in ctx.db.execute(select(User).where(User.firm_id == ctx.firm_id)).scalars()}
    tot_t = tot_e = ZERO
    for mid, v in sorted(per_m.items(), key=lambda kv: matters[kv[0]].reference):
        m = matters[mid]
        r["rows"].append({"matter_id": mid, "reference": m.reference, "title": m.title, "fee_earner": users.get(m.fee_earner_id), "time": v["time"],
                          "hours": v["hours"].quantize(Decimal("0.01")), "expenses": v["expenses"], "total": v["time"] + v["expenses"],
                          "budget": m.budget_amount, "href": f"/matters/{mid}"})
        tot_t += v["time"]; tot_e += v["expenses"]
    r["by_fee_earner"] = [{"user_id": u, "name": users.get(u), "time": v["time"], "hours": v["hours"].quantize(Decimal("0.01"))} for u, v in per_u.items()]
    r["totals"] = {"time": tot_t, "expenses": tot_e, "total": tot_t + tot_e}
    return r


def billing(ctx: Ctx, *, date_from: date | None = None, date_to: date | None = None, matter_id=None, practice_area=None, office_id=None, **_) -> dict:
    date_to = date_to or date.today(); date_from = date_from or date_to.replace(day=1)
    r = _meta("billing", "Billed (invoices issued)", date_from=date_from, date_to=date_to, filters=_clean(matter_id=matter_id, practice_area=practice_area, office_id=office_id),
              basis="Invoices and credit notes ISSUED in the period (by issue date), net of VAT with VAT shown separately. This measures what has been billed - it is NOT recognised revenue and NOT cash received.")
    ms = _visible_matters(ctx, practice_area, office_id, matter_id).subquery()
    stmt = select(Invoice).join(ms, ms.c.id == Invoice.matter_id).where(Invoice.firm_id == ctx.firm_id, Invoice.status.in_(("issued", "partially_paid", "paid")),
                                                                         func.date(Invoice.issued_at) >= date_from, func.date(Invoice.issued_at) <= date_to).order_by(Invoice.issued_at)
    net = vat_ = tot = ZERO
    refs = {m.id: m.reference for m in ctx.db.execute(_visible_matters(ctx)).scalars()}
    for inv in ctx.db.execute(stmt).scalars():
        sign = Decimal(1) if inv.kind == "invoice" else Decimal(-1)
        r["rows"].append({"invoice_id": inv.id, "number": inv.number, "kind": inv.kind, "matter": refs.get(inv.matter_id), "issued_at": inv.issued_at,
                          "net": sign * q(inv.subtotal), "vat": sign * q(inv.vat_amount), "total": sign * q(inv.total), "href": f"/time-billing?invoice={inv.id}"})
        net += sign * q(inv.subtotal); vat_ += sign * q(inv.vat_amount); tot += sign * q(inv.total)
    r["totals"] = {"net": net, "vat": vat_, "total": tot, "label": "billed, not revenue"}
    return r


def cash_received(ctx: Ctx, *, date_from: date | None = None, date_to: date | None = None, matter_id=None, **_) -> dict:
    date_to = date_to or date.today(); date_from = date_from or date_to.replace(day=1)
    r = _meta("cash-received", "Cash received", date_from=date_from, date_to=date_to, filters=_clean(matter_id=matter_id),
              basis="Authorised (posted) receipts by received date. Cash received is NOT earned revenue: office receipts sit in 'unallocated receipts' until allocated to issued invoices, and revenue is recognised only through a separate authorised step. Client-money receipts belong to clients, are held in the client ledger, and are shown separately.")
    visible = select(Matter.id).where(matter_clause(ctx))
    stmt = select(Payment).where(Payment.firm_id == ctx.firm_id, Payment.received_on >= date_from, Payment.received_on <= date_to,
                                 Payment.status.in_(("received_unallocated", "partially_allocated", "allocated")),
                                 or_(Payment.matter_id.is_(None), Payment.matter_id.in_(visible)))
    if matter_id:
        stmt = stmt.where(Payment.matter_id == matter_id)
    office = client = ZERO
    for p in ctx.db.execute(stmt.order_by(Payment.received_on)).scalars():
        r["rows"].append({"payment_id": p.id, "ledger": p.ledger, "received_on": p.received_on, "amount": q(p.amount), "allocated": q(p.allocated_amount),
                          "unallocated": q(p.amount) - q(p.allocated_amount), "status": p.status, "reference": p.reference, "matter_id": p.matter_id})
        if p.ledger == "client": client += q(p.amount)
        else: office += q(p.amount)
    r["totals"] = {"office_receipts": office, "client_money_receipts": client, "label": "cash received, not revenue"}
    return r


def recognised_revenue(ctx: Ctx, *, date_from: date | None = None, date_to: date | None = None, matter_id=None, **_) -> dict:
    date_to = date_to or date.today(); date_from = date_from or date_to.replace(day=1)
    r = _meta("recognised-revenue", "Recognised revenue", date_from=date_from, date_to=date_to, filters=_clean(matter_id=matter_id),
              basis="Only amounts explicitly recognised through the authorised revenue-recognition step (Dr fees billed-not-yet-recognised / Cr fee income), by recognition date. Issuing invoices or receiving payments does not appear here.")
    visible = select(Matter.id).where(matter_clause(ctx))
    stmt = select(RevenueRecognition).where(RevenueRecognition.firm_id == ctx.firm_id, RevenueRecognition.recognised_on >= date_from,
                                            RevenueRecognition.recognised_on <= date_to, RevenueRecognition.matter_id.in_(visible))
    if matter_id:
        stmt = stmt.where(RevenueRecognition.matter_id == matter_id)
    tot = ZERO
    for rr in ctx.db.execute(stmt.order_by(RevenueRecognition.recognised_on)).scalars():
        r["rows"].append({"id": rr.id, "invoice_id": rr.invoice_id, "matter_id": rr.matter_id, "amount": q(rr.amount), "basis": rr.basis, "recognised_on": rr.recognised_on})
        tot += q(rr.amount)
    r["totals"] = {"recognised": tot}
    return r


def aged_debtors(ctx: Ctx, *, as_of: date | None = None, matter_id=None, **_) -> dict:
    as_of = as_of or date.today()
    r = _meta("aged-debtors", "Aged debtors", as_of=as_of, filters=_clean(matter_id=matter_id),
              basis="Issued invoices with an outstanding balance (total less allocated payments less issued credit notes), aged by days since the issue date as at the report date. Buckets: current (0-30), 31-60, 61-90, over 90 days.")
    visible = select(Matter.id).where(matter_clause(ctx))
    stmt = select(Invoice).where(Invoice.firm_id == ctx.firm_id, Invoice.kind == "invoice", Invoice.status.in_(("issued", "partially_paid")), Invoice.matter_id.in_(visible))
    if matter_id:
        stmt = stmt.where(Invoice.matter_id == matter_id)
    buckets = {"0-30": ZERO, "31-60": ZERO, "61-90": ZERO, "90+": ZERO}
    refs = {m.id: m.reference for m in ctx.db.execute(_visible_matters(ctx)).scalars()}
    for inv in ctx.db.execute(stmt.order_by(Invoice.issued_at)).scalars():
        out = led.invoice_outstanding(ctx.db, inv)
        if out <= 0 or not inv.issued_at:
            continue
        days = (as_of - inv.issued_at.date()).days
        b = "0-30" if days <= 30 else "31-60" if days <= 60 else "61-90" if days <= 90 else "90+"
        buckets[b] += out
        r["rows"].append({"invoice_id": inv.id, "number": inv.number, "matter": refs.get(inv.matter_id), "issued_at": inv.issued_at, "days": days, "bucket": b,
                          "total": q(inv.total), "paid": q(inv.amount_paid), "outstanding": out})
    r["totals"] = {**buckets, "total": sum(buckets.values(), ZERO)}
    return r


def client_money(ctx: Ctx, *, matter_id=None, **_) -> dict:
    r = _meta("client-money", "Client money by matter", as_of=date.today(), filters=_clean(matter_id=matter_id),
              basis="Posted client-ledger balances held for each client on each matter, compared with the latest signed-off client bank reconciliation. Client money is not the firm's money and is never included in billed, cash or revenue measures.")
    accts = ctx.db.execute(select(LedgerAccount).where(LedgerAccount.firm_id == ctx.firm_id, LedgerAccount.system_key == "client_matter", LedgerAccount.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))).scalars().all()
    refs = {m.id: m for m in ctx.db.execute(_visible_matters(ctx)).scalars()}
    tot = ZERO
    for a in accts:
        if matter_id and a.matter_id != matter_id:
            continue
        bal = client_balance(ctx.db, a.matter_id)
        m = refs.get(a.matter_id)
        r["rows"].append({"matter_id": a.matter_id, "reference": m.reference if m else None, "title": m.title if m else None, "balance": bal, "href": f"/matters/{a.matter_id}"})
        tot += bal
    bank = ctx.db.execute(select(LedgerAccount).where(LedgerAccount.firm_id == ctx.firm_id, LedgerAccount.system_key == "bank_client")).scalars().first()
    rec = None
    if bank:
        rec = ctx.db.execute(select(Reconciliation).where(Reconciliation.bank_account_id == bank.id, Reconciliation.status == "signed_off")
                             .order_by(Reconciliation.period_end.desc())).scalars().first()
    r["totals"] = {"client_money_held_visible": tot, "client_bank_ledger_balance": led.account_balance(ctx.db, bank) if bank else ZERO,
                   "last_signed_off_reconciliation": rec.period_end if rec else None,
                   "note": "Matters you cannot access are excluded from the per-matter rows; the bank ledger balance covers all matters."}
    return r


def utilisation(ctx: Ctx, *, date_from: date | None = None, date_to: date | None = None, **_) -> dict:
    date_to = date_to or date.today(); date_from = date_from or date_to.replace(day=1)
    own_only = not ctx.has("time.read_all")
    r = _meta("utilisation", "Fee-earner utilisation", date_from=date_from, date_to=date_to, filters={"scope": "own time only" if own_only else "all visible time"},
              basis="Recorded hours in the period (excluding running timers and written-off time) with the billable share; no target hours are assumed, so no percentage-of-target is shown.")
    stmt = (select(TimeEntry.user_id, func.sum(TimeEntry.minutes), func.sum(TimeEntry.minutes).filter(TimeEntry.billable.is_(True)), func.sum(TimeEntry.amount).filter(TimeEntry.billable.is_(True)))
            .where(TimeEntry.firm_id == ctx.firm_id, TimeEntry.work_date >= date_from, TimeEntry.work_date <= date_to, TimeEntry.status != "written_off",
                   TimeEntry.timer_started_at.is_(None), TimeEntry.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))
    if own_only:
        stmt = stmt.where(TimeEntry.user_id == ctx.user.id)
    users = {u.id: u.name for u in ctx.db.execute(select(User).where(User.firm_id == ctx.firm_id)).scalars()}
    for uid, mins, bmins, bamt in ctx.db.execute(stmt.group_by(TimeEntry.user_id)):
        mins, bmins = mins or 0, bmins or 0
        r["rows"].append({"user_id": uid, "name": users.get(uid), "hours": (Decimal(mins) / 60).quantize(Decimal("0.01")), "billable_hours": (Decimal(bmins) / 60).quantize(Decimal("0.01")),
                          "billable_share_pct": (Decimal(bmins) * 100 / Decimal(mins)).quantize(Decimal("0.1")) if mins else None, "billable_value": q(Decimal(bamt or 0))})
    return r


def to_csv(report: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([f"# {report['title']}"])
    w.writerow([f"# Period: {report['period']}", f"Basis: {report['basis']}", f"Currency: {report['currency']}", f"Generated: {report['generated_at'].isoformat()}"])
    rows = report["rows"]
    if rows:
        cols = [k for k in rows[0].keys() if k != "href"]
        w.writerow(cols)
        for row in rows:
            w.writerow([("" if row.get(c) is None else str(row.get(c))) for c in cols])
    w.writerow([]); w.writerow(["# Totals"] + [f"{k}={v}" for k, v in report["totals"].items()])
    return buf.getvalue()
