"""Paragraph-level comparison of two versions of the same document (only where text was extracted)."""
from __future__ import annotations

import difflib
import uuid

from sqlalchemy import select

from app.deps import Ctx
from app.errors import ValidationFailed
from app.models import Document, DocumentChunk, DocumentVersion
from app.permissions import can_preview
from app.services import documents as docs

_UNSUPPORTED = "Comparison is not supported for this file type or scan state (text must be extracted from both versions and both must be scanned clean)."


def _paras(ctx: Ctx, v: DocumentVersion) -> list[dict]:
    if v.scan_status != "clean":
        raise ValidationFailed(_UNSUPPORTED, code="compare_unsupported")
    rows = ctx.db.execute(select(DocumentChunk).where(DocumentChunk.version_id == v.id).order_by(DocumentChunk.ordinal)).scalars().all()
    if not rows or any(r.is_ocr for r in rows):
        raise ValidationFailed(_UNSUPPORTED, code="compare_unsupported")
    return [{"page": r.page, "paragraph": r.paragraph, "text": r.text} for r in rows]


def compare(ctx: Ctx, document_id: uuid.UUID, from_no: int, to_no: int) -> dict:
    doc = docs.get_document(ctx, document_id)
    m = docs.matter_for(ctx, doc)
    if m is not None and not can_preview(ctx, m):
        from app.errors import PermissionDenied
        raise PermissionDenied("Preview is not permitted for this matter.")
    a, b = docs.get_version(ctx, doc, from_no), docs.get_version(ctx, doc, to_no)
    pa, pb = _paras(ctx, a), _paras(ctx, b)
    sm = difflib.SequenceMatcher(a=[p["text"] for p in pa], b=[p["text"] for p in pb], autojunk=False)
    ops, counts = [], {"added": 0, "removed": 0, "changed": 0, "unchanged": 0}
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            counts["unchanged"] += i2 - i1
            ops.append({"op": "equal", "count": i2 - i1})
        else:
            op = {"insert": "added", "delete": "removed", "replace": "changed"}[tag]
            counts[op] += max(i2 - i1, j2 - j1)
            ops.append({"op": op, "from": pa[i1:i2], "to": pb[j1:j2]})
    return {"document_id": str(doc.id), "from_version": from_no, "to_version": to_no, "from_sha256": a.sha256, "to_sha256": b.sha256, "summary": counts, "operations": ops}
