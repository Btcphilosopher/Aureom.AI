"""Diary events and the combined calendar feed (events + task due dates + deadlines)."""
from __future__ import annotations

import uuid
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import and_, or_, select

from app.deps import Ctx
from app.errors import InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.models import Deadline, DiaryEvent, Matter, Task, User
from app.permissions import can_access_matter, visible_matter_ids
from app.services.deadlines import deadline_clause, is_authoritative, label_for
from app.services.tasks import LOCAL_TZ, OPEN_STATES, aware, task_clause


def _day_bounds(start: date, end: date) -> tuple[datetime, datetime]:
    return (datetime.combine(start, time.min, tzinfo=LOCAL_TZ), datetime.combine(end + timedelta(days=1), time.min, tzinfo=LOCAL_TZ))


def _mine(ctx: Ctx):
    return or_(DiaryEvent.owner_id == ctx.user.id, DiaryEvent.attendee_ids.contains([ctx.user.id]))


def event_clause(ctx: Ctx, scope: str = "mine"):
    vis = or_(DiaryEvent.matter_id.is_(None), DiaryEvent.matter_id.in_(visible_matter_ids(ctx)))
    if scope == "mine":
        return and_(DiaryEvent.firm_id == ctx.firm_id, _mine(ctx), vis)
    return and_(DiaryEvent.firm_id == ctx.firm_id, or_(and_(DiaryEvent.matter_id.is_not(None), DiaryEvent.matter_id.in_(visible_matter_ids(ctx))),
                                                       and_(DiaryEvent.matter_id.is_(None), _mine(ctx))))


def get_event(ctx: Ctx, event_id: uuid.UUID) -> DiaryEvent:
    ctx.require("tasks.read")
    e = ctx.db.get(DiaryEvent, event_id)
    if not e or e.firm_id != ctx.firm_id:
        raise NotFound("Diary event not found.")
    if e.matter_id:
        m = ctx.db.get(Matter, e.matter_id)
        if not m or not can_access_matter(ctx, m):
            raise MatterAccessDenied("You do not have access to the matter this event belongs to.")
    elif ctx.user.id != e.owner_id and ctx.user.id not in (e.attendee_ids or []):
        raise NotFound("Diary event not found.")
    return e


def _check_attendees(ctx: Ctx, ids: list[uuid.UUID]) -> list[uuid.UUID]:
    out = []
    for uid in dict.fromkeys(ids):
        u = ctx.db.get(User, uid)
        if not u or u.firm_id != ctx.firm_id or not u.is_active:
            raise ValidationFailed("Attendees must be active users of this firm.")
        out.append(uid)
    return out


def create_event(ctx: Ctx, *, title: str, start_at: datetime, end_at: datetime | None = None, kind: str = "appointment",
                 matter_id: uuid.UUID | None = None, location: str | None = None, attendee_ids: list[uuid.UUID] | None = None,
                 description: str | None = None) -> DiaryEvent:
    ctx.require("tasks.write")
    start_at, end_at = aware(start_at), aware(end_at)
    if end_at and end_at <= start_at:
        raise ValidationFailed("The end must be after the start.")
    if matter_id:
        m = ctx.db.get(Matter, matter_id)
        if not m or m.firm_id != ctx.firm_id:
            raise NotFound("Matter not found.")
        if not can_access_matter(ctx, m):
            raise MatterAccessDenied("You do not have access to this matter.")
    e = DiaryEvent(firm_id=ctx.firm_id, matter_id=matter_id, title=title, kind=kind, start_at=start_at, end_at=end_at, location=location,
                   attendee_ids=_check_attendees(ctx, attendee_ids or []), owner_id=ctx.user.id, description=description)
    ctx.db.add(e)
    ctx.db.flush()
    ctx.audit("diary.created", "diary_event", e.id, f"Diary event created: {title[:120]}", matter_id=matter_id, details={"kind": kind})
    return e


def _can_edit(ctx: Ctx, e: DiaryEvent) -> None:
    if e.owner_id != ctx.user.id and not ctx.has("matters.write"):
        raise PermissionDenied("Only the organiser (or a user who can edit matters) can change this event.")


def update_event(ctx: Ctx, e: DiaryEvent, changes: dict, expected_version: int) -> DiaryEvent:
    ctx.require("tasks.write")
    _can_edit(ctx, e)
    if e.version != expected_version:
        raise VersionConflict("This event was changed by someone else. Reload and try again.", details={"current_version": e.version})
    for k in ("start_at", "end_at"):
        if k in changes:
            changes[k] = aware(changes[k])
    if "attendee_ids" in changes:
        changes["attendee_ids"] = _check_attendees(ctx, changes["attendee_ids"] or [])
    for k in ("title", "kind", "start_at", "end_at", "location", "attendee_ids", "description"):
        if k in changes:
            setattr(e, k, changes[k])
    if e.end_at and e.end_at <= e.start_at:
        raise ValidationFailed("The end must be after the start.")
    ctx.db.flush()
    ctx.audit("diary.updated", "diary_event", e.id, f"Diary event updated: {e.title[:120]}", matter_id=e.matter_id, details={"fields": sorted(changes)})
    return e


def delete_event(ctx: Ctx, e: DiaryEvent) -> None:
    ctx.require("tasks.write")
    _can_edit(ctx, e)
    ctx.audit("diary.deleted", "diary_event", e.id, f"Diary event deleted: {e.title[:120]}", matter_id=e.matter_id)
    ctx.db.delete(e)
    ctx.db.flush()


def feed(ctx: Ctx, start: date, end: date, scope: str = "mine", include_tasks: bool = True, include_deadlines: bool = True,
         include_events: bool = True) -> list[dict]:
    """Calendar feed. Deadlines carry `authoritative` (True only if confirmed by a human) and a label; unconfirmed
    suggestions are included but clearly typed so the UI can show them differently."""
    ctx.require("tasks.read")
    if end < start or (end - start).days > 400:
        raise ValidationFailed("Choose a date range of at most 400 days.")
    lo, hi = _day_bounds(start, end)
    db = ctx.db
    refs = {}
    items: list[dict] = []

    def ref(mid):
        if mid is None:
            return None
        if mid not in refs:
            refs[mid] = db.execute(select(Matter.reference).where(Matter.id == mid)).scalar()
        return refs[mid]

    if include_events:
        for e in db.execute(select(DiaryEvent).where(event_clause(ctx, scope), DiaryEvent.start_at >= lo, DiaryEvent.start_at < hi)
                            .order_by(DiaryEvent.start_at)).scalars():
            items.append({"kind": "event", "id": e.id, "title": e.title, "start": e.start_at, "end": e.end_at, "all_day": False, "matter_id": e.matter_id,
                          "matter_reference": ref(e.matter_id), "status": e.kind, "authoritative": None, "label": e.kind.title(),
                          "href": f"/tasks?tab=diary&event={e.id}", "location": e.location, "description": e.description})
    if include_tasks:
        stmt = select(Task).where(task_clause(ctx), Task.status.in_(OPEN_STATES), Task.due_at >= lo, Task.due_at < hi)
        if scope == "mine":
            stmt = stmt.where(Task.assignee_id == ctx.user.id)
        for t in db.execute(stmt.order_by(Task.due_at)).scalars():
            items.append({"kind": "task", "id": t.id, "title": t.title, "start": t.due_at, "end": None, "all_day": False, "matter_id": t.matter_id,
                          "matter_reference": ref(t.matter_id), "status": t.status, "authoritative": None, "label": "Task due",
                          "href": f"/tasks/{t.id}"})
    if include_deadlines:
        stmt = select(Deadline).where(deadline_clause(ctx), Deadline.status != "rejected", Deadline.due_date >= start, Deadline.due_date <= end)
        if scope == "mine":
            stmt = stmt.join(Matter, Matter.id == Deadline.matter_id).where(or_(Matter.responsible_partner_id == ctx.user.id, Matter.fee_earner_id == ctx.user.id))
        for d in db.execute(stmt.order_by(Deadline.due_date)).scalars():
            auth = is_authoritative(d)
            items.append({"kind": "deadline", "id": d.id, "title": d.title if auth else f"[Unconfirmed] {d.title}", "start": d.due_date, "end": None,
                          "all_day": True, "matter_id": d.matter_id, "matter_reference": ref(d.matter_id), "status": d.status, "authoritative": auth,
                          "label": label_for(d), "href": f"/diary/deadlines/{d.id}", "description": d.assumptions})

    def sort_key(i):
        s = i["start"]
        return datetime.combine(s, time.min, tzinfo=LOCAL_TZ) if not isinstance(s, datetime) else s
    items.sort(key=sort_key)
    return items


def ics_items(ctx: Ctx, start: date, end: date, scope: str = "mine") -> list[dict]:
    """ICS carries events, open tasks and CONFIRMED deadlines only. Unconfirmed suggestions are deliberately excluded
    so they cannot be mistaken for authoritative dates once copied into an external calendar."""
    out = []
    for it in feed(ctx, start, end, scope):
        if it["kind"] == "deadline":
            if not it["authoritative"]:
                continue
            it = {**it, "title": f"DEADLINE: {it['title']}"}
        elif it["kind"] == "task":
            it = {**it, "title": f"TASK: {it['title']}", "end": it["start"] + timedelta(minutes=30)}
        out.append(it)
    return out
