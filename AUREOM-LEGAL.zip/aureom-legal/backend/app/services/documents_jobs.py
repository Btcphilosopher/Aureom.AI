"""Worker handlers: malware_scan -> extract_text (OCR when needed) -> index. Payloads carry ids only."""
from __future__ import annotations

import uuid

from app.models import DocumentVersion
from app.services import documents as docs
from app.services.jobs import enqueue, job_handler


@job_handler("malware_scan")
def malware_scan(db, job):
    vid = uuid.UUID(job.payload["version_id"])
    status = docs.run_scan(db, vid)
    if status == "clean":
        enqueue(db, firm_id=job.firm_id, kind="extract_text", payload={"version_id": str(vid)}, idempotency_key=f"extract:{vid}")
    return {"scan_status": status}


@job_handler("extract_text")
def extract_text(db, job):
    vid = uuid.UUID(job.payload["version_id"])
    out = docs.run_extract(db, vid)
    enqueue(db, firm_id=job.firm_id, kind="index", payload={"version_id": str(vid)}, idempotency_key=f"index:{vid}")
    return out


@job_handler("index")
def index(db, job):
    return docs.run_index(db, uuid.UUID(job.payload["version_id"]))
