from __future__ import annotations

from sqlalchemy.orm import Session

from app.models import Notification


def notify(db: Session, *, firm_id, user_id, kind: str, title: str, body: str | None = None, link: str | None = None, matter_id=None) -> Notification:
    n = Notification(firm_id=firm_id, user_id=user_id, kind=kind, title=title[:300], body=body, link=link, matter_id=matter_id)
    db.add(n)
    db.flush()
    return n
