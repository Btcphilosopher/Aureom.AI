"""Contacts (individuals & organisations), addresses, relationships."""
from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy import func, or_, select, text

from app.deps import Ctx
from app.errors import NotFound, ValidationFailed, VersionConflict
from app.models import (Contact, ContactAddress, ContactRelationship, Firm, Matter, MatterParty, OnboardingCheck, OnboardingRecord, Office, User)
from app.permissions import matter_clause
from app.schemas.contacts import RELATION_TYPES

PATCHABLE = ["display_name", "title", "first_name", "last_name", "date_of_birth", "org_name", "company_number", "email", "phone",
             "preferred_channel", "aliases", "responsible_user_id", "office_id", "notes", "status"]


def clean_aliases(aliases: list[str] | None) -> list[str]:
    out: list[str] = []
    for a in aliases or []:
        a = " ".join(a.split())
        if a and a.lower() not in {x.lower() for x in out}:
            out.append(a)
    return out


def _check_user(ctx: Ctx, uid: uuid.UUID | None) -> None:
    if uid is None:
        return
    u = ctx.db.get(User, uid)
    if not u or u.firm_id != ctx.firm_id or not u.is_active:
        raise ValidationFailed("Responsible user not found in this firm.")


def _check_office(ctx: Ctx, oid: uuid.UUID | None) -> None:
    if oid is None:
        return
    o = ctx.db.get(Office, oid)
    if not o or o.firm_id != ctx.firm_id:
        raise ValidationFailed("Office not found in this firm.")


def get_contact(ctx: Ctx, contact_id: uuid.UUID) -> Contact:
    c = ctx.db.get(Contact, contact_id)
    if not c or c.firm_id != ctx.firm_id:
        raise NotFound("Contact not found.")
    return c


def next_client_ref(ctx: Ctx) -> str:
    firm = ctx.db.get(Firm, ctx.firm_id)
    prefix = (firm.settings or {}).get("client_reference_prefix", "PCS")
    ctx.db.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": f"clientref:{ctx.firm_id}"})
    like = f"{prefix}-C%"
    refs = ctx.db.execute(select(Contact.client_ref).where(Contact.firm_id == ctx.firm_id, Contact.client_ref.like(like))).scalars().all()
    nums = [int(r.rsplit("C", 1)[1]) for r in refs if r and r.rsplit("C", 1)[1].isdigit()]
    return f"{prefix}-C{(max(nums) if nums else 1000) + 1:05d}"


def make_client(ctx: Ctx, contact: Contact) -> Contact:
    """Give the contact a client reference and mark it as a client (called on onboarding approval)."""
    if not contact.client_ref:
        contact.client_ref = next_client_ref(ctx)
    contact.is_client = True
    if contact.status == "prospect":
        contact.status = "active"
    ctx.db.flush()
    return contact


def create_contact(ctx: Ctx, *, kind: str, display_name: str | None = None, addresses: list[dict] | None = None,
                   is_client: bool = False, **fields: Any) -> Contact:
    ctx.require("clients.write")
    first, last, org = fields.get("first_name"), fields.get("last_name"), fields.get("org_name")
    if kind == "individual":
        display_name = display_name or " ".join(x for x in [first, last] if x)
    else:
        display_name = display_name or org
        fields["org_name"] = org or display_name
    if not display_name:
        raise ValidationFailed("A name is required.")
    _check_user(ctx, fields.get("responsible_user_id"))
    _check_office(ctx, fields.get("office_id"))
    fields["aliases"] = clean_aliases(fields.get("aliases"))
    if "responsible_user_id" not in fields or fields["responsible_user_id"] is None:
        fields["responsible_user_id"] = ctx.user.id if ctx.role_key != "client" else None
    if fields.get("office_id") is None:
        fields["office_id"] = ctx.user.office_id
    c = Contact(firm_id=ctx.firm_id, kind=kind, display_name=display_name, status="prospect", **fields)
    ctx.db.add(c)
    ctx.db.flush()
    for a in addresses or []:
        ctx.db.add(ContactAddress(firm_id=ctx.firm_id, contact_id=c.id, **a))
    if is_client:
        make_client(ctx, c)
    ctx.audit("contact.created", "contact", c.id, f"Created {kind} contact {display_name}", details={"kind": kind, "status": c.status})
    return c


def update_contact(ctx: Ctx, contact: Contact, data: dict, expected_version: int) -> Contact:
    ctx.require("clients.write")
    if contact.status == "merged":
        raise ValidationFailed("A merged contact is read-only; edit the surviving record.", code="contact_merged")
    if contact.version != expected_version:
        raise VersionConflict("This contact was changed by someone else. Reload and try again.")
    changed = []
    for k in PATCHABLE:
        if k in data and (data[k] is not None or k not in ("display_name", "preferred_channel", "status", "aliases")):
            v = clean_aliases(data[k]) if k == "aliases" else data[k]
            if getattr(contact, k) != v:
                setattr(contact, k, v)
                changed.append(k)
    _check_user(ctx, contact.responsible_user_id)
    _check_office(ctx, contact.office_id)
    if "status" in changed and contact.status == "active" and not contact.is_client:
        pass
    ctx.db.flush()
    ctx.audit("contact.updated", "contact", contact.id, f"Updated contact {contact.display_name}", details={"fields": changed})
    return contact


def set_primary_address(ctx: Ctx, contact_id: uuid.UUID, keep_id: uuid.UUID) -> None:
    for a in ctx.db.execute(select(ContactAddress).where(ContactAddress.contact_id == contact_id, ContactAddress.id != keep_id)).scalars():
        a.is_primary = False


def add_address(ctx: Ctx, contact: Contact, data: dict) -> ContactAddress:
    ctx.require("clients.write")
    a = ContactAddress(firm_id=ctx.firm_id, contact_id=contact.id, **data)
    ctx.db.add(a)
    ctx.db.flush()
    if a.is_primary:
        set_primary_address(ctx, contact.id, a.id)
    ctx.audit("contact.address_added", "contact", contact.id, f"Added address to {contact.display_name}")
    return a


def get_address(ctx: Ctx, contact: Contact, address_id: uuid.UUID) -> ContactAddress:
    a = ctx.db.get(ContactAddress, address_id)
    if not a or a.contact_id != contact.id or a.firm_id != ctx.firm_id:
        raise NotFound("Address not found.")
    return a


def update_address(ctx: Ctx, contact: Contact, address_id: uuid.UUID, data: dict) -> ContactAddress:
    ctx.require("clients.write")
    a = get_address(ctx, contact, address_id)
    for k, v in data.items():
        if v is not None:
            setattr(a, k, v)
    ctx.db.flush()
    if a.is_primary:
        set_primary_address(ctx, contact.id, a.id)
    ctx.audit("contact.address_updated", "contact", contact.id, f"Updated address for {contact.display_name}")
    return a


def delete_address(ctx: Ctx, contact: Contact, address_id: uuid.UUID) -> None:
    ctx.require("clients.write")
    a = get_address(ctx, contact, address_id)
    ctx.db.delete(a)
    ctx.audit("contact.address_removed", "contact", contact.id, f"Removed address from {contact.display_name}")


def add_relationship(ctx: Ctx, contact: Contact, data: dict) -> ContactRelationship:
    ctx.require("clients.write")
    if data["relation_type"] not in RELATION_TYPES:
        raise ValidationFailed(f"Unknown relationship type. Use one of: {', '.join(RELATION_TYPES)}")
    other = get_contact(ctx, data["to_contact_id"])
    if other.id == contact.id:
        raise ValidationFailed("A contact cannot be related to itself.")
    if other.status == "merged" or contact.status == "merged":
        raise ValidationFailed("Cannot create relationships with a merged contact.")
    dup = ctx.db.execute(select(ContactRelationship).where(ContactRelationship.from_contact_id == contact.id, ContactRelationship.to_contact_id == other.id,
                                                          ContactRelationship.relation_type == data["relation_type"])).scalars().first()
    if dup:
        raise ValidationFailed("That relationship already exists.", code="duplicate_relationship")
    r = ContactRelationship(firm_id=ctx.firm_id, from_contact_id=contact.id, **data)
    ctx.db.add(r)
    ctx.db.flush()
    ctx.audit("contact.relationship_added", "contact", contact.id, f"{contact.display_name} {data['relation_type']} {other.display_name}",
              details={"to": str(other.id), "type": data["relation_type"]})
    return r


def get_relationship(ctx: Ctx, contact: Contact, rid: uuid.UUID) -> ContactRelationship:
    r = ctx.db.get(ContactRelationship, rid)
    if not r or r.firm_id != ctx.firm_id or contact.id not in (r.from_contact_id, r.to_contact_id):
        raise NotFound("Relationship not found.")
    return r


def update_relationship(ctx: Ctx, contact: Contact, rid: uuid.UUID, data: dict) -> ContactRelationship:
    ctx.require("clients.write")
    r = get_relationship(ctx, contact, rid)
    if data.get("relation_type") is not None and data["relation_type"] not in RELATION_TYPES:
        raise ValidationFailed("Unknown relationship type.")
    for k, v in data.items():
        if v is not None:
            setattr(r, k, v)
    ctx.db.flush()
    ctx.audit("contact.relationship_updated", "contact", contact.id, "Updated relationship")
    return r


def delete_relationship(ctx: Ctx, contact: Contact, rid: uuid.UUID) -> None:
    ctx.require("clients.write")
    r = get_relationship(ctx, contact, rid)
    ctx.db.delete(r)
    ctx.audit("contact.relationship_removed", "contact", contact.id, "Removed relationship")


# --------------------------------------------------------------------------- serialisation
def user_names(ctx: Ctx, ids) -> dict:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    return {u.id: u.name for u in ctx.db.execute(select(User).where(User.id.in_(ids))).scalars()}


def contact_out(c: Contact, names: dict | None = None) -> dict:
    return {
        "id": str(c.id), "kind": c.kind, "display_name": c.display_name, "title": c.title, "first_name": c.first_name, "last_name": c.last_name,
        "date_of_birth": c.date_of_birth.isoformat() if c.date_of_birth else None, "org_name": c.org_name, "company_number": c.company_number,
        "email": c.email, "phone": c.phone, "preferred_channel": c.preferred_channel, "aliases": list(c.aliases or []),
        "client_ref": c.client_ref, "is_client": c.is_client, "status": c.status,
        "responsible_user_id": str(c.responsible_user_id) if c.responsible_user_id else None,
        "responsible_name": (names or {}).get(c.responsible_user_id),
        "office_id": str(c.office_id) if c.office_id else None, "notes": c.notes,
        "merged_into_id": str(c.merged_into_id) if c.merged_into_id else None, "version": c.version,
        "created_at": c.created_at.isoformat(), "updated_at": c.updated_at.isoformat(),
    }


def list_contacts(ctx: Ctx, *, q=None, kind=None, status=None, is_client=None, responsible_user_id=None, include_merged=False):
    stmt = select(Contact).where(Contact.firm_id == ctx.firm_id)
    if status:
        stmt = stmt.where(Contact.status == status)
    elif not include_merged:
        stmt = stmt.where(Contact.status != "merged")
    if kind:
        stmt = stmt.where(Contact.kind == kind)
    if is_client is not None:
        stmt = stmt.where(Contact.is_client == is_client)
    if responsible_user_id:
        stmt = stmt.where(Contact.responsible_user_id == responsible_user_id)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Contact.display_name.ilike(like), Contact.email.ilike(like), Contact.client_ref.ilike(like),
                              Contact.org_name.ilike(like), Contact.company_number.ilike(like),
                              func.array_to_string(Contact.aliases, " ").ilike(like)))
    return stmt.order_by(Contact.display_name, Contact.id)


def contact_detail(ctx: Ctx, c: Contact) -> dict:
    db = ctx.db
    addrs = db.execute(select(ContactAddress).where(ContactAddress.contact_id == c.id).order_by(ContactAddress.is_primary.desc(), ContactAddress.kind)).scalars().all()
    rels = db.execute(select(ContactRelationship).where(or_(ContactRelationship.from_contact_id == c.id, ContactRelationship.to_contact_id == c.id))).scalars().all()
    other_ids = {r.to_contact_id if r.from_contact_id == c.id else r.from_contact_id for r in rels}
    others = {o.id: o for o in db.execute(select(Contact).where(Contact.id.in_(other_ids))).scalars()} if other_ids else {}
    # roles on matters, restricted/walled matters excluded for this viewer
    rows = db.execute(
        select(MatterParty, Matter).join(Matter, Matter.id == MatterParty.matter_id)
        .where(MatterParty.contact_id == c.id, matter_clause(ctx)).order_by(Matter.reference)
    ).all()
    by_matter: dict[uuid.UUID, dict] = {}
    for mp, m in rows:
        e = by_matter.setdefault(m.id, {"matter_id": str(m.id), "reference": m.reference, "title": m.title, "status": m.status, "roles": []})
        e["roles"].append(mp.role)
    hidden = db.execute(select(func.count(MatterParty.id)).where(MatterParty.contact_id == c.id)).scalar_one() - len(rows)
    ob = db.execute(select(OnboardingRecord).where(OnboardingRecord.contact_id == c.id).order_by(OnboardingRecord.created_at.desc())).scalars().first()
    names = user_names(ctx, [c.responsible_user_id])
    out = contact_out(c, names)
    out.update({
        "addresses": [{"id": str(a.id), "kind": a.kind, "line1": a.line1, "line2": a.line2, "city": a.city, "county": a.county,
                       "postcode": a.postcode, "country": a.country, "is_primary": a.is_primary} for a in addrs],
        "relationships": [{
            "id": str(r.id), "relation_type": r.relation_type, "direction": "outgoing" if r.from_contact_id == c.id else "incoming",
            "other": {"id": str((o := others[r.to_contact_id if r.from_contact_id == c.id else r.from_contact_id]).id), "display_name": o.display_name, "kind": o.kind},
            "start_date": r.start_date.isoformat() if r.start_date else None, "end_date": r.end_date.isoformat() if r.end_date else None, "notes": r.notes,
        } for r in rels],
        "matters": list(by_matter.values()),
        "restricted_matters_hidden": max(hidden, 0),
        "onboarding": {"status": ob.status if ob else "not_started", "record_id": str(ob.id) if ob else None,
                       "simulated_notice": "Identity checks in this build are SIMULATED demonstrations, not verified identity checks."},
    })
    if c.merged_into_id:
        t = db.get(Contact, c.merged_into_id)
        out["merged_into"] = {"id": str(t.id), "display_name": t.display_name} if t else None
    return out
