"""PostgreSQL-backed job queue (FOR UPDATE SKIP LOCKED). Payloads carry ids only - never document text."""
from __future__ import annotations

import logging
import os
import socket
import traceback
import uuid
from datetime import datetime, timedelta, timezone
from typing import Callable

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.db.session import bind_firm, new_session
from app.models import Job

log = logging.getLogger("aureom.jobs")
HANDLERS: dict[str, Callable[[Session, Job], dict | None]] = {}
WORKER_ID = f"{socket.gethostname()}:{os.getpid()}"


def job_handler(kind: str):
    def deco(fn):
        HANDLERS[kind] = fn
        return fn
    return deco


def enqueue(db: Session, *, firm_id, kind: str, payload: dict, idempotency_key: str | None = None,
            run_after: datetime | None = None, max_attempts: int = 3) -> Job:
    if idempotency_key:
        existing = db.execute(select(Job).where(Job.firm_id == firm_id, Job.idempotency_key == idempotency_key)).scalar_one_or_none()
        if existing:
            return existing
    job = Job(firm_id=firm_id, kind=kind, payload=payload, idempotency_key=idempotency_key, max_attempts=max_attempts,
              run_after=run_after or datetime.now(timezone.utc))
    db.add(job)
    db.flush()
    return job


def claim_next(db: Session, kinds: list[str] | None = None) -> Job | None:
    now = datetime.now(timezone.utc)
    stmt = select(Job).where(Job.status == "queued", Job.run_after <= now).order_by(Job.created_at).limit(1).with_for_update(skip_locked=True)
    if kinds:
        stmt = stmt.where(Job.kind.in_(kinds))
    job = db.execute(stmt).scalar_one_or_none()
    if job:
        job.status, job.locked_at, job.locked_by = "running", now, WORKER_ID
        job.attempts += 1
        db.flush()
    return job


def run_one(kinds: list[str] | None = None) -> bool:
    """Claim and run a single job. Returns False when the queue is empty. Handlers run in the job's firm context."""
    with new_session() as s:
        job = claim_next(s, kinds)
        if not job:
            return False
        job_id, firm_id, kind = job.id, job.firm_id, job.kind
        s.commit()
    with new_session(firm_id) as s:
        job = s.get(Job, job_id)
        handler = HANDLERS.get(kind)
        try:
            if handler is None:
                raise RuntimeError(f"no handler registered for job kind '{kind}'")
            bind_firm(s, firm_id)
            result = handler(s, job)
            job = s.get(Job, job_id)
            job.status, job.result, job.finished_at = "done", result or {}, datetime.now(timezone.utc)
            s.commit()
        except Exception as exc:  # noqa: BLE001
            s.rollback()
            log.warning("job %s (%s) failed: %s", job_id, kind, type(exc).__name__)  # no payload/content in logs
            job = s.get(Job, job_id)
            job.last_error = f"{type(exc).__name__}: {str(exc)[:300]}"
            if job.attempts >= job.max_attempts:
                job.status, job.finished_at = "failed", datetime.now(timezone.utc)
            else:
                job.status = "queued"
                job.run_after = datetime.now(timezone.utc) + timedelta(seconds=2 ** job.attempts)
            s.commit()
    return True


def run_all_pending(limit: int = 200, kinds: list[str] | None = None) -> int:
    """Drain the queue (used by tests, the embedded worker and `python -m app.worker --once`)."""
    n = 0
    while n < limit and run_one(kinds):
        n += 1
    return n
