"""Bank statement lines, receipts and reconciliation workflow.

A receipt is cash received - NOT earned revenue. Recording a receipt creates a payment and a DRAFT journal
(office: Dr bank / Cr unallocated receipts; client money: Dr client bank / Cr the matter's client account) that must be
authorised and posted like any other journal. Reconciliation matches statement lines to posted bank-account journal
lines; sign-off needs a nil difference and a different person from the preparer."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import and_, exists, func, select
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.errors import InvalidState, NotFound, PermissionDenied, ValidationFailed
from app.integrations import base as integrations
from app.models import BankStatementLine, Journal, JournalLine, LedgerAccount, Payment, Reconciliation
from app.money import ZERO, q
from app.services import ledger as led
from app.services.ledger import get_matter_for, require_human
from app.services.matter_finance import POSTED


# ------------------------------------------------------------------------------------------ bank feed
def import_statement_lines(ctx: Ctx, bank_account_id: uuid.UUID, lines: list[dict]) -> dict:
    """Idempotent import keyed on (firm, external_id). `lines`: dicts with external_id, txn_date, description, amount, reference."""
    ctx.require("ledger.post")
    acct = ctx.db.get(LedgerAccount, bank_account_id)
    if not acct or acct.firm_id != ctx.firm_id or not acct.is_bank:
        raise NotFound("Bank account not found.")
    created = skipped = 0
    for l in lines:
        exists_ = ctx.db.execute(select(BankStatementLine.id).where(BankStatementLine.firm_id == ctx.firm_id, BankStatementLine.external_id == l["external_id"])).first()
        if exists_:
            skipped += 1
            continue
        ctx.db.add(BankStatementLine(firm_id=ctx.firm_id, bank_account_id=acct.id, ledger=acct.ledger, txn_date=l["txn_date"], description=l["description"][:300],
                                     reference=l.get("reference"), amount=q(Decimal(str(l["amount"]))), currency=l.get("currency", acct.currency),
                                     external_id=l["external_id"], status="unmatched"))
        created += 1
    ctx.db.flush()
    ctx.audit("bank_feed.imported", "bank_account", acct.id, f"{created} statement line(s) imported", details={"created": created, "skipped": skipped, "ledger": acct.ledger})
    return {"created": created, "skipped": skipped}


def sync_bank_feed(ctx: Ctx, ledger: str) -> dict:
    ctx.require("ledger.post")
    prov = integrations.get_available("banking")
    key = "bank_client" if ledger == "client" else "bank_office"
    acct = led.system_account(ctx.db, ctx.firm_id, key, ledger)
    dtos = prov.fetch_statement(ledger)  # type: ignore[attr-defined]
    res = import_statement_lines(ctx, acct.id, [{"external_id": d.external_id, "txn_date": d.txn_date, "description": d.description, "reference": d.reference,
                                                 "amount": d.amount, "currency": d.currency} for d in dtos])
    res.update({"provider": prov.info().provider, "mode": prov.info().mode, "bank_account_id": acct.id, "synthetic": prov.info().mode == "mock"})
    return res


# ------------------------------------------------------------------------------------------ receipts
def record_receipt(ctx: Ctx, bank_line_id: uuid.UUID, *, matter_id: uuid.UUID | None = None, received_from_id: uuid.UUID | None = None,
                   reference: str | None = None, as_client_money: bool | None = None) -> Payment:
    """Record a bank receipt. Office receipts credit *unallocated receipts* (suspense); client money credits the matter's client account.
    The journal is created as a draft with an approval request - nothing is posted without authorisation."""
    ctx.require("ledger.post")
    require_human(ctx, "recording receipts")
    line = ctx.db.execute(select(BankStatementLine).where(BankStatementLine.id == bank_line_id, BankStatementLine.firm_id == ctx.firm_id)
                          .with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
    if not line:
        raise NotFound("Statement line not found.")
    if line.amount <= 0:
        raise ValidationFailed("Only incoming (positive) statement lines can be recorded as receipts.")
    if line.payment_id:
        raise InvalidState("This statement line has already been recorded as a receipt.", code="already_recorded")
    ledger = line.ledger
    if as_client_money is not None and as_client_money != (ledger == "client"):
        raise ValidationFailed("The statement line belongs to the other ledger; office and client money are recorded against their own bank accounts.")
    matter = get_matter_for(ctx, matter_id) if matter_id else None
    amount = q(line.amount)
    if ledger == "client":
        if not matter:
            raise ValidationFailed("Client money must be recorded against a matter.")
        caccount = led.client_account_for_matter(ctx, matter.id)
        lines = [{"account_id": line.bank_account_id, "debit": amount, "matter_id": matter.id},
                 {"account_id": caccount.id, "credit": amount, "matter_id": matter.id}]
    else:
        lines = [{"account_id": line.bank_account_id, "debit": amount, "matter_id": matter.id if matter else None},
                 {"system_key": "unallocated_receipts", "credit": amount, "matter_id": matter.id if matter else None}]
    pay = Payment(firm_id=ctx.firm_id, bank_statement_line_id=line.id, ledger=ledger, matter_id=matter.id if matter else None,
                  received_from_id=received_from_id or (matter.client_id if matter else None), amount=amount, currency=line.currency, received_on=line.txn_date,
                  reference=reference or line.reference, status="pending_authorisation", recorded_by=ctx.user.id)
    ctx.db.add(pay)
    ctx.db.flush()
    j = led.create_journal(ctx, ledger=ledger, reference=f"RCPT-{line.external_id}"[:60], description=f"Receipt: {line.description}"[:400], effective_date=line.txn_date,
                           lines=lines, source_type="receipt", source_id=pay.id, matter_id=matter.id if matter else None, currency=line.currency, submit=True)
    pay.receipt_journal_id = j.id
    line.payment_id = pay.id
    ctx.db.flush()
    ctx.audit("receipt.recorded", "payment", pay.id, f"{ledger.title()} receipt of {amount} recorded (awaiting authorisation)", matter_id=pay.matter_id,
              details={"amount": str(amount), "ledger": ledger, "revenue_recognised": False})
    return pay


# ------------------------------------------------------------------------------------------ matching
def _bank_journal_lines(db: Session, firm_id, bank_account_id, period_end: date | None, unmatched_only: bool = True):
    stmt = (select(JournalLine, Journal).join(Journal, Journal.id == JournalLine.journal_id)
            .where(JournalLine.firm_id == firm_id, JournalLine.account_id == bank_account_id, Journal.status.in_(POSTED), JournalLine.reconciliation_id.is_(None)))
    if period_end:
        stmt = stmt.where(Journal.effective_date <= period_end)
    if unmatched_only:
        stmt = stmt.where(~exists().where(BankStatementLine.matched_journal_line_id == JournalLine.id))
    return db.execute(stmt.order_by(Journal.effective_date, JournalLine.id)).all()


def _unmatched_statement_lines(db: Session, firm_id, bank_account_id, period_end: date | None) -> list[BankStatementLine]:
    stmt = select(BankStatementLine).where(BankStatementLine.firm_id == firm_id, BankStatementLine.bank_account_id == bank_account_id,
                                           BankStatementLine.status == "unmatched")
    if period_end:
        stmt = stmt.where(BankStatementLine.txn_date <= period_end)
    return list(db.execute(stmt.order_by(BankStatementLine.txn_date, BankStatementLine.id)).scalars())


def suggest_matches(db: Session, firm_id, bank_account_id, period_end: date | None = None) -> list[dict]:
    """Exact-amount/direction pairs; each journal line used once; nearest date wins."""
    jls = [(jl, j) for jl, j in _bank_journal_lines(db, firm_id, bank_account_id, None)]
    used: set = set()
    out = []
    for sl in _unmatched_statement_lines(db, firm_id, bank_account_id, period_end):
        best = None
        for jl, j in jls:
            if jl.id in used:
                continue
            amt = q(jl.debit) if sl.amount > 0 else -q(jl.credit)
            if amt != q(sl.amount) or (sl.amount > 0 and jl.credit > 0) or (sl.amount < 0 and jl.debit > 0):
                continue
            gap = abs((j.effective_date - sl.txn_date).days)
            if best is None or gap < best[0]:
                best = (gap, jl, j)
        if best:
            used.add(best[1].id)
            out.append({"bank_line_id": sl.id, "journal_line_id": best[1].id, "journal_id": best[2].id, "amount": q(sl.amount), "date_gap_days": best[0],
                        "statement_description": sl.description, "journal_reference": best[2].reference})
    return out


def match_lines(ctx: Ctx, pairs: list[dict]) -> int:
    ctx.require("ledger.reconcile")
    require_human(ctx, "reconciliation matching")
    n = 0
    for p in pairs:
        sl = ctx.db.execute(select(BankStatementLine).where(BankStatementLine.id == p["bank_line_id"], BankStatementLine.firm_id == ctx.firm_id)
                            .with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
        jl = ctx.db.get(JournalLine, p["journal_line_id"])
        if not sl or not jl or jl.firm_id != ctx.firm_id:
            raise NotFound("Statement line or journal line not found.")
        j = ctx.db.get(Journal, jl.journal_id)
        if sl.status != "unmatched":
            raise InvalidState("Statement line is already matched.")
        if jl.account_id != sl.bank_account_id or j.status not in POSTED:
            raise ValidationFailed("The journal line must be a posted entry on the same bank account.")
        if ctx.db.execute(select(BankStatementLine.id).where(BankStatementLine.matched_journal_line_id == jl.id)).first():
            raise InvalidState("That journal line is already matched to another statement line.")
        expected = q(jl.debit) if jl.debit > 0 else -q(jl.credit)
        if expected != q(sl.amount):
            raise ValidationFailed(f"Amount/direction mismatch: statement {sl.amount} vs ledger {expected}.", code="match_mismatch")
        sl.matched_journal_line_id, sl.status = jl.id, "matched"
        n += 1
    ctx.db.flush()
    if n:
        ctx.audit("reconciliation.matched", "bank_statement_line", None, f"{n} statement line(s) matched to ledger entries", details={"matched": n})
    return n


# ------------------------------------------------------------------------------------------ reconciliation
def ledger_bank_balance(db: Session, bank_account_id, as_of: date) -> Decimal:
    d, c = db.execute(select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
                      .join(Journal, Journal.id == JournalLine.journal_id)
                      .where(JournalLine.account_id == bank_account_id, Journal.status.in_(POSTED), Journal.effective_date <= as_of)).one()
    return q(Decimal(d) - Decimal(c))


def _position(db: Session, rec: Reconciliation) -> dict:
    ledger_bal = ledger_bank_balance(db, rec.bank_account_id, rec.period_end)
    unmatched_stmt = _unmatched_statement_lines(db, rec.firm_id, rec.bank_account_id, rec.period_end)
    unmatched_ledger = _bank_journal_lines(db, rec.firm_id, rec.bank_account_id, rec.period_end)
    diff = q(rec.statement_balance) - ledger_bal
    return {"ledger_balance": ledger_bal, "difference": diff, "unmatched_statement_lines": unmatched_stmt, "unreconciled_journal_lines": unmatched_ledger,
            "can_sign_off": diff == 0 and not unmatched_stmt and not unmatched_ledger}


def create_reconciliation(ctx: Ctx, *, bank_account_id: uuid.UUID, period_end: date, statement_balance: Decimal, notes: str | None = None) -> Reconciliation:
    ctx.require("ledger.reconcile")
    require_human(ctx, "reconciliation")
    acct = ctx.db.get(LedgerAccount, bank_account_id)
    if not acct or acct.firm_id != ctx.firm_id or not acct.is_bank:
        raise NotFound("Bank account not found.")
    rec = Reconciliation(firm_id=ctx.firm_id, ledger=acct.ledger, bank_account_id=acct.id, period_end=period_end, statement_balance=q(Decimal(str(statement_balance))),
                         ledger_balance=ZERO, difference=ZERO, status="draft", prepared_by=ctx.user.id, notes=notes)
    ctx.db.add(rec)
    ctx.db.flush()
    refresh(ctx, rec)
    ctx.audit("reconciliation.prepared", "reconciliation", rec.id, f"{acct.ledger.title()} bank reconciliation prepared to {period_end}", details={"difference": str(rec.difference)})
    return rec


def refresh(ctx: Ctx, rec: Reconciliation) -> dict:
    if rec.status != "draft":
        raise InvalidState("A signed-off reconciliation cannot be recalculated.")
    pos = _position(ctx.db, rec)
    rec.ledger_balance, rec.difference = pos["ledger_balance"], pos["difference"]
    ctx.db.flush()
    return pos


def sign_off(ctx: Ctx, reconciliation_id: uuid.UUID) -> Reconciliation:
    ctx.require("ledger.reconcile")
    require_human(ctx, "reconciliation sign-off")
    rec = ctx.db.execute(select(Reconciliation).where(Reconciliation.id == reconciliation_id, Reconciliation.firm_id == ctx.firm_id)
                         .with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
    if not rec:
        raise NotFound("Reconciliation not found.")
    if rec.status != "draft":
        raise InvalidState("This reconciliation is already signed off.")
    if rec.prepared_by == ctx.user.id:
        raise PermissionDenied("Four-eyes control: the preparer of a reconciliation cannot sign it off.", code="four_eyes_required")
    pos = refresh(ctx, rec)
    if pos["difference"] != 0:
        raise InvalidState(f"Cannot sign off: difference between statement and ledger is {pos['difference']}, not nil.", code="reconciliation_difference")
    if pos["unmatched_statement_lines"] or pos["unreconciled_journal_lines"]:
        raise InvalidState(f"Cannot sign off: {len(pos['unmatched_statement_lines'])} statement line(s) and {len(pos['unreconciled_journal_lines'])} ledger entr(ies) remain unmatched.",
                           code="unmatched_items")
    now = datetime.now(timezone.utc)
    matched = ctx.db.execute(select(BankStatementLine).where(BankStatementLine.firm_id == ctx.firm_id, BankStatementLine.bank_account_id == rec.bank_account_id,
                                                              BankStatementLine.status == "matched", BankStatementLine.txn_date <= rec.period_end)).scalars().all()
    for sl in matched:
        sl.status, sl.reconciliation_id = "reconciled", rec.id
        jl = ctx.db.get(JournalLine, sl.matched_journal_line_id)
        jl.reconciliation_id, jl.reconciled_at = rec.id, now
    rec.status, rec.signed_off_by, rec.signed_off_at = "signed_off", ctx.user.id, now
    ctx.db.flush()
    ctx.audit("reconciliation.signed_off", "reconciliation", rec.id, f"{rec.ledger.title()} bank reconciliation to {rec.period_end} signed off",
              details={"prepared_by": str(rec.prepared_by), "lines": len(matched), "statement_balance": str(rec.statement_balance)})
    return rec
