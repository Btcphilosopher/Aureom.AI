"""Conflict searching and human review. The system only FLAGS potential matches; it never declares a matter
conflict-free. Every search needs an explicit human decision, and every review step is appended to the history."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select

from app.deps import Ctx
from app.errors import InvalidState, NotFound, ValidationFailed, VersionConflict
from app.models import (ConflictMatch, ConflictReviewEvent, ConflictSearch, Contact, ContactRelationship, Matter, MatterParty, User)
from app.permissions import can_access_matter
from app.services.contacts import get_contact, user_names
from app.services.duplicates import name_similarity, norm_name

FUZZY_MIN = 0.82
ADVERSE_ROLES = {"counterparty", "counterparty_solicitor"}


def _cand_names(c: Contact) -> list[tuple[str, str, str]]:
    """(match_kind, raw value, normalised) for every name a contact can be found by."""
    org = c.kind == "organisation"
    out = [("name", c.display_name, norm_name(c.display_name, org=org))]
    if c.org_name and c.org_name != c.display_name:
        out.append(("organisation", c.org_name, norm_name(c.org_name, org=True)))
    out += [("alias", a, norm_name(a, org=org)) for a in (c.aliases or [])]
    return [x for x in out if x[2]]


def _match_term(term: str, c: Contact) -> tuple[str, float, str, str] | None:
    """Best (type, score, matched_on, matched_value) for a term against a contact, or None."""
    best = None
    for kind, raw, n in _cand_names(c):
        tn_org = norm_name(term, org=(c.kind == "organisation"))
        if not tn_org:
            return None
        if n == tn_org:
            typ, sc = ("name_exact", 1.0) if kind in ("name", "organisation") else ("alias", 0.95)
            if kind == "organisation":
                typ = "organisation"
        else:
            sc = name_similarity(tn_org, n)
            if sc < FUZZY_MIN:
                continue
            typ = "name_fuzzy"
            sc = round(sc * 0.9, 3)
        if best is None or sc > best[1]:
            best = (typ, sc, kind, raw)
    return best


def _roles_for(db, contact_id: uuid.UUID) -> list[dict]:
    rows = db.execute(select(MatterParty.matter_id, MatterParty.role).where(MatterParty.contact_id == contact_id)).all()
    return [{"matter_id": str(m), "role": r} for m, r in rows]


def _relations_for(db, contact_id: uuid.UUID) -> list[ContactRelationship]:
    return list(db.execute(select(ContactRelationship).where((ContactRelationship.from_contact_id == contact_id) | (ContactRelationship.to_contact_id == contact_id))).scalars())


def run_search(ctx: Ctx, *, terms: list[str] | None = None, subject_contact_id=None, matter_id=None) -> ConflictSearch:
    ctx.require("conflicts.run")
    db = ctx.db
    subject = get_contact(ctx, subject_contact_id) if subject_contact_id else None
    all_terms: list[tuple[str, str | None, uuid.UUID | None]] = []  # (term, origin, source_contact_id)
    for t in terms or []:
        if t and t.strip():
            all_terms.append((" ".join(t.split()), "entered", None))
    exclude: set[uuid.UUID] = set()
    if subject:
        exclude.add(subject.id)
        all_terms += [(subject.display_name, "subject", subject.id)]
        all_terms += [(a, "subject_alias", subject.id) for a in (subject.aliases or [])]
        if subject.org_name and subject.org_name != subject.display_name:
            all_terms.append((subject.org_name, "subject_org", subject.id))
        for r in _relations_for(db, subject.id):
            oid = r.to_contact_id if r.from_contact_id == subject.id else r.from_contact_id
            o = db.get(Contact, oid)
            if o and o.status != "merged":
                all_terms.append((o.display_name, f"related_to_subject:{r.relation_type}", o.id))
                exclude.add(o.id)
    if not all_terms:
        raise ValidationFailed("Provide at least one search term or a subject contact.")
    seen, uniq = set(), []
    for t in all_terms:
        k = (t[0].lower(), t[2])
        if k not in seen:
            seen.add(k); uniq.append(t)
    search = ConflictSearch(firm_id=ctx.firm_id, subject_contact_id=subject.id if subject else None, matter_id=matter_id,
                            terms=[t[0] for t in uniq], requested_by=ctx.user.id, status="pending_review")
    if matter_id:
        m = db.get(Matter, matter_id)
        if not m or m.firm_id != ctx.firm_id:
            raise NotFound("Matter not found.")
        if not can_access_matter(ctx, m):
            raise ValidationFailed("You cannot run a conflict search against a matter you cannot access.")
    db.add(search)
    db.flush()

    contacts = db.execute(select(Contact).where(Contact.firm_id == ctx.firm_id, Contact.status != "merged")).scalars().all()
    found: dict[tuple[uuid.UUID, str], ConflictMatch] = {}

    def add(contact: Contact, term: str, typ: str, score: float, evidence: dict) -> None:
        key = (contact.id, norm_name(term))
        old = found.get(key)
        if old is not None and old.score >= score:
            return
        if old is not None:
            db.delete(old)
            db.flush()
        mt = _roles_for(db, contact.id)
        evidence = {**evidence, "contact": {"id": str(contact.id), "name": contact.display_name, "kind": contact.kind, "status": contact.status, "client_ref": contact.client_ref},
                    "matters": mt, "adverse_hint": any(x["role"] in ADVERSE_ROLES for x in mt)}
        mm = ConflictMatch(firm_id=ctx.firm_id, search_id=search.id, matched_contact_id=contact.id,
                           matched_matter_id=uuid.UUID(mt[0]["matter_id"]) if mt else None, searched_term=term,
                           match_type=typ, score=score, evidence=evidence, disposition="unreviewed")
        db.add(mm)
        found[key] = mm

    direct: list[tuple[Contact, str, float]] = []
    for term, origin, src in uniq:
        for c in contacts:
            if c.id in exclude and c.id != src:
                continue
            if c.id == src or (subject and c.id == subject.id):
                continue
            hit = _match_term(term, c)
            if not hit:
                continue
            typ, score, kind, raw = hit
            add(c, term, typ, score, {"origin": origin, "matched_on": kind, "matched_value": raw})
            direct.append((c, term, score))
    db.flush()
    # relationship matches: people/entities linked to anything that matched directly (directors, shareholders, spouses ...)
    direct_ids = {c.id for c, _, _ in direct}
    for c, term, score in direct:
        for r in _relations_for(db, c.id):
            oid = r.to_contact_id if r.from_contact_id == c.id else r.from_contact_id
            if oid in direct_ids or oid in exclude:
                continue
            o = db.get(Contact, oid)
            if not o or o.status == "merged":
                continue
            rel = f"{c.display_name} {r.relation_type.replace('_', ' ')} {o.display_name}" if r.from_contact_id == c.id else f"{o.display_name} {r.relation_type.replace('_', ' ')} {c.display_name}"
            add(o, term, "relationship", round(score * 0.8, 3), {"origin": "relationship", "via_contact": {"id": str(c.id), "name": c.display_name},
                                                               "relationship": rel, "relation_type": r.relation_type})
    db.flush()
    search.match_count = len(found)
    db.add(ConflictReviewEvent(firm_id=ctx.firm_id, search_id=search.id, actor_id=ctx.user.id, event="search_created", to_value="pending_review",
                               note=f"{len(found)} potential match(es) flagged for human review"))
    db.flush()
    ctx.audit("conflict.search_run", "conflict_search", search.id, f"Conflict search run ({len(found)} potential matches)",
              matter_id=matter_id, details={"matches": len(found), "terms": len(uniq)})
    return search


def get_search(ctx: Ctx, search_id: uuid.UUID) -> ConflictSearch:
    s = ctx.db.get(ConflictSearch, search_id)
    if not s or s.firm_id != ctx.firm_id:
        raise NotFound("Conflict search not found.")
    return s


def _mask_matters(ctx: Ctx, evidence: dict, cache: dict) -> dict:
    """Replace matter details the viewer cannot access with a masked placeholder (no title/reference leak)."""
    out = []
    for m in evidence.get("matters", []):
        mid = uuid.UUID(m["matter_id"])
        if mid not in cache:
            mt = ctx.db.get(Matter, mid)
            if mt and can_access_matter(ctx, mt):
                cache[mid] = {"visible": True, "reference": mt.reference, "title": mt.title, "status": mt.status}
            else:
                p = ctx.db.get(User, mt.responsible_partner_id) if mt else None
                cache[mid] = {"visible": False, "contact": p.name if p else "the responsible partner"}
        info = cache[mid]
        if info["visible"]:
            out.append({"matter_id": m["matter_id"], "role": m["role"], "masked": False, "reference": info["reference"], "title": info["title"], "status": info["status"]})
        else:
            out.append({"matter_id": None, "role": m["role"], "masked": True,
                        "label": f"Restricted matter - details withheld; contact {info['contact']}"})
    return {**evidence, "matters": out}


def search_out(ctx: Ctx, s: ConflictSearch, *, with_history: bool = True) -> dict:
    db = ctx.db
    matches = db.execute(select(ConflictMatch).where(ConflictMatch.search_id == s.id).order_by(ConflictMatch.score.desc(), ConflictMatch.id)).scalars().all()
    cache: dict = {}
    ids = {s.requested_by, s.reviewed_by} | {m.reviewed_by for m in matches}
    events = db.execute(select(ConflictReviewEvent).where(ConflictReviewEvent.search_id == s.id).order_by(ConflictReviewEvent.created_at, ConflictReviewEvent.id)).scalars().all() if with_history else []
    ids |= {e.actor_id for e in events}
    names = user_names(ctx, ids)
    subject = db.get(Contact, s.subject_contact_id) if s.subject_contact_id else None
    unrev = sum(1 for m in matches if m.disposition == "unreviewed")
    return {
        "id": str(s.id), "status": s.status, "terms": list(s.terms), "match_count": s.match_count, "version": s.version,
        "subject_contact": {"id": str(subject.id), "name": subject.display_name} if subject else None,
        "matter_id": str(s.matter_id) if s.matter_id else None,
        "requested_by": str(s.requested_by), "requested_by_name": names.get(s.requested_by), "created_at": s.created_at.isoformat(),
        "reviewed_by": str(s.reviewed_by) if s.reviewed_by else None, "reviewed_by_name": names.get(s.reviewed_by),
        "reviewed_at": s.reviewed_at.isoformat() if s.reviewed_at else None, "review_note": s.review_note,
        "unreviewed_matches": unrev,
        "notice": "Matches are flagged for authorised human review. The system never declares a matter conflict-free.",
        "matches": [{
            "id": str(m.id), "searched_term": m.searched_term, "match_type": m.match_type, "score": m.score,
            "disposition": m.disposition, "note": m.note, "reviewed_by_name": names.get(m.reviewed_by),
            "reviewed_at": m.reviewed_at.isoformat() if m.reviewed_at else None,
            "evidence": _mask_matters(ctx, m.evidence, cache),
        } for m in matches],
        "history": [{"id": str(e.id), "event": e.event, "actor": names.get(e.actor_id), "actor_id": str(e.actor_id), "from": e.from_value, "to": e.to_value,
                     "note": e.note, "match_id": str(e.match_id) if e.match_id else None, "at": e.created_at.isoformat()} for e in events],
    }


def list_searches(ctx: Ctx, *, status=None, subject_contact_id=None, matter_id=None):
    ctx.require("conflicts.run")
    stmt = select(ConflictSearch).where(ConflictSearch.firm_id == ctx.firm_id)
    if status:
        stmt = stmt.where(ConflictSearch.status == status)
    if subject_contact_id:
        stmt = stmt.where(ConflictSearch.subject_contact_id == subject_contact_id)
    if matter_id:
        stmt = stmt.where(ConflictSearch.matter_id == matter_id)
    return stmt.order_by(ConflictSearch.created_at.desc())


def review_match(ctx: Ctx, match_id: uuid.UUID, disposition: str, note: str | None) -> ConflictMatch:
    ctx.require("conflicts.review")
    m = ctx.db.get(ConflictMatch, match_id)
    if not m or m.firm_id != ctx.firm_id:
        raise NotFound("Match not found.")
    s = get_search(ctx, m.search_id)
    if s.status != "pending_review":
        raise InvalidState(f"This search has already been decided ({s.status}); run a new search to re-review.")
    if disposition in ("potential_conflict", "confirmed_conflict") and not (note or "").strip():
        raise ValidationFailed("A note is required when flagging a potential or confirmed conflict.")
    prev = m.disposition
    m.disposition, m.reviewed_by, m.reviewed_at, m.note = disposition, ctx.user.id, datetime.now(timezone.utc), note
    ctx.db.add(ConflictReviewEvent(firm_id=ctx.firm_id, search_id=s.id, match_id=m.id, actor_id=ctx.user.id, event="match_disposition",
                                   from_value=prev, to_value=disposition, note=note))
    ctx.db.flush()
    ctx.audit("conflict.match_reviewed", "conflict_search", s.id, f"Match reviewed: {disposition}", matter_id=s.matter_id,
              details={"match": str(m.id), "from": prev, "to": disposition})
    return m


def decide_search(ctx: Ctx, search_id: uuid.UUID, decision: str, note: str | None, expected_version: int | None = None) -> ConflictSearch:
    ctx.require("conflicts.review")
    s = get_search(ctx, search_id)
    if expected_version is not None and s.version != expected_version:
        raise VersionConflict("This search was changed by someone else.")
    if s.status != "pending_review":
        raise InvalidState(f"This search has already been decided ({s.status}).")
    matches = ctx.db.execute(select(ConflictMatch).where(ConflictMatch.search_id == s.id)).scalars().all()
    unrev = [m for m in matches if m.disposition == "unreviewed"]
    if unrev:
        raise ValidationFailed(f"{len(unrev)} match(es) still need a disposition before a decision can be recorded.", code="matches_unreviewed",
                               details={"unreviewed": [str(m.id) for m in unrev]})
    flagged = [m for m in matches if m.disposition in ("potential_conflict", "confirmed_conflict")]
    if flagged and not (note or "").strip():
        raise ValidationFailed("A decision note is required when any match is a potential or confirmed conflict.", code="note_required")
    if decision == "cleared_by_reviewer" and any(m.disposition == "confirmed_conflict" for m in matches):
        raise ValidationFailed("A search with a confirmed conflict cannot be cleared; record 'conflict_confirmed' or 'referred'.")
    if not matches and not (note or "").strip():
        raise ValidationFailed("Record a note explaining the basis for the decision (no matches were flagged; this is still a human decision).", code="note_required")
    prev = s.status
    s.status, s.reviewed_by, s.reviewed_at, s.review_note = decision, ctx.user.id, datetime.now(timezone.utc), note
    ctx.db.add(ConflictReviewEvent(firm_id=ctx.firm_id, search_id=s.id, actor_id=ctx.user.id, event="search_decision", from_value=prev, to_value=decision, note=note))
    ctx.db.flush()
    ctx.audit("conflict.search_decided", "conflict_search", s.id, f"Conflict search decision: {decision}", matter_id=s.matter_id,
              details={"decision": decision, "flagged": len(flagged)})
    return s


def cleared_search_for_matter(ctx: Ctx, matter: Matter) -> ConflictSearch | None:
    """Most recent human-cleared search linked to the matter, or to its client."""
    from sqlalchemy import or_
    cond = [ConflictSearch.matter_id == matter.id, ConflictSearch.subject_contact_id == matter.client_id]
    if matter.conflict_search_id:
        cond.append(ConflictSearch.id == matter.conflict_search_id)
    return ctx.db.execute(select(ConflictSearch).where(ConflictSearch.firm_id == ctx.firm_id, ConflictSearch.status == "cleared_by_reviewer", or_(*cond))
                          .order_by(ConflictSearch.reviewed_at.desc())).scalars().first()
