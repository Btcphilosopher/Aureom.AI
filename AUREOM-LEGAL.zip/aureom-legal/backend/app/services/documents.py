"""Document management: upload/versioning, access rules, extraction/chunking, review/approval/signature, legal hold.

Uploaded files are UNTRUSTED. Nothing is previewed, extracted or served until the scanner reports clean."""
from __future__ import annotations

import email
import io
import re
import uuid
import zipfile
from datetime import date, datetime, timezone
from email import policy as email_policy
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

from sqlalchemy import and_, exists, false, or_, select
from sqlalchemy.orm import Session

from app import audit
from app.config import get_settings
from app.deps import Ctx
from app.errors import InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.integrations import base as integrations
from app.models import (Approval, Document, DocumentChunk, DocumentVersion, Folder, Matter, SignatureRequest, User)
from app.models import Contact
from app.permissions import can_access_matter, can_preview, matter_clause, visible_matter_ids
from app.security import canonical_hash, sha256_hex
from app.services import approvals as approvals_svc
from app.services import filetypes
from app.services.jobs import enqueue
from app.services.notify import notify
from app.storage import get_storage

DOC_TYPES = ["agreement", "engagement_letter", "letter", "advice", "attendance_note", "contract_draft", "contract", "lease", "schedule", "enquiries", "pleading", "note",
             "email_attachment", "id_document", "financial", "template_output", "other"]


# ----------------------------------------------------------------------------------- access
def contact_docs_allowed(ctx: Ctx, write: bool = False) -> bool:
    """Client-level (onboarding) documents are sensitive: onboarding/clients staff only."""
    need = "documents.write" if write else "documents.read"
    return ctx.has(need) and (ctx.has("onboarding.manage") or ctx.has("clients.write"))


def visible_document_clause(ctx: Ctx):
    """SQL predicate for documents the user may see. Matter documents follow matter visibility (restricted/ethical walls)."""
    if not ctx.has("documents.read") or ctx.role_key == "client":
        return false()
    clause = Document.matter_id.in_(visible_matter_ids(ctx))
    if contact_docs_allowed(ctx):
        clause = or_(clause, and_(Document.matter_id.is_(None), Document.contact_id.is_not(None)))
    return and_(Document.firm_id == ctx.firm_id, clause)


def _load_matter(ctx: Ctx, matter_id: uuid.UUID) -> Matter:
    m = ctx.db.get(Matter, matter_id)
    if not m or m.firm_id != ctx.firm_id:
        raise NotFound("Matter not found.")
    if not can_access_matter(ctx, m):
        raise MatterAccessDenied("You do not have access to this matter.")
    return m


def get_document(ctx: Ctx, document_id: uuid.UUID, *, write: bool = False, lock: bool = False) -> Document:
    ctx.require("documents.write" if write else "documents.read")
    stmt = select(Document).where(Document.id == document_id, Document.firm_id == ctx.firm_id)
    if lock:
        stmt = stmt.with_for_update()
    d = ctx.db.execute(stmt).scalar_one_or_none()
    if not d:
        raise NotFound("Document not found.")
    if d.matter_id:
        _load_matter(ctx, d.matter_id)
    elif not contact_docs_allowed(ctx, write):
        raise PermissionDenied("You do not have access to client-level documents.")
    return d


def get_version(ctx: Ctx, doc: Document, version_no: int) -> DocumentVersion:
    v = ctx.db.execute(select(DocumentVersion).where(DocumentVersion.document_id == doc.id, DocumentVersion.version_no == version_no)).scalar_one_or_none()
    if not v:
        raise NotFound("Version not found.")
    return v


def assert_servable(version: DocumentVersion) -> None:
    """Gate for preview/download: only scanned-clean files (or explicit configuration) may be served."""
    if version.scan_status == "clean" or get_settings().allow_unscanned_downloads:
        return
    code = {"infected": "scan_infected", "pending": "scan_pending", "unavailable": "scan_unavailable"}.get(version.scan_status, "scan_failed")
    raise InvalidState(f"This file cannot be opened: malware scan status is '{version.scan_status}'.", code=code, details={"scan_status": version.scan_status})


def matter_for(ctx: Ctx, doc: Document) -> Matter | None:
    return ctx.db.get(Matter, doc.matter_id) if doc.matter_id else None


# ----------------------------------------------------------------------------------- upload / versions
def _next_status_on_new_version(doc: Document) -> str:
    return "draft" if doc.status in ("in_review", "approved", "signature_requested", "signed") else doc.status


def _store_version(ctx: Ctx, doc: Document, *, filename: str, content: bytes, content_type: str, author_id: uuid.UUID,
                   change_note: str | None) -> DocumentVersion:
    db = ctx.db
    n = doc.current_version_no + 1
    sha = sha256_hex(content)
    owner = f"matter-{doc.matter_id}" if doc.matter_id else f"contact-{doc.contact_id}"
    key = f"{ctx.firm_id}/{owner}/{doc.id}/v{n}/{sha}"
    get_storage().put(key, content, content_type)  # write-once: ObjectExists if it somehow already exists
    v = DocumentVersion(firm_id=ctx.firm_id, document_id=doc.id, version_no=n, storage_key=key, sha256=sha, size_bytes=len(content),
                        content_type=content_type, original_filename=filename, author_id=author_id, change_note=change_note)
    db.add(v)
    db.flush()
    doc.current_version_id, doc.current_version_no = v.id, n
    db.flush()
    return v


def _enqueue_pipeline(db: Session, firm_id, version_id) -> None:
    enqueue(db, firm_id=firm_id, kind="malware_scan", payload={"version_id": str(version_id)}, idempotency_key=f"scan:{version_id}")


def upload_document(ctx: Ctx, *, matter_id: uuid.UUID | None = None, contact_id: uuid.UUID | None = None, title: str, doc_type: str = "other",
                    filename: str, content: bytes, folder_id: uuid.UUID | None = None, tags=(), client_visible: bool = False,
                    change_note: str | None = None, document_id: uuid.UUID | None = None, source: str = "upload",
                    _keep_status: bool = False) -> tuple[Document, DocumentVersion]:
    """Create a document (v1) or add a new immutable version to `document_id`."""
    ctx.require("documents.write")
    db = ctx.db
    filename = filetypes.sanitise_filename(filename)
    _, content_type = filetypes.sniff(filename, content)
    if doc_type not in DOC_TYPES:
        raise ValidationFailed(f"Unknown document type '{doc_type}'.", details={"allowed": DOC_TYPES})

    if document_id:
        doc = get_document(ctx, document_id, write=True, lock=True)
        reset = (not _keep_status) and _next_status_on_new_version(doc) != doc.status
        if reset:
            for ap in db.execute(select(Approval).where(Approval.subject_type == "document", Approval.subject_id == doc.id,
                                                        Approval.status.in_(["pending", "approved"]))).scalars():
                ap.status = "superseded"
            doc.status = _next_status_on_new_version(doc)
        v = _store_version(ctx, doc, filename=filename, content=content, content_type=content_type, author_id=ctx.user.id, change_note=change_note)
        ctx.audit("document.version_added", "document", doc.id, f"New version v{v.version_no} added to '{doc.title}'", matter_id=doc.matter_id,
                  details={"version_no": v.version_no, "sha256": v.sha256, "size": v.size_bytes, "status_reset": reset})
    else:
        if not matter_id and not contact_id:
            raise ValidationFailed("A document must belong to a matter or a contact.")
        matter = None
        if matter_id:
            matter = _load_matter(ctx, matter_id)
            contact_id = None
        else:
            if not contact_docs_allowed(ctx, write=True):
                raise PermissionDenied("You do not have permission to add client-level documents.")
            c = db.get(Contact, contact_id)
            if not c or c.firm_id != ctx.firm_id:
                raise NotFound("Contact not found.")
        if folder_id:
            f = db.get(Folder, folder_id)
            if not f or f.firm_id != ctx.firm_id or (matter_id and f.matter_id != matter_id):
                raise ValidationFailed("Folder does not belong to this matter.")
        doc = Document(firm_id=ctx.firm_id, matter_id=matter_id, contact_id=contact_id, folder_id=folder_id, title=title.strip()[:300] or filename,
                       doc_type=doc_type, tags=[t.strip()[:40] for t in tags if t and t.strip()][:20], status="draft", client_visible=False,
                       created_by=ctx.user.id, source=source, current_version_no=0,
                       legal_hold=bool(matter and matter.legal_hold), retention_until=matter.retention_until if matter else None)
        db.add(doc)
        db.flush()
        if client_visible:
            ctx.require("documents.approve")  # sharing a document with a client is a reviewed action
            doc.client_visible = True
        v = _store_version(ctx, doc, filename=filename, content=content, content_type=content_type, author_id=ctx.user.id, change_note=change_note)
        ctx.audit("document.uploaded", "document", doc.id, f"Document '{doc.title}' uploaded (v1)", matter_id=doc.matter_id,
                  details={"sha256": v.sha256, "size": v.size_bytes, "type": doc_type, "content_type": content_type, "source": source})
    _enqueue_pipeline(db, ctx.firm_id, v.id)
    return doc, v


# ----------------------------------------------------------------------------------- extraction
def _split_paragraphs(text: str, *, heuristic: bool = False) -> list[str]:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks = [re.sub(r"[ \t]+", " ", b).strip() for b in re.split(r"\n\s*\n", text)]
    blocks = [b for b in blocks if b]
    if heuristic and len(blocks) <= 1 and blocks and "\n" in blocks[0]:
        paras, cur = [], []
        for line in blocks[0].split("\n"):
            line = line.strip()
            if not line:
                continue
            cur.append(line)
            if re.search(r"[.:;?!]$", line):
                paras.append(" ".join(cur)); cur = []
        if cur:
            paras.append(" ".join(cur))
        return paras
    return [b.replace("\n", " ") if heuristic else b for b in blocks]


class _TextHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.skip += 1
        if tag in ("p", "br", "div", "li", "tr"):
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.skip:
            self.skip -= 1

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def extract_pages(ext: str, data: bytes) -> list[list[str]]:
    """Return pages -> paragraphs. Empty list means 'no extractable text' (route to OCR for pdf/images)."""
    if ext in ("txt", "md"):
        text = data.decode("utf-8", errors="replace")
        pages = text.split("\f")
        return [p for p in ([_split_paragraphs(pg) for pg in pages]) if p]
    if ext == "csv":
        lines = [ln.strip() for ln in data.decode("utf-8", errors="replace").splitlines() if ln.strip()]
        return [lines[i:i + 40] for i in range(0, len(lines), 40)]
    if ext == "pdf":
        from pypdf import PdfReader
        try:
            reader = PdfReader(io.BytesIO(data))
            pages = [_split_paragraphs(pg.extract_text() or "", heuristic=True) for pg in reader.pages[:500]]
        except Exception:  # noqa: BLE001 - malformed untrusted PDF
            raise ValidationFailed("The PDF could not be parsed.", code="pdf_parse_failed")
        return pages if any(pages) else []
    if ext == "docx":
        return _docx_pages(data)
    if ext == "eml":
        msg = email.message_from_bytes(data, policy=email_policy.default)
        head = "\n".join(f"{h}: {msg[h]}" for h in ("From", "To", "Cc", "Date", "Subject") if msg[h])
        body = msg.get_body(preferencelist=("plain", "html"))
        txt = ""
        if body is not None:
            txt = body.get_content()
            if body.get_content_type() == "text/html":
                p = _TextHTML(); p.feed(txt); txt = "".join(p.out)
        return [[head] + _split_paragraphs(txt)]
    return []


def _docx_pages(data: bytes) -> list[list[str]]:
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        info = z.getinfo("word/document.xml")
        if info.file_size > 20 * 1024 * 1024:
            raise ValidationFailed("The document is too large to process.")
        xml = z.read("word/document.xml")
    if b"<!DOCTYPE" in xml or b"<!ENTITY" in xml:  # refuse XML entity tricks in untrusted input
        raise ValidationFailed("The document contains disallowed XML constructs.")
    root = ET.fromstring(xml)
    pages, cur = [], []
    for p in root.iter(W + "p"):
        text = "".join(t.text or "" for t in p.iter(W + "t")).strip()
        if text:
            cur.append(text)
        if any(br.get(W + "type") == "page" for br in p.iter(W + "br")):
            pages.append(cur); cur = []
    if cur:
        pages.append(cur)
    return [pg for pg in pages if pg]


def _write_chunks(db: Session, v: DocumentVersion, doc: Document, pages: list[list[str]], is_ocr: bool) -> int:
    db.query(DocumentChunk).filter(DocumentChunk.version_id == v.id).delete()
    ordinal = 0
    for pno, paras in enumerate(pages, start=1):
        for prno, para in enumerate(paras, start=1):
            for i in range(0, len(para), 4000):
                ordinal += 1
                db.add(DocumentChunk(firm_id=v.firm_id, version_id=v.id, document_id=doc.id, matter_id=doc.matter_id, ordinal=ordinal,
                                     page=pno, paragraph=prno, text=para[i:i + 4000], is_ocr=is_ocr))
    db.flush()
    return ordinal


def _processable(v: DocumentVersion) -> bool:
    return v.scan_status == "clean" or get_settings().allow_unscanned_downloads


# ----------------------------------------------------------------------------------- pipeline steps (used by jobs and inline)
def run_scan(db: Session, version_id: uuid.UUID) -> str:
    v = db.get(DocumentVersion, version_id)
    scanner = integrations.get("malware")
    data = get_storage().get(v.storage_key)
    res = scanner.scan(data, v.original_filename)  # type: ignore[attr-defined]
    v.scan_status, v.scan_detail = res.status, res.detail[:300]
    if res.status != "clean":
        v.ocr_status, v.index_status = "not_needed", "skipped"
    db.flush()
    doc = db.get(Document, v.document_id)
    audit.log(db, firm_id=v.firm_id, action="document.scanned", entity_type="document", entity_id=v.document_id, matter_id=doc.matter_id,
              summary=f"Scan of '{doc.title}' v{v.version_no}: {res.status}", actor_type="system", details={"version_id": str(v.id), "status": res.status})
    if res.status == "infected":
        notify(db, firm_id=v.firm_id, user_id=v.author_id, kind="document_infected", title=f"'{doc.title}' was quarantined",
               body="The malware scan flagged this upload. It cannot be opened or downloaded.", matter_id=doc.matter_id)
    return res.status


def run_extract(db: Session, version_id: uuid.UUID) -> dict:
    v = db.get(DocumentVersion, version_id)
    if not _processable(v):
        return {"skipped": f"scan_status={v.scan_status}"}
    doc = db.get(Document, v.document_id)
    ext = filetypes.extension(v.original_filename)
    data = get_storage().get(v.storage_key)
    try:
        pages = extract_pages(ext, data) if ext not in filetypes.IMAGE_TYPES else []
    except ValidationFailed:
        pages = []
    if pages:
        n = _write_chunks(db, v, doc, pages, is_ocr=False)
        v.ocr_status, v.page_count = "not_needed", len(pages)
        db.flush()
        return {"chunks": n, "ocr": False}
    # no extractable text -> asynchronous OCR via provider interface
    try:
        provider = integrations.get_available("ocr")
        ocr_pages = provider.ocr(data, v.content_type, v.original_filename)  # type: ignore[attr-defined]
        n = _write_chunks(db, v, doc, [_split_paragraphs(p) or [p] for p in ocr_pages], is_ocr=True)
        v.ocr_status = "simulated" if provider.info().mode == "mock" else "done"
        v.page_count = len(ocr_pages)
        db.flush()
        return {"chunks": n, "ocr": True, "simulated": v.ocr_status == "simulated"}
    except Exception as e:  # noqa: BLE001
        v.ocr_status = "failed"
        db.flush()
        return {"error": type(e).__name__}


def run_index(db: Session, version_id: uuid.UUID) -> dict:
    """Full-text indexing is a generated tsvector + GIN index on document_chunks; this step verifies and records readiness."""
    v = db.get(DocumentVersion, version_id)
    from sqlalchemy import func
    n = db.execute(select(func.count()).select_from(DocumentChunk).where(DocumentChunk.version_id == v.id)).scalar_one()
    v.index_status = "done" if n else ("skipped" if v.index_status == "skipped" else "empty")
    db.flush()
    return {"chunks": n}


def process_version_inline(db: Session, version_id: uuid.UUID) -> dict:
    """Run scan -> extract/OCR -> index synchronously (seed data and tests). Caller commits."""
    out = {"scan": run_scan(db, version_id)}
    if out["scan"] == "clean":
        out["extract"] = run_extract(db, version_id)
        out["index"] = run_index(db, version_id)
    return out


# ----------------------------------------------------------------------------------- review / approval / signature
def _approval_payload(doc: Document, v: DocumentVersion) -> dict:
    return {"document_id": str(doc.id), "version_id": str(v.id), "version_no": v.version_no, "sha256": v.sha256}


def request_review(ctx: Ctx, doc_id: uuid.UUID) -> Document:
    doc = get_document(ctx, doc_id, write=True)
    if doc.status not in ("draft",):
        raise InvalidState(f"Only draft documents can be sent for review (status is '{doc.status}').")
    v = ctx.db.get(DocumentVersion, doc.current_version_id)
    approvals_svc.request_approval(ctx, kind="document_approval", subject_type="document", subject_id=doc.id, matter_id=doc.matter_id,
                                   payload=_approval_payload(doc, v), required_permission="documents.approve")
    doc.status = "in_review"
    ctx.audit("document.review_requested", "document", doc.id, f"Review requested for '{doc.title}' v{v.version_no}", matter_id=doc.matter_id)
    return doc


def decide_review(ctx: Ctx, doc_id: uuid.UUID, *, approve: bool, note: str | None) -> Document:
    ctx.require("documents.approve")
    doc = get_document(ctx, doc_id, write=True)
    if doc.status != "in_review":
        raise InvalidState(f"Document is '{doc.status}', not in review.")
    ap = ctx.db.execute(select(Approval).where(Approval.subject_type == "document", Approval.subject_id == doc.id, Approval.kind == "document_approval",
                                               Approval.status == "pending").order_by(Approval.created_at.desc())).scalars().first()
    if not ap:
        raise InvalidState("No pending review request exists for this document.")
    v = ctx.db.get(DocumentVersion, doc.current_version_id)
    if ap.payload_hash != canonical_hash(_approval_payload(doc, v)):
        ap.status = "superseded"
        raise InvalidState("The document changed since review was requested; request review again.", code="approval_stale")
    approvals_svc.decide(ctx, ap.id, approve=approve, note=note)
    doc.status = "approved" if approve else "draft"
    return doc


def supersede(ctx: Ctx, doc_id: uuid.UUID, note: str | None) -> Document:
    ctx.require("documents.approve")
    doc = get_document(ctx, doc_id, write=True)
    doc.status = "superseded"
    ctx.audit("document.superseded", "document", doc.id, f"'{doc.title}' marked superseded", matter_id=doc.matter_id, details={"note": note})
    return doc


def request_signature(ctx: Ctx, doc_id: uuid.UUID, signers: list[dict]) -> SignatureRequest:
    ctx.require("documents.sign")
    doc = get_document(ctx, doc_id, write=True)
    if doc.status != "approved":
        raise InvalidState("Only approved documents can be sent for signature.", code="approval_required")
    if not signers:
        raise ValidationFailed("At least one signer is required.")
    v = ctx.db.get(DocumentVersion, doc.current_version_id)
    ap = ctx.db.execute(select(Approval).where(Approval.subject_type == "document", Approval.subject_id == doc.id, Approval.kind == "document_approval",
                                               Approval.status == "approved").order_by(Approval.decided_at.desc())).scalars().first()
    approvals_svc.assert_approved(ctx, ap.id if ap else None, kind="document_approval", payload=_approval_payload(doc, v), subject_id=doc.id)
    assert_servable(v)
    provider = integrations.get_available("esign")
    info = provider.info()
    ref = provider.create_request(title=doc.title, sha256=v.sha256, signers=signers)  # type: ignore[attr-defined]
    sr = SignatureRequest(firm_id=ctx.firm_id, document_id=doc.id, version_id=v.id, matter_id=doc.matter_id, provider=info.provider,
                          is_simulated=info.mode == "mock", external_ref=ref, requested_by=ctx.user.id, approval_id=ap.id,
                          signers=[{"name": s["name"], "email": s["email"], "status": "sent", "signed_at": None} for s in signers])
    ctx.db.add(sr)
    doc.status = "signature_requested"
    ctx.db.flush()
    ctx.audit("document.signature_requested", "document", doc.id, f"Signature requested for '{doc.title}' ({info.provider})", matter_id=doc.matter_id,
              details={"version_no": v.version_no, "signers": len(signers), "simulated": sr.is_simulated})
    return sr


def simulate_signature_complete(ctx: Ctx, sr_id: uuid.UUID) -> tuple[SignatureRequest, DocumentVersion]:
    ctx.require("documents.sign")
    sr = ctx.db.get(SignatureRequest, sr_id)
    if not sr or sr.firm_id != ctx.firm_id:
        raise NotFound("Signature request not found.")
    doc = get_document(ctx, sr.document_id, write=True)
    provider = integrations.get_available("esign")
    if provider.info().mode != "mock":
        raise PermissionDenied("Simulated completion is only available in mock mode.")
    if sr.status != "sent":
        raise InvalidState(f"Signature request is already '{sr.status}'.")
    src = ctx.db.get(DocumentVersion, sr.version_id)
    now = datetime.now(timezone.utc)
    sr.signers = [{**s, "status": "signed", "signed_at": now.isoformat()} for s in sr.signers]
    sr.status = "signed"
    pages = ctx.db.execute(select(DocumentChunk.text).where(DocumentChunk.version_id == src.id).order_by(DocumentChunk.ordinal)).scalars().all()
    body = "\n\n".join(pages) if pages else "(no extracted text)"
    block = "\n".join(f"- {s['name']} <{s['email']}> signed at {s['signed_at']} (SIMULATED)" for s in sr.signers)
    content = (f"SIGNED COPY - SIMULATED. This is a demonstration artefact; it has no legal effect.\n"
               f"Provider reference: {sr.external_ref}\nSigned version: v{src.version_no} (sha256 {src.sha256})\n\n{body}\n\n--- Signature block ---\n{block}\n").encode()
    v = _store_version(ctx, doc, filename=filetypes.sanitise_filename(f"{doc.title} - signed (simulated).txt"), content=content, content_type="text/plain",
                       author_id=ctx.user.id, change_note="Simulated signed copy")
    doc.status = "signed"
    ctx.audit("document.signed_simulated", "document", doc.id, f"Simulated signature completed for '{doc.title}'", matter_id=doc.matter_id,
              details={"signed_version_no": v.version_no, "source_version_no": src.version_no, "simulated": True})
    _enqueue_pipeline(ctx.db, ctx.firm_id, v.id)
    return sr, v


# ----------------------------------------------------------------------------------- hold / retention / metadata
def set_legal_hold(ctx: Ctx, doc_id: uuid.UUID, hold: bool, reason: str | None) -> Document:
    ctx.require("matters.approve")
    doc = get_document(ctx, doc_id, write=True)
    if hold and not reason:
        raise ValidationFailed("A reason is required to place a legal hold.")
    doc.legal_hold = hold
    ctx.audit("document.legal_hold_set" if hold else "document.legal_hold_cleared", "document", doc.id,
              f"Legal hold {'placed on' if hold else 'released from'} '{doc.title}'", matter_id=doc.matter_id, details={"reason": reason})
    return doc


def set_retention(ctx: Ctx, doc_id: uuid.UUID, retention_until: date | None) -> Document:
    ctx.require("matters.approve")
    doc = get_document(ctx, doc_id, write=True)
    doc.retention_until = retention_until
    ctx.audit("document.retention_set", "document", doc.id, f"Retention date for '{doc.title}' set", matter_id=doc.matter_id,
              details={"retention_until": retention_until})
    return doc


def update_metadata(ctx: Ctx, doc_id: uuid.UUID, data: dict, expected_version: int) -> Document:
    doc = get_document(ctx, doc_id, write=True)
    if doc.version != expected_version:
        raise VersionConflict("This document was changed by someone else. Reload and try again.", details={"current_version": doc.version})
    changes = {}
    if "title" in data and data["title"]:
        changes["title"] = doc.title = data["title"].strip()[:300]
    if "doc_type" in data and data["doc_type"]:
        if data["doc_type"] not in DOC_TYPES:
            raise ValidationFailed(f"Unknown document type '{data['doc_type']}'.")
        changes["doc_type"] = doc.doc_type = data["doc_type"]
    if "tags" in data and data["tags"] is not None:
        doc.tags = [t.strip()[:40] for t in data["tags"] if t.strip()][:20]
        changes["tags"] = doc.tags
    if "folder_id" in data:
        if data["folder_id"]:
            f = ctx.db.get(Folder, data["folder_id"])
            if not f or f.firm_id != ctx.firm_id or f.matter_id != doc.matter_id:
                raise ValidationFailed("Folder does not belong to this matter.")
        doc.folder_id = data["folder_id"]
        changes["folder_id"] = str(data["folder_id"]) if data["folder_id"] else None
    if "client_visible" in data and data["client_visible"] is not None and data["client_visible"] != doc.client_visible:
        ctx.require("documents.approve")  # sharing with a client is a reviewed action
        doc.client_visible = data["client_visible"]
        changes["client_visible"] = doc.client_visible
    ctx.audit("document.updated", "document", doc.id, f"Document '{doc.title}' metadata updated", matter_id=doc.matter_id, details={"changed": list(changes)})
    return doc
