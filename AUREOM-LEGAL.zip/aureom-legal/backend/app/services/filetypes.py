"""Allow-listed file types for UNTRUSTED uploads. A file must match BOTH its extension and its content signature."""
from __future__ import annotations

import io
import re
import unicodedata
import zipfile

from app.config import get_settings
from app.errors import ValidationFailed

ALLOWED: dict[str, str] = {
    "pdf": "application/pdf",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "txt": "text/plain", "md": "text/markdown", "csv": "text/csv",
    "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
    "eml": "message/rfc822",
}
TEXT_TYPES = {"txt", "md", "csv", "eml"}
IMAGE_TYPES = {"png", "jpg", "jpeg"}
_FORBIDDEN_STARTS = (b"MZ", b"\x7fELF", b"PK\x03\x04", b"%PDF", b"\x89PNG", b"\xff\xd8\xff", b"GIF8")  # binary signatures masquerading as text


def sanitise_filename(name: str) -> str:
    name = unicodedata.normalize("NFKC", name or "").replace("\\", "/").split("/")[-1]
    name = re.sub(r"[\x00-\x1f\x7f]", "", name)
    name = re.sub(r"[^\w .,()&'+-]", "_", name, flags=re.UNICODE).strip(" .")
    name = re.sub(r"\.{2,}", ".", name)
    return (name or "file")[:200]


def extension(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def sniff(filename: str, content: bytes) -> tuple[str, str]:
    """Return (extension, content_type) or raise ValidationFailed. Never trusts a client-supplied content type."""
    ext = extension(filename)
    if ext not in ALLOWED:
        raise ValidationFailed(f"File type '.{ext or '?'}' is not allowed. Allowed: {', '.join(sorted(ALLOWED))}.", code="file_type_not_allowed")
    if not content:
        raise ValidationFailed("The file is empty.", code="file_empty")
    if len(content) > get_settings().max_upload_bytes:
        raise ValidationFailed(f"The file exceeds the {get_settings().max_upload_bytes // (1024 * 1024)} MB limit.", code="file_too_large")
    ok = False
    if ext == "pdf":
        ok = content[:1024].lstrip().startswith(b"%PDF-")
    elif ext == "png":
        ok = content.startswith(b"\x89PNG\r\n\x1a\n")
    elif ext in ("jpg", "jpeg"):
        ok = content.startswith(b"\xff\xd8\xff")
    elif ext == "docx":
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as z:
                ok = "word/document.xml" in z.namelist() and "[Content_Types].xml" in z.namelist()
        except zipfile.BadZipFile:
            ok = False
    else:  # text-like
        if b"\x00" not in content and not content.startswith(_FORBIDDEN_STARTS):
            try:
                content.decode("utf-8")
                ok = True
            except UnicodeDecodeError:
                ok = False
    if not ok:
        raise ValidationFailed(f"The file content does not match a valid '.{ext}' file.", code="file_content_mismatch")
    return ext, ALLOWED[ext]
