"""Finance read helpers shared by matters (closure checks), the dashboard and reports."""
from __future__ import annotations

import uuid
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import Expense, Journal, JournalLine, LedgerAccount, TimeEntry

ZERO = Decimal("0.00")
POSTED = ("posted", "reversed")  # reversed journals keep their effect; the reversing journal offsets them


def client_balance(db: Session, matter_id: uuid.UUID) -> Decimal:
    """Money held for the client on this matter: posted client-ledger credits minus debits on the matter's client account(s)."""
    row = db.execute(
        select(func.coalesce(func.sum(JournalLine.credit), 0), func.coalesce(func.sum(JournalLine.debit), 0))
        .join(Journal, Journal.id == JournalLine.journal_id)
        .join(LedgerAccount, LedgerAccount.id == JournalLine.account_id)
        .where(LedgerAccount.ledger == "client", LedgerAccount.system_key == "client_matter", LedgerAccount.matter_id == matter_id,
               Journal.status.in_(POSTED))
    ).one()
    return Decimal(row[0]) - Decimal(row[1])


def unbilled_wip(db: Session, matter_id: uuid.UUID) -> dict:
    """Billable, not-yet-billed time and expenses (draft/submitted/approved). Not revenue; not an invoice."""
    t = db.execute(select(func.coalesce(func.sum(TimeEntry.amount), 0), func.count(TimeEntry.id)).where(
        TimeEntry.matter_id == matter_id, TimeEntry.billable.is_(True), TimeEntry.status.in_(("draft", "submitted", "approved")),
        TimeEntry.timer_started_at.is_(None))).one()
    e = db.execute(select(func.coalesce(func.sum(Expense.amount), 0), func.count(Expense.id)).where(
        Expense.matter_id == matter_id, Expense.billable.is_(True), Expense.status.in_(("draft", "approved")))).one()
    return {"time": Decimal(t[0]), "expenses": Decimal(e[0]), "count": int(t[1]) + int(e[1])}
