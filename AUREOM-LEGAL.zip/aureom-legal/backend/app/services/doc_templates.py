"""Reusable document templates with previewed field substitution. Values are inserted as PLAIN TEXT - no expression evaluation."""
from __future__ import annotations

import re
import uuid
from datetime import date

from sqlalchemy import select

from app.deps import Ctx
from app.errors import InvalidState, NotFound, ValidationFailed
from app.models import Contact, ContactAddress, DocumentTemplate, Matter, User
from app.services import documents as docs

PLACEHOLDER = re.compile(r"\{\{\s*([A-Za-z0-9_.]+)\s*\}\}")
SOURCES = ["matter.reference", "matter.title", "client.name", "client.address", "partner.name", "fee_earner.name", "today", "custom"]


def placeholders(body: str) -> list[str]:
    seen: list[str] = []
    for k in PLACEHOLDER.findall(body):
        if k not in seen:
            seen.append(k)
    return seen


def _address(db, contact_id) -> str | None:
    a = db.execute(select(ContactAddress).where(ContactAddress.contact_id == contact_id).order_by(ContactAddress.is_primary.desc())).scalars().first()
    if not a:
        return None
    return ", ".join(p for p in [a.line1, a.line2, a.city, a.county, a.postcode] if p)


def _context(ctx: Ctx, matter_id: uuid.UUID | None) -> dict[str, str]:
    today = date.today()
    vals: dict[str, str] = {"today": f"{today.day} {today.strftime('%B %Y')}"}
    if matter_id:
        m = docs._load_matter(ctx, matter_id)
        client = ctx.db.get(Contact, m.client_id)
        partner, fe = ctx.db.get(User, m.responsible_partner_id), ctx.db.get(User, m.fee_earner_id)
        vals.update({"matter.reference": m.reference, "matter.title": m.title, "client.name": client.display_name,
                     "partner.name": partner.name, "fee_earner.name": fe.name})
        addr = _address(ctx.db, client.id)
        if addr:
            vals["client.address"] = addr
    return vals


def render(tpl: DocumentTemplate, ctx: Ctx, matter_id: uuid.UUID | None, custom: dict[str, str] | None) -> dict:
    custom = {k: str(v) for k, v in (custom or {}).items() if v is not None}
    base = _context(ctx, matter_id)
    field_src = {f["key"]: f.get("source") for f in (tpl.fields or []) if f.get("key")}
    required = {f["key"] for f in (tpl.fields or []) if f.get("required")}
    resolved, missing = {}, []
    for key in placeholders(tpl.body):
        val = custom.get(key)
        if val is None:
            val = base.get(key)
        if val is None and field_src.get(key) in base:
            val = base[field_src[key]]
        if val is None or not str(val).strip():
            missing.append(key)
        else:
            resolved[key] = str(val)
    text = PLACEHOLDER.sub(lambda m: resolved.get(m.group(1), f"[[MISSING: {m.group(1)}]]"), tpl.body)
    return {"text": text, "fields": [{"key": k, "value": resolved.get(k), "missing": k in missing, "required": k in required} for k in placeholders(tpl.body)],
            "missing": missing, "missing_required": [k for k in missing if k in required or k not in field_src]}


def get_template(ctx: Ctx, tpl_id: uuid.UUID) -> DocumentTemplate:
    if not (ctx.has("documents.read") or ctx.has("documents.templates")):
        ctx.require("documents.read")
    t = ctx.db.get(DocumentTemplate, tpl_id)
    if not t or t.firm_id != ctx.firm_id:
        raise NotFound("Template not found.")
    return t


def generate(ctx: Ctx, tpl_id: uuid.UUID, matter_id: uuid.UUID, custom: dict | None, title: str | None, allow_incomplete: bool):
    ctx.require("documents.write")
    tpl = get_template(ctx, tpl_id)
    if not tpl.approved:
        raise InvalidState("Only approved templates can be used to generate documents.", code="template_not_approved")
    r = render(tpl, ctx, matter_id, custom)
    if r["missing"] and not allow_incomplete:
        raise ValidationFailed("Some template fields have no value.", code="template_fields_missing", details={"missing": r["missing"]})
    doc, v = docs.upload_document(ctx, matter_id=matter_id, title=title or f"{tpl.name}", doc_type="template_output" if tpl.doc_type not in docs.DOC_TYPES else tpl.doc_type,
                                  filename=f"{tpl.name}.txt", content=r["text"].encode(), source="template",
                                  change_note=f"Generated from template '{tpl.name}' v{tpl.template_version}")
    doc.meta = {**(doc.meta or {}), "template_id": str(tpl.id), "template_version": tpl.template_version, "missing_fields": r["missing"]}
    ctx.audit("document.generated_from_template", "document", doc.id, f"Document generated from template '{tpl.name}'", matter_id=matter_id,
              details={"template_id": str(tpl.id), "missing": r["missing"]})
    return doc, v
