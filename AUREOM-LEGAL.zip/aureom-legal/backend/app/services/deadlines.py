"""Deadlines. A deadline is AUTHORITATIVE only when status is confirmed/met/missed with a confirming human
(DB CHECK `confirmed_needs_human`). Calculated and AI suggestions start as 'suggested' and need explicit confirmation."""
from __future__ import annotations

import uuid
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.errors import InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.models import BusinessCalendar, Deadline, DeadlineRule, Matter, User
from app.permissions import can_access_matter, visible_matter_ids
from app.services import business_calendar as bc
from app.services.notify import notify

AUTHORITATIVE = ("confirmed", "met", "missed")

DEFAULT_RULES = [
    ("ack_14_calendar", "Acknowledge correspondence - 14 calendar days (illustrative)", 14, "calendar", "after", "next_business_day",
     "Illustrative: respond/acknowledge within 14 calendar days of receipt; rolls forward to the next business day."),
    ("notice_response_10_business", "Respond to contractual notice - 10 business days (illustrative)", 10, "business", "after", "none",
     "Illustrative: counts 10 business days after notice is deemed served. Check the contract's notice and deemed-service clauses."),
    ("notice_30_before", "Serve notice 30 calendar days before a date (illustrative)", 30, "calendar", "before", "next_business_day",
     "Illustrative: counts back 30 calendar days from a contractual date (e.g. renewal) and rolls back to a business day."),
    ("completion_28_calendar", "Completion / long-stop - 28 calendar days (illustrative)", 28, "calendar", "after", "next_business_day",
     "Illustrative placeholder for a 28-day period; the governing agreement or rule must be checked."),
]


def ensure_default_rules(db: Session, firm_id: uuid.UUID) -> None:
    for key, name, off, dtp, direction, roll, desc in DEFAULT_RULES:
        if not db.execute(select(DeadlineRule.id).where(DeadlineRule.firm_id == firm_id, DeadlineRule.key == key)).first():
            db.add(DeadlineRule(firm_id=firm_id, key=key, name=name, offset_days=off, day_type=dtp, direction=direction,
                                roll_convention=roll, description=desc))
    db.flush()


# ------------------------------------------------------------------ visibility
def deadline_clause(ctx: Ctx):
    return and_(Deadline.firm_id == ctx.firm_id, Deadline.matter_id.in_(visible_matter_ids(ctx)))


def get_deadline(ctx: Ctx, deadline_id: uuid.UUID) -> Deadline:
    ctx.require("tasks.read")
    d = ctx.db.get(Deadline, deadline_id)
    if not d or d.firm_id != ctx.firm_id:
        raise NotFound("Deadline not found.")
    m = ctx.db.get(Matter, d.matter_id)
    if not m or not can_access_matter(ctx, m):
        raise MatterAccessDenied("You do not have access to this matter.")
    return d


def _matter(ctx: Ctx, matter_id: uuid.UUID) -> Matter:
    m = ctx.db.get(Matter, matter_id)
    if not m or m.firm_id != ctx.firm_id:
        raise NotFound("Matter not found.")
    if not can_access_matter(ctx, m):
        raise MatterAccessDenied("You do not have access to this matter.")
    return m


def is_authoritative(d: Deadline) -> bool:
    return d.status in AUTHORITATIVE and d.confirmed_by is not None


def label_for(d: Deadline, confirmer: str | None = None) -> str:
    if d.status == "rejected":
        return "Rejected suggestion"
    if is_authoritative(d):
        return f"Authoritative - confirmed by {confirmer}" if confirmer else "Authoritative - confirmed"
    return {"calculated_suggestion": "Unconfirmed suggestion (calculated) - needs human confirmation",
            "ai_suggestion": "Unconfirmed suggestion (AI-identified) - needs human confirmation"}.get(d.origin, "Unconfirmed - needs human confirmation")


# ------------------------------------------------------------------ creation
def create_suggestion(ctx: Ctx, *, matter_id: uuid.UUID, title: str, due_date: date, origin: str = "calculated_suggestion",
                      due_time: time | None = None, timezone_name: str = "Europe/London", jurisdiction: str | None = None,
                      rule_key: str | None = None, calendar_id: uuid.UUID | None = None, trigger_date: date | None = None,
                      assumptions: str | None = None, calculation: dict | None = None, source_document_id=None, source_version_id=None,
                      source_passage: str | None = None, source_ref: dict | None = None, agent_run_id=None) -> Deadline:
    """Always creates status='suggested'. Used by the calculator and by the agents module's executor."""
    if origin not in ("calculated_suggestion", "ai_suggestion"):
        raise ValidationFailed("Suggestions must have origin calculated_suggestion or ai_suggestion.")
    m = _matter(ctx, matter_id)
    if origin == "ai_suggestion" and not (source_passage or "").strip():
        raise ValidationFailed("An AI-identified deadline must include the supporting passage from the source document.", code="passage_required")
    d = Deadline(firm_id=ctx.firm_id, matter_id=m.id, title=title, due_date=due_date, due_time=due_time, timezone=bc.validate_timezone(timezone_name),
                 origin=origin, status="suggested", jurisdiction=jurisdiction or m.jurisdiction, rule_key=rule_key, calendar_id=calendar_id,
                 trigger_date=trigger_date, assumptions=assumptions, calculation=calculation or {}, source_document_id=source_document_id,
                 source_version_id=source_version_id, source_passage=source_passage, source_ref=source_ref or {}, agent_run_id=agent_run_id,
                 suggested_by=ctx.user.id)
    ctx.db.add(d)
    ctx.db.flush()
    ctx.audit("deadline.suggested", "deadline", d.id, f"Deadline suggested ({origin}): {title[:120]}", matter_id=m.id,
              details={"origin": origin, "due_date": due_date.isoformat(), "rule_key": rule_key, "agent_run_id": str(agent_run_id) if agent_run_id else None})
    for uid in {m.responsible_partner_id, m.fee_earner_id} - {ctx.user.id}:
        notify(ctx.db, firm_id=ctx.firm_id, user_id=uid, kind="deadline_suggested", title=f"Deadline needs confirmation: {title[:140]}",
               body=f"Suggested for {due_date.isoformat()} on {m.reference}. It is not authoritative until a fee earner confirms it.",
               link=f"/diary/deadlines/{d.id}", matter_id=m.id)
    return d


def create_manual(ctx: Ctx, *, matter_id: uuid.UUID, title: str, due_date: date, due_time: time | None = None, timezone_name: str = "Europe/London",
                  jurisdiction: str | None = None, assumptions: str | None = None, reviewer_id: uuid.UUID | None = None) -> Deadline:
    """A manually entered deadline is the entering human's own statement: authoritative at once when the user holds
    deadlines.confirm. Users without that permission (e.g. paralegals) create an 'unconfirmed' manual entry that a
    fee earner must confirm - they cannot make a deadline authoritative."""
    ctx.require("tasks.write")
    m = _matter(ctx, matter_id)
    if reviewer_id:
        r = ctx.db.get(User, reviewer_id)
        if not r or r.firm_id != ctx.firm_id:
            raise ValidationFailed("Reviewer must be a user of this firm.")
    authoritative = ctx.has("deadlines.confirm")
    now = datetime.now(timezone.utc)
    d = Deadline(firm_id=ctx.firm_id, matter_id=m.id, title=title, due_date=due_date, due_time=due_time, timezone=bc.validate_timezone(timezone_name),
                 origin="manual", status="confirmed" if authoritative else "suggested", jurisdiction=jurisdiction or m.jurisdiction,
                 assumptions=assumptions, suggested_by=ctx.user.id, reviewer_id=reviewer_id,
                 confirmed_by=ctx.user.id if authoritative else None, confirmed_at=now if authoritative else None,
                 calculation={"manual_entry": True, "entered_by": str(ctx.user.id)})
    ctx.db.add(d)
    ctx.db.flush()
    ctx.audit("deadline.created_manual", "deadline", d.id, f"Deadline entered manually: {title[:120]}", matter_id=m.id,
              details={"due_date": due_date.isoformat(), "authoritative": authoritative})
    return d


def calculate(ctx: Ctx, *, matter_id: uuid.UUID, rule_key: str, trigger_date: date, calendar_id: uuid.UUID | None = None,
              title: str | None = None, assumptions: str | None = None) -> Deadline:
    ctx.require("tasks.write")
    m = _matter(ctx, matter_id)
    rule = ctx.db.execute(select(DeadlineRule).where(DeadlineRule.firm_id == ctx.firm_id, DeadlineRule.key == rule_key)).scalar_one_or_none()
    if not rule or not rule.is_active:
        raise NotFound("Deadline rule not found or inactive.")
    cal = bc.resolve_calendar(ctx.db, ctx.firm_id, calendar_id=calendar_id, jurisdiction=rule.jurisdiction)
    view = bc.load_view(ctx.db, cal)
    res = bc.calc_offset(view, trigger_date, rule.offset_days, day_type=rule.day_type, direction=rule.direction, roll=rule.roll_convention)
    calculation = {
        "inputs": {"rule_key": rule.key, "rule_name": rule.name, "trigger_date": trigger_date.isoformat(), "offset_days": rule.offset_days,
                   "day_type": rule.day_type, "direction": rule.direction, "roll_convention": rule.roll_convention,
                   "calendar": {"id": str(cal.id), "name": cal.name, "jurisdiction": cal.jurisdiction, "timezone": cal.timezone,
                                "weekend_days": cal.weekend_days, "holiday_source": cal.source_note}},
        "steps": res["steps"], "skipped_days": res["skipped_days"], "raw_date": res["raw_date"].isoformat(),
        "rolled_from": res["rolled_from"].isoformat() if res["rolled_from"] else None,
        "result": res["result"].isoformat(), "rule_source_note": rule.source_note,
        "disclaimer": "Calculated suggestion only. Not authoritative until confirmed by a fee earner.",
    }
    auto = (f"Rule '{rule.name}' ({rule.jurisdiction}) - {rule.source_note} Trigger day not counted. "
            f"Calendar '{cal.name}' ({cal.timezone}); holiday dates are administrator-supplied data. "
            f"Time of day not specified; assumed end of the day in {cal.timezone}.")
    return create_suggestion(ctx, matter_id=m.id, title=title or rule.name, due_date=res["result"], origin="calculated_suggestion",
                             timezone_name=cal.timezone, jurisdiction=rule.jurisdiction, rule_key=rule.key, calendar_id=cal.id,
                             trigger_date=trigger_date, assumptions=(auto + (" Additional assumptions: " + assumptions if assumptions else "")),
                             calculation=calculation)


# ------------------------------------------------------------------ review
def _task_for_deadline(ctx: Ctx, d: Deadline):
    from app.services.tasks import create_task
    m = ctx.db.get(Matter, d.matter_id)
    due = datetime.combine(d.due_date, d.due_time or time(9, 0), tzinfo=ZoneInfo(d.timezone))
    t = create_task(ctx, title=f"Deadline: {d.title}", matter_id=d.matter_id, assignee_id=m.fee_earner_id, due_at=due, priority="high",
                    reminder_offsets_minutes=[7 * 24 * 60, 24 * 60], source="manual", deadline_id=d.id,
                    description=f"Linked to confirmed deadline {d.id}")
    return t


def confirm(ctx: Ctx, deadline_id: uuid.UUID, *, review_note: str | None = None, adjusted_due_date: date | None = None,
            adjustment_reason: str | None = None, create_task: bool = False, expected_version: int | None = None) -> Deadline:
    ctx.require("deadlines.confirm")
    d = get_deadline(ctx, deadline_id)
    if expected_version is not None and d.version != expected_version:
        raise VersionConflict("This deadline was changed by someone else.", details={"current_version": d.version})
    if d.status != "suggested":
        raise InvalidState(f"Only suggested deadlines can be confirmed (this one is {d.status}).")
    if d.origin == "ai_suggestion" and not (d.source_passage or "").strip():
        raise ValidationFailed("Cannot confirm an AI-identified deadline without its supporting passage.", code="passage_required")
    if adjusted_due_date and adjusted_due_date != d.due_date:
        if not (adjustment_reason or "").strip():
            raise ValidationFailed("Changing the suggested date needs a recorded reason.", code="adjustment_reason_required")
        calc = dict(d.calculation or {})
        calc["adjustment"] = {"from": d.due_date.isoformat(), "to": adjusted_due_date.isoformat(), "reason": adjustment_reason,
                              "by": str(ctx.user.id), "at": datetime.now(timezone.utc).isoformat()}
        d.calculation = calc
        d.due_date = adjusted_due_date
    d.status, d.confirmed_by, d.confirmed_at = "confirmed", ctx.user.id, datetime.now(timezone.utc)
    d.reviewer_id, d.review_note = ctx.user.id, review_note
    ctx.db.flush()
    ctx.audit("deadline.confirmed", "deadline", d.id, f"Deadline confirmed: {d.title[:120]}", matter_id=d.matter_id,
              details={"origin": d.origin, "due_date": d.due_date.isoformat(), "adjusted": bool(adjusted_due_date)})
    if create_task:
        _task_for_deadline(ctx, d)
    return d


def reject(ctx: Ctx, deadline_id: uuid.UUID, review_note: str) -> Deadline:
    ctx.require("deadlines.confirm")
    d = get_deadline(ctx, deadline_id)
    if d.status != "suggested":
        raise InvalidState(f"Only suggested deadlines can be rejected (this one is {d.status}).")
    d.status, d.reviewer_id, d.review_note = "rejected", ctx.user.id, review_note
    ctx.db.flush()
    ctx.audit("deadline.rejected", "deadline", d.id, f"Deadline suggestion rejected: {d.title[:120]}", matter_id=d.matter_id, details={"origin": d.origin})
    return d


def update(ctx: Ctx, deadline_id: uuid.UUID, changes: dict, expected_version: int) -> Deadline:
    ctx.require("tasks.write")
    d = get_deadline(ctx, deadline_id)
    if d.version != expected_version:
        raise VersionConflict("This deadline was changed by someone else.", details={"current_version": d.version})
    if d.status == "rejected":
        raise InvalidState("A rejected suggestion cannot be edited.")
    needs_confirm_perm = d.status in AUTHORITATIVE or "status" in changes
    if needs_confirm_perm:
        ctx.require("deadlines.confirm")
    if d.status in AUTHORITATIVE and "due_date" in changes and changes["due_date"] != d.due_date and not (changes.get("reason") or "").strip():
        raise ValidationFailed("Changing a confirmed deadline needs a recorded reason.", code="adjustment_reason_required")
    status = changes.get("status")
    if status:
        if d.status != "confirmed":
            raise InvalidState("Only confirmed deadlines can be marked met or missed.")
        d.status = status
    before = d.due_date
    for k in ("title", "due_date", "due_time", "assumptions"):
        if k in changes and changes[k] is not None:
            setattr(d, k, changes[k])
    if d.due_date != before:
        calc = dict(d.calculation or {})
        calc.setdefault("changes", []).append({"from": before.isoformat(), "to": d.due_date.isoformat(), "reason": changes.get("reason"), "by": str(ctx.user.id),
                                               "at": datetime.now(timezone.utc).isoformat()})
        d.calculation = calc
    ctx.db.flush()
    ctx.audit("deadline.updated", "deadline", d.id, f"Deadline updated: {d.title[:120]}", matter_id=d.matter_id, details={"fields": sorted(changes), "status": d.status})
    return d


# ------------------------------------------------------------------ dashboard
def needs_attention(ctx: Ctx, days: int = 14, limit: int = 20) -> list[Deadline]:
    """Visible deadlines that are unconfirmed suggestions, or confirmed and due within `days` (or overdue)."""
    today = date.today()
    stmt = (select(Deadline).where(deadline_clause(ctx), or_(Deadline.status == "suggested",
                                   and_(Deadline.status == "confirmed", Deadline.due_date <= today + timedelta(days=days))))
            .order_by(Deadline.due_date).limit(limit))
    return list(ctx.db.execute(stmt).scalars())
