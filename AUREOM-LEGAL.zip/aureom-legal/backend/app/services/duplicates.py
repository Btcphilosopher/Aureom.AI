"""Duplicate detection and the reviewed merge workflow (propose -> independent review -> complete)."""
from __future__ import annotations

import difflib
import re
import uuid
from datetime import datetime, timezone

from sqlalchemy import delete, select, update

from app import models as M
from app.deps import Ctx
from app.errors import InvalidState, NotFound, PermissionDenied, ValidationFailed
from app.models import Contact, ContactAddress, ContactMerge, ContactRelationship, MatterParty
from app.services.contacts import clean_aliases, contact_out, get_contact

TITLES = {"mr", "mrs", "ms", "miss", "dr", "prof", "sir", "dame", "mx"}
ORG_SUFFIXES = {"ltd", "limited", "plc", "llp", "llc", "inc", "co", "company", "lp", "group"}
MERGEABLE_FIELDS = ["email", "phone", "date_of_birth", "title", "first_name", "last_name", "org_name", "company_number", "preferred_channel", "notes", "display_name"]
MAX_SCAN = 1500


def norm_name(s: str | None, *, org: bool = False) -> str:
    toks = [t for t in re.sub(r"[^a-z0-9 ]+", " ", (s or "").lower().replace("&", " and ")).split() if t]
    drop = TITLES | (ORG_SUFFIXES if org else set())
    return " ".join(t for t in toks if t not in drop)


def norm_phone(s: str | None) -> str:
    d = re.sub(r"\D", "", s or "")
    return d[-10:] if len(d) >= 10 else d


def norm_postcode(s: str | None) -> str:
    return re.sub(r"\s+", "", (s or "").upper())


def name_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    ta, tb = " ".join(sorted(a.split())), " ".join(sorted(b.split()))
    score = max(difflib.SequenceMatcher(None, a, b).ratio(), difflib.SequenceMatcher(None, ta, tb).ratio())
    # containment: every token of the shorter name appears in the longer one ("Hebden Brewing" vs "Hebden Bridge Brewing").
    # Deliberately over-inclusive: conflict screening prefers a reviewable false positive to a missed match.
    sa, sb = set(a.split()), set(b.split())
    small, large = (sa, sb) if len(sa) <= len(sb) else (sb, sa)
    if len(small) >= 2 and small <= large:
        score = max(score, 0.85 + 0.1 * len(small) / len(large))
    return score


def _names_for(c: Contact) -> list[str]:
    org = c.kind == "organisation"
    return [n for n in {norm_name(c.display_name, org=org), norm_name(c.org_name, org=True) if c.org_name else "", *[norm_name(a, org=org) for a in (c.aliases or [])]} if n]


def score_pair(a: Contact, b: Contact, pcs: dict[uuid.UUID, set[str]]) -> tuple[float, list[str]]:
    reasons: list[str] = []
    best = max((name_similarity(x, y) for x in _names_for(a) for y in _names_for(b)), default=0.0)
    score = 0.0
    if best >= 0.999:
        score += 0.55; reasons.append("Identical normalised name")
    elif best >= 0.8:
        score += 0.45 * (best - 0.6) / 0.4 + 0.1; reasons.append(f"Similar name ({best:.0%} match)")
    if a.date_of_birth and a.date_of_birth == b.date_of_birth:
        score += 0.25; reasons.append("Same date of birth")
    if a.email and b.email and a.email.strip().lower() == b.email.strip().lower():
        score += 0.3; reasons.append("Same email address")
    if norm_phone(a.phone) and norm_phone(a.phone) == norm_phone(b.phone):
        score += 0.2; reasons.append("Same telephone number")
    if a.company_number and b.company_number and a.company_number.strip().upper() == b.company_number.strip().upper():
        score += 0.5; reasons.append("Same company number")
    if pcs.get(a.id, set()) & pcs.get(b.id, set()):
        score += 0.15; reasons.append("Shares a postcode")
    return min(score, 1.0), reasons


def find_duplicates(ctx: Ctx, threshold: float = 0.6, limit: int = 100) -> list[dict]:
    ctx.require("clients.read")
    contacts = ctx.db.execute(select(Contact).where(Contact.firm_id == ctx.firm_id, Contact.status != "merged").order_by(Contact.created_at).limit(MAX_SCAN)).scalars().all()
    pcs: dict[uuid.UUID, set[str]] = {}
    for a in ctx.db.execute(select(ContactAddress).where(ContactAddress.firm_id == ctx.firm_id)).scalars():
        if a.postcode:
            pcs.setdefault(a.contact_id, set()).add(norm_postcode(a.postcode))
    pending = {frozenset((m.survivor_id, m.merged_id)) for m in ctx.db.execute(select(ContactMerge).where(ContactMerge.firm_id == ctx.firm_id, ContactMerge.status == "pending")).scalars()}
    out = []
    for i, a in enumerate(contacts):
        for b in contacts[i + 1:]:
            if a.kind != b.kind:
                continue
            s, reasons = score_pair(a, b, pcs)
            if s >= threshold and reasons:
                out.append({"score": round(s, 3), "reasons": reasons, "a": contact_out(a), "b": contact_out(b),
                            "merge_pending": frozenset((a.id, b.id)) in pending})
    out.sort(key=lambda x: -x["score"])
    return out[:limit]


# --------------------------------------------------------------------------- merge workflow
def merge_out(m: ContactMerge, names: dict | None = None) -> dict:
    names = names or {}
    return {"id": str(m.id), "survivor_id": str(m.survivor_id), "merged_id": str(m.merged_id), "status": m.status,
            "requested_by": str(m.requested_by), "requested_by_name": names.get(m.requested_by),
            "reviewed_by": str(m.reviewed_by) if m.reviewed_by else None, "reviewed_by_name": names.get(m.reviewed_by),
            "field_choices": m.field_choices, "repointed": m.repointed, "reason": m.reason, "snapshot": m.snapshot,
            "created_at": m.created_at.isoformat(), "completed_at": m.completed_at.isoformat() if m.completed_at else None}


def propose_merge(ctx: Ctx, survivor_id, merged_id, field_choices: dict, reason: str) -> ContactMerge:
    ctx.require("clients.write")
    if survivor_id == merged_id:
        raise ValidationFailed("Choose two different contacts.")
    s, m = get_contact(ctx, survivor_id), get_contact(ctx, merged_id)
    if "merged" in (s.status, m.status):
        raise InvalidState("A merged contact cannot be merged again.")
    if s.kind != m.kind:
        raise ValidationFailed("Only contacts of the same kind can be merged.")
    bad = [k for k in field_choices if k not in MERGEABLE_FIELDS]
    if bad:
        raise ValidationFailed(f"Unknown merge fields: {', '.join(bad)}", details={"allowed": MERGEABLE_FIELDS})
    existing = ctx.db.execute(select(ContactMerge).where(ContactMerge.firm_id == ctx.firm_id, ContactMerge.status == "pending",
                                                         ContactMerge.merged_id == merged_id)).scalars().first()
    if existing:
        raise InvalidState("A merge for this contact is already pending review.", code="merge_pending")
    snap = contact_out(m)
    mg = ContactMerge(firm_id=ctx.firm_id, survivor_id=survivor_id, merged_id=merged_id, requested_by=ctx.user.id, field_choices=field_choices,
                      reason=reason, snapshot=snap, status="pending")
    ctx.db.add(mg)
    ctx.db.flush()
    ctx.audit("contact.merge_proposed", "contact_merge", mg.id, f"Merge proposed: {m.display_name} into {s.display_name}",
              details={"survivor": str(s.id), "merged": str(m.id)})
    return mg


def _repoint(ctx: Ctx, survivor: Contact, merged: Contact) -> dict:
    db, sid, mid = ctx.db, survivor.id, merged.id
    counts: dict[str, int] = {}

    def rp(model, col: str, label: str | None = None) -> None:
        r = db.execute(update(model).where(getattr(model, col) == mid).values({col: sid}))
        if r.rowcount:
            counts[label or f"{model.__tablename__}.{col}"] = r.rowcount

    # matter parties: avoid violating unique(matter, contact, role)
    s_roles = {(p.matter_id, p.role) for p in db.execute(select(MatterParty).where(MatterParty.contact_id == sid)).scalars()}
    dropped = 0
    for p in db.execute(select(MatterParty).where(MatterParty.contact_id == mid)).scalars().all():
        if (p.matter_id, p.role) in s_roles:
            db.delete(p); dropped += 1
        else:
            p.contact_id = sid
            counts["matter_parties.contact_id"] = counts.get("matter_parties.contact_id", 0) + 1
    if dropped:
        counts["matter_parties.duplicates_collapsed"] = dropped
    db.flush()
    # relationships: move, collapse duplicates, drop self-links
    existing = {(r.from_contact_id, r.to_contact_id, r.relation_type) for r in db.execute(select(ContactRelationship).where(
        (ContactRelationship.from_contact_id == sid) | (ContactRelationship.to_contact_id == sid))).scalars()}
    moved = collapsed = 0
    for r in db.execute(select(ContactRelationship).where((ContactRelationship.from_contact_id == mid) | (ContactRelationship.to_contact_id == mid))).scalars().all():
        f = sid if r.from_contact_id == mid else r.from_contact_id
        t = sid if r.to_contact_id == mid else r.to_contact_id
        if f == t or (f, t, r.relation_type) in existing:
            db.delete(r); collapsed += 1
        else:
            r.from_contact_id, r.to_contact_id = f, t
            existing.add((f, t, r.relation_type)); moved += 1
    if moved:
        counts["contact_relationships"] = moved
    if collapsed:
        counts["contact_relationships.duplicates_collapsed"] = collapsed
    db.flush()
    # addresses: only one primary
    has_primary = db.execute(select(ContactAddress.id).where(ContactAddress.contact_id == sid, ContactAddress.is_primary.is_(True))).first() is not None
    for a in db.execute(select(ContactAddress).where(ContactAddress.contact_id == mid)).scalars().all():
        if has_primary:
            a.is_primary = False
        a.contact_id = sid
        counts["contact_addresses.contact_id"] = counts.get("contact_addresses.contact_id", 0) + 1
    for model, col in [(M.Matter, "client_id"), (M.OnboardingRecord, "contact_id"), (M.Document, "contact_id"), (M.Folder, "contact_id"),
                       (M.Invoice, "client_id"), (M.Invoice, "payer_id"), (M.ConflictMatch, "matched_contact_id"), (M.ConflictSearch, "subject_contact_id"),
                       (M.User, "contact_id"), (M.Payment, "received_from_id"), (M.LedgerAccount, "contact_id"), (M.AgentRun, "contact_id"),
                       (M.Contact, "merged_into_id")]:
        rp(model, col)
    db.flush()
    return counts


def complete_merge(ctx: Ctx, merge_id: uuid.UUID, note: str | None = None) -> ContactMerge:
    ctx.require("clients.merge")
    mg = ctx.db.get(ContactMerge, merge_id)
    if not mg or mg.firm_id != ctx.firm_id:
        raise NotFound("Merge not found.")
    if mg.status != "pending":
        raise InvalidState(f"This merge is already {mg.status}.")
    if mg.requested_by == ctx.user.id:
        raise PermissionDenied("Merges must be reviewed by someone other than the person who proposed them.", code="four_eyes_required")
    survivor, merged = get_contact(ctx, mg.survivor_id), get_contact(ctx, mg.merged_id)
    if "merged" in (survivor.status, merged.status):
        raise InvalidState("One of the contacts has already been merged.")
    # field choices from the merged record
    for f, side in (mg.field_choices or {}).items():
        if side == "merged" and f in MERGEABLE_FIELDS:
            setattr(survivor, f, getattr(merged, f))
    # aliases: survivor + merged name + merged aliases
    survivor.aliases = clean_aliases([*(survivor.aliases or []), merged.display_name, *(merged.aliases or [])])
    survivor.aliases = [a for a in survivor.aliases if a.lower() != survivor.display_name.lower()]
    # client references are preserved, never discarded
    meta = dict(survivor.meta or {})
    if merged.client_ref:
        if not survivor.client_ref:
            ref = merged.client_ref
            merged.client_ref = None
            ctx.db.flush()
            survivor.client_ref = ref
            merged.meta = {**(merged.meta or {}), "former_client_ref": ref}
        else:
            meta["former_client_refs"] = [*meta.get("former_client_refs", []), merged.client_ref]
    if merged.is_client:
        survivor.is_client = True
        if survivor.status == "prospect":
            survivor.status = "active"
    survivor.meta = meta
    ctx.db.flush()
    counts = _repoint(ctx, survivor, merged)
    merged.status, merged.merged_into_id, merged.is_client = "merged", survivor.id, False
    mg.status, mg.reviewed_by, mg.completed_at, mg.repointed = "completed", ctx.user.id, datetime.now(timezone.utc), counts
    if note:
        mg.reason = f"{mg.reason or ''}\nReviewer note: {note}".strip()
    ctx.db.flush()
    ctx.audit("contact.merge_completed", "contact_merge", mg.id, f"Merged {merged.display_name} into {survivor.display_name}",
              details={"survivor": str(survivor.id), "merged": str(merged.id), "repointed": counts})
    return mg


def reject_merge(ctx: Ctx, merge_id: uuid.UUID, note: str | None = None) -> ContactMerge:
    ctx.require("clients.merge")
    mg = ctx.db.get(ContactMerge, merge_id)
    if not mg or mg.firm_id != ctx.firm_id:
        raise NotFound("Merge not found.")
    if mg.status != "pending":
        raise InvalidState(f"This merge is already {mg.status}.")
    mg.status, mg.reviewed_by, mg.completed_at = "rejected", ctx.user.id, datetime.now(timezone.utc)
    if note:
        mg.reason = f"{mg.reason or ''}\nRejected: {note}".strip()
    ctx.db.flush()
    ctx.audit("contact.merge_rejected", "contact_merge", mg.id, "Merge rejected")
    return mg
