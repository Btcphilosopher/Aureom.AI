"""Business-day arithmetic over a configurable calendar. Holidays are DATA (calendar_holidays), never hard-coded."""
from __future__ import annotations

import uuid
from datetime import date, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.errors import NotFound, ValidationFailed
from app.models import BusinessCalendar, CalendarHoliday


def validate_timezone(tz: str) -> str:
    try:
        ZoneInfo(tz)
    except (ZoneInfoNotFoundError, ValueError, KeyError) as e:
        raise ValidationFailed(f"Unknown timezone '{tz}'.") from e
    return tz


class CalendarView:
    """A calendar plus its holiday dates, with business-day helpers."""

    def __init__(self, cal: BusinessCalendar, holidays: dict[date, str]):
        self.cal = cal
        self.holidays = holidays
        self.weekend = set(cal.weekend_days or [5, 6])

    def non_business_reason(self, d: date) -> str | None:
        if d.weekday() in self.weekend:
            return "weekend"
        if d in self.holidays:
            return f"holiday: {self.holidays[d]}"
        return None

    def is_business_day(self, d: date) -> bool:
        return self.non_business_reason(d) is None

    def next_business_day(self, d: date, forward: bool = True) -> tuple[date, list[dict]]:
        step = timedelta(days=1 if forward else -1)
        skipped: list[dict] = []
        while (reason := self.non_business_reason(d)) is not None:
            skipped.append({"date": d.isoformat(), "reason": reason})
            d += step
        return d, skipped

    def add_business_days(self, start: date, n: int, direction: str = "after") -> tuple[date, list[dict]]:
        """Day 1 is the first business day after (or before) `start`; `start` itself is never counted."""
        step = timedelta(days=1 if direction == "after" else -1)
        d, counted, skipped = start, 0, []
        while counted < n:
            d += step
            reason = self.non_business_reason(d)
            if reason is None:
                counted += 1
            else:
                skipped.append({"date": d.isoformat(), "reason": reason})
        return d, skipped


def load_view(db: Session, cal: BusinessCalendar) -> CalendarView:
    rows = db.execute(select(CalendarHoliday).where(CalendarHoliday.calendar_id == cal.id)).scalars().all()
    return CalendarView(cal, {h.holiday_date: h.name for h in rows})


def get_calendar(db: Session, firm_id: uuid.UUID, calendar_id: uuid.UUID) -> BusinessCalendar:
    cal = db.get(BusinessCalendar, calendar_id)
    if not cal or cal.firm_id != firm_id:
        raise NotFound("Business calendar not found.")
    return cal


def resolve_calendar(db: Session, firm_id: uuid.UUID, *, calendar_id: uuid.UUID | None = None, jurisdiction: str | None = None) -> BusinessCalendar:
    if calendar_id:
        return get_calendar(db, firm_id, calendar_id)
    stmt = select(BusinessCalendar).where(BusinessCalendar.firm_id == firm_id)
    cals = db.execute(stmt.order_by(BusinessCalendar.is_default.desc(), BusinessCalendar.name)).scalars().all()
    if jurisdiction:
        for c in cals:
            if c.jurisdiction == jurisdiction:
                return c
    if cals:
        return cals[0]
    raise ValidationFailed("No business calendar is configured for this firm. Ask an administrator to add one.")


def calc_offset(view: CalendarView, trigger: date, offset: int, *, day_type: str, direction: str, roll: str) -> dict:
    """Apply a rule. Returns {result, raw_date, rolled_from, skipped_days, steps}."""
    steps = [f"Trigger date {trigger.isoformat()} (the trigger day itself is not counted)."]
    skipped: list[dict] = []
    rolled_from = None
    if day_type == "business":
        raw, skipped = view.add_business_days(trigger, offset, direction)
        steps.append(f"Counted {offset} business day(s) {direction} the trigger, skipping weekends and calendar holidays -> {raw.isoformat()}.")
        result = raw
    else:
        raw = trigger + timedelta(days=offset if direction == "after" else -offset)
        steps.append(f"Counted {offset} calendar day(s) {direction} the trigger -> {raw.isoformat()}.")
        result = raw
        if roll == "next_business_day":
            forward = direction == "after"
            adj, sk = view.next_business_day(raw, forward=forward)
            if adj != raw:
                rolled_from = raw
                skipped = sk
                result = adj
                steps.append(f"{raw.isoformat()} is not a business day; rolled {'forward' if forward else 'back'} to {adj.isoformat()}.")
            else:
                steps.append("Result is a business day; no roll needed.")
        else:
            steps.append("Roll convention 'none': date not adjusted for non-business days.")
    return {"result": result, "raw_date": raw, "rolled_from": rolled_from, "skipped_days": skipped, "steps": steps}
