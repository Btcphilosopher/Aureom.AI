"""Generic approvals. An approval is bound to the SHA-256 of the exact payload approved; if the content changes the
approval no longer verifies and a new one must be requested."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select

from app.deps import Ctx
from app.errors import ApprovalRequired, InvalidState, NotFound, PermissionDenied
from app.models import Approval
from app.security import canonical_hash

# kinds for which the approver must be a different person from the requester ("four eyes")
FOUR_EYES = {"journal_post", "client_funds_transfer", "payment_allocation", "invoice_issue", "revenue_recognition", "reconciliation_signoff", "bank_detail_change"}


def request_approval(ctx: Ctx, *, kind: str, subject_type: str, subject_id: uuid.UUID | None, payload: dict, matter_id=None,
                     required_permission: str | None = None, note: str | None = None) -> Approval:
    """Create (or replace) a pending approval for a subject. Previous pending approvals for the same subject+kind are superseded."""
    db = ctx.db
    if subject_id is not None:
        for old in db.execute(select(Approval).where(Approval.subject_type == subject_type, Approval.subject_id == subject_id,
                                                      Approval.kind == kind, Approval.status == "pending")).scalars():
            old.status = "superseded"
    ap = Approval(firm_id=ctx.firm_id, kind=kind, subject_type=subject_type, subject_id=subject_id, matter_id=matter_id,
                  requested_by=ctx.user.id, payload=payload, payload_hash=canonical_hash(payload), required_permission=required_permission,
                  decision_note=note)
    db.add(ap)
    db.flush()
    ctx.audit("approval.requested", "approval", ap.id, f"Approval requested: {kind}", matter_id=matter_id, details={"kind": kind, "subject": str(subject_id), "payload_hash": ap.payload_hash})
    return ap


def decide(ctx: Ctx, approval_id: uuid.UUID, *, approve: bool, note: str | None = None) -> Approval:
    ap = ctx.db.get(Approval, approval_id)
    if not ap or ap.firm_id != ctx.firm_id:
        raise NotFound("Approval not found.")
    if ap.status != "pending":
        raise InvalidState(f"This approval is already {ap.status}.")
    if ap.required_permission:
        ctx.require(ap.required_permission)
    if approve and ap.kind in FOUR_EYES and ap.requested_by == ctx.user.id:
        raise PermissionDenied("Four-eyes control: the person who prepared this cannot also approve it.", code="four_eyes_required")
    ap.status = "approved" if approve else "rejected"
    ap.decided_by, ap.decided_at, ap.decision_note = ctx.user.id, datetime.now(timezone.utc), note
    ctx.db.flush()
    ctx.audit("approval.approved" if approve else "approval.rejected", "approval", ap.id, f"Approval {ap.status}: {ap.kind}",
              matter_id=ap.matter_id, details={"kind": ap.kind, "payload_hash": ap.payload_hash})
    return ap


def assert_approved(ctx: Ctx, approval_id: uuid.UUID | None, *, kind: str, payload: dict, subject_id: uuid.UUID | None = None) -> Approval:
    """Verify an approved approval exists for exactly this payload. Raises ApprovalRequired otherwise."""
    if not approval_id:
        raise ApprovalRequired("This action requires an approval first.")
    ap = ctx.db.get(Approval, approval_id)
    if not ap or ap.firm_id != ctx.firm_id or ap.kind != kind:
        raise ApprovalRequired("No matching approval.")
    if subject_id is not None and ap.subject_id != subject_id:
        raise ApprovalRequired("Approval belongs to a different record.")
    if ap.status != "approved":
        raise ApprovalRequired(f"Approval is {ap.status}, not approved.")
    if ap.payload_hash != canonical_hash(payload):
        raise ApprovalRequired("The content changed after it was approved; a fresh approval is required.", code="approval_stale")
    return ap
