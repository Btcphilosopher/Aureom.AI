"""Create the skeleton of a firm: offices, teams, roles, retention policies, calendar, default settings.
Shared by the demo seed and by tests so both exercise the same configuration paths."""
from __future__ import annotations

import uuid
from datetime import date

from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import BusinessCalendar, CalendarHoliday, Firm, Office, RetentionPolicy, Role, Team
from app.permissions import ROLE_PERMISSIONS

ROLE_NAMES = {"partner": "Partner", "solicitor": "Solicitor", "paralegal": "Paralegal / Legal Assistant", "finance": "Finance",
              "compliance": "Compliance (COLP/MLRO)", "admin": "Administrator", "client": "Authorised client"}

DEFAULT_SETTINGS = {
    "onboarding_check_types": [
        {"key": "id_individual", "label": "Photo identity (individual)", "applies_to": "individual"},
        {"key": "address", "label": "Proof of address", "applies_to": "individual"},
        {"key": "sanctions_pep", "label": "Sanctions & PEP screening", "applies_to": "any"},
        {"key": "source_of_funds", "label": "Source of funds / wealth", "applies_to": "any"},
        {"key": "company_kyb", "label": "Company & beneficial ownership", "applies_to": "organisation"},
    ],
    "onboarding_required_checks": ["id_individual", "sanctions_pep"],
    "client_reference_prefix": "PCS",
    "vat_rate": "20.00",
    "ai": {
        "enabled": True, "provider": "mock", "auto_complete_readonly": True,
        "monthly_budget_gbp": 50.0, "per_run_budget_gbp": 2.0, "user_daily_runs": 40,
        "train_on_matter_content": False,
        "allowed_agents": ["matter_briefing", "document_review", "chronology", "drafting", "knowledge", "intake", "billing_assistant"],
    },
    "finance": {"four_eyes": True, "currency": "GBP"},
    "retention": {"default_policy": "general_6y"},
}

DEFAULT_RETENTION = [
    ("general_6y", "General files - 6 years", 6, "Standard retention from closure; review before destruction."),
    ("property_15y", "Conveyancing / property - 15 years", 15, "Longer retention for property-related files (demonstration default)."),
    ("private_client_15y", "Wills, probate & trusts - 15 years", 15, "Review required; original wills handled separately."),
    ("litigation_7y", "Litigation - 7 years", 7, "From conclusion of proceedings, subject to review."),
]


def create_firm(db: Session, *, name: str, slug: str, offices: list[tuple[str, str]] | None = None, residency: str = "uk") -> Firm:
    firm = Firm(name=name, slug=slug, data_residency=residency, settings=dict(DEFAULT_SETTINGS))
    db.add(firm)
    db.flush()
    for key, perms in ROLE_PERMISSIONS.items():
        db.add(Role(firm_id=firm.id, key=key, name=ROLE_NAMES[key], permissions=sorted(perms), is_system=True))
    for oname, city in (offices or [("Head Office", "Leeds")]):
        db.add(Office(firm_id=firm.id, name=oname, city=city))
    for key, nm, years, desc in DEFAULT_RETENTION:
        db.add(RetentionPolicy(firm_id=firm.id, key=key, name=nm, years=years, description=desc))
    cal = BusinessCalendar(firm_id=firm.id, name="England & Wales business days", jurisdiction="england_and_wales", is_default=True,
                           source_note="Holiday dates are administrator-supplied input data; verify against official sources before relying on them.")
    db.add(cal)
    db.flush()
    db.flush()
    return firm


def load_default_holidays(db: Session, firm_id: uuid.UUID) -> None:
    """Illustrative bank-holiday inputs for 2026-2027 (administrator-editable). Verify before relying on them."""
    cal = db.query(BusinessCalendar).filter_by(firm_id=firm_id, is_default=True).one()
    for d, n in [(date(2026, 12, 25), "Christmas Day"), (date(2026, 12, 28), "Boxing Day (substitute)"), (date(2027, 1, 1), "New Year's Day"),
                 (date(2027, 3, 26), "Good Friday"), (date(2027, 3, 29), "Easter Monday"), (date(2027, 5, 3), "Early May bank holiday"),
                 (date(2027, 5, 31), "Spring bank holiday"), (date(2027, 8, 30), "Summer bank holiday")]:
        if not db.query(CalendarHoliday).filter_by(calendar_id=cal.id, holiday_date=d).first():
            db.add(CalendarHoliday(firm_id=firm_id, calendar_id=cal.id, holiday_date=d, name=n))
    db.flush()
