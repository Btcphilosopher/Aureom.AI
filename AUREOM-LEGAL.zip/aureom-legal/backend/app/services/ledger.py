"""Double-entry ledgers (office / client), journals with explicit authorisation, allocation, client-money transfers
and revenue recognition.

Rules enforced here (and, where possible, again by database triggers - see app/db/safeguards.sql):
* Office funds and client funds live in separate ledgers; a journal belongs to exactly one ledger.
* Every journal must balance; posted journals are immutable (reverse them instead).
* Nothing is posted without a human authorisation (approval bound to the exact lines); four-eyes where listed in
  approvals.FOUR_EYES. Agents/automation (ctx.actor_type != "user") can never post, approve, allocate or transfer.
* A matter's client account can never be overdrawn.
* Receipt of money is NOT revenue. Issue (billing.py) -> receipt -> allocation -> reconciliation -> revenue
  recognition are distinct, separately authorised steps.
DEMONSTRATION ONLY: synthetic data; see billing.py docstring for the professional review required.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.enums import LEDGERS
from app.errors import InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed
from app.models import (Approval, Invoice, Journal, JournalLine, LedgerAccount, Matter, Payment, PaymentAllocation, RevenueRecognition)
from app.money import ZERO, q
from app.permissions import can_access_matter
from app.security import canonical_hash
from app.services import approvals
from app.services.matter_finance import POSTED

OFFICE_ACCOUNTS = [
    ("1000", "Office bank account", "asset", "bank_office", True),
    ("1100", "Debtors (client bills issued)", "asset", "debtors", False),
    ("1200", "Disbursements recoverable", "asset", "disbursements_recoverable", False),
    ("2000", "Unallocated receipts (suspense)", "liability", "unallocated_receipts", False),
    ("2100", "Fees billed - not yet recognised", "liability", "fees_billed_unrecognised", False),
    ("2200", "VAT output", "liability", "vat_output", False),
    ("4000", "Fee income (recognised)", "income", "fee_income", False),
]
CLIENT_ACCOUNTS = [("C1000", "Client bank account", "asset", "bank_client", True)]

FINANCE_KINDS = {"journal_post", "payment_allocation", "client_funds_transfer", "revenue_recognition"}


def _db(x) -> Session:
    return x.db if hasattr(x, "db") else x


def require_human(ctx: Ctx, what: str = "financial postings") -> None:
    """AI agents / automation must never authorise or execute financial actions."""
    if getattr(ctx, "actor_type", "user") != "user":
        raise PermissionDenied(f"AI agents and automated processes cannot perform {what}; a named human must.", code="human_authorisation_required")


# ------------------------------------------------------------------------------------------ accounts
def ensure_chart_of_accounts(db: Session, firm_id: uuid.UUID) -> None:
    """Idempotently create the demonstration chart of accounts (NOT a compliant statutory chart)."""
    existing = {(a.ledger, a.system_key) for a in db.execute(select(LedgerAccount).where(LedgerAccount.firm_id == firm_id)).scalars()}
    for ledger, rows in (("office", OFFICE_ACCOUNTS), ("client", CLIENT_ACCOUNTS)):
        for code, name, typ, key, is_bank in rows:
            if (ledger, key) not in existing:
                db.add(LedgerAccount(firm_id=firm_id, ledger=ledger, code=code, name=name, account_type=typ, system_key=key, is_bank=is_bank))
    db.flush()


def system_account(db: Session, firm_id: uuid.UUID, system_key: str, ledger: str | None = None) -> LedgerAccount:
    stmt = select(LedgerAccount).where(LedgerAccount.firm_id == firm_id, LedgerAccount.system_key == system_key)
    if ledger:
        stmt = stmt.where(LedgerAccount.ledger == ledger)
    acct = db.execute(stmt).scalars().first()
    if not acct:
        ensure_chart_of_accounts(db, firm_id)
        acct = db.execute(stmt).scalars().first()
    if not acct:
        raise NotFound(f"Ledger account '{system_key}' is not configured.")
    return acct


def client_account_for_matter(ctx_or_db, matter_id: uuid.UUID) -> LedgerAccount:
    """The client-ledger liability account holding a client's money on a matter (created lazily)."""
    db = _db(ctx_or_db)
    matter = db.get(Matter, matter_id)
    if not matter:
        raise NotFound("Matter not found.")
    stmt = select(LedgerAccount).where(LedgerAccount.firm_id == matter.firm_id, LedgerAccount.ledger == "client",
                                       LedgerAccount.system_key == "client_matter", LedgerAccount.matter_id == matter_id)
    acct = db.execute(stmt).scalars().first()
    if acct:
        return acct
    try:
        with db.begin_nested():
            acct = LedgerAccount(firm_id=matter.firm_id, ledger="client", code=f"CM-{matter.reference}"[:30],
                                 name=f"Client funds - {matter.reference} {matter.title}"[:160], account_type="liability",
                                 currency=matter.currency, system_key="client_matter", matter_id=matter_id, contact_id=matter.client_id)
            db.add(acct)
            db.flush()
    except IntegrityError:
        acct = db.execute(stmt).scalars().first()
    return acct


def account_balance(db: Session, account: LedgerAccount | uuid.UUID, as_of: date | None = None) -> Decimal:
    """Posted balance on the account's natural side (assets/expenses: debit-credit; others: credit-debit)."""
    acct = account if isinstance(account, LedgerAccount) else db.get(LedgerAccount, account)
    stmt = (select(func.coalesce(func.sum(JournalLine.debit), 0), func.coalesce(func.sum(JournalLine.credit), 0))
            .join(Journal, Journal.id == JournalLine.journal_id).where(JournalLine.account_id == acct.id, Journal.status.in_(POSTED)))
    if as_of:
        stmt = stmt.where(Journal.effective_date <= as_of)
    d, c = db.execute(stmt).one()
    d, c = Decimal(d), Decimal(c)
    return (d - c) if acct.account_type in ("asset", "expense") else (c - d)


def trial_balance(ctx: Ctx, ledger: str, as_of: date | None = None) -> dict:
    ctx.require("ledger.read")
    if ledger not in LEDGERS:
        raise ValidationFailed("ledger must be 'office' or 'client'.")
    sub = (select(JournalLine.account_id.label("aid"), func.sum(JournalLine.debit).label("d"), func.sum(JournalLine.credit).label("c"))
           .join(Journal, Journal.id == JournalLine.journal_id).where(Journal.status.in_(POSTED), Journal.ledger == ledger))
    if as_of:
        sub = sub.where(Journal.effective_date <= as_of)
    sub = sub.group_by(JournalLine.account_id).subquery()
    rows = ctx.db.execute(select(LedgerAccount, func.coalesce(sub.c.d, 0), func.coalesce(sub.c.c, 0))
                          .outerjoin(sub, sub.c.aid == LedgerAccount.id)
                          .where(LedgerAccount.firm_id == ctx.firm_id, LedgerAccount.ledger == ledger).order_by(LedgerAccount.code)).all()
    out, td, tc = [], ZERO, ZERO
    for a, d, c in rows:
        d, c = Decimal(d), Decimal(c)
        if a.matter_id and not _matter_ok(ctx, a.matter_id):
            continue  # per-matter client accounts of restricted matters are not listed (totals below include them only via other rows)
        bal = (d - c) if a.account_type in ("asset", "expense") else (c - d)
        out.append({"account_id": a.id, "code": a.code, "name": a.name, "type": a.account_type, "system_key": a.system_key,
                    "matter_id": a.matter_id, "debit": d, "credit": c, "balance": bal})
        td, tc = td + d, tc + c
    return {"ledger": ledger, "as_of": as_of, "accounts": out, "total_debit": td, "total_credit": tc, "balanced": td == tc or None,
            "note": "Per-matter client accounts of matters you cannot access are omitted from the listing."}


def _matter_ok(ctx: Ctx, matter_id) -> bool:
    m = ctx.db.get(Matter, matter_id)
    return bool(m and can_access_matter(ctx, m))


def get_matter_for(ctx: Ctx, matter_id: uuid.UUID) -> Matter:
    m = ctx.db.get(Matter, matter_id)
    if not m or m.firm_id != ctx.firm_id:
        raise NotFound("Matter not found.")
    if not can_access_matter(ctx, m):
        raise MatterAccessDenied("You do not have access to this matter.")
    return m


# ------------------------------------------------------------------------------------------ journals
def journal_lines(db: Session, journal_id: uuid.UUID) -> list[JournalLine]:
    return list(db.execute(select(JournalLine).where(JournalLine.journal_id == journal_id).order_by(JournalLine.id)).scalars())


def journal_payload(j: Journal, lines: list[JournalLine]) -> dict:
    """Canonical content an approval binds to. Any change to ledger, date, currency or a line changes the hash."""
    ls = [{"account_id": str(l.account_id), "debit": str(q(l.debit)), "credit": str(q(l.credit)), "matter_id": str(l.matter_id) if l.matter_id else None}
          for l in lines]
    ls.sort(key=lambda x: (x["account_id"], x["debit"], x["credit"], x["matter_id"] or ""))
    return {"ledger": j.ledger, "reference": j.reference, "effective_date": j.effective_date.isoformat(), "currency": j.currency,
            "matter_id": str(j.matter_id) if j.matter_id else None, "lines": ls}


def _validate_lines(ctx: Ctx, ledger: str, currency: str, raw_lines: list[dict]) -> list[JournalLine]:
    if len(raw_lines) < 2:
        raise ValidationFailed("A journal needs at least two lines.")
    out: list[JournalLine] = []
    for i, rl in enumerate(raw_lines, 1):
        debit, credit = q(Decimal(str(rl.get("debit") or 0))), q(Decimal(str(rl.get("credit") or 0)))
        if debit < 0 or credit < 0 or (debit > 0) == (credit > 0):
            raise ValidationFailed(f"Line {i}: exactly one of debit or credit must be a positive amount.", code="one_sided_line_required")
        acct = None
        if rl.get("account_id"):
            acct = ctx.db.get(LedgerAccount, rl["account_id"])
        elif rl.get("system_key"):
            acct = system_account(ctx.db, ctx.firm_id, rl["system_key"])  # any ledger: mismatches are reported below
        if not acct or acct.firm_id != ctx.firm_id:
            raise NotFound(f"Line {i}: ledger account not found.")
        if acct.ledger != ledger:
            raise ValidationFailed(f"Line {i}: account {acct.code} is in the {acct.ledger} ledger but the journal is in the {ledger} ledger. "
                                   "Office and client funds must never be mixed in one journal.", code="ledger_mismatch")
        if acct.currency != currency:
            raise ValidationFailed(f"Line {i}: account currency {acct.currency} differs from journal currency {currency}.", code="currency_mismatch")
        if not acct.is_active:
            raise ValidationFailed(f"Line {i}: account {acct.code} is inactive.")
        mid = rl.get("matter_id") or acct.matter_id
        if mid:
            get_matter_for(ctx, uuid.UUID(str(mid)))
        out.append(JournalLine(firm_id=ctx.firm_id, account_id=acct.id, debit=debit, credit=credit, matter_id=mid, narrative=(rl.get("narrative") or None)))
    td, tc = sum((l.debit for l in out), ZERO), sum((l.credit for l in out), ZERO)
    if td != tc:
        raise ValidationFailed(f"Journal is unbalanced: debits {td} do not equal credits {tc}.", code="unbalanced_journal",
                               details={"debits": str(td), "credits": str(tc)})
    return out


def create_journal(ctx: Ctx, *, ledger: str, reference: str, description: str, effective_date: date, lines: list[dict],
                   source_type: str | None = None, source_id: uuid.UUID | None = None, matter_id: uuid.UUID | None = None,
                   currency: str = "GBP", reverses_journal_id: uuid.UUID | None = None, submit: bool = False,
                   approval_extra: dict | None = None) -> Journal:
    """Create a DRAFT journal (never posted here). `submit=True` also raises the authorisation request."""
    ctx.require("ledger.post")
    require_human(ctx)
    if ledger not in LEDGERS:
        raise ValidationFailed("ledger must be 'office' or 'client'.")
    if matter_id:
        get_matter_for(ctx, matter_id)
    jl = _validate_lines(ctx, ledger, currency, lines)
    j = Journal(firm_id=ctx.firm_id, ledger=ledger, reference=reference[:60], description=description[:400], effective_date=effective_date,
                currency=currency, status="draft", matter_id=matter_id, source_type=source_type, source_id=source_id,
                prepared_by=ctx.user.id, reverses_journal_id=reverses_journal_id)
    ctx.db.add(j)
    ctx.db.flush()
    for l in jl:
        l.journal_id = j.id
        ctx.db.add(l)
    ctx.db.flush()
    ctx.audit("journal.created", "journal", j.id, f"Draft {ledger} journal {j.reference} created", matter_id=matter_id,
              details={"ledger": ledger, "source_type": source_type, "lines": len(jl), "total": str(sum((l.debit for l in jl), ZERO))})
    if submit:
        submit_for_approval(ctx, j.id, extra=approval_extra)
    return j


def _kind_for(j: Journal) -> str:
    return "revenue_recognition" if j.source_type == "revenue_recognition" else "journal_post"


def submit_for_approval(ctx: Ctx, journal_id: uuid.UUID, extra: dict | None = None) -> Approval:
    ctx.require("ledger.post")
    require_human(ctx)
    j = _get_journal(ctx, journal_id, lock=True)
    if j.status != "draft":
        raise InvalidState(f"Only draft journals can be submitted (this one is {j.status}).")
    payload = {**(extra or {}), "journal": journal_payload(j, journal_lines(ctx.db, j.id))}
    ap = approvals.request_approval(ctx, kind=_kind_for(j), subject_type="journal", subject_id=j.id, payload=payload,
                                    matter_id=j.matter_id, required_permission="ledger.approve")
    j.status, j.approval_id = "pending_approval", ap.id
    ctx.db.flush()
    return ap


def decide_approval(ctx: Ctx, approval_id: uuid.UUID, *, approve: bool, note: str | None = None) -> Approval:
    """Finance-scoped wrapper around approvals.decide (journals, allocations, transfers, revenue recognition)."""
    require_human(ctx, "approvals")
    ap = ctx.db.get(Approval, approval_id)
    if not ap or ap.firm_id != ctx.firm_id or ap.kind not in FINANCE_KINDS:
        raise NotFound("Approval not found.")
    ap = approvals.decide(ctx, approval_id, approve=approve, note=note)
    if ap.subject_type == "journal" and ap.subject_id:
        j = ctx.db.get(Journal, ap.subject_id)
        if j and j.status == "pending_approval" and not approve:
            j.status = "draft"
    return ap


def _get_journal(ctx: Ctx, journal_id: uuid.UUID, lock: bool = False) -> Journal:
    stmt = select(Journal).where(Journal.id == journal_id, Journal.firm_id == ctx.firm_id)
    if lock:
        stmt = stmt.with_for_update().execution_options(populate_existing=True)
    j = ctx.db.execute(stmt).scalar_one_or_none()
    if not j:
        raise NotFound("Journal not found.")
    if j.matter_id:
        get_matter_for(ctx, j.matter_id)
    return j


def post_journal(ctx: Ctx, journal_id: uuid.UUID) -> Journal:
    """Post an approved draft. The approval must be approved, by someone other than the preparer, and bound to the exact lines."""
    ctx.require("ledger.post")
    require_human(ctx)
    j = _get_journal(ctx, journal_id, lock=True)
    if j.status != "pending_approval" or not j.approval_id:
        raise InvalidState("This journal has not been submitted for approval.", code="approval_required")
    ap = ctx.db.get(Approval, j.approval_id)
    expected = {**{k: v for k, v in ap.payload.items() if k != "journal"}, "journal": journal_payload(j, journal_lines(ctx.db, j.id))}
    approvals.assert_approved(ctx, ap.id, kind=ap.kind, payload=expected, subject_id=j.id)
    if ap.decided_by == j.prepared_by:
        raise PermissionDenied("Four-eyes control: the preparer of a journal cannot be its approver.", code="four_eyes_required")
    return _post(ctx, j, ap)


def _post(ctx: Ctx, j: Journal, ap: Approval) -> Journal:
    """Internal: post a journal whose authorisation has ALREADY been verified by the caller."""
    lines = journal_lines(ctx.db, j.id)
    td, tc = sum((l.debit for l in lines), ZERO), sum((l.credit for l in lines), ZERO)
    if len(lines) < 2 or td != tc:
        raise ValidationFailed(f"Journal is unbalanced: debits {td} do not equal credits {tc}.", code="unbalanced_journal")
    if j.ledger == "client":
        _check_client_overdraft(ctx.db, lines)
    now = datetime.now(timezone.utc)
    j.status, j.posted_by, j.posted_at, j.approval_id = "posted", ctx.user.id, now, ap.id
    ctx.db.flush()  # DB trigger re-checks balance / ledger separation
    _after_post(ctx, j, ap, lines)
    ctx.audit("journal.posted", "journal", j.id, f"Journal {j.reference} posted ({j.ledger} ledger)", matter_id=j.matter_id,
              details={"ledger": j.ledger, "source_type": j.source_type, "approval_id": str(ap.id), "approved_by": str(ap.decided_by), "total": str(td)})
    return j


def _check_client_overdraft(db: Session, lines: list[JournalLine]) -> None:
    deltas: dict[uuid.UUID, Decimal] = {}
    for l in lines:
        deltas[l.account_id] = deltas.get(l.account_id, ZERO) + l.credit - l.debit
    accts = db.execute(select(LedgerAccount).where(LedgerAccount.id.in_(list(deltas))).order_by(LedgerAccount.id)
                       .with_for_update().execution_options(populate_existing=True)).scalars().all()
    for a in accts:
        if a.system_key == "client_matter" and account_balance(db, a) + deltas[a.id] < 0:
            raise InvalidState(f"Posting would overdraw client account {a.code}: client money for a matter can never go negative.",
                               code="client_account_overdrawn", details={"account": a.code})


def recognisable_remaining(db: Session, inv: Invoice) -> Decimal:
    """Net fees on an issued invoice not yet recognised and not credited."""
    rec = db.execute(select(func.coalesce(func.sum(RevenueRecognition.amount), 0)).where(RevenueRecognition.invoice_id == inv.id)).scalar_one()
    cred = db.execute(select(func.coalesce(func.sum(Invoice.subtotal), 0)).where(
        Invoice.credit_for_invoice_id == inv.id, Invoice.kind == "credit_note", Invoice.status == "issued")).scalar_one()
    return q(inv.subtotal) - q(Decimal(rec)) - q(Decimal(cred))


def _after_post(ctx: Ctx, j: Journal, ap: Approval, lines: list[JournalLine]) -> None:
    db = ctx.db
    if j.source_type == "revenue_recognition":
        inv = db.execute(select(Invoice).where(Invoice.id == j.source_id).with_for_update().execution_options(populate_existing=True)).scalar_one()
        amount = sum((l.credit for l in lines), ZERO)
        if amount > recognisable_remaining(db, inv):
            raise InvalidState("Revenue recognition exceeds the unrecognised net fees on the invoice.", code="over_recognition")
        db.add(RevenueRecognition(firm_id=ctx.firm_id, invoice_id=inv.id, matter_id=inv.matter_id, amount=amount,
                                  basis=str(ap.payload.get("basis") or "Recognised on authorisation")[:300], recognised_by=ctx.user.id,
                                  approval_id=ap.id, journal_id=j.id, recognised_on=j.effective_date, created_at=datetime.now(timezone.utc)))
    elif j.source_type == "receipt":
        pay = db.execute(select(Payment).where(Payment.receipt_journal_id == j.id)).scalar_one_or_none()
        if pay and pay.status == "pending_authorisation":
            pay.status = "received_unallocated"
    elif j.source_type == "reversal" and j.reverses_journal_id:
        orig = db.execute(select(Journal).where(Journal.id == j.reverses_journal_id).with_for_update().execution_options(populate_existing=True)).scalar_one()
        if orig.status != "posted":
            raise InvalidState("The journal being reversed is no longer in the posted state.")
        orig.status = "reversed"
    db.flush()


def reverse_journal(ctx: Ctx, journal_id: uuid.UUID, reason: str) -> Journal:
    """Create a DRAFT reversing journal (must itself be approved and posted). Only manual journals can be reversed here;
    invoice/receipt/allocation journals are undone through their own workflows (credit note, etc.)."""
    ctx.require("ledger.post")
    require_human(ctx)
    j = _get_journal(ctx, journal_id)
    if j.status != "posted":
        raise InvalidState("Only posted journals can be reversed.")
    if j.source_type not in (None, "manual"):
        raise InvalidState(f"Journals created by '{j.source_type}' cannot be reversed directly; use the originating workflow.")
    if ctx.db.execute(select(Journal.id).where(Journal.reverses_journal_id == j.id, Journal.status != "draft")).first():
        raise InvalidState("A reversal for this journal already exists.")
    if not reason or len(reason.strip()) < 3:
        raise ValidationFailed("A reason is required to reverse a journal.")
    lines = [{"account_id": l.account_id, "debit": l.credit, "credit": l.debit, "matter_id": l.matter_id, "narrative": f"Reversal of {j.reference}"}
             for l in journal_lines(ctx.db, j.id)]
    rj = create_journal(ctx, ledger=j.ledger, reference=f"REV-{j.reference}"[:60], description=f"Reversal of {j.reference}: {reason}"[:400],
                        effective_date=date.today(), lines=lines, source_type="reversal", source_id=j.id, matter_id=j.matter_id,
                        currency=j.currency, reverses_journal_id=j.id, submit=True, approval_extra={"reason": reason[:300]})
    return rj


# ------------------------------------------------------------------------------------------ invoice balances
def credited_total(db: Session, invoice_id: uuid.UUID, *, issued_only: bool = True, exclude: uuid.UUID | None = None) -> Decimal:
    stmt = select(func.coalesce(func.sum(Invoice.total), 0)).where(Invoice.credit_for_invoice_id == invoice_id, Invoice.kind == "credit_note")
    stmt = stmt.where(Invoice.status == "issued") if issued_only else stmt.where(Invoice.status != "void")
    if exclude:
        stmt = stmt.where(Invoice.id != exclude)
    return q(Decimal(db.execute(stmt).scalar_one()))


def invoice_outstanding(db: Session, inv: Invoice) -> Decimal:
    if inv.kind != "invoice":
        return ZERO
    return q(inv.total) - q(inv.amount_paid) - credited_total(db, inv.id)


# ------------------------------------------------------------------------------------------ allocation
def _norm_allocations(allocs: list[dict]) -> list[dict]:
    merged: dict[str, Decimal] = {}
    for a in allocs:
        amt = q(Decimal(str(a["amount"])))
        if amt <= 0:
            raise ValidationFailed("Allocation amounts must be positive.")
        merged[str(a["invoice_id"])] = merged.get(str(a["invoice_id"]), ZERO) + amt
    return [{"invoice_id": k, "amount": str(v)} for k, v in sorted(merged.items())]


def _allocation_payload(payment_id, allocs: list[dict]) -> dict:
    return {"payment_id": str(payment_id), "allocations": _norm_allocations(allocs)}


def _lock_for_allocation(ctx: Ctx, payment_id: uuid.UUID, allocs: list[dict]) -> tuple[Payment, dict[str, Invoice]]:
    db = ctx.db
    pay = db.execute(select(Payment).where(Payment.id == payment_id, Payment.firm_id == ctx.firm_id).with_for_update()
                     .execution_options(populate_existing=True)).scalar_one_or_none()
    if not pay:
        raise NotFound("Payment not found.")
    ids = sorted({uuid.UUID(a["invoice_id"]) for a in allocs})
    invs = db.execute(select(Invoice).where(Invoice.id.in_(ids), Invoice.firm_id == ctx.firm_id).order_by(Invoice.id).with_for_update()
                      .execution_options(populate_existing=True)).scalars().all()
    if len(invs) != len(ids):
        raise NotFound("One or more invoices were not found.")
    return pay, {str(i.id): i for i in invs}


def _check_allocation(ctx: Ctx, pay: Payment, invs: dict[str, Invoice], allocs: list[dict]) -> None:
    if pay.ledger != "office":
        raise InvalidState("Client-money receipts are not allocated to invoices; use a client-to-office transfer.", code="client_money_not_allocatable")
    if pay.status not in ("received_unallocated", "partially_allocated"):
        raise InvalidState(f"Payment is {pay.status}; only authorised, unallocated receipts can be allocated.")
    total = sum((q(Decimal(a["amount"])) for a in allocs), ZERO)
    if total > q(pay.amount) - q(pay.allocated_amount):
        raise InvalidState(f"Allocation {total} exceeds the unallocated balance {q(pay.amount) - q(pay.allocated_amount)} of the payment.", code="over_allocation")
    for a in allocs:
        inv = invs[a["invoice_id"]]
        if inv.kind != "invoice" or inv.status not in ("issued", "partially_paid"):
            raise InvalidState(f"Invoice {inv.number or inv.id} is {inv.status}; only issued invoices can receive payments.")
        if inv.currency != pay.currency:
            raise ValidationFailed("Payment and invoice currencies differ.")
        get_matter_for(ctx, inv.matter_id)
        if q(Decimal(a["amount"])) > invoice_outstanding(ctx.db, inv):
            raise InvalidState(f"Allocation exceeds the outstanding balance of invoice {inv.number}.", code="over_allocation")


def request_allocation(ctx: Ctx, payment_id: uuid.UUID, allocations: list[dict]) -> Approval:
    ctx.require("ledger.post")
    require_human(ctx)
    allocs = _norm_allocations(allocations)
    pay = ctx.db.get(Payment, payment_id)
    if not pay or pay.firm_id != ctx.firm_id:
        raise NotFound("Payment not found.")
    invs = {str(i.id): i for i in ctx.db.execute(select(Invoice).where(Invoice.id.in_([uuid.UUID(a["invoice_id"]) for a in allocs]), Invoice.firm_id == ctx.firm_id)).scalars()}
    if len(invs) != len(allocs):
        raise NotFound("One or more invoices were not found.")
    _check_allocation(ctx, pay, invs, allocs)  # fail early; re-checked under lock at execution
    ap = approvals.request_approval(ctx, kind="payment_allocation", subject_type="payment", subject_id=payment_id,
                                    payload=_allocation_payload(payment_id, allocs), matter_id=pay.matter_id, required_permission="ledger.approve")
    return ap


def execute_allocation(ctx: Ctx, payment_id: uuid.UUID, allocations: list[dict], approval_id: uuid.UUID) -> dict:
    """Apply an APPROVED allocation atomically. Locks the payment and invoices (ordered) so that duplicate or
    concurrent executions can neither over-allocate nor apply the same approval twice."""
    ctx.require("ledger.post")
    require_human(ctx)
    allocs = _norm_allocations(allocations)
    ap = approvals.assert_approved(ctx, approval_id, kind="payment_allocation", payload=_allocation_payload(payment_id, allocs), subject_id=payment_id)
    pay, invs = _lock_for_allocation(ctx, payment_id, allocs)   # <- row locks; everything below sees committed state
    if ctx.db.execute(select(PaymentAllocation.id).where(PaymentAllocation.approval_id == ap.id)).first():
        raise InvalidState("This approval has already been used to allocate the payment.", code="already_executed")
    _check_allocation(ctx, pay, invs, allocs)
    total = sum((q(Decimal(a["amount"])) for a in allocs), ZERO)
    debtors, unalloc = system_account(ctx.db, ctx.firm_id, "debtors", "office"), system_account(ctx.db, ctx.firm_id, "unallocated_receipts", "office")
    jl = [{"account_id": unalloc.id, "debit": total, "matter_id": pay.matter_id, "narrative": f"Allocate receipt {pay.reference or pay.id}"}]
    for a in allocs:
        inv = invs[a["invoice_id"]]
        jl.append({"account_id": debtors.id, "credit": q(Decimal(a["amount"])), "matter_id": inv.matter_id, "narrative": f"Payment to {inv.number}"})
    j = create_journal(ctx, ledger="office", reference=f"ALLOC-{str(pay.id)[:8]}-{str(ap.id)[:6]}", description=f"Allocation of receipt to {len(allocs)} invoice(s)",
                       effective_date=date.today(), lines=jl, source_type="allocation", source_id=pay.id, matter_id=pay.matter_id, currency=pay.currency)
    j.status = "pending_approval"  # authorised by the payment_allocation approval verified above
    ctx.db.flush()
    _post(ctx, j, ap)
    now = datetime.now(timezone.utc)
    for a in allocs:
        inv, amt = invs[a["invoice_id"]], q(Decimal(a["amount"]))
        ctx.db.add(PaymentAllocation(firm_id=ctx.firm_id, payment_id=pay.id, invoice_id=inv.id, amount=amt, allocated_by=ctx.user.id,
                                     approval_id=ap.id, journal_id=j.id, created_at=now))
        inv.amount_paid = q(inv.amount_paid) + amt
        inv.status = "paid" if invoice_outstanding(ctx.db, inv) == 0 else "partially_paid"
    pay.allocated_amount = q(pay.allocated_amount) + total
    pay.status = "allocated" if pay.allocated_amount == q(pay.amount) else "partially_allocated"
    ctx.db.flush()
    ctx.audit("payment.allocated", "payment", pay.id, f"Receipt allocated to {len(allocs)} invoice(s)", matter_id=pay.matter_id,
              details={"amount": str(total), "invoices": [a["invoice_id"] for a in allocs], "approval_id": str(ap.id), "journal_id": str(j.id)})
    return {"payment": pay, "journal": j, "allocations": allocs}


# ------------------------------------------------------------------------------------------ client -> office transfer
def _transfer_payload(invoice_id, matter_id, amount: Decimal, currency: str) -> dict:
    return {"invoice_id": str(invoice_id), "matter_id": str(matter_id), "amount": str(q(amount)), "currency": currency}


def request_client_transfer(ctx: Ctx, invoice_id: uuid.UUID, amount: Decimal) -> Approval:
    """Propose moving client money to office account to pay an issued invoice. Only a human with ledger.post can propose;
    a different human with ledger.approve must authorise; AI agents can do neither."""
    ctx.require("ledger.post")
    require_human(ctx, "client-money transfers")
    amount = q(Decimal(str(amount)))
    inv = ctx.db.get(Invoice, invoice_id)
    if not inv or inv.firm_id != ctx.firm_id:
        raise NotFound("Invoice not found.")
    get_matter_for(ctx, inv.matter_id)
    _check_transfer(ctx, inv, amount)
    return approvals.request_approval(ctx, kind="client_funds_transfer", subject_type="invoice", subject_id=inv.id,
                                      payload=_transfer_payload(inv.id, inv.matter_id, amount, inv.currency), matter_id=inv.matter_id,
                                      required_permission="ledger.approve")


def _check_transfer(ctx: Ctx, inv: Invoice, amount: Decimal) -> None:
    if amount <= 0:
        raise ValidationFailed("Transfer amount must be positive.")
    if inv.kind != "invoice" or inv.status not in ("issued", "partially_paid"):
        raise InvalidState("Client money may only be applied to an issued invoice (a bill must be delivered first).", code="invoice_not_issued")
    if amount > invoice_outstanding(ctx.db, inv):
        raise InvalidState("Transfer exceeds the outstanding balance of the invoice.", code="over_allocation")
    from app.services.matter_finance import client_balance
    bal = client_balance(ctx.db, inv.matter_id)
    if amount > bal:
        raise InvalidState(f"Insufficient client money on this matter ({bal} held, {amount} requested).", code="insufficient_client_funds")


def execute_client_transfer(ctx: Ctx, invoice_id: uuid.UUID, amount: Decimal, approval_id: uuid.UUID) -> dict:
    ctx.require("ledger.post")
    require_human(ctx, "client-money transfers")
    amount = q(Decimal(str(amount)))
    inv0 = ctx.db.get(Invoice, invoice_id)
    if not inv0 or inv0.firm_id != ctx.firm_id:
        raise NotFound("Invoice not found.")
    ap = approvals.assert_approved(ctx, approval_id, kind="client_funds_transfer",
                                   payload=_transfer_payload(inv0.id, inv0.matter_id, amount, inv0.currency), subject_id=inv0.id)
    get_matter_for(ctx, inv0.matter_id)
    caccount = client_account_for_matter(ctx, inv0.matter_id)
    ctx.db.execute(select(LedgerAccount).where(LedgerAccount.id == caccount.id).with_for_update().execution_options(populate_existing=True))
    inv = ctx.db.execute(select(Invoice).where(Invoice.id == inv0.id).with_for_update().execution_options(populate_existing=True)).scalar_one()
    if ctx.db.execute(select(Journal.id).where(Journal.source_type == "client_transfer", Journal.approval_id == ap.id)).first():
        raise InvalidState("This approval has already been used for a transfer.", code="already_executed")
    _check_transfer(ctx, inv, amount)
    ref = f"XFER-{inv.number}-{str(ap.id)[:6]}"
    cj = create_journal(ctx, ledger="client", reference=ref, description=f"Client funds applied to {inv.number}", effective_date=date.today(),
                        lines=[{"account_id": caccount.id, "debit": amount, "matter_id": inv.matter_id},
                               {"system_key": "bank_client", "credit": amount, "matter_id": inv.matter_id}],
                        source_type="client_transfer", source_id=inv.id, matter_id=inv.matter_id, currency=inv.currency)
    oj = create_journal(ctx, ledger="office", reference=ref, description=f"Receipt from client account for {inv.number}", effective_date=date.today(),
                        lines=[{"system_key": "bank_office", "debit": amount, "matter_id": inv.matter_id},
                               {"system_key": "debtors", "credit": amount, "matter_id": inv.matter_id}],
                        source_type="client_transfer", source_id=inv.id, matter_id=inv.matter_id, currency=inv.currency)
    for j in (cj, oj):
        j.status = "pending_approval"
    ctx.db.flush()
    _post(ctx, cj, ap)
    _post(ctx, oj, ap)
    pay = Payment(firm_id=ctx.firm_id, ledger="office", matter_id=inv.matter_id, received_from_id=inv.client_id, amount=amount, allocated_amount=amount,
                  currency=inv.currency, received_on=date.today(), reference=f"Client account transfer {ref}", status="allocated",
                  receipt_journal_id=oj.id, recorded_by=ctx.user.id)
    ctx.db.add(pay)
    ctx.db.flush()
    ctx.db.add(PaymentAllocation(firm_id=ctx.firm_id, payment_id=pay.id, invoice_id=inv.id, amount=amount, allocated_by=ctx.user.id,
                                 approval_id=ap.id, journal_id=oj.id, created_at=datetime.now(timezone.utc)))
    inv.amount_paid = q(inv.amount_paid) + amount
    inv.status = "paid" if invoice_outstanding(ctx.db, inv) == 0 else "partially_paid"
    ctx.db.flush()
    ctx.audit("client_funds.transferred", "invoice", inv.id, f"Client funds of {amount} applied to invoice {inv.number}", matter_id=inv.matter_id,
              details={"amount": str(amount), "approval_id": str(ap.id), "client_journal": str(cj.id), "office_journal": str(oj.id)})
    return {"invoice": inv, "client_journal": cj, "office_journal": oj, "payment": pay}


# ------------------------------------------------------------------------------------------ revenue recognition
def request_revenue_recognition(ctx: Ctx, invoice_id: uuid.UUID, amount: Decimal, basis: str, recognised_on: date | None = None) -> Journal:
    """Revenue is recognised only through this explicit, separately authorised step (Dr fees billed-unrecognised / Cr fee income).
    Creates a draft journal + approval; posting (post_journal) writes the revenue_recognitions row."""
    ctx.require("ledger.post")
    require_human(ctx, "revenue recognition")
    amount = q(Decimal(str(amount)))
    if not basis or len(basis.strip()) < 5:
        raise ValidationFailed("State the basis for recognising this revenue (e.g. 'work completed and billed per fee arrangement').")
    inv = ctx.db.get(Invoice, invoice_id)
    if not inv or inv.firm_id != ctx.firm_id:
        raise NotFound("Invoice not found.")
    get_matter_for(ctx, inv.matter_id)
    if inv.kind != "invoice" or inv.status not in ("issued", "partially_paid", "paid"):
        raise InvalidState("Only issued invoices can have revenue recognised.")
    if amount <= 0 or amount > recognisable_remaining(ctx.db, inv):
        raise InvalidState(f"Amount must be positive and at most the unrecognised net fees ({recognisable_remaining(ctx.db, inv)}).", code="over_recognition")
    return create_journal(ctx, ledger="office", reference=f"REVREC-{inv.number}", description=f"Revenue recognition on {inv.number}: {basis}"[:400],
                          effective_date=recognised_on or date.today(),
                          lines=[{"system_key": "fees_billed_unrecognised", "debit": amount, "matter_id": inv.matter_id},
                                 {"system_key": "fee_income", "credit": amount, "matter_id": inv.matter_id}],
                          source_type="revenue_recognition", source_id=inv.id, matter_id=inv.matter_id, currency=inv.currency, submit=True,
                          approval_extra={"invoice_id": str(inv.id), "basis": basis.strip()[:300], "amount": str(amount)})
