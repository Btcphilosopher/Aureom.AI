"""Background sweeps: task reminders and escalations. Idempotent (last_reminded_at / escalated_at markers)."""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.session import bind_firm, new_session
from app.models import Firm, Job, Task
from app.services.jobs import job_handler
from app.services.notify import notify
from app.services.tasks import OPEN_STATES

log = logging.getLogger("aureom.task_jobs")


def sweep_firm(db: Session, firm_id: uuid.UUID, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    bind_firm(db, firm_id)
    reminders = escalations = 0
    base = select(Task).where(Task.firm_id == firm_id, Task.status.in_(OPEN_STATES), Task.due_at.is_not(None))
    for t in db.execute(base.where(Task.assignee_id.is_not(None))).scalars():
        offs = list(t.reminder_offsets_minutes or [])
        if not offs or now > t.due_at:
            continue
        due_times = [t.due_at - timedelta(minutes=o) for o in offs]
        pending = [r for r in due_times if r <= now and (t.last_reminded_at is None or t.last_reminded_at < r)]
        if pending:
            notify(db, firm_id=firm_id, user_id=t.assignee_id, kind="task_reminder", title=f"Reminder: {t.title[:150]}",
                   body=f"Due {t.due_at.strftime('%d %b %Y %H:%M')} UTC", link=f"/tasks/{t.id}", matter_id=t.matter_id)
            t.last_reminded_at = now
            reminders += 1
    for t in db.execute(base.where(Task.escalate_to_id.is_not(None), Task.escalate_after_hours.is_not(None), Task.escalated_at.is_(None))).scalars():
        if t.due_at + timedelta(hours=t.escalate_after_hours) <= now:
            notify(db, firm_id=firm_id, user_id=t.escalate_to_id, kind="task_escalated", title=f"Escalation: overdue task - {t.title[:140]}",
                   body=f"Overdue by more than {t.escalate_after_hours}h and not completed.", link=f"/tasks/{t.id}", matter_id=t.matter_id)
            t.escalated_at = now
            escalations += 1
    db.flush()
    return {"reminders": reminders, "escalations": escalations}


def sweep_all_firms(now: datetime | None = None) -> dict:
    totals = {"reminders": 0, "escalations": 0}
    with new_session() as s:  # firms table is exempt from RLS
        firm_ids = list(s.execute(select(Firm.id)).scalars())
    for fid in firm_ids:
        s = new_session(fid)
        try:
            r = sweep_firm(s, fid, now)
            s.commit()
            for k in totals:
                totals[k] += r[k]
        except Exception:  # noqa: BLE001
            s.rollback()
            log.warning("task sweep failed for a firm")
        finally:
            s.close()
    return totals


@job_handler("task_sweep")
def _handle(db: Session, job: Job) -> dict:
    return sweep_firm(db, job.firm_id)
