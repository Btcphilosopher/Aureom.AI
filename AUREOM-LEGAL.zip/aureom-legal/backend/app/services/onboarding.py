"""Client onboarding with SIMULATED identity checks and human approval."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone

from sqlalchemy import select

from app.deps import Ctx
from app.errors import InvalidState, NotFound, PermissionDenied, ValidationFailed, VersionConflict
from app.integrations import base as integrations
from app.integrations.identity import SIMULATED_NOTICE, STATUS_LABELS
from app.models import Contact, Firm, OnboardingCheck, OnboardingRecord
from app.services import contacts as contacts_svc

OK_STATUSES = {"passed_simulated", "waived"}
STATUS_LABEL_RECORD = {"not_started": "Not started", "in_progress": "In progress", "awaiting_client": "Awaiting client",
                       "awaiting_review": "Awaiting human review", "approved": "Approved by reviewer", "rejected": "Rejected"}
MAX_FORM_BYTES = 100_000


def firm_check_types(ctx: Ctx) -> list[dict]:
    firm = ctx.db.get(Firm, ctx.firm_id)
    return list((firm.settings or {}).get("onboarding_check_types", []))


def required_checks(ctx: Ctx, contact: Contact) -> list[str]:
    firm = ctx.db.get(Firm, ctx.firm_id)
    req = (firm.settings or {}).get("onboarding_required_checks", [])
    types = {t["key"]: t for t in firm_check_types(ctx)}
    return [k for k in req if types.get(k, {}).get("applies_to", "any") in ("any", contact.kind)]


def get_record(ctx: Ctx, contact: Contact) -> OnboardingRecord | None:
    return ctx.db.execute(select(OnboardingRecord).where(OnboardingRecord.contact_id == contact.id)
                          .order_by(OnboardingRecord.created_at.desc())).scalars().first()


def get_or_create(ctx: Ctx, contact: Contact) -> OnboardingRecord:
    ctx.require("onboarding.manage")
    rec = get_record(ctx, contact)
    if not rec:
        rec = OnboardingRecord(firm_id=ctx.firm_id, contact_id=contact.id, status="not_started")
        ctx.db.add(rec)
        ctx.db.flush()
        ctx.audit("onboarding.created", "onboarding", rec.id, f"Onboarding started for {contact.display_name}")
    return rec


def _touch(rec: OnboardingRecord) -> None:
    if rec.status == "not_started":
        rec.status = "in_progress"


def submit_form(ctx: Ctx, contact: Contact, form: dict) -> OnboardingRecord:
    ctx.require("onboarding.manage")
    if len(json.dumps(form)) > MAX_FORM_BYTES:
        raise ValidationFailed("Intake form is too large.")
    rec = get_or_create(ctx, contact)
    if rec.status in ("approved", "rejected"):
        raise InvalidState(f"Onboarding is already {rec.status}.")
    rec.submitted_form = form  # raw, untrusted: only ever rendered as text
    _touch(rec)
    ctx.db.flush()
    ctx.audit("onboarding.form_submitted", "onboarding", rec.id, f"Intake form recorded for {contact.display_name}", details={"fields": sorted(form.keys())[:50]})
    return rec


def run_check(ctx: Ctx, contact: Contact, check_type: str) -> OnboardingCheck:
    ctx.require("onboarding.manage")
    types = {t["key"]: t for t in firm_check_types(ctx)}
    if check_type not in types:
        raise ValidationFailed(f"Unknown check type '{check_type}'.", details={"allowed": sorted(types)})
    if types[check_type].get("applies_to", "any") not in ("any", contact.kind):
        raise ValidationFailed(f"The '{check_type}' check does not apply to a {contact.kind}.")
    rec = get_or_create(ctx, contact)
    if rec.status in ("approved", "rejected"):
        raise InvalidState(f"Onboarding is already {rec.status}.")
    provider = integrations.get_available("identity")
    res = provider.run_check(check_type, {"display_name": contact.display_name, "aliases": contact.aliases, "kind": contact.kind})
    info = provider.info()
    chk = ctx.db.execute(select(OnboardingCheck).where(OnboardingCheck.onboarding_id == rec.id, OnboardingCheck.check_type == check_type)).scalars().first()
    if not chk:
        chk = OnboardingCheck(firm_id=ctx.firm_id, onboarding_id=rec.id, check_type=check_type)
        ctx.db.add(chk)
    chk.provider, chk.is_simulated = info.provider, info.mode == "mock"
    chk.status, chk.result_summary, chk.external_ref = res.status, res.summary, res.external_ref
    chk.performed_by, chk.performed_at = ctx.user.id, datetime.now(timezone.utc)
    chk.reviewed_by = chk.reviewed_at = chk.review_note = None
    _touch(rec)
    ctx.db.flush()
    ctx.audit("onboarding.check_run", "onboarding", rec.id, f"Ran simulated check {check_type} for {contact.display_name}",
              details={"check_type": check_type, "status": chk.status, "simulated": chk.is_simulated})
    return chk


def _get_check(ctx: Ctx, contact: Contact, check_id: uuid.UUID) -> tuple[OnboardingRecord, OnboardingCheck]:
    rec = get_record(ctx, contact)
    chk = ctx.db.get(OnboardingCheck, check_id)
    if not rec or not chk or chk.onboarding_id != rec.id or chk.firm_id != ctx.firm_id:
        raise NotFound("Check not found.")
    return rec, chk


def review_check(ctx: Ctx, contact: Contact, check_id: uuid.UUID, decision: str, note: str) -> OnboardingCheck:
    ctx.require("onboarding.approve")
    rec, chk = _get_check(ctx, contact, check_id)
    if rec.status in ("approved", "rejected"):
        raise InvalidState(f"Onboarding is already {rec.status}.")
    prev = chk.status
    chk.status = "passed_simulated" if decision == "accept" else "failed"
    chk.reviewed_by, chk.reviewed_at, chk.review_note = ctx.user.id, datetime.now(timezone.utc), note
    ctx.db.flush()
    ctx.audit("onboarding.check_reviewed", "onboarding", rec.id, f"Human review of {chk.check_type}: {decision}",
              details={"check_type": chk.check_type, "from": prev, "to": chk.status})
    return chk


def waive_check(ctx: Ctx, contact: Contact, check_id: uuid.UUID, reason: str) -> OnboardingCheck:
    ctx.require("onboarding.approve")
    rec, chk = _get_check(ctx, contact, check_id)
    chk.status, chk.reviewed_by, chk.reviewed_at, chk.review_note = "waived", ctx.user.id, datetime.now(timezone.utc), reason
    ctx.db.flush()
    ctx.audit("onboarding.check_waived", "onboarding", rec.id, f"Check {chk.check_type} waived by reviewer", details={"check_type": chk.check_type})
    return chk


def submit_for_review(ctx: Ctx, contact: Contact) -> OnboardingRecord:
    ctx.require("onboarding.manage")
    rec = get_or_create(ctx, contact)
    if rec.status in ("approved", "rejected"):
        raise InvalidState(f"Onboarding is already {rec.status}.")
    rec.status = "awaiting_review"
    ctx.db.flush()
    ctx.audit("onboarding.submitted_for_review", "onboarding", rec.id, f"Onboarding for {contact.display_name} submitted for review")
    return rec


def blockers(ctx: Ctx, contact: Contact, rec: OnboardingRecord | None) -> list[dict]:
    out: list[dict] = []
    checks = {c.check_type: c for c in ctx.db.execute(select(OnboardingCheck).where(OnboardingCheck.onboarding_id == rec.id)).scalars()} if rec else {}
    for key in required_checks(ctx, contact):
        c = checks.get(key)
        if not c:
            out.append({"code": "check_missing", "check_type": key, "message": f"Required check '{key}' has not been run."})
        elif c.status not in OK_STATUSES:
            out.append({"code": "check_not_passed", "check_type": key, "message": f"Required check '{key}' is {STATUS_LABELS.get(c.status, c.status)}."})
        elif c.status == "waived" and not (c.review_note or "").strip():
            out.append({"code": "waiver_unexplained", "check_type": key, "message": f"Waiver of '{key}' needs a recorded reason."})
    return out


def approve(ctx: Ctx, contact: Contact, note: str | None, risk_level: str | None) -> OnboardingRecord:
    ctx.require("onboarding.approve")
    rec = get_record(ctx, contact)
    if not rec:
        raise InvalidState("Onboarding has not been started.")
    if rec.status in ("approved", "rejected"):
        raise InvalidState(f"Onboarding is already {rec.status}.")
    b = blockers(ctx, contact, rec)
    if b:
        raise ValidationFailed("Required onboarding checks are incomplete.", code="onboarding_blocked", details={"blockers": b})
    rec.status, rec.reviewed_by, rec.reviewed_at = "approved", ctx.user.id, datetime.now(timezone.utc)
    rec.risk_level = risk_level or rec.risk_level
    if note:
        rec.notes = note
    contacts_svc.make_client(ctx, contact)
    ctx.db.flush()
    ctx.audit("onboarding.approved", "onboarding", rec.id, f"Onboarding approved for {contact.display_name} (checks were simulated)",
              details={"client_ref": contact.client_ref, "risk_level": rec.risk_level})
    return rec


def reject(ctx: Ctx, contact: Contact, note: str | None) -> OnboardingRecord:
    ctx.require("onboarding.approve")
    rec = get_record(ctx, contact)
    if not rec:
        raise InvalidState("Onboarding has not been started.")
    if rec.status in ("approved", "rejected"):
        raise InvalidState(f"Onboarding is already {rec.status}.")
    rec.status, rec.reviewed_by, rec.reviewed_at, rec.notes = "rejected", ctx.user.id, datetime.now(timezone.utc), note or rec.notes
    ctx.db.flush()
    ctx.audit("onboarding.rejected", "onboarding", rec.id, f"Onboarding rejected for {contact.display_name}")
    return rec


def onboarding_out(ctx: Ctx, contact: Contact) -> dict:
    rec = get_record(ctx, contact)
    checks = ctx.db.execute(select(OnboardingCheck).where(OnboardingCheck.onboarding_id == rec.id).order_by(OnboardingCheck.check_type)).scalars().all() if rec else []
    types = firm_check_types(ctx)
    by_type = {c.check_type: c for c in checks}
    return {
        "simulated_notice": SIMULATED_NOTICE,
        "record": None if not rec else {
            "id": str(rec.id), "status": rec.status, "status_label": STATUS_LABEL_RECORD.get(rec.status, rec.status), "risk_level": rec.risk_level,
            "submitted_form": rec.submitted_form, "notes": rec.notes, "version": rec.version,
            "reviewed_by": str(rec.reviewed_by) if rec.reviewed_by else None,
            "reviewed_at": rec.reviewed_at.isoformat() if rec.reviewed_at else None,
        },
        "status": rec.status if rec else "not_started",
        "required_checks": required_checks(ctx, contact),
        "check_types": [{**t, "applicable": t.get("applies_to", "any") in ("any", contact.kind), "required": t["key"] in required_checks(ctx, contact)} for t in types],
        "checks": [{
            "id": str(c.id), "check_type": c.check_type, "provider": c.provider, "simulated": c.is_simulated, "status": c.status,
            "status_label": STATUS_LABELS.get(c.status, c.status), "result_summary": c.result_summary, "external_ref": c.external_ref,
            "performed_at": c.performed_at.isoformat() if c.performed_at else None,
            "reviewed_by": str(c.reviewed_by) if c.reviewed_by else None, "review_note": c.review_note,
        } for c in checks],
        "blockers": blockers(ctx, contact, rec),
        "checks_missing": [t["key"] for t in types if t["key"] not in by_type],
    }
