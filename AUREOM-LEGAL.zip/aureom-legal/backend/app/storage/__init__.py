"""S3-compatible object storage with a local-filesystem implementation for development and tests.
Objects are write-once: originals are immutable."""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path

from app.config import get_settings


class StorageError(Exception):
    pass


class ObjectExists(StorageError):
    pass


class Storage(ABC):
    kind = "abstract"

    @abstractmethod
    def put(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> None: ...
    @abstractmethod
    def get(self, key: str) -> bytes: ...
    @abstractmethod
    def exists(self, key: str) -> bool: ...
    def status(self) -> dict:
        return {"backend": self.kind}


class LocalStorage(Storage):
    kind = "local"

    def __init__(self, root: str):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise StorageError("invalid storage key")
        return p

    def put(self, key, data, content_type="application/octet-stream"):
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(p, "xb") as f:  # exclusive create: never overwrite
                f.write(data)
        except FileExistsError as e:
            raise ObjectExists(key) from e

    def get(self, key):
        try:
            return self._path(key).read_bytes()
        except FileNotFoundError as e:
            raise StorageError("object not found") from e

    def exists(self, key):
        return self._path(key).exists()


class S3Storage(Storage):
    kind = "s3"

    def __init__(self):
        import boto3  # lazy import

        s = get_settings()
        self.bucket = s.s3_bucket
        self.client = boto3.client("s3", endpoint_url=s.s3_endpoint_url, region_name=s.s3_region,
                                   aws_access_key_id=s.s3_access_key, aws_secret_access_key=s.s3_secret_key)

    def ensure_bucket(self) -> None:
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:  # noqa: BLE001
            self.client.create_bucket(Bucket=self.bucket)

    def put(self, key, data, content_type="application/octet-stream"):
        if self.exists(key):
            raise ObjectExists(key)
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type, ServerSideEncryption="AES256") \
            if get_settings().s3_endpoint_url is None else self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)

    def get(self, key):
        try:
            return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()
        except Exception as e:  # noqa: BLE001
            raise StorageError("object not found") from e

    def exists(self, key):
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:  # noqa: BLE001
            return False

    def status(self):
        return {"backend": "s3", "bucket": self.bucket, "endpoint": get_settings().s3_endpoint_url or "aws"}


_storage: Storage | None = None


def get_storage() -> Storage:
    global _storage
    if _storage is None:
        s = get_settings()
        if s.storage_backend == "s3":
            st = S3Storage()
            st.ensure_bucket()
            _storage = st
        else:
            _storage = LocalStorage(s.local_storage_path)
    return _storage


def reset_storage() -> None:
    global _storage
    _storage = None
