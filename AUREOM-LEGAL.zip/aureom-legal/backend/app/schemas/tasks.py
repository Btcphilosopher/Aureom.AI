from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field

Priority = Literal["low", "normal", "high", "urgent"]


class Recurrence(BaseModel):
    freq: Literal["daily", "weekly", "monthly"]
    interval: int = Field(1, ge=1, le=52)
    until: date | None = None


class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    matter_id: uuid.UUID | None = None
    description: str | None = None
    assignee_id: uuid.UUID | None = None
    due_at: datetime | None = None
    priority: Priority = "normal"
    recurrence: Recurrence | None = None
    reminder_offsets_minutes: list[int] = Field(default_factory=list)
    escalate_to_id: uuid.UUID | None = None
    escalate_after_hours: int | None = Field(None, ge=1, le=24 * 60)
    depends_on: list[uuid.UUID] = Field(default_factory=list)


class TaskUpdate(BaseModel):
    expected_version: int
    title: str | None = Field(None, min_length=1, max_length=300)
    description: str | None = None
    assignee_id: uuid.UUID | None = None
    due_at: datetime | None = None
    priority: Priority | None = None
    recurrence: Recurrence | None = None
    reminder_offsets_minutes: list[int] | None = None
    escalate_to_id: uuid.UUID | None = None
    escalate_after_hours: int | None = Field(None, ge=1, le=24 * 60)


class DependencyIn(BaseModel):
    depends_on_task_id: uuid.UUID


class BlockerOut(BaseModel):
    id: uuid.UUID
    title: str
    status: str


class TaskOut(BaseModel):
    id: uuid.UUID
    matter_id: uuid.UUID | None
    matter_reference: str | None = None
    matter_title: str | None = None
    title: str
    description: str | None
    assignee_id: uuid.UUID | None
    assignee_name: str | None = None
    created_by: uuid.UUID | None
    due_at: datetime | None
    status: str
    priority: str
    completed_at: datetime | None
    recurrence: dict | None
    reminder_offsets_minutes: list[int]
    escalate_to_id: uuid.UUID | None
    escalate_after_hours: int | None
    escalated_at: datetime | None
    deadline_id: uuid.UUID | None
    source: str
    agent_run_id: uuid.UUID | None
    version: int
    is_overdue: bool
    blocked_by: list[BlockerOut] = Field(default_factory=list)
    created_at: datetime
