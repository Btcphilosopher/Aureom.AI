from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class AttachmentOut(ORM):
    id: uuid.UUID
    filename: str
    content_type: str
    size_bytes: int
    scan_status: str
    document_id: uuid.UUID | None


class CorrespondenceListItem(ORM):
    id: uuid.UUID
    matter_id: uuid.UUID | None
    matter_reference: str | None = None
    direction: str
    status: str
    from_addr: str
    to_addrs: list[str]
    subject: str
    preview: str  # first characters of the PLAIN-TEXT body
    client_visible: bool
    is_read: bool
    has_attachments: bool
    received_at: datetime | None
    sent_at: datetime | None
    created_at: datetime


class CorrespondenceOut(ORM):
    """Staff view. Internal notes are NOT part of this schema - they are fetched separately."""
    id: uuid.UUID
    matter_id: uuid.UUID | None
    matter_reference: str | None = None
    thread_id: str | None
    direction: str
    channel: str
    from_addr: str
    to_addrs: list[str]
    cc_addrs: list[str]
    subject: str
    body_text: str  # plain text only; render as text
    status: str
    client_visible: bool
    is_read: bool
    received_at: datetime | None
    sent_at: datetime | None
    approval_id: uuid.UUID | None
    agent_run_id: uuid.UUID | None
    external_ref: str | None
    simulated: bool = False
    version: int
    attachments: list[AttachmentOut] = []
    untrusted_content: bool = False
    created_at: datetime


class ClientVisibleCorrespondence(BaseModel):
    """What an authorised client sees. Deliberately has no notes, approval, agent or internal fields."""
    id: uuid.UUID
    direction: str
    from_addr: str
    to_addrs: list[str]
    subject: str
    body_text: str
    date: datetime | None
    attachments: list[str] = []


class DraftIn(BaseModel):
    matter_id: uuid.UUID | None = None
    reply_to_id: uuid.UUID | None = None
    to_addrs: list[str] = []
    cc_addrs: list[str] = []
    subject: str = Field(min_length=1, max_length=500)
    body_text: str = ""
    client_visible: bool = False
    attachment_document_ids: list[uuid.UUID] = []


class DraftPatch(BaseModel):
    expected_version: int
    matter_id: uuid.UUID | None = None
    to_addrs: list[str] | None = None
    cc_addrs: list[str] | None = None
    subject: str | None = None
    body_text: str | None = None
    client_visible: bool | None = None


class FileIn(BaseModel):
    matter_id: uuid.UUID


class DecisionIn(BaseModel):
    approve: bool
    note: str | None = None


class NoteIn(BaseModel):
    body: str = Field(min_length=1, max_length=10000)
    matter_id: uuid.UUID | None = None


class NoteOut(ORM):
    id: uuid.UUID
    matter_id: uuid.UUID | None
    correspondence_id: uuid.UUID | None
    author_id: uuid.UUID
    author_name: str | None = None
    body: str
    created_at: datetime
