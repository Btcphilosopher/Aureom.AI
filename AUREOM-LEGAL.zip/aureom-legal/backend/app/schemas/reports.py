from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class ReportOut(BaseModel):
    report: str
    title: str
    period: dict[str, Any]
    filters: dict[str, Any]
    basis: str
    currency: str
    generated_at: datetime
    rows: list[dict[str, Any]]
    totals: dict[str, Any]
    by_fee_earner: list[dict[str, Any]] | None = None
