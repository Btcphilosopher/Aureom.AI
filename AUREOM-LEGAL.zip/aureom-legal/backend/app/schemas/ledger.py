from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

ORM = ConfigDict(from_attributes=True)


class AccountOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    ledger: str
    code: str
    name: str
    account_type: str
    currency: str
    is_bank: bool
    system_key: str | None
    matter_id: uuid.UUID | None
    balance: Decimal | None = None


class JournalLineIn(BaseModel):
    account_id: uuid.UUID | None = None
    system_key: str | None = None
    debit: Decimal = Decimal("0")
    credit: Decimal = Decimal("0")
    matter_id: uuid.UUID | None = None
    narrative: str | None = None


class JournalIn(BaseModel):
    ledger: str
    reference: str = Field(min_length=1, max_length=60)
    description: str = Field(min_length=1, max_length=400)
    effective_date: date
    currency: str = "GBP"
    matter_id: uuid.UUID | None = None
    lines: list[JournalLineIn]
    submit: bool = False


class JournalLineOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    account_id: uuid.UUID
    debit: Decimal
    credit: Decimal
    matter_id: uuid.UUID | None
    narrative: str | None
    reconciled_at: datetime | None
    account_code: str | None = None
    account_name: str | None = None


class JournalOut(BaseModel):
    id: uuid.UUID
    ledger: str
    reference: str
    description: str
    effective_date: date
    currency: str
    status: str
    matter_id: uuid.UUID | None
    source_type: str | None
    prepared_by: uuid.UUID
    posted_by: uuid.UUID | None
    posted_at: datetime | None
    approval_id: uuid.UUID | None
    approval_status: str | None = None
    reverses_journal_id: uuid.UUID | None
    total: Decimal
    version: int
    lines: list[JournalLineOut] = []


class DecideIn(BaseModel):
    approve: bool = True
    note: str | None = None


class ReverseIn(BaseModel):
    reason: str


class BankSyncIn(BaseModel):
    ledger: str = "office"


class BankLineOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    bank_account_id: uuid.UUID
    ledger: str
    txn_date: date
    description: str
    reference: str | None
    amount: Decimal
    currency: str
    external_id: str
    status: str
    payment_id: uuid.UUID | None
    matched_journal_line_id: uuid.UUID | None


class ReceiptIn(BaseModel):
    bank_line_id: uuid.UUID
    matter_id: uuid.UUID | None = None
    received_from_id: uuid.UUID | None = None
    reference: str | None = None


class PaymentOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    ledger: str
    matter_id: uuid.UUID | None
    received_from_id: uuid.UUID | None
    amount: Decimal
    allocated_amount: Decimal
    unallocated_amount: Decimal | None = None
    currency: str
    received_on: date
    reference: str | None
    status: str
    receipt_journal_id: uuid.UUID | None
    bank_statement_line_id: uuid.UUID | None
    version: int
    note: str = "A receipt is cash received - not earned revenue."


class AllocationItem(BaseModel):
    invoice_id: uuid.UUID
    amount: Decimal = Field(gt=0)


class AllocateIn(BaseModel):
    allocations: list[AllocationItem]
    approval_id: uuid.UUID | None = Field(None, description="Omit to request authorisation; supply the approved approval id to execute.")


class TransferIn(BaseModel):
    invoice_id: uuid.UUID
    amount: Decimal = Field(gt=0)
    approval_id: uuid.UUID | None = None


class RevRecIn(BaseModel):
    invoice_id: uuid.UUID
    amount: Decimal = Field(gt=0)
    basis: str = Field(min_length=5, max_length=300)
    recognised_on: date | None = None


class ReconIn(BaseModel):
    bank_account_id: uuid.UUID
    period_end: date
    statement_balance: Decimal
    notes: str | None = None


class MatchPair(BaseModel):
    bank_line_id: uuid.UUID
    journal_line_id: uuid.UUID


class MatchIn(BaseModel):
    pairs: list[MatchPair] = []
    apply_suggestions: bool = False


def jsonable(obj):
    """Make plain dict/list responses money-safe: FastAPI would otherwise encode bare Decimals as floats.
    Decimals become strings (integers get two decimal places)."""
    if isinstance(obj, Decimal):
        return str(obj.quantize(Decimal("0.01"))) if obj.as_tuple().exponent >= 0 else str(obj)
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    return obj
