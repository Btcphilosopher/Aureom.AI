from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class VersionOut(ORM):
    id: uuid.UUID
    version_no: int
    original_filename: str
    content_type: str
    size_bytes: int
    sha256: str
    author_id: uuid.UUID
    author_name: str | None = None
    change_note: str | None = None
    created_at: datetime
    scan_status: str
    scan_detail: str | None = None
    ocr_status: str
    index_status: str
    page_count: int | None = None


class DocumentOut(ORM):
    id: uuid.UUID
    matter_id: uuid.UUID | None
    contact_id: uuid.UUID | None
    folder_id: uuid.UUID | None
    title: str
    doc_type: str
    tags: list[str]
    status: str
    current_version_no: int
    current_version_id: uuid.UUID | None
    client_visible: bool
    legal_hold: bool
    retention_until: date | None
    source: str
    created_by: uuid.UUID
    created_at: datetime
    updated_at: datetime
    version: int
    matter_reference: str | None = None
    matter_title: str | None = None
    current: VersionOut | None = None


class DocumentDetail(DocumentOut):
    versions: list[VersionOut]
    signature_requests: list[dict] = []
    meta: dict = {}


class DocumentPatch(BaseModel):
    expected_version: int
    title: str | None = None
    doc_type: str | None = None
    tags: list[str] | None = None
    folder_id: uuid.UUID | None = None
    client_visible: bool | None = None
    model_config = ConfigDict(extra="forbid")


class ReviewDecision(BaseModel):
    approve: bool
    note: str | None = None


class Signer(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    email: str = Field(min_length=3, max_length=254)


class SignatureIn(BaseModel):
    signers: list[Signer]


class HoldIn(BaseModel):
    hold: bool
    reason: str | None = None


class RetentionIn(BaseModel):
    retention_until: date | None


class SupersedeIn(BaseModel):
    note: str | None = None


class FolderIn(BaseModel):
    matter_id: uuid.UUID
    name: str = Field(min_length=1, max_length=160)
    parent_id: uuid.UUID | None = None


class FolderPatch(BaseModel):
    name: str = Field(min_length=1, max_length=160)


class FolderOut(ORM):
    id: uuid.UUID
    matter_id: uuid.UUID | None
    parent_id: uuid.UUID | None
    name: str


class TemplateField(BaseModel):
    key: str
    label: str | None = None
    source: str | None = None
    required: bool = False


class TemplateIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    doc_type: str = "letter"
    practice_area: str | None = None
    body: str = Field(min_length=1)
    fields: list[TemplateField] = []


class TemplatePatch(BaseModel):
    name: str | None = None
    doc_type: str | None = None
    practice_area: str | None = None
    body: str | None = None
    fields: list[TemplateField] | None = None


class TemplateOut(ORM):
    id: uuid.UUID
    name: str
    doc_type: str
    practice_area: str | None
    body: str
    fields: list[dict]
    approved: bool
    approved_by: uuid.UUID | None
    template_version: int
    updated_at: datetime


class TemplateRenderIn(BaseModel):
    matter_id: uuid.UUID | None = None
    custom: dict[str, str] = {}
    title: str | None = None
    allow_incomplete: bool = False


class ExportIn(BaseModel):
    matter_id: uuid.UUID
    document_ids: list[uuid.UUID]
    reason: str


class ExportDecision(BaseModel):
    approve: bool
    note: str | None = None


class ExportOut(ORM):
    id: uuid.UUID
    matter_id: uuid.UUID
    requested_by: uuid.UUID
    document_ids: list
    reason: str
    status: str
    approval_id: uuid.UUID | None
    sha256: str | None
    expires_at: datetime | None
    download_count: int
    error: str | None
    created_at: datetime


class SearchHit(BaseModel):
    document_id: uuid.UUID
    title: str
    doc_type: str
    matter_id: uuid.UUID | None
    matter_reference: str | None
    version_id: uuid.UUID
    version_no: int
    page: int
    paragraph: int
    chunk_id: uuid.UUID
    is_ocr: bool
    snippet: str  # plain text; matches wrapped in ⟦ ⟧ markers - render as text, never as HTML
    rank: float
