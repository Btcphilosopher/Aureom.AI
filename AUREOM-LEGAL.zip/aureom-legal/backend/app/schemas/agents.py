from __future__ import annotations

import uuid
from datetime import date
from typing import Literal

from pydantic import BaseModel, Field


class RunStart(BaseModel):
    agent_type: str
    matter_id: uuid.UUID | None = None
    contact_id: uuid.UUID | None = None
    input: dict = Field(default_factory=dict)
    idempotency_key: str | None = Field(None, max_length=160)


class Decision(BaseModel):
    action_id: uuid.UUID
    decision: Literal["approve", "reject"]
    note: str | None = Field(None, max_length=2000)
    params: dict | None = None  # optional human correction applied BEFORE the decision (approval binds to the corrected content)


class ReviewIn(BaseModel):
    decisions: list[Decision] = Field(default_factory=list)
    execute: bool = False


class ActionEdit(BaseModel):
    params: dict
    expected_version: int | None = None


class KnowledgeIn(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    kind: Literal["precedent", "practice_note", "policy", "checklist"] = "precedent"
    practice_area: str | None = None
    body: str = Field(min_length=1, max_length=200000)
    source_ref: str | None = Field(None, max_length=300)
    effective_date: date
    last_reviewed: date | None = None


class KnowledgePatch(BaseModel):
    title: str | None = Field(None, min_length=3, max_length=300)
    kind: Literal["precedent", "practice_note", "policy", "checklist"] | None = None
    practice_area: str | None = None
    body: str | None = Field(None, min_length=1, max_length=200000)
    source_ref: str | None = None
    effective_date: date | None = None
    last_reviewed: date | None = None


class KnowledgeApproval(BaseModel):
    approved: bool
