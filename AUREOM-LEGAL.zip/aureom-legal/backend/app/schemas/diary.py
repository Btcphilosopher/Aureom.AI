from __future__ import annotations

import uuid
from datetime import date, datetime, time
from typing import Literal

from pydantic import BaseModel, Field


class EventCreate(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    kind: Literal["appointment", "hearing", "meeting", "call", "deadline"] = "appointment"
    start_at: datetime
    end_at: datetime | None = None
    matter_id: uuid.UUID | None = None
    location: str | None = None
    attendee_ids: list[uuid.UUID] = Field(default_factory=list)
    description: str | None = None


class EventUpdate(BaseModel):
    expected_version: int
    title: str | None = Field(None, min_length=1, max_length=300)
    kind: Literal["appointment", "hearing", "meeting", "call", "deadline"] | None = None
    start_at: datetime | None = None
    end_at: datetime | None = None
    location: str | None = None
    attendee_ids: list[uuid.UUID] | None = None
    description: str | None = None


class EventOut(BaseModel):
    id: uuid.UUID
    matter_id: uuid.UUID | None
    matter_reference: str | None = None
    title: str
    kind: str
    start_at: datetime
    end_at: datetime | None
    location: str | None
    attendee_ids: list[uuid.UUID]
    owner_id: uuid.UUID
    owner_name: str | None = None
    description: str | None
    external_calendar_ref: str | None
    version: int


class FeedItem(BaseModel):
    kind: Literal["event", "task", "deadline"]
    id: uuid.UUID
    title: str
    start: datetime | date
    end: datetime | date | None = None
    all_day: bool = False
    matter_id: uuid.UUID | None = None
    matter_reference: str | None = None
    status: str | None = None
    authoritative: bool | None = None  # deadlines only: True only when confirmed by a human
    label: str | None = None
    href: str


# ---- deadlines
class DeadlineManualCreate(BaseModel):
    matter_id: uuid.UUID
    title: str = Field(min_length=1, max_length=300)
    due_date: date
    due_time: time | None = None
    timezone: str = "Europe/London"
    jurisdiction: str | None = None
    assumptions: str | None = None
    reviewer_id: uuid.UUID | None = None
    create_task: bool = False


class DeadlineCalculateIn(BaseModel):
    matter_id: uuid.UUID
    rule_key: str
    trigger_date: date
    calendar_id: uuid.UUID | None = None
    title: str | None = None
    assumptions: str | None = None


class DeadlineUpdate(BaseModel):
    expected_version: int
    title: str | None = None
    due_date: date | None = None
    due_time: time | None = None
    assumptions: str | None = None
    status: Literal["met", "missed"] | None = None
    reason: str | None = None


class DeadlineConfirmIn(BaseModel):
    review_note: str | None = None
    adjusted_due_date: date | None = None
    adjustment_reason: str | None = None
    create_task: bool = False
    expected_version: int | None = None


class DeadlineRejectIn(BaseModel):
    review_note: str = Field(min_length=3)


class DeadlineOut(BaseModel):
    id: uuid.UUID
    matter_id: uuid.UUID
    matter_reference: str | None = None
    title: str
    due_date: date
    due_time: time | None
    timezone: str
    origin: str
    status: str
    authoritative: bool
    label: str
    jurisdiction: str | None
    rule_key: str | None
    calendar_id: uuid.UUID | None
    calendar_name: str | None = None
    trigger_date: date | None
    assumptions: str | None
    calculation: dict
    source_document_id: uuid.UUID | None
    source_version_id: uuid.UUID | None
    source_passage: str | None
    source_ref: dict
    agent_run_id: uuid.UUID | None
    suggested_by: uuid.UUID | None
    reviewer_id: uuid.UUID | None
    confirmed_by: uuid.UUID | None
    confirmed_by_name: str | None = None
    confirmed_at: datetime | None
    review_note: str | None
    version: int


class RuleIn(BaseModel):
    key: str = Field(min_length=2, max_length=60, pattern=r"^[a-z0-9_\-]+$")
    name: str
    jurisdiction: str = "england_and_wales"
    offset_days: int = Field(ge=0, le=3660)
    day_type: Literal["business", "calendar"] = "business"
    direction: Literal["after", "before"] = "after"
    roll_convention: Literal["next_business_day", "none"] = "next_business_day"
    description: str | None = None
    source_note: str = "Illustrative demonstration rule - verify against the governing rule or agreement."


class RuleUpdate(BaseModel):
    name: str | None = None
    jurisdiction: str | None = None
    offset_days: int | None = Field(None, ge=0, le=3660)
    day_type: Literal["business", "calendar"] | None = None
    direction: Literal["after", "before"] | None = None
    roll_convention: Literal["next_business_day", "none"] | None = None
    description: str | None = None
    source_note: str | None = None
    is_active: bool | None = None


class RuleOut(RuleIn):
    id: uuid.UUID
    is_active: bool


class CalendarIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    jurisdiction: str = "england_and_wales"
    timezone: str = "Europe/London"
    weekend_days: list[int] = Field(default_factory=lambda: [5, 6])
    is_default: bool = False
    source_note: str | None = None


class CalendarUpdate(BaseModel):
    name: str | None = None
    timezone: str | None = None
    weekend_days: list[int] | None = None
    is_default: bool | None = None
    source_note: str | None = None


class HolidayIn(BaseModel):
    date: date
    name: str = Field(min_length=1, max_length=120)


class HolidayImportIn(BaseModel):
    holidays: list[HolidayIn]
    source_note: str | None = None


class HolidayOut(BaseModel):
    id: uuid.UUID
    date: date
    name: str


class CalendarOut(BaseModel):
    id: uuid.UUID
    name: str
    jurisdiction: str
    timezone: str
    weekend_days: list[int]
    is_default: bool
    source_note: str | None
    holiday_count: int = 0
