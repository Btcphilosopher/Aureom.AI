from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class AddressIn(BaseModel):
    kind: Literal["registered", "residential", "correspondence", "trading"] = "correspondence"
    line1: str = Field(min_length=1, max_length=200)
    line2: str | None = None
    city: str | None = None
    county: str | None = None
    postcode: str | None = None
    country: str = "United Kingdom"
    is_primary: bool = False


class AddressPatch(BaseModel):
    kind: Literal["registered", "residential", "correspondence", "trading"] | None = None
    line1: str | None = None
    line2: str | None = None
    city: str | None = None
    county: str | None = None
    postcode: str | None = None
    country: str | None = None
    is_primary: bool | None = None


class ContactCreate(BaseModel):
    kind: Literal["individual", "organisation"]
    display_name: str | None = None
    title: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    date_of_birth: date | None = None
    org_name: str | None = None
    company_number: str | None = None
    email: str | None = None
    phone: str | None = None
    preferred_channel: Literal["email", "phone", "post", "portal"] = "email"
    aliases: list[str] = []
    responsible_user_id: uuid.UUID | None = None
    office_id: uuid.UUID | None = None
    notes: str | None = None
    addresses: list[AddressIn] = []


class ContactPatch(BaseModel):
    expected_version: int
    display_name: str | None = None
    title: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    date_of_birth: date | None = None
    org_name: str | None = None
    company_number: str | None = None
    email: str | None = None
    phone: str | None = None
    preferred_channel: Literal["email", "phone", "post", "portal"] | None = None
    aliases: list[str] | None = None
    responsible_user_id: uuid.UUID | None = None
    office_id: uuid.UUID | None = None
    notes: str | None = None
    status: Literal["prospect", "active", "inactive"] | None = None


class ContactListItem(ORM):
    id: uuid.UUID
    kind: str
    display_name: str
    email: str | None = None
    phone: str | None = None
    status: str
    is_client: bool
    client_ref: str | None = None
    responsible_user_id: uuid.UUID | None = None
    responsible_name: str | None = None
    aliases: list[str] = []
    merged_into_id: uuid.UUID | None = None
    version: int


RELATION_TYPES = ["director_of", "shareholder_of", "subsidiary_of", "parent_of", "spouse_of", "partner_of", "employee_of",
                  "trustee_of", "beneficiary_of", "guarantor_of", "associate_of", "sibling_of", "child_of", "other"]


class RelationshipIn(BaseModel):
    to_contact_id: uuid.UUID
    relation_type: str
    start_date: date | None = None
    end_date: date | None = None
    notes: str | None = None


class RelationshipPatch(BaseModel):
    relation_type: str | None = None
    start_date: date | None = None
    end_date: date | None = None
    notes: str | None = None


class IntakeFormIn(BaseModel):
    form: dict


class CheckRunIn(BaseModel):
    check_type: str


class CheckReviewIn(BaseModel):
    decision: Literal["accept", "reject"]
    note: str = Field(min_length=3)


class CheckWaiveIn(BaseModel):
    reason: str = Field(min_length=10)


class OnboardingDecisionIn(BaseModel):
    note: str | None = None
    risk_level: Literal["low", "medium", "high"] | None = None


class MergeProposeIn(BaseModel):
    survivor_id: uuid.UUID
    merged_id: uuid.UUID
    field_choices: dict[str, Literal["survivor", "merged"]] = {}
    reason: str = Field(min_length=5)


class MergeDecisionIn(BaseModel):
    note: str | None = None
