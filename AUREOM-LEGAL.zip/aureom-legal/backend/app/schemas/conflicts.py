from __future__ import annotations

import uuid
from typing import Literal

from pydantic import BaseModel, Field


class ConflictSearchIn(BaseModel):
    terms: list[str] = []
    subject_contact_id: uuid.UUID | None = None
    matter_id: uuid.UUID | None = None


class MatchReviewIn(BaseModel):
    disposition: Literal["false_positive", "potential_conflict", "confirmed_conflict"]
    note: str | None = None


class SearchDecisionIn(BaseModel):
    decision: Literal["cleared_by_reviewer", "conflict_confirmed", "referred"]
    note: str | None = None
    expected_version: int | None = None
