from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field

PartyRole = Literal["client", "payer", "beneficiary", "counterparty", "counterparty_solicitor", "witness", "other"]


class MatterCreate(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    client_id: uuid.UUID
    template_id: uuid.UUID | None = None
    matter_type: str | None = None
    practice_area: str | None = None
    description: str | None = None
    office_id: uuid.UUID | None = None
    team_id: uuid.UUID | None = None
    responsible_partner_id: uuid.UUID
    fee_earner_id: uuid.UUID | None = None
    jurisdiction: str = "england_and_wales"
    target_date: date | None = None
    fee_arrangement: Literal["hourly", "fixed", "capped", "retainer"] | None = None
    fixed_fee_amount: Decimal | None = None
    budget_amount: Decimal | None = None
    retention_policy_key: str | None = None
    access_level: Literal["standard", "restricted"] = "standard"
    custom_fields: dict = {}
    conflict_search_id: uuid.UUID | None = None


class MatterPatch(BaseModel):
    expected_version: int
    title: str | None = None
    description: str | None = None
    matter_type: str | None = None
    office_id: uuid.UUID | None = None
    team_id: uuid.UUID | None = None
    responsible_partner_id: uuid.UUID | None = None
    fee_earner_id: uuid.UUID | None = None
    jurisdiction: str | None = None
    target_date: date | None = None
    fee_arrangement: Literal["hourly", "fixed", "capped", "retainer"] | None = None
    fixed_fee_amount: Decimal | None = None
    budget_amount: Decimal | None = None
    custom_fields: dict | None = None
    conflict_search_id: uuid.UUID | None = None


class PartyIn(BaseModel):
    contact_id: uuid.UUID
    role: PartyRole
    notes: str | None = None


class MemberIn(BaseModel):
    user_id: uuid.UUID | None = None
    team_id: uuid.UUID | None = None
    access: Literal["allow", "deny"] = "allow"
    member_role: str | None = None
    reason: str = Field(min_length=5)


class AccessIn(BaseModel):
    expected_version: int
    access_level: Literal["standard", "restricted"]
    ethical_wall: bool = False
    exports_allowed: bool = True
    ai_retrieval_allowed: bool = True
    reason: str = Field(min_length=5)


class StageIn(BaseModel):
    stage: str
    expected_version: int


class ChecklistToggleIn(BaseModel):
    completed: bool
    note: str | None = None


class ChecklistAddIn(BaseModel):
    phase: Literal["opening", "closing"]
    label: str = Field(min_length=2)
    required: bool = True


class LegalHoldIn(BaseModel):
    active: bool
    reason: str = Field(min_length=5)


class RetentionIn(BaseModel):
    policy_key: str


class TransitionIn(BaseModel):
    to_status: Literal["open", "paused", "closed"]
    reason: str | None = None
    expected_version: int
    retention_policy_key: str | None = None


class TransitionDecisionIn(BaseModel):
    approve: bool
    note: str | None = None


class ChecklistTemplateItem(BaseModel):
    label: str
    required: bool = True


class TemplateStage(BaseModel):
    key: str
    name: str


class TemplateTask(BaseModel):
    title: str
    due_in_days: int = 7


class TemplateIn(BaseModel):
    name: str
    practice_area: str
    matter_type: str
    description: str | None = None
    stages: list[TemplateStage] = []
    opening_checklist: list[ChecklistTemplateItem] = []
    closing_checklist: list[ChecklistTemplateItem] = []
    required_fields: list[str] = []
    default_fee_arrangement: Literal["hourly", "fixed", "capped", "retainer"] = "hourly"
    default_retention_key: str | None = None
    default_tasks: list[TemplateTask] = []
    is_active: bool = True


class ChronologyIn(BaseModel):
    event_date: date | None = None
    date_text: str | None = None
    date_basis: Literal["explicit", "inferred"] = "explicit"
    description: str = Field(min_length=3)
    source: dict = {}


class ChronologyPatch(BaseModel):
    expected_version: int
    event_date: date | None = None
    date_text: str | None = None
    date_basis: Literal["explicit", "inferred"] | None = None
    description: str | None = None
    source: dict | None = None
