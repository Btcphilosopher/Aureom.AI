from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

ORM = ConfigDict(from_attributes=True)
Money = Decimal


class TimeEntryIn(BaseModel):
    matter_id: uuid.UUID
    work_date: date
    minutes: int = Field(ge=0, le=1440)
    narrative: str = ""
    billable: bool = True
    rate: Money | None = Field(None, description="Override rate (needs billing.write)")
    user_id: uuid.UUID | None = None


class TimeEntryPatch(BaseModel):
    expected_version: int | None = None
    work_date: date | None = None
    minutes: int | None = Field(None, ge=0, le=1440)
    narrative: str | None = None
    billable: bool | None = None
    rate: Money | None = None


class TimeEntryOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    matter_id: uuid.UUID
    user_id: uuid.UUID
    work_date: date
    minutes: int
    narrative: str
    rate: Money
    amount: Money
    currency: str
    billable: bool
    status: str
    source: str
    timer_started_at: datetime | None
    invoice_line_id: uuid.UUID | None
    version: int
    matter_reference: str | None = None
    user_name: str | None = None


class ReasonIn(BaseModel):
    reason: str


class TimerStartIn(BaseModel):
    matter_id: uuid.UUID
    narrative: str = ""
    billable: bool = True


class TimerStopIn(BaseModel):
    narrative: str | None = None


class ExpenseIn(BaseModel):
    matter_id: uuid.UUID
    expense_date: date
    description: str = Field(min_length=1, max_length=300)
    amount: Money = Field(ge=0)
    vat_rate: Decimal = Decimal("0")
    billable: bool = True


class ExpensePatch(BaseModel):
    expected_version: int | None = None
    expense_date: date | None = None
    description: str | None = None
    amount: Money | None = Field(None, ge=0)
    vat_rate: Decimal | None = None
    billable: bool | None = None


class ExpenseOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    matter_id: uuid.UUID
    user_id: uuid.UUID
    expense_date: date
    description: str
    amount: Money
    vat_rate: Decimal
    currency: str
    billable: bool
    status: str
    invoice_line_id: uuid.UUID | None
    version: int


class RateEntryIn(BaseModel):
    grade: str
    hourly_rate: Money = Field(ge=0)
    user_id: uuid.UUID | None = None


class RateEntryOut(RateEntryIn):
    model_config = ORM
    id: uuid.UUID


class RateCardIn(BaseModel):
    name: str
    currency: str = "GBP"
    is_default: bool = False
    entries: list[RateEntryIn] = []


class RateCardOut(BaseModel):
    id: uuid.UUID
    name: str
    currency: str
    is_default: bool
    is_active: bool
    entries: list[RateEntryOut] = []


class AdjustmentIn(BaseModel):
    description: str = Field(min_length=1, max_length=500)
    amount: Money
    vat_rate: Decimal | None = None


class InvoiceDraftIn(BaseModel):
    matter_id: uuid.UUID
    time_entry_ids: list[uuid.UUID] = []
    expense_ids: list[uuid.UUID] = []
    include_fixed_fee: bool = False
    fixed_fee_amount: Money | None = None
    adjustments: list[AdjustmentIn] = []
    payer_id: uuid.UUID | None = None
    narrative: str | None = None
    due_days: int = 30


class InvoicePatch(BaseModel):
    expected_version: int | None = None
    narrative: str | None = None
    due_date: date | None = None
    payer_id: uuid.UUID | None = None
    add_time_entry_ids: list[uuid.UUID] = []
    add_expense_ids: list[uuid.UUID] = []
    remove_line_ids: list[uuid.UUID] = []
    add_adjustments: list[AdjustmentIn] = []


class CreditNoteIn(BaseModel):
    full: bool = False
    lines: list[AdjustmentIn] = []
    narrative: str | None = None


class DecideIn(BaseModel):
    approve: bool = True
    note: str | None = None


class InvoiceLineOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    line_type: str
    description: str
    quantity: Decimal
    unit_amount: Money
    amount: Money
    vat_rate: Decimal
    vat_amount: Money
    time_entry_id: uuid.UUID | None
    expense_id: uuid.UUID | None


class InvoiceOut(BaseModel):
    id: uuid.UUID
    matter_id: uuid.UUID
    matter_reference: str | None = None
    client_id: uuid.UUID
    payer_id: uuid.UUID | None
    kind: str
    credit_for_invoice_id: uuid.UUID | None
    number: str | None
    status: str
    currency: str
    subtotal: Money
    vat_amount: Money
    total: Money
    amount_paid: Money
    outstanding: Money
    issued_at: datetime | None
    due_date: date | None
    narrative: str | None
    approval_id: uuid.UUID | None
    approval_status: str | None = None
    version: int
    lines: list[InvoiceLineOut] = []
    basis: str = "Issued invoice = billed, not recognised revenue and not cash received."
