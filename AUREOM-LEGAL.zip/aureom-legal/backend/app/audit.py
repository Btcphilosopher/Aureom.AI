"""Append-only, hash-chained audit log. DB triggers forbid UPDATE/DELETE/TRUNCATE; the chain lets auditors detect
gaps or tampering made with elevated database access. Details must never contain confidential document/email text."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.models import AuditEvent
from app.security import canonical_json, sha256_hex

GENESIS = "0" * 64
_REDACT_KEYS = {"body", "body_text", "text", "content", "passage", "quote", "password", "token", "secret", "csrf_token", "prompt", "description_text"}


def scrub(details: dict | None) -> dict:
    """Strip confidential-content keys. Nested dicts/lists are scrubbed recursively; long strings are truncated."""
    def _s(v, key=None):
        if key and key.lower() in _REDACT_KEYS:
            return "[redacted]"
        if isinstance(v, dict):
            return {k: _s(x, k) for k, x in v.items()}
        if isinstance(v, (list, tuple)):
            return [_s(x) for x in v][:100]
        if isinstance(v, str) and len(v) > 300:
            return v[:300] + "…"
        return v
    return _s(details or {})


def _digest(prev: str, e: AuditEvent) -> str:
    payload = canonical_json({
        "firm": str(e.firm_id), "at": e.occurred_at.astimezone(timezone.utc).isoformat(), "actor": str(e.actor_user_id) if e.actor_user_id else None,
        "type": e.actor_type, "action": e.action, "entity": e.entity_type, "eid": e.entity_id,
        "matter": str(e.matter_id) if e.matter_id else None, "summary": e.summary, "details": e.details,
    })
    return sha256_hex(prev + payload)


def log(db: Session, *, firm_id, action: str, entity_type: str, entity_id=None, summary: str, matter_id=None,
        actor_user_id=None, actor_type: str = "user", details: dict | None = None, ip: str | None = None) -> AuditEvent:
    # Serialise chain extension per firm (released at transaction end)
    db.execute(text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": f"audit:{firm_id}"})
    prev = db.execute(select(AuditEvent.hash).where(AuditEvent.firm_id == firm_id).order_by(AuditEvent.id.desc()).limit(1)).scalar()
    ev = AuditEvent(
        firm_id=firm_id, occurred_at=datetime.now(timezone.utc), actor_user_id=actor_user_id, actor_type=actor_type,
        action=action, entity_type=entity_type, entity_id=str(entity_id) if entity_id else None, matter_id=matter_id,
        summary=summary[:500], details=scrub(details), ip=ip, prev_hash=prev or GENESIS, hash="",
    )
    ev.hash = _digest(ev.prev_hash, ev)
    db.add(ev)
    db.flush()
    return ev


def verify_chain(db: Session, firm_id) -> dict:
    """Recompute the chain. Returns {ok, checked, first_bad_id}."""
    prev, n = GENESIS, 0
    for ev in db.execute(select(AuditEvent).where(AuditEvent.firm_id == firm_id).order_by(AuditEvent.id)).scalars():
        if ev.prev_hash != prev or ev.hash != _digest(prev, ev):
            return {"ok": False, "checked": n, "first_bad_id": ev.id}
        prev, n = ev.hash, n + 1
    return {"ok": True, "checked": n, "first_bad_id": None}
