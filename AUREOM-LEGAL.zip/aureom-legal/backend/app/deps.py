"""Request context: authenticated user, firm binding, permissions, audit helper."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Iterator

from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app import audit as audit_mod
from app.config import get_settings
from app.db.session import bind_firm, new_session
from app.errors import PermissionDenied, Unauthenticated
from app.models import Role, User, UserSession
from app.permissions import permissions_for
from app.security import sha256_hex

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


class Ctx:
    """Everything a service needs to act *as the requesting user*. Services must take a Ctx (not a bare Session)
    for any user-initiated action so that permission and tenant rules cannot be skipped."""

    def __init__(self, db: Session, user: User, role_key: str, perms: frozenset[str], *, ip: str | None = None,
                 session: UserSession | None = None, actor_type: str = "user"):
        self.db, self.user, self.role_key, self.perms, self.ip, self.session, self.actor_type = db, user, role_key, perms, ip, session, actor_type
        self.firm_id: uuid.UUID = user.firm_id

    def has(self, perm: str) -> bool:
        return perm in self.perms

    def require(self, *perms: str) -> None:
        missing = [p for p in perms if p not in self.perms]
        if missing:
            raise PermissionDenied(f"Your role does not include the permission: {', '.join(missing)}", details={"required": missing})

    def audit(self, action: str, entity_type: str, entity_id=None, summary: str = "", *, matter_id=None, details: dict | None = None):
        return audit_mod.log(self.db, firm_id=self.firm_id, action=action, entity_type=entity_type, entity_id=entity_id,
                             summary=summary or action, matter_id=matter_id, actor_user_id=self.user.id, actor_type=self.actor_type,
                             details=details, ip=self.ip)

    @classmethod
    def for_user(cls, db: Session, user: User, *, ip: str | None = None, actor_type: str = "user") -> "Ctx":
        """Build a context outside HTTP (seed, worker, tests). Binds the session to the user's firm."""
        bind_firm(db, user.firm_id)
        role = db.get(Role, user.role_id)
        return cls(db, user, role.key, permissions_for(role.key, role.permissions), ip=ip, actor_type=actor_type)


def get_db() -> Iterator[Session]:
    db = new_session()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def _lookup_session(db: Session, token: str) -> UserSession | None:
    s = db.execute(select(UserSession).where(UserSession.token_hash == sha256_hex(token))).scalar_one_or_none()
    if not s or s.revoked_at or s.expires_at < datetime.now(timezone.utc):
        return None
    return s


def get_ctx(request: Request, db: Session = Depends(get_db)) -> Ctx:
    settings = get_settings()
    token = request.cookies.get(settings.session_cookie_name)
    if not token:
        raise Unauthenticated("Sign in to continue.")
    s = _lookup_session(db, token)
    if not s:
        raise Unauthenticated("Your session has expired. Sign in again.")
    user = db.get(User, s.user_id)
    if not user or not user.is_active:
        raise Unauthenticated("This account is disabled.")
    if request.method not in SAFE_METHODS:
        sent = request.headers.get("x-csrf-token")
        if not sent or sent != s.csrf_token:
            raise PermissionDenied("Missing or invalid CSRF token.", code="csrf_failed")
    bind_firm(db, user.firm_id)
    role = db.get(Role, user.role_id)
    ctx = Ctx(db, user, role.key, permissions_for(role.key, role.permissions), ip=request.client.host if request.client else None, session=s)
    # sliding session
    now = datetime.now(timezone.utc)
    if (now - s.last_seen_at) > timedelta(minutes=1):
        s.last_seen_at = now
    return ctx


def require(*perms: str):
    """Dependency factory: `ctx: Ctx = Depends(require('matters.read'))`."""
    def dep(ctx: Ctx = Depends(get_ctx)) -> Ctx:
        ctx.require(*perms)
        return ctx
    return dep
