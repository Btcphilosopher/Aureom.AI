"""Seed part 3: a handful of AI runs (local mock provider) so the AI workspace and dashboard show real review work.
Runs execute as the named users, inside their own permissions; nothing is applied - proposals await human review."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.agents import runner
from app.deps import Ctx
from app.models import Document
from app.seed.base import World


def seed_ai(db: Session, w: World) -> None:
    def go(user: str, agent: str, mkey: str | None = None, **inp):
        ctx = Ctx.for_user(db, w.u(user))
        run = runner.start_run(ctx, agent, matter_id=w.matters[mkey].id if mkey else None, input=inp, enqueue=False)
        db.flush()
        runner.process_run(db, run.id)
        db.commit()
        return run

    def doc(mkey: str, title_part: str) -> str:
        return str(db.execute(select(Document.id).where(Document.matter_id == w.matters[mkey].id, Document.title.ilike(f"%{title_part}%"))).scalars().first())

    go("Daniel Rhodes", "matter_briefing", "supply")                                              # read-only: completes without review
    go("Daniel Rhodes", "document_review", "supply", document_ids=[doc("supply", "Supply Agreement")])
    go("Thomas Bagshaw", "chronology", "whitaker_dispute")
    go("Sofia Marchetti", "document_review", "aldwark_acq", document_ids=[doc("aldwark_acq", "retained documents")])   # hostile text: flagged, treated as data
    go("Daniel Rhodes", "knowledge", "supply", query="distribution agreement drafting checklist")
    go("Joseph Lister", "drafting", "hartley_sale", kind="correspondence", subject="14 Weavers Row - progress update",
       instructions="Update the clients on the buyer's enquiries and next steps.")
    go("Joseph Lister", "billing_assistant", "hartley_sale")
