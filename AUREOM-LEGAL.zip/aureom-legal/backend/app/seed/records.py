"""Seed part 2: documents, correspondence, knowledge, templates, time, billing, ledger. Uses the real services so seeded
data obeys the same rules (approvals, four-eyes, balanced journals) as live data."""
from __future__ import annotations

import random
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.deps import Ctx
from app.models import (BankStatementLine, Correspondence, DocumentTemplate, Document, Invoice, Journal, KnowledgeItem, Payment, Role, User)
from app.seed import content as C
from app.seed.base import TODAY, World, dt
from app.seed.pdfgen import pdf_from_text
from app.security import hash_password
from app.config import get_settings
from app.services import billing, correspondence as corr, documents as docsvc
from app.services import ledger as led, reconciliation as rec


def ctx_for(db: Session, user: User) -> Ctx:
    return Ctx.for_user(db, user)


# ------------------------------------------------------------------------------------------------ users for the portal
def seed_portal_users(db: Session, w: World) -> None:
    role = db.execute(select(Role).where(Role.firm_id == w.firm.id, Role.key == "client")).scalar_one()
    pw = hash_password(get_settings().demo_password)
    for name, email, contact in [("Anna Hartley", "anna.hartley@mailbox.example", "anna"), ("Moorside Brewing (Jonathan Marsden)", "jonathan.marsden@moorsidebrewing.example", "moorside")]:
        u = User(firm_id=w.firm.id, email=email, name=name, initials="".join(p[0] for p in name.split()[:2]).upper(), job_title="Authorised client", password_hash=pw,
                 role_id=role.id, contact_id=w.contacts[contact].id)
        db.add(u); db.flush()
        w.users[name] = u
    from app.models import MatterParty
    db.add(MatterParty(firm_id=w.firm.id, matter_id=w.matters["moorside_lease"].id, contact_id=w.contacts["moorside"].id, role="client")) if False else None
    db.flush()


# ------------------------------------------------------------------------------------------------ documents
def _letter(title, body):
    return f"{title}\n\n{body}"


ENGAGEMENT = """LETTER OF ENGAGEMENT

Dear {client}

Matter: {matter} ({ref})

Thank you for instructing Pennine & Calder Solicitors. I am the partner responsible for this matter and {fe} will carry out most of the day-to-day work.

Scope of work: {scope}

Charges: {basis}

Please let us know promptly if anything in this letter does not reflect your instructions. If you are unhappy with our service please tell us - our complaints procedure is available on request.

Yours sincerely
{partner}"""

SUPPLY_V1 = """DRAFT SUPPLY AGREEMENT (Version 1)

PARTIES

(1) CALDER TEXTILES LTD (company number 05123456) (the "Customer"); and

(2) MARSDEN YARNS LIMITED (the "Supplier").

1. SUPPLY

1.1 The Supplier shall supply the Yarn in accordance with the specification in Schedule 1 and shall deliver within 10 business days of each order.

1.2 The Customer shall pay the Supplier's invoices within 30 days of the date of invoice.

2. TERM

2.1 This Agreement commences on 1 January 2027 and continues for three years unless terminated earlier.

2.2 Either party may terminate on 90 days' written notice.

3. LIABILITY

3.1 The Supplier's liability under this Agreement shall not exceed GBP 100,000 in any year.

4. SPECIAL TERMS

4.1 The Customer must confirm the volume forecast in writing no later than 20 November 2026.
"""

NOTES = {
    "advice": "ADVICE NOTE\n\nWe have considered the position as instructed and set out our conclusions below.\n\nSummary: {summary}\n\nNext steps: {next}\n\nThis note is a draft for partner review and does not constitute final advice until approved.",
    "attendance": "ATTENDANCE NOTE\n\nDate: {date}\nAttendees: {fe}, {client}\n\nDiscussion: {summary}\n\nAgreed actions: {next}",
}


def seed_documents(db: Session, w: World) -> dict:
    """Returns {title: document id}. All documents are processed inline (scan, extract, index)."""
    made: dict = {}
    M = w.matters

    def up(mkey, who, title, doc_type, filename, content, *, client_visible=False, tags=(), note=None, document_id=None):
        ctx = ctx_for(db, w.u(who))
        if isinstance(content, str):
            content = content.encode()
        d, v = docsvc.upload_document(ctx, matter_id=M[mkey].id, title=title, doc_type=doc_type, filename=filename, content=content, client_visible=client_visible,
                                      tags=list(tags), change_note=note, document_id=document_id, source="seed")
        db.flush()
        docsvc.process_version_inline(db, v.id)
        made[title] = d.id
        return d

    eng = {"supply": ("Eleanor Whitcombe", "Daniel Rhodes", "Review and negotiation of a supply agreement for yarn.", "Hourly rates: partner £295, solicitor £210, paralegal £125 plus VAT; estimate £18,000."),
           "aldwark_acq": ("Eleanor Whitcombe", "Sofia Marchetti", "Acquisition of Brigg Precision Engineering Ltd.", "Capped fee of £85,000 plus VAT and disbursements."),
           "hartley_sale": ("Priya Venkataraman", "Joseph Lister", "Sale of 14 Weavers Row, Halifax.", "Fixed fee £1,850 plus VAT."),
           "whitaker_dispute": ("Gareth Ainsworth", "Thomas Bagshaw", "Pre-action recovery of unpaid haulage invoices.", "Hourly rates; budget £25,000 plus VAT."),
           "exec_settlement": ("Marianne Oyelaran", "Amira Khalid", "Negotiation of a settlement agreement.", "Fixed fee £6,500 plus VAT."),
           "ainsley_estate": ("Hugh Fairbairn", "Charlotte Dunmore", "Probate and estate administration.", "Hourly rates; estimate £9,500 plus VAT."),
           "ogden_lpa": ("Hugh Fairbairn", "Charlotte Dunmore", "Preparation and registration of two lasting powers of attorney.", "Fixed fee £950 plus VAT."),
           "penfab_sha": ("Eleanor Whitcombe", "Sofia Marchetti", "Shareholders' agreement and articles amendments.", "Capped fee £22,000 plus VAT."),
           "calder_debt": ("Gareth Ainsworth", "Thomas Bagshaw", "Recovery of a trade debt.", "Hourly rates; budget £9,000 plus VAT.")}
    for k, (partner, fe, scope, basis) in eng.items():
        m = M[k]
        text = ENGAGEMENT.format(client=next(c.display_name for c in w.contacts.values() if c.id == m.client_id), matter=m.title, ref=m.reference, fe=fe, scope=scope, basis=basis, partner=partner)
        up(k, fe, f"Engagement letter - {m.reference}", "engagement_letter", f"engagement-{m.reference}.txt", text, tags=["engagement"])
    # note: moorside_lease and tupe deliberately have no engagement letter (dashboard exception demo)

    sup = up("supply", "Daniel Rhodes", "Supply Agreement - Calder Textiles / Marsden Yarns", "agreement", "supply-agreement-v1.pdf", pdf_from_text(SUPPLY_V1, "Supply Agreement v1"), tags=["draft", "yarn"], note="First draft for client review")
    v2 = SUPPLY_V1.replace("(Version 1)", "(Version 2)").replace("GBP 100,000", "GBP 250,000").replace("90 days'", "120 days'")
    up("supply", "Daniel Rhodes", "Supply Agreement - Calder Textiles / Marsden Yarns", "agreement", "supply-agreement-v2.pdf", pdf_from_text(v2, "Supply Agreement v2"), document_id=sup.id, note="Revised after client comments: liability cap and notice period")
    up("supply", "Daniel Rhodes", "Advice note - liability cap", "advice", "advice-liability-cap.txt", NOTES["advice"].format(summary="A GBP 250,000 annual cap is reasonable against annual spend of about GBP 1.1m; we recommend the carve-outs for death/personal injury and fraud remain.", next="Obtain client instructions on the cap by 20 November."), tags=["advice"])
    up("hartley_sale", "Joseph Lister", "Draft contract pack for client", "contract", "contract-pack.txt", "DRAFT CONTRACT PACK\n\nProperty: 14 Weavers Row, Halifax HX1 3JD.\n\nPrice: GBP 245,000. Completion date to be agreed.\n\nPlease read the attached protocol forms and return them with any questions.", client_visible=True, tags=["client-copy"])
    up("hartley_sale", "Joseph Lister", "Buyer's enquiries - boundary and fixtures", "enquiries", "enquiries.txt", "PRE-CONTRACT ENQUIRIES\n\n1. Please confirm who owns the boundary wall on the eastern side.\n\n2. Please confirm whether the fitted wardrobes are included in the sale.", tags=["enquiries"])
    up("moorside_lease", "Joseph Lister", "Existing lease - Unit 6 Canal Wharf", "lease", "existing-lease.txt", "LEASE\n\nLandlord: Canal Wharf Estates Ltd. Tenant: Moorside Brewing Ltd.\n\nTerm: 10 years from 1 March 2017. Rent: GBP 18,000 per year, reviewed every five years.\n\nThe Tenant must not assign or underlet without the Landlord's consent.", tags=["lease"])
    up("whitaker_dispute", "Thomas Bagshaw", "Schedule of unpaid invoices", "schedule", "unpaid-invoices.txt", "SCHEDULE OF UNPAID INVOICES\n\nInvoice WH-1041 dated 12 June 2026 for GBP 8,420.00 - unpaid.\n\nInvoice WH-1057 dated 3 July 2026 for GBP 6,115.50 - unpaid.\n\nInvoice WH-1088 dated 29 August 2026 for GBP 9,300.00 - unpaid.", tags=["evidence"])
    up("whitaker_dispute", "Thomas Bagshaw", "Draft letter before claim", "letter", "letter-before-claim.txt", "DRAFT LETTER BEFORE CLAIM\n\nDear Sirs\n\nWe act for Whitaker Haulage Ltd. Our client's invoices totalling GBP 23,835.50 remain unpaid despite reminders.\n\nPlease respond within 14 days of the date of this letter. The response period must be confirmed by the supervising solicitor before sending.", tags=["draft"])
    up("aldwark_acq", "Sofia Marchetti", "Heads of terms - Project Heron", "agreement", "heads-of-terms.txt", "HEADS OF TERMS\n\nBuyer: Aldwark Industrial Holdings Ltd. Target: Brigg Precision Engineering Ltd.\n\nPrice: GBP 4,200,000 on a cash-free debt-free basis. Exclusivity until 2 December 2026.\n\nCompletion is conditional on satisfactory due diligence.", tags=["deal"])
    up("aldwark_acq", "Sofia Marchetti", "Schedule of retained documents (target)", "schedule", "retained-documents.txt", C.INJECTION_DOC, tags=["due-diligence", "contains-hostile-text"])
    up("exec_settlement", "Amira Khalid", "Draft settlement agreement", "agreement", "settlement-draft.txt", "DRAFT SETTLEMENT AGREEMENT\n\nThe Employee's employment will terminate on 31 December 2026. The Company shall pay GBP 62,000 as compensation, subject to the Employee's signing a compromise.\n\nThe Employee must return Company property by 15 December 2026.", tags=["confidential"])
    up("ainsley_estate", "Charlotte Dunmore", "Schedule of assets and liabilities", "schedule", "estate-assets.txt", "ESTATE OF MARGARET AINSLEY\n\nBank accounts: GBP 41,200. Property: 27 Elland Road, Brighouse valued at GBP 215,000. Liabilities: funeral costs GBP 4,800.", tags=["estate"])
    up("ogden_lpa", "Charlotte Dunmore", "Draft LPA - property and financial affairs", "contract_draft", "lpa-draft.txt", "DRAFT LASTING POWER OF ATTORNEY\n\nDonor: Dennis Ogden. Attorneys: to be confirmed at signing appointment.", tags=["draft"])
    up("penfab_sha", "Sofia Marchetti", "Shareholders' agreement - draft 3", "agreement", "sha-draft3.txt", "SHAREHOLDERS' AGREEMENT (Draft 3)\n\nThe Investor shall subscribe for 15% of the share capital for GBP 750,000.\n\nA Shareholder who is a Leaver must offer his shares for sale within 30 days of ceasing to be employed.", tags=["draft"])
    up("tupe", "Amira Khalid", "TUPE consultation timetable (draft)", "advice", "tupe-timetable.txt", "TUPE CONSULTATION TIMETABLE\n\nElection of representatives: week commencing 23 November 2026. First consultation meeting: 2 December 2026.", tags=["draft"])
    up("ridgeway_licence", "Daniel Rhodes", "Executed software licence", "agreement", "ridgeway-licence.txt", "SOFTWARE LICENCE AGREEMENT\n\nThe Licensee shall pay the annual fee within 30 days of invoice. Term: three years from 1 April 2025.", tags=["executed"])
    up("calder_debt", "Thomas Bagshaw", "Debtor's payment proposal", "letter", "payment-proposal.txt", "Dear Sirs\n\nWe propose to settle by 12 monthly instalments of GBP 1,250 starting 1 December 2026.", tags=["incoming"])
    up("supply", "Ben Holroyd", "Attendance note - client call", "attendance_note", "attendance-call.txt", NOTES["attendance"].format(date="10 November 2026", fe="Daniel Rhodes", client="Calder Textiles", summary="Client prefers 120-day notice and a higher liability cap; volume forecast to be confirmed.", next="Daniel to send mark-up; client to confirm forecast."), tags=["attendance"])
    db.flush()

    # review / approval / signature states through the real workflow
    ctx_d = ctx_for(db, w.u("Daniel Rhodes"))
    docsvc.request_review(ctx_d, made["Advice note - liability cap"])
    docsvc.request_review(ctx_for(db, w.u("Sofia Marchetti")), made["Shareholders' agreement - draft 3"])
    docsvc.decide_review(ctx_for(db, w.u("Eleanor Whitcombe")), made["Shareholders' agreement - draft 3"], approve=True, note="Approved for circulation.")
    docsvc.request_review(ctx_for(db, w.u("Joseph Lister")), made["Draft contract pack for client"])
    docsvc.decide_review(ctx_for(db, w.u("Priya Venkataraman")), made["Draft contract pack for client"], approve=True, note="Fine to send.")
    docsvc.request_signature(ctx_for(db, w.u("Priya Venkataraman")), made["Draft contract pack for client"], [{"name": "Anna Hartley", "email": "anna.hartley@mailbox.example"}])
    db.flush()
    return made


# ------------------------------------------------------------------------------------------------ correspondence
def seed_correspondence(db: Session, w: World) -> None:
    M = w.matters
    eleanor = ctx_for(db, w.u("Eleanor Whitcombe"))
    inbound = [
        ("supply", "r.marsden@marsden-yarns.example", "daniel.rhodes", "RE: Draft supply agreement - clause 3 liability", "Daniel,\n\nThanks for the draft. Our board will not accept a cap below GBP 250,000 and we would like to discuss termination notice. Can we speak on Friday?\n\nRichard Marsden", -3),
        ("hartley_sale", "enquiries@buyer-solicitors.example", "joseph.lister", "14 Weavers Row - replies to enquiries", "Dear Mr Lister,\n\nPlease let us have replies on the boundary wall and fixtures by 20 November 2026 so that exchange can be targeted for the end of the month.\n\nHarcourt & Dene LLP", -2),
        ("whitaker_dispute", "accounts@pennine-aggregates.example", "thomas.bagshaw", "Invoices WH-1041 and WH-1057", "We dispute these invoices on the basis that the loads were short. We will set off the sum of GBP 4,000 against any amount found due.\n\nPennine Aggregates Ltd accounts", -5),
        ("ainsley_estate", "ruth.ainsley@mailbox.example", "charlotte.dunmore", "Mum's estate - bank letters", "Charlotte, I have found two more bank statements in mum's desk. Shall I scan them or bring them in?\n\nRuth", -1),
        ("tupe", "hr@holroyd-logistics.example", "amira.khalid", "Depot transfer - employee list", "Please find the draft list of affected employees. Two employees are currently on long-term sick leave.\n\nHolroyd HR", -4),
    ]
    for mk, frm, to, subj, body, days in inbound:
        user = M[mk].fee_earner_id
        ctx = ctx_for(db, next(u for u in w.users.values() if u.id == user))
        row, _ = corr.create_inbound(ctx, from_addr=frm, to_addrs=[f"{to}@{C.EMAIL_DOMAIN}"], subject=subj, body_text=body, received_at=dt(days, 10), external_ref=f"seed-{mk}-{days}", matter_id=M[mk].id, client_visible=(mk in ("hartley_sale", "ainsley_estate")))
        row.status = "filed"
    # unfiled shared-inbox items, incl. a hostile one
    shared = ctx_for(db, w.u("Ben Holroyd"))
    corr.create_inbound(shared, from_addr="newclient@ridings-bakery.example", to_addrs=[f"info@{C.EMAIL_DOMAIN}"], subject="Enquiry - shop lease assignment",
                        body_text="Hello, we are looking to assign the lease of our Skipton shop to a new operator. Could someone call me this week?\n\nHannah Pickles", received_at=dt(-1, 15), external_ref="seed-unfiled-1")
    corr.create_inbound(shared, from_addr="accounts@supplier-payments.example", to_addrs=[f"accounts@{C.EMAIL_DOMAIN}"], subject="URGENT: updated bank details",
                        body_text=C.SUPPLIER_EMAIL_WITH_INJECTION, received_at=dt(0, 8), external_ref="seed-unfiled-2")
    corr.create_inbound(shared, from_addr="rebecca.ellison@hebden-brewing.example", to_addrs=[f"daniel.rhodes@{C.EMAIL_DOMAIN}"], subject="New instruction - distribution agreement",
                        body_text=C.CLIENT_INSTRUCTION_EMAIL, received_at=dt(-1, 9), external_ref="seed-unfiled-3")
    # sent history + a draft awaiting approval
    d = ctx_for(db, w.u("Daniel Rhodes"))
    sent = corr.create_draft(d, matter_id=M["supply"].id, subject="Supply agreement - our mark-up", body_text="Dear Richard,\n\nPlease find our mark-up of clauses 4-7. We will call you on Friday as suggested.\n\nKind regards\nDaniel Rhodes", to_addrs=["r.marsden@marsden-yarns.example"])
    sent.status, sent.sent_at, sent.meta = "sent", dt(-6, 16), {"note": "seeded history (SIMULATED send)"}
    pend = corr.create_draft(ctx_for(db, w.u("Joseph Lister")), matter_id=M["hartley_sale"].id, subject="14 Weavers Row - update for Mr and Mrs Hartley",
                             body_text="Dear Anna and Peter,\n\nThe buyer's solicitors have raised enquiries about the boundary wall and fixtures. We will reply this week and will let you know if we need anything from you.\n\nKind regards\nJoseph Lister", to_addrs=["anna.hartley@mailbox.example"], client_visible=True)
    note = None
    from app.models import InternalNote
    db.add(InternalNote(firm_id=w.firm.id, matter_id=M["supply"].id, author_id=w.u("Eleanor Whitcombe").id, body="Internal: client is price-sensitive on liability; partner happy to concede cap to GBP 250k if notice is 120 days."))
    db.add(InternalNote(firm_id=w.firm.id, matter_id=M["whitaker_dispute"].id, author_id=w.u("Gareth Ainsworth").id, body="Internal: check whether the set-off argument has any evidential support before we send the letter before claim."))
    db.flush()


# ------------------------------------------------------------------------------------------------ knowledge & templates
def seed_knowledge_and_templates(db: Session, w: World) -> None:
    fid = w.firm.id
    approver = w.u("Eleanor Whitcombe")
    for (title, kind, area, eff, rev, ref, body) in C.KNOWLEDGE:
        db.add(KnowledgeItem(firm_id=fid, title=title, kind=kind, practice_area=area, body=body, source_ref=ref, effective_date=date.fromisoformat(eff),
                             last_reviewed=date.fromisoformat(rev) if rev else None, approved=True, approved_by=approver.id))
    t = C.KNOWLEDGE_UNAPPROVED
    db.add(KnowledgeItem(firm_id=fid, title=t[0], kind=t[1], practice_area=t[2], body=t[6], source_ref=t[5], effective_date=date.fromisoformat(t[3]), approved=False))
    for (name, dtype, area, approved, body, fields) in C.TEMPLATES:
        db.add(DocumentTemplate(firm_id=fid, name=name, doc_type=dtype, practice_area=area, body=body, fields=fields, approved=approved, approved_by=approver.id if approved else None))
    db.flush()


# ------------------------------------------------------------------------------------------------ time, billing, ledger
NARR = {
    "commercial": ["Reviewing draft agreement and preparing mark-up", "Attendance on client call regarding commercial terms", "Drafting email to counterparty's solicitors", "Reviewing counterparty comments", "Preparing note on liability provisions"],
    "corporate": ["Reviewing due diligence materials", "Drafting disclosure letter", "Attendance on deal team call", "Reviewing draft SPA mark-up", "Preparing completion checklist"],
    "property": ["Reviewing title and replies to enquiries", "Drafting replies to buyer's enquiries", "Telephone call with client", "Reviewing draft contract", "Preparing report on title"],
    "litigation": ["Reviewing client documents and invoices", "Drafting letter before claim", "Attendance on client conference", "Legal research note (internal sources only)", "Reviewing counterparty correspondence"],
    "employment": ["Reviewing employment contract and policies", "Preparing advice on consultation obligations", "Call with client HR", "Drafting settlement terms", "Reviewing draft consultation timetable"],
    "private_client": ["Taking instructions on estate", "Collating asset information", "Drafting executor update letter", "Reviewing will and codicil", "Preparing inheritance tax account workings"],
}


def seed_time(db: Session, w: World) -> dict:
    rnd = random.Random(2026)
    entries: dict[str, list] = {}
    for key, m in w.matters.items():
        if key == "ridgeway_licence":
            continue
        who = next(u for u in w.users.values() if u.id == m.fee_earner_id)
        partner = next(u for u in w.users.values() if u.id == m.responsible_partner_id)
        n = 14 if m.status == "open" else 6
        for i in range(n):
            days = rnd.randint(1, 44)
            u = partner if i % 5 == 0 else who
            ctx = ctx_for(db, u)
            te = billing.create_time_entry(ctx, matter_id=m.id, work_date=TODAY - timedelta(days=days), minutes=rnd.choice([12, 18, 24, 30, 36, 42, 48, 60, 72, 90, 120]),
                                           narrative=rnd.choice(NARR[m.practice_area]))
            if days > 6:
                billing.submit_time_entry(ctx, te.id)
                billing.approve_time_entry(ctx_for(db, partner), te.id)
            elif days > 2:
                billing.submit_time_entry(ctx, te.id)
            entries.setdefault(key, []).append((te.id, days))
    # ridgeway: two entries, billed in full then paid
    d = w.u("Daniel Rhodes")
    rm = w.matters["ridgeway_licence"]
    rm.status = "open"   # time can only be recorded on open matters; the matter is re-closed straight after
    db.flush()
    for mins in (120, 120):
        te = billing.create_time_entry(ctx_for(db, d), matter_id=w.matters["ridgeway_licence"].id, work_date=TODAY - timedelta(days=90), minutes=mins, narrative="Final review of licence and completion")
        billing.submit_time_entry(ctx_for(db, d), te.id)
        billing.approve_time_entry(ctx_for(db, w.u("Eleanor Whitcombe")), te.id)
        entries.setdefault("ridgeway_licence", []).append((te.id, 90))
    rm.status = "closed"
    db.flush()
    return entries


def _bill(db, w, matter_key, te_ids, *, approve=True, issue=True, **kw):
    m = w.matters[matter_key]
    fe = next(u for u in w.users.values() if u.id == m.fee_earner_id)
    partner = next(u for u in w.users.values() if u.id == m.responsible_partner_id)
    inv = billing.create_draft_invoice(ctx_for(db, fe), matter_id=m.id, time_entry_ids=te_ids, **kw)
    if approve or issue:
        billing.submit_invoice_for_approval(ctx_for(db, fe), inv.id)
    if approve:
        billing.decide_invoice(ctx_for(db, partner), inv.id, approve=True)
    if issue:
        billing.issue_invoice(ctx_for(db, w.u("Nadia Siddiqui")), inv.id)
    db.flush()
    return inv


def seed_billing_and_ledger(db: Session, w: World, entries: dict) -> None:
    led.ensure_chart_of_accounts(db, w.firm.id)
    nadia, colin = w.u("Nadia Siddiqui"), w.u("Colin Whitaker")
    invs = {}
    # issued invoices from time older than four weeks (approved entries)
    for key in ["supply", "whitaker_dispute", "penfab_sha", "ainsley_estate", "aldwark_acq"]:
        ids = [i for i, d in entries.get(key, []) if d > 20]
        if ids:
            invs[key] = _bill(db, w, key, ids)
    invs["ridgeway_licence"] = _bill(db, w, "ridgeway_licence", [i for i, _ in entries["ridgeway_licence"]])
    # a draft invoice awaiting partner approval and one plain draft
    ids = [i for i, d in entries.get("supply", []) if 7 < d <= 20]
    if ids:
        _bill(db, w, "supply", ids[:3], approve=False, issue=False)
    ids = [i for i, d in entries.get("tupe", []) if d > 6]
    if ids:
        inv = billing.create_draft_invoice(ctx_for(db, w.u("Amira Khalid")), matter_id=w.matters["tupe"].id, time_entry_ids=ids)
        billing.submit_invoice_for_approval(ctx_for(db, w.u("Amira Khalid")), inv.id)
    # fixed fee invoice on hartley_sale, paid from client money below
    hs = _bill(db, w, "hartley_sale", [], include_fixed_fee=True)
    invs["hartley_sale"] = hs
    db.flush()

    # ---- bank feeds (SYNTHETIC) -> receipts
    rec.sync_bank_feed(ctx_for(db, colin), "office")
    rec.sync_bank_feed(ctx_for(db, colin), "client")
    lines = {l.external_id: l for l in db.execute(select(BankStatementLine).where(BankStatementLine.firm_id == w.firm.id)).scalars()}

    def receive(line_id, matter_key=None):
        ctx_c = ctx_for(db, colin)
        pay = rec.record_receipt(ctx_c, lines[line_id].id, matter_id=w.matters[matter_key].id if matter_key else None)
        j = db.get(Journal, pay.receipt_journal_id)
        led.decide_approval(ctx_for(db, nadia), j.approval_id, approve=True)
        led.post_journal(ctx_c, j.id)
        db.flush()
        return pay

    p_office_a = receive("SYN-O-0001")                                # £1,500 -> allocate to ridgeway invoice
    p_office_b = receive("SYN-O-0002")                                # £2,400 -> left unallocated (exception demo)
    c1 = receive("SYN-C-0001", "hartley_sale")                         # £10,000 client money (completion funds)
    c2 = receive("SYN-C-0002", "ainsley_estate")                       # £2,500 client money on account
    # allocate receipt A to the ridgeway invoice (min of invoice total / receipt)
    rinv = db.get(Invoice, invs["ridgeway_licence"].id)
    amt = min(rinv.total - rinv.amount_paid, p_office_a.amount)
    ap = led.request_allocation(ctx_for(db, colin), p_office_a.id, [{"invoice_id": str(rinv.id), "amount": str(amt)}])
    led.decide_approval(ctx_for(db, nadia), ap.id, approve=True)
    led.execute_allocation(ctx_for(db, colin), p_office_a.id, [{"invoice_id": str(rinv.id), "amount": str(amt)}], ap.id)
    # client -> office transfer to pay the hartley fixed-fee invoice (four-eyes)
    hinv = db.get(Invoice, hs.id)
    tr = led.request_client_transfer(ctx_for(db, colin), hinv.id, hinv.total)
    led.decide_approval(ctx_for(db, nadia), tr.id, approve=True)
    led.execute_client_transfer(ctx_for(db, colin), hinv.id, hinv.total, tr.id)
    # the bank statements would show the internal transfer on both accounts (SYNTHETIC lines)
    from app.models import LedgerAccount
    ob = db.execute(select(LedgerAccount).where(LedgerAccount.firm_id == w.firm.id, LedgerAccount.system_key == "bank_office")).scalar_one()
    cb = db.execute(select(LedgerAccount).where(LedgerAccount.firm_id == w.firm.id, LedgerAccount.system_key == "bank_client")).scalar_one()
    rec.import_statement_lines(ctx_for(db, colin), ob.id, [{"external_id": "SYN-O-TRF-0001", "txn_date": TODAY, "description": "SYNTHETIC INTERNAL TRANSFER FROM CLIENT ACCOUNT", "amount": hinv.total, "reference": "SYN-TRANSFER"}])
    rec.import_statement_lines(ctx_for(db, colin), cb.id, [{"external_id": "SYN-C-TRF-0001", "txn_date": TODAY, "description": "SYNTHETIC INTERNAL TRANSFER TO OFFICE ACCOUNT", "amount": -hinv.total, "reference": "SYN-TRANSFER"}])
    # explicit revenue recognition on the (paid) ridgeway invoice: net fees only
    rinv = db.get(Invoice, invs["ridgeway_licence"].id)
    j = led.request_revenue_recognition(ctx_for(db, colin), rinv.id, rinv.subtotal, "Matter completed and bill delivered; recognised on completion of the instruction (demonstration basis).")
    led.decide_approval(ctx_for(db, nadia), j.approval_id, approve=True)
    led.post_journal(ctx_for(db, colin), j.id)
    db.flush()
