"""Tiny PDF generator (reportlab) for fictional sample documents."""
from __future__ import annotations

import io

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate


def pdf_from_text(text: str, title: str, break_after: tuple[int, ...] = (9, 20)) -> bytes:
    st = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=st["BodyText"], fontName="Times-Roman", fontSize=11, leading=15, spaceAfter=9)
    head = ParagraphStyle("h", parent=st["Heading2"], fontName="Times-Bold", fontSize=12, spaceBefore=6, spaceAfter=8)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=25 * mm, rightMargin=25 * mm, topMargin=25 * mm, bottomMargin=22 * mm, title=title,
                            author="Pennine & Calder Solicitors (fictional)")
    flow = []
    for i, block in enumerate(b.strip() for b in text.split("\n\n") if b.strip()):
        safe = block.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br/>")
        first = block.split("\n")[0]
        flow.append(Paragraph(safe, head if first.isupper() else body))
        if i in break_after:
            flow.append(PageBreak())
    doc.build(flow)
    return buf.getvalue()
