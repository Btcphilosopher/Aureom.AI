"""Seed part 1: firm, staff, contacts, matters, parties, access control, tasks, deadlines, diary. All data is fictional."""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import (Contact, ContactAddress, ContactRelationship, Deadline, DeadlineRule, DiaryEvent, Firm, Matter, MatterChecklistItem, MatterMember,
                        MatterParty, MatterStateEvent, MatterTemplate, Office, OnboardingCheck, OnboardingRecord, RateCard, RateCardEntry, Role, Task,
                        TaskDependency, Team, User)
from app.security import hash_password
from app.seed import content as C
from app.services.bootstrap import create_firm, load_default_holidays

TODAY = date.today()


def dt(days: int, hour: int = 9, minute: int = 0) -> datetime:
    return datetime.combine(TODAY + timedelta(days=days), time(hour, minute), tzinfo=timezone.utc)


@dataclass
class World:
    firm: Firm
    offices: dict = field(default_factory=dict)
    teams: dict = field(default_factory=dict)
    users: dict = field(default_factory=dict)       # key: "first last" lower -> User
    contacts: dict = field(default_factory=dict)    # short key -> Contact
    matters: dict = field(default_factory=dict)     # short key -> Matter
    templates: dict = field(default_factory=dict)   # practice_area -> MatterTemplate

    def u(self, name: str) -> User:
        return self.users[name]


def seed_firm_and_staff(db: Session) -> World:
    firm = create_firm(db, name=C.FIRM_NAME, slug=C.FIRM_SLUG, offices=C.OFFICES)
    load_default_holidays(db, firm.id)
    w = World(firm=firm)
    for o in db.execute(select(Office).where(Office.firm_id == firm.id)).scalars():
        w.offices[o.city] = o
    offices_addr = {"Leeds": "1 Aire Street, Leeds LS1 4HT", "Manchester": "22 Peter Street, Manchester M2 5QR", "Halifax": "9 Southgate, Halifax HX1 1AA"}
    for city, o in w.offices.items():
        o.address = offices_addr[city]
    for name, area in C.TEAMS:
        t = Team(firm_id=firm.id, name=name, practice_area=area)
        db.add(t); db.flush()
        w.teams[name] = t
    roles = {r.key: r for r in db.execute(select(Role).where(Role.firm_id == firm.id)).scalars()}
    pw = hash_password(get_settings().demo_password)
    for name, local, role, title, city, team, grade in C.STAFF:
        u = User(firm_id=firm.id, email=f"{local}@{C.EMAIL_DOMAIN}", name=name, initials="".join(p[0] for p in name.split()[:2]).upper(), job_title=title,
                 password_hash=pw, role_id=roles[role].id, office_id=w.offices[city].id, team_id=w.teams[team].id, grade=grade)
        db.add(u); db.flush()
        w.users[name] = u
    # rate card
    rc = RateCard(firm_id=firm.id, name="Standard rates 2026", currency="GBP", is_default=True)
    db.add(rc); db.flush()
    for grade, rate in C.RATES.items():
        db.add(RateCardEntry(firm_id=firm.id, rate_card_id=rc.id, grade=grade, hourly_rate=rate))
    w.rate_card = rc
    # illustrative deadline rules (NOT authoritative)
    for key, name, off, daytype, direction, desc in [
        ("response_14_cal", "Response to correspondence - 14 days after receipt (illustrative)", 14, "calendar", "after", "Illustrative demonstration rule."),
        ("contractual_notice_10_bd", "Contractual notice - 10 business days after service (illustrative)", 10, "business", "after", "Use only where the agreement says business days; verify definitions."),
        ("acknowledgement_5_bd", "Acknowledgement - 5 business days after instruction (illustrative)", 5, "business", "after", "Internal service standard."),
        ("limitation_review_6y", "Limitation review reminder - 6 years after breach (placeholder)", 365 * 6, "calendar", "after", "Placeholder to prompt solicitor review. Not a statement of the limitation period."),
    ]:
        db.add(DeadlineRule(firm_id=firm.id, key=key, name=name, offset_days=off, day_type=daytype, direction=direction, description=desc))
    # matter templates
    for (name, area, mtype, stages, opening, closing, req, fee, ret, tasks) in C.MATTER_TEMPLATES:
        t = MatterTemplate(firm_id=firm.id, name=name, practice_area=area, matter_type=mtype, description=f"Standard {area.replace('_', ' ')} workflow (demonstration template).",
                           stages=[{"key": k, "name": n} for k, n in stages], opening_checklist=[{"label": l, "required": r} for l, r in opening],
                           closing_checklist=[{"label": l, "required": r} for l, r in closing], required_fields=req, default_fee_arrangement=fee,
                           default_retention_key=ret, default_tasks=[{"title": t_, "due_in_days": d} for t_, d in tasks])
        db.add(t); db.flush()
        w.templates[area] = t
    db.flush()
    return w


def _contact(db, w, key, kind, name, *, client=False, status="active", **kw) -> Contact:
    c = Contact(firm_id=w.firm.id, kind=kind, display_name=name, is_client=client, status=status, **kw)
    if kind == "individual" and "first_name" not in kw:
        parts = name.replace("Mr ", "").replace("Mrs ", "").split()
        c.first_name, c.last_name = parts[0], parts[-1]
    if kind == "organisation":
        c.org_name = name
    db.add(c); db.flush()
    w.contacts[key] = c
    return c


def _addr(db, w, c, line1, city, postcode, kind="registered"):
    db.add(ContactAddress(firm_id=w.firm.id, contact_id=c.id, kind=kind, line1=line1, city=city, postcode=postcode, is_primary=True))


def seed_contacts(db: Session, w: World) -> None:
    fid = w.firm.id
    owner = {"calder": "Daniel Rhodes", "aldwark": "Eleanor Whitcombe", "moorside": "Priya Venkataraman", "holroyd": "Marianne Oyelaran", "penfab": "Sofia Marchetti",
             "ridgeway": "Daniel Rhodes", "whitaker": "Gareth Ainsworth"}
    orgs = [("calder", "Calder Textiles Ltd", "05123456", "Unit 4, Brookfoot Mills, Brighouse", "Brighouse", "HD6 2RW", "accounts@calder-textiles.example", "Leeds"),
            ("aldwark", "Aldwark Industrial Holdings Ltd", "06234567", "Aldwark House, Wellington Street, Leeds", "Leeds", "LS1 4DL", "legal@aldwark-holdings.example", "Leeds"),
            ("moorside", "Moorside Brewing Ltd", "07345678", "Canal Wharf, Hebden Road, Halifax", "Halifax", "HX1 2AB", "hello@moorsidebrewing.example", "Halifax"),
            ("holroyd", "Holroyd Logistics Ltd", "04456789", "Depot Way, Trafford Park, Manchester", "Manchester", "M17 1QS", "hr@holroyd-logistics.example", "Manchester"),
            ("penfab", "Pennine Fabrication Ltd", "08567890", "Brewery Lane Industrial Estate, Huddersfield", "Huddersfield", "HD1 5NN", "office@pennine-fab.example", "Leeds"),
            ("ridgeway", "Ridgeway Software Ltd", "09678901", "3 Victoria Road, Saltaire", "Bradford", "BD18 3LA", "finance@ridgeway-software.example", "Leeds"),
            ("whitaker", "Whitaker Haulage Ltd", "03789012", "Moss Lane Yard, Rochdale", "Rochdale", "OL11 2PD", "info@whitaker-haulage.example", "Manchester")]
    n = 1
    for key, name, cn, line, city, pc, email, office in orgs:
        c = _contact(db, w, key, "organisation", name, client=True, company_number=cn, email=email, client_ref=f"PCS-C-{n:04d}",
                     responsible_user_id=w.u(owner[key]).id, office_id=w.offices[office].id, preferred_channel="email", phone="0113 496 0" + f"{100 + n}")
        _addr(db, w, c, line, city, pc); n += 1
    people = [("anna", "Anna Hartley", "1961-04-12", "Hugh Fairbairn", "Halifax", "anna.hartley@mailbox.example", "14 Weavers Row", "Halifax", "HX1 3JD"),
              ("peter", "Peter Hartley", "1958-09-30", "Hugh Fairbairn", "Halifax", "peter.hartley@mailbox.example", "14 Weavers Row", "Halifax", "HX1 3JD"),
              ("ogden", "Dennis Ogden", "1948-01-22", "Hugh Fairbairn", "Halifax", "dennis.ogden@mailbox.example", "2 Park Terrace", "Todmorden", "OL14 5DH"),
              ("ainsley_exec", "Ruth Ainsley", "1970-06-05", "Hugh Fairbairn", "Halifax", "ruth.ainsley@mailbox.example", "27 Elland Road", "Brighouse", "HD6 2QR"),
              ("ackroyd", "Martin Ackroyd", "1975-11-02", "Hugh Fairbairn", "Halifax", "martin.ackroyd@mailbox.example", "5 Spring Hall Lane", "Halifax", "HX1 4JG")]
    for key, name, dob, resp, office, email, line1, city, pc in people:
        c = _contact(db, w, key, "individual", name, client=True, date_of_birth=date.fromisoformat(dob), email=email, client_ref=f"PCS-C-{n:04d}", responsible_user_id=w.u(resp).id,
                     office_id=w.offices[office].id, phone="01422 " + f"{355000 + n}")
        _addr(db, w, c, line1, city, pc, "residential"); n += 1
    # directors / other individuals
    jm = _contact(db, w, "marsden", "individual", "Jonathan Marsden", client=False, date_of_birth=date(1979, 3, 3), email="jonathan.marsden@moorsidebrewing.example", status="active")
    jm2 = _contact(db, w, "marsden_dup", "individual", "Jon Marsden", client=False, date_of_birth=date(1979, 3, 3), email="jonathan.marsden@moorsidebrewing.example", status="prospect")
    dup = _contact(db, w, "calder_dup", "organisation", "Calder Textiles Limited", client=False, company_number="05123456", status="prospect", email="accounts@calder-textiles.example")
    # counterparties
    for key, name, kind, extra in [
        ("brigg", "Brigg Precision Engineering Ltd", "organisation", {"company_number": "02345678"}),
        ("aggregates", "Pennine Aggregates Ltd", "organisation", {"company_number": "01567890"}),
        ("ripon", "Ripon Interiors Ltd", "organisation", {"company_number": "06111222"}),
        ("hebden_co", "Hebden Brewing Co", "organisation", {"company_number": "04999888", "aliases": ["Hebden Brewing Company"]}),
        ("canalwharf", "Canal Wharf Estates Ltd", "organisation", {"company_number": "07000111"}),
        ("rowley", "Rowley & Finch LLP", "organisation", {}),
        ("bairstow", "Stephen Bairstow", "individual", {"date_of_birth": date(1968, 8, 19)}),
        ("brook", "Harriet Brook", "individual", {"date_of_birth": date(1985, 2, 14)}),
        ("ackroyd_other", "Martin Ackroyd", "individual", {"date_of_birth": date(1991, 5, 21), "email": "m.ackroyd@sheffield-mail.example"}),
    ]:
        _contact(db, w, key, kind, name, client=False, status="active", **extra)
    db.flush()
    # relationships
    def rel(a, b, t):
        db.add(ContactRelationship(firm_id=fid, from_contact_id=w.contacts[a].id, to_contact_id=w.contacts[b].id, relation_type=t))
    rel("marsden", "moorside", "director_of"); rel("ackroyd", "penfab", "director_of"); rel("anna", "peter", "spouse_of")
    rel("bairstow", "holroyd", "employee_of"); rel("ackroyd_other", "aggregates", "director_of")
    # onboarding for clients (approved, simulated checks)
    reviewer = w.u("Margaret Thackray")
    for key in ["calder", "aldwark", "moorside", "holroyd", "penfab", "ridgeway", "whitaker", "anna", "peter", "ogden", "ainsley_exec", "ackroyd"]:
        c = w.contacts[key]
        rec = OnboardingRecord(firm_id=fid, contact_id=c.id, status="approved", risk_level="low", reviewed_by=reviewer.id, reviewed_at=dt(-60),
                               notes="Onboarding approved by human reviewer (checks were SIMULATED in this demonstration).",
                               submitted_form={"source": "intake form", "how_heard": "referral"})
        db.add(rec); db.flush()
        types = ["id_individual", "address", "sanctions_pep"] if c.kind == "individual" else ["company_kyb", "sanctions_pep"]
        for t in types:
            db.add(OnboardingCheck(firm_id=fid, onboarding_id=rec.id, check_type=t, provider="simulated-identity", is_simulated=True, status="passed_simulated",
                                   result_summary="SIMULATED result - not a verified identity check.", performed_by=reviewer.id, performed_at=dt(-61),
                                   reviewed_by=reviewer.id, reviewed_at=dt(-60), external_ref="SIM-" + c.display_name[:3].upper()))
    # an incomplete onboarding (exception demo)
    c = w.contacts["marsden_dup"]
    rec = OnboardingRecord(firm_id=fid, contact_id=c.id, status="awaiting_client", notes="Waiting for proof of address.")
    db.add(rec)
    db.flush()


# (key, ref, title, area, mtype, client, partner, fee_earner, office, status, stage, desc, fee, budget, access, retention, opened_days_ago, target_days, team)
MATTERS = [
    ("supply", "PCS-COM-2026-0012", "Supply agreement review", "commercial", "Commercial contract", "calder", "Eleanor Whitcombe", "Daniel Rhodes", "Leeds", "open", "negotiation",
     "Review and negotiate a three-year supply agreement with a key yarn supplier.", "hourly", "18000.00", "standard", None, 70, 30, "Corporate & Commercial"),
    ("aldwark_acq", "PCS-COR-2026-0019", "Project Heron - acquisition of Brigg Precision Engineering Ltd", "corporate", "Corporate transaction", "aldwark", "Eleanor Whitcombe", "Sofia Marchetti", "Leeds",
     "open", "due_diligence", "Share purchase of Brigg Precision Engineering Ltd. Restricted: deal-sensitive.", "capped", "85000.00", "restricted", None, 45, 75, "Corporate & Commercial"),
    ("hartley_sale", "PCS-PRO-2026-0031", "Sale of 14 Weavers Row, Halifax", "property", "Residential sale", "anna", "Priya Venkataraman", "Joseph Lister", "Leeds", "open", "searches_enquiries",
     "Sale of the clients' home; buyer's solicitors have raised enquiries.", "fixed", "1850.00", "standard", None, 30, 25, "Property"),
    ("moorside_lease", "PCS-PRO-2026-0044", "Lease renewal - Unit 6, Canal Wharf", "property", "Commercial lease renewal", "moorside", "Priya Venkataraman", "Joseph Lister", "Leeds", "open", "instruction",
     "Renewal of the brewery taproom lease from Canal Wharf Estates Ltd.", "hourly", "7500.00", "standard", None, 14, 60, "Property"),
    ("whitaker_dispute", "PCS-LIT-2026-0007", "Whitaker Haulage v Pennine Aggregates - unpaid haulage invoices", "litigation", "Contract dispute", "whitaker", "Gareth Ainsworth", "Thomas Bagshaw", "Manchester", "open", "pre_action",
     "Pre-action recovery of unpaid haulage invoices; counterparty may rely on a set-off.", "hourly", "25000.00", "standard", None, 40, 45, "Litigation & Disputes"),
    ("calder_debt", "PCS-LIT-2025-0102", "Calder Textiles v Ripon Interiors - debt recovery", "litigation", "Debt recovery", "calder", "Gareth Ainsworth", "Thomas Bagshaw", "Manchester", "paused", "directions",
     "Paused pending the debtor's proposal.", "hourly", "9000.00", "standard", None, 210, None, "Litigation & Disputes"),
    ("exec_settlement", "PCS-EMP-2026-0015", "Senior executive settlement agreement (confidential)", "employment", "Settlement agreement", "holroyd", "Marianne Oyelaran", "Amira Khalid", "Manchester", "open", "negotiation",
     "Confidential exit negotiations for a senior employee. Client has instructed that AI tools are not to be used.", "fixed", "6500.00", "restricted", None, 21, 20, "Employment"),
    ("tupe", "PCS-EMP-2026-0021", "TUPE advice - depot transfer", "employment", "Employment advice", "holroyd", "Marianne Oyelaran", "Amira Khalid", "Manchester", "open", "advice",
     "Advice on information and consultation obligations on a proposed depot transfer.", "hourly", "12000.00", "standard", None, 18, 40, "Employment"),
    ("ainsley_estate", "PCS-PC-2026-0008", "Estate of Margaret Ainsley - probate", "private_client", "Probate", "ainsley_exec", "Hugh Fairbairn", "Charlotte Dunmore", "Halifax", "open", "administration",
     "Probate and administration of the estate; executor is the client.", "hourly", "9500.00", "standard", None, 95, 120, "Private Client"),
    ("ogden_lpa", "PCS-PC-2026-0013", "Lasting powers of attorney - Mr Ogden", "private_client", "Lasting power of attorney", "ogden", "Hugh Fairbairn", "Charlotte Dunmore", "Halifax", "open", "drafting_or_grant",
     "Property & financial affairs and health & welfare LPAs.", "fixed", "950.00", "standard", None, 12, 21, "Private Client"),
    ("penfab_sha", "PCS-COR-2026-0003", "Shareholders' agreement - Pennine Fabrication Ltd", "corporate", "Shareholders' agreement", "penfab", "Eleanor Whitcombe", "Sofia Marchetti", "Leeds", "open", "documentation",
     "New investor joining; shareholders' agreement and articles amendments.", "capped", "22000.00", "standard", None, 88, 20, "Corporate & Commercial"),
    ("ridgeway_licence", "PCS-COM-2025-0088", "Software licensing - Ridgeway Software Ltd", "commercial", "Commercial contract", "ridgeway", "Eleanor Whitcombe", "Daniel Rhodes", "Leeds", "closed", "post_completion",
     "Enterprise software licence agreement. Completed and closed.", "hourly", "6000.00", "standard", "general_6y", 400, None, "Corporate & Commercial"),
]


def seed_matters(db: Session, w: World) -> None:
    fid = w.firm.id
    for (key, ref, title, area, mtype, client, partner, fe, office, status, stage, desc, fee, budget, access, ret, opened_ago, target, team) in MATTERS:
        tpl = w.templates[area]
        m = Matter(firm_id=fid, reference=ref, title=title, matter_type=mtype, practice_area=area, description=desc, client_id=w.contacts[client].id, office_id=w.offices[office].id,
                   team_id=w.teams[team].id, responsible_partner_id=w.u(partner).id, fee_earner_id=w.u(fe).id, status=status, stage=stage, opened_at=TODAY - timedelta(days=opened_ago),
                   target_date=TODAY + timedelta(days=target) if target else None, template_id=tpl.id, access_level=access, fee_arrangement=fee,
                   fixed_fee_amount=budget if fee == "fixed" else None, budget_amount=budget, currency="GBP", rate_card_id=w.rate_card.id,
                   retention_policy_key=ret or tpl.default_retention_key, custom_fields={})
        if status == "closed":
            m.closed_at = TODAY - timedelta(days=45)
            m.retention_until = date(m.closed_at.year + 6, m.closed_at.month, min(m.closed_at.day, 28))
        db.add(m); db.flush()
        w.matters[key] = m
        db.add(MatterParty(firm_id=fid, matter_id=m.id, contact_id=w.contacts[client].id, role="client"))
        for i, it in enumerate(tpl.opening_checklist):
            db.add(MatterChecklistItem(firm_id=fid, matter_id=m.id, phase="opening", label=it["label"], required=it["required"], position=i, completed_at=dt(-opened_ago), completed_by=w.u(partner).id))
        for i, it in enumerate(tpl.closing_checklist):
            done = status == "closed"
            db.add(MatterChecklistItem(firm_id=fid, matter_id=m.id, phase="closing", label=it["label"], required=it["required"], position=i,
                                       completed_at=dt(-46) if done else None, completed_by=w.u(partner).id if done else None))
        db.add(MatterStateEvent(firm_id=fid, matter_id=m.id, from_status="prospective", to_status="open", actor_id=w.u(partner).id, reason="Opened after conflict review and onboarding approval (seed)"))
        if status == "paused":
            db.add(MatterStateEvent(firm_id=fid, matter_id=m.id, from_status="open", to_status="paused", actor_id=w.u(partner).id, reason="Debtor has made a payment proposal; pausing pending response"))
        if status == "closed":
            db.add(MatterStateEvent(firm_id=fid, matter_id=m.id, from_status="open", to_status="closed", actor_id=w.u(partner).id, reason="Matter complete; retention policy general_6y applied"))
    db.flush()
    # parties: counterparties, payers, witnesses
    def party(m, c, role):
        db.add(MatterParty(firm_id=fid, matter_id=w.matters[m].id, contact_id=w.contacts[c].id, role=role))
    party("aldwark_acq", "brigg", "counterparty"); party("aldwark_acq", "rowley", "counterparty_solicitor")
    party("whitaker_dispute", "aggregates", "counterparty"); party("whitaker_dispute", "hebden_co", "witness"); party("whitaker_dispute", "ackroyd_other", "other")
    party("calder_debt", "ripon", "counterparty"); party("moorside_lease", "canalwharf", "counterparty"); party("moorside_lease", "marsden", "other")
    party("hartley_sale", "peter", "client"); party("hartley_sale", "peter", "payer")
    party("exec_settlement", "bairstow", "beneficiary"); party("ainsley_estate", "ainsley_exec", "beneficiary"); party("tupe", "bairstow", "witness")
    party("penfab_sha", "ackroyd", "other"); party("supply", "brook", "witness")
    # restricted matters: members + ethical wall
    A = w.matters["aldwark_acq"]; E = w.matters["exec_settlement"]
    for u in ["Eleanor Whitcombe", "Sofia Marchetti", "Nadia Siddiqui"]:
        db.add(MatterMember(firm_id=fid, matter_id=A.id, user_id=w.u(u).id, access="allow", member_role="lead" if "Eleanor" in u else "team", added_by=w.u("Eleanor Whitcombe").id, reason="Deal team"))
    db.add(MatterMember(firm_id=fid, matter_id=A.id, team_id=w.teams["Employment"].id, access="deny", added_by=w.u("Margaret Thackray").id,
                        reason="Precautionary ethical wall: Employment team acts for a former Brigg executive in an unrelated matter."))
    A.ethical_wall = True
    for u in ["Marianne Oyelaran", "Amira Khalid", "Nadia Siddiqui"]:
        db.add(MatterMember(firm_id=fid, matter_id=E.id, user_id=w.u(u).id, access="allow", member_role="team", added_by=w.u("Marianne Oyelaran").id, reason="Matter team"))
    E.ai_retrieval_allowed = False
    E.exports_allowed = False
    db.flush()


def seed_tasks_deadlines_diary(db: Session, w: World) -> None:
    fid = w.firm.id
    def task(m, title, who, days, status="open", prio="normal", created_by=None, **kw):
        t = Task(firm_id=fid, matter_id=w.matters[m].id if m else None, title=title, assignee_id=w.u(who).id, created_by=w.u(created_by or who).id,
                 due_at=dt(days, 17), status=status, priority=prio, completed_at=dt(days, 12) if status == "done" else None, source="manual", **kw)
        db.add(t); db.flush()
        return t
    t1 = task("supply", "Send mark-up of clauses 4-7 to Calder's supplier", "Daniel Rhodes", -2, prio="high")
    t2 = task("supply", "Call Eleanor re liability cap position", "Daniel Rhodes", 1)
    t3 = task("supply", "Prepare final execution version", "Ben Holroyd", 9)
    db.add(TaskDependency(firm_id=fid, task_id=t3.id, depends_on_task_id=t1.id))
    task("aldwark_acq", "Review disclosure letter - schedule 4 (employees)", "Sofia Marchetti", 3, prio="urgent")
    task("aldwark_acq", "Chase target's solicitors for data room index", "Ben Holroyd", -1, prio="high")
    task("hartley_sale", "Reply to buyer's enquiries (boundary and fixtures)", "Joseph Lister", 2)
    task("hartley_sale", "Request redemption statement", "Joseph Lister", 4)
    task("moorside_lease", "Take instructions on rent proposal", "Priya Venkataraman", 5)
    task("whitaker_dispute", "Draft letter before claim", "Thomas Bagshaw", 4, prio="high", escalate_to_id=w.u("Gareth Ainsworth").id, escalate_after_hours=24)
    task("whitaker_dispute", "Collate invoices and delivery notes", "Imogen Pratt", -3, prio="high")
    task("whitaker_dispute", "Supervisor review of draft letter before claim", "Gareth Ainsworth", 6)
    task("exec_settlement", "Prepare first draft settlement agreement", "Amira Khalid", 5)
    task("tupe", "Consultation timetable note for client", "Amira Khalid", 7)
    task("ainsley_estate", "Submit inheritance tax account", "Charlotte Dunmore", 15)
    task("ainsley_estate", "Update executor on asset collection", "Charlotte Dunmore", -4, prio="normal")
    task("ogden_lpa", "Arrange signing appointment", "Charlotte Dunmore", 3)
    task("penfab_sha", "Circulate engrossments for signature", "Sofia Marchetti", 8)
    task(None, "Complete AML refresher training", "Daniel Rhodes", 12, status="open", prio="low")
    task("supply", "Weekly file review (recurring)", "Daniel Rhodes", 3, recurrence={"freq": "weekly", "interval": 1, "until": (TODAY + timedelta(days=60)).isoformat()}, reminder_offsets_minutes=[60])
    task("whitaker_dispute", "Initial client call", "Thomas Bagshaw", -30, status="done")
    db.flush()

    def deadline(m, title, days, status, origin, who, **kw):
        d = Deadline(firm_id=fid, matter_id=w.matters[m].id, title=title, due_date=TODAY + timedelta(days=days), status=status, origin=origin, timezone="Europe/London",
                     jurisdiction="england_and_wales", **kw)
        if status in ("confirmed", "met", "missed"):
            d.confirmed_by, d.confirmed_at = w.u(who).id, dt(-3)
        db.add(d)
        return d
    deadline("supply", "Counter-party response to mark-up due", 6, "confirmed", "manual", "Eleanor Whitcombe", assumptions="Date agreed by email with counterparty's solicitor.")
    deadline("hartley_sale", "Target exchange of contracts", 14, "confirmed", "manual", "Priya Venkataraman", assumptions="Buyer's target date; not a legal limit.")
    deadline("whitaker_dispute", "Response period to letter before claim (suggested)", 18, "suggested", "calculated_suggestion", "Thomas Bagshaw", rule_key="response_14_cal",
             trigger_date=TODAY + timedelta(days=4), suggested_by=w.u("Thomas Bagshaw").id, reviewer_id=w.u("Gareth Ainsworth").id,
             assumptions="Assumes the letter is sent on the due date of the drafting task and deemed received the same day. Illustrative rule: 14 calendar days. REQUIRES solicitor confirmation against the applicable protocol.",
             calculation={"rule": "response_14_cal", "offset_days": 14, "day_type": "calendar", "steps": ["trigger 2026-11-16", "+14 calendar days = 2026-11-30", "not a weekend or holiday"]})
    deadline("penfab_sha", "Investor long-stop date", 25, "confirmed", "manual", "Eleanor Whitcombe", assumptions="Per term sheet clause 9.")
    deadline("ainsley_estate", "IHT account target submission", 28, "confirmed", "manual", "Hugh Fairbairn", assumptions="Internal target. The statutory position is for the supervising solicitor to confirm.")
    deadline("aldwark_acq", "Exclusivity period ends", 20, "confirmed", "manual", "Eleanor Whitcombe", assumptions="Per exclusivity letter signed 29 Sept.")
    deadline("tupe", "Consultation start date", -1, "met", "manual", "Marianne Oyelaran")
    db.flush()

    def event(m, title, kind, days, hour, mins, who, loc):
        s = dt(days, hour)
        db.add(DiaryEvent(firm_id=fid, matter_id=w.matters[m].id if m else None, title=title, kind=kind, start_at=s, end_at=s + timedelta(minutes=mins), owner_id=w.u(who).id,
                          attendee_ids=[w.u(who).id], location=loc))
    event("supply", "Client call - Calder Textiles", "call", 1, 11, 45, "Daniel Rhodes", "Teams")
    event("aldwark_acq", "Deal team stand-up", "meeting", 0, 8, 30, "Eleanor Whitcombe", "Leeds, Room 3")
    event("aldwark_acq", "Disclosure meeting with target's solicitors", "meeting", 4, 14, 120, "Sofia Marchetti", "Leeds, Boardroom")
    event("whitaker_dispute", "Case conference", "meeting", 3, 10, 60, "Gareth Ainsworth", "Manchester, Room 2")
    event("hartley_sale", "Client appointment - signing Form TA6", "appointment", 5, 15, 45, "Joseph Lister", "Leeds reception")
    event("ogden_lpa", "LPA signing appointment", "appointment", 6, 11, 60, "Charlotte Dunmore", "Halifax, Room 1")
    event("exec_settlement", "Negotiation call", "call", 8, 16, 45, "Marianne Oyelaran", "Teams")
    event(None, "Partners' meeting", "meeting", 2, 9, 90, "Eleanor Whitcombe", "Leeds, Boardroom")
    db.flush()
