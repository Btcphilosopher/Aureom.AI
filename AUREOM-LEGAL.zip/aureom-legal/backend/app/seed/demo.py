"""Seed the Pennine & Calder Solicitors demonstration firm.

    python -m app.seed.demo --if-empty      # used by docker entrypoint
    python -m app.seed.demo --reset         # DROP the demo firm (only) and re-seed
Runs with the OWNER database connection (MIGRATION_DATABASE_URL). All data is fictional."""
from __future__ import annotations

import sys

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Firm
from app.seed import base, content as C, records


def seed(db: Session) -> base.World:
    w = base.seed_firm_and_staff(db)
    base.seed_contacts(db, w)
    base.seed_matters(db, w)
    base.seed_tasks_deadlines_diary(db, w)
    db.commit()
    records.seed_portal_users(db, w)
    records.seed_knowledge_and_templates(db, w)
    db.commit()
    from app.worker import load_handlers
    load_handlers()
    records.seed_documents(db, w)
    db.commit()
    records.seed_correspondence(db, w)
    db.commit()
    entries = records.seed_time(db, w)
    db.commit()
    records.seed_billing_and_ledger(db, w, entries)
    db.commit()
    try:
        from app.seed import ai_runs
        ai_runs.seed_ai(db, w)
        db.commit()
    except ImportError:  # AI demo runs are optional
        pass
    return w


def main(argv: list[str]) -> int:
    from app import integrations
    integrations.load_all()
    engine = create_engine(get_settings().migration_database_url)
    with Session(engine, expire_on_commit=False) as db:
        existing = db.execute(select(Firm).where(Firm.slug == C.FIRM_SLUG)).scalar_one_or_none()
        if existing and "--if-empty" in argv:
            print("Demo firm already present; nothing to do.")
            return 0
        if existing:
            print("Demo firm exists. Drop the database or use a fresh schema to re-seed.")
            return 1
        seed(db)
        print(f"Seeded {C.FIRM_NAME}. Demo password for all users: {get_settings().demo_password}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
