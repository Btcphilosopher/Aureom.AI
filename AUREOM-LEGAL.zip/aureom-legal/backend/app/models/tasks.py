from __future__ import annotations

import uuid
from datetime import date, datetime, time

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, Integer, String, Text, Time, UniqueConstraint
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, pk


class Task(Base, TenantMixin, TimestampMixin):
    __tablename__ = "tasks"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    assignee_id: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    created_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="open")
    priority: Mapped[str] = mapped_column(String(8), nullable=False, default="normal")  # low|normal|high|urgent
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # recurrence: {"freq": "daily|weekly|monthly", "interval": 1, "until": "YYYY-MM-DD"}
    recurrence: Mapped[dict | None] = mapped_column(JSONB)
    reminder_offsets_minutes: Mapped[list] = mapped_column(ARRAY(Integer), nullable=False, default=list)
    last_reminded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    escalate_to_id: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    escalate_after_hours: Mapped[int | None] = mapped_column(Integer)
    escalated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deadline_id: Mapped[uuid.UUID | None] = fk("deadlines.id", nullable=True)
    source: Mapped[str] = mapped_column(String(16), nullable=False, default="manual")  # manual|template|agent
    agent_run_id: Mapped[uuid.UUID | None] = fk("agent_runs.id", nullable=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class TaskDependency(Base, TenantMixin):
    __tablename__ = "task_dependencies"
    id: Mapped[uuid.UUID] = pk()
    task_id: Mapped[uuid.UUID] = fk("tasks.id", ondelete="CASCADE")
    depends_on_task_id: Mapped[uuid.UUID] = fk("tasks.id", ondelete="CASCADE")
    __table_args__ = (UniqueConstraint("task_id", "depends_on_task_id"), CheckConstraint("task_id <> depends_on_task_id", name="no_self"))


class DiaryEvent(Base, TenantMixin, TimestampMixin):
    __tablename__ = "diary_events"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="appointment")  # appointment|hearing|meeting|call|deadline
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    end_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    location: Mapped[str | None] = mapped_column(String(300))
    attendee_ids: Mapped[list] = mapped_column(ARRAY(UUID(as_uuid=True)), nullable=False, default=list)
    owner_id: Mapped[uuid.UUID] = fk("users.id")
    description: Mapped[str | None] = mapped_column(Text)
    external_calendar_ref: Mapped[str | None] = mapped_column(String(120))
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class DeadlineRule(Base, TenantMixin, TimestampMixin):
    """Configurable, ILLUSTRATIVE calculation rules. A rule never makes a deadline authoritative:
    suggestions require human confirmation."""
    __tablename__ = "deadline_rules"
    id: Mapped[uuid.UUID] = pk()
    key: Mapped[str] = mapped_column(String(60), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    jurisdiction: Mapped[str] = mapped_column(String(60), nullable=False, default="england_and_wales")
    offset_days: Mapped[int] = mapped_column(Integer, nullable=False)
    day_type: Mapped[str] = mapped_column(String(10), nullable=False, default="business")  # business|calendar
    direction: Mapped[str] = mapped_column(String(8), nullable=False, default="after")  # after|before
    roll_convention: Mapped[str] = mapped_column(String(24), nullable=False, default="next_business_day")  # next_business_day|none
    description: Mapped[str | None] = mapped_column(Text)
    source_note: Mapped[str] = mapped_column(Text, nullable=False, default="Illustrative demonstration rule - verify against the governing rule or agreement.")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("firm_id", "key"),)


class Deadline(Base, TenantMixin, TimestampMixin):
    """A deadline is *authoritative* only when status='confirmed' with a confirming human (CHECK constraint)."""
    __tablename__ = "deadlines"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    due_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    due_time: Mapped[time | None] = mapped_column(Time)
    timezone: Mapped[str] = mapped_column(String(60), nullable=False, default="Europe/London")
    origin: Mapped[str] = mapped_column(String(24), nullable=False, default="manual")
    status: Mapped[str] = mapped_column(String(12), nullable=False, default="suggested")
    jurisdiction: Mapped[str | None] = mapped_column(String(60))
    rule_key: Mapped[str | None] = mapped_column(String(60))
    calendar_id: Mapped[uuid.UUID | None] = fk("business_calendars.id", nullable=True)
    trigger_date: Mapped[date | None] = mapped_column(Date)
    assumptions: Mapped[str | None] = mapped_column(Text)
    calculation: Mapped[dict] = jsonb()  # inputs + steps for calculated suggestions
    source_document_id: Mapped[uuid.UUID | None] = fk("documents.id", nullable=True)
    source_version_id: Mapped[uuid.UUID | None] = fk("document_versions.id", nullable=True)
    source_passage: Mapped[str | None] = mapped_column(Text)  # supporting passage for AI suggestions
    source_ref: Mapped[dict] = jsonb()  # {page, paragraph, version_no}
    agent_run_id: Mapped[uuid.UUID | None] = fk("agent_runs.id", nullable=True)
    suggested_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    reviewer_id: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    confirmed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str | None] = mapped_column(Text)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint("status in ('suggested','confirmed','rejected','met','missed')", name="status"),
        CheckConstraint("origin in ('manual','calculated_suggestion','ai_suggestion')", name="origin"),
        CheckConstraint("status not in ('confirmed','met','missed') or confirmed_by is not null", name="confirmed_needs_human"),
    )
