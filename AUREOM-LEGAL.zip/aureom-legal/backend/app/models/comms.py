from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Computed, DateTime, Index, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, TSVECTOR, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, pk


class Correspondence(Base, TenantMixin, TimestampMixin):
    """Emails/letters. Bodies are UNTRUSTED text: stored as plain text and rendered as text only.
    Internal comments live in `internal_notes`, never here."""
    __tablename__ = "correspondence"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    thread_id: Mapped[str | None] = mapped_column(String(80), index=True)
    direction: Mapped[str] = mapped_column(String(10), nullable=False)  # inbound|outbound
    channel: Mapped[str] = mapped_column(String(10), nullable=False, default="email")
    from_addr: Mapped[str] = mapped_column(String(254), nullable=False)
    to_addrs: Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)
    cc_addrs: Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)
    subject: Mapped[str] = mapped_column(String(500), nullable=False)
    body_text: Mapped[str] = mapped_column(Text, nullable=False)
    # received -> filed (inbound); draft -> pending_approval -> approved -> sent|failed (outbound)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="received")
    client_visible: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_read: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    filed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    created_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    approved_hash: Mapped[str | None] = mapped_column(String(64))
    agent_run_id: Mapped[uuid.UUID | None] = fk("agent_runs.id", nullable=True)
    external_ref: Mapped[str | None] = mapped_column(String(120))
    meta: Mapped[dict] = jsonb()
    tsv = mapped_column(TSVECTOR, Computed("to_tsvector('english', coalesce(subject,'') || ' ' || coalesce(body_text,''))", persisted=True))
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (Index("ix_correspondence_tsv", "tsv", postgresql_using="gin"),)


class CorrespondenceAttachment(Base, TenantMixin):
    __tablename__ = "correspondence_attachments"
    id: Mapped[uuid.UUID] = pk()
    correspondence_id: Mapped[uuid.UUID] = fk("correspondence.id", ondelete="CASCADE")
    document_id: Mapped[uuid.UUID | None] = fk("documents.id", nullable=True)  # set once filed to the DMS
    filename: Mapped[str] = mapped_column(String(300), nullable=False)
    content_type: Mapped[str] = mapped_column(String(100), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    storage_key: Mapped[str | None] = mapped_column(String(300))
    scan_status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")


class InternalNote(Base, TenantMixin, TimestampMixin):
    """Internal-only comments on a matter or an email. Never client-visible, never sent."""
    __tablename__ = "internal_notes"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    correspondence_id: Mapped[uuid.UUID | None] = fk("correspondence.id", nullable=True)
    document_id: Mapped[uuid.UUID | None] = fk("documents.id", nullable=True)
    author_id: Mapped[uuid.UUID] = fk("users.id")
    body: Mapped[str] = mapped_column(Text, nullable=False)
