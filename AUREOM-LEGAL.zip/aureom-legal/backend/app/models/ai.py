from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Computed, Date, DateTime, Index, Integer, Numeric, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, TSVECTOR, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, pk


class KnowledgeItem(Base, TenantMixin, TimestampMixin):
    """Approved internal precedents and practice materials. Firm-level (not matter-level)."""
    __tablename__ = "knowledge_items"
    id: Mapped[uuid.UUID] = pk()
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    kind: Mapped[str] = mapped_column(String(24), nullable=False, default="precedent")  # precedent|practice_note|policy|checklist
    practice_area: Mapped[str | None] = mapped_column(String(40))
    body: Mapped[str] = mapped_column(Text, nullable=False)
    source_ref: Mapped[str | None] = mapped_column(String(300))
    effective_date: Mapped[date] = mapped_column(Date, nullable=False)
    last_reviewed: Mapped[date | None] = mapped_column(Date)
    approved: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    approved_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    tsv = mapped_column(TSVECTOR, Computed("to_tsvector('english', coalesce(title,'') || ' ' || coalesce(body,''))", persisted=True))
    __table_args__ = (Index("ix_knowledge_tsv", "tsv", postgresql_using="gin"),)


class AgentRun(Base, TenantMixin, TimestampMixin):
    __tablename__ = "agent_runs"
    id: Mapped[uuid.UUID] = pk()
    requested_by: Mapped[uuid.UUID] = fk("users.id")
    agent_type: Mapped[str] = mapped_column(String(30), nullable=False, index=True)
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    scope: Mapped[dict] = jsonb()  # {matter_id, document_ids, ...}
    input: Mapped[dict] = jsonb()
    provider: Mapped[str] = mapped_column(String(30), nullable=False, default="mock")
    model: Mapped[str] = mapped_column(String(80), nullable=False)
    prompt_template_version: Mapped[str] = mapped_column(String(40), nullable=False)
    source_versions: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # [{type,id,version_id,version_no}]
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="queued", index=True)
    approval_state: Mapped[str] = mapped_column(String(16), nullable=False, default="not_required")  # not_required|pending|approved|rejected|partial
    result: Mapped[dict | None] = mapped_column(JSONB)  # structured: facts / inferences / recommendations / missing / contradictions / citations
    execution_result: Mapped[dict | None] = mapped_column(JSONB)
    error: Mapped[str | None] = mapped_column(Text)
    tokens_in: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    tokens_out: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    cost_gbp: Mapped[Decimal] = mapped_column(Numeric(10, 4), nullable=False, default=Decimal("0"))
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=2)
    timeout_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=120)
    cancel_requested: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(160))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint(
            "status in ('queued','running','awaiting_review','approved','rejected','executing','completed','failed','cancelled')",
            name="status",
        ),
        Index("uq_agent_runs_idem", "firm_id", "requested_by", "idempotency_key", unique=True, postgresql_where="idempotency_key is not null"),
    )


class AgentProposedAction(Base, TenantMixin, TimestampMixin):
    """A proposed change. Approval binds to approved_hash = sha256(canonical(action_type, params, matter_id));
    editing params after approval clears the approval and requires renewed approval."""
    __tablename__ = "agent_proposed_actions"
    id: Mapped[uuid.UUID] = pk()
    run_id: Mapped[uuid.UUID] = fk("agent_runs.id", ondelete="CASCADE")
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    action_type: Mapped[str] = mapped_column(String(40), nullable=False)
    summary: Mapped[str] = mapped_column(String(400), nullable=False)
    params: Mapped[dict] = jsonb()
    params_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    evidence: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # citations supporting the proposal
    risk: Mapped[str] = mapped_column(String(8), nullable=False, default="medium")
    status: Mapped[str] = mapped_column(String(12), nullable=False, default="proposed")
    approved_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approved_hash: Mapped[str | None] = mapped_column(String(64))
    decision_note: Mapped[str | None] = mapped_column(Text)
    executed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    execution_key: Mapped[str] = mapped_column(String(80), nullable=False, default=lambda: uuid.uuid4().hex)
    result: Mapped[dict | None] = mapped_column(JSONB)
    error: Mapped[str | None] = mapped_column(Text)
    edit_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    edit_history: Mapped[list | None] = mapped_column(JSONB, nullable=True, default=list)  # human corrections: before/after params
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (UniqueConstraint("execution_key"),)


class AgentRunEvent(Base, TenantMixin):
    """Execution evidence & action summaries (retrievals, tool calls, policy denials, human corrections).
    Deliberately does NOT store model reasoning."""
    __tablename__ = "agent_run_events"
    id: Mapped[uuid.UUID] = pk()
    run_id: Mapped[uuid.UUID] = fk("agent_runs.id", ondelete="CASCADE")
    kind: Mapped[str] = mapped_column(String(30), nullable=False)  # state_change|retrieval|tool_call|policy_denied|injection_flag|human_edit|human_decision|execution|budget
    summary: Mapped[str] = mapped_column(String(500), nullable=False)
    details: Mapped[dict] = jsonb()
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
