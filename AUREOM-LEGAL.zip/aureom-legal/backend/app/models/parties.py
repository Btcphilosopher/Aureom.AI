from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, pk


class Contact(Base, TenantMixin, TimestampMixin):
    """An individual or organisation. A contact becomes a *client* only via a matter party role;
    `is_client` / `client_ref` mark contacts that have been given a client reference."""
    __tablename__ = "contacts"
    id: Mapped[uuid.UUID] = pk()
    kind: Mapped[str] = mapped_column(String(16), nullable=False)
    display_name: Mapped[str] = mapped_column(String(240), nullable=False, index=True)
    title: Mapped[str | None] = mapped_column(String(20))
    first_name: Mapped[str | None] = mapped_column(String(100))
    last_name: Mapped[str | None] = mapped_column(String(100))
    date_of_birth: Mapped[date | None] = mapped_column(Date)
    org_name: Mapped[str | None] = mapped_column(String(240))
    company_number: Mapped[str | None] = mapped_column(String(20))
    email: Mapped[str | None] = mapped_column(String(254))
    phone: Mapped[str | None] = mapped_column(String(40))
    preferred_channel: Mapped[str] = mapped_column(String(16), nullable=False, default="email")
    aliases: Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)
    client_ref: Mapped[str | None] = mapped_column(String(30))
    is_client: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="prospect")  # prospect|active|inactive|merged
    responsible_user_id: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    office_id: Mapped[uuid.UUID | None] = fk("offices.id", nullable=True)
    notes: Mapped[str | None] = mapped_column(Text)
    merged_into_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    meta: Mapped[dict] = jsonb()
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint("kind in ('individual','organisation')", name="kind"),
        Index("uq_contacts_client_ref", "firm_id", "client_ref", unique=True, postgresql_where="client_ref is not null"),
    )


class ContactAddress(Base, TenantMixin):
    __tablename__ = "contact_addresses"
    id: Mapped[uuid.UUID] = pk()
    contact_id: Mapped[uuid.UUID] = fk("contacts.id", ondelete="CASCADE")
    kind: Mapped[str] = mapped_column(String(20), nullable=False, default="correspondence")  # registered|residential|correspondence|trading
    line1: Mapped[str] = mapped_column(String(200), nullable=False)
    line2: Mapped[str | None] = mapped_column(String(200))
    city: Mapped[str | None] = mapped_column(String(100))
    county: Mapped[str | None] = mapped_column(String(100))
    postcode: Mapped[str | None] = mapped_column(String(20))
    country: Mapped[str] = mapped_column(String(80), nullable=False, default="United Kingdom")
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


class ContactRelationship(Base, TenantMixin, TimestampMixin):
    __tablename__ = "contact_relationships"
    id: Mapped[uuid.UUID] = pk()
    from_contact_id: Mapped[uuid.UUID] = fk("contacts.id")
    to_contact_id: Mapped[uuid.UUID] = fk("contacts.id")
    relation_type: Mapped[str] = mapped_column(String(40), nullable=False)  # director_of, shareholder_of, spouse_of, subsidiary_of, employee_of, trustee_of, associate_of
    start_date: Mapped[date | None] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date)
    notes: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (CheckConstraint("from_contact_id <> to_contact_id", name="no_self"),)


class OnboardingRecord(Base, TenantMixin, TimestampMixin):
    __tablename__ = "onboarding_records"
    id: Mapped[uuid.UUID] = pk()
    contact_id: Mapped[uuid.UUID] = fk("contacts.id")
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="not_started")
    risk_level: Mapped[str | None] = mapped_column(String(16))  # low|medium|high (human-assigned)
    submitted_form: Mapped[dict] = jsonb()  # raw intake form (untrusted)
    notes: Mapped[str | None] = mapped_column(Text)
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class OnboardingCheck(Base, TenantMixin, TimestampMixin):
    __tablename__ = "onboarding_checks"
    id: Mapped[uuid.UUID] = pk()
    onboarding_id: Mapped[uuid.UUID] = fk("onboarding_records.id", ondelete="CASCADE")
    check_type: Mapped[str] = mapped_column(String(40), nullable=False)  # configurable in firm settings
    provider: Mapped[str] = mapped_column(String(60), nullable=False, default="simulated-identity")
    is_simulated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="not_started")
    result_summary: Mapped[str | None] = mapped_column(Text)
    external_ref: Mapped[str | None] = mapped_column(String(80))
    performed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    performed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (UniqueConstraint("onboarding_id", "check_type"),)


class ConflictSearch(Base, TenantMixin, TimestampMixin):
    __tablename__ = "conflict_searches"
    id: Mapped[uuid.UUID] = pk()
    subject_contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    terms: Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)
    requested_by: Mapped[uuid.UUID] = fk("users.id")
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="pending_review")
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str | None] = mapped_column(Text)
    match_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class ConflictMatch(Base, TenantMixin):
    __tablename__ = "conflict_matches"
    id: Mapped[uuid.UUID] = pk()
    search_id: Mapped[uuid.UUID] = fk("conflict_searches.id", ondelete="CASCADE")
    matched_contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    matched_matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    searched_term: Mapped[str] = mapped_column(String(240), nullable=False)
    match_type: Mapped[str] = mapped_column(String(30), nullable=False)  # name_exact|name_fuzzy|alias|organisation|relationship
    score: Mapped[float] = mapped_column(Float, nullable=False)
    evidence: Mapped[dict] = jsonb()  # supporting records (ids + human readable labels)
    disposition: Mapped[str] = mapped_column(String(24), nullable=False, default="unreviewed")
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    note: Mapped[str | None] = mapped_column(Text)


class ConflictReviewEvent(Base, TenantMixin):
    """Append-only history of every conflict review decision."""
    __tablename__ = "conflict_review_events"
    id: Mapped[uuid.UUID] = pk()
    search_id: Mapped[uuid.UUID] = fk("conflict_searches.id")
    match_id: Mapped[uuid.UUID | None] = fk("conflict_matches.id", nullable=True)
    actor_id: Mapped[uuid.UUID] = fk("users.id")
    event: Mapped[str] = mapped_column(String(40), nullable=False)  # match_disposition|search_decision|search_created
    from_value: Mapped[str | None] = mapped_column(String(40))
    to_value: Mapped[str | None] = mapped_column(String(40))
    note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class ContactMerge(Base, TenantMixin):
    __tablename__ = "contact_merges"
    id: Mapped[uuid.UUID] = pk()
    survivor_id: Mapped[uuid.UUID] = fk("contacts.id")
    merged_id: Mapped[uuid.UUID] = fk("contacts.id")
    requested_by: Mapped[uuid.UUID] = fk("users.id")
    reviewed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")  # pending|completed|rejected
    field_choices: Mapped[dict] = jsonb()
    repointed: Mapped[dict] = jsonb()  # counts of references moved, per table
    snapshot: Mapped[dict] = jsonb()  # full snapshot of merged contact before merge
    reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
