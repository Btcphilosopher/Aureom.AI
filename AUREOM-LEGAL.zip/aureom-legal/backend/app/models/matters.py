from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, money, pk


class MatterTemplate(Base, TenantMixin, TimestampMixin):
    __tablename__ = "matter_templates"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    practice_area: Mapped[str] = mapped_column(String(40), nullable=False)
    matter_type: Mapped[str] = mapped_column(String(80), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    stages: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # [{key,name}]
    opening_checklist: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # [{label,required}]
    closing_checklist: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    required_fields: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # field keys that must be set to open
    default_fee_arrangement: Mapped[str] = mapped_column(String(16), nullable=False, default="hourly")
    default_retention_key: Mapped[str | None] = mapped_column(String(60))
    default_tasks: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # [{title, due_in_days}]
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("firm_id", "name"),)


class Matter(Base, TenantMixin, TimestampMixin):
    __tablename__ = "matters"
    id: Mapped[uuid.UUID] = pk()
    reference: Mapped[str] = mapped_column(String(40), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    matter_type: Mapped[str] = mapped_column(String(80), nullable=False)
    practice_area: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text)
    client_id: Mapped[uuid.UUID] = fk("contacts.id")
    office_id: Mapped[uuid.UUID] = fk("offices.id")
    team_id: Mapped[uuid.UUID | None] = fk("teams.id", nullable=True)
    responsible_partner_id: Mapped[uuid.UUID] = fk("users.id")
    fee_earner_id: Mapped[uuid.UUID] = fk("users.id")
    jurisdiction: Mapped[str] = mapped_column(String(60), nullable=False, default="england_and_wales")
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="prospective", index=True)
    stage: Mapped[str | None] = mapped_column(String(60))
    opened_at: Mapped[date | None] = mapped_column(Date)
    target_date: Mapped[date | None] = mapped_column(Date)
    closed_at: Mapped[date | None] = mapped_column(Date)
    template_id: Mapped[uuid.UUID | None] = fk("matter_templates.id", nullable=True)
    # access control
    access_level: Mapped[str] = mapped_column(String(16), nullable=False, default="standard")  # standard|restricted
    ethical_wall: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    exports_allowed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    ai_retrieval_allowed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    # finance
    fee_arrangement: Mapped[str] = mapped_column(String(16), nullable=False, default="hourly")
    fixed_fee_amount: Mapped[Decimal | None] = money(nullable=True)
    budget_amount: Mapped[Decimal | None] = money(nullable=True)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    rate_card_id: Mapped[uuid.UUID | None] = fk("rate_cards.id", nullable=True)
    # retention
    retention_policy_key: Mapped[str | None] = mapped_column(String(60))
    retention_until: Mapped[date | None] = mapped_column(Date)
    legal_hold: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    legal_hold_reason: Mapped[str | None] = mapped_column(Text)
    conflict_search_id: Mapped[uuid.UUID | None] = fk("conflict_searches.id", nullable=True, use_alter=True)
    custom_fields: Mapped[dict] = jsonb()
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        UniqueConstraint("firm_id", "reference"),
        CheckConstraint("status in ('prospective','open','paused','closed')", name="status"),
        CheckConstraint("access_level in ('standard','restricted')", name="access_level"),
    )


class MatterParty(Base, TenantMixin, TimestampMixin):
    """A contact can hold different roles on different matters (and several roles on one)."""
    __tablename__ = "matter_parties"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id", ondelete="CASCADE")
    contact_id: Mapped[uuid.UUID] = fk("contacts.id")
    role: Mapped[str] = mapped_column(String(30), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (UniqueConstraint("matter_id", "contact_id", "role"),)


class MatterMember(Base, TenantMixin, TimestampMixin):
    """Access list. access='allow' grants a user access to a restricted matter; access='deny' is an
    ethical-wall exclusion (user or whole team) and always wins."""
    __tablename__ = "matter_members"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id", ondelete="CASCADE")
    user_id: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    team_id: Mapped[uuid.UUID | None] = fk("teams.id", nullable=True)
    access: Mapped[str] = mapped_column(String(8), nullable=False, default="allow")
    member_role: Mapped[str | None] = mapped_column(String(40))  # lead|team|finance|supervisor...
    reason: Mapped[str | None] = mapped_column(Text)
    added_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    __table_args__ = (
        CheckConstraint("access in ('allow','deny')", name="access"),
        CheckConstraint("(user_id is not null) <> (team_id is not null)", name="one_subject"),
        CheckConstraint("access = 'deny' or team_id is null", name="allow_user_only"),
    )


class MatterStateEvent(Base, TenantMixin):
    __tablename__ = "matter_state_events"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    from_status: Mapped[str | None] = mapped_column(String(16))
    to_status: Mapped[str] = mapped_column(String(16), nullable=False)
    actor_id: Mapped[uuid.UUID] = fk("users.id")
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class MatterChecklistItem(Base, TenantMixin, TimestampMixin):
    __tablename__ = "matter_checklist_items"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id", ondelete="CASCADE")
    phase: Mapped[str] = mapped_column(String(10), nullable=False)  # opening|closing
    label: Mapped[str] = mapped_column(String(300), nullable=False)
    required: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    position: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    note: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (CheckConstraint("phase in ('opening','closing')", name="phase"),)


class ChronologyEntry(Base, TenantMixin, TimestampMixin):
    """Editable matter chronology. Distinguishes explicit dates (stated in a source) from inferred ones."""
    __tablename__ = "chronology_entries"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id", ondelete="CASCADE")
    event_date: Mapped[date | None] = mapped_column(Date)
    date_text: Mapped[str | None] = mapped_column(String(120))  # the date as written in the source
    date_basis: Mapped[str] = mapped_column(String(12), nullable=False, default="explicit")  # explicit|inferred
    description: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[dict] = jsonb()  # {type, id, version_id, version_no, page, paragraph, quote}
    origin: Mapped[str] = mapped_column(String(12), nullable=False, default="manual")  # manual|agent
    agent_run_id: Mapped[uuid.UUID | None] = fk("agent_runs.id", nullable=True)
    status: Mapped[str] = mapped_column(String(12), nullable=False, default="accepted")  # accepted|edited|rejected
    created_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    edited_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
