from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Computed, Date, DateTime, Index, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, TSVECTOR, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, pk


class Folder(Base, TenantMixin, TimestampMixin):
    __tablename__ = "document_folders"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    parent_id: Mapped[uuid.UUID | None] = fk("document_folders.id", nullable=True)
    name: Mapped[str] = mapped_column(String(160), nullable=False)


class Document(Base, TenantMixin, TimestampMixin):
    __tablename__ = "documents"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)  # onboarding / client-level documents
    folder_id: Mapped[uuid.UUID | None] = fk("document_folders.id", nullable=True)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    doc_type: Mapped[str] = mapped_column(String(60), nullable=False, default="other")
    tags: Mapped[list] = mapped_column(ARRAY(String), nullable=False, default=list)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="draft")
    current_version_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    current_version_no: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    client_visible: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    legal_hold: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    retention_until: Mapped[date | None] = mapped_column(Date)
    created_by: Mapped[uuid.UUID] = fk("users.id")
    source: Mapped[str] = mapped_column(String(30), nullable=False, default="upload")  # upload|template|email_attachment|agent_draft|seed
    meta: Mapped[dict] = jsonb()
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (CheckConstraint("matter_id is not null or contact_id is not null", name="has_owner"),)


class DocumentVersion(Base, TenantMixin):
    """Immutable original file record. Storage key, hash, size and authorship cannot change once written
    (enforced by trigger); only scan/OCR/extraction status columns may be updated by the worker."""
    __tablename__ = "document_versions"
    id: Mapped[uuid.UUID] = pk()
    document_id: Mapped[uuid.UUID] = fk("documents.id")
    version_no: Mapped[int] = mapped_column(Integer, nullable=False)
    storage_key: Mapped[str] = mapped_column(String(300), nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    content_type: Mapped[str] = mapped_column(String(100), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(300), nullable=False)
    author_id: Mapped[uuid.UUID] = fk("users.id")
    change_note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    # mutable worker-owned state
    scan_status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")  # pending|clean|infected|unavailable|error
    scan_detail: Mapped[str | None] = mapped_column(String(300))
    ocr_status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")  # pending|not_needed|done|simulated|failed
    index_status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")
    page_count: Mapped[int | None] = mapped_column(Integer)
    __table_args__ = (UniqueConstraint("document_id", "version_no"),)


class DocumentChunk(Base, TenantMixin):
    """Extracted text split into page/paragraph units. Used for full-text search and for AI citations
    (document version + page + paragraph). Confidential: never logged."""
    __tablename__ = "document_chunks"
    id: Mapped[uuid.UUID] = pk()
    version_id: Mapped[uuid.UUID] = fk("document_versions.id", ondelete="CASCADE")
    document_id: Mapped[uuid.UUID] = fk("documents.id")
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    ordinal: Mapped[int] = mapped_column(Integer, nullable=False)
    page: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    paragraph: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    is_ocr: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    tsv = mapped_column(TSVECTOR, Computed("to_tsvector('english', text)", persisted=True))
    __table_args__ = (
        UniqueConstraint("version_id", "ordinal"),
        Index("ix_document_chunks_tsv", "tsv", postgresql_using="gin"),
    )


class DocumentTemplate(Base, TenantMixin, TimestampMixin):
    __tablename__ = "document_templates"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    doc_type: Mapped[str] = mapped_column(String(60), nullable=False, default="letter")
    practice_area: Mapped[str | None] = mapped_column(String(40))
    body: Mapped[str] = mapped_column(Text, nullable=False)  # {{placeholders}}
    fields: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # [{key,label,source,required}]
    approved: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    approved_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    template_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __table_args__ = (UniqueConstraint("firm_id", "name"),)


class SignatureRequest(Base, TenantMixin, TimestampMixin):
    __tablename__ = "signature_requests"
    id: Mapped[uuid.UUID] = pk()
    document_id: Mapped[uuid.UUID] = fk("documents.id")
    version_id: Mapped[uuid.UUID] = fk("document_versions.id")
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    provider: Mapped[str] = mapped_column(String(60), nullable=False)
    is_simulated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    external_ref: Mapped[str | None] = mapped_column(String(80))
    signers: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)  # [{name,email,status,signed_at}]
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="sent")  # sent|signed|declined|cancelled
    requested_by: Mapped[uuid.UUID] = fk("users.id")
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)


class ExportRequest(Base, TenantMixin, TimestampMixin):
    """Controlled export of matter documents. Generated asynchronously; download is time-limited and audited."""
    __tablename__ = "export_requests"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    requested_by: Mapped[uuid.UUID] = fk("users.id")
    document_ids: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending_approval")  # pending_approval|approved|rejected|building|ready|failed|expired
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    storage_key: Mapped[str | None] = mapped_column(String(300))
    sha256: Mapped[str | None] = mapped_column(String(64))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    download_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    error: Mapped[str | None] = mapped_column(Text)
