from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import BigInteger, Boolean, Date, DateTime, ForeignKey, Identity, Integer, String, Text, UniqueConstraint, func, Index, CheckConstraint
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, pk


class Firm(Base, TimestampMixin):
    __tablename__ = "firms"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    slug: Mapped[str] = mapped_column(String(80), nullable=False, unique=True)
    data_residency: Mapped[str] = mapped_column(String(20), nullable=False, default="uk")
    # configurable: onboarding_check_types, onboarding_statuses, ai policy, budgets, auto_complete_readonly ...
    settings: Mapped[dict] = jsonb()


class Office(Base, TenantMixin, TimestampMixin):
    __tablename__ = "offices"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    city: Mapped[str] = mapped_column(String(80), nullable=False)
    address: Mapped[str | None] = mapped_column(Text)
    timezone: Mapped[str] = mapped_column(String(60), nullable=False, default="Europe/London")
    __table_args__ = (UniqueConstraint("firm_id", "name"),)


class Team(Base, TenantMixin, TimestampMixin):
    __tablename__ = "teams"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    practice_area: Mapped[str | None] = mapped_column(String(40))
    office_id: Mapped[uuid.UUID | None] = fk("offices.id", nullable=True)
    __table_args__ = (UniqueConstraint("firm_id", "name"),)


class Role(Base, TenantMixin, TimestampMixin):
    __tablename__ = "roles"
    id: Mapped[uuid.UUID] = pk()
    key: Mapped[str] = mapped_column(String(40), nullable=False)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    permissions: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    is_system: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("firm_id", "key"),)


class User(Base, TenantMixin, TimestampMixin):
    """Staff and authorised-client users. Auth tables are exempt from RLS (login precedes tenant binding)."""
    __tablename__ = "users"
    id: Mapped[uuid.UUID] = pk()
    email: Mapped[str] = mapped_column(String(254), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    initials: Mapped[str] = mapped_column(String(6), nullable=False)
    job_title: Mapped[str | None] = mapped_column(String(120))
    password_hash: Mapped[str | None] = mapped_column(String(300))
    role_id: Mapped[uuid.UUID] = fk("roles.id")
    office_id: Mapped[uuid.UUID | None] = fk("offices.id", nullable=True)
    team_id: Mapped[uuid.UUID | None] = fk("teams.id", nullable=True)
    contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True, use_alter=True)  # for authorised-client users
    grade: Mapped[str | None] = mapped_column(String(40))  # partner/solicitor/paralegal... for rate cards
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    sso_subject: Mapped[str | None] = mapped_column(String(200))
    failed_logins: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    prefs: Mapped[dict] = jsonb()
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}


class UserSession(Base):
    __tablename__ = "sessions"
    id: Mapped[uuid.UUID] = pk()
    user_id: Mapped[uuid.UUID] = fk("users.id")
    firm_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("firms.id"), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)  # sha256 of opaque token
    csrf_token: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ip: Mapped[str | None] = mapped_column(String(64))
    user_agent: Mapped[str | None] = mapped_column(String(300))
    active_office_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)


class AuditEvent(Base):
    """Append-only, hash-chained. UPDATE/DELETE/TRUNCATE are blocked by DB triggers."""
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(BigInteger, Identity(always=True), primary_key=True)
    firm_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("firms.id"), nullable=False, index=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    actor_type: Mapped[str] = mapped_column(String(16), nullable=False, default="user")  # user|agent|system
    action: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    entity_type: Mapped[str] = mapped_column(String(60), nullable=False)
    entity_id: Mapped[str | None] = mapped_column(String(64))
    matter_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    summary: Mapped[str] = mapped_column(String(500), nullable=False)
    details: Mapped[dict] = jsonb()  # never contains confidential document/email text
    ip: Mapped[str | None] = mapped_column(String(64))
    prev_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    hash: Mapped[str] = mapped_column(String(64), nullable=False)
    __table_args__ = (Index("ix_audit_entity", "entity_type", "entity_id"),)


class Approval(Base, TenantMixin, TimestampMixin):
    """Generic approval bound to the exact payload via payload_hash."""
    __tablename__ = "approvals"
    id: Mapped[uuid.UUID] = pk()
    kind: Mapped[str] = mapped_column(String(60), nullable=False, index=True)
    subject_type: Mapped[str] = mapped_column(String(60), nullable=False)
    subject_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    requested_by: Mapped[uuid.UUID] = fk("users.id")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")  # pending|approved|rejected|superseded|cancelled
    payload_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[dict] = jsonb()  # summary of what is approved (no confidential text)
    required_permission: Mapped[str | None] = mapped_column(String(60))
    decided_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    decision_note: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (CheckConstraint("status in ('pending','approved','rejected','superseded','cancelled')", name="status"),)


class Job(Base):
    """PostgreSQL-backed job queue for OCR, indexing, scanning, exports and agent runs."""
    __tablename__ = "jobs"
    id: Mapped[uuid.UUID] = pk()
    firm_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("firms.id"), nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    payload: Mapped[dict] = jsonb()
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="queued", index=True)  # queued|running|done|failed|cancelled
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    run_after: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    locked_by: Mapped[str | None] = mapped_column(String(80))
    last_error: Mapped[str | None] = mapped_column(Text)
    result: Mapped[dict | None] = mapped_column(JSONB)
    idempotency_key: Mapped[str | None] = mapped_column(String(160))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (Index("uq_jobs_idem", "firm_id", "idempotency_key", unique=True, postgresql_where="idempotency_key is not null"),)


class Notification(Base, TenantMixin):
    __tablename__ = "notifications"
    id: Mapped[uuid.UUID] = pk()
    user_id: Mapped[uuid.UUID] = fk("users.id")
    kind: Mapped[str] = mapped_column(String(40), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    body: Mapped[str | None] = mapped_column(Text)
    link: Mapped[str | None] = mapped_column(String(300))
    matter_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    read_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class RetentionPolicy(Base, TenantMixin, TimestampMixin):
    __tablename__ = "retention_policies"
    id: Mapped[uuid.UUID] = pk()
    key: Mapped[str] = mapped_column(String(60), nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    years: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    action_at_expiry: Mapped[str] = mapped_column(String(40), nullable=False, default="review")  # review|destroy_after_review
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("firm_id", "key"),)


class BusinessCalendar(Base, TenantMixin, TimestampMixin):
    __tablename__ = "business_calendars"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    jurisdiction: Mapped[str] = mapped_column(String(60), nullable=False)  # e.g. england_and_wales
    timezone: Mapped[str] = mapped_column(String(60), nullable=False, default="Europe/London")
    weekend_days: Mapped[list] = mapped_column(JSONB, nullable=False, default=lambda: [5, 6])  # Mon=0
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    source_note: Mapped[str | None] = mapped_column(Text)  # where holiday data came from / who loaded it
    __table_args__ = (UniqueConstraint("firm_id", "name"),)


class CalendarHoliday(Base, TenantMixin):
    __tablename__ = "calendar_holidays"
    id: Mapped[uuid.UUID] = pk()
    calendar_id: Mapped[uuid.UUID] = fk("business_calendars.id", ondelete="CASCADE")
    holiday_date: Mapped[date] = mapped_column(Date, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    __table_args__ = (UniqueConstraint("calendar_id", "holiday_date"),)


class IntegrationEvent(Base, TenantMixin):
    """Log of calls to (mock or real) integration providers - e.g. simulated outbound email."""
    __tablename__ = "integration_events"
    id: Mapped[uuid.UUID] = pk()
    integration: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    provider: Mapped[str] = mapped_column(String(60), nullable=False)
    mode: Mapped[str] = mapped_column(String(20), nullable=False, default="mock")
    kind: Mapped[str] = mapped_column(String(60), nullable=False)
    payload: Mapped[dict] = jsonb()
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="ok")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
