from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TenantMixin, TimestampMixin, fk, jsonb, money, pk


class RateCard(Base, TenantMixin, TimestampMixin):
    __tablename__ = "rate_cards"
    id: Mapped[uuid.UUID] = pk()
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("firm_id", "name"),)


class RateCardEntry(Base, TenantMixin):
    __tablename__ = "rate_card_entries"
    id: Mapped[uuid.UUID] = pk()
    rate_card_id: Mapped[uuid.UUID] = fk("rate_cards.id", ondelete="CASCADE")
    grade: Mapped[str] = mapped_column(String(40), nullable=False)
    user_id: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)  # optional named override
    hourly_rate: Mapped[Decimal] = money()
    __table_args__ = (CheckConstraint("hourly_rate >= 0", name="rate_nonneg"),)


class TimeEntry(Base, TenantMixin, TimestampMixin):
    __tablename__ = "time_entries"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    user_id: Mapped[uuid.UUID] = fk("users.id")
    work_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    minutes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    narrative: Mapped[str] = mapped_column(Text, nullable=False, default="")
    rate: Mapped[Decimal] = money()
    amount: Mapped[Decimal] = money()  # = minutes/60 * rate, rounded half-up (computed in service, verified by CHECK of non-negativity)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    billable: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    status: Mapped[str] = mapped_column(String(12), nullable=False, default="draft")  # draft|submitted|approved|billed|written_off
    timer_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # running timer if set
    source: Mapped[str] = mapped_column(String(16), nullable=False, default="manual")  # manual|timer|agent_suggestion
    agent_run_id: Mapped[uuid.UUID | None] = fk("agent_runs.id", nullable=True)
    invoice_line_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint("minutes >= 0", name="minutes_nonneg"),
        CheckConstraint("amount >= 0", name="amount_nonneg"),
        # at most one running timer per user (concurrency-safe)
        Index("uq_time_one_running_timer", "firm_id", "user_id", unique=True, postgresql_where="timer_started_at is not null"),
    )


class Expense(Base, TenantMixin, TimestampMixin):
    __tablename__ = "expenses"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    user_id: Mapped[uuid.UUID] = fk("users.id")
    expense_date: Mapped[date] = mapped_column(Date, nullable=False)
    description: Mapped[str] = mapped_column(String(300), nullable=False)
    amount: Mapped[Decimal] = money()  # net
    vat_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2), nullable=False, default=Decimal("0"))
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    billable: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    status: Mapped[str] = mapped_column(String(12), nullable=False, default="draft")  # draft|approved|billed|written_off
    receipt_document_id: Mapped[uuid.UUID | None] = fk("documents.id", nullable=True)
    invoice_line_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (CheckConstraint("amount >= 0", name="amount_nonneg"),)


class Invoice(Base, TenantMixin, TimestampMixin):
    """kind='invoice' or 'credit_note'. A credit note references the invoice it credits and carries positive
    amounts that reduce the receivable. Number is assigned only when issued."""
    __tablename__ = "invoices"
    id: Mapped[uuid.UUID] = pk()
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    client_id: Mapped[uuid.UUID] = fk("contacts.id")
    payer_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    kind: Mapped[str] = mapped_column(String(12), nullable=False, default="invoice")
    credit_for_invoice_id: Mapped[uuid.UUID | None] = fk("invoices.id", nullable=True)
    number: Mapped[str | None] = mapped_column(String(30))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft")
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    subtotal: Mapped[Decimal] = money(default=Decimal("0"))
    vat_amount: Mapped[Decimal] = money(default=Decimal("0"))
    total: Mapped[Decimal] = money(default=Decimal("0"))
    amount_paid: Mapped[Decimal] = money(default=Decimal("0"))  # sum of allocations (maintained transactionally)
    issued_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    issued_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    due_date: Mapped[date | None] = mapped_column(Date)
    narrative: Mapped[str | None] = mapped_column(Text)
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    approved_hash: Mapped[str | None] = mapped_column(String(64))
    issue_journal_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    created_by: Mapped[uuid.UUID] = fk("users.id")
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint("kind in ('invoice','credit_note')", name="kind"),
        CheckConstraint("status in ('draft','pending_approval','issued','partially_paid','paid','void')", name="status"),
        CheckConstraint("amount_paid >= 0 and amount_paid <= total", name="paid_within_total"),
        Index("uq_invoices_number", "firm_id", "number", unique=True, postgresql_where="number is not null"),
    )


class InvoiceLine(Base, TenantMixin):
    __tablename__ = "invoice_lines"
    id: Mapped[uuid.UUID] = pk()
    invoice_id: Mapped[uuid.UUID] = fk("invoices.id", ondelete="CASCADE")
    line_type: Mapped[str] = mapped_column(String(12), nullable=False)  # time|expense|fixed|adjustment
    description: Mapped[str] = mapped_column(Text, nullable=False)
    quantity: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False, default=Decimal("1"))
    unit_amount: Mapped[Decimal] = money()
    amount: Mapped[Decimal] = money()
    vat_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2), nullable=False, default=Decimal("20"))
    vat_amount: Mapped[Decimal] = money()
    time_entry_id: Mapped[uuid.UUID | None] = fk("time_entries.id", nullable=True)
    expense_id: Mapped[uuid.UUID | None] = fk("expenses.id", nullable=True)


class LedgerAccount(Base, TenantMixin, TimestampMixin):
    __tablename__ = "ledger_accounts"
    id: Mapped[uuid.UUID] = pk()
    ledger: Mapped[str] = mapped_column(String(8), nullable=False)  # office|client  (separate ledgers)
    code: Mapped[str] = mapped_column(String(30), nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    account_type: Mapped[str] = mapped_column(String(12), nullable=False)  # asset|liability|income|expense|equity
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    is_bank: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    system_key: Mapped[str | None] = mapped_column(String(40))  # debtors|unallocated_receipts|fees_billed_unrecognised|fee_income|vat_output|bank_office|bank_client|client_funds_control
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)  # client-ledger matter account
    contact_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    __table_args__ = (
        UniqueConstraint("firm_id", "ledger", "code"),
        CheckConstraint("ledger in ('office','client')", name="ledger"),
        CheckConstraint("account_type in ('asset','liability','income','expense','equity')", name="type"),
    )


class Journal(Base, TenantMixin, TimestampMixin):
    """Double-entry journal within ONE ledger. Posting requires balanced lines (DB trigger + service) and an
    explicit human authorisation (approval)."""
    __tablename__ = "journals"
    id: Mapped[uuid.UUID] = pk()
    ledger: Mapped[str] = mapped_column(String(8), nullable=False)
    reference: Mapped[str] = mapped_column(String(60), nullable=False)
    description: Mapped[str] = mapped_column(String(400), nullable=False)
    effective_date: Mapped[date] = mapped_column(Date, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="draft")
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    source_type: Mapped[str | None] = mapped_column(String(40))  # invoice_issue|receipt|allocation|revenue_recognition|client_transfer|manual
    source_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    prepared_by: Mapped[uuid.UUID] = fk("users.id")
    posted_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    posted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    reverses_journal_id: Mapped[uuid.UUID | None] = fk("journals.id", nullable=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint("ledger in ('office','client')", name="ledger"),
        CheckConstraint("status in ('draft','pending_approval','posted','reversed')", name="status"),
        CheckConstraint("status not in ('posted','reversed') or (posted_by is not null and posted_at is not null)", name="posted_has_poster"),
    )


class JournalLine(Base, TenantMixin):
    __tablename__ = "journal_lines"
    id: Mapped[uuid.UUID] = pk()
    journal_id: Mapped[uuid.UUID] = fk("journals.id", ondelete="CASCADE")
    account_id: Mapped[uuid.UUID] = fk("ledger_accounts.id")
    debit: Mapped[Decimal] = money(default=Decimal("0"))
    credit: Mapped[Decimal] = money(default=Decimal("0"))
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    narrative: Mapped[str | None] = mapped_column(String(300))
    reconciled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reconciliation_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    __table_args__ = (
        CheckConstraint("debit >= 0 and credit >= 0 and (debit = 0 or credit = 0) and (debit + credit) > 0", name="one_sided_positive"),
    )


class BankStatementLine(Base, TenantMixin, TimestampMixin):
    """Imported (synthetic) bank statement line. Receipt of funds is NOT revenue."""
    __tablename__ = "bank_statement_lines"
    id: Mapped[uuid.UUID] = pk()
    bank_account_id: Mapped[uuid.UUID] = fk("ledger_accounts.id")
    ledger: Mapped[str] = mapped_column(String(8), nullable=False)
    txn_date: Mapped[date] = mapped_column(Date, nullable=False)
    description: Mapped[str] = mapped_column(String(300), nullable=False)
    reference: Mapped[str | None] = mapped_column(String(80))
    amount: Mapped[Decimal] = money()  # signed: + money in, - money out
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    external_id: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[str] = mapped_column(String(12), nullable=False, default="unmatched")  # unmatched|matched|reconciled
    matched_journal_line_id: Mapped[uuid.UUID | None] = fk("journal_lines.id", nullable=True)
    payment_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    reconciliation_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    __table_args__ = (UniqueConstraint("firm_id", "external_id"),)


class Payment(Base, TenantMixin, TimestampMixin):
    """A receipt recorded against a bank line. Lifecycle: received_unallocated -> partially_allocated -> allocated."""
    __tablename__ = "payments"
    id: Mapped[uuid.UUID] = pk()
    bank_statement_line_id: Mapped[uuid.UUID | None] = fk("bank_statement_lines.id", nullable=True)
    ledger: Mapped[str] = mapped_column(String(8), nullable=False, default="office")  # office receipt or client-money receipt
    matter_id: Mapped[uuid.UUID | None] = fk("matters.id", nullable=True)
    received_from_id: Mapped[uuid.UUID | None] = fk("contacts.id", nullable=True)
    amount: Mapped[Decimal] = money()
    allocated_amount: Mapped[Decimal] = money(default=Decimal("0"))
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")
    received_on: Mapped[date] = mapped_column(Date, nullable=False)
    reference: Mapped[str | None] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="received_unallocated")
    receipt_journal_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    recorded_by: Mapped[uuid.UUID] = fk("users.id")
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (
        CheckConstraint("amount > 0", name="amount_pos"),
        CheckConstraint("allocated_amount >= 0 and allocated_amount <= amount", name="alloc_within_amount"),
    )


class PaymentAllocation(Base, TenantMixin):
    __tablename__ = "payment_allocations"
    id: Mapped[uuid.UUID] = pk()
    payment_id: Mapped[uuid.UUID] = fk("payments.id")
    invoice_id: Mapped[uuid.UUID] = fk("invoices.id")
    amount: Mapped[Decimal] = money()
    allocated_by: Mapped[uuid.UUID] = fk("users.id")
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    journal_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    __table_args__ = (CheckConstraint("amount > 0", name="amount_pos"),)


class Reconciliation(Base, TenantMixin, TimestampMixin):
    __tablename__ = "reconciliations"
    id: Mapped[uuid.UUID] = pk()
    ledger: Mapped[str] = mapped_column(String(8), nullable=False)
    bank_account_id: Mapped[uuid.UUID] = fk("ledger_accounts.id")
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    statement_balance: Mapped[Decimal] = money()
    ledger_balance: Mapped[Decimal] = money()
    difference: Mapped[Decimal] = money()
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="draft")  # draft|signed_off
    prepared_by: Mapped[uuid.UUID] = fk("users.id")
    signed_off_by: Mapped[uuid.UUID | None] = fk("users.id", nullable=True)
    signed_off_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str | None] = mapped_column(Text)


class RevenueRecognition(Base, TenantMixin):
    """Explicit, separately authorised step: issuing an invoice or receiving cash does not recognise revenue."""
    __tablename__ = "revenue_recognitions"
    id: Mapped[uuid.UUID] = pk()
    invoice_id: Mapped[uuid.UUID] = fk("invoices.id")
    matter_id: Mapped[uuid.UUID] = fk("matters.id")
    amount: Mapped[Decimal] = money()
    basis: Mapped[str] = mapped_column(String(300), nullable=False)
    recognised_by: Mapped[uuid.UUID] = fk("users.id")
    approval_id: Mapped[uuid.UUID | None] = fk("approvals.id", nullable=True)
    journal_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    recognised_on: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    __table_args__ = (CheckConstraint("amount > 0", name="amount_pos"),)
