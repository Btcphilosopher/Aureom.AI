"""Citation verifier. The model proposes claims + evidence refs + quotes; this module REJECTS any claim whose citation is not in the
retrieved evidence set, whose version/page/paragraph do not match, or whose quote is not a verbatim substring of the cited evidence.
It also rejects unsupported legal-authority strings (case citations) that do not appear in any cited quote - guarding against
invented authorities."""
from __future__ import annotations

import re

AUTHORITY_RES = [
    re.compile(r"\[(?:19|20)\d{2}\]\s+(?:\d+\s+)?[A-Z][A-Za-z]{1,8}(?:\s+[A-Z][A-Za-z]{1,8})?\s+\d+"),   # [2019] UKSC 12 / [2020] 1 WLR 45 (approx.)
    re.compile(r"\b[A-Z][\w&'.\-]+(?:\s+[A-Z][\w&'.\-]+)*\s+v\.?\s+[A-Z][\w&'.\-]+(?:\s+[A-Z][\w&'.\-]+)*\s+\((?:19|20)\d{2}\)"),  # Smith v Jones (2001)
    re.compile(r"\b(?:section|s\.)\s*\d+[A-Z]?\s+of\s+the\s+[A-Z][A-Za-z ]+Act\s+(?:19|20)\d{2}"),
]
CLAIM_SECTIONS = ("facts", "inferences", "contradictions")


def norm(s: str | None) -> str:
    return " ".join((s or "").split())


def _same(a, b) -> bool:
    return (a is None and b is None) or (a is not None and b is not None and str(a) == str(b))


def check_citation(c: dict, index: dict) -> tuple[bool, str]:
    if not c or c.get("invalid") or not c.get("source_type"):
        return False, "unknown_source"
    ev = index.get((c["source_type"], str(c.get("source_id"))))
    if ev is None:
        return False, "source_not_in_retrieved_evidence"
    for f in ("document_id", "version_id", "version_no", "page", "paragraph"):
        if not _same(c.get(f), getattr(ev, f)):
            return False, f"{f}_mismatch"
    q = norm(c.get("quote"))
    if not q:
        return False, "quote_missing"
    if q not in norm(ev.text):
        return False, "quote_not_verbatim"
    return True, "ok"


def unsupported_authorities(statement: str, citations: list[dict]) -> list[str]:
    quotes = " ".join(norm(c.get("quote")) for c in citations)
    bad = []
    for rx in AUTHORITY_RES:
        for m in rx.finditer(statement or ""):
            if norm(m.group(0)) not in quotes:
                bad.append(m.group(0))
    return bad


def verify_result(result: dict, index: dict) -> tuple[dict, list[dict]]:
    """Return (clean_result, rejected_claims). Claims must carry >=1 citation and ALL must verify."""
    rejected: list[dict] = []
    clean = dict(result)
    checked = 0
    for section in CLAIM_SECTIONS:
        kept = []
        for claim in result.get(section, []):
            checked += 1
            cites = claim.get("citations") or []
            reason = None
            if not cites:
                reason = "no_citation"
            else:
                for c in cites:
                    ok, why = check_citation(c, index)
                    if not ok:
                        reason = why
                        break
            if reason is None:
                bad = unsupported_authorities(claim.get("statement", ""), cites)
                if bad:
                    reason = "unsupported_legal_authority"
            if reason:
                rejected.append({"section": section, "statement": claim.get("statement", "")[:300], "reason": reason})
            else:
                kept.append(claim)
        clean[section] = kept
    clean["verification"] = {"claims_checked": checked, "claims_rejected": len(rejected), "method": "citation existence + field match + verbatim quote"}
    return clean, rejected
