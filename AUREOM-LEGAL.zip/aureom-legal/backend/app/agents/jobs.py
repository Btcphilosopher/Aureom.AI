"""Worker handlers for agent jobs (registered when app.worker imports this module)."""
from __future__ import annotations

import uuid

from app.agents import runner
from app.services.jobs import job_handler


@job_handler("agent_run")
def handle_agent_run(db, job):
    run = runner.process_run(db, uuid.UUID(job.payload["run_id"]))
    return {"run_id": str(run.id), "status": run.status}


@job_handler("agent_execute")
def handle_agent_execute(db, job):
    run = runner.execute_run(db, uuid.UUID(job.payload["run_id"]))
    return {"run_id": str(run.id), "status": run.status}
