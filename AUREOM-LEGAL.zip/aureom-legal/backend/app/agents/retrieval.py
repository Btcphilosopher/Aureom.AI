"""Permission-scoped retrieval. Every method re-checks the REQUESTING user's rights; scope (firm + matter) comes from the run,
never from tool arguments. Retrieved text is returned as `Evidence` objects (data, not instructions)."""
from __future__ import annotations

import re
import time
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone

from sqlalchemy import func, or_, select

from app.agents.policy import PolicyDenied
from app.deps import Ctx
from app.errors import MatterAccessDenied, NotFound, PermissionDenied
from app.models import (ChronologyEntry, Contact, Correspondence, Deadline, DiaryEvent, Document, DocumentChunk, DocumentTemplate,
                        DocumentVersion, KnowledgeItem, Matter, OnboardingCheck, OnboardingRecord, Task, TimeEntry, User, ConflictSearch)
from app.permissions import can_ai_retrieve

MAX_CHUNKS = 400


@dataclass
class Evidence:
    source_type: str
    source_id: str
    text: str
    document_id: str | None = None
    version_id: str | None = None
    version_no: int | None = None
    page: int | None = None
    paragraph: int | None = None
    title: str | None = None
    meta: dict = field(default_factory=dict)
    ref: str = ""

    @property
    def key(self) -> tuple[str, str]:
        return (self.source_type, self.source_id)

    def citation(self, quote: str | None = None) -> dict:
        c = {"source_type": self.source_type, "source_id": self.source_id, "document_id": self.document_id, "version_id": self.version_id,
             "version_no": self.version_no, "page": self.page, "paragraph": self.paragraph, "quote": quote, "ref": self.ref, "title": self.title}
        if self.meta:
            c["meta"] = {k: v for k, v in self.meta.items() if k in ("effective_date", "last_reviewed", "source_ref", "retrieved_at", "source")}
        return c


# ---------------------------------------------------------------------------- cache (firm + user + matter keyed)
_CACHE: dict[tuple, tuple[float, object]] = {}
_TTL = 60.0


def cache_key(firm_id, user_id, matter_id, name: str, *parts) -> tuple:
    return (str(firm_id), str(user_id), str(matter_id), name, *[str(p) for p in parts])


def cache_get(key: tuple):
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    _CACHE.pop(key, None)
    return None


def cache_put(key: tuple, value) -> None:
    _CACHE[key] = (time.time(), value)


def clear_cache() -> None:
    _CACHE.clear()


def _d(v) -> str:
    return v.isoformat() if v else "not set"


class Retriever:
    def __init__(self, ctx: Ctx, matter_id: uuid.UUID | None = None):
        self.ctx, self.matter_id, self._matter = ctx, matter_id, None

    # -- scope ---------------------------------------------------------------------------------
    def matter(self) -> Matter:
        if self._matter is not None:
            return self._matter
        if not self.matter_id:
            raise PolicyDenied("This run has no matter scope.", details={"reason": "no_matter_scope"})
        m = self.ctx.db.get(Matter, self.matter_id)
        if not m or m.firm_id != self.ctx.firm_id:
            raise NotFound("Matter not found.")
        if not can_ai_retrieve(self.ctx, m):  # visibility + ethical wall + ai_retrieval_allowed + ai.use, evaluated for the REQUESTER
            raise MatterAccessDenied("AI retrieval is not permitted for this matter and user.", details={"reason": "ai_retrieval_not_permitted"})
        self._matter = m
        return m

    def _need(self, *perms: str) -> None:
        self.ctx.require(*perms)

    def _name(self, uid) -> str:
        u = self.ctx.db.get(User, uid) if uid else None
        return u.name if u else "unassigned"

    # -- matter ---------------------------------------------------------------------------------
    def matter_evidence(self) -> list[Evidence]:
        m = self.matter(); db = self.ctx.db
        client = db.get(Contact, m.client_id)
        cs = db.get(ConflictSearch, m.conflict_search_id) if m.conflict_search_id else None
        ob = db.execute(select(OnboardingRecord).where(OnboardingRecord.contact_id == m.client_id).order_by(OnboardingRecord.created_at.desc())).scalars().first()
        lines = [f"Reference: {m.reference}", f"Title: {m.title}", f"Matter type: {m.matter_type}", f"Practice area: {m.practice_area}",
                 f"Status: {m.status}", f"Stage: {m.stage or 'not set'}", f"Opened: {_d(m.opened_at)}", f"Target date: {_d(m.target_date)}",
                 f"Budget: {m.budget_amount if m.budget_amount is not None else 'not set'} {m.currency}", f"Fee arrangement: {m.fee_arrangement}",
                 f"Responsible partner: {self._name(m.responsible_partner_id)}", f"Fee earner: {self._name(m.fee_earner_id)}",
                 f"Client: {client.display_name if client else 'unknown'}",
                 f"Conflict search: {cs.status if cs else 'none recorded'}", f"Client onboarding: {ob.status if ob else 'none recorded'}",
                 f"Legal hold: {'yes' if m.legal_hold else 'no'}"]
        if m.description:
            lines.append(f"Description: {m.description}")
        return [Evidence("matter", str(m.id), "\n".join(lines), title=f"{m.reference} {m.title}")]

    # -- documents ---------------------------------------------------------------------------------
    def _docs(self) -> list[Document]:
        m = self.matter()
        return list(self.ctx.db.execute(select(Document).where(Document.firm_id == self.ctx.firm_id, Document.matter_id == m.id)
                                        .order_by(Document.created_at)).scalars())

    def documents(self) -> list[Evidence]:
        self._need("documents.read")
        out = []
        for d in self._docs():
            v = self.ctx.db.get(DocumentVersion, d.current_version_id) if d.current_version_id else None
            lines = [f"Document: {d.title}", f"Type: {d.doc_type}", f"Status: {d.status}", f"Current version: {d.current_version_no}",
                     f"Last updated: {d.updated_at.date().isoformat() if d.updated_at else 'unknown'}"]
            if v:
                lines.append(f"Text extraction: {v.index_status}; OCR: {v.ocr_status}; malware scan: {v.scan_status}")
            out.append(Evidence("document", str(d.id), "\n".join(lines), document_id=str(d.id), version_id=str(v.id) if v else None,
                                version_no=d.current_version_no or None, title=d.title, meta={"doc_type": d.doc_type, "index_status": v.index_status if v else "none"}))
        return out

    def chunks(self, document_ids: list[str] | None = None, limit: int = MAX_CHUNKS) -> tuple[list[Evidence], dict]:
        """Chunks of the CURRENT version of matter documents. Document ids outside the run's matter are refused."""
        self._need("documents.read")
        docs = self._docs()
        by_id = {str(d.id): d for d in docs}
        if document_ids:
            foreign = [i for i in document_ids if str(i) not in by_id]
            if foreign:
                raise PolicyDenied("Requested document is outside the matter scope of this run.", details={"reason": "out_of_scope", "count": len(foreign)})
            docs = [by_id[str(i)] for i in document_ids]
        ev: list[Evidence] = []
        stats = {"documents": 0, "chunks": 0, "skipped_unindexed": 0, "skipped_infected": 0, "truncated": False}
        for d in docs:
            if not d.current_version_id:
                continue
            v = self.ctx.db.get(DocumentVersion, d.current_version_id)
            if v.scan_status == "infected":
                stats["skipped_infected"] += 1
                continue
            key = cache_key(self.ctx.firm_id, self.ctx.user.id, self.matter_id, "chunks", v.id)
            rows = cache_get(key)
            if rows is None:
                rows = [(c.id, c.page, c.paragraph, c.text) for c in self.ctx.db.execute(
                    select(DocumentChunk).where(DocumentChunk.version_id == v.id, DocumentChunk.matter_id == self.matter_id).order_by(DocumentChunk.ordinal)).scalars()]
                cache_put(key, rows)
            if not rows:
                stats["skipped_unindexed"] += 1
                continue
            stats["documents"] += 1
            for cid, page, para, text in rows:
                if len(ev) >= limit:
                    stats["truncated"] = True
                    break
                ev.append(Evidence("document_chunk", str(cid), text, document_id=str(d.id), version_id=str(v.id), version_no=v.version_no,
                                   page=page, paragraph=para, title=d.title))
        stats["chunks"] = len(ev)
        return ev, stats

    # -- tasks / deadlines / correspondence ----------------------------------------------------
    def tasks(self) -> list[Evidence]:
        self._need("tasks.read")
        m = self.matter()
        rows = self.ctx.db.execute(select(Task).where(Task.firm_id == self.ctx.firm_id, Task.matter_id == m.id)
                                   .order_by(Task.due_at.asc().nulls_last()).limit(100)).scalars().all()
        return [Evidence("task", str(t.id), f"Task: {t.title}\nStatus: {t.status}\nDue: {t.due_at.date().isoformat() if t.due_at else 'no due date'}\n"
                                              f"Assignee: {self._name(t.assignee_id)}\nPriority: {t.priority}", title=t.title,
                         meta={"status": t.status, "due": t.due_at.date().isoformat() if t.due_at else None}) for t in rows]

    def deadlines(self) -> list[Evidence]:
        self._need("tasks.read")
        m = self.matter()
        rows = self.ctx.db.execute(select(Deadline).where(Deadline.firm_id == self.ctx.firm_id, Deadline.matter_id == m.id)
                                   .order_by(Deadline.due_date).limit(100)).scalars().all()
        return [Evidence("deadline", str(d.id), f"Deadline: {d.title}\nDue date: {d.due_date.isoformat()}\nStatus: {d.status}\nOrigin: {d.origin}", title=d.title,
                         meta={"status": d.status, "due": d.due_date.isoformat()}) for d in rows]

    def correspondence(self, limit: int = 30) -> list[Evidence]:
        self._need("correspondence.read")
        m = self.matter()
        rows = self.ctx.db.execute(select(Correspondence).where(Correspondence.firm_id == self.ctx.firm_id, Correspondence.matter_id == m.id,
                                                                Correspondence.status != "draft")
                                   .order_by(func.coalesce(Correspondence.received_at, Correspondence.sent_at, Correspondence.created_at).desc()).limit(limit)).scalars().all()
        out = []
        for c in rows:
            when = c.received_at or c.sent_at or c.created_at
            body = (c.body_text or "")[:6000]
            out.append(Evidence("correspondence", str(c.id),
                                f"Date: {when.date().isoformat()}\nDirection: {c.direction}\nFrom: {c.from_addr}\nSubject: {c.subject}\n\n{body}",
                                title=c.subject, meta={"date": when.date().isoformat()}))
        return out

    # -- time & activity (the requester's own) --------------------------------------------------
    def time_entries(self, date_from: date | None = None, date_to: date | None = None) -> list[Evidence]:
        self._need("time.write")
        m = self.matter()
        q = select(TimeEntry).where(TimeEntry.firm_id == self.ctx.firm_id, TimeEntry.matter_id == m.id, TimeEntry.user_id == self.ctx.user.id)
        if date_from:
            q = q.where(TimeEntry.work_date >= date_from)
        if date_to:
            q = q.where(TimeEntry.work_date <= date_to)
        rows = self.ctx.db.execute(q.order_by(TimeEntry.work_date).limit(200)).scalars().all()
        return [Evidence("time_entry", str(t.id), f"Time entry: {t.work_date.isoformat()}\nMinutes: {t.minutes}\nStatus: {t.status}\nNarrative: {t.narrative or ''}",
                         title=t.narrative[:60] if t.narrative else "time entry", meta={"work_date": t.work_date.isoformat(), "narrative": t.narrative or "", "status": t.status, "minutes": t.minutes})
                for t in rows]

    def activity(self, date_from: date | None = None, date_to: date | None = None) -> list[Evidence]:
        """Recorded activity by the requesting user on this matter (evidence that work occurred; never evidence of duration)."""
        self._need("time.write")
        m = self.matter(); db = self.ctx.db; uid = self.ctx.user.id
        lo = datetime.combine(date_from or date.min, datetime.min.time(), tzinfo=timezone.utc)
        hi = datetime.combine((date_to or date.max) , datetime.max.time(), tzinfo=timezone.utc)
        out: list[Evidence] = []
        vs = db.execute(select(DocumentVersion, Document).join(Document, Document.id == DocumentVersion.document_id)
                        .where(Document.matter_id == m.id, DocumentVersion.author_id == uid, DocumentVersion.created_at >= lo, DocumentVersion.created_at <= hi)).all()
        for v, d in vs:
            out.append(Evidence("activity", f"docver:{v.id}", f"Activity {v.created_at.date().isoformat()}: saved version {v.version_no} of document '{d.title}'",
                                title=d.title, meta={"date": v.created_at.date().isoformat(), "verb": f"saved version {v.version_no} of document '{d.title}'"}))
        cs = db.execute(select(Correspondence).where(Correspondence.matter_id == m.id, Correspondence.created_by == uid, Correspondence.created_at >= lo, Correspondence.created_at <= hi)).scalars().all()
        for c in cs:
            out.append(Evidence("activity", f"corr:{c.id}", f"Activity {c.created_at.date().isoformat()}: {c.direction} correspondence '{c.subject}'",
                                title=c.subject, meta={"date": c.created_at.date().isoformat(), "verb": f"handled {c.direction} correspondence '{c.subject}'"}))
        ts = db.execute(select(Task).where(Task.matter_id == m.id, Task.assignee_id == uid, Task.completed_at.is_not(None), Task.completed_at >= lo, Task.completed_at <= hi)).scalars().all()
        for t in ts:
            out.append(Evidence("activity", f"task:{t.id}", f"Activity {t.completed_at.date().isoformat()}: completed task '{t.title}'",
                                title=t.title, meta={"date": t.completed_at.date().isoformat(), "verb": f"completed task '{t.title}'"}))
        ds = db.execute(select(DiaryEvent).where(DiaryEvent.matter_id == m.id, DiaryEvent.owner_id == uid, DiaryEvent.start_at >= lo, DiaryEvent.start_at <= hi)).scalars().all()
        for e in ds:
            out.append(Evidence("activity", f"diary:{e.id}", f"Activity {e.start_at.date().isoformat()}: diary event '{e.title}' ({e.kind})",
                                title=e.title, meta={"date": e.start_at.date().isoformat(), "verb": f"attended diary event '{e.title}' ({e.kind})"}))
        return out

    # -- firm knowledge & templates ------------------------------------------------------------
    def knowledge(self, q: str | None, practice_area: str | None = None, limit: int = 5) -> list[Evidence]:
        """APPROVED items only. Tries a web-style query first, then falls back to an OR of the terms."""
        self._need("ai.use")
        base = select(KnowledgeItem).where(KnowledgeItem.firm_id == self.ctx.firm_id, KnowledgeItem.approved.is_(True))
        if practice_area:
            base = base.where(or_(KnowledgeItem.practice_area == practice_area, KnowledgeItem.practice_area.is_(None)))
        rows: list = []
        if q and q.strip():
            terms = [t for t in re.findall(r"[A-Za-z0-9]{3,}", q)][:12]
            queries = [func.websearch_to_tsquery("english", q)] + ([func.to_tsquery("english", " | ".join(terms))] if terms else [])
            for tsq in queries:
                rows = self.ctx.db.execute(base.where(KnowledgeItem.tsv.op("@@")(tsq)).order_by(func.ts_rank(KnowledgeItem.tsv, tsq).desc()).limit(limit)).scalars().all()
                if rows:
                    break
        else:
            rows = self.ctx.db.execute(base.order_by(KnowledgeItem.effective_date.desc()).limit(limit)).scalars().all()
        return [Evidence("knowledge", str(k.id), f"{k.title}\n{k.body[:4000]}", title=k.title,
                         meta={"effective_date": k.effective_date.isoformat(), "last_reviewed": k.last_reviewed.isoformat() if k.last_reviewed else None,
                               "source_ref": k.source_ref, "kind": k.kind}) for k in rows]

    def templates(self, template_id: str | None = None, doc_types: set[str] | None = None) -> tuple[list[Evidence], dict]:
        """APPROVED templates only. Returns (evidence, info) where info flags a requested-but-unapproved template."""
        self._need("documents.read")
        stmt = select(DocumentTemplate).where(DocumentTemplate.firm_id == self.ctx.firm_id)
        info = {"requested_unapproved": False, "requested_missing": False}
        if template_id:
            t = self.ctx.db.execute(stmt.where(DocumentTemplate.id == uuid.UUID(str(template_id)))).scalar_one_or_none()
            if t is None:
                info["requested_missing"] = True
                return [], info
            if not t.approved:
                info["requested_unapproved"] = True
                return [], info
            rows = [t]
        else:
            rows = self.ctx.db.execute(stmt.where(DocumentTemplate.approved.is_(True)).order_by(DocumentTemplate.name)).scalars().all()
            if doc_types:
                rows = [t for t in rows if t.doc_type in doc_types]
        return [Evidence("template", str(t.id), f"Template: {t.name}\nVersion: {t.template_version}\n\n{t.body}", title=t.name,
                         meta={"doc_type": t.doc_type, "fields": t.fields, "version": t.template_version, "body": t.body}) for t in rows], info

    # -- contacts / onboarding (intake) --------------------------------------------------------
    def contact(self, contact_id) -> Evidence:
        self._need("clients.read")
        c = self.ctx.db.get(Contact, uuid.UUID(str(contact_id)))
        if not c or c.firm_id != self.ctx.firm_id:
            raise NotFound("Contact not found.")
        lines = [f"Contact: {c.display_name}", f"Kind: {c.kind}", f"First name: {c.first_name or ''}", f"Last name: {c.last_name or ''}",
                 f"Email: {c.email or ''}", f"Phone: {c.phone or ''}", f"Date of birth: {c.date_of_birth.isoformat() if c.date_of_birth else ''}",
                 f"Preferred channel: {c.preferred_channel}", f"Company number: {c.company_number or ''}", f"Organisation: {c.org_name or ''}"]
        return Evidence("contact", str(c.id), "\n".join(lines), title=c.display_name,
                        meta={"kind": c.kind, "current": {"first_name": c.first_name, "last_name": c.last_name, "email": c.email, "phone": c.phone,
                                                          "date_of_birth": c.date_of_birth.isoformat() if c.date_of_birth else None,
                                                          "preferred_channel": c.preferred_channel, "company_number": c.company_number, "org_name": c.org_name}})

    def onboarding_form(self, contact_id) -> tuple[list[Evidence], dict]:
        self._need("clients.read")
        db = self.ctx.db
        c = db.get(Contact, uuid.UUID(str(contact_id)))
        if not c or c.firm_id != self.ctx.firm_id:
            raise NotFound("Contact not found.")
        rec = db.execute(select(OnboardingRecord).where(OnboardingRecord.contact_id == c.id).order_by(OnboardingRecord.created_at.desc())).scalars().first()
        info = {"has_record": rec is not None, "status": rec.status if rec else None, "checks": {}}
        ev: list[Evidence] = []
        if not rec:
            return ev, info
        for k, v in (rec.submitted_form or {}).items():
            if isinstance(v, (str, int, float)) and str(v).strip():
                ev.append(Evidence("onboarding_form", f"{rec.id}:{k}", f"{k}: {v}", title=k, meta={"key": k, "value": str(v)}))
        for ch in db.execute(select(OnboardingCheck).where(OnboardingCheck.onboarding_id == rec.id)).scalars():
            info["checks"][ch.check_type] = {"status": ch.status, "simulated": ch.is_simulated}
            ev.append(Evidence("onboarding_check", str(ch.id), f"Check {ch.check_type}: {ch.status}{' (SIMULATED - not a verified identity check)' if ch.is_simulated else ''}",
                               title=ch.check_type, meta={"check_type": ch.check_type, "status": ch.status}))
        return ev, info
