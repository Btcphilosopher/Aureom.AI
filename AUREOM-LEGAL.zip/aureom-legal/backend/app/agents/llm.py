"""Provider-independent model adapter.

* MockProvider      - deterministic, local, no network. Heuristic extraction over the retrieved evidence only. This is the default.
* AnthropicProvider - calls the Anthropic Messages API over HTTPS. NOT exercised by the automated tests (no key/network in CI);
                      enabling it sends the retrieved evidence blocks to the provider - see `AIProviderIntegration.info()`.

Contract: `complete_structured(task, system, evidence_blocks, schema, params) -> LLMResponse(output, tokens_in, tokens_out)`.
`output` is untrusted: the agent layer maps its evidence refs to real citations, verifies every quote verbatim against the evidence,
routes any `tool_calls` through the policy layer, and composes the human-readable summary itself. Private reasoning is never requested or stored.
"""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal

from app.agents import extract as X
from app.agents import prompts
from app.config import get_settings
from app.errors import IntegrationUnavailable
from app.integrations.base import Integration, IntegrationInfo, register


class ProviderError(Exception):
    """Transient provider failure (eligible for retry up to the run's max_attempts)."""


@dataclass
class LLMResponse:
    output: dict
    tokens_in: int
    tokens_out: int


class LLMProvider(ABC):
    name = "abstract"
    model = "abstract"

    @abstractmethod
    def complete_structured(self, task: str, system: str, evidence_blocks: list[dict], schema: dict, params: dict | None = None) -> LLMResponse: ...


def _tok(s: str) -> int:
    return max(1, len(s) // 4)


def estimate_tokens_in(system: str, blocks: list[dict]) -> int:
    return _tok(system) + sum(_tok(b.get("text", "")) for b in blocks)


def _f(statement, kind, ref, quote, **data):
    return {"statement": statement, "kind": kind, "evidence": [{"ref": ref, "quote": quote}], "data": data}


class MockProvider(LLMProvider):
    """LOCAL MOCK - not a language model. Everything it states is lifted from the evidence (verbatim quotes) by regular expressions."""
    name, model = "mock", "mock-local-1"

    def complete_structured(self, task, system, evidence_blocks, schema, params=None) -> LLMResponse:
        fn = getattr(self, f"_task_{task}", None)
        if fn is None:
            raise ProviderError(f"mock provider has no task '{task}'")
        out = fn(evidence_blocks, params or {})
        for k in ("facts", "inferences", "recommendations", "missing_information", "contradictions", "tool_calls"):
            out.setdefault(k, [])
        return LLMResponse(out, estimate_tokens_in(system, evidence_blocks), _tok(json.dumps(out, default=str)))

    # ------------------------------------------------------------------------------------------ document review
    def _task_document_review(self, blocks, params):
        chunks = [b for b in blocks if b["source_type"] == "document_chunk"]
        facts, infs, missing, contra, calls = [], [], [], [], []
        seen_party: set[str] = set()
        laws: list[tuple[str, dict]] = []
        notices: list[tuple[str, dict]] = []
        n_date = n_rel = 0
        has_law = has_notice = False
        for b in chunks:
            ref, text = b["ref"], b["text"]
            where = dict(document_id=b["document_id"], version_no=b["version_no"], page=b["page"], paragraph=b["paragraph"])
            for m in list(X.ORG_RE.finditer(text)) + list(X.PERSON_RE.finditer(text)):
                name = m.group(1).strip()
                if name.lower() not in seen_party and len(seen_party) < 20:
                    seen_party.add(name.lower())
                    facts.append(_f(f"Party named: {name}", "party", ref, name, name=name, **where))
            for m in X.DEFINED_RE.finditer(text):
                facts.append(_f(f"Defined term: \"{m.group(1)}\"", "defined_term", ref, m.group(0), term=m.group(1), **where))
            for seg in X.segments(text):
                hm = X.HEADING_RE.match(seg)
                if hm:
                    facts.append(_f(f"Clause {hm.group(1)}: {hm.group(2).strip()}", "clause", ref, seg, clause=hm.group(1), heading=hm.group(2).strip(), **where))
                    continue
                dates = X.find_dates(seg)
                rels = X.find_relative(seg)
                for d, txt in dates:
                    n_date += 1
                    facts.append(_f(f"Date stated: {d.isoformat()} ({txt}) - {X.short(seg, 140)}", "date", ref, seg, date=d.isoformat(), date_text=txt, basis="explicit", **where))
                    if X.has_deadline_cue(seg) and not any(txt in r["anchor"] for r in rels) and len(calls) < 8:
                        calls.append({"tool": "propose_deadline", "evidence": [{"ref": ref, "quote": seg}],
                                      "args": {"title": f"Deadline: {X.short(seg, 90)}", "due_date": d.isoformat(), "source_document_id": b["document_id"],
                                               "source_version_id": b.get("version_id"), "source_passage": seg, "date_basis": "explicit",
                                               "source_ref": {"page": b["page"], "paragraph": b["paragraph"], "version_no": b["version_no"]},
                                               "summary": f"Suggest deadline {d.isoformat()} from {b['title']} p.{b['page']} para {b['paragraph']}"}})
                for r in rels:
                    n_rel += 1
                    facts.append(_f(f"Relative time period stated: \"{r['matched']}\"", "relative_period", ref, r["matched"], n=r["n"], unit=r["unit"], daytype=r["daytype"], anchor=r["anchor"], **where))
                    anchor_date = dates[0][0] if dates else None
                    resolved = X.resolve_relative(r, anchor_date) if anchor_date else None
                    if resolved:
                        infs.append({"statement": f"Inferred date {resolved.isoformat()}: {r['n']} {r['unit']}(s) after {anchor_date.isoformat()} (calendar arithmetic only; not checked against a business calendar)",
                                     "confidence": "medium", "evidence": [{"ref": ref, "quote": seg}]})
                        calls.append({"tool": "propose_deadline", "evidence": [{"ref": ref, "quote": seg}],
                                      "args": {"title": f"Deadline (calculated): {X.short(seg, 80)}", "due_date": resolved.isoformat(), "source_document_id": b["document_id"],
                                               "source_version_id": b.get("version_id"), "source_passage": seg, "date_basis": "inferred",
                                               "assumptions": f"Inferred: {r['n']} {r['unit']}(s) after {anchor_date.isoformat()}, calendar arithmetic, no business-day or holiday adjustment. Verify the governing rule/agreement and trigger date.",
                                               "source_ref": {"page": b["page"], "paragraph": b["paragraph"], "version_no": b["version_no"]},
                                               "summary": f"Suggest calculated deadline {resolved.isoformat()} (inferred)"}})
                    else:
                        missing.append(f"Trigger date for \"{r['matched']}\" ({b['title']}, p.{b['page']} para {b['paragraph']}) is not stated in that passage, so no date was calculated.")
                        if len(calls) < 8:
                            calls.append({"tool": "propose_task", "evidence": [{"ref": ref, "quote": r["matched"]}],
                                          "args": {"title": f"Establish trigger date: {X.short(r['matched'], 90)}", "priority": "high",
                                                   "description": f"A time period was found in {b['title']} (v{b['version_no']}, p.{b['page']}, para {b['paragraph']}). Identify the trigger date and diarise a deadline for confirmation.",
                                                   "summary": "Task: establish trigger date for a stated time period"}})
                for m in X.NOTICE_RE.finditer(seg):
                    has_notice = True
                    notices.append((m.group(0), where))
                    facts.append(_f(f"Notice period stated: {m.group(0)}", "notice_period", ref, m.group(0), text=m.group(0), **where))
                    if len(calls) < 10 and sum(1 for c in calls if c["tool"] == "propose_task" and "notice" in c["args"]["title"].lower()) < 2:
                        calls.append({"tool": "propose_task", "evidence": [{"ref": ref, "quote": seg}],
                                      "args": {"title": f"Review notice provision: {X.short(m.group(0), 60)}", "description": f"See {b['title']} v{b['version_no']} p.{b['page']} para {b['paragraph']}.",
                                               "summary": "Task: review notice provision"}})
                for m in X.AMOUNT_RE.finditer(seg):
                    facts.append(_f(f"Amount stated: {m.group(0)} - {X.short(seg, 120)}", "amount", ref, seg, amount_text=m.group(0), **where))
                lm = X.LAW_RE.search(seg)
                if lm:
                    has_law = True
                    laws.append((lm.group(1).strip(), where))
                    facts.append(_f(f"Governing law: {lm.group(1).strip()}", "governing_law", ref, lm.group(0), law=lm.group(1).strip(), **where))
                if X.OBLIGATION_RE.search(seg) and not hm:
                    facts.append(_f(f"Obligation: {X.short(seg, 200)}", "obligation", ref, seg, **where))
        if not chunks:
            missing.append("No extracted document text was available. Documents may be unindexed or awaiting OCR; nothing could be reviewed.")
        else:
            if not seen_party:
                missing.append("No parties could be identified from the text (no company names or titled individuals found).")
            if n_date == 0 and n_rel == 0:
                missing.append("No dates or time periods were found in the reviewed text.")
            if not has_law:
                missing.append("No governing-law provision was found.")
            if not has_notice:
                missing.append("No termination or notice-period provision was found.")
        distinct = {l.lower() for l, _ in laws}
        if len(distinct) > 1:
            contra.append({"statement": "Different governing laws are stated: " + "; ".join(sorted({l for l, _ in laws})),
                           "evidence": [{"ref": b["ref"], "quote": X.LAW_RE.search(b["text"]).group(0)} for b in chunks if X.LAW_RE.search(b["text"])][:3]})
        recs = []
        if calls:
            recs.append({"statement": "Review the proposed tasks and deadline suggestions. Suggested deadlines are not authoritative until a solicitor confirms them."})
        return {"facts": facts[:150], "inferences": infs, "missing_information": missing, "contradictions": contra, "tool_calls": calls[:12], "recommendations": recs}

    # ------------------------------------------------------------------------------------------ chronology
    _KEYWORDS = ("completion", "exchange", "expiry", "termination", "hearing", "payment", "delivery")
    # concepts compared across sources: (label, phrases). Different explicit dates for the same concept are flagged for human review.
    _CONCEPTS = (("completion", ("completion",)), ("exchange", ("exchange",)), ("expiry", ("expiry", "expire")), ("termination", ("termination",)),
                 ("start / effective date", ("effective date", "commence", "starts on", "start date", "commencement")))

    def _task_chronology(self, blocks, params):
        src = [b for b in blocks if b["source_type"] in ("document_chunk", "correspondence")]
        entries, infs, missing, contra, calls, facts = [], [], [], [], [], []
        seen: set[tuple] = set()

        def add(d, date_text, basis, desc, b, quote):
            key = (d, " ".join(desc.lower().split())[:80])
            if key in seen:
                return
            seen.add(key)
            entries.append({"date": d, "date_text": date_text, "basis": basis, "desc": desc, "b": b, "quote": quote})

        for b in src:
            text, ref = b["text"], b["ref"]
            if b["source_type"] == "correspondence":
                lines = dict(l.split(": ", 1) for l in text.split("\n") if ": " in l and l.split(": ", 1)[0] in ("Date", "Direction", "Subject", "From"))
                dl = f"Date: {lines.get('Date', '')}"
                ds = X.find_dates(dl)
                if ds:
                    add(ds[0][0], ds[0][1], "explicit", f"{lines.get('Direction', 'correspondence').title()} email: {lines.get('Subject', '(no subject)')}", b, dl)
            for seg in X.segments(text):
                if b["source_type"] == "correspondence" and seg.startswith(("Date:", "Direction:", "From:", "Subject:")):
                    continue
                dates = X.find_dates(seg)
                for d, t in dates:
                    add(d, t, "explicit", X.short(seg, 220), b, seg)
                for r in X.find_relative(seg):
                    if dates:
                        res = X.resolve_relative(r, dates[0][0])
                        if res:
                            add(res, r["matched"], "inferred", f"{X.short(seg, 160)} [date inferred: {r['n']} {r['unit']}(s) after {dates[0][0].isoformat()}]", b, seg)
                            continue
                    missing.append(f"\"{r['matched']}\" ({b['title']}) has no stated trigger date, so it could not be placed on the timeline.")
        entries.sort(key=lambda e: e["date"])
        for e in entries[:60]:
            b = e["b"]
            where = dict(document_id=b.get("document_id"), version_no=b.get("version_no"), page=b.get("page"), paragraph=b.get("paragraph"))
            stmt = f"{e['date'].isoformat()} ({e['basis']}): {e['desc']}"
            facts.append(_f(stmt, "chronology_event", b["ref"], e["quote"], date=e["date"].isoformat(), basis=e["basis"], **where) if e["basis"] == "explicit" else None)
            if e["basis"] == "inferred":
                infs.append({"statement": stmt, "confidence": "medium", "evidence": [{"ref": b["ref"], "quote": e["quote"]}]})
            calls.append({"tool": "propose_chronology", "evidence": [{"ref": b["ref"], "quote": e["quote"]}], "args": {
                "entries": [{"event_date": e["date"].isoformat(), "date_text": e["date_text"], "date_basis": e["basis"], "description": e["desc"],
                             "source": {"type": b["source_type"], "id": b["source_id"], "document_id": b.get("document_id"), "version_id": b.get("version_id"),
                                        "version_no": b.get("version_no"), "page": b.get("page"), "paragraph": b.get("paragraph"), "quote": e["quote"]}}],
                "summary": f"Chronology: {e['date'].isoformat()} ({e['basis']})"}})
        facts = [f for f in facts if f]
        for kw, phrases in self._CONCEPTS:
            hits = {}
            for e in entries:
                if any(ph in e["quote"].lower() for ph in phrases) and e["basis"] == "explicit":
                    hits.setdefault(e["date"], e)
            if len(hits) > 1:
                ev = list(hits.values())[:3]
                contra.append({"statement": f"Different dates are associated with '{kw}': " + ", ".join(d.isoformat() for d in sorted(hits)),
                               "evidence": [{"ref": e["b"]["ref"], "quote": e["quote"]} for e in ev]})
        if not src:
            missing.append("No documents or correspondence with extractable text were available to build a chronology.")
        elif not entries:
            missing.append("No explicit or calculable dates were found in the available sources.")
        return {"facts": facts, "inferences": infs, "missing_information": missing, "contradictions": contra, "tool_calls": calls[:50],
                "recommendations": [{"statement": "Edit or reject entries before approval; inferred dates are calculations, not statements in the sources."}] if entries else []}

    # ------------------------------------------------------------------------------------------ briefing
    def _task_matter_briefing(self, blocks, params):
        by = lambda t: [b for b in blocks if b["source_type"] == t]  # noqa: E731
        facts, infs, missing, contra, recs = [], [], [], [], []
        mb = (by("matter") or [None])[0]
        today = date.today()
        if mb:
            L = dict(l.split(": ", 1) for l in mb["text"].split("\n") if ": " in l)
            q = lambda k: f"{k}: {L[k]}"  # noqa: E731
            facts.append(_f(f"Matter {L['Reference']} - {L['Title']} ({L['Matter type']}, {L['Practice area']}) is {L['Status']}", "matter", mb["ref"], q("Title"), status=L["Status"]))
            facts.append(_f(f"Current stage: {L['Stage']}", "stage", mb["ref"], q("Stage")))
            facts.append(_f(f"Client: {L['Client']}; responsible partner {L['Responsible partner']}; fee earner {L['Fee earner']}", "team", mb["ref"], q("Client")))
            if L["Target date"] == "not set":
                missing.append("No target date is set for this matter.")
            else:
                facts.append(_f(f"Target date: {L['Target date']}", "date", mb["ref"], q("Target date")))
            if L["Budget"].startswith("not set"):
                missing.append("No budget is recorded for this matter.")
            if L["Conflict search"] != "cleared_by_reviewer":
                missing.append(f"Conflict search status is '{L['Conflict search']}' (human clearance not recorded).")
                if L["Status"] in ("open",):
                    contra.append({"statement": f"Matter is open but the conflict search status is '{L['Conflict search']}'", "evidence": [{"ref": mb["ref"], "quote": q("Conflict search")}, {"ref": mb["ref"], "quote": q("Status")}]})
            if L["Client onboarding"] != "approved":
                missing.append(f"Client onboarding status is '{L['Client onboarding']}'.")
            if L["Legal hold"] == "yes":
                facts.append(_f("Legal hold is in place on this matter", "legal_hold", mb["ref"], q("Legal hold")))
        docs = by("document")
        if docs:
            facts.append(_f(f"{len(docs)} document(s) on file; most recently listed: {docs[-1]['title']} (version {docs[-1]['version_no']})", "documents", docs[-1]["ref"], f"Document: {docs[-1]['title']}"))
            pending = [d for d in docs if d["meta"].get("index_status") not in ("done",)]
            if pending:
                missing.append(f"{len(pending)} document(s) have no extracted text yet (indexing/OCR pending); their content is not reflected in this briefing.")
        else:
            missing.append("No documents are filed on this matter (or your role cannot read documents).")
        tasks = by("task")
        open_t = [t for t in tasks if t["meta"].get("status") not in ("done", "cancelled")]
        for t in open_t[:8]:
            line = t["text"].split("\n")[0]
            due = t["meta"].get("due")
            facts.append(_f(f"Outstanding task: {t['title']} (due {due or 'no date'})", "task", t["ref"], line, status=t["meta"].get("status"), due=due))
            if due and date.fromisoformat(due) < today:
                infs.append({"statement": f"Task '{t['title']}' appears overdue (due {due}, today {today.isoformat()})", "confidence": "high", "evidence": [{"ref": t["ref"], "quote": f"Due: {due}"}]})
        if not tasks:
            missing.append("No tasks are recorded for this matter (or your role cannot read tasks).")
        if mb and L["Status"] == "closed" and open_t:
            contra.append({"statement": f"Matter is closed but {len(open_t)} task(s) remain open", "evidence": [{"ref": mb["ref"], "quote": "Status: closed"}, {"ref": open_t[0]["ref"], "quote": open_t[0]["text"].split("\n")[0]}]})
        dls = by("deadline")
        conf = [d for d in dls if d["meta"].get("status") == "confirmed"]
        sugg = [d for d in dls if d["meta"].get("status") == "suggested"]
        for d in conf[:5]:
            facts.append(_f(f"Confirmed deadline: {d['title']} on {d['meta']['due']}", "deadline", d["ref"], d["text"].split("\n")[1], status="confirmed"))
        for d in sugg[:5]:
            facts.append(_f(f"Unconfirmed deadline suggestion: {d['title']} on {d['meta']['due']}", "deadline", d["ref"], d["text"].split("\n")[1], status="suggested"))
        if sugg:
            recs.append({"statement": f"{len(sugg)} suggested deadline(s) await human confirmation."})
        if not conf:
            missing.append("No confirmed deadlines are recorded.")
        corr = by("correspondence")
        for c in corr[:3]:
            facts.append(_f(f"Recent correspondence ({c['meta'].get('date')}): {c['title']}", "correspondence", c["ref"], f"Subject: {c['title']}"))
        if not corr:
            missing.append("No correspondence is filed on this matter (or your role cannot read correspondence).")
        return {"facts": facts, "inferences": infs, "missing_information": missing, "contradictions": contra, "recommendations": recs}

    # ------------------------------------------------------------------------------------------ drafting
    def _task_drafting(self, blocks, params):
        d = params.get("draft") or {}
        facts, missing, calls, recs = [], list(params.get("missing", [])), [], []
        tpl = next((b for b in blocks if b["source_type"] == "template"), None)
        if tpl:
            facts.append(_f(f"Draft is based on approved template '{tpl['title']}' (version {tpl['meta'].get('version')})", "template", tpl["ref"], f"Template: {tpl['title']}"))
        m = next((b for b in blocks if b["source_type"] == "matter"), None)
        if m:
            ref_line = next(l for l in m["text"].split("\n") if l.startswith("Reference:"))
            facts.append(_f(f"Draft relates to matter {ref_line.split(': ', 1)[1]}", "matter", m["ref"], ref_line))
        for k in [b for b in blocks if b["source_type"] == "knowledge"][:3]:
            facts.append(_f(f"Approved internal reference material available: '{k['title']}' (effective {k['meta'].get('effective_date')})", "knowledge", k["ref"], k["title"]))
        for u in [b for b in blocks if b["source_type"] == "user_input"][:5]:
            facts.append(_f(f"Instruction/notes supplied by the requesting user: {X.short(u['text'], 120)}", "user_input", u["ref"], u["text"][:200].split("\n")[0]))
        if d.get("kind") == "correspondence" and d.get("body"):
            ev = [{"ref": tpl["ref"], "quote": f"Template: {tpl['title']}"}] if tpl else []
            calls.append({"tool": "propose_correspondence_draft", "evidence": ev, "args": {"subject": d["subject"], "body_text": d["body"], "to_addrs": d.get("to", []),
                          "template_id": tpl["source_id"] if tpl else None, "summary": f"Draft correspondence: {d['subject']}"}})
        if d.get("kind") in ("document", "attendance_note") and d.get("body"):
            ev = [{"ref": tpl["ref"], "quote": f"Template: {tpl['title']}"}] if tpl else []
            calls.append({"tool": "propose_document_draft", "evidence": ev, "args": {"title": d["subject"], "content": d["body"], "doc_type": d.get("doc_type", "letter"),
                          "template_id": tpl["source_id"] if tpl else None, "summary": f"Draft document: {d['subject']}"}})
        if not calls:
            missing.append("No draft was produced (see the notes above).")
        else:
            recs.append({"statement": "Review and edit the draft. It will be saved as a DRAFT only; it cannot be sent or shared from the AI workspace."})
        return {"facts": facts, "missing_information": missing, "tool_calls": calls, "recommendations": recs}

    # ------------------------------------------------------------------------------------------ knowledge
    def _task_knowledge(self, blocks, params):
        q = (params.get("query") or "").lower()
        terms = {t for t in re.findall(r"[a-z]{4,}", q)}
        facts, missing, recs, infs = [], [], [], []
        items = [b for b in blocks if b["source_type"] in ("knowledge", "external_research")]
        for b in items:
            body = b["text"].split("\n", 1)[1] if "\n" in b["text"] else b["text"]
            segs = X.segments(body) or [b["text"]]
            best = max(segs, key=lambda s: len(terms & set(re.findall(r"[a-z]{4,}", s.lower()))))
            m = b["meta"]
            label = "Internal" if b["source_type"] == "knowledge" else f"External ({m.get('source')}, retrieved {m.get('retrieved_at')})"
            facts.append(_f(f"{label} - '{b['title']}': {X.short(best, 260)}", b["source_type"], b["ref"], best, title=b["title"], effective_date=m.get("effective_date"),
                            last_reviewed=m.get("last_reviewed"), source_ref=m.get("source_ref")))
            lr = m.get("last_reviewed") or m.get("effective_date")
            if lr and date.fromisoformat(lr) < date.today() - timedelta(days=548):
                infs.append({"statement": f"'{b['title']}' was last reviewed {lr}, more than 18 months ago; check it is current", "confidence": "medium", "evidence": [{"ref": b["ref"], "quote": b["title"]}]})
        if not items:
            missing.append(f"No approved internal precedents or practice materials matched the query. Nothing has been inferred or supplied from outside the approved knowledge base.")
            recs.append({"statement": "Ask the supervising partner or add/approve relevant material in the knowledge base. This assistant does not supply case citations or authorities."})
        ext = params.get("external")
        if ext and not ext.get("available"):
            missing.append(f"External legal research was requested but no research source is configured ({ext.get('reason') or 'not configured'}). No external authorities were retrieved.")
        return {"facts": facts, "inferences": infs, "missing_information": missing, "recommendations": recs}

    # ------------------------------------------------------------------------------------------ intake
    _ALIASES = {
        "first_name": ["first_name", "forename", "given_name", "firstname"], "last_name": ["last_name", "surname", "family_name", "lastname"],
        "email": ["email", "email_address"], "phone": ["phone", "telephone", "mobile", "phone_number"],
        "date_of_birth": ["dob", "date_of_birth", "birth_date"], "preferred_channel": ["preferred_channel", "contact_preference"],
        "company_number": ["company_number", "companies_house_number", "registration_number"], "org_name": ["company_name", "organisation", "organisation_name"],
    }

    def _task_intake(self, blocks, params):
        forms = [b for b in blocks if b["source_type"] == "onboarding_form"]
        contact = next((b for b in blocks if b["source_type"] == "contact"), None)
        current = (contact or {}).get("meta", {}).get("current", {})
        facts, infs, missing, calls = [], [], [], []
        mapped: dict[str, tuple[str, dict]] = {}
        keys = set()
        for b in forms:
            k, v = b["meta"]["key"].lower(), b["meta"]["value"].strip()
            keys.add(k)
            for field, al in self._ALIASES.items():
                if k in al:
                    if field == "date_of_birth":
                        ds = X.find_dates(v)
                        if not ds:
                            missing.append(f"Date of birth value '{v}' is not in a recognisable date format; confirm with the client.")
                            continue
                        v = ds[0][0].isoformat()
                    if field == "preferred_channel" and v.lower() not in ("email", "phone", "post", "portal"):
                        continue
                    mapped[field] = (v.lower() if field == "preferred_channel" else v, b)
                    facts.append(_f(f"Form entry '{b['meta']['key']}' maps to contact field {field}: {v}", "form_field", b["ref"], b["text"], field=field))
        changes = {f: v for f, (v, _) in mapped.items() if (current.get(f) or "") != v}
        if changes:
            ev = [{"ref": mapped[f][1]["ref"], "quote": mapped[f][1]["text"]} for f in changes]
            calls.append({"tool": "propose_contact_update", "evidence": ev, "args": {"contact_id": params["contact_id"], "changes": changes,
                          "summary": f"Update contact fields from submitted form: {', '.join(sorted(changes))}"}})
        kind = params.get("contact_kind")
        req = ["first_name", "last_name", "date_of_birth"] if kind == "individual" else ["org_name", "company_number"]
        for f in req:
            if f not in mapped and not current.get(f):
                missing.append(f"Required field not provided: {f.replace('_', ' ')}.")
        if not ({"email", "phone"} & set(mapped) or current.get("email") or current.get("phone")):
            missing.append("No email address or telephone number provided.")
        if not any(k.startswith(("address", "postcode")) for k in keys):
            missing.append("No address provided on the form.")
        if kind == "organisation" and not any(k in keys for k in ("directors", "beneficial_owners", "ubo", "persons_with_significant_control")):
            missing.append("Directors / beneficial ownership information not provided.")
        checks = {b["meta"]["check_type"]: b["meta"]["status"] for b in blocks if b["source_type"] == "onboarding_check"}
        for c in params.get("required_checks", []):
            st = checks.get(c)
            if st not in ("passed_simulated", "waived"):
                missing.append(f"Onboarding check '{c}' is {st or 'not started'} (checks in this build are SIMULATED and never constitute verified identity).")
        if kind == "individual" and "company_number" in mapped:
            infs.append({"statement": "A company number was supplied for an individual contact; the applicant may be acting for an organisation.", "confidence": "low",
                         "evidence": [{"ref": mapped["company_number"][1]["ref"], "quote": mapped["company_number"][1]["text"]}]})
        if not forms:
            missing.append("No submitted onboarding form was found for this contact.")
        return {"facts": facts, "inferences": infs, "missing_information": missing, "tool_calls": calls}

    # ------------------------------------------------------------------------------------------ billing assistant
    def _task_billing_assistant(self, blocks, params):
        tes = [b for b in blocks if b["source_type"] == "time_entry"]
        acts = [b for b in blocks if b["source_type"] == "activity"]
        users = [b for b in blocks if b["source_type"] == "user_input"]
        by_date: dict[str, list[dict]] = {}
        for a in acts:
            by_date.setdefault(a["meta"]["date"], []).append(a)
        facts, missing, calls, recs = [], [], [], []
        for a in acts:
            facts.append(_f(f"Recorded activity on {a['meta']['date']}: {a['meta']['verb']}", "activity", a["ref"], a["text"]))

        def narrative(day):
            return "; ".join(sorted({a["meta"]["verb"] for a in by_date.get(day, [])}))[:600]

        covered_days = set()
        for t in tes:
            day = t["meta"]["work_date"]
            covered_days.add(day)
            nar = t["meta"].get("narrative") or ""
            if len(nar.strip()) >= 15:
                continue
            if by_date.get(day):
                text = "Work on matter: " + narrative(day)
                calls.append({"tool": "propose_time_narrative", "evidence": [{"ref": t["ref"], "quote": f"Time entry: {day}"}] + [{"ref": a["ref"], "quote": a["text"]} for a in by_date[day]][:4],
                              "args": {"time_entry_id": t["source_id"], "narrative": text, "summary": f"Suggested narrative for time entry on {day}"}})
            else:
                missing.append(f"Time entry on {day} has no narrative and there is no recorded activity to base one on; the fee earner must describe the work.")
        supplied = params.get("entries") or []
        for e in supplied:
            day = e.get("work_date")
            covered_days.add(day)
            mins = e.get("minutes")
            if not mins:
                missing.append(f"Minutes required for {day}: this assistant does not estimate time spent.")
                continue
            if by_date.get(day):
                nar = "Work on matter: " + narrative(day)
                ev = [{"ref": a["ref"], "quote": a["text"]} for a in by_date[day]][:4]
            elif e.get("narrative_hint") and users:
                u = users[0]
                nar, ev = e["narrative_hint"], [{"ref": u["ref"], "quote": u["text"].split("\n")[0]}]
            else:
                missing.append(f"No recorded activity on {day} and no description supplied; cannot draft a time entry narrative.")
                continue
            calls.append({"tool": "propose_time_entry", "evidence": ev, "args": {"work_date": day, "minutes": int(mins), "narrative": nar,
                          "summary": f"Draft time entry {day}: {mins} min (minutes supplied by you)"}})
        for day, lst in sorted(by_date.items()):
            if day not in covered_days:
                missing.append(f"Recorded activity on {day} ({len(lst)} item(s)) has no time entry. Minutes required - enter the time you spent; this assistant will not estimate it.")
        if calls:
            recs.append({"statement": "Review suggested narratives; they describe recorded activity only. Time entries are created as drafts and billed only after normal approval."})
        return {"facts": facts, "missing_information": missing, "tool_calls": calls, "recommendations": recs}


# ============================================================================================ Anthropic (live) - NOT exercised by tests
class AnthropicProvider(LLMProvider):
    """Calls https://api.anthropic.com/v1/messages. Sends ONLY the evidence blocks retrieved for the run (wrapped as untrusted data),
    the system prompt and the task parameters. Never sends other matters, bank details, ledgers or binary files.
    NOT covered by automated tests: it needs a real API key and network access."""
    name = "anthropic"

    def __init__(self, api_key: str, model: str, timeout: float = 90.0):
        self.api_key, self.model, self.timeout = api_key, model, timeout

    def complete_structured(self, task, system, evidence_blocks, schema, params=None) -> LLMResponse:
        import httpx

        data = "\n\n".join(prompts.wrap_data(b["ref"], b["source_type"], b["text"]) for b in evidence_blocks)
        user = (f"TASK PARAMETERS (from the authenticated user):\n{json.dumps(params or {}, default=str)[:4000]}\n\nEVIDENCE (untrusted data):\n{data}\n\n"
                f"Respond with ONLY a JSON object matching this schema (refs must be evidence refs; quotes must be verbatim):\n{json.dumps(schema)}")
        try:
            r = httpx.post("https://api.anthropic.com/v1/messages", timeout=self.timeout,
                           headers={"x-api-key": self.api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                           json={"model": self.model, "max_tokens": 4096, "system": system, "messages": [{"role": "user", "content": user}]})
            r.raise_for_status()
            body = r.json()
            text = "".join(p.get("text", "") for p in body.get("content", []) if p.get("type") == "text")
            m = re.search(r"\{.*\}", text, re.S)
            out = json.loads(m.group(0)) if m else {}
            u = body.get("usage", {})
            return LLMResponse(out, int(u.get("input_tokens", 0)), int(u.get("output_tokens", 0)))
        except (httpx.HTTPError, ValueError, KeyError) as e:  # content deliberately not logged
            raise ProviderError(f"provider call failed: {type(e).__name__}") from e


# ============================================================================================ selection, cost, integration info
_OVERRIDE: LLMProvider | None = None


def set_provider_override(p: LLMProvider | None) -> None:
    """Test hook / dependency injection."""
    global _OVERRIDE
    _OVERRIDE = p


def get_provider(ai_cfg: dict | None = None) -> LLMProvider:
    if _OVERRIDE is not None:
        return _OVERRIDE
    s = get_settings()
    name = "mock" if (ai_cfg or {}).get("provider") == "mock" else s.ai_provider
    if name == "anthropic":
        if not s.anthropic_api_key:
            raise IntegrationUnavailable("AI provider 'anthropic' is selected but ANTHROPIC_API_KEY is not set.", details={"integration": "ai_provider"})
        return AnthropicProvider(s.anthropic_api_key, s.ai_model)
    return MockProvider()


def compute_cost(ai_cfg: dict, tokens_in: int, tokens_out: int) -> Decimal:
    rin = Decimal(str(ai_cfg.get("cost_per_1k_tokens_in_gbp", "0.0004")))
    rout = Decimal(str(ai_cfg.get("cost_per_1k_tokens_out_gbp", "0.0012")))
    return ((Decimal(tokens_in) * rin + Decimal(tokens_out) * rout) / Decimal(1000)).quantize(Decimal("0.0001"))


class AIProviderIntegration(Integration):
    key = "ai_provider"

    def info(self) -> IntegrationInfo:
        s = get_settings()
        if s.ai_provider == "anthropic":
            live = bool(s.anthropic_api_key)
            return IntegrationInfo(
                key=self.key, name="AI model provider (Anthropic)", category="ai", provider="anthropic", mode="live" if live else "unavailable",
                description="Live model calls via the Anthropic Messages API. NOT exercised by this project's automated tests.",
                data_leaves_application=("When a run executes, the following leave the application to the provider: the system prompt, the user's task parameters, and the evidence "
                                         "retrieved for that run under the requesting user's permissions - matter metadata lines, extracted document text paragraphs, correspondence bodies, "
                                         "task/deadline lines, approved knowledge items/templates, onboarding form values (intake agent) and time-entry narratives (billing assistant). "
                                         "NOT sent: original files, other matters, restricted matters the user cannot access, bank details, ledgers. "
                                         f"Data residency setting: {s.data_residency}. Matter content is not used for model training by this application; confirm the provider's contractual terms."),
                setup_hint="Set ANTHROPIC_API_KEY and AI_PROVIDER=anthropic; complete a data-protection review first.")
        return IntegrationInfo(
            key=self.key, name="AI model provider (local mock)", category="ai", provider="mock-local-1", mode="mock",
            description="Deterministic local mock - heuristics over retrieved text. Not a language model. No network calls.",
            data_leaves_application="Nothing leaves the application in mock mode.", setup_hint="Set AI_PROVIDER=anthropic and ANTHROPIC_API_KEY to use a live provider.")


register(AIProviderIntegration())
