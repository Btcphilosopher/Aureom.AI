"""Application policy layer for agent tools. Agents are READ-ONLY by default; they may only call tools in their
allowlist, and `propose_*` tools merely record a proposal for human review. Everything in PROHIBITED_TOOLS is denied for
every agent, always. Permissions are checked again when a tool executes (see tools.ToolBox.call / actions.check_action_permission)."""
from __future__ import annotations

from app.errors import PermissionDenied

PROHIBITED_TOOLS = {
    "send_email", "send_message", "share_document", "post_journal", "transfer_funds", "release_client_funds", "change_bank_details",
    "issue_invoice", "approve_invoice", "confirm_deadline", "mark_conflict_cleared", "clear_conflict", "complete_onboarding",
    "approve_action", "execute_action", "grant_access", "change_permissions", "export_documents", "close_matter", "open_matter",
}

READ_TOOLS = {
    "get_matter", "list_matter_documents", "read_document_chunks", "list_matter_tasks", "list_matter_deadlines", "list_correspondence",
    "list_time_entries", "list_activity", "search_knowledge", "list_approved_templates", "get_contact", "get_onboarding_form",
    "external_legal_research",
}
PROPOSAL_TOOLS = {
    "propose_task", "propose_deadline", "propose_chronology", "propose_correspondence_draft", "propose_document_draft",
    "propose_time_entry", "propose_time_narrative", "propose_contact_update",
}

AGENT_POLICY: dict[str, dict] = {
    "matter_briefing": {"read": {"get_matter", "list_matter_documents", "list_matter_tasks", "list_matter_deadlines", "list_correspondence"}, "propose": set(), "needs_matter": True},
    "document_review": {"read": {"get_matter", "list_matter_documents", "read_document_chunks"}, "propose": {"propose_task", "propose_deadline"}, "needs_matter": True},
    "chronology": {"read": {"get_matter", "list_matter_documents", "read_document_chunks", "list_correspondence"}, "propose": {"propose_chronology"}, "needs_matter": True},
    "drafting": {"read": {"get_matter", "list_approved_templates", "search_knowledge", "list_correspondence"},
                 "propose": {"propose_correspondence_draft", "propose_document_draft"}, "needs_matter": True},
    "knowledge": {"read": {"search_knowledge", "external_legal_research"}, "propose": set(), "needs_matter": False},
    "intake": {"read": {"get_contact", "get_onboarding_form"}, "propose": {"propose_contact_update"}, "needs_matter": False},
    "billing_assistant": {"read": {"get_matter", "list_time_entries", "list_activity"}, "propose": {"propose_time_narrative", "propose_time_entry"}, "needs_matter": True},
}

# permission the REQUESTING user must hold for a read tool / to propose an action type
TOOL_PERMISSIONS = {
    "get_matter": ["ai.use"], "list_matter_documents": ["documents.read"], "read_document_chunks": ["documents.read"],
    "list_matter_tasks": ["tasks.read"], "list_matter_deadlines": ["tasks.read"], "list_correspondence": ["correspondence.read"],
    "list_time_entries": ["time.write"], "list_activity": ["time.write"], "search_knowledge": ["ai.use"], "list_approved_templates": ["documents.read"],
    "get_contact": ["clients.read"], "get_onboarding_form": ["clients.read"], "external_legal_research": ["ai.use"],
}
ACTION_PERMISSIONS = {
    "create_task": ["tasks.write"], "suggest_deadline": ["tasks.write"], "add_chronology_entries": ["documents.write"],
    "create_correspondence_draft": ["correspondence.write"], "create_document_draft": ["documents.write"],
    "create_time_entry": ["time.write"], "update_time_narrative": ["time.write"], "update_contact_fields": ["clients.write"],
}
TOOL_TO_ACTION = {
    "propose_task": "create_task", "propose_deadline": "suggest_deadline", "propose_chronology": "add_chronology_entries",
    "propose_correspondence_draft": "create_correspondence_draft", "propose_document_draft": "create_document_draft",
    "propose_time_entry": "create_time_entry", "propose_time_narrative": "update_time_narrative", "propose_contact_update": "update_contact_fields",
}
RISK = {"create_task": "low", "suggest_deadline": "medium", "add_chronology_entries": "low", "create_correspondence_draft": "medium",
        "create_document_draft": "medium", "create_time_entry": "medium", "update_time_narrative": "low", "update_contact_fields": "high"}


class PolicyDenied(PermissionDenied):
    code = "tool_denied"


def is_prohibited(tool: str) -> bool:
    return tool in PROHIBITED_TOOLS or tool.startswith("delete_") or tool.startswith("drop_")


def check_tool_allowed(agent_type: str, tool: str) -> None:
    if is_prohibited(tool):
        raise PolicyDenied(f"Tool '{tool}' is prohibited for AI agents.", details={"tool": tool, "reason": "prohibited"})
    pol = AGENT_POLICY.get(agent_type)
    if pol is None:
        raise PolicyDenied(f"Unknown agent '{agent_type}'.", details={"tool": tool, "reason": "unknown_agent"})
    if tool not in pol["read"] and tool not in pol["propose"]:
        raise PolicyDenied(f"Tool '{tool}' is not in the allowlist of the {agent_type} agent.", details={"tool": tool, "reason": "not_allowlisted"})


def is_read_only(agent_type: str) -> bool:
    return not AGENT_POLICY[agent_type]["propose"]
