"""Agent run lifecycle: Queued -> Running -> Awaiting review -> Approved|Rejected -> Executing -> Completed|Failed (+Cancelled).

Guarantees:
* analysis runs with the REQUESTING user's permissions (Ctx.for_user(requester)); agents are read-only and can only PROPOSE;
* a proposal is applied only after a human approves that exact content (approved_hash); edits clear approvals;
* execution is idempotent (row lock + status guard + unique execution_key) and re-verifies hash and approver permissions;
* budgets, timeouts, cancellation and retry limits are enforced; events store evidence/summaries, never reasoning or content."""
from __future__ import annotations

import json
import logging
import time
import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.agents import actions as A
from app.agents import policy
from app.agents.agents import get_agent
from app.agents.llm import LLMProvider, LLMResponse, ProviderError, compute_cost, estimate_tokens_in, get_provider
from app.agents.prompts import template_version
from app.agents.tools import ToolBox, log_event
from app.config import get_settings
from app.deps import Ctx
from app.errors import (AppError, BudgetExceeded, InvalidState, MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed)
from app.models import AgentProposedAction, AgentRun, AgentRunEvent, Contact, Firm, Matter, User
from app.permissions import can_access_matter, can_ai_retrieve, matter_clause
from app.security import canonical_hash
from app.services import jobs
from app.services.notify import notify

log = logging.getLogger("aureom.agents")

TRANSITIONS: dict[str, set[str]] = {
    "queued": {"running", "cancelled"},
    "running": {"awaiting_review", "completed", "failed", "cancelled", "queued"},
    "awaiting_review": {"approved", "rejected", "cancelled", "completed"},
    "approved": {"executing", "awaiting_review", "cancelled"},
    "executing": {"completed", "failed"},
    "failed": {"queued", "approved"},
    "rejected": set(), "completed": set(), "cancelled": set(),
}
TERMINAL = {"rejected", "completed", "cancelled"}
DEFAULT_AI = {"enabled": True, "auto_complete_readonly": True, "monthly_budget_gbp": 50.0, "per_run_budget_gbp": 2.0, "user_daily_runs": 40,
              "allowed_agents": list(policy.AGENT_POLICY)}


class RunCancelled(Exception):
    pass


class RunTimeout(AppError):
    status_code, code = 408, "run_timeout"


def now() -> datetime:
    return datetime.now(timezone.utc)


def ai_settings(db: Session, firm_id) -> dict:
    firm = db.get(Firm, firm_id)
    return {**DEFAULT_AI, **((firm.settings or {}).get("ai") or {})}


def _transition(db: Session, run: AgentRun, to: str, actor=None, note: str | None = None) -> None:
    if to not in TRANSITIONS.get(run.status, set()):
        raise InvalidState(f"A run cannot move from '{run.status}' to '{to}'.", details={"from": run.status, "to": to})
    log_event(db, run, "state_change", f"{run.status} -> {to}" + (f" ({note})" if note else ""), {"from": run.status, "to": to}, actor)
    run.status = to
    if to in TERMINAL or to == "failed":
        run.finished_at = now()
    elif to in ("queued", "running", "awaiting_review", "approved", "executing"):
        pass


# ------------------------------------------------------------------------------------------------ budgets
def usage_summary(ctx: Ctx) -> dict:
    db = ctx.db
    cfg = ai_settings(db, ctx.firm_id)
    first = datetime.combine(date.today().replace(day=1), datetime.min.time(), tzinfo=timezone.utc)
    spent = db.execute(select(func.coalesce(func.sum(AgentRun.cost_gbp), 0)).where(AgentRun.firm_id == ctx.firm_id, AgentRun.created_at >= first)).scalar_one()
    today = datetime.combine(date.today(), datetime.min.time(), tzinfo=timezone.utc)
    mine = db.execute(select(func.count()).where(AgentRun.firm_id == ctx.firm_id, AgentRun.requested_by == ctx.user.id, AgentRun.created_at >= today)).scalar_one()
    by_agent = db.execute(select(AgentRun.agent_type, func.count(), func.coalesce(func.sum(AgentRun.cost_gbp), 0)).where(AgentRun.firm_id == ctx.firm_id, AgentRun.created_at >= first)
                          .group_by(AgentRun.agent_type)).all()
    return {"period_start": first.date().isoformat(), "basis": "Sum of run cost (tokens x configured GBP rate) for runs created this calendar month, all users in the firm.",
            "currency": "GBP", "spent_gbp": str(Decimal(spent).quantize(Decimal("0.0001"))), "monthly_budget_gbp": str(cfg["monthly_budget_gbp"]),
            "per_run_budget_gbp": str(cfg["per_run_budget_gbp"]), "your_runs_today": mine, "user_daily_runs_limit": cfg["user_daily_runs"],
            "by_agent": [{"agent_type": a, "runs": n, "cost_gbp": str(Decimal(c).quantize(Decimal("0.0001")))} for a, n, c in by_agent]}


def check_budget(ctx: Ctx, cfg: dict) -> None:
    u = usage_summary(ctx)
    if Decimal(u["spent_gbp"]) >= Decimal(str(cfg["monthly_budget_gbp"])):
        raise BudgetExceeded("The firm's monthly AI usage budget has been reached.", details={"spent_gbp": u["spent_gbp"], "budget_gbp": str(cfg["monthly_budget_gbp"])})
    if u["your_runs_today"] >= int(cfg["user_daily_runs"]):
        raise BudgetExceeded("You have reached your daily AI run limit.", details={"limit": cfg["user_daily_runs"]})


class _Guarded(LLMProvider):
    """Wraps a provider to enforce the per-run budget before and after the call and to capture usage."""

    def __init__(self, inner: LLMProvider, cfg: dict, checkpoint):
        self.inner, self.cfg, self.checkpoint = inner, cfg, checkpoint
        self.name, self.model = inner.name, inner.model
        self.usage: LLMResponse | None = None

    def complete_structured(self, task, system, evidence_blocks, schema, params=None):
        limit = Decimal(str(self.cfg["per_run_budget_gbp"]))
        est = compute_cost(self.cfg, estimate_tokens_in(system, evidence_blocks), 0)
        if est > limit:
            raise BudgetExceeded("Estimated cost of this run exceeds the per-run budget.", details={"estimated_gbp": str(est), "per_run_budget_gbp": str(limit)})
        self.checkpoint()
        resp = self.inner.complete_structured(task, system, evidence_blocks, schema, params)
        self.usage = resp
        if compute_cost(self.cfg, resp.tokens_in, resp.tokens_out) > limit:
            raise BudgetExceeded("Actual cost of this run exceeded the per-run budget.", details={"per_run_budget_gbp": str(limit)})
        return resp


# ------------------------------------------------------------------------------------------------ start
def start_run(ctx: Ctx, agent_type: str, *, matter_id=None, contact_id=None, input: dict | None = None, idempotency_key: str | None = None,
              enqueue: bool = True) -> AgentRun:
    db = ctx.db
    ctx.require("ai.use")
    agent = get_agent(agent_type)
    cfg = ai_settings(db, ctx.firm_id)
    if not cfg.get("enabled") or agent_type not in cfg.get("allowed_agents", []):
        raise PermissionDenied("This agent is disabled for your firm.", code="agent_disabled")
    if idempotency_key:
        ex = db.execute(select(AgentRun).where(AgentRun.firm_id == ctx.firm_id, AgentRun.requested_by == ctx.user.id, AgentRun.idempotency_key == idempotency_key)).scalar_one_or_none()
        if ex:
            return ex
    input = input or {}
    if len(json.dumps(input, default=str)) > 30000:
        raise ValidationFailed("Run input is too large.")
    pol = policy.AGENT_POLICY[agent_type]
    mid = uuid.UUID(str(matter_id)) if matter_id else None
    cid = uuid.UUID(str(contact_id)) if contact_id else None
    if pol["needs_matter"] and not mid:
        raise ValidationFailed(f"The {agent.title} agent needs a matter.")
    if mid:
        m = db.get(Matter, mid)
        if not m or m.firm_id != ctx.firm_id:
            raise NotFound("Matter not found.")
        if not can_ai_retrieve(ctx, m):
            raise MatterAccessDenied("AI cannot be used on this matter by you (restricted, ethical wall, or AI retrieval disabled).", details={"reason": "ai_retrieval_not_permitted"})
    if agent_type == "intake":
        if not cid:
            raise ValidationFailed("The intake agent needs a contact.")
        ctx.require("clients.read")
        c = db.get(Contact, cid)
        if not c or c.firm_id != ctx.firm_id:
            raise NotFound("Contact not found.")
    check_budget(ctx, cfg)
    provider = get_provider(cfg)
    s = get_settings()
    run = AgentRun(firm_id=ctx.firm_id, requested_by=ctx.user.id, agent_type=agent_type, matter_id=mid, contact_id=cid,
                   scope={"matter_id": str(mid) if mid else None, "contact_id": str(cid) if cid else None, "document_ids": input.get("document_ids")},
                   input=input, provider=provider.name, model=provider.model, prompt_template_version=template_version(agent_type),
                   max_attempts=s.ai_max_attempts, timeout_seconds=s.ai_run_timeout_seconds, idempotency_key=idempotency_key, status="queued", approval_state="not_required")
    db.add(run)
    try:
        db.flush()
    except IntegrityError:  # concurrent duplicate idempotency key
        db.rollback()
        return db.execute(select(AgentRun).where(AgentRun.firm_id == ctx.firm_id, AgentRun.requested_by == ctx.user.id, AgentRun.idempotency_key == idempotency_key)).scalar_one()
    log_event(db, run, "state_change", "created -> queued", {"to": "queued"}, ctx.user.id)
    ctx.audit("agent.run_started", "agent_run", run.id, f"AI run started: {agent_type}", matter_id=mid, details={"agent": agent_type, "provider": provider.name, "model": provider.model})
    if enqueue:
        jobs.enqueue(db, firm_id=ctx.firm_id, kind="agent_run", payload={"run_id": str(run.id)}, idempotency_key=f"agent_run:{run.id}:{run.attempts}")
    return run


# ------------------------------------------------------------------------------------------------ analysis
def _load_locked(db: Session, run_id) -> AgentRun | None:
    return db.execute(select(AgentRun).where(AgentRun.id == run_id).with_for_update()).scalar_one_or_none()


def process_run(db: Session, run_id: uuid.UUID) -> AgentRun:
    run = _load_locked(db, run_id)
    if run is None:
        raise NotFound("Run not found.")
    if run.status != "queued":
        db.commit()  # release the row lock; duplicate job delivery is a no-op
        return run
    requester = db.get(User, run.requested_by)
    ctx = Ctx.for_user(db, requester, actor_type="agent")
    cfg = ai_settings(db, run.firm_id)
    run.attempts += 1
    run.started_at = run.started_at or now()
    _transition(db, run, "running", requester.id)
    db.commit()
    t0 = time.monotonic()
    rid = run.id

    def checkpoint() -> None:
        if db.execute(select(AgentRun.cancel_requested).where(AgentRun.id == rid)).scalar_one():
            raise RunCancelled()
        if time.monotonic() - t0 > run.timeout_seconds:
            raise RunTimeout(f"The run exceeded its {run.timeout_seconds}s timeout.")

    try:
        check_budget(ctx, {**cfg, "user_daily_runs": 10 ** 9})  # monthly budget re-check at start of work
        agent = get_agent(run.agent_type)
        provider = _Guarded(get_provider(cfg), cfg, checkpoint)
        tb = ToolBox(ctx, run, run.agent_type, checkpoint)
        result, resp = agent.run(tb, run.input or {}, provider)
        checkpoint()
        tin, tout = (resp.tokens_in, resp.tokens_out)
        run.tokens_in, run.tokens_out = tin, tout
        run.cost_gbp = compute_cost(cfg, tin, tout)
        run.source_versions = json.loads(json.dumps(tb.source_versions(), default=str))
        run.result = result
        for p in tb.proposals:
            db.add(AgentProposedAction(firm_id=run.firm_id, run_id=run.id, matter_id=run.matter_id, action_type=p["action_type"], summary=p["summary"], params=p["params"],
                                       params_hash=canonical_hash(p["params"]), evidence=p["evidence"], risk=p["risk"], status="proposed"))
        db.flush()
        log_event(db, run, "retrieval", f"Retrieved {len(tb.evidence)} evidence item(s)", {"count": len(tb.evidence), "by_type": result["evidence_summary"]["by_type"],
                                                                                              "document_ids": sorted({e.document_id for e in tb.evidence if e.document_id})}, requester.id)
        if not tb.proposals and cfg.get("auto_complete_readonly", True):
            run.approval_state = "not_required"
            _transition(db, run, "completed", requester.id, "read-only result; no review required by policy")
        else:
            run.approval_state = "pending"
            _transition(db, run, "awaiting_review", requester.id)
            notify(db, firm_id=run.firm_id, user_id=requester.id, kind="ai_review", title=f"AI draft awaiting review: {get_agent(run.agent_type).title}",
                   link=f"/ai/runs/{run.id}", matter_id=run.matter_id)
        db.commit()
    except RunCancelled:
        run.error = "cancelled by user"
        _transition(db, run, "cancelled", requester.id)
        db.commit()
    except (BudgetExceeded, PermissionDenied, NotFound, ValidationFailed, RunTimeout, AppError) as e:
        run.error = f"{e.code}: {e.message}"[:500]
        _transition(db, run, "failed", requester.id, e.code)
        db.commit()
    except ProviderError as e:
        _retry_or_fail(db, run, requester.id, f"provider_error: {e}")
    except Exception as e:  # noqa: BLE001
        db.rollback()
        run = db.get(AgentRun, rid)
        log.warning("agent run %s failed: %s", rid, type(e).__name__)  # never log content
        run.error = f"unexpected_error: {type(e).__name__}"
        if run.status == "running":
            _transition(db, run, "failed", requester.id, "unexpected_error")
        db.commit()
    return db.get(AgentRun, rid)


def _retry_or_fail(db: Session, run: AgentRun, uid, msg: str) -> None:
    run.error = msg[:500]
    if run.attempts < run.max_attempts:
        _transition(db, run, "queued", uid, f"transient failure; retry {run.attempts}/{run.max_attempts}")
        jobs.enqueue(db, firm_id=run.firm_id, kind="agent_run", payload={"run_id": str(run.id)}, idempotency_key=f"agent_run:{run.id}:{run.attempts}")
    else:
        _transition(db, run, "failed", uid, "retry limit reached")
    db.commit()


# ------------------------------------------------------------------------------------------------ access to runs
def visible_run(ctx: Ctx, run_id) -> AgentRun:
    run = ctx.db.get(AgentRun, uuid.UUID(str(run_id)))
    if not run or run.firm_id != ctx.firm_id:
        raise NotFound("Run not found.")
    if run.matter_id:
        m = ctx.db.get(Matter, run.matter_id)
        if not m or not can_access_matter(ctx, m):
            raise MatterAccessDenied("You do not have access to the matter this run relates to.")
        if run.requested_by != ctx.user.id and not ctx.has("ai.review"):
            raise PermissionDenied("Only the requester or an AI reviewer can open this run.")
    elif run.requested_by != ctx.user.id:
        raise PermissionDenied("This run is private to the person who started it.")
    return run


def runs_filter(ctx: Ctx):
    """SQL predicate for the runs a user may list."""
    from sqlalchemy import and_, or_

    mine = AgentRun.requested_by == ctx.user.id
    matter_ok = and_(AgentRun.matter_id.is_not(None), AgentRun.matter_id.in_(select(Matter.id).where(matter_clause(ctx))))
    reviewable = and_(matter_ok, True if ctx.has("ai.review") else False)
    # own runs are listed only while the matter (if any) is still accessible
    own_ok = and_(mine, or_(AgentRun.matter_id.is_(None), AgentRun.matter_id.in_(select(Matter.id).where(matter_clause(ctx)))))
    return and_(AgentRun.firm_id == ctx.firm_id, or_(own_ok, reviewable))


# ------------------------------------------------------------------------------------------------ human review
def _action(db: Session, run: AgentRun, action_id) -> AgentProposedAction:
    a = db.execute(select(AgentProposedAction).where(AgentProposedAction.id == uuid.UUID(str(action_id)), AgentProposedAction.run_id == run.id).with_for_update()).scalar_one_or_none()
    if not a:
        raise NotFound("Proposed action not found on this run.")
    return a


def _changed_fields(before: dict, after: dict) -> list[str]:
    return sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))


def edit_action(ctx: Ctx, run_id, action_id, params: dict, expected_version: int | None = None) -> AgentProposedAction:
    """Human correction. Preserves before/after; if the action was already approved, the approval is cleared and renewed approval is required."""
    ctx.require("ai.review")
    db = ctx.db
    run = visible_run(ctx, run_id)
    if run.status not in ("awaiting_review", "approved"):
        raise InvalidState(f"Actions can only be edited while the run is awaiting review (run is {run.status}).")
    a = _action(db, run, action_id)
    if expected_version is not None and a.version != expected_version:
        from app.errors import VersionConflict
        raise VersionConflict("This proposed action was changed by someone else. Reload and try again.")
    if a.status not in ("proposed", "approved"):
        raise InvalidState(f"A {a.status} action cannot be edited.")
    new = A.validate_params(a.action_type, params)
    if new == a.params:
        return a
    was_approved = a.status == "approved"
    a.edit_history = [*(a.edit_history or []), {"at": now().isoformat(), "by": str(ctx.user.id), "before": a.params, "after": new, "was_approved": was_approved}]
    fields = _changed_fields(a.params, new)
    a.params, a.params_hash, a.edit_count = new, canonical_hash(new), a.edit_count + 1
    if was_approved:
        a.status, a.approved_by, a.approved_at, a.approved_hash = "proposed", None, None, None
        if run.status == "approved":
            _transition(db, run, "awaiting_review", ctx.user.id, "approved action edited; renewed approval required")
            run.approval_state = "pending"
    log_event(db, run, "human_edit", "Proposed action edited by a reviewer", {"action_id": str(a.id), "action_type": a.action_type, "fields_changed": fields,
                                                                              "renewed_approval_required": was_approved, "edit_no": a.edit_count}, ctx.user.id)
    ctx.audit("agent.action_edited", "agent_proposed_action", a.id, "AI-proposed action edited by a human", matter_id=run.matter_id,
              details={"run_id": str(run.id), "fields_changed": fields, "renewed_approval_required": was_approved})
    db.flush()
    return a


def review_run(ctx: Ctx, run_id, decisions: list[dict], *, execute: bool = False) -> AgentRun:
    """decisions: [{action_id, decision: approve|reject, note?, params?}]. Atomic: any failure leaves nothing changed."""
    ctx.require("ai.review")
    db = ctx.db
    run = visible_run(ctx, run_id)
    run = _load_locked(db, run.id)
    if run.status != "awaiting_review":
        raise InvalidState(f"This run is {run.status}; only runs awaiting review can be reviewed.")
    actions = db.execute(select(AgentProposedAction).where(AgentProposedAction.run_id == run.id).order_by(AgentProposedAction.created_at)).scalars().all()
    if not actions:  # nothing proposed (policy required review): acknowledging completes the run
        _transition(db, run, "completed", ctx.user.id, "acknowledged by reviewer")
        run.approval_state, run.reviewed_by, run.reviewed_at = "not_required", ctx.user.id, now()
        db.commit()
        return run
    with db.begin_nested():
        for d in decisions:
            a = _action(db, run, d["action_id"])
            if a.status not in ("proposed", "approved"):
                raise InvalidState(f"Action is {a.status}; it can no longer be decided.")
            if d.get("params") is not None:
                edit_action(ctx, run.id, a.id, d["params"])
                db.refresh(a)
            if d["decision"] == "approve":
                A.check_action_permission(ctx, run, a)
                a.status, a.approved_by, a.approved_at = "approved", ctx.user.id, now()
                a.approved_hash = A.binding_hash(run, a)
                a.decision_note = d.get("note")
                kind, summ = "human_decision", "Action approved"
            elif d["decision"] == "reject":
                a.status, a.approved_by, a.approved_at, a.approved_hash = "rejected", None, None, None
                a.decision_note = d.get("note")
                kind, summ = "human_decision", "Action rejected"
            else:
                raise ValidationFailed("decision must be 'approve' or 'reject'.")
            log_event(db, run, kind, summ, {"action_id": str(a.id), "action_type": a.action_type, "decision": d["decision"], "params_hash": a.params_hash, "bound_hash": a.approved_hash}, ctx.user.id)
            ctx.audit(f"agent.action_{d['decision']}d", "agent_proposed_action", a.id, f"AI-proposed action {d['decision']}d", matter_id=run.matter_id,
                      details={"run_id": str(run.id), "action_type": a.action_type, "bound_hash": a.approved_hash})
        db.flush()
    actions = db.execute(select(AgentProposedAction).where(AgentProposedAction.run_id == run.id)).scalars().all()
    pending = [a for a in actions if a.status == "proposed"]
    approved = [a for a in actions if a.status == "approved"]
    rejected = [a for a in actions if a.status == "rejected"]
    run.reviewed_by, run.reviewed_at = ctx.user.id, now()
    if pending:
        run.approval_state = "pending"
    elif approved:
        run.approval_state = "approved" if not rejected else "partial"
        _transition(db, run, "approved", ctx.user.id)
        jobs.enqueue(db, firm_id=run.firm_id, kind="agent_execute", payload={"run_id": str(run.id)}, idempotency_key=f"agent_execute:{run.id}:{run.attempts}:{run.version}")
    else:
        run.approval_state = "rejected"
        _transition(db, run, "rejected", ctx.user.id)
    db.commit()
    if execute and run.status == "approved":
        return execute_run(db, run.id)
    return run


# ------------------------------------------------------------------------------------------------ execution
def execute_run(db: Session, run_id) -> AgentRun:
    """Apply APPROVED actions, each as the person who approved it. Idempotent: only a run in 'approved' state is executed, once."""
    run = _load_locked(db, run_id)
    if run is None:
        raise NotFound("Run not found.")
    if run.status != "approved":
        db.commit()  # release the row lock; nothing to do (already executing/completed, or not approved)
        return run
    _transition(db, run, "executing", run.reviewed_by)
    db.commit()  # durable 'executing' + released lock: concurrent callers now see a non-approved state and no-op
    rid = run.id
    results, failed = [], False
    ids = db.execute(select(AgentProposedAction.id).where(AgentProposedAction.run_id == rid, AgentProposedAction.status == "approved")
                     .order_by(AgentProposedAction.created_at)).scalars().all()
    for aid in ids:
        a = db.execute(select(AgentProposedAction).where(AgentProposedAction.id == aid).with_for_update()).scalar_one()
        if a.status != "approved":
            continue
        run = db.get(AgentRun, rid)
        err = None
        try:
            if A.binding_hash(run, a) != a.approved_hash:
                raise PermissionDenied("The action content no longer matches what was approved; a fresh approval is required.", code="approval_stale")
            approver = db.get(User, a.approved_by)
            actx = Ctx.for_user(db, approver)
            A.check_action_permission(actx, run, a)  # approver's CURRENT permissions
            a.status = "executing"
            db.flush()
            with db.begin_nested():
                res = A.execute(actx, run, a)
            a.status, a.result, a.executed_at = "executed", res, now()
            log_event(db, run, "execution", f"Executed {a.action_type}", {"action_id": str(a.id), "action_type": a.action_type, "result": res}, approver.id)
            results.append({"action_id": str(a.id), "action_type": a.action_type, "status": "executed", "result": res})
        except Exception as e:  # noqa: BLE001
            db.rollback()
            a = db.get(AgentProposedAction, aid)
            err = f"{getattr(e, 'code', type(e).__name__)}: {getattr(e, 'message', type(e).__name__)}"[:300]
            a.status, a.error = "failed", err
            failed = True
            log_event(db, db.get(AgentRun, rid), "execution", f"Execution failed for {a.action_type}", {"action_id": str(a.id), "action_type": a.action_type, "error": err[:120]}, None)
            results.append({"action_id": str(a.id), "action_type": a.action_type, "status": "failed", "error": err})
        db.commit()
    run = _load_locked(db, rid)
    run.execution_result = {"actions": results, "executed": sum(1 for r in results if r["status"] == "executed"), "failed": sum(1 for r in results if r["status"] == "failed")}
    _transition(db, run, "failed" if failed else "completed", run.reviewed_by)
    if failed:
        run.error = "one or more approved actions failed to execute"
    db.commit()
    return run


def execute_pending(db: Session, *, run_id=None, limit: int = 50) -> int:
    """Execute every approved run visible to this (firm-bound) session. Used by the worker, seed and tests."""
    q = select(AgentRun.id).where(AgentRun.status == "approved")
    if run_id:
        q = q.where(AgentRun.id == uuid.UUID(str(run_id)))
    n = 0
    for rid in db.execute(q.limit(limit)).scalars().all():
        execute_run(db, rid)
        n += 1
    return n


# ------------------------------------------------------------------------------------------------ cancel / retry
def cancel_run(ctx: Ctx, run_id) -> AgentRun:
    db = ctx.db
    run = visible_run(ctx, run_id)
    if run.requested_by != ctx.user.id and not ctx.has("ai.admin"):
        raise PermissionDenied("Only the requester can cancel this run.")
    run = _load_locked(db, run.id)
    if run.status in ("executing", "completed", "rejected", "cancelled", "failed"):
        raise InvalidState(f"A {run.status} run cannot be cancelled.")
    if run.status == "running":
        run.cancel_requested = True
        log_event(db, run, "state_change", "cancellation requested", {"cancel_requested": True}, ctx.user.id)
    else:
        for a in db.execute(select(AgentProposedAction).where(AgentProposedAction.run_id == run.id, AgentProposedAction.status.in_(["proposed", "approved"]))).scalars():
            a.status, a.approved_hash = "superseded", None
        _transition(db, run, "cancelled", ctx.user.id)
        run.error = "cancelled by user"
    ctx.audit("agent.run_cancelled", "agent_run", run.id, "AI run cancelled", matter_id=run.matter_id, details={"run_id": str(run.id)})
    db.flush()
    return run


def retry_run(ctx: Ctx, run_id, *, enqueue: bool = True) -> AgentRun:
    db = ctx.db
    run = visible_run(ctx, run_id)
    if run.requested_by != ctx.user.id and not ctx.has("ai.review"):
        raise PermissionDenied("Only the requester or a reviewer can retry this run.")
    run = _load_locked(db, run.id)
    if run.status != "failed":
        raise InvalidState("Only failed runs can be retried.")
    if run.attempts >= run.max_attempts:
        raise InvalidState(f"Retry limit reached ({run.attempts}/{run.max_attempts}).", code="retry_limit_reached")
    if run.result is None:  # analysis failed: run again
        run.error, run.cancel_requested = None, False
        _transition(db, run, "queued", ctx.user.id, "manual retry")
        if enqueue:
            jobs.enqueue(db, firm_id=run.firm_id, kind="agent_run", payload={"run_id": str(run.id)}, idempotency_key=f"agent_run:{run.id}:{run.attempts}")
    else:  # execution failed: re-attempt only the failed actions (hash and approver permissions are re-verified at execution)
        failed = db.execute(select(AgentProposedAction).where(AgentProposedAction.run_id == run.id, AgentProposedAction.status == "failed")).scalars().all()
        for a in failed:
            a.status, a.error = "approved", None
        run.attempts += 1
        run.error = None
        _transition(db, run, "approved", ctx.user.id, "manual retry of failed actions")
        if enqueue:
            jobs.enqueue(db, firm_id=run.firm_id, kind="agent_execute", payload={"run_id": str(run.id)}, idempotency_key=f"agent_execute:{run.id}:{run.attempts}:{run.version}")
    ctx.audit("agent.run_retried", "agent_run", run.id, "AI run retried", matter_id=run.matter_id, details={"run_id": str(run.id), "attempt": run.attempts})
    db.flush()
    return run
