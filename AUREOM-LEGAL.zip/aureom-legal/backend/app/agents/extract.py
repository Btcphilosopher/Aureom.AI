"""Deterministic text heuristics used by the local MockProvider (and by the injection detector).
Every returned `quote` is a VERBATIM substring of the input text so the verifier can check it."""
from __future__ import annotations

import calendar
import re
from datetime import date, timedelta

MONTHS = {m.lower(): i for i, m in enumerate(calendar.month_name) if m}
_MONTH_RE = "|".join(calendar.month_name[1:])
WORD_NUMS = {w: i for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty".split())}
WORD_NUMS.update({"thirty": 30, "forty": 40, "sixty": 60, "ninety": 90})

_SPLIT = re.compile(r"\n+|(?<=[.;!?])\s+(?=[A-Z0-9(“\"'‘])")
DATE_RES = [
    re.compile(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?\s+({_MONTH_RE})\s+(\d{{4}})\b"),
    re.compile(rf"\b({_MONTH_RE})\s+(\d{{1,2}})(?:st|nd|rd|th)?,?\s+(\d{{4}})\b"),
    re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b"),
    re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b"),
]
REL_RE = re.compile(
    r"within\s+(\d+|[a-z]+)\s+(?:\(\d+\)\s+)?(business |working |calendar )?(days?|weeks?|months?)\s+(?:of|after|from|following)\s+([^.;,\n]{3,80})", re.I)
AMOUNT_RE = re.compile(r"£\s?\d[\d,]*(?:\.\d{2})?(?:\s?(?:million|m|k)\b)?")
NOTICE_RE = re.compile(r"(\d+|[a-z]+)\s*(?:\(\d+\)\s*)?(calendar |business |working )?(days?|weeks?|months?)['’]?\s+(?:written\s+|prior\s+|prior written\s+)?notice", re.I)
ORG_RE = re.compile(r"\b([A-Z][A-Za-z0-9&'’.\-]*(?:\s+[A-Z&][A-Za-z0-9&'’.\-]*){0,5}\s+(?:Limited|Ltd|LLP|PLC|plc|LTD|Inc\.?))")
PERSON_RE = re.compile(r"\b((?:Mr|Mrs|Ms|Miss|Dr|Mx)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)")
DEFINED_RE = re.compile(r"\(\s*(?:the\s+)?[\"“']([A-Z][A-Za-z ]{1,40})[\"”']\s*\)")
LAW_RE = re.compile(r"governed by (?:and construed in accordance with )?the laws? of ([A-Z][A-Za-z &]+?)(?:[.,;]|\s+and\b|$)")
OBLIGATION_RE = re.compile(r"\b(shall|must|agrees to|undertakes to|is required to|will pay)\b", re.I)
HEADING_RE = re.compile(r"^\s*(?:clause\s+)?(\d+(?:\.\d+)*)[.)]?\s+([A-Z][A-Za-z ,&\-/]{2,70})\s*$")
DEADLINE_CUES = ("no later than", "on or before", "deadline", "expire", "expiry", "close of business", "long stop", "long-stop",
                 "completion", "must be served", "must be paid", "shall be paid", "by no later", "time is of the essence")

INJECTION_PATTERNS: dict[str, re.Pattern] = {
    "override_instructions": re.compile(r"\b(ignore|disregard|forget|override)\s+(all\s+|any\s+)?(the\s+)?(previous|prior|above|earlier|system)\s+(instructions?|rules|prompts?|messages?)", re.I),
    "system_role_marker": re.compile(r"(^|\n)\s*(system|assistant|developer)\s*(prompt|message)?\s*:", re.I),
    "role_reassignment": re.compile(r"\byou\s+(are\s+now|must\s+now|will\s+now|should\s+now)\b", re.I),
    "exfiltrate_documents": re.compile(r"\b(forward|email|e-mail|send|share|upload|post)\s+(all|every|any|the|these|those)?\s*(documents?|files?|emails?|records|data|contents?)\b[^.\n]{0,40}\bto\b", re.I),
    "send_to_address": re.compile(r"\b(send|email|e-mail|forward)\b[^.\n]{0,80}[\w.+-]+@[\w-]+\.[\w.]+", re.I),
    "declare_conflict_free": re.compile(r"\bmark\b[^.\n]{0,40}\b(conflict[- ]free|conflicts? (?:as )?cleared|cleared)\b", re.I),
    "move_money": re.compile(r"\b(transfer|remit|wire|release)\b[^.\n]{0,50}£\s?\d|\bpay\b[^.\n]{0,30}£\s?\d[^.\n]{0,40}\bto\s+(?:account|sort code|iban)", re.I),
    "change_bank_details": re.compile(r"\bchange\b[^.\n]{0,30}\bbank (?:details|account)\b", re.I),
    "secrecy_instruction": re.compile(r"\bdo not (tell|inform|notify|mention|alert)\b", re.I),
    "reveal_prompt": re.compile(r"\breveal\b[^.\n]{0,30}\b(system prompt|instructions)\b", re.I),
}


def detect_injection(text: str) -> list[str]:
    """Return labels of instruction-like patterns found. The text is still treated strictly as data."""
    return [label for label, rx in INJECTION_PATTERNS.items() if rx.search(text or "")]


def segments(text: str) -> list[str]:
    out, pos = [], 0
    for m in _SPLIT.finditer(text):
        seg = text[pos:m.start()].strip()
        if seg:
            out.append(seg)
        pos = m.end()
    tail = text[pos:].strip()
    if tail:
        out.append(tail)
    merged: list[str] = []  # re-join bare clause numbers ("1.") split from their heading
    for seg in out:
        if merged and re.fullmatch(r"(?:clause\s+)?\d+(?:\.\d+)*\.?", merged[-1], re.I):
            merged[-1] = f"{merged[-1]} {seg}"
        else:
            merged.append(seg)
    return merged


def _mk(y, m, d) -> date | None:
    try:
        return date(int(y), int(m), int(d))
    except ValueError:
        return None


def find_dates(seg: str) -> list[tuple[date, str]]:
    found: list[tuple[date, str]] = []
    for i, rx in enumerate(DATE_RES):
        for m in rx.finditer(seg):
            g = m.groups()
            if i == 0:
                d = _mk(g[2], MONTHS[g[1].lower()], g[0])
            elif i == 1:
                d = _mk(g[2], MONTHS[g[0].lower()], g[1])
            elif i == 2:
                d = _mk(g[0], g[1], g[2])
            else:
                d = _mk(g[2], g[1], g[0])  # UK day/month/year
            if d:
                found.append((d, m.group(0)))
    return found


def to_int(tok: str) -> int | None:
    tok = tok.lower()
    return int(tok) if tok.isdigit() else WORD_NUMS.get(tok)


def add_months(d: date, n: int) -> date:
    y, mth = divmod(d.month - 1 + n, 12)
    y, mth = d.year + y, mth + 1
    return date(y, mth, min(d.day, calendar.monthrange(y, mth)[1]))


def find_relative(seg: str) -> list[dict]:
    out = []
    for m in REL_RE.finditer(seg):
        n = to_int(m.group(1))
        if n is None:
            continue
        out.append({"n": n, "daytype": (m.group(2) or "").strip().lower() or "calendar", "unit": m.group(3).lower().rstrip("s"),
                    "anchor": m.group(4).strip(), "matched": m.group(0)})
    return out


def resolve_relative(rel: dict, anchor_date: date) -> date | None:
    """Calendar arithmetic only. Business-day offsets are NOT resolved here (needs a configured calendar)."""
    if rel["daytype"] in ("business", "working"):
        return None
    if rel["unit"] == "day":
        return anchor_date + timedelta(days=rel["n"])
    if rel["unit"] == "week":
        return anchor_date + timedelta(weeks=rel["n"])
    return add_months(anchor_date, rel["n"])


def has_deadline_cue(seg: str) -> bool:
    low = seg.lower()
    return any(c in low for c in DEADLINE_CUES)


def short(s: str, n: int = 110) -> str:
    s = " ".join(s.split())
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"
