"""Proposed-action parameter validation, approval-binding hash, permission checks and the executors that apply an APPROVED action.
Executors never confirm deadlines, send communications, share documents, issue invoices or touch money."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field, ValidationError
from sqlalchemy import select

from app.agents.policy import ACTION_PERMISSIONS
from app.deps import Ctx
from app.errors import MatterAccessDenied, NotFound, PermissionDenied, ValidationFailed
from app.models import (ChronologyEntry, Contact, Correspondence, Deadline, Document, DocumentChunk, DocumentVersion, Matter, RateCard,
                        RateCardEntry, Task, TimeEntry, User)
from app.money import time_amount
from app.permissions import can_access_matter
from app.security import canonical_hash, sha256_hex
from app.storage import get_storage


class TaskP(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    description: str | None = Field(None, max_length=4000)
    due_at: datetime | None = None
    priority: Literal["low", "normal", "high", "urgent"] = "normal"
    assignee_id: uuid.UUID | None = None


class DeadlineP(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    due_date: date
    source_document_id: uuid.UUID | None = None
    source_version_id: uuid.UUID | None = None
    source_passage: str | None = Field(None, max_length=2000)
    source_ref: dict = {}
    assumptions: str | None = Field(None, max_length=2000)
    timezone: str = "Europe/London"
    date_basis: Literal["explicit", "inferred"] = "explicit"


class ChronEntryP(BaseModel):
    event_date: date | None = None
    date_text: str | None = Field(None, max_length=120)
    date_basis: Literal["explicit", "inferred"] = "explicit"
    description: str = Field(min_length=3, max_length=2000)
    source: dict = {}


class ChronologyP(BaseModel):
    entries: list[ChronEntryP] = Field(min_length=1, max_length=100)


class CorrespondenceP(BaseModel):
    subject: str = Field(min_length=1, max_length=500)
    body_text: str = Field(min_length=1, max_length=50000)
    to_addrs: list[str] = []
    cc_addrs: list[str] = []
    thread_id: str | None = None
    template_id: uuid.UUID | None = None


class DocumentDraftP(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    content: str = Field(min_length=1, max_length=200000)
    doc_type: str = "letter"
    template_id: uuid.UUID | None = None


class TimeEntryP(BaseModel):
    work_date: date
    minutes: int = Field(gt=0, le=1440)
    narrative: str = Field(min_length=3, max_length=2000)
    billable: bool = True


class TimeNarrativeP(BaseModel):
    time_entry_id: uuid.UUID
    narrative: str = Field(min_length=3, max_length=2000)


CONTACT_FIELD_WHITELIST = {"first_name", "last_name", "email", "phone", "date_of_birth", "preferred_channel", "title", "org_name", "company_number", "aliases"}


class ContactUpdateP(BaseModel):
    contact_id: uuid.UUID
    changes: dict = Field(min_length=1)


MODELS = {"create_task": TaskP, "suggest_deadline": DeadlineP, "add_chronology_entries": ChronologyP, "create_correspondence_draft": CorrespondenceP,
          "create_document_draft": DocumentDraftP, "create_time_entry": TimeEntryP, "update_time_narrative": TimeNarrativeP, "update_contact_fields": ContactUpdateP}


def validate_params(action_type: str, params: dict) -> dict:
    model = MODELS.get(action_type)
    if not model:
        raise ValidationFailed(f"Unknown action type '{action_type}'.")
    try:
        out = model.model_validate(params).model_dump(mode="json", exclude_none=True)
    except ValidationError as e:
        raise ValidationFailed("Invalid action parameters.", details={"errors": [{"loc": list(x["loc"]), "msg": x["msg"]} for x in e.errors()][:10]}) from e
    if action_type == "update_contact_fields":
        bad = sorted(set(out["changes"]) - CONTACT_FIELD_WHITELIST)
        if bad:
            raise ValidationFailed("Field(s) not permitted for AI-proposed updates.", details={"fields": bad, "allowed": sorted(CONTACT_FIELD_WHITELIST)})
    return out


def binding_hash(run, action) -> str:
    """Approval binds to exactly this content; any change to params/type/matter/run changes the hash."""
    return canonical_hash({"run": str(run.id), "action_type": action.action_type, "params": action.params, "matter": str(run.matter_id) if run.matter_id else None})


def check_action_permission(ctx: Ctx, run, action) -> None:
    """Enforced when approving AND again when executing, for the person acting at that moment."""
    ctx.require("ai.review", *ACTION_PERMISSIONS.get(action.action_type, ["admin.settings"]))
    if run.matter_id:
        m = ctx.db.get(Matter, run.matter_id)
        if not m or not can_access_matter(ctx, m):
            raise MatterAccessDenied("You no longer have access to this matter.")
    if action.action_type in ("create_time_entry", "update_time_narrative") and ctx.user.id != run.requested_by:
        raise PermissionDenied("Only the fee earner whose time it is may approve AI-suggested time entries.", code="own_time_only")


# ----------------------------------------------------------------------------------------------------- executors
def _utc(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def execute(ctx: Ctx, run, action) -> dict:
    fn = _EXEC[action.action_type]
    res = fn(ctx, run, action, action.params)
    ctx.audit("agent.action_executed", "agent_proposed_action", action.id, f"Applied AI-proposed change: {action.action_type}", matter_id=run.matter_id,
              details={"run_id": str(run.id), "action_type": action.action_type, "result": res})
    return res


def _x_task(ctx, run, action, p):
    assignee = uuid.UUID(p["assignee_id"]) if p.get("assignee_id") else run.requested_by
    u = ctx.db.get(User, assignee)
    if not u or u.firm_id != ctx.firm_id:
        raise ValidationFailed("Assignee not found.")
    t = Task(firm_id=ctx.firm_id, matter_id=run.matter_id, title=p["title"], description=p.get("description"), assignee_id=assignee, created_by=ctx.user.id,
             due_at=_utc(datetime.fromisoformat(p["due_at"].replace("Z", "+00:00"))) if p.get("due_at") else None, priority=p.get("priority", "normal"),
             source="agent", agent_run_id=run.id)
    ctx.db.add(t); ctx.db.flush()
    return {"type": "task", "id": str(t.id)}


def _x_deadline(ctx, run, action, p):
    if p.get("source_document_id"):
        d = ctx.db.get(Document, uuid.UUID(p["source_document_id"]))
        if not d or d.firm_id != ctx.firm_id or d.matter_id != run.matter_id:
            raise ValidationFailed("Source document is not on this matter.")
    assumptions = p.get("assumptions") or ("Suggested by an AI agent from the cited passage. Date arithmetic and legal effect have NOT been verified; "
                                           "a solicitor must confirm before this is treated as authoritative.")
    m = ctx.db.get(Matter, run.matter_id)
    dl = Deadline(firm_id=ctx.firm_id, matter_id=run.matter_id, title=p["title"], due_date=date.fromisoformat(p["due_date"]), timezone=p.get("timezone", "Europe/London"),
                  origin="ai_suggestion", status="suggested", jurisdiction=m.jurisdiction if m else None, assumptions=assumptions,
                  source_document_id=uuid.UUID(p["source_document_id"]) if p.get("source_document_id") else None,
                  source_version_id=uuid.UUID(p["source_version_id"]) if p.get("source_version_id") else None,
                  source_passage=p.get("source_passage"), source_ref={**(p.get("source_ref") or {}), "date_basis": p.get("date_basis", "explicit")},
                  agent_run_id=run.id, suggested_by=run.requested_by,
                  calculation={"method": "extracted_from_text" if p.get("date_basis", "explicit") == "explicit" else "inferred_from_text", "run_id": str(run.id)})
    ctx.db.add(dl); ctx.db.flush()
    return {"type": "deadline", "id": str(dl.id), "status": "suggested"}


def _x_chronology(ctx, run, action, p):
    ids = []
    for e in p["entries"]:
        ce = ChronologyEntry(firm_id=ctx.firm_id, matter_id=run.matter_id, event_date=date.fromisoformat(e["event_date"]) if e.get("event_date") else None,
                             date_text=e.get("date_text"), date_basis=e.get("date_basis", "explicit"), description=e["description"], source=e.get("source") or {},
                             origin="agent", agent_run_id=run.id, status="edited" if action.edit_count else "accepted", created_by=ctx.user.id,
                             edited_by=ctx.user.id if action.edit_count else None)
        ctx.db.add(ce); ctx.db.flush(); ids.append(str(ce.id))
    return {"type": "chronology_entries", "ids": ids}


def _x_correspondence(ctx, run, action, p):
    requester = ctx.db.get(User, run.requested_by)
    c = Correspondence(firm_id=ctx.firm_id, matter_id=run.matter_id, thread_id=p.get("thread_id"), direction="outbound", channel="email",
                       from_addr=requester.email, to_addrs=p.get("to_addrs", []), cc_addrs=p.get("cc_addrs", []), subject=p["subject"], body_text=p["body_text"],
                       status="draft", client_visible=False, created_by=ctx.user.id, agent_run_id=run.id, meta={"ai_draft": True, "template_id": p.get("template_id")})
    ctx.db.add(c); ctx.db.flush()
    return {"type": "correspondence_draft", "id": str(c.id), "status": "draft", "sent": False}


def _x_document(ctx, run, action, p):
    content = p["content"].encode("utf-8")
    sha = sha256_hex(content)
    d = Document(firm_id=ctx.firm_id, matter_id=run.matter_id, title=p["title"], doc_type=p.get("doc_type", "letter"), status="draft", created_by=ctx.user.id,
                 source="agent_draft", meta={"agent_run_id": str(run.id), "template_id": p.get("template_id")}, tags=["ai-draft"])
    ctx.db.add(d); ctx.db.flush()
    key = f"{ctx.firm_id}/{run.matter_id}/{d.id}/v1/{sha}"
    get_storage().put(key, content, "text/plain")
    fname = "".join(ch if ch.isalnum() else "-" for ch in p["title"].lower())[:60].strip("-") or "draft"
    v = DocumentVersion(firm_id=ctx.firm_id, document_id=d.id, version_no=1, storage_key=key, sha256=sha, size_bytes=len(content), content_type="text/plain",
                        original_filename=f"{fname}.txt", author_id=ctx.user.id, change_note="AI-assisted draft (approved by a human reviewer)",
                        scan_status="clean", scan_detail="generated internally by the application; not an uploaded file", ocr_status="not_needed",
                        index_status="done", page_count=1)
    ctx.db.add(v); ctx.db.flush()
    d.current_version_id, d.current_version_no = v.id, 1
    for i, para in enumerate([x for x in p["content"].split("\n\n") if x.strip()], start=1):
        ctx.db.add(DocumentChunk(firm_id=ctx.firm_id, version_id=v.id, document_id=d.id, matter_id=run.matter_id, ordinal=i, page=1, paragraph=i, text=para.strip()))
    ctx.db.flush()
    return {"type": "document_draft", "id": str(d.id), "version_id": str(v.id), "status": "draft"}


def _rate_for(ctx, matter, user) -> Decimal:
    card_id = matter.rate_card_id
    if not card_id:
        card = ctx.db.execute(select(RateCard).where(RateCard.firm_id == ctx.firm_id, RateCard.is_default.is_(True), RateCard.is_active.is_(True))).scalars().first()
        card_id = card.id if card else None
    if not card_id:
        return Decimal("0.00")
    rows = ctx.db.execute(select(RateCardEntry).where(RateCardEntry.rate_card_id == card_id)).scalars().all()
    for r in rows:
        if r.user_id == user.id:
            return r.hourly_rate
    for r in rows:
        if r.user_id is None and user.grade and r.grade == user.grade:
            return r.hourly_rate
    return Decimal("0.00")


def _x_time(ctx, run, action, p):
    m = ctx.db.get(Matter, run.matter_id)
    u = ctx.db.get(User, run.requested_by)
    rate = _rate_for(ctx, m, u)
    te = TimeEntry(firm_id=ctx.firm_id, matter_id=m.id, user_id=u.id, work_date=date.fromisoformat(p["work_date"]), minutes=p["minutes"], narrative=p["narrative"],
                   rate=rate, amount=time_amount(p["minutes"], rate), currency=m.currency, billable=p.get("billable", True), status="draft", source="agent_suggestion",
                   agent_run_id=run.id)
    ctx.db.add(te); ctx.db.flush()
    return {"type": "time_entry", "id": str(te.id), "status": "draft", "minutes_source": "supplied by the fee earner"}


def _x_time_narrative(ctx, run, action, p):
    te = ctx.db.get(TimeEntry, uuid.UUID(p["time_entry_id"]))
    if not te or te.firm_id != ctx.firm_id or te.matter_id != run.matter_id or te.user_id != run.requested_by:
        raise NotFound("Time entry not found.")
    if te.status not in ("draft", "submitted"):
        raise ValidationFailed("Only unbilled draft/submitted entries can be edited.")
    te.narrative = p["narrative"]
    ctx.db.flush()
    return {"type": "time_entry", "id": str(te.id), "updated": ["narrative"]}


def _x_contact(ctx, run, action, p):
    c = ctx.db.get(Contact, uuid.UUID(p["contact_id"]))
    if not c or c.firm_id != ctx.firm_id:
        raise NotFound("Contact not found.")
    changed = []
    for k, v in p["changes"].items():
        if k == "date_of_birth":
            v = date.fromisoformat(v)
        if k == "aliases":
            v = [str(x) for x in v]
        setattr(c, k, v)
        changed.append(k)
    if "first_name" in p["changes"] or "last_name" in p["changes"]:
        if c.kind == "individual":
            c.display_name = " ".join(x for x in (c.first_name, c.last_name) if x) or c.display_name
    ctx.db.flush()
    return {"type": "contact", "id": str(c.id), "fields_changed": changed}  # field names only; values are personal data


_EXEC = {"create_task": _x_task, "suggest_deadline": _x_deadline, "add_chronology_entries": _x_chronology, "create_correspondence_draft": _x_correspondence,
         "create_document_draft": _x_document, "create_time_entry": _x_time, "update_time_narrative": _x_time_narrative, "update_contact_fields": _x_contact}
