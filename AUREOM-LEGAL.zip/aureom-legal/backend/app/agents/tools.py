"""Policy-guarded tool layer. Agents (and the model's requested tool calls) can reach data/changes ONLY through ToolBox.call:
allowlist check -> prohibited check -> requester permission check -> retrieval/proposal -> event + audit. Nothing here applies a change."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Callable

from app.agents import actions as A
from app.agents import policy, verify
from app.agents.extract import detect_injection
from app.agents.retrieval import Evidence, Retriever
from app.deps import Ctx
from app.errors import AppError, MatterAccessDenied, PermissionDenied, ValidationFailed
from app.models import AgentRunEvent

_FORBIDDEN_DETAIL_KEYS = {"text", "quote", "body", "body_text", "content", "passage", "statement", "narrative", "description", "query", "excerpt"}


def _safe(details: dict | None) -> dict:
    """Events hold ids, counts and labels only - never document/email/draft text."""
    def s(v, k=None):
        if k and k.lower() in _FORBIDDEN_DETAIL_KEYS:
            return "[omitted]"
        if isinstance(v, dict):
            return {kk: s(x, kk) for kk, x in v.items()}
        if isinstance(v, (list, tuple)):
            return [s(x) for x in v][:50]
        if isinstance(v, str):
            return v[:120]
        return v
    return s(details or {})


def log_event(db, run, kind: str, summary: str, details: dict | None = None, actor_user_id=None) -> AgentRunEvent:
    ev = AgentRunEvent(firm_id=run.firm_id, run_id=run.id, kind=kind, summary=summary[:500], details=_safe(details), actor_user_id=actor_user_id,
                       created_at=datetime.now(timezone.utc))  # clock time (not transaction time) so the event order is faithful
    db.add(ev)
    db.flush()
    return ev


class ToolBox:
    def __init__(self, ctx: Ctx, run, agent_type: str, checkpoint: Callable[[], None] | None = None):
        self.ctx, self.run, self.agent_type = ctx, run, agent_type
        self.retr = Retriever(ctx, run.matter_id)
        self.checkpoint = checkpoint or (lambda: None)
        self.evidence: list[Evidence] = []
        self.index: dict[tuple[str, str], Evidence] = {}
        self.by_ref: dict[str, Evidence] = {}
        self.injection: list[dict] = []
        self.unavailable: dict[str, str] = {}
        self.proposals: list[dict] = []
        self.rejected: list[dict] = []
        self.notes: dict = {}

    # ---------------------------------------------------------------- evidence registry
    def register(self, ev: Evidence) -> Evidence:
        if ev.key in self.index:
            return self.index[ev.key]
        ev.ref = f"E{len(self.evidence) + 1}"
        self.evidence.append(ev); self.index[ev.key] = ev; self.by_ref[ev.ref] = ev
        if ev.source_type not in ("matter", "activity", "time_entry", "task", "deadline"):
            labels = detect_injection(ev.text)
            if labels:
                self.injection.append({"ref": ev.ref, "source_type": ev.source_type, "source_id": ev.source_id, "patterns": labels, "citation": ev.citation(None)})
                log_event(self.ctx.db, self.run, "injection_flag", "Instruction-like text found in retrieved content; treated as data only",
                          {"ref": ev.ref, "source_type": ev.source_type, "source_id": ev.source_id, "patterns": labels}, self.ctx.user.id)
        return ev

    def cite(self, ref: str, quote: str | None) -> dict:
        ev = self.by_ref.get(ref)
        if ev is None:
            return {"source_type": None, "source_id": str(ref), "quote": quote, "ref": str(ref), "invalid": True}
        return ev.citation(quote)

    def cite_many(self, items: list[dict] | None) -> list[dict]:
        return [self.cite(i.get("ref", ""), i.get("quote")) for i in (items or [])]

    def evidence_blocks(self) -> list[dict]:
        return [{"ref": e.ref, "source_type": e.source_type, "source_id": e.source_id, "text": e.text, "title": e.title, "document_id": e.document_id, "version_id": e.version_id,
                 "version_no": e.version_no, "page": e.page, "paragraph": e.paragraph, "meta": e.meta} for e in self.evidence]

    def source_versions(self) -> list[dict]:
        seen, out = set(), []
        for e in self.evidence:
            if e.source_type == "document_chunk":
                k = ("document", e.document_id, e.version_id)
                if k in seen:
                    continue
                seen.add(k); out.append({"type": "document", "id": e.document_id, "version_id": e.version_id, "version_no": e.version_no, "title": e.title})
            elif e.source_type not in ("user_input",):
                k = (e.source_type, e.source_id, None)
                if k in seen:
                    continue
                seen.add(k); out.append({"type": e.source_type, "id": e.source_id, "version_id": e.version_id, "version_no": e.version_no})
        return out

    # ---------------------------------------------------------------- guarded dispatch
    def _deny(self, tool: str, why: str, exc: AppError) -> None:
        log_event(self.ctx.db, self.run, "policy_denied", f"Tool '{tool}' denied: {why}", {"tool": tool, "reason": why, "agent": self.agent_type}, self.ctx.user.id)
        self.ctx.audit("agent.tool_denied", "agent_run", self.run.id, f"AI tool call denied: {tool}", matter_id=self.run.matter_id,
                       details={"tool": tool, "reason": why, "agent": self.agent_type, "run_id": str(self.run.id)})
        self.ctx.db.commit()  # evidence of the denial is durable even if the run then fails
        raise exc

    def call(self, tool: str, **kwargs):
        self.checkpoint()
        try:
            policy.check_tool_allowed(self.agent_type, tool)
        except policy.PolicyDenied as e:
            self._deny(tool, e.details.get("reason", "denied"), e)
        # permissions of the REQUESTING user, enforced at execution time of the tool
        needed = policy.TOOL_PERMISSIONS.get(tool)
        if needed is None and tool in policy.TOOL_TO_ACTION:
            needed = policy.ACTION_PERMISSIONS[policy.TOOL_TO_ACTION[tool]]
        try:
            self.ctx.require(*(needed or []))
        except PermissionDenied as e:
            self._deny(tool, "requester_lacks_permission", e)
        try:
            out = getattr(self, f"_t_{tool}")(**kwargs)
        except TypeError as e:  # arguments the tool does not accept (e.g. model-invented parameters)
            raise ValidationFailed(f"Invalid arguments for tool '{tool}'.", details={"tool": tool, "reason": "invalid_arguments"}) from e
        except MatterAccessDenied as e:
            self._deny(tool, "matter_access", e)
        except policy.PolicyDenied as e:
            self._deny(tool, e.details.get("reason", "denied"), e)
        log_event(self.ctx.db, self.run, "tool_call", f"Tool call: {tool}",
                  {"tool": tool, "args": sorted(k for k in kwargs), "returned": len(out) if isinstance(out, (list, tuple)) else 1}, self.ctx.user.id)
        self.ctx.audit("agent.tool_call", "agent_run", self.run.id, f"AI tool call: {tool}", matter_id=self.run.matter_id,
                       details={"tool": tool, "run_id": str(self.run.id), "agent": self.agent_type})
        self.ctx.db.commit()  # keep transactions short: the per-firm audit-chain lock must not be held across slow model calls
        return out

    def read(self, tool: str, **kwargs):
        """Read-tool wrapper that degrades gracefully when the *role* lacks a permission (recorded as unavailable evidence).
        Matter-level denial (restricted/ethical wall/AI blocked) is NOT swallowed."""
        try:
            return self.call(tool, **kwargs)
        except MatterAccessDenied:
            raise
        except policy.PolicyDenied:
            raise
        except PermissionDenied as e:
            self.unavailable[tool] = ", ".join(e.details.get("required", [])) or "permission"
            return []

    # ---------------------------------------------------------------- read tools
    def _reg(self, items):
        return [self.register(i) for i in items]

    def _t_get_matter(self):
        return self._reg(self.retr.matter_evidence())

    def _t_list_matter_documents(self):
        return self._reg(self.retr.documents())

    def _t_read_document_chunks(self, document_ids=None):
        ev, stats = self.retr.chunks(document_ids)
        self.notes["chunks"] = stats
        return self._reg(ev)

    def _t_list_matter_tasks(self):
        return self._reg(self.retr.tasks())

    def _t_list_matter_deadlines(self):
        return self._reg(self.retr.deadlines())

    def _t_list_correspondence(self, limit=30):
        return self._reg(self.retr.correspondence(limit))

    def _t_list_time_entries(self, date_from=None, date_to=None):
        return self._reg(self.retr.time_entries(date_from, date_to))

    def _t_list_activity(self, date_from=None, date_to=None):
        return self._reg(self.retr.activity(date_from, date_to))

    def _t_search_knowledge(self, query=None, practice_area=None, limit=5):
        return self._reg(self.retr.knowledge(query, practice_area, limit))

    def _t_list_approved_templates(self, template_id=None, doc_types=None):
        ev, info = self.retr.templates(template_id, set(doc_types) if doc_types else None)
        self.notes["templates"] = info
        return self._reg(ev)

    def _t_get_contact(self, contact_id):
        if str(contact_id) != str(self.run.contact_id):
            raise policy.PolicyDenied("Contact is outside the scope of this run.", details={"reason": "out_of_scope"})
        return self._reg([self.retr.contact(contact_id)])

    def _t_get_onboarding_form(self, contact_id):
        if str(contact_id) != str(self.run.contact_id):
            raise policy.PolicyDenied("Contact is outside the scope of this run.", details={"reason": "out_of_scope"})
        ev, info = self.retr.onboarding_form(contact_id)
        self.notes["onboarding"] = info
        return self._reg(ev)

    def _t_external_legal_research(self, query):
        from app.integrations.legal_research import get_legal_research

        prov = get_legal_research()
        info = prov.info()
        if not info.available:
            self.notes["external_research"] = {"available": False, "reason": info.setup_hint, "provider": info.provider}
            return []
        res = prov.search(query)
        self.notes["external_research"] = {"available": True, "source": res["source"], "retrieved_at": res["retrieved_at"], "provider": info.provider}
        return self._reg([Evidence("external_research", f"ext:{i}:{hash(it['citation']) & 0xffffff}", f"{it['title']}\n{it['excerpt']}", title=it["title"],
                                   meta={"source": res["source"], "retrieved_at": res["retrieved_at"], "source_ref": it.get("url")}) for i, it in enumerate(res["items"])])

    # ---------------------------------------------------------------- proposal tools (record only; never apply)
    def _propose(self, tool: str, args: dict):
        action_type = policy.TOOL_TO_ACTION[tool]
        args = dict(args)
        ev_in = args.pop("evidence", []) or []
        cites = self.cite_many(ev_in)
        bad = [c for c in cites if not verify.check_citation(c, self.index)[0]]
        if bad or (action_type in ("suggest_deadline", "add_chronology_entries") and not cites):
            self.rejected.append({"tool": tool, "reason": "unverifiable_or_missing_citation"})
            log_event(self.ctx.db, self.run, "tool_call", f"Proposal rejected ({tool}): citation could not be verified", {"tool": tool, "reason": "unverifiable_citation"}, self.ctx.user.id)
            return None
        summary = args.pop("summary", None)
        try:
            params = A.validate_params(action_type, args)
        except ValidationFailed as e:
            self.rejected.append({"tool": tool, "reason": "invalid_parameters"})
            log_event(self.ctx.db, self.run, "tool_call", f"Proposal rejected ({tool}): invalid parameters", {"tool": tool, "errors": e.details.get("errors", [])[:3]}, self.ctx.user.id)
            return None
        if action_type == "suggest_deadline" and params.get("source_document_id") and not any(e.document_id == params["source_document_id"] for e in self.evidence):
            self.rejected.append({"tool": tool, "reason": "source_document_not_retrieved"})
            return None
        if action_type == "update_contact_fields" and params["contact_id"] != str(self.run.contact_id):
            self.rejected.append({"tool": tool, "reason": "contact_out_of_scope"})
            return None
        if action_type == "update_time_narrative" and not any(e.source_type == "time_entry" and e.source_id == params["time_entry_id"] for e in self.evidence):
            self.rejected.append({"tool": tool, "reason": "time_entry_not_retrieved"})
            return None
        p = {"action_type": action_type, "summary": (summary or action_type.replace("_", " "))[:400], "params": params, "evidence": cites, "risk": policy.RISK[action_type]}
        self.proposals.append(p)
        return p

    def _t_propose_task(self, **a): return self._propose("propose_task", a)
    def _t_propose_deadline(self, **a): return self._propose("propose_deadline", a)
    def _t_propose_chronology(self, **a): return self._propose("propose_chronology", a)
    def _t_propose_correspondence_draft(self, **a): return self._propose("propose_correspondence_draft", a)
    def _t_propose_document_draft(self, **a): return self._propose("propose_document_draft", a)
    def _t_propose_time_entry(self, **a): return self._propose("propose_time_entry", a)
    def _t_propose_time_narrative(self, **a): return self._propose("propose_time_narrative", a)
    def _t_propose_contact_update(self, **a): return self._propose("propose_contact_update", a)
