from app.agents.agents import BaseAgent


class ChronologyAgent(BaseAgent):
    agent_type = "chronology"
    title = "Chronology builder"
    description = "Builds an editable timeline from documents and correspondence, distinguishing explicit dates from inferred ones. Entries are proposals until approved."
    retrieves = ["matter record", "document text", "correspondence"]

    def gather(self, tb, inp):
        tb.call("get_matter")
        tb.read("read_document_chunks", document_ids=inp.get("document_ids") or None)
        tb.read("list_correspondence", limit=30)
