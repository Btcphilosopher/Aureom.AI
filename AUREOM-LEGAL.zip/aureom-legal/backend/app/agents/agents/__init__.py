"""Agent registry and the shared compose pipeline (claims -> citations -> tool calls via policy -> verification -> result)."""
from __future__ import annotations

import json

from app.agents import policy, prompts, verify
from app.agents.llm import LLMProvider, LLMResponse
from app.agents.retrieval import Evidence
from app.agents.tools import ToolBox
from app.errors import AppError

_FRIENDLY = {"list_matter_documents": "documents", "read_document_chunks": "document text", "list_matter_tasks": "tasks", "list_matter_deadlines": "deadlines",
             "list_correspondence": "correspondence", "list_time_entries": "time entries", "list_activity": "recorded activity", "get_contact": "contact",
             "get_onboarding_form": "onboarding form", "list_approved_templates": "templates", "search_knowledge": "knowledge base"}


class BaseAgent:
    agent_type = "abstract"
    title = ""
    description = ""
    retrieves: list[str] = []
    summary_mode = "counts"  # counts | facts

    @property
    def read_only(self) -> bool:
        return policy.is_read_only(self.agent_type)

    def catalog(self) -> dict:
        pol = policy.AGENT_POLICY[self.agent_type]
        return {"key": self.agent_type, "name": self.title, "description": self.description, "retrieves": self.retrieves, "read_only": self.read_only,
                "read_tools": sorted(pol["read"]), "proposal_tools": sorted(pol["propose"]), "proposes_actions": sorted({policy.TOOL_TO_ACTION[t] for t in pol["propose"]}),
                "requires_matter": pol["needs_matter"], "prompt_template_version": prompts.template_version(self.agent_type)}

    # -- to override
    def gather(self, tb: ToolBox, inp: dict) -> None:
        raise NotImplementedError

    def params(self, tb: ToolBox, inp: dict) -> dict:
        return {}

    # -- pipeline
    def run(self, tb: ToolBox, inp: dict, provider: LLMProvider) -> tuple[dict, LLMResponse]:
        self.gather(tb, inp)
        tb.checkpoint()
        resp = provider.complete_structured(self.agent_type, prompts.system_prompt(self.agent_type), tb.evidence_blocks(), prompts.OUTPUT_SCHEMA, self.params(tb, inp))
        tb.checkpoint()
        return self.compose(tb, resp.output), resp

    def compose(self, tb: ToolBox, out: dict) -> dict:
        warnings: list[dict] = []
        res: dict = {"agent_type": self.agent_type, "title": self.title}
        for section in ("facts", "inferences", "contradictions"):
            items = []
            for c in out.get(section, []) or []:
                item = {"statement": str(c.get("statement", ""))[:1200], "citations": tb.cite_many(c.get("evidence"))}
                if c.get("kind"):
                    item["kind"] = c["kind"]
                if c.get("data"):
                    item["data"] = c["data"]
                if c.get("confidence"):
                    item["confidence"] = c["confidence"]
                items.append(item)
            res[section] = items
        res["recommendations"] = [{"statement": str(r.get("statement", ""))[:600]} for r in out.get("recommendations", []) or []]
        missing = [str(m)[:400] for m in out.get("missing_information", []) or []]
        # tool calls requested by the model go through the SAME policy layer as any other call
        proposed = 0
        for tc in out.get("tool_calls", []) or []:
            tool = str(tc.get("tool", ""))
            try:
                args = dict(tc.get("args") or {})
                if tool.startswith("propose_"):
                    args["evidence"] = tc.get("evidence") or []
                r = tb.call(tool, **args)
                if r:
                    proposed += 1
            except AppError as e:
                warnings.append({"type": "tool_call_denied", "tool": tool, "message": e.message, "reason": e.details.get("reason", e.code)})
        for tool, perm in tb.unavailable.items():
            missing.append(f"Not retrieved: {_FRIENDLY.get(tool, tool)} - your role does not include the required permission ({perm}).")
        st = tb.notes.get("chunks") or {}
        if st.get("skipped_unindexed"):
            missing.append(f"{st['skipped_unindexed']} document(s) had no extracted text yet (indexing/OCR pending) and were not reviewed.")
        if st.get("skipped_infected"):
            missing.append(f"{st['skipped_infected']} document(s) were withheld because the malware scan flagged them.")
        if st.get("truncated"):
            missing.append("The document text was truncated at the review limit; later sections were not reviewed.")
        for f in tb.injection:
            warnings.append({"type": "instruction_like_content", "message": "Instruction-like text was found in retrieved content. It was treated as data and had no effect on tools or actions.",
                             "patterns": f["patterns"], "citation": f["citation"]})
        res["missing_information"] = missing
        clean, rejected = verify.verify_result(res, tb.index)
        for r in rejected:
            warnings.append({"type": "claim_rejected", "message": f"A {r['section'][:-1] if r['section'].endswith('s') else r['section']} was withheld by the citation verifier ({r['reason']}).", "reason": r["reason"]})
        for r in tb.rejected:
            warnings.append({"type": "proposal_rejected", "message": f"A proposed change ({r['tool']}) was discarded: {r['reason']}.", "reason": r["reason"]})
        clean["warnings"] = warnings
        clean["rejected_claims"] = rejected
        clean["proposed_action_count"] = len(tb.proposals)
        clean["evidence_summary"] = {"items_retrieved": len(tb.evidence),
                                     "by_type": {t: sum(1 for e in tb.evidence if e.source_type == t) for t in sorted({e.source_type for e in tb.evidence})}}
        clean["summary"] = self.summarise(clean, len(tb.proposals))
        clean["sections_note"] = "facts = extracted & cited; inferences = reasoned, flagged; recommendations = suggestions for the user; nothing is applied without review."
        return json.loads(json.dumps(clean, default=str))

    def summarise(self, r: dict, n_actions: int) -> str:
        if self.summary_mode == "facts" and r["facts"]:
            return " ".join(f["statement"].rstrip(".") + "." for f in r["facts"][:4])
        return (f"{self.title}: {len(r['facts'])} cited fact(s), {len(r['inferences'])} inference(s), {n_actions} proposed action(s) for review, "
                f"{len(r['missing_information'])} gap(s) flagged, {len(r['contradictions'])} possible contradiction(s).")

    # helper for agents with user-supplied text
    def user_evidence(self, tb: ToolBox, key: str, text: str) -> Evidence | None:
        if not text or not str(text).strip():
            return None
        return tb.register(Evidence("user_input", f"{tb.run.id}:{key}", str(text)[:6000], title=key))


def _load() -> dict[str, BaseAgent]:
    from app.agents.agents.billing_assistant import BillingAssistantAgent
    from app.agents.agents.briefing import BriefingAgent
    from app.agents.agents.chronology import ChronologyAgent
    from app.agents.agents.document_review import DocumentReviewAgent
    from app.agents.agents.drafting import DraftingAgent
    from app.agents.agents.intake import IntakeAgent
    from app.agents.agents.knowledge import KnowledgeAgent

    return {a.agent_type: a for a in (BriefingAgent(), DocumentReviewAgent(), ChronologyAgent(), DraftingAgent(), KnowledgeAgent(), IntakeAgent(), BillingAssistantAgent())}


_REGISTRY: dict[str, BaseAgent] | None = None


def registry() -> dict[str, BaseAgent]:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _load()
    return _REGISTRY


def get_agent(agent_type: str) -> BaseAgent:
    from app.errors import ValidationFailed

    try:
        return registry()[agent_type]
    except KeyError as e:
        raise ValidationFailed(f"Unknown agent '{agent_type}'.", details={"agents": sorted(registry())}) from e
