from app.agents.agents import BaseAgent


class DocumentReviewAgent(BaseAgent):
    agent_type = "document_review"
    title = "Document review"
    description = ("Extracts parties, dates, obligations, clauses, notice periods and amounts from matter documents with document version and page/paragraph references. "
                   "May propose tasks and deadline SUGGESTIONS (with the supporting passage) for human confirmation.")
    retrieves = ["matter record", "extracted text of the matter's documents (current versions)"]

    def gather(self, tb, inp):
        tb.call("get_matter")
        tb.read("read_document_chunks", document_ids=inp.get("document_ids") or None)
