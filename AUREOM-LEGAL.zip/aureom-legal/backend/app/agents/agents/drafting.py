import re
from datetime import date

from app.agents.agents import BaseAgent
from app.models import Contact, Firm

PLACEHOLDER = re.compile(r"\{\{\s*([\w.]+)\s*\}\}")
KIND_TYPES = {"correspondence": {"letter", "email", "correspondence"}, "document": None, "attendance_note": {"attendance_note", "note"}}


def render(body: str, values: dict) -> tuple[str, list[str]]:
    missing: list[str] = []

    def sub(m):
        k = m.group(1)
        v = values.get(k)
        if v in (None, ""):
            if k not in missing:
                missing.append(k)
            return f"[[MISSING: {k}]]"
        return str(v)

    return PLACEHOLDER.sub(sub, body), missing


class DraftingAgent(BaseAgent):
    agent_type = "drafting"
    title = "Drafting assistant"
    description = ("Prepares EDITABLE correspondence, attendance-note summaries and document drafts using APPROVED templates and the facts you supply. "
                   "Saves drafts only; nothing is sent or shared. Unresolved fields are marked.")
    retrieves = ["matter record", "approved templates", "approved knowledge items", "your instructions/notes"]

    def gather(self, tb, inp):
        kind = inp.get("kind", "correspondence")
        tb.call("get_matter")
        tb.read("list_approved_templates", template_id=inp.get("template_id"), doc_types=sorted(KIND_TYPES[kind]) if (KIND_TYPES.get(kind) and not inp.get("template_id")) else None)
        m = tb.retr.matter()
        q = inp.get("instructions") or m.title
        tb.read("search_knowledge", query=q, practice_area=m.practice_area, limit=3)
        self.user_evidence(tb, "instructions", inp.get("instructions") or "")
        self.user_evidence(tb, "notes", inp.get("notes") or "")

    def params(self, tb, inp):
        kind = inp.get("kind", "correspondence")
        db = tb.ctx.db
        m = tb.retr.matter()
        client = db.get(Contact, m.client_id)
        firm = db.get(Firm, tb.ctx.firm_id)
        values = {"matter.reference": m.reference, "matter.title": m.title, "matter.type": m.matter_type, "matter.practice_area": m.practice_area,
                  "matter.status": m.status, "client.name": client.display_name if client else "", "client.email": client.email if client else "",
                  "user.name": tb.ctx.user.name, "firm.name": firm.name if firm else "", "today": date.today().strftime("%-d %B %Y")}
        values.update({str(k): v for k, v in (inp.get("fields") or {}).items() if isinstance(v, (str, int, float))})
        missing: list[str] = []
        tpl = next((e for e in tb.evidence if e.source_type == "template"), None)
        info = tb.notes.get("templates", {})
        if info.get("requested_unapproved"):
            missing.append("The requested template is not approved. Only approved templates may be used for drafting.")
        elif info.get("requested_missing"):
            missing.append("The requested template was not found.")
        draft: dict = {"kind": kind}
        subject = inp.get("subject") or f"{m.reference} - {m.title}"
        if kind == "attendance_note":
            notes = (inp.get("notes") or "").strip()
            if not notes:
                missing.append("No attendance notes were supplied; nothing to summarise.")
            else:
                lines = [l.strip(" -•\t") for l in notes.splitlines() if l.strip()]
                actions = [l for l in lines if re.search(r"\b(action|to do|will|agreed to|follow up)\b", l, re.I)]
                body = (f"ATTENDANCE NOTE - DRAFT SUMMARY\nPrepared by an AI assistant from notes supplied by {tb.ctx.user.name}; not verified. Review and correct before filing.\n\n"
                        f"Matter: {m.reference} - {m.title}\nClient: {values['client.name']}\nDate: {inp.get('date') or values['today']}\nAttendees: {inp.get('attendees') or '[[MISSING: attendees]]'}\n\n"
                        "Notes supplied:\n" + "\n".join(f"- {l}" for l in lines) + ("\n\nPossible follow-up actions mentioned in the notes:\n" + "\n".join(f"- {a}" for a in actions) if actions else ""))
                if not inp.get("attendees"):
                    missing.append("Attendees were not supplied.")
                draft.update(subject=f"Attendance note - {m.reference} - {inp.get('date') or values['today']}", body=body, doc_type="attendance_note")
        elif tpl is None:
            if not (info.get("requested_unapproved") or info.get("requested_missing")):
                missing.append(f"No approved template is available for a '{kind}' draft. Free-form drafting is not performed; ask a template owner to approve a suitable template.")
        else:
            body, miss = render(tpl.meta["body"], values)
            for k in miss:
                missing.append(f"Template field '{{{{{k}}}}}' could not be filled from the matter or your inputs; it is marked [[MISSING: {k}]] in the draft.")
            to = inp.get("to") or ([client.email] if client and client.email else [])
            if kind == "correspondence" and not to:
                missing.append("No recipient address is available for the client; add one before sending.")
            draft.update(subject=subject, body=body, to=to, doc_type=tpl.meta.get("doc_type", "letter"))
        return {"draft": draft, "missing": missing, "kind": kind}
