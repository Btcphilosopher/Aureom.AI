from app.agents.agents import BaseAgent


class BriefingAgent(BaseAgent):
    agent_type = "matter_briefing"
    title = "Matter briefing"
    description = "Cited summary of the matter: current stage, outstanding tasks, deadlines and missing information. Read-only."
    retrieves = ["matter record", "document list", "tasks", "deadlines", "recent correspondence"]
    summary_mode = "facts"

    def gather(self, tb, inp):
        tb.call("get_matter")
        tb.read("list_matter_documents")
        tb.read("list_matter_tasks")
        tb.read("list_matter_deadlines")
        tb.read("list_correspondence", limit=5)
