from sqlalchemy import select

from app.agents.agents import BaseAgent
from app.models import Contact, Firm


class IntakeAgent(BaseAgent):
    agent_type = "intake"
    title = "Intake assistant"
    description = ("Maps a submitted onboarding form to structured contact fields and lists missing onboarding information. Proposes contact updates for review. "
                   "Check results in this build are SIMULATED and are never presented as verified identity.")
    retrieves = ["contact record", "submitted onboarding form (untrusted)", "onboarding check statuses"]

    def gather(self, tb, inp):
        cid = str(tb.run.contact_id)
        tb.read("get_contact", contact_id=cid)
        tb.read("get_onboarding_form", contact_id=cid)

    def params(self, tb, inp):
        c = tb.ctx.db.get(Contact, tb.run.contact_id)
        firm = tb.ctx.db.get(Firm, tb.ctx.firm_id)
        return {"contact_id": str(tb.run.contact_id), "contact_kind": c.kind if c else None, "required_checks": (firm.settings or {}).get("onboarding_required_checks", [])}
