from app.agents.agents import BaseAgent


class KnowledgeAgent(BaseAgent):
    agent_type = "knowledge"
    title = "Knowledge search"
    description = ("Searches APPROVED internal precedents and practice materials and shows source, kind and dates. Never supplies case citations or authorities from model memory; "
                   "external research only through a configured source adapter.")
    retrieves = ["approved knowledge items (firm-wide)", "external research adapter (if configured)"]
    summary_mode = "facts"

    def gather(self, tb, inp):
        q = (inp.get("query") or "").strip()
        pa = inp.get("practice_area")
        tb.read("search_knowledge", query=q, practice_area=pa, limit=6)
        if inp.get("external_research"):
            tb.read("external_legal_research", query=q)

    def params(self, tb, inp):
        return {"query": inp.get("query", ""), "external": tb.notes.get("external_research")}
