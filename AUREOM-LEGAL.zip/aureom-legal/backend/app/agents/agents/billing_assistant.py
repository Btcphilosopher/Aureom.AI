from datetime import date

from app.agents.agents import BaseAgent


def _d(v):
    try:
        return date.fromisoformat(str(v)) if v else None
    except ValueError:
        return None


class BillingAssistantAgent(BaseAgent):
    agent_type = "billing_assistant"
    title = "Billing assistant"
    description = ("Suggests time-entry narratives from RECORDED activity and flags missing information. It never invents work performed or time spent: "
                   "minutes must be supplied by the fee earner, otherwise it flags 'minutes required'.")
    retrieves = ["matter record", "your own time entries on the matter", "your own recorded activity (document versions, correspondence, completed tasks, diary events)"]

    def gather(self, tb, inp):
        lo, hi = _d(inp.get("date_from")), _d(inp.get("date_to"))
        tb.call("get_matter")
        tb.read("list_time_entries", date_from=lo, date_to=hi)
        tb.read("list_activity", date_from=lo, date_to=hi)
        for i, e in enumerate(inp.get("entries") or []):
            if e.get("narrative_hint"):
                self.user_evidence(tb, f"narrative_hint_{i}", f"Narrative supplied by user for {e.get('work_date')}: {e['narrative_hint']}")

    def params(self, tb, inp):
        return {"entries": [{"work_date": e.get("work_date"), "minutes": e.get("minutes"), "narrative_hint": e.get("narrative_hint")} for e in (inp.get("entries") or [])]}
