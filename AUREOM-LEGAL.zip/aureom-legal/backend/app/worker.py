"""Background worker: OCR, malware scan, indexing, exports, agent runs, reminders/escalation.
Run:  python -m app.worker            (loop)   |   python -m app.worker --once   (drain queue and exit)"""
from __future__ import annotations

import importlib
import logging
import sys
import time

from app.config import get_settings
from app.services import jobs

log = logging.getLogger("aureom.worker")

# modules that register @job_handler functions
HANDLER_MODULES = ["app.services.documents_jobs", "app.services.export_jobs", "app.services.task_jobs", "app.agents.jobs"]


def load_handlers() -> None:
    for m in HANDLER_MODULES:
        try:
            importlib.import_module(m)
        except ModuleNotFoundError as e:
            if e.name != m:
                raise


def run_forever() -> None:
    load_handlers()
    from app import integrations
    integrations.load_all()
    poll = get_settings().worker_poll_seconds
    last_sweep = 0.0
    log.info("worker started")
    while True:
        try:
            n = jobs.run_all_pending(limit=25)
            if time.time() - last_sweep > 60:  # periodic sweeps (reminders, escalations, retention)
                last_sweep = time.time()
                try:
                    from app.services import task_jobs
                    task_jobs.sweep_all_firms()
                except ModuleNotFoundError:
                    pass
            if n == 0:
                time.sleep(poll)
        except Exception:  # noqa: BLE001
            log.exception("worker loop error")
            time.sleep(5)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    if "--once" in sys.argv:
        load_handlers()
        from app import integrations
        integrations.load_all()
        print(f"processed {jobs.run_all_pending()} jobs")
    else:
        run_forever()
