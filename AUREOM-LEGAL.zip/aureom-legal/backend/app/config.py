"""Application settings. All secrets come from the environment; nothing is hard-coded."""
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    env: str = "development"  # development | test | production
    # Application connection: a NON-superuser, NON-owner role so row-level security is enforced.
    database_url: str = "postgresql+psycopg://aureom_app:aureom_app@localhost:5432/aureom"
    # Owner connection used only by migrations / seeding / maintenance.
    migration_database_url: str = "postgresql+psycopg://aureom:aureom@localhost:5432/aureom"

    # Sessions
    session_cookie_name: str = "aureom_session"
    session_ttl_minutes: int = 480
    cookie_secure: bool = False
    secret_key: str = "change-me-in-production"  # used for HMAC of idempotency / signed download links

    # Demo mode exposes the persona picker and demo password. NEVER enable in production.
    demo_mode: bool = True
    demo_password: str = "pennine-demo-2026"

    # Object storage (S3-compatible). storage_backend: s3 | local
    storage_backend: str = "local"
    local_storage_path: str = "./.storage"
    s3_endpoint_url: str | None = None
    s3_region: str = "eu-west-2"
    s3_bucket: str = "aureom-documents"
    s3_access_key: str | None = None
    s3_secret_key: str | None = None

    max_upload_bytes: int = 25 * 1024 * 1024
    allow_unscanned_downloads: bool = False

    # Data residency label (informational + enforced as a config gate for AI egress)
    data_residency: str = "uk"

    # Background worker
    embedded_worker: bool = False
    worker_poll_seconds: float = 1.0

    # AI
    ai_provider: str = "mock"  # mock | anthropic
    ai_model: str = "mock-local-1"
    anthropic_api_key: str | None = None
    ai_default_monthly_budget_gbp: float = 50.0
    ai_run_timeout_seconds: int = 120
    ai_max_attempts: int = 2

    # SSO boundary (OIDC). Not implemented beyond the adapter interface.
    sso_issuer: str | None = None
    sso_client_id: str | None = None

    cors_origins: str = "http://localhost:5173"


@lru_cache
def get_settings() -> Settings:
    return Settings()
