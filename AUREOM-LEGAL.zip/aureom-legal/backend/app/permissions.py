"""Role -> permission catalogue and matter-level access rules (restricted matters, ethical walls).

Two layers, always both applied:
  1. role permissions (what kind of action a user may perform at all)
  2. matter visibility (which matters a user may see/act on): standard matters are visible to staff with
     matters.read; restricted matters only to allow-listed members / responsible people; an ethical-wall
     `deny` entry (user or team) always wins.
Search, previews, exports and AI retrieval all go through `matter_clause` / the can_* helpers below.
"""
from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

from sqlalchemy import ColumnElement, and_, exists, false, or_, select

if TYPE_CHECKING:  # pragma: no cover
    from app.deps import Ctx

P = {
    "clients.read", "clients.write", "clients.merge",
    "conflicts.run", "conflicts.review",
    "onboarding.manage", "onboarding.approve",
    "matters.read", "matters.create", "matters.write", "matters.transition", "matters.approve", "matters.access_admin",
    "documents.read", "documents.write", "documents.approve", "documents.sign", "documents.export", "documents.export_approve", "documents.templates",
    "correspondence.read", "correspondence.write", "correspondence.approve",
    "tasks.read", "tasks.write", "deadlines.confirm",
    "time.write", "time.read_all",
    "billing.read", "billing.write", "billing.approve", "billing.issue",
    "ledger.read", "ledger.post", "ledger.approve", "ledger.reconcile",
    "reports.read", "reports.financial",
    "ai.use", "ai.review", "ai.admin", "knowledge.manage",
    "admin.users", "admin.settings", "audit.read",
    "portal.read",
}

_FEE_EARNER = {
    "clients.read", "clients.write", "conflicts.run", "onboarding.manage",
    "matters.read", "matters.create", "matters.write", "matters.transition",
    "documents.read", "documents.write", "documents.approve", "documents.sign", "documents.export", "documents.templates",
    "correspondence.read", "correspondence.write",
    "tasks.read", "tasks.write", "deadlines.confirm",
    "time.write", "billing.read", "billing.write",
    "reports.read", "ai.use", "ai.review",
}

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "partner": _FEE_EARNER | {
        "clients.merge", "conflicts.review", "onboarding.approve",
        "matters.approve", "matters.access_admin", "documents.export_approve", "correspondence.approve",
        "time.read_all", "billing.approve", "ledger.read", "reports.financial", "knowledge.manage",
    },
    "solicitor": set(_FEE_EARNER),
    "paralegal": {
        "clients.read", "clients.write", "conflicts.run",
        "matters.read", "documents.read", "documents.write", "correspondence.read", "correspondence.write",
        "tasks.read", "tasks.write", "time.write", "ai.use", "ai.review", "reports.read",
    },
    "finance": {
        "clients.read", "matters.read", "time.read_all", "time.write",
        "billing.read", "billing.write", "billing.issue",
        "ledger.read", "ledger.post", "ledger.approve", "ledger.reconcile",
        "reports.read", "reports.financial", "tasks.read",
    },
    "compliance": {
        "clients.read", "clients.write", "clients.merge", "conflicts.run", "conflicts.review",
        "onboarding.manage", "onboarding.approve", "matters.read", "matters.approve", "matters.access_admin",
        "audit.read", "reports.read", "knowledge.manage", "ai.admin", "tasks.read",
    },
    "admin": {"admin.users", "admin.settings", "audit.read", "clients.read", "ai.admin", "knowledge.manage", "documents.templates"},
    "client": {"portal.read"},
}
assert all(set(v) <= P for v in ROLE_PERMISSIONS.values()), "unknown permission in role catalogue"

STAFF_ROLES = [r for r in ROLE_PERMISSIONS if r != "client"]


def permissions_for(role_key: str, override: list[str] | None = None) -> frozenset[str]:
    """DB role rows may override the defaults (roles.permissions); unknown strings are dropped."""
    perms = set(override) if override else ROLE_PERMISSIONS.get(role_key, set())
    return frozenset(p for p in perms if p in P)


# --------------------------------------------------------------------------- matter visibility
def matter_clause(ctx: "Ctx") -> ColumnElement[bool]:
    """SQL predicate selecting the matters this user may see. Use it (never ad-hoc filters) in list/search/AI queries."""
    from app.models import Matter, MatterMember, MatterParty  # local import: avoid cycles

    user = ctx.user
    if ctx.role_key == "client":
        if not user.contact_id:
            return false()
        return and_(
            Matter.firm_id == ctx.firm_id,
            Matter.status != "prospective",
            Matter.id.in_(select(MatterParty.matter_id).where(MatterParty.contact_id == user.contact_id, MatterParty.role == "client")),
        )
    if not ctx.has("matters.read"):
        return false()
    deny = exists().where(
        MatterMember.matter_id == Matter.id,
        MatterMember.access == "deny",
        or_(MatterMember.user_id == user.id, MatterMember.team_id == user.team_id if user.team_id else false()),
    )
    allow = exists().where(MatterMember.matter_id == Matter.id, MatterMember.access == "allow", MatterMember.user_id == user.id)
    return and_(
        Matter.firm_id == ctx.firm_id,
        ~deny,
        or_(Matter.access_level == "standard", allow, Matter.responsible_partner_id == user.id, Matter.fee_earner_id == user.id),
    )


def visible_matter_ids(ctx: "Ctx"):
    from app.models import Matter

    return select(Matter.id).where(matter_clause(ctx))


def can_access_matter(ctx: "Ctx", matter) -> bool:
    from app.models import MatterMember, MatterParty

    if matter.firm_id != ctx.firm_id:
        return False
    user = ctx.user
    if ctx.role_key == "client":
        if matter.status == "prospective" or not user.contact_id:
            return False
        return ctx.db.execute(
            select(MatterParty.id).where(MatterParty.matter_id == matter.id, MatterParty.contact_id == user.contact_id, MatterParty.role == "client")
        ).first() is not None
    if not ctx.has("matters.read"):
        return False
    members = ctx.db.execute(select(MatterMember).where(MatterMember.matter_id == matter.id)).scalars().all()
    for m in members:
        if m.access == "deny" and (m.user_id == user.id or (m.team_id is not None and m.team_id == user.team_id)):
            return False
    if matter.access_level == "standard":
        return True
    if matter.responsible_partner_id == user.id or matter.fee_earner_id == user.id:
        return True
    return any(m.access == "allow" and m.user_id == user.id for m in members)


def can_export(ctx: "Ctx", matter) -> bool:
    return can_access_matter(ctx, matter) and matter.exports_allowed and ctx.has("documents.export")


def can_preview(ctx: "Ctx", matter) -> bool:
    return can_access_matter(ctx, matter) and ctx.has("documents.read")


def can_ai_retrieve(ctx: "Ctx", matter) -> bool:
    """AI retrieval is permitted only where the *requesting user* could read the matter AND the matter allows it."""
    return can_access_matter(ctx, matter) and matter.ai_retrieval_allowed and ctx.has("ai.use")
