"""Electronic-signature integration interface with a clearly-labelled mock."""
from __future__ import annotations

import uuid

from .base import Integration, IntegrationInfo, register


class ESignProvider(Integration):
    key = "esign"

    def create_request(self, *, title: str, sha256: str, signers: list[dict]) -> str:  # pragma: no cover - interface
        raise NotImplementedError


class MockESignProvider(ESignProvider):
    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key=self.key, name="E-signature (simulated)", category="documents", provider="mock-esign", mode="mock",
            description="No envelope is sent. Signing is simulated by an explicit 'simulate completion' action. A simulated signature has NO legal effect.",
            data_leaves_application="A live provider would receive the document and signer names/emails.",
            setup_hint="Implement ESignProvider for your e-signature vendor and register it in app/integrations/esign.py.")

    def create_request(self, *, title: str, sha256: str, signers: list[dict]) -> str:
        return "SIM-ENV-" + uuid.uuid4().hex[:10].upper()


register(MockESignProvider())
