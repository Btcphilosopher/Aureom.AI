"""Asynchronous OCR integration. The mock provider produces clearly-flagged SIMULATED text so the pipeline can be shown end to end."""
from __future__ import annotations

from .base import Integration, IntegrationInfo, register


class OcrProvider(Integration):
    key = "ocr"

    def ocr(self, data: bytes, content_type: str, filename: str) -> list[str]:  # pragma: no cover - interface
        """Return one text block per page."""
        raise NotImplementedError


class MockOcrProvider(OcrProvider):
    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key=self.key, name="OCR (simulated)", category="documents", provider="mock-ocr", mode="mock",
            description="Does not read the image. Emits a placeholder marked SIMULATED so search/AI flows can be demonstrated.",
            data_leaves_application="Nothing in mock mode. A live OCR service would receive page images / PDF bytes.",
            setup_hint="Implement OcrProvider for Tesseract or a cloud OCR service and register it in app/integrations/ocr.py.")

    def ocr(self, data: bytes, content_type: str, filename: str) -> list[str]:
        return [f"[SIMULATED OCR OUTPUT - no OCR engine is configured; the content of '{filename}' has not been read.]"]


register(MockOcrProvider())
