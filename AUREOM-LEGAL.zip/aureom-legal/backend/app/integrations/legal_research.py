"""External legal-research adapter. NO provider is bundled: by default the integration is registered as UNAVAILABLE. A deployment
must configure an explicit, contractually-approved source; every result must carry its source and retrieval date. The knowledge agent
never answers legal-authority questions from model memory."""
from __future__ import annotations

from datetime import datetime, timezone

from app.integrations.base import Integration, IntegrationInfo, get, register

try:  # registers the "ai_provider" integration info alongside the other adapters
    from app.agents import llm as _llm  # noqa: F401
except Exception:  # pragma: no cover
    pass


class LegalResearchProvider(Integration):
    """Interface. Subclasses implement `search(query) -> {"source", "retrieved_at", "items": [{"title","citation","excerpt","url"}]}`."""
    key = "legal_research"

    def search(self, query: str) -> dict:  # pragma: no cover - interface
        raise NotImplementedError

    @staticmethod
    def now_iso() -> str:
        return datetime.now(timezone.utc).date().isoformat()


class UnconfiguredLegalResearch(LegalResearchProvider):
    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key=self.key, name="External legal research source", category="research", provider="none", mode="unavailable",
            description="No external legal research provider is configured. AI agents answer only from approved internal materials.",
            data_leaves_application="If configured, the search query text (which may reveal matter context) would be sent to the chosen research provider.",
            setup_hint="Implement LegalResearchProvider for your licensed source and register it; results must show source and retrieval date.")

    def search(self, query: str) -> dict:
        raise RuntimeError("legal research provider not configured")


register(UnconfiguredLegalResearch())


def get_legal_research() -> LegalResearchProvider:
    return get("legal_research")  # type: ignore[return-value]
