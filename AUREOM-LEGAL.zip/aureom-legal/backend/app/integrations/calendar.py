"""Calendar integration boundary. The only implementation here is a MOCK: ICS export works for real (RFC 5545 text a user
can import into any calendar app); two-way sync with Microsoft 365 / Google Calendar is NOT connected."""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy.orm import Session

from app.integrations.base import Integration, IntegrationInfo, register
from app.models import IntegrationEvent


def _esc(s: str) -> str:
    return (s or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n")


def _fold(line: str) -> list[str]:
    """RFC 5545 line folding at 75 octets (continuation lines begin with a space)."""
    raw = line.encode()
    if len(raw) <= 75:
        return [line]
    out, cur, cur_len = [], "", 0
    limit = 75
    for ch in line:
        n = len(ch.encode())
        if cur_len + n > limit:
            out.append(cur)
            cur, cur_len, limit = " ", 1, 75
        cur += ch
        cur_len += n
    out.append(cur)
    return out


def _utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


class CalendarProvider(Integration):
    key = "calendar"

    def render_ics(self, items: list[dict], *, calname: str) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    def sync_event(self, db: Session, firm_id, event_id, title: str) -> dict:  # pragma: no cover - interface
        raise NotImplementedError


class MockCalendarProvider(CalendarProvider):
    key = "calendar"

    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key="calendar", name="Calendar (MOCK - ICS export only)", category="calendar", provider="mock-ics", mode="mock",
            description="Diary items can be exported as an .ics file. No external calendar (Microsoft 365 / Google) is connected; sync is simulated and recorded locally.",
            data_leaves_application="Live provider: event titles, times, locations and attendee names would be sent to the calendar service. Mock: nothing leaves the application.",
            setup_hint="Implement CalendarProvider for your calendar service and register it under key 'calendar'.")

    def render_ics(self, items: list[dict], *, calname: str) -> str:
        now = _utc(datetime.now(timezone.utc))
        lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//AUREOM LEGAL//Diary (demonstration)//EN", "CALSCALE:GREGORIAN",
                 f"X-WR-CALNAME:{_esc(calname)}"]
        for it in items:
            lines += ["BEGIN:VEVENT", f"UID:{it['kind']}-{it['id']}@aureom.invalid", f"DTSTAMP:{now}"]
            start, end = it["start"], it.get("end")
            if it.get("all_day"):
                d = start if isinstance(start, date) and not isinstance(start, datetime) else start.date()
                lines.append(f"DTSTART;VALUE=DATE:{d.strftime('%Y%m%d')}")
            else:
                lines.append(f"DTSTART:{_utc(start)}")
                if end:
                    lines.append(f"DTEND:{_utc(end)}")
            lines.append(f"SUMMARY:{_esc(it['title'])}")
            if it.get("description"):
                lines.append(f"DESCRIPTION:{_esc(it['description'])}")
            if it.get("location"):
                lines.append(f"LOCATION:{_esc(it['location'])}")
            lines.append(f"CATEGORIES:{it['kind'].upper()}")
            lines.append("END:VEVENT")
        lines.append("END:VCALENDAR")
        folded = [seg for ln in lines for seg in _fold(ln)]
        return "\r\n".join(folded) + "\r\n"

    def sync_event(self, db: Session, firm_id, event_id, title: str) -> dict:
        db.add(IntegrationEvent(firm_id=firm_id, integration="calendar", provider="mock-ics", mode="mock", kind="event_sync_simulated",
                                payload={"event_id": str(event_id)}, status="simulated"))
        db.flush()
        return {"simulated": True, "synced": False,
                "message": "Simulated only: no external calendar is connected, so nothing was sent. Use the ICS export to import this item into your calendar."}


register(MockCalendarProvider())
