"""Bank-feed integration boundary.

`BankFeedProvider` is the interface a real open-banking / bank-file adapter would implement. Only READ operations
exist: statement import. There is deliberately NO method to initiate payments, change bank details or release funds -
those are human actions outside the AI/agent surface. The mock below returns clearly-labelled SYNTHETIC lines."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal

from .base import Integration, IntegrationInfo, register


@dataclass
class StatementLineDTO:
    external_id: str
    txn_date: date
    description: str
    reference: str | None
    amount: Decimal  # signed: + in, - out
    currency: str = "GBP"


class BankFeedProvider(Integration):
    key = "banking"

    def fetch_statement(self, ledger: str, since: date | None = None) -> list[StatementLineDTO]:  # pragma: no cover - interface
        raise NotImplementedError


class MockBankFeedProvider(BankFeedProvider):
    """SYNTHETIC statement lines: deterministic, idempotent (stable external ids)."""

    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key="banking", name="Bank feed (MOCK - synthetic transactions)", category="banking", provider="mock-bank-feed", mode="mock",
            description="Generates deterministic synthetic statement lines for demonstration. No real bank is contacted; no payments can be initiated.",
            data_leaves_application="Nothing in mock mode. A live feed would receive account identifiers and return transaction data; no matter content is sent.",
            setup_hint="Implement BankFeedProvider for your bank/open-banking aggregator and register it; credentials must be server-side secrets.")

    def fetch_statement(self, ledger: str, since: date | None = None) -> list[StatementLineDTO]:
        base = date.today()
        if ledger == "client":
            return [StatementLineDTO("SYN-C-0001", base - timedelta(days=6), "SYNTHETIC BACS CR completion funds", "SYN-CLIENT-A", Decimal("10000.00")),
                    StatementLineDTO("SYN-C-0002", base - timedelta(days=2), "SYNTHETIC FPS CR monies on account", "SYN-CLIENT-B", Decimal("2500.00"))]
        return [StatementLineDTO("SYN-O-0001", base - timedelta(days=5), "SYNTHETIC BACS CR client payment", "SYN-OFFICE-A", Decimal("1500.00")),
                StatementLineDTO("SYN-O-0002", base - timedelta(days=3), "SYNTHETIC FPS CR client payment", "SYN-OFFICE-B", Decimal("2400.00")),
                StatementLineDTO("SYN-O-0003", base - timedelta(days=1), "SYNTHETIC BACS CR client payment", "SYN-OFFICE-C", Decimal("960.00"))]


register(MockBankFeedProvider())
