"""Integration boundary. Every external dependency (email, calendar, e-signature, identity checks, banking, malware
scanning, OCR, legal research, SSO) is an interface with a clearly-labelled mock implementation registered here.
The registry feeds the Administration > Integrations page and the 'integration unavailable' UI states."""
from __future__ import annotations

from dataclasses import asdict, dataclass

from app.errors import IntegrationUnavailable


@dataclass
class IntegrationInfo:
    key: str
    name: str
    category: str
    provider: str
    mode: str  # mock | live | unavailable
    description: str
    data_leaves_application: str  # plain-language statement of what would leave the app if this were live
    setup_hint: str = ""

    @property
    def available(self) -> bool:
        return self.mode in ("mock", "live")

    def to_dict(self) -> dict:
        d = asdict(self)
        d["available"] = self.available
        return d


class Integration:
    key = "abstract"

    def info(self) -> IntegrationInfo:  # pragma: no cover - interface
        raise NotImplementedError


_REGISTRY: dict[str, Integration] = {}


def register(provider: Integration) -> Integration:
    _REGISTRY[provider.key] = provider
    return provider


def get(key: str) -> Integration:
    if key not in _REGISTRY:
        raise IntegrationUnavailable(f"The '{key}' integration is not installed.", details={"integration": key})
    return _REGISTRY[key]


def get_available(key: str) -> Integration:
    p = get(key)
    info = p.info()
    if not info.available:
        raise IntegrationUnavailable(f"{info.name} is not available: {info.setup_hint or 'not configured'}",
                                     details={"integration": key, "setup_hint": info.setup_hint})
    return p


def all_infos() -> list[IntegrationInfo]:
    return [p.info() for p in _REGISTRY.values()]
