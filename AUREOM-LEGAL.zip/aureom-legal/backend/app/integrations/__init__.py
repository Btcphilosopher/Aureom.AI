"""Importing this package registers every integration provider with the registry."""
import importlib

_MODULES = ["identity", "email", "calendar", "esign", "malware", "ocr", "banking", "legal_research", "sso", "companies_house"]


def load_all() -> None:
    for m in _MODULES:
        try:
            importlib.import_module(f"app.integrations.{m}")
        except ModuleNotFoundError as e:  # a module not written yet (dev only)
            if e.name != f"app.integrations.{m}":
                raise
