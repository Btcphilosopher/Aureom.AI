"""Identity / AML check adapter boundary. ONLY a simulated provider ships with this build.
Nothing here verifies a real identity: results are labelled SIMULATED everywhere they appear."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

from app.integrations.base import Integration, IntegrationInfo, register

SIMULATED_NOTICE = "SIMULATED check - no real identity document, database, sanctions list or biometric verification was performed."
STATUS_LABELS = {
    "not_started": "Not started", "requested": "Requested", "passed_simulated": "Passed (simulated)",
    "needs_review": "Needs human review (simulated)", "failed": "Failed (simulated)", "waived": "Waived by reviewer",
}


@dataclass
class CheckResult:
    status: str  # passed_simulated | needs_review | failed
    summary: str
    external_ref: str
    simulated: bool = True


class IdentityVerificationProvider(Integration):
    key = "identity"

    def run_check(self, check_type: str, subject: dict) -> CheckResult:  # pragma: no cover - interface
        raise NotImplementedError


class SimulatedIdentityProvider(IdentityVerificationProvider):
    """Deterministic demo adapter. Names/aliases containing the synthetic trigger word 'fail' return a failure;
    'refer' returns needs_review; everything else 'passes' - which is NOT a verification of anyone."""

    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key=self.key, name="Identity & AML checks", category="identity", provider="simulated-identity", mode="mock",
            description="Simulated provider adapter for demonstration. Results are never evidence of verified identity.",
            data_leaves_application="Nothing leaves the application in mock mode. A live provider would receive the individual's name, date of birth, address and identity-document images.",
            setup_hint="Implement IdentityVerificationProvider for your regulated provider and register it as key 'identity'.",
        )

    def run_check(self, check_type: str, subject: dict) -> CheckResult:
        hay = " ".join([subject.get("display_name") or ""] + list(subject.get("aliases") or [])).lower()
        ref = "SIM-" + hashlib.sha256(f"{check_type}:{hay}".encode()).hexdigest()[:10].upper()
        if "fail" in hay:
            return CheckResult("failed", f"Simulated {check_type} check returned a failure (synthetic trigger word). {SIMULATED_NOTICE}", ref)
        if "refer" in hay:
            return CheckResult("needs_review", f"Simulated {check_type} check was referred for human review (synthetic trigger word). {SIMULATED_NOTICE}", ref)
        return CheckResult("passed_simulated", f"Simulated {check_type} check returned a demonstration pass. {SIMULATED_NOTICE}", ref)


register(SimulatedIdentityProvider())
