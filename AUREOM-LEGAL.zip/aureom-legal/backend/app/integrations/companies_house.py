"""Company-register lookup boundary. Deliberately NOT configured in this build, to demonstrate the
'integration unavailable' state: lookups raise IntegrationUnavailable (HTTP 503)."""
from __future__ import annotations

from app.integrations.base import Integration, IntegrationInfo, register


class CompanyRegisterProvider(Integration):
    key = "companies_house"

    def lookup(self, company_number: str) -> dict:  # pragma: no cover - interface
        raise NotImplementedError


class UnconfiguredCompanyRegister(CompanyRegisterProvider):
    def info(self) -> IntegrationInfo:
        return IntegrationInfo(
            key=self.key, name="Company register lookup", category="registry", provider="not configured", mode="unavailable",
            description="Looks up company name, status, officers and persons with significant control.",
            data_leaves_application="The company number or name being searched would be sent to the registry API.",
            setup_hint="Provide a company-register API key and implement CompanyRegisterProvider (not included in this build).",
        )


register(UnconfiguredCompanyRegister())
