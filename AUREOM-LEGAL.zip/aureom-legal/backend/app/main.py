from __future__ import annotations

import logging
import threading
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.api import build_router
from app.config import get_settings
from app.db.session import get_engine
from app.errors import install_handlers

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

DESCRIPTION = """
**AUREOM LEGAL - Practice Database & Intelligence** (demonstration build).

All data is synthetic. Integrations are mocks unless stated. Money is exact decimal; ledgers are separated;
financial postings and AI-proposed changes require explicit human approval.
Authentication: HttpOnly session cookie + `X-CSRF-Token` header on unsafe methods (see `POST /api/v1/auth/login`).
"""


@asynccontextmanager
async def lifespan(_: FastAPI):
    if get_settings().embedded_worker:  # convenience for single-process local runs; use the worker container otherwise
        from app.worker import run_forever
        threading.Thread(target=run_forever, daemon=True, name="embedded-worker").start()
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(lifespan=lifespan, title="AUREOM LEGAL API", version="0.1.0", description=DESCRIPTION, docs_url="/api/docs", openapi_url="/api/openapi.json", redoc_url=None)
    app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
                       allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    install_handlers(app)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault("Cache-Control", "no-store")
        resp.headers.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'; sandbox") if not request.url.path.startswith("/api/docs") else None
        return resp

    from app import integrations
    integrations.load_all()
    app.include_router(build_router(), prefix="/api/v1")

    @app.get("/api/health", tags=["system"])
    def health():
        with get_engine().connect() as c:
            c.execute(text("select 1"))
        return {"status": "ok"}

    return app


app = create_app()
