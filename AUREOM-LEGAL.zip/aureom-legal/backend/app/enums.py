"""Controlled vocabularies. Stored as plain strings (not PG enums) to keep migrations simple;
validated in schemas/services and, for critical ones, by CHECK constraints."""
from __future__ import annotations

PRACTICE_AREAS = ["commercial", "property", "litigation", "employment", "private_client", "corporate"]
PARTY_ROLES = ["client", "payer", "beneficiary", "counterparty", "counterparty_solicitor", "witness", "other"]
CONTACT_KINDS = ["individual", "organisation"]
COMM_CHANNELS = ["email", "phone", "post", "portal"]
MATTER_STATUSES = ["prospective", "open", "paused", "closed"]
# explicit state machine: from -> allowed targets
MATTER_TRANSITIONS: dict[str, list[str]] = {
    "prospective": ["open"],
    "open": ["paused", "closed"],
    "paused": ["open", "closed"],
    "closed": ["open"],  # reopen
}
ACCESS_LEVELS = ["standard", "restricted"]
FEE_ARRANGEMENTS = ["hourly", "fixed", "capped", "retainer"]
ONBOARDING_STATUSES = ["not_started", "in_progress", "awaiting_client", "awaiting_review", "approved", "rejected"]
CHECK_STATUSES = ["not_started", "requested", "passed_simulated", "needs_review", "failed", "waived"]
CONFLICT_SEARCH_STATUSES = ["pending_review", "cleared_by_reviewer", "conflict_confirmed", "referred"]
CONFLICT_DISPOSITIONS = ["unreviewed", "false_positive", "potential_conflict", "confirmed_conflict"]
DOC_STATUSES = ["draft", "in_review", "approved", "signature_requested", "signed", "superseded"]
TASK_STATUSES = ["open", "in_progress", "blocked", "done", "cancelled"]
DEADLINE_STATUSES = ["suggested", "confirmed", "rejected", "met", "missed"]
DEADLINE_ORIGINS = ["manual", "calculated_suggestion", "ai_suggestion"]
INVOICE_STATUSES = ["draft", "pending_approval", "issued", "partially_paid", "paid", "void"]
JOURNAL_STATUSES = ["draft", "pending_approval", "posted", "reversed"]
LEDGERS = ["office", "client"]
AGENT_TYPES = ["matter_briefing", "document_review", "chronology", "drafting", "knowledge", "intake", "billing_assistant"]
RUN_STATES = ["queued", "running", "awaiting_review", "approved", "rejected", "executing", "completed", "failed", "cancelled"]
ACTION_STATES = ["proposed", "approved", "rejected", "executing", "executed", "failed", "superseded"]
CURRENCIES = ["GBP", "EUR", "USD"]
