from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import DBAPIError, IntegrityError
from sqlalchemy.orm.exc import StaleDataError


class AppError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str, *, code: str | None = None, status_code: int | None = None, details: dict | None = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        if status_code:
            self.status_code = status_code
        self.details = details or {}


class NotFound(AppError):
    status_code, code = 404, "not_found"


class PermissionDenied(AppError):
    status_code, code = 403, "permission_denied"


class MatterAccessDenied(PermissionDenied):
    code = "matter_access_denied"


class Unauthenticated(AppError):
    status_code, code = 401, "unauthenticated"


class VersionConflict(AppError):
    status_code, code = 409, "version_conflict"


class InvalidState(AppError):
    status_code, code = 409, "invalid_state"


class ValidationFailed(AppError):
    status_code, code = 422, "validation_failed"


class IntegrationUnavailable(AppError):
    status_code, code = 503, "integration_unavailable"


class ApprovalRequired(AppError):
    status_code, code = 409, "approval_required"


class BudgetExceeded(AppError):
    status_code, code = 429, "budget_exceeded"


def _payload(exc: AppError) -> dict:
    return {"error": {"code": exc.code, "message": exc.message, "details": exc.details}}


def install_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError):
        return JSONResponse(status_code=exc.status_code, content=_payload(exc))

    @app.exception_handler(StaleDataError)
    async def _stale(_: Request, exc: StaleDataError):
        return JSONResponse(status_code=409, content={"error": {"code": "version_conflict", "message": "This record was changed by someone else. Reload and try again.", "details": {}}})

    @app.exception_handler(IntegrityError)
    async def _integrity(_: Request, exc: IntegrityError):
        msg = str(getattr(exc, "orig", exc)).split("\n")[0]
        return JSONResponse(status_code=409, content={"error": {"code": "integrity_error", "message": "The change violates a data integrity rule.", "details": {"database": msg[:300]}}})

    @app.exception_handler(DBAPIError)
    async def _dbapi(_: Request, exc: DBAPIError):
        msg = str(getattr(exc, "orig", exc)).split("\n")[0]
        # RAISE EXCEPTION from safeguard triggers surfaces here (e.g. unbalanced journal, immutable record)
        return JSONResponse(status_code=409, content={"error": {"code": "database_rule", "message": msg[:300], "details": {}}})
