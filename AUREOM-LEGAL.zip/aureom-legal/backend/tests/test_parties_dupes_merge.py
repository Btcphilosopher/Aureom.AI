from datetime import date

from sqlalchemy import select

from app.models import Contact, ContactRelationship, Matter, MatterParty
from tests._pm_helpers import apis, new_client, setup_firm
from tests.factories import make_contact, make_matter


def _mk(a, name, **kw):
    return new_client(a.sol, name, "individual", **kw)


def test_duplicate_detection_scores_and_explains(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c1 = _mk(a, "Mr John A Smith", date_of_birth="1980-02-03", email="js@example.test", addresses=[{"line1": "1 Road", "postcode": "LS1 4AB"}])
    c2 = _mk(a, "John Smith", date_of_birth="1980-02-03", email="JS@example.test", addresses=[{"line1": "1 Road", "postcode": "ls14ab"}])
    _mk(a, "Completely Different")
    org1 = new_client(a.sol, "Pennine Widgets Ltd", company_number="01234567")
    org2 = new_client(a.sol, "Pennine Widgets Limited", company_number="01234567")
    items = a.sol.get("/clients/duplicates").json()["items"]
    pairs = {frozenset((i["a"]["id"], i["b"]["id"])): i for i in items}
    p = pairs[frozenset((c1["id"], c2["id"]))]
    assert p["score"] >= 0.8 and "Same date of birth" in p["reasons"] and "Same email address" in p["reasons"]
    assert frozenset((org1["id"], org2["id"])) in pairs and any("company number" in r for r in pairs[frozenset((org1["id"], org2["id"]))]["reasons"])
    assert not any("Completely Different" in (i["a"]["display_name"], i["b"]["display_name"]) for i in items)


def test_reviewed_merge_preserves_references_and_history(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    s = _mk(a, "Jon Smith", email="jon@example.test")
    m = _mk(a, "Jonathan Smith", email="jonathan@example.test", phone="0113 111", aliases=["Jonny S"])
    other = new_client(a.sol, "Smith & Co Ltd")
    a.sol.post(f"/clients/{m['id']}/relationships", {"to_contact_id": other["id"], "relation_type": "director_of"})
    a.sol.post(f"/clients/{s['id']}/relationships", {"to_contact_id": other["id"], "relation_type": "director_of"})  # duplicate once merged
    a.sol.post(f"/clients/{m['id']}/addresses", {"line1": "9 Old Lane", "postcode": "HX1 1AA", "is_primary": True})
    # merged contact is a client with a reference, and holds roles on matters
    for ck in ("sanctions_pep", "id_individual"):
        a.sol.post(f"/clients/{m['id']}/onboarding/checks", {"check_type": ck})
    a.partner.post(f"/clients/{m['id']}/onboarding/approve", {})
    ref = a.sol.get(f"/clients/{m['id']}").json()["client_ref"]
    client_c = make_contact(db, ns.firm, "Other Client")
    mt1 = make_matter(db, ns.firm, db.get(Contact, m["id"]), ns.partner, title="As client", reference="MM-1")
    mt2 = make_matter(db, ns.firm, client_c, ns.partner, title="As witness", reference="MM-2")
    db.add(MatterParty(firm_id=ns.firm.id, matter_id=mt2.id, contact_id=m["id"], role="witness"))
    db.add(MatterParty(firm_id=ns.firm.id, matter_id=mt1.id, contact_id=m["id"], role="client")); db.commit()
    mt1_id = str(mt1.id)

    prop = a.sol.post("/clients/merges", {"survivor_id": s["id"], "merged_id": m["id"], "field_choices": {"phone": "merged"}, "reason": "Same person"})
    assert prop.status_code == 201 and prop.json()["status"] == "pending"
    mid = prop.json()["id"]
    assert a.sol.post("/clients/merges", {"survivor_id": s["id"], "merged_id": m["id"], "reason": "again"}).status_code == 409  # already pending
    # same user cannot complete; and solicitor lacks clients.merge anyway; proposer with merge right is refused (four-eyes)
    assert a.sol.post(f"/clients/merges/{mid}/complete").status_code == 403
    other_i = _mk(a, "Zed Unrelated")
    prop2 = a.partner.post("/clients/merges", {"survivor_id": other_i["id"], "merged_id": s["id"], "reason": "test four eyes"})
    assert a.partner.post(f"/clients/merges/{prop2.json()['id']}/complete").status_code == 403
    assert a.partner.post(f"/clients/merges/{prop2.json()['id']}/complete").json()["error"]["code"] == "four_eyes_required"
    a.compliance.post(f"/clients/merges/{prop2.json()['id']}/reject", {"note": "not a duplicate"})
    # independent reviewer completes
    done = a.partner.post(f"/clients/merges/{mid}/complete", {"note": "Confirmed same individual"})
    assert done.status_code == 200 and done.json()["status"] == "completed"
    rp = done.json()["repointed"]
    assert rp.get("matter_parties.contact_id") == 2 and rp.get("matters.client_id") == 1 and rp.get("contact_relationships.duplicates_collapsed") == 1

    surv = a.sol.get(f"/clients/{s['id']}").json()
    assert "Jonathan Smith" in surv["aliases"] and "Jonny S" in surv["aliases"] and surv["phone"] == "0113 111" and surv["email"] == "jon@example.test"
    assert surv["client_ref"] == ref and surv["is_client"] is True  # reference preserved on the survivor
    assert {x["reference"]: sorted(x["roles"]) for x in surv["matters"]} == {"MM-1": ["client"], "MM-2": ["witness"]}
    assert len(surv["relationships"]) == 1 and len(surv["addresses"]) == 1
    # history: merged record remains retrievable and points at the survivor; matters still reference real rows
    old = a.sol.get(f"/clients/{m['id']}").json()
    assert old["status"] == "merged" and old["merged_into"]["id"] == s["id"] and old["display_name"] == "Jonathan Smith"
    db.expire_all()
    assert str(db.get(Matter, mt1_id).client_id) == s["id"]
    assert a.sol.patch(f"/clients/{m['id']}", {"expected_version": old["version"], "notes": "x"}).status_code == 422
    found = a.sol.get("/clients", params={"q": "Jonathan"}).json()  # findable via the survivor's alias; merged shell is hidden by default
    assert [i["id"] for i in found["items"]] == [s["id"]]
    assert a.sol.get("/clients", params={"q": "Jonathan", "include_merged": "true"}).json()["total"] == 2
    # snapshot of the merged record retained in the merge row
    assert a.sol.get("/clients/merges", params={"status": "completed"}).json()["items"][0]["snapshot"]["display_name"] == "Jonathan Smith"
