"""Templates (previewed substitution) and controlled exports (approval, four-eyes, audit, zip manifest)."""
import io
import json
import zipfile

import pytest
from sqlalchemy import select

from app.models import AuditEvent, ContactAddress
from app.security import sha256_hex
from tests.docs_helpers import arrange, drain, upload


@pytest.fixture()
def w(db, app):
    return arrange(db, app)


def test_template_preview_missing_fields_and_generate(w, db):
    db.add(ContactAddress(firm_id=w.firm.id, contact_id=w.client.id, line1="1 Mill Lane", city="Halifax", postcode="HX1 1AA", is_primary=True)); db.commit()
    a = w.api(w.fe)
    body = "Dear {{client.name}},\nRe: {{matter.reference}} - {{matter.title}}\nAddress: {{client.address}}\nHearing: {{hearing_date}}\n{{ __import__('os').system('id') }}\nFrom {{fee_earner.name}}, {{today}}"
    t = a.post("/documents/templates", {"name": "Update letter", "doc_type": "letter", "body": body,
                                        "fields": [{"key": "hearing_date", "label": "Hearing date", "source": "custom", "required": True}]})
    assert t.status_code == 201, t.text
    tid = t.json()["id"]
    pv = a.post(f"/documents/templates/{tid}/preview", {"matter_id": str(w.std.id)}).json()
    assert "hearing_date" in pv["missing"] and "[[MISSING: hearing_date]]" in pv["text"]
    assert "Dear Heron Valley Logistics Ltd," in pv["text"] and "HV-001" in pv["text"] and "1 Mill Lane, Halifax, HX1 1AA" in pv["text"]
    assert "Sam Solicitor" in pv["text"] and pv["approved"] is False
    # placeholder-like expressions are plain text, never evaluated
    assert "__import__" in pv["text"] or "MISSING: __import__('os').system('id')" not in pv["text"]
    pv2 = a.post(f"/documents/templates/{tid}/preview", {"matter_id": str(w.std.id), "custom": {"hearing_date": "3 December 2026"}}).json()
    assert "3 December 2026" in pv2["text"] and "hearing_date" not in pv2["missing"]
    # unapproved templates cannot generate; incomplete values are refused
    assert a.post(f"/documents/templates/{tid}/generate", {"matter_id": str(w.std.id), "custom": {"hearing_date": "x"}}).json()["error"]["code"] == "template_not_approved"
    assert w.api(w.para).post("/documents/templates", {"name": "n", "body": "x"}).status_code == 403
    assert a.post(f"/documents/templates/{tid}/approve").json()["approved"] is True
    r = a.post(f"/documents/templates/{tid}/generate", {"matter_id": str(w.std.id)})
    assert r.status_code == 422 and r.json()["error"]["details"]["missing"]
    g = a.post(f"/documents/templates/{tid}/generate", {"matter_id": str(w.std.id), "custom": {"hearing_date": "3 December 2026"}, "allow_incomplete": True})
    assert g.status_code == 201
    doc = g.json()
    assert doc["source"] == "template" and doc["versions"][0]["scan_status"] == "clean"
    prev = a.get(f"/documents/{doc['id']}/versions/1/preview").json()
    assert "Dear Heron Valley Logistics Ltd," in prev["pages"][0]["paragraphs"][0]["text"]
    # editing an approved template withdraws approval
    a.patch(f"/documents/templates/{tid}", {"body": body + "\nPS"})
    assert a.get(f"/documents/templates/{tid}").json()["approved"] is False


def test_export_requires_approval_four_eyes_and_is_audited(w, db):
    fe, partner = w.api(w.fe), w.api(w.partner)
    d1 = upload(fe, "a.txt", b"First export document", matter_id=w.std.id, title="Doc A").json()
    d2 = upload(fe, "b.txt", b"Second export document", matter_id=w.std.id, title="Doc B").json()
    drain()
    ids = [d1["id"], d2["id"]]
    assert w.api(w.para).post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": ids, "reason": "client asked"}).status_code == 403
    assert fe.post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": ids, "reason": ""}).status_code == 422
    ex = fe.post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": ids, "reason": "Client requested copy of file"}).json()
    assert ex["status"] == "pending_approval"
    # not ready, not approved: download refused; requester cannot approve
    assert fe.get(f"/documents/exports/{ex['id']}/download").status_code == 409
    assert fe.post(f"/documents/exports/{ex['id']}/decision", {"approve": True}).status_code == 403
    assert drain() == 0  # nothing queued until approved
    # partner requesting their own export cannot approve it either (four eyes)
    own = partner.post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": ids, "reason": "Partner copy for review"}).json()
    r = partner.post(f"/documents/exports/{own['id']}/decision", {"approve": True})
    assert r.status_code == 403 and r.json()["error"]["code"] == "four_eyes_required"
    # a different approver approves the solicitor's request
    assert partner.post(f"/documents/exports/{ex['id']}/decision", {"approve": True, "note": "ok"}).json()["status"] == "approved"
    drain()
    st = fe.get(f"/documents/exports/{ex['id']}").json()
    assert st["status"] == "ready" and st["sha256"] and st["expires_at"]
    assert w.api(w.other).get(f"/documents/exports/{ex['id']}/download").status_code in (403, 404)  # not requester
    dl = fe.get(f"/documents/exports/{ex['id']}/download")
    assert dl.status_code == 200 and sha256_hex(dl.content) == st["sha256"]
    z = zipfile.ZipFile(io.BytesIO(dl.content))
    man = json.loads(z.read("MANIFEST.json"))
    assert {m["title"] for m in man["documents"]} == {"Doc A", "Doc B"} and man["matter_reference"] == "HV-001"
    assert all(sha256_hex(z.read(m["file"])) == m["sha256"] for m in man["documents"])
    actions = set(db.execute(select(AuditEvent.action).where(AuditEvent.firm_id == w.firm.id)).scalars())
    assert {"document.export_requested", "approval.approved", "document.export_built", "document.export_downloaded"} <= actions
    # rejected exports never build
    rej = fe.post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": ids[:1], "reason": "Another copy please"}).json()
    assert partner.post(f"/documents/exports/{rej['id']}/decision", {"approve": False}).json()["status"] == "rejected"
    assert drain() == 0


def test_export_job_refuses_if_document_changed_after_approval(w, db):
    from tests.docs_helpers import add_version
    fe, partner = w.api(w.fe), w.api(w.partner)
    d = upload(fe, "a.txt", b"Original content", matter_id=w.std.id, title="Doc A").json(); drain()
    ex = fe.post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": [d["id"]], "reason": "Client copy needed"}).json()
    add_version(fe, d["id"], "a.txt", b"Changed after the request")
    partner.post(f"/documents/exports/{ex['id']}/decision", {"approve": True})  # approval payload was for v1
    drain()
    st = fe.get(f"/documents/exports/{ex['id']}").json()
    assert st["status"] == "failed" and "after approval" in st["error"]


def test_export_blocked_for_restricted_matter_non_member(w, db):
    fe = w.api(w.fe)
    d = upload(fe, "s.txt", b"restricted text", matter_id=w.restricted.id).json(); drain()
    r = w.api(w.other).post("/documents/exports", {"matter_id": str(w.restricted.id), "document_ids": [d["id"]], "reason": "I would like these"})
    assert r.status_code == 403
