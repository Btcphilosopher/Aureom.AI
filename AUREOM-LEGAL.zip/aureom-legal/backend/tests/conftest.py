from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from pathlib import Path

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session

ADMIN_URL = os.environ.get("TEST_ADMIN_URL", "postgresql+psycopg://postgres:postgres@localhost:5432/postgres")
BACKEND = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session", autouse=True)
def _database():
    """Create a throw-away database per test session: schema via Alembic (TEST_USE_MIGRATIONS=1) or metadata,
    then the SQL safeguards (RLS, triggers). The app connects as a NON-superuser role so RLS is really enforced."""
    name = f"aureom_t_{uuid.uuid4().hex[:8]}"
    admin = create_engine(ADMIN_URL, isolation_level="AUTOCOMMIT")
    with admin.connect() as c:
        c.execute(text(f"CREATE DATABASE {name}"))
        exists = c.execute(text("select 1 from pg_roles where rolname='aureom_app'")).first()
        if not exists:
            c.execute(text("CREATE ROLE aureom_app LOGIN PASSWORD 'aureom_app' NOSUPERUSER NOBYPASSRLS"))
    base = make_url(ADMIN_URL).set(database=name)
    owner_url = base.render_as_string(hide_password=False)
    app_url = base.set(username="aureom_app", password="aureom_app").render_as_string(hide_password=False)
    storage = tempfile.mkdtemp(prefix="aureom_store_")
    os.environ.update(DATABASE_URL=app_url, MIGRATION_DATABASE_URL=owner_url, LOCAL_STORAGE_PATH=storage, STORAGE_BACKEND="local",
                      ENV="test", DEMO_MODE="true", AI_PROVIDER="mock")
    from app.config import get_settings
    from app.db.session import reset_engine
    from app.storage import reset_storage

    get_settings.cache_clear(); reset_engine(); reset_storage()
    if os.environ.get("TEST_USE_MIGRATIONS"):
        from alembic import command
        from alembic.config import Config
        cfg = Config(str(BACKEND / "alembic.ini")); cfg.set_main_option("script_location", str(BACKEND / "migrations"))
        os.environ["ALEMBIC_DATABASE_URL"] = owner_url
        command.upgrade(cfg, "head")
    else:
        from app.models import Base
        eng = create_engine(owner_url)
        Base.metadata.create_all(eng)
        with eng.begin() as conn:
            conn.exec_driver_sql((BACKEND / "app" / "db" / "safeguards.sql").read_text().replace("%", "%%"))
        eng.dispose()
    from app import integrations
    integrations.load_all()
    yield owner_url
    reset_engine()
    with admin.connect() as c:
        c.execute(text(f"DROP DATABASE IF EXISTS {name} WITH (FORCE)"))
    shutil.rmtree(storage, ignore_errors=True)


@pytest.fixture(scope="session")
def owner_engine(_database):
    eng = create_engine(_database)
    yield eng
    eng.dispose()


@pytest.fixture()
def db(owner_engine):
    """Owner-privileged session (bypasses RLS) for arranging test data. Commits are real."""
    s = Session(owner_engine, expire_on_commit=False)
    yield s
    s.rollback()
    s.close()


@pytest.fixture(scope="session")
def app():
    from app.main import create_app
    return create_app()
