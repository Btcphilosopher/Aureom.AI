from datetime import date
from decimal import Decimal

from sqlalchemy import select

from app.models import AuditEvent, Task, TimeEntry
from tests._pm_helpers import apis, make_template, new_client, onboard_and_clear, setup_firm


def _prospect(a, ns, tpl, name="Workflow Client Ltd", **over):
    c = new_client(a.sol, name)
    r = a.sol.post("/matters", {"title": f"{name} agreement", "client_id": c["id"], "template_id": tpl["id"], "responsible_partner_id": str(ns.partner.id),
                                "target_date": "2027-02-01", **over})
    assert r.status_code == 201, r.text
    return c, r.json()


def _open(a, ns, tpl, name="Workflow Client Ltd", **over):
    c, m = _prospect(a, ns, tpl, name, **over)
    onboard_and_clear(a, c["id"])
    for it in m["checklist"]:
        if it["phase"] == "opening" and it["required"]:
            a.sol.post(f"/matters/{m['id']}/checklist/{it['id']}", {"completed": True})
    r = a.partner.post(f"/matters/{m['id']}/transitions", {"to_status": "open", "expected_version": m["version"]})
    assert r.status_code == 200, r.text
    return c, r.json()["matter"]


def test_create_from_template_builds_checklists_stage_tasks_and_reference(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    tpl = make_template(a.partner)
    assert a.sol.post("/matters/templates", {**tpl, "name": "Another"}).status_code == 403  # only partner/admin manage templates
    assert a.admin.post("/matters/templates", {**tpl, "name": "Admin made"}).status_code == 201
    c, m = _prospect(a, ns, tpl)
    assert m["status"] == "prospective" and m["stage"] == "instruct"
    year = date.today().year
    assert m["reference"] == f"PCS-COM-{year}-0001"
    assert [i["label"] for i in m["checklist"] if i["phase"] == "opening"] == ["Client care letter sent", "Optional welcome pack"]
    assert len([i for i in m["checklist"] if i["phase"] == "closing"]) == 2
    assert [p["role"] for p in m["parties"]] == ["client"]
    assert db.execute(select(Task).where(Task.matter_id == m["id"])).scalars().one().title == "Send client care letter"
    _, m2 = _prospect(a, ns, tpl, "Second Client Ltd")
    assert m2["reference"].endswith("-0002")
    assert m["template"]["required_fields"] == ["target_date"]
    # stage must be one of the template's
    assert a.sol.post(f"/matters/{m['id']}/stage", {"stage": "nonsense", "expected_version": m["version"]}).status_code == 422
    r = a.sol.post(f"/matters/{m['id']}/stage", {"stage": "draft", "expected_version": m["version"]})
    assert r.status_code == 200 and r.json()["stage"] == "draft"
    # parties
    other = new_client(a.sol, "Counter Party Ltd")
    p = a.sol.post(f"/matters/{m['id']}/parties", {"contact_id": other["id"], "role": "counterparty"})
    assert p.status_code == 201
    assert a.sol.post(f"/matters/{m['id']}/parties", {"contact_id": other["id"], "role": "counterparty"}).status_code == 422
    detail = a.sol.get(f"/matters/{m['id']}").json()
    client_party = [x for x in detail["parties"] if x["role"] == "client"][0]
    assert a.sol.delete(f"/matters/{m['id']}/parties/{client_party['id']}").status_code == 409
    assert a.sol.delete(f"/matters/{m['id']}/parties/{p.json()['id']}").status_code == 204


def test_open_requires_partner_approval_and_records_who_changed(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    tpl = make_template(a.partner)
    c, m = _prospect(a, ns, tpl)
    onboard_and_clear(a, c["id"])
    for it in m["checklist"]:
        if it["required"] and it["phase"] == "opening":
            a.sol.post(f"/matters/{m['id']}/checklist/{it['id']}", {"completed": True})
    av = a.sol.get(f"/matters/{m['id']}/transitions/available").json()
    assert av["transitions"][0]["to_status"] == "open" and av["transitions"][0]["allowed"] and av["transitions"][0]["needs_approval_from_partner"]
    # invalid transition
    bad = a.sol.post(f"/matters/{m['id']}/transitions", {"to_status": "paused", "reason": "x", "expected_version": m["version"]})
    assert bad.status_code == 409 and bad.json()["error"]["code"] == "invalid_transition"
    # solicitor request -> 202 pending approval, matter unchanged
    r = a.sol.post(f"/matters/{m['id']}/transitions", {"to_status": "open", "expected_version": m["version"]})
    assert r.status_code == 202 and r.json()["executed"] is False and r.json()["matter"]["status"] == "prospective"
    apid = r.json()["approval_id"]
    assert r.json()["matter"]["pending_transition"]["approval_id"] == apid
    # solicitor cannot approve; para cannot; partner can
    assert a.sol.post(f"/matters/{m['id']}/transitions/{apid}/decide", {"approve": True}).status_code == 403
    d = a.partner.post(f"/matters/{m['id']}/transitions/{apid}/decide", {"approve": True, "note": "Approved to open"})
    assert d.status_code == 200 and d.json()["executed"] and d.json()["matter"]["status"] == "open"
    hist = d.json()["matter"]["state_history"]
    assert hist[-1]["from"] == "prospective" and hist[-1]["to"] == "open" and hist[-1]["actor"] == "Penelope Partner" and hist[-1]["requested_by"] == "Sam Solicitor"
    assert d.json()["matter"]["opened_at"] == date.today().isoformat() and d.json()["matter"]["conflict_search_id"]
    assert a.partner.post(f"/matters/{m['id']}/transitions/{apid}/decide", {"approve": True}).status_code == 409  # already decided
    acts = a.partner.get(f"/matters/{m['id']}/activity").json()["items"]
    assert any(i["action"] == "matter.state_changed" for i in acts)


def test_approval_is_bound_to_matter_version(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    tpl = make_template(a.partner)
    c, m = _prospect(a, ns, tpl)
    onboard_and_clear(a, c["id"])
    for it in m["checklist"]:
        if it["required"] and it["phase"] == "opening":
            a.sol.post(f"/matters/{m['id']}/checklist/{it['id']}", {"completed": True})
    r = a.sol.post(f"/matters/{m['id']}/transitions", {"to_status": "open", "expected_version": m["version"]})
    apid = r.json()["approval_id"]
    # matter edited after the request -> the approved payload no longer matches
    a.sol.patch(f"/matters/{m['id']}", {"expected_version": m["version"], "title": "Renamed after request"})
    d = a.partner.post(f"/matters/{m['id']}/transitions/{apid}/decide", {"approve": True})
    assert d.status_code == 409 and d.json()["error"]["code"] == "approval_stale"
    # rejection path
    cur = a.sol.get(f"/matters/{m['id']}").json()
    r2 = a.sol.post(f"/matters/{m['id']}/transitions", {"to_status": "open", "expected_version": cur["version"]})
    rej = a.partner.post(f"/matters/{m['id']}/transitions/{r2.json()['approval_id']}/decide", {"approve": False, "note": "Not yet"})
    assert rej.status_code == 200 and rej.json()["approval_status"] == "rejected" and rej.json()["matter"]["status"] == "prospective"


def test_pause_close_reopen_with_blockers_hold_and_retention(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    tpl = make_template(a.partner)
    c, m = _open(a, ns, tpl)
    mid = m["id"]
    ver = lambda: a.partner.get(f"/matters/{mid}").json()["version"]  # noqa: E731
    assert a.partner.post(f"/matters/{mid}/transitions", {"to_status": "paused", "expected_version": ver()}).json()["error"]["code"] == "reason_required"
    p = a.partner.post(f"/matters/{mid}/transitions", {"to_status": "paused", "reason": "Awaiting client funds", "expected_version": ver()})
    assert p.status_code == 200 and p.json()["matter"]["status"] == "paused"
    assert a.partner.post(f"/matters/{mid}/transitions", {"to_status": "open", "reason": "Funds received", "expected_version": ver()}).json()["matter"]["status"] == "open"
    # closing blockers: checklist, legal hold, WIP, retention (template default key is not set until chosen? default applied at creation)
    db.add(TimeEntry(firm_id=ns.firm.id, matter_id=mid, user_id=ns.sol.id, work_date=date.today(), minutes=30, narrative="Drafting", rate=Decimal("200.00"),
                     amount=Decimal("100.00"), status="approved")); db.commit()
    assert a.partner.post(f"/matters/{mid}/legal-hold", {"active": True, "reason": "Regulatory enquiry"}).status_code == 200
    r = a.partner.post(f"/matters/{mid}/transitions", {"to_status": "closed", "expected_version": ver()})
    codes = {b["code"] for b in r.json()["error"]["details"]["blockers"]}
    assert r.status_code == 422 and {"closing_checklist", "legal_hold", "unbilled_wip"} <= codes
    assert a.sol.post(f"/matters/{mid}/legal-hold", {"active": False, "reason": "release it"}).status_code == 403
    a.partner.post(f"/matters/{mid}/legal-hold", {"active": False, "reason": "Enquiry closed"})
    time_row = db.execute(select(TimeEntry).where(TimeEntry.matter_id == mid)).scalars().one()
    time_row.status, time_row.invoice_line_id = "billed", __import__("uuid").uuid4(); db.commit()
    for it in a.partner.get(f"/matters/{mid}").json()["checklist"]:
        if it["phase"] == "closing" and it["required"]:
            a.partner.post(f"/matters/{mid}/checklist/{it['id']}", {"completed": True})
    r = a.partner.post(f"/matters/{mid}/transitions", {"to_status": "closed", "expected_version": ver(), "retention_policy_key": "nope"})
    assert r.status_code == 422 and r.json()["error"]["details"]["blockers"][0]["code"] == "retention_policy_invalid"
    r = a.partner.post(f"/matters/{mid}/transitions", {"to_status": "closed", "expected_version": ver(), "retention_policy_key": "general_6y"})
    assert r.status_code == 200, r.text
    closed = r.json()["matter"]
    assert closed["status"] == "closed" and closed["closed_at"] == date.today().isoformat()
    assert closed["retention_until"] == date(date.today().year + 6, date.today().month, min(date.today().day, 28) if date.today().month == 2 else date.today().day).isoformat()
    assert [h["to"] for h in closed["state_history"]] == ["open", "paused", "open", "closed"]
    # closed matters are read-only until reopened (with a reason)
    assert a.partner.patch(f"/matters/{mid}", {"expected_version": closed["version"], "title": "x"}).json()["error"]["code"] == "matter_closed"
    assert a.partner.post(f"/matters/{mid}/transitions", {"to_status": "open", "expected_version": closed["version"]}).json()["error"]["code"] == "reason_required"
    re = a.partner.post(f"/matters/{mid}/transitions", {"to_status": "open", "reason": "Client instructed further work", "expected_version": closed["version"]})
    assert re.status_code == 200 and re.json()["matter"]["status"] == "open" and re.json()["matter"]["closed_at"] is None and re.json()["matter"]["retention_until"] is None
    # financial summary is permission-gated
    assert a.para.get(f"/matters/{mid}").json()["financial"] is None
    fin = a.partner.get(f"/matters/{mid}").json()["financial"]
    assert fin["client_balance"] == "0" and fin["unbilled_entries"] == 0 and "Unbilled" in fin["basis"]


def test_optimistic_concurrency_on_matters_and_chronology(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    tpl = make_template(a.partner)
    c, m = _prospect(a, ns, tpl)
    ok = a.sol.patch(f"/matters/{m['id']}", {"expected_version": m["version"], "description": "v2", "budget_amount": "1500.00"})
    assert ok.status_code == 200
    stale = a.para.patch(f"/matters/{m['id']}", {"expected_version": m["version"], "description": "stale"})
    assert stale.status_code == 403 or stale.status_code == 409
    stale = a.sol_b.patch(f"/matters/{m['id']}", {"expected_version": m["version"], "description": "stale"})
    assert stale.status_code == 409 and stale.json()["error"]["code"] == "version_conflict"
    # chronology: explicit vs inferred; human edits recorded; rejection keeps history
    e = a.sol.post(f"/matters/{m['id']}/chronology", {"event_date": "2026-03-01", "date_text": "1 March 2026", "description": "Heads of terms signed",
                                                       "source": {"type": "document", "page": 2}})
    assert e.status_code == 201
    inf = a.sol.post(f"/matters/{m['id']}/chronology", {"date_basis": "inferred", "description": "Approximate date of supply failure"})
    assert inf.status_code == 201
    assert a.sol.post(f"/matters/{m['id']}/chronology", {"description": "No date at all, claimed explicit"}).status_code == 422
    items = a.sol.get(f"/matters/{m['id']}/chronology").json()["items"]
    assert [i["date_basis"] for i in items] == ["explicit", "inferred"]
    up = a.sol.patch(f"/matters/{m['id']}/chronology/{e.json()['id']}", {"expected_version": e.json()["version"], "description": "Heads of terms signed by both parties"})
    assert up.status_code == 200 and up.json()["status"] == "edited"
    assert a.sol.patch(f"/matters/{m['id']}/chronology/{e.json()['id']}", {"expected_version": e.json()["version"], "description": "stale"}).status_code == 409
    assert a.sol.delete(f"/matters/{m['id']}/chronology/{inf.json()['id']}").status_code == 204
    assert len(a.sol.get(f"/matters/{m['id']}/chronology").json()["items"]) == 1
    all_ = a.sol.get(f"/matters/{m['id']}/chronology", params={"include_rejected": "true"}).json()["items"]
    assert len(all_) == 2 and [i["edited_by"] for i in all_ if i["status"] == "rejected"] == ["Sam Solicitor"]
    # activity feed carries no confidential text
    acts = a.sol.get(f"/matters/{m['id']}/activity").json()
    assert acts["total"] >= 4 and "Heads of terms" not in str(acts)
