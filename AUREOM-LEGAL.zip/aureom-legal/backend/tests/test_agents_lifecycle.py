"""Agent run state machine, approval binding, idempotent execution, cancellation/timeout/retry, budgets."""
import threading

import pytest
from sqlalchemy import select, text

from app.agents import actions as A, llm, runner
from app.agents.llm import MockProvider, ProviderError
from app.db.session import new_session
from app.deps import Ctx
from app.errors import BudgetExceeded, InvalidState, PermissionDenied
from app.models import AgentProposedAction, AgentRun, AgentRunEvent, Deadline, Role, Task, User
from app.services import jobs
from tests.agents_helpers import *  # noqa: F401,F403
from tests.agents_helpers import _reset_ai, run_sync, set_ai


def actions_of(db, run):
    db.expire_all()
    return db.execute(select(AgentProposedAction).where(AgentProposedAction.run_id == run.id).order_by(AgentProposedAction.created_at)).scalars().all()


def decide(ctx, run, db, decision="approve", only=None, execute=False):
    acts = [a for a in actions_of(db, run) if not only or a.action_type in only]
    return runner.review_run(ctx, run.id, [{"action_id": a.id, "decision": decision} for a in acts], execute=execute)


# ------------------------------------------------------------------------------------------- state machine
def test_full_path_queued_to_completed_with_events_and_notification(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = runner.start_run(ctx, "document_review", matter_id=w.matter.id)  # queued + job
    ctx.db.commit()
    assert run.status == "queued" and run.approval_state == "not_required"
    from app.worker import load_handlers
    load_handlers()
    assert jobs.run_all_pending() >= 1
    db.expire_all()
    run = db.get(AgentRun, run.id)
    assert run.status == "awaiting_review" and run.approval_state == "pending" and run.started_at and run.attempts == 1
    assert run.tokens_in > 0 and run.cost_gbp > 0
    rctx = sess.ctx(w.firm, w.partner)  # a different reviewer
    run = decide(rctx, run, db)
    assert run.status == "approved" and run.approval_state == "approved" and run.reviewed_by == w.partner.id
    # worker executes the approved run
    jobs.run_all_pending()
    db.expire_all()
    run = db.get(AgentRun, run.id)
    assert run.status == "completed" and run.execution_result["executed"] == len(actions_of(db, run)) and run.finished_at
    kinds = [e.kind for e in db.execute(select(AgentRunEvent).where(AgentRunEvent.run_id == run.id).order_by(AgentRunEvent.created_at)).scalars()]
    assert {"state_change", "tool_call", "retrieval", "human_decision", "execution"} <= set(kinds)
    states = [e.details.get("to") for e in db.execute(select(AgentRunEvent).where(AgentRunEvent.run_id == run.id, AgentRunEvent.kind == "state_change").order_by(AgentRunEvent.created_at)).scalars() if e.details.get("to")]
    assert states[:3] == ["queued", "running", "awaiting_review"] and "approved" in states and "executing" in states and states[-1] == "completed"
    from app.models import Notification
    assert db.execute(select(Notification).where(Notification.user_id == w.solicitor.id, Notification.kind == "ai_review")).scalars().first()


def test_reject_and_partial_approval_and_double_review(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "document_review", matter_id=w.matter.id)
    rejected = decide(ctx, run, db, "reject")
    assert rejected.status == "rejected" and rejected.approval_state == "rejected" and rejected.finished_at
    assert not db.execute(select(Task).where(Task.matter_id == w.matter.id)).scalars().first()  # rejected => nothing applied
    with pytest.raises(InvalidState):  # double click
        decide(ctx, run, db, "reject")
    ctx.db.rollback()
    run2 = run_sync(sess.ctx(w.firm, w.solicitor), "document_review", matter_id=w.matter.id)
    acts = actions_of(db, run2)
    c2 = sess.ctx(w.firm, w.solicitor)
    r = runner.review_run(c2, run2.id, [{"action_id": acts[0].id, "decision": "approve"}] + [{"action_id": a.id, "decision": "reject"} for a in acts[1:]], execute=True)
    assert r.status == "completed" and r.approval_state == "partial" and r.execution_result["executed"] == 1
    statuses = [a.status for a in actions_of(db, run2)]
    assert statuses.count("executed") == 1 and statuses.count("rejected") == len(acts) - 1


def test_readonly_policy_and_manual_review_when_auto_complete_disabled(db, world, sess):
    w = world
    set_ai(db, w.firm, auto_complete_readonly=False)
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "matter_briefing", matter_id=w.matter.id)
    assert run.status == "awaiting_review" and run.approval_state == "pending"
    done = runner.review_run(ctx, run.id, [])  # nothing proposed: acknowledging completes it
    assert done.status == "completed" and done.approval_state == "not_required"


def test_invalid_transitions_are_refused(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "matter_briefing", matter_id=w.matter.id)
    assert run.status == "completed"
    for to in ("running", "approved", "executing", "queued"):
        with pytest.raises(InvalidState):
            runner._transition(ctx.db, run, to)
    with pytest.raises(InvalidState):
        runner.cancel_run(ctx, run.id)
    with pytest.raises(InvalidState):
        runner.retry_run(ctx, run.id)


def test_cancel_queued_awaiting_review_and_mid_run(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    q = runner.start_run(ctx, "document_review", matter_id=w.matter.id, enqueue=False); ctx.db.commit()
    assert runner.cancel_run(ctx, q.id).status == "cancelled"
    assert runner.process_run(ctx.db, q.id).status == "cancelled"  # a cancelled run is never processed
    a = run_sync(sess.ctx(w.firm, w.solicitor), "document_review", matter_id=w.matter.id)
    c2 = sess.ctx(w.firm, w.solicitor)
    runner.cancel_run(c2, a.id); c2.db.commit()
    assert all(x.status == "superseded" for x in actions_of(db, a)) and db.get(AgentRun, a.id).status == "cancelled"

    class CancelMidRun(MockProvider):  # the user clicks cancel while the model call is in flight
        def complete_structured(self, *args, **kw):
            with new_session(w.firm.id) as s:
                s.execute(text("update agent_runs set cancel_requested = true")); s.commit()
            return super().complete_structured(*args, **kw)
    llm.set_provider_override(CancelMidRun())
    r = run_sync(sess.ctx(w.firm, w.solicitor), "document_review", matter_id=w.matter.id)
    assert r.status == "cancelled" and not actions_of(db, r)  # nothing proposed after cancellation
    # only the requester (or ai admin) may cancel
    llm.set_provider_override(None)
    rc = sess.ctx(w.firm, w.solicitor)
    other = runner.start_run(rc, "document_review", matter_id=w.matter.id, enqueue=False); rc.db.commit()
    other_ctx = sess.ctx(w.firm, w.paralegal)
    with pytest.raises(PermissionDenied):
        runner.cancel_run(other_ctx, other.id)


def test_timeout_marks_run_failed_without_retry(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = runner.start_run(ctx, "document_review", matter_id=w.matter.id, enqueue=False)
    run.timeout_seconds = 0
    ctx.db.commit()
    r = runner.process_run(ctx.db, run.id)
    assert r.status == "failed" and r.error.startswith("run_timeout") and r.attempts == 1 and r.result is None


def test_transient_provider_errors_retry_then_fail_at_limit(db, world, sess):
    w = world

    class Flaky(MockProvider):
        calls = 0
        def complete_structured(self, *a, **k):
            Flaky.calls += 1
            raise ProviderError("upstream 503")
    llm.set_provider_override(Flaky())
    ctx = sess.ctx(w.firm, w.solicitor)
    run = runner.start_run(ctx, "matter_briefing", matter_id=w.matter.id)
    ctx.db.commit()
    from app.worker import load_handlers
    load_handlers()
    jobs.run_all_pending()
    db.expire_all()
    run = db.get(AgentRun, run.id)
    assert Flaky.calls == 2 and run.attempts == 2 and run.status == "failed" and "provider_error" in run.error
    c2 = sess.ctx(w.firm, w.solicitor)
    with pytest.raises(InvalidState) as e:
        runner.retry_run(c2, run.id)
    assert e.value.code == "retry_limit_reached"


def test_manual_retry_after_analysis_failure_within_limit(db, world, sess):
    w = world
    set_ai(db, w.firm)  # no-op; ensures settings exist

    class Once(MockProvider):
        n = 0
        def complete_structured(self, *a, **k):
            Once.n += 1
            if Once.n == 1:
                raise ProviderError("blip")
            return super().complete_structured(*a, **k)
    llm.set_provider_override(Once())
    ctx = sess.ctx(w.firm, w.solicitor)
    run = runner.start_run(ctx, "matter_briefing", matter_id=w.matter.id, enqueue=False); ctx.db.commit()
    r = runner.process_run(ctx.db, run.id)  # attempt 1 fails transiently -> requeued automatically
    assert r.status == "queued" and r.attempts == 1
    r = runner.process_run(ctx.db, run.id)
    assert r.status == "completed" and r.attempts == 2


# ------------------------------------------------------------------------------------------- execution & approval binding
def test_edit_after_approval_clears_approval_and_requires_renewed_approval(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "document_review", matter_id=w.matter.id)
    act = next(a for a in actions_of(db, run) if a.action_type == "create_task")
    orig_params = dict(act.params)
    runner.review_run(ctx, run.id, [{"action_id": act.id, "decision": "approve"}] + [{"action_id": a.id, "decision": "approve"} for a in actions_of(db, run) if a.id != act.id])
    run = db.get(AgentRun, run.id); db.expire_all()
    assert db.get(AgentRun, run.id).status == "approved"
    first = db.get(AgentProposedAction, act.id)
    h1 = first.approved_hash
    assert h1 == A.binding_hash(run, first) and first.status == "approved"
    # a reviewer changes the content after approval
    c2 = sess.ctx(w.firm, w.partner)
    runner.edit_action(c2, run.id, act.id, {**orig_params, "title": "Different task title chosen by reviewer"})
    c2.db.commit(); db.expire_all()
    run, edited = db.get(AgentRun, run.id), db.get(AgentProposedAction, act.id)
    assert edited.status == "proposed" and edited.approved_hash is None and edited.approved_by is None and edited.edit_count == 1
    assert run.status == "awaiting_review" and run.approval_state == "pending"
    assert edited.edit_history[0]["before"]["title"] == orig_params["title"] and edited.edit_history[0]["after"]["title"].startswith("Different")
    ev = db.execute(select(AgentRunEvent).where(AgentRunEvent.run_id == run.id, AgentRunEvent.kind == "human_edit")).scalar_one()
    assert ev.details["renewed_approval_required"] is True and ev.details["fields_changed"] == ["title"] and "Different" not in str(ev.details)
    # the run cannot execute until approved again
    assert runner.execute_run(sess.ctx(w.firm, w.solicitor).db, run.id).status == "awaiting_review"
    c3 = sess.ctx(w.firm, w.solicitor)
    r = runner.review_run(c3, run.id, [{"action_id": act.id, "decision": "approve"}], execute=True)
    db.expire_all()
    assert r.status == "completed"
    assert db.get(AgentProposedAction, act.id).approved_hash != h1  # new binding for the new content
    assert db.execute(select(Task).where(Task.title == "Different task title chosen by reviewer")).scalar_one().source == "agent"


def test_correction_supplied_with_decision_binds_approval_to_corrected_content(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "document_review", matter_id=w.matter.id)
    acts = actions_of(db, run)
    t = next(a for a in acts if a.action_type == "create_task")
    decisions = [{"action_id": a.id, "decision": "approve"} for a in acts if a.id != t.id]
    decisions.append({"action_id": t.id, "decision": "approve", "params": {**t.params, "priority": "urgent", "title": "Corrected title"}})
    r = runner.review_run(ctx, run.id, decisions, execute=True)
    assert r.status == "completed"
    db.expire_all()
    done = db.get(AgentProposedAction, t.id)
    assert done.params["title"] == "Corrected title" and done.edit_count == 1 and done.status == "executed"
    assert db.execute(select(Task).where(Task.title == "Corrected title")).scalar_one().priority == "urgent"


def test_tampered_params_after_approval_are_refused_at_execution(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "document_review", matter_id=w.matter.id)
    act = next(a for a in actions_of(db, run) if a.action_type == "create_task")
    run = decide(ctx, run, db, only=None)
    assert run.status == "approved"
    db.execute(text("update agent_proposed_actions set params = jsonb_set(params, '{title}', '\"Tampered title\"') where id = :i"), {"i": act.id}); db.commit()
    r = runner.execute_run(sess.ctx(w.firm, w.solicitor).db, run.id)
    db.expire_all()
    bad = db.get(AgentProposedAction, act.id)
    assert bad.status == "failed" and "approval_stale" in bad.error
    assert not db.execute(select(Task).where(Task.title == "Tampered title")).first()
    assert r.status == "failed" and r.execution_result["failed"] == 1


def test_execution_is_idempotent_sequential_and_concurrent(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "document_review", matter_id=w.matter.id)
    n_tasks = sum(1 for a in actions_of(db, run) if a.action_type == "create_task")
    n_dl = sum(1 for a in actions_of(db, run) if a.action_type == "suggest_deadline")
    run = decide(ctx, run, db)
    results = []

    def go():
        with new_session(w.firm.id) as s:
            results.append(runner.execute_run(s, run.id).status)
    ts = [threading.Thread(target=go) for _ in range(4)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert runner.execute_run(sess.ctx(w.firm, w.solicitor).db, run.id).status == "completed"  # and once more, sequentially
    db.expire_all()
    assert len(db.execute(select(Task).where(Task.agent_run_id == run.id)).scalars().all()) == n_tasks
    assert len(db.execute(select(Deadline).where(Deadline.agent_run_id == run.id)).scalars().all()) == n_dl
    assert all(a.status == "executed" for a in actions_of(db, run))
    assert db.execute(select(AgentRunEvent).where(AgentRunEvent.run_id == run.id, AgentRunEvent.kind == "execution")).scalars().all().__len__() == n_tasks + n_dl
    # a duplicate review of an already-approved run is refused
    with pytest.raises(InvalidState):
        runner.review_run(sess.ctx(w.firm, w.solicitor), run.id, [])


def test_failed_execution_can_be_retried_without_duplicating_successes(db, world, sess, monkeypatch):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    run = run_sync(ctx, "document_review", matter_id=w.matter.id)
    n_dl = sum(1 for a in actions_of(db, run) if a.action_type == "suggest_deadline")
    orig = A._EXEC["create_task"]
    monkeypatch.setitem(A._EXEC, "create_task", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))
    run = decide(ctx, run, db, execute=True)
    assert run.status == "failed" and run.execution_result["failed"] >= 1 and run.execution_result["executed"] == n_dl
    monkeypatch.setitem(A._EXEC, "create_task", orig)
    c2 = sess.ctx(w.firm, w.solicitor)
    r = runner.retry_run(c2, run.id, enqueue=False); c2.db.commit()
    assert r.status == "approved"
    r = runner.execute_run(c2.db, run.id)
    assert r.status == "completed"
    db.expire_all()
    assert len(db.execute(select(Deadline).where(Deadline.agent_run_id == run.id)).scalars().all()) == n_dl  # not duplicated
    assert db.execute(select(Task).where(Task.agent_run_id == run.id)).scalars().first()


def test_run_idempotency_key_returns_same_run(db, world, sess):
    w = world
    ctx = sess.ctx(w.firm, w.solicitor)
    a = runner.start_run(ctx, "matter_briefing", matter_id=w.matter.id, idempotency_key="click-1", enqueue=False); ctx.db.commit()
    b = runner.start_run(sess.ctx(w.firm, w.solicitor), "matter_briefing", matter_id=w.matter.id, idempotency_key="click-1", enqueue=False)
    assert a.id == b.id
    c = runner.start_run(sess.ctx(w.firm, w.paralegal), "matter_briefing", matter_id=w.matter.id, idempotency_key="click-1", enqueue=False)
    assert c.id != a.id  # keys are per user


# ------------------------------------------------------------------------------------------- budgets
def test_monthly_budget_blocks_new_runs(db, world, sess):
    w = world
    run = run_sync(sess.ctx(w.firm, w.solicitor), "matter_briefing", matter_id=w.matter.id)
    assert run.cost_gbp > 0
    set_ai(db, w.firm, monthly_budget_gbp=0.00001)
    with pytest.raises(BudgetExceeded) as e:
        runner.start_run(sess.ctx(w.firm, w.solicitor), "matter_briefing", matter_id=w.matter.id, enqueue=False)
    assert e.value.status_code == 429 and "spent_gbp" in e.value.details
    u = runner.usage_summary(sess.ctx(w.firm, w.solicitor))
    assert u["currency"] == "GBP" and u["spent_gbp"] != "0.0000" and u["by_agent"][0]["agent_type"] == "matter_briefing" and "basis" in u


def test_daily_run_limit_and_per_run_budget(db, world, sess):
    w = world
    set_ai(db, w.firm, user_daily_runs=1)
    run_sync(sess.ctx(w.firm, w.solicitor), "matter_briefing", matter_id=w.matter.id)
    with pytest.raises(BudgetExceeded):
        runner.start_run(sess.ctx(w.firm, w.solicitor), "matter_briefing", matter_id=w.matter.id, enqueue=False)
    pc = sess.ctx(w.firm, w.paralegal)
    runner.start_run(pc, "matter_briefing", matter_id=w.matter.id, enqueue=False); pc.db.commit()  # limit is per user
    set_ai(db, w.firm, user_daily_runs=100, per_run_budget_gbp=0.0000001)
    r = run_sync(sess.ctx(w.firm, w.partner), "document_review", matter_id=w.matter.id)
    assert r.status == "failed" and r.error.startswith("budget_exceeded") and not actions_of(db, r)


def test_agents_can_be_disabled_per_firm(db, world, sess):
    w = world
    set_ai(db, w.firm, allowed_agents=["knowledge"])
    with pytest.raises(PermissionDenied) as e:
        runner.start_run(sess.ctx(w.firm, w.solicitor), "document_review", matter_id=w.matter.id, enqueue=False)
    assert e.value.code == "agent_disabled"
    set_ai(db, w.firm, enabled=False, allowed_agents=list(__import__("app.agents.policy", fromlist=["x"]).AGENT_POLICY))
    with pytest.raises(PermissionDenied):
        runner.start_run(sess.ctx(w.firm, w.solicitor), "knowledge", input={"query": "x"}, enqueue=False)
