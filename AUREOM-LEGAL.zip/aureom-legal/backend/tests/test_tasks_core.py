"""Tasks: visibility, assignment, dependencies, recurrence, reminders/escalation, concurrency."""
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select

from app.db.session import new_session
from app.models import Notification, Task
from app.services import task_jobs
from app.services.tasks import next_due
from tests.factories import api_for, make_contact, make_firm, make_matter, make_team, make_user


@pytest.fixture()
def world(db):
    firm = make_firm(db)
    partner = make_user(db, firm, "partner", "Penny Partner")
    sol = make_user(db, firm, "solicitor", "Sam Solicitor")
    other = make_user(db, firm, "solicitor", "Olive Other")
    para = make_user(db, firm, "paralegal", "Pat Para")
    client = make_contact(db, firm, "Acme Widgets Ltd", "organisation")
    std = make_matter(db, firm, client, partner, sol, title="Standard matter")
    restricted = make_matter(db, firm, client, partner, sol, access_level="restricted", title="Restricted matter")
    return dict(firm=firm, partner=partner, sol=sol, other=other, para=para, client=client, std=std, restricted=restricted)


def _in(hours):
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat()


def test_restricted_matter_task_visibility(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    r = a.post("/tasks", {"title": "Secret task", "matter_id": str(w["restricted"].id), "assignee_id": str(w["sol"].id)})
    assert r.status_code == 201, r.text
    tid = r.json()["id"]
    a.post("/tasks", {"title": "Open task", "matter_id": str(w["std"].id)})
    # non-member solicitor: not in lists, 403 by id, cannot create on that matter
    o = api_for(app, w["other"])
    titles = [t["title"] for t in o.get("/tasks").json()["items"]]
    assert "Open task" in titles and "Secret task" not in titles
    r = o.get(f"/tasks/{tid}")
    assert r.status_code == 403 and r.json()["error"]["code"] == "matter_access_denied"
    assert o.post("/tasks", {"title": "x", "matter_id": str(w["restricted"].id)}).status_code == 403
    assert o.get(f"/tasks?matter_id={w['restricted'].id}").json()["total"] == 0
    # the responsible partner can see it
    assert api_for(app, w["partner"]).get(f"/tasks/{tid}").status_code == 200


def test_unattached_task_only_assignee_or_creator(app, db, world):
    w = world
    r = api_for(app, w["sol"]).post("/tasks", {"title": "Personal", "assignee_id": str(w["para"].id)})
    tid = r.json()["id"]
    assert api_for(app, w["para"]).get(f"/tasks/{tid}").status_code == 200
    assert api_for(app, w["other"]).get(f"/tasks/{tid}").status_code == 404


def test_cross_firm_task_is_404(app, db, world):
    other_firm = make_firm(db)
    u2 = make_user(db, other_firm, "solicitor")
    tid = api_for(app, world["sol"]).post("/tasks", {"title": "Mine", "matter_id": str(world["std"].id)}).json()["id"]
    assert api_for(app, u2).get(f"/tasks/{tid}").status_code == 404


def test_assignment_creates_notification(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    tid = a.post("/tasks", {"title": "Review lease", "matter_id": str(w["std"].id), "assignee_id": str(w["para"].id)}).json()["id"]
    notes = db.execute(select(Notification).where(Notification.user_id == w["para"].id, Notification.kind == "task_assigned")).scalars().all()
    assert len(notes) == 1 and "Review lease" in notes[0].title
    # self-assignment does not notify; reassignment does
    t2 = a.post("/tasks", {"title": "Self", "assignee_id": str(w["sol"].id)}).json()
    assert db.execute(select(Notification).where(Notification.user_id == w["sol"].id)).scalars().all() == []
    r = a.patch(f"/tasks/{tid}", {"expected_version": 1, "assignee_id": str(w["other"].id)})
    assert r.status_code == 200
    assert len(db.execute(select(Notification).where(Notification.user_id == w["other"].id, Notification.kind == "task_assigned")).scalars().all()) == 1


def test_dependencies_cycles_and_blockers(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    mk = lambda t: a.post("/tasks", {"title": t, "matter_id": str(w["std"].id)}).json()["id"]
    A, B, C = mk("A"), mk("B"), mk("C")
    assert a.post(f"/tasks/{A}/dependencies", {"depends_on_task_id": B}).status_code == 201
    assert a.post(f"/tasks/{B}/dependencies", {"depends_on_task_id": C}).status_code == 201
    # direct and indirect cycles are rejected
    r = a.post(f"/tasks/{B}/dependencies", {"depends_on_task_id": A})
    assert r.status_code == 422 and r.json()["error"]["code"] == "dependency_cycle"
    assert a.post(f"/tasks/{C}/dependencies", {"depends_on_task_id": A}).json()["error"]["code"] == "dependency_cycle"
    assert a.post(f"/tasks/{A}/dependencies", {"depends_on_task_id": A}).status_code == 422
    # A is blocked by B; cannot start/complete
    assert [b["title"] for b in a.get(f"/tasks/{A}").json()["blocked_by"]] == ["B"]
    r = a.post(f"/tasks/{A}/complete")
    assert r.status_code == 409 and r.json()["error"]["code"] == "task_blocked"
    assert r.json()["error"]["details"]["blocked_by"][0]["title"] == "B"
    assert a.post(f"/tasks/{A}/start").status_code == 409
    # unblock chain: C then B then A
    assert a.post(f"/tasks/{B}/complete").status_code == 409
    assert a.post(f"/tasks/{C}/complete").status_code == 200
    assert a.post(f"/tasks/{B}/complete").status_code == 200
    assert a.post(f"/tasks/{A}/complete").status_code == 200


def test_recurrence_creates_exactly_one_next_occurrence(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    due = datetime(2026, 11, 16, 9, 0, tzinfo=timezone.utc)
    t = a.post("/tasks", {"title": "Weekly file review", "matter_id": str(w["std"].id), "due_at": due.isoformat(),
                          "recurrence": {"freq": "weekly", "interval": 1}}).json()
    r = a.post(f"/tasks/{t['id']}/complete")
    assert r.status_code == 200 and r.json()["next_occurrence"]["due_at"].startswith("2026-11-23T09:00")
    assert a.post(f"/tasks/{t['id']}/complete").status_code == 409  # already done: no duplicate occurrence
    # reopening and completing again must NOT spawn a second occurrence
    assert a.post(f"/tasks/{t['id']}/reopen").status_code == 200
    r = a.post(f"/tasks/{t['id']}/complete")
    assert r.status_code == 200 and r.json()["next_occurrence"] is None
    copies = db.execute(select(Task).where(Task.matter_id == w["std"].id, Task.title == "Weekly file review")).scalars().all()
    assert len(copies) == 2
    # 'until' stops the series
    t2 = a.post("/tasks", {"title": "Daily chase", "matter_id": str(w["std"].id), "due_at": due.isoformat(),
                           "recurrence": {"freq": "daily", "interval": 1, "until": "2026-11-16"}}).json()
    assert a.post(f"/tasks/{t2['id']}/complete").json()["next_occurrence"] is None
    # recurrence requires a due date
    assert a.post("/tasks", {"title": "x", "recurrence": {"freq": "daily"}}).status_code == 422


def test_next_due_monthly_clamps_and_keeps_wall_clock():
    jan31 = datetime(2027, 1, 31, 9, 0, tzinfo=timezone.utc)
    assert next_due(jan31, {"freq": "monthly", "interval": 1}).date().isoformat() == "2027-02-28"
    # 09:00 London on 27 Mar 2027 (GMT) -> a daily step over the BST change stays 09:00 local (08:00 UTC)
    sat = datetime(2027, 3, 27, 9, 0, tzinfo=timezone.utc)
    nxt = next_due(sat + timedelta(days=0), {"freq": "weekly", "interval": 1})
    assert nxt == datetime(2027, 4, 3, 8, 0, tzinfo=timezone.utc)


def test_reminders_and_escalation_are_idempotent(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    due = datetime(2027, 2, 1, 12, 0, tzinfo=timezone.utc)
    tid = a.post("/tasks", {"title": "File acknowledgment", "matter_id": str(w["std"].id), "assignee_id": str(w["para"].id), "due_at": due.isoformat(),
                            "reminder_offsets_minutes": [60, 1440], "escalate_to_id": str(w["partner"].id), "escalate_after_hours": 2}).json()["id"]

    def sweep(now):
        s = new_session(w["firm"].id)
        try:
            r = task_jobs.sweep_firm(s, w["firm"].id, now)
            s.commit()
            return r
        finally:
            s.close()

    assert sweep(due - timedelta(days=3)) == {"reminders": 0, "escalations": 0}
    assert sweep(due - timedelta(hours=23)) == {"reminders": 1, "escalations": 0}  # 24h reminder
    assert sweep(due - timedelta(hours=23)) == {"reminders": 0, "escalations": 0}  # idempotent
    assert sweep(due - timedelta(minutes=30)) == {"reminders": 1, "escalations": 0}  # 60-minute reminder
    assert sweep(due - timedelta(minutes=29)) == {"reminders": 0, "escalations": 0}
    assert sweep(due + timedelta(hours=1)) == {"reminders": 0, "escalations": 0}  # overdue but within grace
    assert sweep(due + timedelta(hours=3)) == {"reminders": 0, "escalations": 1}
    assert sweep(due + timedelta(hours=4)) == {"reminders": 0, "escalations": 0}
    rem = db.execute(select(Notification).where(Notification.user_id == w["para"].id, Notification.kind == "task_reminder")).scalars().all()
    esc = db.execute(select(Notification).where(Notification.user_id == w["partner"].id, Notification.kind == "task_escalated")).scalars().all()
    assert len(rem) == 2 and len(esc) == 1
    # completed tasks are never chased
    a.post(f"/tasks/{tid}/complete")
    db.expire_all()


def test_sweep_all_firms_runs_and_job_handler_registered(app, db, world):
    from app.services.jobs import HANDLERS
    assert "task_sweep" in HANDLERS
    assert set(task_jobs.sweep_all_firms()) == {"reminders", "escalations"}


def test_optimistic_concurrency_on_tasks(app, db, world):
    a = api_for(app, world["sol"])
    t = a.post("/tasks", {"title": "Draft letter", "matter_id": str(world["std"].id)}).json()
    assert t["version"] == 1
    r = a.patch(f"/tasks/{t['id']}", {"expected_version": 1, "title": "Draft letter v2", "priority": "high"})
    assert r.status_code == 200 and r.json()["version"] == 2 and r.json()["priority"] == "high"
    r = a.patch(f"/tasks/{t['id']}", {"expected_version": 1, "title": "stale write"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "version_conflict"


def test_filters_and_permissions(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    a.post("/tasks", {"title": "Overdue one", "matter_id": str(w["std"].id), "assignee_id": str(w["sol"].id), "due_at": _in(-48)})
    a.post("/tasks", {"title": "Future one", "matter_id": str(w["std"].id), "assignee_id": str(w["sol"].id), "due_at": _in(48)})
    od = a.get("/tasks?overdue=true&mine=true").json()
    assert [t["title"] for t in od["items"]] == ["Overdue one"] and od["items"][0]["is_overdue"]
    # finance can read but not write tasks; clients have no task access at all
    fin = make_user(db, w["firm"], "finance")
    f = api_for(app, fin)
    assert f.get("/tasks").status_code == 200
    assert f.post("/tasks", {"title": "nope"}).status_code == 403
