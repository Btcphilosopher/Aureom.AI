"""Shared arrangement helpers for the parties/matters tests."""
from __future__ import annotations

from types import SimpleNamespace

from sqlalchemy import select

from app.models import RetentionPolicy
from tests.factories import Api, make_firm, make_team, make_user


def setup_firm(db, name=None):
    firm = make_firm(db, name)
    ta, tb = make_team(db, firm, "Commercial", "commercial"), make_team(db, firm, "Litigation", "litigation")
    ns = SimpleNamespace(firm=firm, team_a=ta, team_b=tb)
    ns.partner = make_user(db, firm, "partner", "Penelope Partner", team=ta)
    ns.partner2 = make_user(db, firm, "partner", "Peter Partner", team=tb)
    ns.sol = make_user(db, firm, "solicitor", "Sam Solicitor", team=ta)
    ns.sol_b = make_user(db, firm, "solicitor", "Sue Solicitor", team=tb)
    ns.para = make_user(db, firm, "paralegal", "Pat Paralegal", team=ta)
    ns.compliance = make_user(db, firm, "compliance", "Cora Compliance")
    ns.finance = make_user(db, firm, "finance", "Fin Finance")
    ns.admin = make_user(db, firm, "admin", "Ada Admin")
    return ns


def apis(app, ns):
    return SimpleNamespace(**{k: Api(app).login(getattr(ns, k)) for k in ["partner", "partner2", "sol", "sol_b", "para", "compliance", "finance", "admin"]})


TEMPLATE = {
    "name": "Commercial contract", "practice_area": "commercial", "matter_type": "Commercial agreement", "description": "Drafting and negotiation",
    "stages": [{"key": "instruct", "name": "Instructions"}, {"key": "draft", "name": "Drafting"}, {"key": "complete", "name": "Completion"}],
    "opening_checklist": [{"label": "Client care letter sent", "required": True}, {"label": "Optional welcome pack", "required": False}],
    "closing_checklist": [{"label": "Final bill issued", "required": True}, {"label": "Archive note", "required": False}],
    "required_fields": ["target_date"], "default_fee_arrangement": "hourly", "default_retention_key": "general_6y",
    "default_tasks": [{"title": "Send client care letter", "due_in_days": 2}],
}


def make_template(api_partner, **over):
    r = api_partner.post("/matters/templates", {**TEMPLATE, **over})
    assert r.status_code == 201, r.text
    return r.json()


def new_client(api, name="Hargreaves Holdings Limited", kind="organisation", **kw):
    body = {"kind": kind, "display_name": name, **kw}
    r = api.post("/clients", body)
    assert r.status_code == 201, r.text
    return r.json()


def onboard_and_clear(a, client_id):
    """Run simulated checks, approve onboarding and get a human-cleared conflict search for a client."""
    for ck in ("sanctions_pep", "id_individual"):
        a.sol.post(f"/clients/{client_id}/onboarding/checks", {"check_type": ck})
    r = a.partner.post(f"/clients/{client_id}/onboarding/approve", {"note": "ok", "risk_level": "low"})
    assert r.status_code == 200, r.text
    s = a.sol.post("/conflicts/searches", {"terms": [], "subject_contact_id": client_id})
    assert s.status_code == 201, s.text
    sid = s.json()["id"]
    for m in s.json()["matches"]:
        a.compliance.patch(f"/conflicts/matches/{m['id']}", {"disposition": "false_positive", "note": "different person"})
    d = a.compliance.post(f"/conflicts/searches/{sid}/decision", {"decision": "cleared_by_reviewer", "note": "No conflict identified on review."})
    assert d.status_code == 200, d.text
    return sid
