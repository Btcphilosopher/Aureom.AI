"""Time entries, timers, invoices (approval binding, issue != revenue, numbering), credit notes."""
from datetime import date, timedelta
from decimal import Decimal

import pytest
from sqlalchemy import select, text

from app.errors import ApprovalRequired, InvalidState, PermissionDenied, ValidationFailed
from app.models import Approval, Expense, Firm, Invoice, InvoiceLine, Journal, JournalLine, TimeEntry
from app.services import billing, ledger as led
from app.services.matter_finance import unbilled_wip
from tests.finance_world import World


@pytest.fixture()
def w(db):
    world = World(db)
    yield world
    world.close()


def bal(w, key, ledger="office"):
    return led.account_balance(w.s, led.system_account(w.s, w.firm.id, key, ledger))


def draft_invoice(w, minutes=90, user=None):
    user = user or w.solicitor
    te = billing.create_time_entry(w.ctx(user), matter_id=w.matter.id, work_date=date.today(), minutes=minutes, narrative="Negotiation")
    billing.submit_time_entry(w.ctx(user), te.id)
    inv = billing.create_draft_invoice(w.ctx(user), matter_id=w.matter.id, time_entry_ids=[te.id])
    w.commit()
    return inv, te


def test_submit_requires_narrative_and_writeoff_rules(w):
    te = billing.create_time_entry(w.ctx(w.solicitor), matter_id=w.matter.id, work_date=date.today(), minutes=12, narrative="")
    with pytest.raises(ValidationFailed) as e:
        billing.submit_time_entry(w.ctx(w.solicitor), te.id)
    assert e.value.code == "narrative_required"   # never invent a narrative
    w.s.rollback()
    te = billing.create_time_entry(w.ctx(w.solicitor), matter_id=w.matter.id, work_date=date.today(), minutes=12, narrative="Attendance")
    w.commit()
    with pytest.raises(PermissionDenied):          # paralegals have no billing.write
        billing.write_off_time_entry(w.ctx(w.paralegal), te.id, "no reason")
    w.s.rollback()
    with pytest.raises(ValidationFailed):          # a reason is mandatory
        billing.write_off_time_entry(w.ctx(w.solicitor), te.id, " ")
    w.s.rollback()
    billing.write_off_time_entry(w.ctx(w.solicitor), te.id, "Goodwill reduction"); w.commit()
    assert w.s.get(TimeEntry, te.id).status == "written_off"
    assert unbilled_wip(w.s, w.matter.id)["time"] == Decimal("0.00")


def test_timer_single_running_and_unit_rounding(w):
    te = billing.start_timer(w.ctx(w.solicitor), w.matter.id, "Drafting"); w.commit()
    with pytest.raises(InvalidState) as e:
        billing.start_timer(w.ctx(w.solicitor), w.matter.id)
    assert e.value.code == "timer_running"; w.s.rollback()
    firm = w.s.get(Firm, w.firm.id); firm.settings = {**firm.settings, "time_unit_minutes": 6}; w.commit()
    stopped = billing.stop_timer(w.ctx(w.solicitor), now=te.timer_started_at + timedelta(minutes=7, seconds=10)); w.commit()
    assert stopped.minutes == 12 and stopped.timer_started_at is None and stopped.amount == Decimal("40.00")   # 8 min rounds up to two 6-min units
    with pytest.raises(InvalidState):
        billing.stop_timer(w.ctx(w.solicitor))
    w.s.rollback()


def test_invoice_totals_use_decimal_vat_per_line(w):
    te = billing.create_time_entry(w.ctx(w.solicitor), matter_id=w.matter.id, work_date=date.today(), minutes=90, narrative="Negotiation")
    billing.submit_time_entry(w.ctx(w.solicitor), te.id)
    exp = billing.create_expense(w.ctx(w.solicitor), matter_id=w.matter.id, expense_date=date.today(), description="Land Registry fee", amount=Decimal("45.00"))
    inv = billing.create_draft_invoice(w.ctx(w.solicitor), matter_id=w.matter.id, time_entry_ids=[te.id], expense_ids=[exp.id],
                                       adjustments=[{"description": "Discount", "amount": Decimal("-20.00")}])
    w.commit()
    assert (inv.subtotal, inv.vat_amount, inv.total) == (Decimal("325.00"), Decimal("56.00"), Decimal("381.00"))   # 300 + 45 - 20; VAT 60 + 0 - 4
    # the same time entry cannot be put on a second invoice while it is on this one
    with pytest.raises(InvalidState) as e:
        billing.create_draft_invoice(w.ctx(w.solicitor), matter_id=w.matter.id, time_entry_ids=[te.id])
    assert e.value.code == "time_not_billable"; w.s.rollback()
    # voiding the draft releases the entries
    billing.void_draft_invoice(w.ctx(w.solicitor), inv.id, "Raised in error"); w.commit()
    assert w.s.get(TimeEntry, te.id).invoice_line_id is None and w.s.get(Invoice, inv.id).status == "void"


def test_fixed_fee_line(w):
    inv = billing.create_draft_invoice(w.ctx(w.solicitor), matter_id=w.matter.id, include_fixed_fee=True); w.commit()
    assert inv.subtotal == Decimal("2500.00") and inv.total == Decimal("3000.00")


def test_issue_requires_authorisation_posts_issue_journal_not_revenue(w):
    inv, te = draft_invoice(w)
    with pytest.raises(InvalidState):                         # draft cannot be issued
        billing.issue_invoice(w.ctx(w.fin_a), inv.id)
    w.s.rollback()
    billing.submit_invoice_for_approval(w.ctx(w.solicitor), inv.id); w.commit()
    with pytest.raises(ApprovalRequired):                     # pending approval is not enough
        billing.issue_invoice(w.ctx(w.fin_a), inv.id)
    w.s.rollback()
    with pytest.raises(PermissionDenied):                     # fee earner has no billing.approve
        billing.decide_invoice(w.ctx(w.solicitor), inv.id, approve=True)
    w.s.rollback()
    billing.decide_invoice(w.ctx(w.partner), inv.id, approve=True); w.commit()
    with pytest.raises(PermissionDenied):                     # a partner cannot issue (billing.issue is finance's)
        billing.issue_invoice(w.ctx(w.partner), inv.id)
    w.s.rollback()
    issued = billing.issue_invoice(w.ctx(w.fin_a), inv.id); w.commit()
    year = date.today().year
    assert issued.status == "issued" and issued.number == f"INV-{year}-0001" and issued.issued_by == w.fin_a.id
    assert bal(w, "debtors") == Decimal("360.00")              # 300 + 20% VAT
    assert bal(w, "fees_billed_unrecognised") == Decimal("300.00") and bal(w, "vat_output") == Decimal("60.00")
    assert bal(w, "fee_income") == Decimal("0.00") and bal(w, "bank_office") == Decimal("0.00")   # issue is neither revenue nor cash
    j = w.s.get(Journal, issued.issue_journal_id)
    assert j.status == "posted" and j.source_type == "invoice_issue" and j.approval_id == issued.approval_id
    assert w.s.get(TimeEntry, te.id).status == "billed"
    assert unbilled_wip(w.s, w.matter.id)["time"] == Decimal("0.00")


def test_invoice_requester_cannot_approve_own_and_numbers_are_sequential(w):
    nums = []
    for _ in range(3):
        iid = w.billed_invoice(minutes=30)
        nums.append(w.s.get(Invoice, iid).number)
    year = date.today().year
    assert nums == [f"INV-{year}-000{i}" for i in (1, 2, 3)] and len(set(nums)) == 3
    inv, _ = draft_invoice(w, 30)
    billing.submit_invoice_for_approval(w.ctx(w.partner), inv.id); w.commit()       # partner submits...
    with pytest.raises(PermissionDenied) as e:                                      # ...and cannot also approve
        billing.decide_invoice(w.ctx(w.partner), inv.id, approve=True)
    assert e.value.code == "four_eyes_required"; w.s.rollback()


def test_editing_after_approval_withdraws_approval(w):
    inv, _ = draft_invoice(w)
    billing.submit_invoice_for_approval(w.ctx(w.solicitor), inv.id); w.commit()
    billing.decide_invoice(w.ctx(w.partner), inv.id, approve=True); w.commit()
    edited = billing.update_draft_invoice(w.ctx(w.solicitor), inv.id, add_adjustments=[{"description": "Extra", "amount": Decimal("10.00")}]); w.commit()
    assert edited.status == "draft" and edited.approval_id is None
    assert w.s.execute(select(Approval.status).where(Approval.subject_id == inv.id)).scalar() == "superseded"
    with pytest.raises(InvalidState):
        billing.issue_invoice(w.ctx(w.fin_a), inv.id)
    w.s.rollback()


def test_approval_is_bound_to_exact_content_hash(w, owner_engine):
    inv, _ = draft_invoice(w)
    billing.submit_invoice_for_approval(w.ctx(w.solicitor), inv.id); w.commit()
    billing.decide_invoice(w.ctx(w.partner), inv.id, approve=True); w.commit()
    with owner_engine.begin() as conn:   # content changed behind the service layer's back
        conn.execute(text("update invoice_lines set amount = amount + 1000 where invoice_id = :i"), {"i": inv.id})
    with pytest.raises(ApprovalRequired) as e:
        billing.issue_invoice(w.ctx(w.fin_a), inv.id)
    assert e.value.code == "approval_stale"


def test_credit_notes_limits_and_journal(w):
    iid = w.billed_invoice(minutes=90)                           # 300 net, 60 VAT, 360 total
    with pytest.raises(InvalidState):                            # unissued invoice cannot be credited
        inv2, _ = draft_invoice(w, 30)
        billing.create_credit_note(w.ctx(w.solicitor), inv2.id, full=True)
    w.s.rollback()
    with pytest.raises(InvalidState) as e:                       # more than outstanding
        billing.create_credit_note(w.ctx(w.solicitor), iid, lines=[{"description": "Too much", "amount": Decimal("301.00")}])
    assert e.value.code == "credit_exceeds_outstanding"; w.s.rollback()
    cn = billing.create_credit_note(w.ctx(w.solicitor), iid, lines=[{"description": "Part refund", "amount": Decimal("100.00")}])
    billing.submit_invoice_for_approval(w.ctx(w.solicitor), cn.id); w.commit()
    billing.decide_invoice(w.ctx(w.partner), cn.id, approve=True); w.commit()
    cn = billing.issue_invoice(w.ctx(w.fin_a), cn.id); w.commit()
    assert cn.number == f"CN-{date.today().year}-0001" and cn.total == Decimal("120.00")
    assert bal(w, "debtors") == Decimal("240.00") and bal(w, "fees_billed_unrecognised") == Decimal("200.00") and bal(w, "vat_output") == Decimal("40.00")
    orig = w.s.get(Invoice, iid)
    assert led.invoice_outstanding(w.s, orig) == Decimal("240.00")
    with pytest.raises(InvalidState):                            # further credit beyond what is left
        billing.create_credit_note(w.ctx(w.solicitor), iid, lines=[{"description": "Again", "amount": Decimal("201.00")}])
    w.s.rollback()
