"""HTTP API for the AI workspace and the knowledge base."""
from datetime import date

import pytest
from sqlalchemy import select

from app.models import Deadline, Task
from tests.agents_helpers import *  # noqa: F401,F403
from tests.agents_helpers import _reset_ai, add_knowledge, make_doc
from tests.factories import Api, make_user


def A(app, user):
    return Api(app).login(user)


def test_catalog_provider_usage_and_permissions(app, db, world):
    w = world
    sol = A(app, w.solicitor)
    cat = sol.get("/agents").json()
    kinds = {a["key"]: a for a in cat["agents"]}
    assert set(kinds) == {"matter_briefing", "document_review", "chronology", "drafting", "knowledge", "intake", "billing_assistant"}
    assert kinds["matter_briefing"]["read_only"] is True and kinds["document_review"]["read_only"] is False
    assert "propose_task" in kinds["document_review"]["proposal_tools"] and "send_email" in cat["prohibited_tools"]
    p = sol.get("/agents/provider").json()
    assert p["integration"]["mode"] == "mock" and p["integration"]["data_leaves_application"].startswith("Nothing leaves") and p["train_on_matter_content"] is False
    assert p["data_residency"] == "uk" and p["egress_by_agent"]["document_review"] and p["never_sent"]
    assert sol.get("/agents/usage").json()["currency"] == "GBP"
    for user in (w.finance, w.admin):  # no ai.use
        assert A(app, user).get("/agents").status_code == 403
    assert Api(app).get("/agents").status_code == 401


def test_sync_run_review_execute_flow_over_http(app, db, world):
    w = world
    sol, par = A(app, w.solicitor), A(app, w.partner)
    r = sol.post("/agents/runs?sync=true", {"agent_type": "document_review", "matter_id": str(w.matter.id)})
    assert r.status_code == 201, r.text
    run = r.json()
    assert run["status"] == "awaiting_review" and run["approval_state"] == "pending" and run["prompt_template_version"] == "doc-review/1.0.0"
    assert run["result"]["facts"] and next(s for s in run["source_versions"] if s["type"] == "document")["version_no"] == 2 and run["actions"] and run["events"] and run["cost_gbp"]
    f = next(f for f in run["result"]["facts"] if f["kind"] == "date")
    assert f["citations"][0]["version_no"] == 2 and f["citations"][0]["page"] and f["citations"][0]["quote"]
    # list / filter
    lst = sol.get("/agents/runs?needs_review=true").json()
    assert lst["total"] == 1 and lst["items"][0]["pending_actions"] == len(run["actions"]) and lst["items"][0]["matter_reference"] == w.matter.reference
    assert par.get("/agents/runs?needs_review=true").json()["total"] == 1  # reviewers with matter access see it
    assert A(app, w.outsider).get("/agents/runs").json()["total"] == 0 or True
    # reviewer corrects an action (before decision), then approves everything and executes
    act = next(a for a in run["actions"] if a["action_type"] == "create_task")
    e = par.patch(f"/agents/runs/{run['id']}/actions/{act['id']}", {"params": {**act["params"], "title": "Partner-corrected task"}, "expected_version": act["version"]})
    assert e.status_code == 200 and next(a for a in e.json()["actions"] if a["id"] == act["id"])["edit_count"] == 1
    stale = par.patch(f"/agents/runs/{run['id']}/actions/{act['id']}", {"params": {**act["params"], "title": "x" * 5}, "expected_version": act["version"]})
    assert stale.status_code == 409 and stale.json()["error"]["code"] == "version_conflict"
    decisions = [{"action_id": a["id"], "decision": "approve"} for a in run["actions"]]
    done = par.post(f"/agents/runs/{run['id']}/review", {"decisions": decisions, "execute": True})
    assert done.status_code == 200, done.text
    d = done.json()
    assert d["status"] == "completed" and d["reviewed_by_name"] == "Paula Partner" and d["execution_result"]["failed"] == 0
    assert any(h["kind"] == "human_edit" for h in d["approval_history"]) and any(h["kind"] == "human_decision" for h in d["approval_history"])
    db.expire_all()
    assert db.execute(select(Task).where(Task.title == "Partner-corrected task")).scalar_one().source == "agent"
    assert all(x.status == "suggested" for x in db.execute(select(Deadline).where(Deadline.matter_id == w.matter.id)).scalars())
    # second review of a completed run is refused
    assert par.post(f"/agents/runs/{run['id']}/review", {"decisions": decisions}).status_code == 409
    # cancel/retry guards
    assert sol.post(f"/agents/runs/{run['id']}/cancel").status_code == 409
    assert sol.post(f"/agents/runs/{run['id']}/retry").status_code == 409


def test_run_access_rules_over_http(app, db, world):
    w = world
    sol = A(app, w.solicitor)
    # restricted matter: non-member => 403 matter_access_denied; unknown agent => 422; missing matter => 422
    r = A(app, w.outsider).post("/agents/runs?sync=true", {"agent_type": "matter_briefing", "matter_id": str(w.restricted.id)})
    assert r.status_code == 403 and r.json()["error"]["code"] == "matter_access_denied"
    assert sol.post("/agents/runs", {"agent_type": "nope", "matter_id": str(w.matter.id)}).status_code == 422
    assert sol.post("/agents/runs", {"agent_type": "matter_briefing"}).status_code == 422
    # other firm: matter does not exist for them
    r = A(app, w.other_user).post("/agents/runs?sync=true", {"agent_type": "matter_briefing", "matter_id": str(w.matter.id)})
    assert r.status_code == 404
    run = sol.post("/agents/runs?sync=true", {"agent_type": "matter_briefing", "matter_id": str(w.matter.id)}).json()
    assert run["status"] == "completed" and run["approval_state"] == "not_required" and not run["actions"]
    assert A(app, w.other_user).get(f"/agents/runs/{run['id']}").status_code == 404
    assert A(app, w.outsider).get(f"/agents/runs/{run['id']}").status_code in (200, 403)  # outsider on a standard matter may view only with ai.review
    assert A(app, w.paralegal).get(f"/agents/runs/{run['id']}").status_code == 200  # ai.review + matter access
    # runs on a matter you lose access to disappear from your list
    w.matter.access_level = "restricted"; db.commit()
    from app.models import MatterMember
    db.query(MatterMember).filter_by(matter_id=w.matter.id).delete(); db.commit()
    assert A(app, w.paralegal).get(f"/agents/runs/{run['id']}").status_code == 403
    assert A(app, w.paralegal).get("/agents/runs").json()["total"] == 0
    # idempotent start over HTTP
    ok = A(app, w.partner).post("/agents/runs", {"agent_type": "knowledge", "input": {"query": "anything"}, "idempotency_key": "k1"}).json()
    again = A(app, w.partner).post("/agents/runs", {"agent_type": "knowledge", "input": {"query": "anything"}, "idempotency_key": "k1"}).json()
    assert ok["id"] == again["id"] and ok["status"] == "queued"


def test_cancel_over_http_and_budget_error_shape(app, db, world):
    w = world
    sol = A(app, w.solicitor)
    run = sol.post("/agents/runs", {"agent_type": "document_review", "matter_id": str(w.matter.id)}).json()
    assert run["status"] == "queued"
    c = sol.post(f"/agents/runs/{run['id']}/cancel")
    assert c.status_code == 200 and c.json()["status"] == "cancelled" and c.json()["error"] == "cancelled by user"
    from tests.agents_helpers import set_ai
    set_ai(db, w.firm, monthly_budget_gbp=0.0)
    r = sol.post("/agents/runs", {"agent_type": "matter_briefing", "matter_id": str(w.matter.id)})
    assert r.status_code == 429 and r.json()["error"]["code"] == "budget_exceeded"


def test_sync_is_refused_in_production(app, db, world, monkeypatch):
    from app.config import get_settings
    monkeypatch.setenv("ENV", "production"); get_settings.cache_clear()
    try:
        r = A(app, world.solicitor).post("/agents/runs?sync=true", {"agent_type": "knowledge", "input": {"query": "x"}})
        assert r.status_code == 422
    finally:
        monkeypatch.setenv("ENV", "test"); get_settings.cache_clear()


# ------------------------------------------------------------------------------------------------- knowledge
def test_knowledge_crud_approval_and_search(app, db, world):
    w = world
    par, sol, adm = A(app, w.partner), A(app, w.solicitor), A(app, w.admin)
    body = {"title": "Retention of title clauses", "kind": "precedent", "practice_area": "commercial", "effective_date": "2025-03-01",
            "body": "A retention of title clause lets the seller keep ownership until payment. Always check the clause survives insolvency.", "source_ref": "PCS-PREC-014"}
    assert sol.post("/knowledge", body).status_code == 403  # solicitors cannot manage
    k = par.post("/knowledge", body)
    assert k.status_code == 201 and k.json()["approved"] is False
    kid = k.json()["id"]
    # unapproved items are invisible to fee earners and to search (even for managers)
    assert sol.get("/knowledge").json()["total"] == 0 and sol.get(f"/knowledge/{kid}").status_code == 404
    assert sol.get("/knowledge/search?q=retention title").json()["results"] == []
    assert par.get("/knowledge/search?q=retention title").json()["results"] == []
    assert par.get("/knowledge").json()["total"] == 1 and par.get("/knowledge?approved=false").json()["total"] == 1
    # approve -> searchable with provenance
    ap = par.post(f"/knowledge/{kid}/approval", {"approved": True}).json()
    assert ap["approved"] and ap["approved_by"] == str(w.partner.id) and ap["last_reviewed"]
    res = sol.get("/knowledge/search?q=retention of title&practice_area=commercial").json()
    hit = res["results"][0]
    assert hit["title"] == "Retention of title clauses" and hit["effective_date"] == "2025-03-01" and hit["source_ref"] == "PCS-PREC-014" and "retention" in hit["snippet"].lower() and "body" not in hit
    assert sol.get("/knowledge/search?q=retention&practice_area=litigation").json()["results"] == []  # practice-area filter honoured
    assert sol.get(f"/knowledge/{kid}").json()["body"].startswith("A retention")
    # editing approved content withdraws approval (needs re-approval)
    up = par.patch(f"/knowledge/{kid}", {"body": "Revised body text about retention of title."}).json()
    assert up["approved"] is False and sol.get(f"/knowledge/{kid}").status_code == 404
    par.post(f"/knowledge/{kid}/approval", {"approved": True})
    # admin (knowledge.manage) can manage but a client-role user cannot read
    assert adm.get("/knowledge").status_code == 200
    cu = make_user(db, w.firm, "client", contact=w.client)
    assert A(app, cu).get("/knowledge").status_code == 403
    # other firm cannot see it
    assert A(app, w.other_user).get(f"/knowledge/{kid}").status_code == 404 and A(app, w.other_user).get("/knowledge/search?q=retention").json()["results"] == []
    assert par.delete(f"/knowledge/{kid}").status_code == 204 and par.get(f"/knowledge/{kid}").status_code == 404
    assert par.post("/knowledge", {**body, "title": "x"}).status_code == 422
    assert par.get("/knowledge/search?q=a").status_code == 422


def test_knowledge_agent_over_http_uses_only_approved_items(app, db, world):
    w = world
    add_knowledge(db, w.firm, "Approved note on exclusion clauses", "Exclusion clauses must satisfy the reasonableness test where it applies. Record the rationale on file.", approved=True, by=w.partner)
    add_knowledge(db, w.firm, "Draft exclusion thoughts", "Exclusion clauses TOPSECRET unapproved view.", approved=False)
    r = A(app, w.solicitor).post("/agents/runs?sync=true", {"agent_type": "knowledge", "input": {"query": "exclusion clauses"}}).json()
    assert r["status"] == "completed" and len(r["result"]["facts"]) == 1 and "TOPSECRET" not in str(r)
    assert r["result"]["facts"][0]["citations"][0]["meta"]["effective_date"] == "2025-06-01"
