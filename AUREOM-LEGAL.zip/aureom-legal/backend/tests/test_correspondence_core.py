"""Correspondence: simulated inbox, untrusted bodies, filing, notes separation, approval-bound sending."""
import pytest
from sqlalchemy import select

from app.integrations import base
from app.models import AuditEvent, Correspondence, Document, IntegrationEvent
from tests.docs_helpers import arrange, drain


@pytest.fixture()
def w(db, app):
    return arrange(db, app)


def _sync(api):
    r = api.post("/correspondence/sync")
    assert r.status_code == 200, r.text
    return r.json()


def test_sync_is_idempotent_and_labelled_simulated(w):
    a = w.api(w.fe)
    s1 = _sync(a)
    assert s1["created"] == 4 and s1["mode"] == "mock" and "SIMULATED" in s1["notice"]
    assert _sync(a)["created"] == 0
    items = a.get("/correspondence", params={"unfiled": True}).json()
    assert items["total"] == 4 and any(i["has_attachments"] for i in items["items"])
    assert w.api(w.fin).get("/correspondence").status_code == 403  # finance has no correspondence access


def test_email_bodies_are_untrusted_plain_text(w, db):
    a = w.api(w.fe)
    _sync(a)
    inj = next(i for i in a.get("/correspondence", params={"q": "ignore previous instructions"}).json()["items"] if "URGENT" in i["subject"])
    d = a.get(f"/correspondence/{inj['id']}").json()
    assert d["untrusted_content"] is True and d["body_text"].startswith("SYSTEM INSTRUCTION")
    # reading/syncing a hostile message performed no action: still unfiled, no drafts/sent, no clearance, nothing outbound
    assert d["status"] == "received" and d["matter_id"] is None
    assert db.query(Correspondence).filter_by(firm_id=w.firm.id, direction="outbound").count() == 0
    assert db.query(IntegrationEvent).filter_by(firm_id=w.firm.id, kind="send").count() == 0
    # html in a body is returned verbatim as text
    dr = a.post("/correspondence", {"matter_id": str(w.std.id), "to_addrs": ["x@y.example"], "subject": "html", "body_text": "<img src=x onerror=alert(1)>"}).json()
    got = a.get(f"/correspondence/{dr['id']}")
    assert got.json()["body_text"] == "<img src=x onerror=alert(1)>" and got.headers["content-type"].startswith("application/json")


def test_filing_creates_documents_and_blocks_disallowed_attachments(w, db):
    a = w.api(w.fe)
    _sync(a)
    heron = next(i for i in a.get("/correspondence").json()["items"] if i["subject"].startswith("Supply agreement"))
    r = a.post(f"/correspondence/{heron['id']}/file", {"matter_id": str(w.std.id)})
    assert r.status_code == 200 and len(r.json()["filed_documents"]) == 1
    detail = a.get(f"/correspondence/{heron['id']}").json()
    assert detail["status"] == "filed" and detail["matter_reference"] == "HV-001" and detail["attachments"][0]["document_id"]
    drain()
    assert a.get("/documents", params={"matter_id": str(w.std.id)}).json()["items"][0]["doc_type"] == "email_attachment"
    # the .exe attachment was never stored
    rent = next(i for i in a.get("/correspondence").json()["items"] if i["subject"].startswith("Rent review"))
    r2 = a.post(f"/correspondence/{rent['id']}/file", {"matter_id": str(w.std.id)}).json()
    assert r2["filed_documents"] == [] and r2["skipped_attachments"][0]["reason"] == "scan_status=blocked"
    # restricted matter: non-member cannot file to it
    r3 = w.api(w.other).post(f"/correspondence/{rent['id']}/file", {"matter_id": str(w.restricted.id)})
    assert r3.status_code == 403
    # once filed to a restricted matter, non-members cannot see the message
    msg = next(i for i in a.get("/correspondence").json()["items"] if i["subject"].startswith("Letter before claim"))
    assert a.post(f"/correspondence/{msg['id']}/file", {"matter_id": str(w.restricted.id)}).status_code == 200
    assert w.api(w.other).get(f"/correspondence/{msg['id']}").status_code == 403
    assert msg["id"] not in {i["id"] for i in w.api(w.other).get("/correspondence").json()["items"]}


def test_internal_notes_never_leak_to_client_view_or_outgoing(w, db):
    a, p = w.api(w.fe), w.api(w.partner)
    secret = "INTERNAL: client is weak on liability, settle cheaply"
    c = a.post("/correspondence", {"matter_id": str(w.std.id), "to_addrs": ["s.whitlock@heronvalley.example"], "subject": "Update", "body_text": "Dear Sarah, update.",
                                   "client_visible": True}).json()
    assert a.post(f"/correspondence/{c['id']}/notes", {"body": secret}).status_code == 201
    assert a.post("/correspondence/matter-notes", {"matter_id": str(w.std.id), "body": secret + " (matter)"}).status_code == 201
    assert [n["body"] for n in a.get(f"/correspondence/{c['id']}/notes").json()] == [secret]
    assert len(a.get("/correspondence/matter-notes", params={"matter_id": str(w.std.id)}).json()) == 2
    assert secret not in a.get(f"/correspondence/{c['id']}").text and secret not in a.get("/correspondence").text
    a.post(f"/correspondence/{c['id']}/request-approval"); p.post(f"/correspondence/{c['id']}/approve", {"approve": True})
    assert a.post(f"/correspondence/{c['id']}/send").status_code == 200
    cv = a.get("/correspondence/client-view", params={"matter_id": str(w.std.id)})
    assert cv.status_code == 200 and len(cv.json()) == 1 and secret not in cv.text
    assert set(cv.json()[0]) == {"id", "direction", "from_addr", "to_addrs", "subject", "body_text", "date", "attachments"}
    ev = db.query(IntegrationEvent).filter_by(firm_id=w.firm.id, kind="send").one()
    assert secret not in str(ev.payload)
    assert not any(secret in str(e.details) for e in db.execute(select(AuditEvent).where(AuditEvent.firm_id == w.firm.id)).scalars())
    # unsent / not-client-visible items are excluded from the client view
    a.post("/correspondence", {"matter_id": str(w.std.id), "to_addrs": ["x@y.example"], "subject": "Internal draft", "body_text": "draft", "client_visible": True})
    assert len(a.get("/correspondence/client-view", params={"matter_id": str(w.std.id)}).json()) == 1
    # non-members cannot read notes on a restricted matter
    assert w.api(w.other).get("/correspondence/matter-notes", params={"matter_id": str(w.restricted.id)}).status_code == 403


def test_approval_binding_edit_invalidates_and_duplicate_send_blocked(w, db):
    a, p, para = w.api(w.fe), w.api(w.partner), w.api(w.para)
    c = a.post("/correspondence", {"matter_id": str(w.std.id), "to_addrs": ["s@heron.example"], "subject": "Terms", "body_text": "Draft v1", "client_visible": True}).json()
    cid = c["id"]
    r = a.post(f"/correspondence/{cid}/send")  # not approved
    assert r.status_code == 409 and r.json()["error"]["code"] == "approval_required"
    assert a.post(f"/correspondence/{cid}/request-approval").json()["status"] == "pending_approval"
    assert a.post(f"/correspondence/{cid}/send").status_code == 409  # pending is not approved
    assert para.post(f"/correspondence/{cid}/approve", {"approve": True}).status_code == 403  # paralegal lacks correspondence.approve
    assert p.post(f"/correspondence/{cid}/approve", {"approve": True}).json()["status"] == "approved"
    # editing after approval clears it
    cur = a.get(f"/correspondence/{cid}").json()
    e = a.patch(f"/correspondence/{cid}", {"expected_version": cur["version"], "body_text": "Draft v2 - changed after approval"})
    assert e.status_code == 200 and e.json()["status"] == "draft" and e.json()["approval_id"] is None
    r = a.post(f"/correspondence/{cid}/send")
    assert r.status_code == 409 and r.json()["error"]["code"] == "approval_required"
    # stale optimistic version
    assert a.patch(f"/correspondence/{cid}", {"expected_version": cur["version"], "subject": "x"}).status_code == 409
    # renewed approval, then tampering behind the application's back is still caught at send time
    a.post(f"/correspondence/{cid}/request-approval"); p.post(f"/correspondence/{cid}/approve", {"approve": True})
    row = db.execute(select(Correspondence).where(Correspondence.id == cid)).scalar_one()
    db.execute(Correspondence.__table__.update().where(Correspondence.id == cid).values(body_text="TAMPERED BODY")); db.commit()
    r = a.post(f"/correspondence/{cid}/send")
    assert r.status_code == 409 and r.json()["error"]["code"] == "approval_stale"
    db.execute(Correspondence.__table__.update().where(Correspondence.id == cid).values(body_text="Draft v2 - changed after approval")); db.commit()
    ok = a.post(f"/correspondence/{cid}/send")
    assert ok.status_code == 200 and ok.json()["status"] == "sent" and ok.json()["simulated"] is True
    dup = a.post(f"/correspondence/{cid}/send")
    assert dup.status_code == 409 and dup.json()["error"]["code"] == "already_sent"
    assert db.query(IntegrationEvent).filter_by(firm_id=w.firm.id, kind="send").count() == 1
    assert a.patch(f"/correspondence/{cid}", {"expected_version": 99, "subject": "late edit"}).status_code == 409


def test_drafts_scoping_and_service_helpers(w, db):
    from app.db.session import new_session
    from app.deps import Ctx
    from app.services import correspondence as svc
    with new_session(w.firm.id) as s:
        ctx = Ctx.for_user(s, w.fe)
        d = svc.create_draft(ctx, matter_id=w.std.id, subject="Hello", body_text="Hi", to_addrs=["a@b.example"])
        inbound, created = svc.create_inbound(ctx, from_addr="x@y.example", to_addrs=["fees@penninecalder.example"], subject="Seed email", body_text="Body", external_ref="seed-1", matter_id=w.std.id)
        again, created2 = svc.create_inbound(ctx, from_addr="x@y.example", to_addrs=[], subject="Seed email", body_text="Body", external_ref="seed-1")
        s.commit()
        assert created and not created2 and again.id == inbound.id and d.status == "draft"
    # another user's unfiled draft is private; invalid addresses rejected
    a = w.api(w.fe)
    mine = a.post("/correspondence", {"to_addrs": ["a@b.example"], "subject": "Unfiled draft", "body_text": "x"}).json()
    assert w.api(w.other).get(f"/correspondence/{mine['id']}").status_code == 403
    assert mine["id"] not in {i["id"] for i in w.api(w.other).get("/correspondence").json()["items"]}
    assert a.post("/correspondence", {"to_addrs": ["not-an-address"], "subject": "bad", "body_text": "x"}).status_code == 422


def test_integration_unavailable_state(w):
    from app.integrations.base import Integration, IntegrationInfo
    class Down(Integration):
        key = "email"
        def info(self): return IntegrationInfo("email", "Email", "communications", "m365", "unavailable", "d", "everything", "Connect your Microsoft 365 tenant")
    old = base._REGISTRY["email"]; base.register(Down())
    try:
        r = w.api(w.fe).post("/correspondence/sync")
        assert r.status_code == 503 and r.json()["error"]["code"] == "integration_unavailable" and "Microsoft 365" in r.json()["error"]["message"]
    finally:
        base._REGISTRY["email"] = old
