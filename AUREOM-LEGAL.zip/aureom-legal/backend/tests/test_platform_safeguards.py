"""Database-level safeguards exercised directly with SQL (independent of service code)."""
import uuid
from datetime import date

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, IntegrityError

from app.models import Document, DocumentVersion, Journal, JournalLine, LedgerAccount
from tests.factories import make_firm, make_user, make_contact, make_matter


def _journal(db, firm, user, ledger="office", lines=()):
    accts = {}
    for code in ("A", "B"):
        a = LedgerAccount(firm_id=firm.id, ledger=ledger, code=f"{code}-{uuid.uuid4().hex[:4]}", name=code, account_type="asset"); db.add(a); accts[code] = a
    other = LedgerAccount(firm_id=firm.id, ledger="client" if ledger == "office" else "office", code=f"X-{uuid.uuid4().hex[:4]}", name="X", account_type="asset"); db.add(other)
    db.flush()
    j = Journal(firm_id=firm.id, ledger=ledger, reference="J1", description="t", effective_date=date.today(), prepared_by=user.id); db.add(j); db.flush()
    for acct, d, c in lines:
        db.add(JournalLine(firm_id=firm.id, journal_id=j.id, account_id=(accts.get(acct) or other).id, debit=d, credit=c))
    db.flush()
    return j


def _post(db, j, user):
    db.execute(text("update journals set status='posted', posted_by=:u, posted_at=now() where id=:i"), {"u": user.id, "i": j.id}); db.flush()


def test_unbalanced_journal_cannot_be_posted(db):
    firm = make_firm(db); u = make_user(db, firm, "finance")
    j = _journal(db, firm, u, lines=[("A", 100, 0), ("B", 0, 90)])
    with pytest.raises(DBAPIError, match="unbalanced"):
        _post(db, j, u)
    db.rollback()


def test_journal_with_single_line_or_mixed_ledgers_cannot_be_posted(db):
    firm = make_firm(db); u = make_user(db, firm, "finance")
    j = _journal(db, firm, u, lines=[("A", 100, 0)])
    with pytest.raises(DBAPIError, match="fewer than two"):
        _post(db, j, u)
    db.rollback()
    j = _journal(db, firm, u, lines=[("A", 100, 0), ("X", 0, 100)])  # client-ledger account inside an office journal
    with pytest.raises(DBAPIError, match="office and client funds"):
        _post(db, j, u)
    db.rollback()


def test_balanced_journal_posts_then_is_immutable(db):
    firm = make_firm(db); u = make_user(db, firm, "finance")
    j = _journal(db, firm, u, lines=[("A", 100, 0), ("B", 0, 100)])
    _post(db, j, u)
    with pytest.raises(DBAPIError, match="immutable"):
        db.execute(text("update journal_lines set debit=999 where journal_id=:i and debit>0"), {"i": j.id}); db.flush()
    db.rollback()


def test_line_checks_reject_two_sided_or_negative_lines(db):
    firm = make_firm(db); u = make_user(db, firm, "finance")
    with pytest.raises(IntegrityError):
        _journal(db, firm, u, lines=[("A", 10, 10)])
    db.rollback()
    with pytest.raises(IntegrityError):
        _journal(db, firm, u, lines=[("A", -5, 0)])
    db.rollback()


def test_document_version_originals_are_immutable(db):
    firm = make_firm(db); u = make_user(db, firm, "solicitor"); c = make_contact(db, firm, "Acme Ltd", "organisation"); m = make_matter(db, firm, c, u)
    d = Document(firm_id=firm.id, matter_id=m.id, title="A", created_by=u.id); db.add(d); db.flush()
    v = DocumentVersion(firm_id=firm.id, document_id=d.id, version_no=1, storage_key="k/1", sha256="b" * 64, size_bytes=3, content_type="text/plain", original_filename="a.txt", author_id=u.id)
    db.add(v); db.commit()
    db.execute(text("update document_versions set scan_status='clean', ocr_status='done' where id=:i"), {"i": v.id}); db.commit()  # worker-owned fields may change
    for sql in ("update document_versions set sha256='c' where id=:i", "update document_versions set storage_key='x' where id=:i", "delete from document_versions where id=:i"):
        with pytest.raises(DBAPIError, match="immutable|cannot be deleted"):
            db.execute(text(sql), {"i": v.id}); db.flush()
        db.rollback()


def test_confirmed_deadline_requires_a_human(db):
    from app.models import Deadline
    firm = make_firm(db); u = make_user(db, firm, "solicitor"); c = make_contact(db, firm, "Acme Ltd", "organisation"); m = make_matter(db, firm, c, u)
    with pytest.raises(IntegrityError):
        db.add(Deadline(firm_id=firm.id, matter_id=m.id, title="x", due_date=date.today(), origin="ai_suggestion", status="confirmed")); db.flush()
    db.rollback()
    db.add(Deadline(firm_id=firm.id, matter_id=m.id, title="x", due_date=date.today(), origin="ai_suggestion", status="suggested")); db.commit()
