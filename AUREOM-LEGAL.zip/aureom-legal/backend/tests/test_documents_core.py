"""Documents: upload validation, hashing/immutability, versions, access control, scan gating, OCR, search, compare."""
import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError

from app.config import get_settings
from app.db.session import new_session
from app.integrations.malware import EICAR
from app.models import AuditEvent, Document, DocumentChunk, DocumentVersion, MatterMember
from app.security import sha256_hex
from tests.docs_helpers import AGREEMENT, PNG, add_version, arrange, drain, upload


@pytest.fixture()
def w(db, app):
    return arrange(db, app)


def test_upload_validates_type_content_size_and_filename(w, monkeypatch):
    a = w.api(w.fe)
    assert upload(a, "malware.exe", b"MZ\x90\x00", matter_id=w.std.id).status_code == 422
    r = upload(a, "fake.pdf", b"just text, not a pdf", matter_id=w.std.id)
    assert r.status_code == 422 and r.json()["error"]["code"] == "file_content_mismatch"
    assert upload(a, "binary.txt", b"abc\x00def", matter_id=w.std.id).status_code == 422
    assert upload(a, "empty.txt", b"", matter_id=w.std.id).status_code == 422
    monkeypatch.setattr(get_settings(), "max_upload_bytes", 50)
    r = upload(a, "big.txt", b"x" * 200, matter_id=w.std.id)
    assert r.status_code == 422 and r.json()["error"]["code"] == "file_too_large"
    monkeypatch.undo()
    r = upload(a, "../../etc/passwd.txt", b"hello world", matter_id=w.std.id, title="Odd name")
    assert r.status_code == 201
    assert r.json()["versions"][0]["original_filename"] == "passwd.txt"
    assert upload(a, "x.txt", b"hello", matter_id=w.std.id, doc_type="nonsense").status_code == 422


def test_hash_immutability_and_versions(w, db):
    a = w.api(w.fe)
    r = upload(a, "agreement.txt", AGREEMENT, matter_id=w.std.id, title="Supply agreement", doc_type="agreement", tags="draft,heron")
    assert r.status_code == 201, r.text
    d = r.json(); v1 = d["versions"][0]
    assert v1["sha256"] == sha256_hex(AGREEMENT) and v1["version_no"] == 1 and v1["scan_status"] == "pending"
    v2_body = AGREEMENT.replace(b"thirty", b"sixty")
    r2 = add_version(a, d["id"], "agreement-v2.txt", v2_body, change_note="Notice period to 60 days")
    assert r2.status_code == 201
    d2 = r2.json()
    assert [v["version_no"] for v in d2["versions"]] == [2, 1] and d2["current_version_no"] == 2
    # references stay stable: v1 keeps its id and hash
    old = next(v for v in d2["versions"] if v["version_no"] == 1)
    assert old["id"] == v1["id"] and old["sha256"] == v1["sha256"]
    assert d2["versions"][0]["sha256"] == sha256_hex(v2_body) and d2["versions"][0]["author_name"] == "Sam Solicitor"
    # DB trigger: originals cannot be tampered with or deleted (even by the owner)
    for sql in ("update document_versions set sha256 = 'f' where id = :i", "update document_versions set storage_key = 'x' where id = :i",
                "delete from document_versions where id = :i"):
        with pytest.raises(DBAPIError):
            db.execute(text(sql), {"i": v1["id"]}); db.flush()
        db.rollback()
    # worker-owned status columns remain updatable
    db.execute(text("update document_versions set scan_status='clean' where id = :i"), {"i": v1["id"]}); db.commit()
    # application role can never delete versions
    with new_session(w.firm.id) as s:
        with pytest.raises(DBAPIError):
            s.execute(text("delete from document_versions")); s.flush()
    audits = db.execute(select(AuditEvent.action).where(AuditEvent.firm_id == w.firm.id, AuditEvent.entity_id == d["id"])).scalars().all()
    assert "document.uploaded" in audits and "document.version_added" in audits


def test_restricted_matter_and_role_enforcement(w, db):
    fe = w.api(w.fe)
    r = upload(fe, "secret.txt", b"The merger codename is Project Falcon.", matter_id=w.restricted.id, title="Secret note")
    assert r.status_code == 201; doc_id = r.json()["id"]
    assert upload(fe, "pub.txt", b"The merger codename is public knowledge Falcon.", matter_id=w.std.id, title="Public note").status_code == 201
    drain()
    # member paralegal and fee earner see it; non-member solicitor does not (list, search, get, preview, download, export)
    for u in (w.fe, w.para):
        titles = {d["title"] for d in w.api(u).get("/documents").json()["items"]}
        assert "Secret note" in titles
    o = w.api(w.other)
    assert {d["title"] for d in o.get("/documents").json()["items"]} == {"Public note"}
    hits = o.get("/documents/search", params={"q": "Falcon"}).json()
    assert [h["title"] for h in hits["items"]] == ["Public note"] and hits["total"] == 1
    assert o.get(f"/documents/{doc_id}").status_code == 403
    assert o.get(f"/documents/{doc_id}").json()["error"]["code"] == "matter_access_denied"
    assert o.get(f"/documents/{doc_id}/versions/1/preview").status_code == 403
    assert o.get(f"/documents/{doc_id}/versions/1/download").status_code == 403
    assert o.post("/documents/exports", {"matter_id": str(w.restricted.id), "document_ids": [doc_id], "reason": "client request"}).status_code == 403
    assert upload(o, "x.txt", b"hi there", matter_id=w.restricted.id).status_code == 403
    # ethical wall deny entry beats membership
    db.add(MatterMember(firm_id=w.firm.id, matter_id=w.restricted.id, user_id=w.para.id, access="deny")); db.commit()
    db.query(MatterMember).filter_by(matter_id=w.restricted.id, user_id=w.para.id, access="allow").delete(); db.commit()
    assert w.api(w.para).get(f"/documents/{doc_id}").status_code == 403
    # finance has no document access at all; cross-firm id is 404
    f = w.api(w.fin)
    assert f.get("/documents").status_code == 403 and f.get(f"/documents/{doc_id}").status_code == 403
    from tests.factories import make_firm, make_user
    f2 = make_firm(db); u2 = make_user(db, f2, "partner")
    assert w.api(u2).get(f"/documents/{doc_id}").status_code == 404


def test_exports_disabled_matter_blocks_download(w, db):
    w.std.exports_allowed = False; db.commit()
    a = w.api(w.fe)
    doc = upload(a, "a.txt", b"hello there", matter_id=w.std.id).json()
    drain()
    assert a.get(f"/documents/{doc['id']}/versions/1/preview").status_code == 200
    r = a.get(f"/documents/{doc['id']}/versions/1/download")
    assert r.status_code == 403 and r.json()["error"]["code"] == "export_blocked"
    assert a.post("/documents/exports", {"matter_id": str(w.std.id), "document_ids": [doc["id"]], "reason": "needed for client"}).status_code == 403


def test_scan_gating_with_eicar(w, db):
    a = w.api(w.fe)
    ok = upload(a, "ok.txt", b"clean document text", matter_id=w.std.id, title="Clean").json()
    bad = upload(a, "eicar.txt", EICAR, matter_id=w.std.id, title="Infected").json()
    # before the worker runs nothing can be previewed or downloaded
    r = a.get(f"/documents/{ok['id']}/versions/1/preview")
    assert r.status_code == 409 and r.json()["error"]["code"] == "scan_pending"
    assert drain() >= 4
    assert a.get(f"/documents/{ok['id']}/versions/1/preview").status_code == 200
    d = a.get(f"/documents/{bad['id']}").json()["versions"][0]
    assert d["scan_status"] == "infected" and d["index_status"] == "skipped"
    for ep in ("preview", "download"):
        r = a.get(f"/documents/{bad['id']}/versions/1/{ep}")
        assert r.status_code == 409 and r.json()["error"]["code"] == "scan_infected"
    # infected text was never extracted/indexed
    assert db.query(DocumentChunk).filter(DocumentChunk.document_id == bad["id"]).count() == 0
    assert a.get("/documents/search", params={"q": "EICAR"}).json()["total"] == 0
    # unavailable scanner -> files stay blocked (fail closed)
    from app.integrations import base
    from app.integrations.malware import ClamAVScanner, MockScanner
    old = base._REGISTRY["malware"]
    base.register(ClamAVScanner())
    try:
        d3 = upload(a, "c.txt", b"another clean file", matter_id=w.std.id).json()
        drain()
        v = a.get(f"/documents/{d3['id']}").json()["versions"][0]
        assert v["scan_status"] == "unavailable"
        assert a.get(f"/documents/{d3['id']}/versions/1/download").json()["error"]["code"] == "scan_unavailable"
    finally:
        base._REGISTRY["malware"] = old


def test_download_headers_and_audit(w, db):
    a = w.api(w.fe)
    d = upload(a, "n.txt", b"<script>alert(1)</script> note", matter_id=w.std.id).json()
    drain()
    r = a.get(f"/documents/{d['id']}/versions/1/download")
    assert r.status_code == 200 and r.content == b"<script>alert(1)</script> note"
    assert r.headers["content-disposition"].startswith("attachment") and r.headers["x-content-type-options"] == "nosniff"
    assert "sandbox" in r.headers["content-security-policy"] and r.headers["content-type"] == "application/octet-stream"
    # preview is plain text JSON (script is data, not rendered)
    p = a.get(f"/documents/{d['id']}/versions/1/preview").json()
    assert p["render"] == "text" and "<script>" in p["pages"][0]["paragraphs"][0]["text"]
    assert db.query(AuditEvent).filter_by(firm_id=w.firm.id, action="document.downloaded").count() == 1
    img = upload(a, "pic.png", PNG, matter_id=w.std.id).json(); drain()
    ri = a.get(f"/documents/{img['id']}/versions/1/download", params={"inline": "true"})
    assert ri.headers["content-type"] == "image/png" and ri.headers["content-disposition"] == "inline"


def test_ocr_job_simulated_for_images_and_scanned_pdf(w, db):
    a = w.api(w.fe)
    d = upload(a, "scan.png", PNG, matter_id=w.std.id, title="Scanned letter").json()
    assert d["versions"][0]["ocr_status"] == "pending"
    drain()
    v = a.get(f"/documents/{d['id']}").json()["versions"][0]
    assert v["scan_status"] == "clean" and v["ocr_status"] == "simulated" and v["index_status"] == "done"
    chunks = db.query(DocumentChunk).filter(DocumentChunk.document_id == d["id"]).all()
    assert chunks and all(c.is_ocr for c in chunks) and "SIMULATED" in chunks[0].text
    hit = a.get("/documents/search", params={"q": "simulated ocr"}).json()["items"][0]
    assert hit["is_ocr"] is True
    # a PDF with no text layer is routed to OCR too
    from reportlab.pdfgen import canvas
    import io
    buf = io.BytesIO(); c = canvas.Canvas(buf); c.rect(50, 50, 100, 100); c.save()
    d2 = upload(a, "blank.pdf", buf.getvalue(), matter_id=w.std.id).json(); drain()
    assert a.get(f"/documents/{d2['id']}").json()["versions"][0]["ocr_status"] == "simulated"


def test_fulltext_search_and_citation_refs_pdf_and_text(w, db):
    a = w.api(w.fe)
    d = upload(a, "agreement.txt", AGREEMENT, matter_id=w.std.id, title="Supply agreement").json()
    drain()
    hits = a.get("/documents/search", params={"q": "termination notice"}).json()
    assert hits["total"] >= 1
    h = hits["items"][0]
    assert (h["page"], h["paragraph"], h["version_no"], h["matter_reference"]) == (2, 1, 1, "HV-001")
    assert "⟦" in h["snippet"] and h["document_id"] == d["id"]
    # new version replaces the searchable text; old text is not matched as current
    add_version(a, d["id"], "agreement.txt", AGREEMENT.replace(b"thirty days", b"ninety days"))
    drain()
    assert a.get("/documents/search", params={"q": "ninety"}).json()["items"][0]["version_no"] == 2
    assert a.get("/documents/search", params={"q": "thirty"}).json()["total"] == 0
    # PDF text extraction with page references
    from reportlab.pdfgen import canvas
    import io
    buf = io.BytesIO(); c = canvas.Canvas(buf)
    c.drawString(72, 750, "Lease of Unit 4 Weaver's Yard."); c.showPage()
    c.drawString(72, 750, "Rent review shall take place every five years."); c.save()
    p = upload(a, "lease.pdf", buf.getvalue(), matter_id=w.std.id, title="Lease").json(); drain()
    ph = a.get("/documents/search", params={"q": "rent review"}).json()["items"][0]
    assert ph["title"] == "Lease" and ph["page"] == 2
    assert a.get("/documents", params={"q": "ninety"}).json()["total"] == 1
    assert a.get("/documents", params={"tag": "nothing"}).json()["total"] == 0


def test_compare_versions(w, db):
    a = w.api(w.fe)
    d = upload(a, "agreement.txt", AGREEMENT, matter_id=w.std.id, title="Supply agreement").json()
    add_version(a, d["id"], "agreement.txt", AGREEMENT.replace(b"thirty", b"sixty") + b"\n12. Governing law. England and Wales.\n")
    r = a.get(f"/documents/{d['id']}/compare", params={"from": 1, "to": 2})
    assert r.status_code == 422 and r.json()["error"]["code"] == "compare_unsupported"  # not scanned/extracted yet
    drain()
    c = a.get(f"/documents/{d['id']}/compare", params={"from": 1, "to": 2}).json()
    assert c["summary"]["changed"] == 1 and c["summary"]["added"] == 1 and c["summary"]["unchanged"] >= 3
    changed = next(o for o in c["operations"] if o["op"] == "changed")
    assert "thirty" in changed["from"][0]["text"] and "sixty" in changed["to"][0]["text"]
    img = upload(a, "p.png", PNG, matter_id=w.std.id).json(); add_version(a, img["id"], "q.png", PNG + b"1"); drain()
    assert a.get(f"/documents/{img['id']}/compare", params={"from": 1, "to": 2}).status_code == 422


def test_review_approval_signature_flow(w, db):
    a, p = w.api(w.fe), w.api(w.partner)
    d = upload(a, "agreement.txt", AGREEMENT, matter_id=w.std.id, title="Supply agreement").json(); drain()
    assert a.post(f"/documents/{d['id']}/signature-request", {"signers": [{"name": "A", "email": "a@x.example"}]}).status_code == 409  # not approved
    assert a.post(f"/documents/{d['id']}/review-request").json()["status"] == "in_review"
    assert w.api(w.para).post(f"/documents/{d['id']}/approve", {"approve": True}).status_code == 403
    assert p.post(f"/documents/{d['id']}/approve", {"approve": True}).json()["status"] == "approved"
    sr = a.post(f"/documents/{d['id']}/signature-request", {"signers": [{"name": "Sarah Whitlock", "email": "s@heron.example"}]}).json()
    assert sr["simulated"] and "SIMULATED" in sr["notice"]
    done = a.post(f"/documents/signature-requests/{sr['id']}/simulate-complete").json()
    assert done["status"] == "signed" and done["signed_version_no"] == 2
    full = a.get(f"/documents/{d['id']}").json()
    assert full["status"] == "signed" and full["versions"][0]["original_filename"].endswith("(simulated).txt")
    assert a.post(f"/documents/signature-requests/{sr['id']}/simulate-complete").status_code == 409
    # a new version after approval resets the workflow
    d2 = upload(a, "b.txt", b"second doc text", matter_id=w.std.id).json(); drain()
    a.post(f"/documents/{d2['id']}/review-request"); p.post(f"/documents/{d2['id']}/approve", {"approve": True})
    assert add_version(a, d2["id"], "b.txt", b"second doc text edited").json()["status"] == "draft"
    assert a.post(f"/documents/{d2['id']}/signature-request", {"signers": [{"name": "A", "email": "a@x.example"}]}).status_code == 409


def test_folders_metadata_concurrency_and_legal_hold(w, db):
    a = w.api(w.fe)
    f = a.post("/documents/folders", {"matter_id": str(w.std.id), "name": "Correspondence"}).json()
    d = upload(a, "a.txt", b"hello there", matter_id=w.std.id, folder_id=f["id"]).json()
    assert a.delete(f"/documents/folders/{f['id']}").status_code == 409
    r = a.patch(f"/documents/{d['id']}", {"expected_version": d["version"], "title": "Renamed", "tags": ["x"]})
    assert r.status_code == 200 and r.json()["title"] == "Renamed"
    assert a.patch(f"/documents/{d['id']}", {"expected_version": d["version"], "title": "Stale"}).status_code == 409
    cur = r.json()["version"]
    assert a.patch(f"/documents/{d['id']}", {"expected_version": cur, "client_visible": True}).status_code == 200  # solicitor holds documents.approve
    assert w.api(w.para).patch(f"/documents/{d['id']}", {"expected_version": cur + 1, "client_visible": False}).status_code == 403
    assert a.post(f"/documents/{d['id']}/legal-hold", {"hold": True, "reason": "x"}).status_code == 403  # needs matters.approve
    r = w.api(w.partner).post(f"/documents/{d['id']}/legal-hold", {"hold": True, "reason": "Litigation anticipated"})
    assert r.status_code == 200 and r.json()["legal_hold"] is True
