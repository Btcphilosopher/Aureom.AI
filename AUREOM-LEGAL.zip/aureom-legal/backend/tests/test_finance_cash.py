"""Receipts, allocation (limits, replay, concurrency), client-money transfers, revenue recognition, reconciliation."""
import threading
from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.db.session import new_session
from app.deps import Ctx
from app.errors import AppError, ApprovalRequired, InvalidState, PermissionDenied, ValidationFailed
from app.models import BankStatementLine, Invoice, Journal, JournalLine, Payment, PaymentAllocation, RevenueRecognition, User
from app.services import approvals, billing, ledger as led, reconciliation as rec, reports
from app.services.matter_finance import client_balance
from tests.finance_world import World


@pytest.fixture()
def w(db):
    world = World(db)
    yield world
    world.close()


def bal(w, key, ledger="office"):
    return led.account_balance(w.s, led.system_account(w.s, w.firm.id, key, ledger))


def approve_alloc(w, pid, allocs):
    ap = led.request_allocation(w.ctx(w.fin_a), pid, allocs); w.commit()
    led.decide_approval(w.ctx(w.fin_b), ap.id, approve=True); w.commit()
    return ap


def test_bank_feed_sync_idempotent_and_receipt_needs_authorisation(w):
    r1 = rec.sync_bank_feed(w.ctx(w.fin_a), "office"); w.commit()
    r2 = rec.sync_bank_feed(w.ctx(w.fin_a), "office"); w.commit()
    assert r1["created"] == 3 and r2["created"] == 0 and r2["skipped"] == 3 and r1["mode"] == "mock" and r1["synthetic"] is True
    line = w.s.execute(select(BankStatementLine).where(BankStatementLine.external_id == "SYN-O-0001")).scalar_one()
    pay = rec.record_receipt(w.ctx(w.fin_a), line.id); w.commit()
    assert pay.status == "pending_authorisation" and bal(w, "bank_office") == Decimal("0.00")   # draft journal only: nothing posted yet
    with pytest.raises(InvalidState) as e:
        rec.record_receipt(w.ctx(w.fin_a), line.id)
    assert e.value.code == "already_recorded"; w.s.rollback()
    with pytest.raises(InvalidState):   # unposted receipt cannot be allocated
        iid = w.billed_invoice()
        led.request_allocation(w.ctx(w.fin_a), pay.id, [{"invoice_id": str(iid), "amount": "10"}])
    w.s.rollback()


def test_receipt_is_not_revenue_until_recognition_step(w):
    iid = w.billed_invoice(minutes=90)                       # invoice total 360 (net 300)
    pid = w.record_and_post_receipt("office", amount_index=0)   # SYN-O-0001 1,500
    pay = w.s.get(Payment, pid)
    assert pay.status == "received_unallocated"
    assert bal(w, "bank_office") == Decimal("1500.00") and bal(w, "unallocated_receipts") == Decimal("1500.00") and bal(w, "fee_income") == Decimal("0.00")
    ap = approve_alloc(w, pid, [{"invoice_id": str(iid), "amount": "360.00"}])
    led.execute_allocation(w.ctx(w.fin_a), pid, [{"invoice_id": str(iid), "amount": "360.00"}], ap.id); w.commit()
    inv, pay = w.s.get(Invoice, iid), w.s.get(Payment, pid)
    assert inv.status == "paid" and inv.amount_paid == Decimal("360.00") and pay.status == "partially_allocated" and pay.allocated_amount == Decimal("360.00")
    assert bal(w, "debtors") == Decimal("0.00") and bal(w, "unallocated_receipts") == Decimal("1140.00")
    assert bal(w, "fee_income") == Decimal("0.00"), "cash received and allocated must still not be revenue"
    rep = reports.run(w.ctx(w.fin_a), "recognised-revenue")
    assert rep["totals"]["recognised"] == Decimal("0.00")
    cash = reports.run(w.ctx(w.fin_a), "cash-received")
    assert cash["totals"]["office_receipts"] == Decimal("1500.00") and "NOT earned revenue" in cash["basis"]
    # explicit, separately authorised revenue recognition
    j = led.request_revenue_recognition(w.ctx(w.fin_a), iid, Decimal("300.00"), "Work complete and billed under hourly arrangement"); w.commit()
    assert j.status == "pending_approval" and bal(w, "fee_income") == Decimal("0.00")
    led.decide_approval(w.ctx(w.fin_b), j.approval_id, approve=True); w.commit()
    led.post_journal(w.ctx(w.fin_a), j.id); w.commit()
    assert bal(w, "fee_income") == Decimal("300.00") and bal(w, "fees_billed_unrecognised") == Decimal("0.00")
    rr = w.s.execute(select(RevenueRecognition)).scalar_one()
    assert rr.amount == Decimal("300.00") and "hourly" in rr.basis and rr.recognised_by == w.fin_a.id
    assert reports.run(w.ctx(w.fin_a), "recognised-revenue")["totals"]["recognised"] == Decimal("300.00")
    with pytest.raises(InvalidState) as e:                        # nothing left to recognise
        led.request_revenue_recognition(w.ctx(w.fin_a), iid, Decimal("0.01"), "More revenue please")
    assert e.value.code == "over_recognition"; w.s.rollback()


def test_allocation_limits_four_eyes_and_replay(w):
    ids = [w.billed_invoice(minutes=90) for _ in range(3)]       # 3 x 360
    pid = w.record_and_post_receipt("office", amount_index=2)      # SYN-O-0003 960
    A = lambda i, amt: {"invoice_id": str(ids[i]), "amount": amt}
    with pytest.raises(InvalidState) as e:                        # 1080 > 960 available
        led.request_allocation(w.ctx(w.fin_a), pid, [A(0, "360"), A(1, "360"), A(2, "360")])
    assert e.value.code == "over_allocation"; w.s.rollback()
    with pytest.raises(InvalidState):                             # more than the invoice outstanding
        led.request_allocation(w.ctx(w.fin_a), pid, [A(0, "360.01")])
    w.s.rollback()
    req = led.request_allocation(w.ctx(w.fin_a), pid, [A(0, "360"), A(1, "360")]); w.commit()
    with pytest.raises(ApprovalRequired):                         # not yet authorised
        led.execute_allocation(w.ctx(w.fin_a), pid, [A(0, "360"), A(1, "360")], req.id)
    w.s.rollback()
    with pytest.raises(PermissionDenied) as e:                    # requester cannot approve own request
        led.decide_approval(w.ctx(w.fin_a), req.id, approve=True)
    assert e.value.code == "four_eyes_required"; w.s.rollback()
    led.decide_approval(w.ctx(w.fin_b), req.id, approve=True); w.commit()
    with pytest.raises(ApprovalRequired) as e:                    # approval binds to the exact allocation
        led.execute_allocation(w.ctx(w.fin_a), pid, [A(0, "360"), A(1, "300")], req.id)
    assert e.value.code == "approval_stale"; w.s.rollback()
    led.execute_allocation(w.ctx(w.fin_a), pid, [A(0, "360"), A(1, "360")], req.id); w.commit()
    with pytest.raises(InvalidState) as e:                        # duplicate execution of the same approval
        led.execute_allocation(w.ctx(w.fin_a), pid, [A(0, "360"), A(1, "360")], req.id)
    assert e.value.code == "already_executed"; w.s.rollback()
    assert w.s.execute(select(PaymentAllocation)).scalars().all().__len__() == 2
    pay = w.s.get(Payment, pid)
    assert pay.allocated_amount == Decimal("720.00") and pay.status == "partially_allocated"
    with pytest.raises(InvalidState):                             # only 240 left on the payment
        led.request_allocation(w.ctx(w.fin_a), pid, [A(2, "241")])
    w.s.rollback()
    ap = approve_alloc(w, pid, [A(2, "240")])
    led.execute_allocation(w.ctx(w.fin_a), pid, [A(2, "240")], ap.id); w.commit()
    third = w.s.get(Invoice, ids[2])
    assert third.status == "partially_paid" and third.amount_paid == Decimal("240.00") and w.s.get(Payment, pid).status == "allocated"


def _threaded(w, jobs):
    """Run allocation executions concurrently, each on its own application-role session."""
    results, barrier = [], threading.Barrier(len(jobs))

    def run(pid, allocs, ap_id):
        with new_session(w.firm.id) as s:
            ctx = Ctx.for_user(s, s.get(User, w.fin_a.id))
            barrier.wait()
            try:
                led.execute_allocation(ctx, pid, allocs, ap_id)
                s.commit(); results.append("ok")
            except AppError as exc:
                s.rollback(); results.append(exc.code)
    ts = [threading.Thread(target=run, args=j) for j in jobs]
    [t.start() for t in ts]; [t.join(30) for t in ts]
    return results


def test_concurrent_allocations_cannot_over_allocate(w):
    a, b = w.billed_invoice(minutes=300), w.billed_invoice(minutes=300)      # 1,200 each (1,000 + VAT)
    pid = w.record_and_post_receipt("office", amount_index=2)                 # 960 available
    AA, BB = [{"invoice_id": str(a), "amount": "600"}], [{"invoice_id": str(b), "amount": "600"}]
    ap1, ap2 = approve_alloc(w, pid, AA), approve_alloc(w, pid, BB)           # each valid alone; together 1,200 > 960
    results = _threaded(w, [(pid, AA, ap1.id), (pid, BB, ap2.id)])
    assert sorted(results) == ["ok", "over_allocation"], results
    w.s.expire_all()
    assert w.s.get(Payment, pid).allocated_amount == Decimal("600.00")
    assert sum(i.amount_paid for i in w.s.execute(select(Invoice).where(Invoice.id.in_([a, b]))).scalars()) == Decimal("600.00")
    assert bal(w, "unallocated_receipts") == Decimal("360.00")                 # 960 - 600


def test_concurrent_duplicate_execution_of_one_approval(w):
    a = w.billed_invoice(minutes=300)
    pid = w.record_and_post_receipt("office", amount_index=2)
    AA = [{"invoice_id": str(a), "amount": "500"}]
    ap = approve_alloc(w, pid, AA)
    results = _threaded(w, [(pid, AA, ap.id), (pid, AA, ap.id)])
    assert sorted(results) == ["already_executed", "ok"], results
    w.s.expire_all()
    assert w.s.get(Payment, pid).allocated_amount == Decimal("500.00")
    assert len(w.s.execute(select(PaymentAllocation)).scalars().all()) == 1


def test_client_money_transfer_requires_funds_invoice_and_dual_authorisation(w):
    iid = w.billed_invoice(minutes=90)
    with pytest.raises(InvalidState) as e:
        led.request_client_transfer(w.ctx(w.fin_a), iid, Decimal("360"))
    assert e.value.code == "insufficient_client_funds"; w.s.rollback()
    w.record_and_post_receipt("client", matter=w.matter, amount_index=0)       # 10,000 client money
    assert client_balance(w.s, w.matter.id) == Decimal("10000.00")
    assert bal(w, "bank_office") == Decimal("0.00")                              # client money is not office money
    with pytest.raises(PermissionDenied):                                        # a partner cannot propose (no ledger.post)
        led.request_client_transfer(w.ctx(w.partner), iid, Decimal("360"))
    w.s.rollback()
    draft, _ = (lambda: (billing.create_draft_invoice(w.ctx(w.solicitor), matter_id=w.matter.id, adjustments=[{"description": "x", "amount": Decimal("5")}]), None))()
    w.commit()
    with pytest.raises(InvalidState) as e:
        led.request_client_transfer(w.ctx(w.fin_a), draft.id, Decimal("1"))
    assert e.value.code == "invoice_not_issued"; w.s.rollback()
    ap = led.request_client_transfer(w.ctx(w.fin_a), iid, Decimal("360")); w.commit()
    with pytest.raises(PermissionDenied) as e:
        led.decide_approval(w.ctx(w.fin_a), ap.id, approve=True)
    assert e.value.code == "four_eyes_required"; w.s.rollback()
    with pytest.raises(ApprovalRequired):
        led.execute_client_transfer(w.ctx(w.fin_a), iid, Decimal("360"), ap.id)
    w.s.rollback()
    led.decide_approval(w.ctx(w.fin_b), ap.id, approve=True); w.commit()
    with pytest.raises(ApprovalRequired):                                        # amount is bound to the approval
        led.execute_client_transfer(w.ctx(w.fin_a), iid, Decimal("359"), ap.id)
    w.s.rollback()
    led.execute_client_transfer(w.ctx(w.fin_a), iid, Decimal("360"), ap.id); w.commit()
    assert client_balance(w.s, w.matter.id) == Decimal("9640.00") and bal(w, "bank_client", "client") == Decimal("9640.00")
    assert bal(w, "bank_office") == Decimal("360.00") and bal(w, "debtors") == Decimal("0.00") and w.s.get(Invoice, iid).status == "paid"
    with pytest.raises(InvalidState) as e:
        led.execute_client_transfer(w.ctx(w.fin_a), iid, Decimal("360"), ap.id)
    assert e.value.code in ("already_executed", "over_allocation", "invoice_not_issued"); w.s.rollback()


def test_reconciliation_workflow(w):
    w.record_and_post_receipt("office", amount_index=0)    # 1,500
    w.record_and_post_receipt("office", amount_index=0)    # 2,400 (next unrecorded line)
    bank = led.system_account(w.s, w.firm.id, "bank_office", "office")
    r = rec.create_reconciliation(w.ctx(w.fin_a), bank_account_id=bank.id, period_end=date.today(), statement_balance=Decimal("4860.00")); w.commit()
    assert r.ledger_balance == Decimal("3900.00") and r.difference == Decimal("960.00")     # third statement line not yet in the ledger
    with pytest.raises(PermissionDenied) as e:
        rec.sign_off(w.ctx(w.fin_a), r.id)
    assert e.value.code == "four_eyes_required"; w.s.rollback()
    with pytest.raises(InvalidState) as e:
        rec.sign_off(w.ctx(w.fin_b), r.id)
    assert e.value.code == "reconciliation_difference"; w.s.rollback()
    w.record_and_post_receipt("office", amount_index=0)    # 960 -> ledger now 4,860
    r = w.s.get(type(r), r.id); rec.refresh(w.ctx(w.fin_a), r); w.commit()
    assert r.difference == Decimal("0.00")
    with pytest.raises(InvalidState) as e:                 # nil difference but items not matched yet
        rec.sign_off(w.ctx(w.fin_b), r.id)
    assert e.value.code == "unmatched_items"; w.s.rollback()
    sugg = rec.suggest_matches(w.s, w.firm.id, bank.id, date.today())
    assert len(sugg) == 3
    bad = {"bank_line_id": sugg[0]["bank_line_id"], "journal_line_id": sugg[1]["journal_line_id"]}
    with pytest.raises(ValidationFailed) as e:
        rec.match_lines(w.ctx(w.fin_a), [bad])
    assert e.value.code == "match_mismatch"; w.s.rollback()
    assert rec.match_lines(w.ctx(w.fin_a), [{"bank_line_id": s["bank_line_id"], "journal_line_id": s["journal_line_id"]} for s in sugg]) == 3; w.commit()
    done = rec.sign_off(w.ctx(w.fin_b), r.id); w.commit()
    assert done.status == "signed_off" and done.signed_off_by == w.fin_b.id and done.prepared_by == w.fin_a.id
    assert {l.status for l in w.s.execute(select(BankStatementLine).where(BankStatementLine.bank_account_id == bank.id)).scalars()} == {"reconciled"}
    assert all(l.reconciled_at for l in w.s.execute(select(JournalLine).where(JournalLine.account_id == bank.id)).scalars())
    with pytest.raises(InvalidState):
        rec.refresh(w.ctx(w.fin_a), w.s.get(type(r), r.id))
    w.s.rollback()
