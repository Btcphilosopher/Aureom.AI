"""The complete demonstration workflow, driven only through the public HTTP API as the people who would do each step.

 1 create prospective client  2 review conflict match  3 simulated onboarding  4 open restricted commercial matter
 5 upload + version a fictional agreement  6 document-review + chronology agents  7 confirm suggested task + deadline
 8 review/approve a draft client message  9 record time, draft invoice  10 allocate synthetic receipt + reconcile
 11 close the matter with retention."""
from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import AuditEvent, Firm, User
from app.seed import content as C
from tests.factories import Api

SAMPLE = Path(__file__).resolve().parents[2] / "sample-docs"


@pytest.fixture(scope="module")
def world(owner_engine):
    from app.seed import demo
    from app import integrations
    integrations.load_all()
    with Session(owner_engine, expire_on_commit=False) as db:
        demo.seed(db)
    yield


def who(app, local: str) -> Api:
    return Api(app).login(f"{local}@{C.EMAIL_DOMAIN}", get_settings().demo_password)


def drain():
    from app.services import jobs
    from app.worker import load_handlers
    load_handlers()
    return jobs.run_all_pending()


def ok(r, code=(200, 201)):
    assert r.status_code in (code if isinstance(code, tuple) else (code,)), f"{r.request.method} {r.request.url.path} -> {r.status_code}: {r.text[:600]}"
    return r.json()


class Flow:  # shared state across the ordered steps
    pass


F = Flow()


def test_step01_create_prospective_client(app, world):
    daniel = who(app, "daniel.rhodes")
    org = ok(daniel.post("/clients", {"kind": "organisation", "display_name": "Hebden Bridge Brewing Company Ltd", "company_number": "09876543",
                                      "email": "rebecca.ellison@hebden-brewing.example", "preferred_channel": "email",
                                      "addresses": [{"kind": "registered", "line1": "Mill Lane", "city": "Hebden Bridge", "postcode": "HX7 8AA", "is_primary": True}]}))
    assert org["status"] == "prospect" and not org["is_client"]
    director = ok(daniel.post("/clients", {"kind": "individual", "display_name": "Martin Ackroyd", "date_of_birth": "1975-11-02", "email": "martin@hebden-brewing.example"}))
    ok(daniel.post(f"/clients/{director['id']}/relationships", {"to_contact_id": org["id"], "relation_type": "director_of"}))
    F.client_id, F.director_id = org["id"], director["id"]
    # counterparty recorded as a contact so it can be a party / searched
    cp = ok(daniel.post("/clients", {"kind": "organisation", "display_name": "Northern Taprooms Distribution Limited", "company_number": "07123456"}))
    F.counterparty_id = cp["id"]


def test_step02_conflict_search_and_human_review(app, world):
    daniel, margaret = who(app, "daniel.rhodes"), who(app, "margaret.thackray")
    s = ok(daniel.post("/conflicts/searches", {"terms": ["Hebden Bridge Brewing Company Ltd", "Northern Taprooms Distribution Limited", "Martin Ackroyd"], "subject_contact_id": F.client_id}))
    F.search_id = s["id"]
    detail = ok(margaret.get(f"/conflicts/searches/{F.search_id}"))
    assert detail["status"] == "pending_review", "a search is never auto-cleared"
    matches = detail["matches"]
    assert matches, "expected supporting matches (fuzzy org name / director name)"
    assert any(m["match_type"] in ("name_fuzzy", "alias", "organisation") for m in matches) or any("Hebden" in m["searched_term"] for m in matches)
    # cannot clear before every match has a disposition
    early = margaret.post(f"/conflicts/searches/{F.search_id}/decision", {"decision": "cleared_by_reviewer", "note": "x" * 10})
    assert early.status_code in (409, 422)
    # a solicitor without conflicts.review cannot decide
    assert daniel.post(f"/conflicts/searches/{F.search_id}/decision", {"decision": "cleared_by_reviewer", "note": "trying"}).status_code == 403
    for m in matches:
        ok(margaret.patch(f"/conflicts/matches/{m['id']}", {"disposition": "false_positive", "note": "Different entity: different company number and location (reviewed supporting records)."}))
    detail = ok(margaret.get(f"/conflicts/searches/{F.search_id}"))
    ok(margaret.post(f"/conflicts/searches/{F.search_id}/decision", {"decision": "cleared_by_reviewer", "note": "All matches reviewed and recorded as false positives.", "expected_version": detail["version"]}))
    hist = ok(margaret.get(f"/conflicts/searches/{F.search_id}"))["history"]
    assert len(hist) >= len(matches) + 1 and {h["event"] for h in hist} >= {"match_disposition", "search_decision"}


def test_step03_simulated_onboarding(app, world):
    daniel, margaret = who(app, "daniel.rhodes"), who(app, "margaret.thackray")
    ok(daniel.post(f"/clients/{F.client_id}/onboarding", {}), (200, 201))
    for ct in ("company_kyb", "sanctions_pep", "id_individual"):
        r = daniel.post(f"/clients/{F.client_id}/onboarding/checks", {"check_type": ct})
        if r.status_code in (200, 201):
            body = r.json()
            blob = str(body).lower()
            assert "simulated" in blob and "verified identity" not in blob.replace("not a verified identity", "")
    ob = ok(daniel.get(f"/clients/{F.client_id}/onboarding"))
    assert all(c["is_simulated"] if "is_simulated" in c else True for c in ob["checks"])
    # solicitor cannot approve; compliance can (human reviewer)
    assert daniel.post(f"/clients/{F.client_id}/onboarding/approve", {"note": "ok"}).status_code == 403
    for c in ob["checks"]:
        if c["status"] in ("passed_simulated", "needs_review"):
            r = margaret.post(f"/clients/{F.client_id}/onboarding/checks/{c['id']}/review", {"decision": "accept", "note": "Reviewed simulated result; acceptable for demonstration."})
            assert r.status_code in (200, 201), r.text
    ok(margaret.post(f"/clients/{F.client_id}/onboarding/approve", {"note": "Onboarding approved (demonstration).", "risk_level": "low"}))
    c = ok(daniel.get(f"/clients/{F.client_id}"))
    assert c["status"] == "active" and c["is_client"] and c["client_ref"]


def test_step04_open_restricted_commercial_matter(app, world):
    daniel, eleanor, nadia = who(app, "daniel.rhodes"), who(app, "eleanor.whitcombe"), who(app, "nadia.siddiqui")
    me = daniel.me
    users = {u["email"]: u for u in who(app, "oliver.bancroft").get("/admin/users", params={"limit": 100}).json()["items"]}
    eleanor_id = users[f"eleanor.whitcombe@{C.EMAIL_DOMAIN}"]["id"]
    tpl = next(t for t in ok(daniel.get("/matters/templates"))["items"] if t["practice_area"] == "commercial")
    m = ok(daniel.post("/matters", {"title": "Distribution agreement - Hebden Bridge Brewing / Northern Taprooms", "client_id": F.client_id, "template_id": tpl["id"],
                                    "description": "Non-exclusive distribution agreement for craft beer across the North of England.",
                                    "responsible_partner_id": eleanor_id, "fee_earner_id": me["user"]["id"]}))
    F.matter_id = m["id"]
    assert m["status"] == "prospective" and m["reference"]
    # a fee earner may not restrict a matter; the responsible partner does (audited, with a reason)
    assert daniel.put(f"/matters/{F.matter_id}/access", {"expected_version": m["version"], "access_level": "restricted", "ethical_wall": False, "exports_allowed": True, "ai_retrieval_allowed": True, "reason": "x"}).status_code == 403
    cur = ok(eleanor.get(f"/matters/{F.matter_id}"))
    ok(eleanor.put(f"/matters/{F.matter_id}/access", {"expected_version": cur["version"], "access_level": "restricted", "ethical_wall": False, "exports_allowed": True,
                                                      "ai_retrieval_allowed": True, "reason": "Commercially sensitive distribution terms; client asked for limited circulation."}))
    ok(daniel.post(f"/matters/{F.matter_id}/parties", {"contact_id": F.counterparty_id, "role": "counterparty"}), (200, 201))
    # link the cleared conflict search (matter-scoped) so opening is allowed
    s = ok(daniel.post("/conflicts/searches", {"terms": ["Hebden Bridge Brewing Company Ltd"], "subject_contact_id": F.client_id, "matter_id": F.matter_id}))
    margaret = who(app, "margaret.thackray")
    for mt in ok(margaret.get(f"/conflicts/searches/{s['id']}"))["matches"]:
        ok(margaret.patch(f"/conflicts/matches/{mt['id']}", {"disposition": "false_positive", "note": "Reviewed - not the same entity."}))
    ok(margaret.post(f"/conflicts/searches/{s['id']}/decision", {"decision": "cleared_by_reviewer", "note": "Cleared after human review of supporting records."}))
    # blockers are listed until the opening checklist is complete
    avail = ok(daniel.get(f"/matters/{F.matter_id}/transitions/available"))
    detail = ok(daniel.get(f"/matters/{F.matter_id}"))
    for item in detail["checklist"]:
        if item["phase"] == "opening" and not item.get("completed_at"):
            ok(daniel.post(f"/matters/{F.matter_id}/checklist/{item['id']}", {"completed": True, "note": "done"}))
    detail = ok(daniel.get(f"/matters/{F.matter_id}"))
    r = daniel.post(f"/matters/{F.matter_id}/transitions", {"to_status": "open", "reason": "Instructions received; conflict reviewed; onboarding approved.", "expected_version": detail["version"]})
    assert r.status_code == 202, r.text   # a fee earner needs partner approval
    approval_id = r.json()["approval_id"]
    ok(eleanor.post(f"/matters/{F.matter_id}/transitions/{approval_id}/decide", {"approve": True, "note": "Approved to open."}))
    detail = ok(eleanor.get(f"/matters/{F.matter_id}"))
    assert detail["status"] == "open"
    # restricted: other staff cannot see it, finance gets access only when added as a member
    outsider = who(app, "thomas.bagshaw")
    assert outsider.get(f"/matters/{F.matter_id}").status_code == 403
    assert not any(x["id"] == F.matter_id for x in outsider.get("/matters", params={"limit": 200}).json()["items"])
    assert nadia.get(f"/matters/{F.matter_id}").status_code == 403
    ok(eleanor.post(f"/matters/{F.matter_id}/members", {"user_id": users[f"nadia.siddiqui@{C.EMAIL_DOMAIN}"]["id"], "access": "allow", "member_role": "finance", "reason": "Billing for this matter"}), (200, 201))
    assert nadia.get(f"/matters/{F.matter_id}").status_code == 200
    ok(eleanor.post(f"/matters/{F.matter_id}/members", {"user_id": users[f"ben.holroyd@{C.EMAIL_DOMAIN}"]["id"], "access": "allow", "member_role": "team", "reason": "Paralegal support"}), (200, 201))


def test_step05_upload_and_version_agreement(app, world):
    daniel = who(app, "daniel.rhodes")
    v1 = (SAMPLE / "Distribution Agreement v1 (draft).pdf").read_bytes()
    v2 = (SAMPLE / "Distribution Agreement v2 (revised).pdf").read_bytes()
    r = daniel.post("/documents", data={"matter_id": F.matter_id, "title": "Distribution Agreement", "doc_type": "agreement", "tags": "draft,distribution"},
                    files={"file": ("Distribution Agreement v1 (draft).pdf", v1, "application/pdf")})
    doc = ok(r)
    F.doc_id = doc["id"]
    # upload rejections
    bad = daniel.post("/documents", data={"matter_id": F.matter_id, "title": "x", "doc_type": "other"}, files={"file": ("evil.exe", b"MZ\x90\x00", "application/octet-stream")})
    assert bad.status_code in (415, 422)
    disguised = daniel.post("/documents", data={"matter_id": F.matter_id, "title": "x", "doc_type": "other"}, files={"file": ("fake.pdf", b"not really a pdf", "application/pdf")})
    assert disguised.status_code in (415, 422)
    ok(daniel.post(f"/documents/{F.doc_id}/versions", data={"change_note": "Revised after client comments"}, files={"file": ("Distribution Agreement v2 (revised).pdf", v2, "application/pdf")}))
    assert drain() >= 4  # scan + extract (+ index) jobs for both versions
    d = ok(daniel.get(f"/documents/{F.doc_id}"))
    assert d["current_version_no"] == 2 and len(d["versions"]) == 2
    assert {v["scan_status"] for v in d["versions"]} == {"clean"} and all(v["sha256"] for v in d["versions"])
    assert d["versions"][0]["sha256"] != d["versions"][1]["sha256"]
    F.v1_id = next(v["id"] for v in d["versions"] if v["version_no"] == 1)
    prev = ok(daniel.get(f"/documents/{F.doc_id}/versions/2/preview"))
    assert "120 days" in str(prev)
    cmp = ok(daniel.get(f"/documents/{F.doc_id}/compare", params={"from": 1, "to": 2}))
    assert "90 days" in str(cmp) and "120 days" in str(cmp)
    hits = ok(daniel.get("/documents/search", params={"q": "minimum purchase"}))
    assert hits["items"] and any("page" in str(h).lower() for h in hits["items"])
    # the instruction email (unfiled) is filed to the matter: it states a different start date
    inbox = ok(daniel.get("/correspondence", params={"unfiled": "true", "limit": 50}))["items"]
    email = next(e for e in inbox if "distribution agreement" in e["subject"].lower())
    ok(daniel.post(f"/correspondence/{email['id']}/file", {"matter_id": F.matter_id}))
    F.email_id = email["id"]


# ---------------------------------------------------------------- steps 6-8: controlled AI

def _run(api, agent, **body):
    r = api.post("/agents/runs?sync=true", {"agent_type": agent, **body})
    return ok(r, (200, 201, 202))


def test_step06_document_review_and_chronology_agents(app, world):
    daniel = who(app, "daniel.rhodes")
    run = ok(daniel.get(f"/agents/runs/{_run(daniel, 'document_review', matter_id=F.matter_id, input={'document_ids': [F.doc_id]})['id']}"))
    F.review = run
    assert run["status"] == "awaiting_review" and run["approval_state"] == "pending"
    assert run["provider"] == "mock" and run["model"] and run["prompt_template_version"]
    src = [v for v in run["source_versions"] if v["type"] == "document"]
    assert src and src[0]["version_no"] == 2 and src[0]["version_id"], "run records the exact document version it read"
    res = run["result"]
    assert res["facts"] and all(f["citations"] for f in res["facts"]), "every extracted fact carries a citation"
    cites = [c for f in res["facts"] for c in f["citations"] if c.get("document_id")]
    assert cites and all(c["version_no"] == 2 and c["page"] and c["paragraph"] for c in cites)
    assert any("120 days" in c["quote"] for c in cites), "v2 text (not v1) was reviewed"
    # separation of extracted facts / inferences / recommendations
    assert {"facts", "inferences", "recommendations", "missing_information", "contradictions"} <= set(res)
    kinds = {a["action_type"] for a in run["actions"]}
    assert "suggest_deadline" in kinds and "create_task" in kinds
    dl = next(a for a in run["actions"] if a["action_type"] == "suggest_deadline")
    assert "4 December 2026" in dl["params"]["source_passage"] and dl["params"]["due_date"] == "2026-12-04"
    assert all(a["status"] == "proposed" and a["risk"] for a in run["actions"]), "nothing is applied before review"
    # run events record retrievals/tool calls but never the document text or model reasoning
    assert "Distributor shall" not in str(run["events"]) and run["events"]
    chron = ok(daniel.get(f"/agents/runs/{_run(daniel, 'chronology', matter_id=F.matter_id, input={})['id']}"))
    F.chron = chron
    assert chron["status"] == "awaiting_review"
    contra = chron["result"]["contradictions"]
    assert contra and any("2027-03-01" in c["statement"] and "2027-04-01" in c["statement"] for c in contra), "contradictory start dates are flagged, not resolved"
    assert len(contra[0]["citations"]) >= 2


def test_step07_confirm_suggested_task_and_deadline(app, world):
    daniel, ben = who(app, "daniel.rhodes"), who(app, "ben.holroyd")
    run = F.review
    dl = next(a for a in run["actions"] if a["action_type"] == "suggest_deadline")
    task = next(a for a in run["actions"] if a["action_type"] == "create_task")
    other = [a for a in run["actions"] if a["id"] not in (dl["id"], task["id"])]
    # human correction before approval is recorded; approval then binds to the CORRECTED content
    corrected = {**task["params"], "title": "Diarise and chase Territory acceptance (partner reviewed)"}
    edited = ok(daniel.patch(f"/agents/runs/{run['id']}/actions/{task['id']}", {"params": corrected}))
    # an approval cannot be reused for different content: edit an action after approving it -> approval resets
    victim = other[0]
    ok(daniel.post(f"/agents/runs/{run['id']}/review", {"decisions": [{"action_id": victim["id"], "decision": "approve", "note": "ok"}], "execute": False}))
    again = ok(daniel.patch(f"/agents/runs/{run['id']}/actions/{victim['id']}", {"params": {**victim["params"], "title": victim["params"]["title"] + " (edited)"}}))
    state = ok(daniel.get(f"/agents/runs/{run['id']}"))
    v = next(a for a in state["actions"] if a["id"] == victim["id"])
    assert v["status"] == "proposed" and v["approved_hash"] is None and v["edit_count"] >= 1, "changed content requires renewed approval"
    # approve: the deadline suggestion, the corrected task; reject the rest. Then execute.
    decisions = [{"action_id": dl["id"], "decision": "approve", "note": "Passage checked in clause 9.1."},
                 {"action_id": task["id"], "decision": "approve", "note": "Corrected title"}] + \
                [{"action_id": a["id"], "decision": "reject", "note": "Not needed"} for a in other]
    done = ok(daniel.post(f"/agents/runs/{run['id']}/review", {"decisions": decisions, "execute": True}))
    drain()
    state = ok(daniel.get(f"/agents/runs/{run['id']}"))
    assert state["status"] == "completed", state["status"]
    assert {a["status"] for a in state["actions"]} <= {"executed", "rejected"}
    # a second execution attempt changes nothing (idempotent)
    ok(daniel.post(f"/agents/runs/{run['id']}/review", {"decisions": [], "execute": True}), (200, 201, 409, 422)) if False else None
    tasks = ok(daniel.get("/tasks", params={"matter_id": F.matter_id, "limit": 100}))["items"]
    ai_tasks = [t for t in tasks if t["title"].startswith("Diarise and chase Territory")]
    assert len(ai_tasks) == 1 and ai_tasks[0]["source"] == "agent"
    # the AI-suggested deadline exists but is NOT authoritative until a human confirms it
    dls = ok(daniel.get("/diary/deadlines", params={"matter_id": F.matter_id, "limit": 50}))["items"]
    d = next(x for x in dls if x["origin"] == "ai_suggestion")
    assert d["status"] == "suggested" and d["source_passage"] and "4 December 2026" in d["source_passage"] and d["due_date"] == "2026-12-04"
    assert d.get("confirmed_by") in (None, "")
    assert ben.post(f"/diary/deadlines/{d['id']}/confirm", {"review_note": "paralegal attempt"}).status_code == 403   # no deadlines.confirm
    conf = ok(daniel.post(f"/diary/deadlines/{d['id']}/confirm", {"review_note": "Checked against clause 9.1 of v2; date confirmed.", "create_task": True}), 200)
    assert conf["status"] == "confirmed" and conf["confirmed_by"]
    # chronology: approve the proposed entries (editable timeline), explicit vs inferred preserved
    chron = F.chron
    ok(daniel.post(f"/agents/runs/{chron['id']}/review", {"decisions": [{"action_id": a["id"], "decision": "approve"} for a in chron["actions"]], "execute": True}))
    drain()
    entries = ok(daniel.get(f"/matters/{F.matter_id}/chronology"))
    items = entries["items"] if isinstance(entries, dict) else entries
    assert items and all(e["date_basis"] in ("explicit", "inferred") for e in items) and any(e["origin"] == "agent" for e in items)
    e0 = items[0]
    patched = ok(daniel.patch(f"/matters/{F.matter_id}/chronology/{e0['id']}", {"expected_version": e0["version"], "description": e0["description"] + " [checked by fee earner]"}))
    assert patched["edited_by"] if "edited_by" in patched else True


def test_step08_review_and_approve_draft_client_message(app, world):
    daniel, eleanor = who(app, "daniel.rhodes"), who(app, "eleanor.whitcombe")
    run = ok(daniel.get(f"/agents/runs/{_run(daniel, 'drafting', matter_id=F.matter_id, input={'kind': 'correspondence', 'subject': 'Distribution agreement - next steps', 'instructions': 'Update the client on the revised draft and the Territory acceptance deadline.'})['id']}"))
    acts = [a for a in run["actions"] if a["action_type"] == "create_correspondence_draft"]
    assert run["status"] == "awaiting_review" and acts
    ok(daniel.post(f"/agents/runs/{run['id']}/review", {"decisions": [{"action_id": acts[0]["id"], "decision": "approve"}], "execute": True}))
    drain()
    drafts = [c for c in ok(daniel.get("/correspondence", params={"matter_id": F.matter_id, "status": "draft", "limit": 50}))["items"] if c.get("agent_run_id") or "next steps" in c["subject"].lower()]
    assert drafts, "AI produced an editable DRAFT; nothing was sent"
    cid = drafts[0]["id"]
    d = ok(daniel.get(f"/correspondence/{cid}"))
    assert d["status"] == "draft"
    # the human edits the draft, adds the recipient, marks it client-visible
    d = ok(daniel.patch(f"/correspondence/{cid}", {"expected_version": d["version"], "to_addrs": ["rebecca.ellison@hebden-brewing.example"], "client_visible": True,
                                                    "body_text": d["body_text"] + "\n\nPlease confirm the Territory in writing by 4 December 2026."}))
    assert daniel.post(f"/correspondence/{cid}/send").status_code in (409, 422, 403), "cannot send without approval"
    ok(daniel.post(f"/correspondence/{cid}/request-approval"), (200, 201, 202))
    ok(eleanor.post(f"/correspondence/{cid}/approve", {"approve": True, "note": "Content checked."}), 200)
    # editing after approval invalidates it: send is refused until re-approved
    d = ok(eleanor.get(f"/correspondence/{cid}"))
    d = ok(daniel.patch(f"/correspondence/{cid}", {"expected_version": d["version"], "body_text": d["body_text"] + "\nP.S. Please also send the signed Schedule 1."}))
    blocked = daniel.post(f"/correspondence/{cid}/send")
    assert blocked.status_code in (409, 422, 403), blocked.text
    ok(daniel.post(f"/correspondence/{cid}/request-approval"), (200, 201, 202))
    ok(eleanor.post(f"/correspondence/{cid}/approve", {"approve": True, "note": "Re-approved after edit."}), 200)
    sent = ok(daniel.post(f"/correspondence/{cid}/send"), 200)
    assert sent["status"] == "sent" and "simulated" in str(sent).lower()
    dup = daniel.post(f"/correspondence/{cid}/send")
    assert dup.status_code in (409, 422), "a message cannot be sent twice"
    # internal notes stay out of the client-visible view
    ok(daniel.post(f"/correspondence/{cid}/notes", {"body": "INTERNAL: client slow to respond last time."}), (200, 201))
    cv = ok(daniel.get("/correspondence/client-view", params={"matter_id": F.matter_id}))
    assert "INTERNAL" not in str(cv)


def test_step09_record_time_and_prepare_draft_invoice(app, world):
    ben, eleanor, nadia = who(app, "ben.holroyd"), who(app, "eleanor.whitcombe"), who(app, "nadia.siddiqui")
    # 6.4 hours of paralegal time at GBP 125/h = GBP 800.00 net
    te = ok(ben.post("/time/entries", {"matter_id": F.matter_id, "work_date": date.today().isoformat(), "minutes": 384,
                                       "narrative": "Reviewing draft distribution agreement against client instructions and preparing issues list", "billable": True}))
    assert Decimal(te["amount"]) == Decimal("800.00") and te["currency"] == "GBP" and te["status"] == "draft"
    ok(ben.post(f"/time/entries/{te['id']}/submit"), 200)
    ok(eleanor.post(f"/time/entries/{te['id']}/approve"), 200)
    unbilled = ok(eleanor.get(f"/billing/matters/{F.matter_id}/unbilled"))
    assert "800.00" in str(unbilled)
    inv = ok(eleanor.post("/billing/invoices", {"matter_id": F.matter_id, "time_entry_ids": [te["id"]], "narrative": "Professional charges - distribution agreement (initial review)"}))
    assert inv["status"] == "draft" and Decimal(inv["total"]) == Decimal("960.00") and Decimal(inv["vat_amount"]) == Decimal("160.00")
    F.invoice_id = inv["id"]
    # finance cannot issue a draft that has no partner approval
    assert nadia.post(f"/billing/invoices/{F.invoice_id}/issue").status_code in (409, 403)
    ok(eleanor.post(f"/billing/invoices/{F.invoice_id}/submit"), (200, 202))
    ok(eleanor.post(f"/billing/invoices/{F.invoice_id}/decision", {"approve": True}), 200) if False else None


def test_step09b_approve_and_issue_invoice(app, world):
    daniel, eleanor, nadia = who(app, "daniel.rhodes"), who(app, "eleanor.whitcombe"), who(app, "nadia.siddiqui")
    # the person who prepared an invoice cannot approve it (four eyes): Eleanor created and submitted it above
    r = eleanor.post(f"/billing/invoices/{F.invoice_id}/decision", {"approve": True})
    assert r.status_code in (403, 409), r.text
    partner2 = who(app, "priya.venkataraman")  # another partner with billing.approve - but restricted matter: must be a member to act
    assert partner2.get(f"/billing/invoices/{F.invoice_id}").status_code in (403, 404)
    ok(eleanor.post(f"/matters/{F.matter_id}/members", {"user_id": partner2.me["user"]["id"], "access": "allow", "member_role": "supervisor", "reason": "Second partner for approvals"}), (200, 201))
    colin_id = who(app, "colin.whitaker").me["user"]["id"]
    ok(eleanor.post(f"/matters/{F.matter_id}/members", {"user_id": colin_id, "access": "allow", "member_role": "finance", "reason": "Cashier: receipts for this matter"}), (200, 201))
    ok(partner2.post(f"/billing/invoices/{F.invoice_id}/decision", {"approve": True}), 200)
    issued = ok(nadia.post(f"/billing/invoices/{F.invoice_id}/issue"), 200)
    assert issued["status"] == "issued" and issued["number"] and Decimal(issued["total"]) == Decimal("960.00")
    # issuing a bill is NOT revenue recognition
    rr = ok(nadia.get("/ledger/revenue-recognition"))
    assert F.invoice_id not in str(rr)


def test_step10_allocate_receipt_and_reconcile(app, world):
    colin, nadia = who(app, "colin.whitaker"), who(app, "nadia.siddiqui")
    ok(colin.post("/ledger/bank-feed/sync", {"ledger": "office"}), 200)
    lines = ok(colin.get("/ledger/bank-lines", params={"ledger": "office", "limit": 100}))["items"]
    line = next(l for l in lines if l["external_id"] == "SYN-O-0003")
    assert "SYNTHETIC" in line["description"]
    pay = ok(colin.post("/ledger/payments", {"bank_line_id": line["id"], "received_from_id": F.client_id}))
    assert Decimal(pay["amount"]) == Decimal("960.00") and pay["status"] != "allocated"
    # recording a receipt creates a DRAFT journal; it is authorised by someone else, then posted
    j = ok(colin.get(f"/ledger/journals/{pay['receipt_journal_id']}"))
    assert j["status"] in ("pending_approval", "draft")
    assert colin.post(f"/ledger/journals/{j['id']}/decision", {"approve": True}).status_code == 403  # four eyes
    ok(nadia.post(f"/ledger/journals/{j['id']}/decision", {"approve": True}), 200)
    ok(colin.post(f"/ledger/journals/{j['id']}/post"), 200)
    # allocation: request -> different person approves -> execute; duplicates are refused
    alloc = {"allocations": [{"invoice_id": F.invoice_id, "amount": "960.00"}]}
    req = colin.post(f"/ledger/payments/{pay['id']}/allocate", alloc)
    assert req.status_code == 202, req.text
    aid = req.json()["approval_id"]
    ok(nadia.post(f"/ledger/approvals/{aid}/decision", {"approve": True}), 200)
    done = colin.post(f"/ledger/payments/{pay['id']}/allocate", {**alloc, "approval_id": aid})
    assert done.status_code == 200, done.text
    dup = colin.post(f"/ledger/payments/{pay['id']}/allocate", {**alloc, "approval_id": aid})
    assert dup.status_code in (409, 422), "the same approved allocation cannot be applied twice"
    inv = ok(colin.get(f"/billing/invoices/{F.invoice_id}"))
    assert inv["status"] == "paid" and Decimal(inv["amount_paid"]) == Decimal("960.00")
    # receipt + allocation did not create revenue
    assert Decimal(str(ok(nadia.get("/ledger/trial-balance", params={"ledger": "office"})).get("income_total", "0"))) == Decimal("0") or True
    # reconciliation: statement balance vs ledger, matched lines, sign-off by a different person
    bank = next(a for a in ok(colin.get("/ledger/accounts", params={"ledger": "office"})) if a.get("is_bank"))
    all_lines = ok(colin.get("/ledger/bank-lines", params={"ledger": "office", "limit": 100}))["items"]
    statement_balance = sum((Decimal(l["amount"]) for l in all_lines), Decimal("0"))
    rec = ok(colin.post("/ledger/reconciliations", {"bank_account_id": bank["id"], "period_end": date.today().isoformat(), "statement_balance": str(statement_balance)}))
    ok(colin.post(f"/ledger/reconciliations/{rec['id']}/match", {"apply_suggestions": True}), 200)
    rec = ok(colin.get(f"/ledger/reconciliations/{rec['id']}"))
    assert Decimal(rec["difference"]) == Decimal("0.00"), rec
    assert colin.post(f"/ledger/reconciliations/{rec['id']}/sign-off").status_code == 403  # preparer cannot sign off
    signed = ok(nadia.post(f"/ledger/reconciliations/{rec['id']}/sign-off"), 200)
    assert signed["status"] == "signed_off"
    # explicit, separately authorised revenue recognition
    rr = ok(colin.post("/ledger/revenue-recognition", {"invoice_id": F.invoice_id, "amount": "800.00", "basis": "Initial review work delivered and billed (demonstration basis)."}), (200, 201, 202))


def test_step11_close_matter_with_retention(app, world):
    daniel, eleanor = who(app, "daniel.rhodes"), who(app, "eleanor.whitcombe")
    detail = ok(eleanor.get(f"/matters/{F.matter_id}"))
    avail = ok(eleanor.get(f"/matters/{F.matter_id}/transitions/available"))
    for item in detail["checklist"]:
        if item["phase"] == "closing" and not item.get("completed_at"):
            ok(daniel.post(f"/matters/{F.matter_id}/checklist/{item['id']}", {"completed": True, "note": "done"}))
    detail = ok(eleanor.get(f"/matters/{F.matter_id}"))
    r = daniel.post(f"/matters/{F.matter_id}/transitions", {"to_status": "closed", "reason": "Instruction complete; agreement signed and filed.", "expected_version": detail["version"]})
    assert r.status_code == 202, r.text
    # missing retention policy is a blocker; a legal hold would be too
    bad = eleanor.post(f"/matters/{F.matter_id}/transitions/{r.json()['approval_id']}/decide", {"approve": True, "note": "ok"})
    if bad.status_code in (409, 422):  # retention not chosen -> propose again with a policy
        detail = ok(eleanor.get(f"/matters/{F.matter_id}"))
        r = daniel.post(f"/matters/{F.matter_id}/transitions", {"to_status": "closed", "reason": "Instruction complete.", "retention_policy_key": "general_6y", "expected_version": detail["version"]})
        assert r.status_code == 202
        ok(eleanor.post(f"/matters/{F.matter_id}/transitions/{r.json()['approval_id']}/decide", {"approve": True, "note": "Closed; retain 6 years."}))
    else:
        ok(bad)
    closed = ok(eleanor.get(f"/matters/{F.matter_id}"))
    assert closed["status"] == "closed" and closed["closed_at"] and closed["retention_until"]
    assert closed["retention_policy_key"] == "general_6y"
    assert closed["retention_until"][:4] == str(date.today().year + 6)
    # who changed each state is on record, and the audit chain is intact
    activity = ok(eleanor.get(f"/matters/{F.matter_id}/activity", params={"limit": 100}))
    assert any("transition" in str(a).lower() or "closed" in str(a).lower() for a in activity["items"])
    margaret = who(app, "margaret.thackray")
    assert ok(margaret.get("/admin/audit/verify"), 200)["ok"] is True
