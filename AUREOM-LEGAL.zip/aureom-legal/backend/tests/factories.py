"""Test data factories (run with the owner connection) and an API client wrapper with CSRF handling."""
from __future__ import annotations

import uuid
from datetime import date

from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Contact, Firm, Matter, MatterMember, Office, Role, Team, User
from app.security import hash_password
from app.services.bootstrap import create_firm, load_default_holidays

PASSWORD = "Test-Passw0rd!"
_PW_HASH = hash_password(PASSWORD)


def make_firm(db: Session, name: str | None = None) -> Firm:
    slug = f"firm-{uuid.uuid4().hex[:8]}"
    firm = create_firm(db, name=name or f"Firm {slug}", slug=slug, offices=[("Leeds", "Leeds"), ("Manchester", "Manchester")])
    load_default_holidays(db, firm.id)
    try:  # finance chart of accounts, if the finance module is present
        from app.services.ledger import ensure_chart_of_accounts
        ensure_chart_of_accounts(db, firm.id)
    except ModuleNotFoundError:
        pass
    db.commit()
    return firm


def make_team(db: Session, firm: Firm, name: str, practice_area: str | None = None) -> Team:
    t = Team(firm_id=firm.id, name=name, practice_area=practice_area)
    db.add(t); db.commit()
    return t


def make_user(db: Session, firm: Firm, role_key: str = "solicitor", name: str | None = None, team: Team | None = None,
              office: Office | None = None, contact: Contact | None = None, grade: str | None = None) -> User:
    role = db.execute(select(Role).where(Role.firm_id == firm.id, Role.key == role_key)).scalar_one()
    office = office or db.execute(select(Office).where(Office.firm_id == firm.id).order_by(Office.name)).scalars().first()
    uid = uuid.uuid4().hex[:6]
    name = name or f"{role_key.title()} {uid}"
    u = User(firm_id=firm.id, email=f"{uid}.{role_key}@test.example", name=name, initials="".join(w[0] for w in name.split()[:2]).upper(),
             password_hash=_PW_HASH, role_id=role.id, office_id=office.id if office else None, team_id=team.id if team else None,
             contact_id=contact.id if contact else None, grade=grade or {"partner": "partner", "solicitor": "solicitor", "paralegal": "paralegal"}.get(role_key))
    db.add(u); db.commit()
    return u


def make_contact(db: Session, firm: Firm, name: str, kind: str = "individual", **kw) -> Contact:
    c = Contact(firm_id=firm.id, kind=kind, display_name=name, **kw)
    if kind == "individual" and " " in name and "first_name" not in kw:
        c.first_name, c.last_name = name.split(" ", 1)[0], name.split(" ", 1)[1]
    if kind == "organisation":
        c.org_name = kw.get("org_name", name)
    db.add(c); db.commit()
    return c


def make_matter(db: Session, firm: Firm, client: Contact, partner: User, fee_earner: User | None = None, *, status: str = "open",
                access_level: str = "standard", reference: str | None = None, title: str = "Test matter", practice_area: str = "commercial",
                members: list[User] | None = None, **kw) -> Matter:
    office = db.execute(select(Office).where(Office.firm_id == firm.id)).scalars().first()
    m = Matter(firm_id=firm.id, reference=reference or f"M-{uuid.uuid4().hex[:6].upper()}", title=title, matter_type=kw.pop("matter_type", "General"),
               practice_area=practice_area, client_id=client.id, office_id=office.id, responsible_partner_id=partner.id,
               fee_earner_id=(fee_earner or partner).id, status=status, access_level=access_level,
               opened_at=date.today() if status != "prospective" else None, **kw)
    db.add(m); db.flush()
    for u in members or []:
        db.add(MatterMember(firm_id=firm.id, matter_id=m.id, user_id=u.id, access="allow"))
    db.commit()
    return m


class Api:
    """Cookie-session API client that injects the CSRF header automatically."""

    def __init__(self, app, prefix: str = "/api/v1"):
        self.c = TestClient(app, raise_server_exceptions=False)
        self.prefix, self.csrf, self.me = prefix, None, None

    def login(self, user_or_email, password: str = PASSWORD) -> "Api":
        email = getattr(user_or_email, "email", user_or_email)
        r = self.c.post(f"{self.prefix}/auth/login", json={"email": email, "password": password})
        assert r.status_code == 200, r.text
        self.me = r.json(); self.csrf = self.me["csrf_token"]
        return self

    def _h(self):
        return {"X-CSRF-Token": self.csrf} if self.csrf else {}

    def get(self, path, **kw): return self.c.get(self.prefix + path, **kw)
    def post(self, path, json=None, **kw): return self.c.post(self.prefix + path, json=json, headers=self._h(), **kw)
    def put(self, path, json=None, **kw): return self.c.put(self.prefix + path, json=json, headers=self._h(), **kw)
    def patch(self, path, json=None, **kw): return self.c.patch(self.prefix + path, json=json, headers=self._h(), **kw)
    def delete(self, path, **kw): return self.c.delete(self.prefix + path, headers=self._h(), **kw)


def api_for(app, user) -> Api:
    return Api(app).login(user)
