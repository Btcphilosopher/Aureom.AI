"""Core: authentication, CSRF, tenant isolation (app + row-level security), audit immutability."""
import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError, ProgrammingError

from app import audit
from app.db.session import new_session
from app.deps import Ctx
from app.models import AuditEvent, Contact
from tests.factories import Api, api_for, make_contact, make_firm, make_user, PASSWORD


def test_login_csrf_and_me(app, db):
    firm = make_firm(db); u = make_user(db, firm, "solicitor")
    a = Api(app)
    assert a.get("/auth/me").status_code == 401
    assert a.c.post("/api/v1/auth/login", json={"email": u.email, "password": "wrong"}).status_code == 401
    a.login(u)
    me = a.get("/auth/me").json()
    assert me["role"]["key"] == "solicitor" and "matters.read" in me["permissions"] and "ledger.post" not in me["permissions"]
    # unsafe method without CSRF header is refused
    r = a.c.post("/api/v1/auth/office", json={"office_id": None})
    assert r.status_code == 403 and r.json()["error"]["code"] == "csrf_failed"
    assert a.post("/auth/logout").status_code == 200
    assert a.get("/auth/me").status_code == 401


def test_account_lockout(app, db):
    firm = make_firm(db); u = make_user(db, firm, "paralegal")
    a = Api(app)
    for _ in range(5):
        a.c.post("/api/v1/auth/login", json={"email": u.email, "password": "nope"})
    r = a.c.post("/api/v1/auth/login", json={"email": u.email, "password": PASSWORD})
    assert r.status_code == 401 and r.json()["error"]["code"] == "account_locked"


def test_rls_blocks_cross_firm_rows_even_without_where_clause(db):
    f1, f2 = make_firm(db), make_firm(db)
    make_contact(db, f1, "Alice Alpha"); make_contact(db, f2, "Bob Beta")
    with new_session(f1.id) as s:  # app role, bound to firm 1 - no WHERE clause at all
        names = {c.display_name for c in s.execute(select(Contact)).scalars()}
        assert "Alice Alpha" in names and "Bob Beta" not in names
    with new_session() as s:  # no tenant bound -> sees nothing
        assert s.execute(select(Contact)).scalars().all() == []
    with new_session(f1.id) as s:  # cannot write a row into another tenant
        s.add(Contact(firm_id=f2.id, kind="individual", display_name="Intruder"))
        with pytest.raises(DBAPIError):
            s.flush()


def test_audit_chain_and_immutability(db):
    firm = make_firm(db); u = make_user(db, firm, "partner")
    with new_session(firm.id) as s:
        ctx = Ctx.for_user(s, u)
        for i in range(3):
            ctx.audit("test.event", "thing", None, f"event {i}", details={"body": "SECRET TEXT", "n": i})
        s.commit()
    with new_session(firm.id) as s:
        evs = s.execute(select(AuditEvent).where(AuditEvent.action == "test.event")).scalars().all()
        assert all(e.details["body"] == "[redacted]" for e in evs)
        assert audit.verify_chain(s, firm.id)["ok"]
        with pytest.raises(DBAPIError):  # app role cannot update or delete audit rows
            s.execute(text("update audit_events set summary='x'")); s.flush()
    with pytest.raises(DBAPIError):  # even the table owner is blocked by the trigger
        db.execute(text("delete from audit_events where firm_id = :f"), {"f": firm.id}); db.flush()
    db.rollback()
