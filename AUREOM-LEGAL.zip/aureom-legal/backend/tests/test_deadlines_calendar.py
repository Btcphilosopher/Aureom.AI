"""Business calendar arithmetic and the deadline suggestion -> confirmation workflow."""
from datetime import date

import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError

from app.db.session import new_session
from app.deps import Ctx
from app.errors import ValidationFailed
from app.models import BusinessCalendar, Deadline, Task
from app.services import business_calendar as bc
from app.services import deadlines as dl
from tests.factories import api_for, make_contact, make_firm, make_matter, make_user


@pytest.fixture()
def world(db):
    firm = make_firm(db)  # default calendar with 25 & 28 Dec 2026 holidays
    dl.ensure_default_rules(db, firm.id)
    db.commit()
    partner = make_user(db, firm, "partner", "Penny Partner")
    sol = make_user(db, firm, "solicitor", "Sam Solicitor")
    other = make_user(db, firm, "solicitor", "Olive Other")
    para = make_user(db, firm, "paralegal", "Pat Para")
    client = make_contact(db, firm, "Acme Widgets Ltd", "organisation")
    std = make_matter(db, firm, client, partner, sol, title="Supply agreement")
    restricted = make_matter(db, firm, client, partner, sol, access_level="restricted", title="Restricted")
    return dict(firm=firm, partner=partner, sol=sol, other=other, para=para, std=std, restricted=restricted)


def _view(db, firm):
    cal = db.execute(select(BusinessCalendar).where(BusinessCalendar.firm_id == firm.id, BusinessCalendar.is_default)).scalar_one()
    return bc.load_view(db, cal)


# ------------------------------------------------------------ arithmetic
def test_business_day_arithmetic_weekends_and_bank_holidays(db, world):
    v = _view(db, world["firm"])
    assert v.is_business_day(date(2026, 12, 24)) and not v.is_business_day(date(2026, 12, 25)) and not v.is_business_day(date(2026, 12, 28))
    # across a weekend
    assert v.add_business_days(date(2026, 12, 4), 1)[0] == date(2026, 12, 7)
    # across Christmas: 25 (holiday), 26-27 (weekend), 28 (substitute holiday) skipped
    res, skipped = v.add_business_days(date(2026, 12, 23), 3)
    assert res == date(2026, 12, 30)
    assert [s["date"] for s in skipped] == ["2026-12-25", "2026-12-26", "2026-12-27", "2026-12-28"]
    assert "holiday: Christmas Day" in skipped[0]["reason"] and skipped[1]["reason"] == "weekend"
    # counting backwards
    assert v.add_business_days(date(2026, 12, 29), 1, "before")[0] == date(2026, 12, 24)
    assert v.next_business_day(date(2026, 12, 25))[0] == date(2026, 12, 29)
    assert v.next_business_day(date(2026, 12, 28), forward=False)[0] == date(2026, 12, 24)


def test_calendar_with_no_holiday_data_hardcodes_nothing(db, world):
    from tests.factories import make_firm as mf
    f2 = mf(db)
    cal = db.execute(select(BusinessCalendar).where(BusinessCalendar.firm_id == f2.id)).scalar_one()
    from app.models import CalendarHoliday
    db.query(CalendarHoliday).filter_by(calendar_id=cal.id).delete(); db.commit()
    v = bc.load_view(db, cal)
    assert v.is_business_day(date(2026, 12, 25))  # no holidays loaded => Christmas Day is just a Friday


def test_holiday_import_endpoint_changes_results(app, db, world):
    w = world
    cals = api_for(app, w["partner"]).get("/diary/calendars").json()
    cid = cals[0]["id"]
    assert cals[0]["holiday_count"] >= 2
    assert api_for(app, w["sol"]).post(f"/diary/calendars/{cid}/holidays/import", {"holidays": []}).status_code == 403  # solicitor: not config-level
    p = api_for(app, w["partner"])
    r = p.post(f"/diary/calendars/{cid}/holidays/import", {"holidays": [{"date": "2027-06-01", "name": "Test closure day"}, {"date": "2026-12-25", "name": "dup"}],
                                                           "source_note": "Supplied by office manager from the firm's closure list"})
    assert r.json() == {"added": 1, "skipped_existing": 1}
    v = _view(db, w["firm"])
    assert not v.is_business_day(date(2027, 6, 1))
    assert "closure list" in p.get("/diary/calendars").json()[0]["source_note"]
    # add/remove single holiday
    h = p.post(f"/diary/calendars/{cid}/holidays", {"date": "2027-07-01", "name": "x"}).json()
    assert p.post(f"/diary/calendars/{cid}/holidays", {"date": "2027-07-01", "name": "x"}).status_code == 422
    assert p.delete(f"/diary/calendars/{cid}/holidays/{h['id']}").status_code == 204
    assert p.post("/diary/calendars", {"name": "Scottish", "jurisdiction": "scotland", "timezone": "Not/AZone"}).status_code == 422


# ------------------------------------------------------------ calculate -> suggest
def _calc(api, w, rule="ack_14_calendar", trigger="2026-12-11", **kw):
    return api.post("/diary/deadlines/calculate", {"matter_id": str(w["std"].id), "rule_key": rule, "trigger_date": trigger, **kw})


def test_calculated_deadline_records_full_basis_and_is_not_authoritative(app, db, world):
    w = world
    r = _calc(api_for(app, w["sol"]), w)
    assert r.status_code == 201, r.text
    d = r.json()
    assert d["status"] == "suggested" and d["origin"] == "calculated_suggestion" and d["authoritative"] is False
    assert "Unconfirmed suggestion" in d["label"]
    # 11 Dec + 14 calendar days = 25 Dec (holiday) -> rolls over 25,26,27,28 -> 29 Dec
    assert d["due_date"] == "2026-12-29" and d["trigger_date"] == "2026-12-11"
    assert d["rule_key"] == "ack_14_calendar" and d["jurisdiction"] == "england_and_wales" and d["timezone"] == "Europe/London"
    assert "Illustrative" in d["assumptions"] and "Europe/London" in d["assumptions"] and d["calendar_name"].startswith("England")
    c = d["calculation"]
    assert c["inputs"]["offset_days"] == 14 and c["inputs"]["day_type"] == "calendar" and c["raw_date"] == "2026-12-25" and c["rolled_from"] == "2026-12-25"
    assert [s["date"] for s in c["skipped_days"]] == ["2026-12-25", "2026-12-26", "2026-12-27", "2026-12-28"] and len(c["steps"]) >= 2
    assert c["inputs"]["calendar"]["holiday_source"]
    assert d["suggested_by"] == str(w["sol"].id) and d["confirmed_by"] is None


def test_business_day_rule_and_errors(app, db, world):
    w = world
    a = api_for(app, w["sol"])
    d = _calc(a, w, "notice_response_10_business", "2026-12-14").json()
    # 10 business days after Mon 14 Dec 2026: 15,16,17,18 (4), 21..24 (8), 29, 30 (10)
    assert d["due_date"] == "2026-12-30"
    before = _calc(a, w, "notice_30_before", "2027-02-01").json()
    # 1 Feb 2027 - 30 calendar days = Sat 2 Jan; rolls BACK past the 1 Jan holiday to Thu 31 Dec 2026
    assert before["due_date"] == "2026-12-31"
    assert a.post("/diary/deadlines/calculate", {"matter_id": str(w["std"].id), "rule_key": "nope", "trigger_date": "2026-12-14"}).status_code == 404
    assert _calc(a, w, calendar_id="00000000-0000-0000-0000-000000000000").status_code == 404


def test_suggestion_cannot_be_authoritative_without_human_confirmation(app, db, world):
    w = world
    d = _calc(api_for(app, w["sol"]), w).json()
    # database-level guarantee: confirmed status needs a confirming user
    with pytest.raises(IntegrityError):
        db.execute(text("update deadlines set status='confirmed' where id=:i"), {"i": d["id"]})
        db.flush()
    db.rollback()
    # paralegal (no deadlines.confirm) cannot confirm or reject
    p = api_for(app, w["para"])
    assert p.post(f"/diary/deadlines/{d['id']}/confirm", {}).status_code == 403
    assert p.post(f"/diary/deadlines/{d['id']}/reject", {"review_note": "no"}).status_code == 403
    assert p.get(f"/diary/deadlines/{d['id']}").json()["authoritative"] is False
    # a fee earner confirms
    r = api_for(app, w["other"]).post(f"/diary/deadlines/{d['id']}/confirm", {"review_note": "Checked against the contract notice clause"})
    assert r.status_code == 200
    c = r.json()
    assert c["status"] == "confirmed" and c["authoritative"] and c["confirmed_by"] == str(w["other"].id) and c["reviewer_id"] == str(w["other"].id)
    assert c["confirmed_by_name"] == "Olive Other" and "Authoritative" in c["label"] and c["calculation"]["steps"]  # calculation preserved
    assert api_for(app, w["sol"]).post(f"/diary/deadlines/{d['id']}/confirm", {}).status_code == 409  # not twice


def test_confirm_with_adjustment_requires_reason_and_can_create_task(app, db, world):
    w = world
    s = api_for(app, w["sol"])
    d = _calc(s, w).json()
    r = s.post(f"/diary/deadlines/{d['id']}/confirm", {"adjusted_due_date": "2026-12-23"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "adjustment_reason_required"
    r = s.post(f"/diary/deadlines/{d['id']}/confirm", {"adjusted_due_date": "2026-12-23", "adjustment_reason": "Contract says business days before Christmas close", "create_task": True})
    assert r.status_code == 200
    out = r.json()
    assert out["due_date"] == "2026-12-23" and out["calculation"]["adjustment"]["from"] == "2026-12-29" and out["calculation"]["inputs"]["offset_days"] == 14
    tasks = s.get(f"/tasks?matter_id={w['std'].id}").json()["items"]
    linked = [t for t in tasks if t["deadline_id"] == d["id"]]
    assert len(linked) == 1 and linked[0]["priority"] == "high" and linked[0]["assignee_id"] == str(w["sol"].id)


def test_reject_flow(app, db, world):
    w = world
    d = _calc(api_for(app, w["sol"]), w).json()
    s = api_for(app, w["sol"])
    assert s.post(f"/diary/deadlines/{d['id']}/reject", {"review_note": "x"}).status_code == 422  # note required (min 3)
    r = s.post(f"/diary/deadlines/{d['id']}/reject", {"review_note": "Wrong trigger event"})
    assert r.status_code == 200 and r.json()["status"] == "rejected" and r.json()["authoritative"] is False
    assert s.post(f"/diary/deadlines/{d['id']}/confirm", {}).status_code == 409
    assert s.patch(f"/diary/deadlines/{d['id']}", {"expected_version": r.json()["version"], "title": "x"}).status_code == 409


def test_ai_origin_deadline_requires_supporting_passage(app, db, world):
    w = world
    with new_session(w["firm"].id) as sess:
        ctx = Ctx.for_user(sess, w["sol"])
        with pytest.raises(ValidationFailed):  # the helper refuses an AI suggestion with no passage
            dl.create_suggestion(ctx, matter_id=w["std"].id, title="Pay deposit", due_date=date(2027, 1, 15), origin="ai_suggestion")
        ok = dl.create_suggestion(ctx, matter_id=w["std"].id, title="Pay deposit", due_date=date(2027, 1, 15), origin="ai_suggestion",
                                  source_passage="The Buyer shall pay the deposit within 10 Business Days of exchange.", source_ref={"page": 2, "paragraph": 4, "version_no": 1})
        sess.commit()
        ok_id = ok.id
        # a row written by a faulty/other writer with an empty passage still cannot be confirmed
        bad = Deadline(firm_id=w["firm"].id, matter_id=w["std"].id, title="No evidence", due_date=date(2027, 2, 1), origin="ai_suggestion", status="suggested", source_passage="  ")
        sess.add(bad); sess.commit(); bad_id = bad.id
    s = api_for(app, w["sol"])
    r = s.post(f"/diary/deadlines/{bad_id}/confirm", {})
    assert r.status_code == 422 and r.json()["error"]["code"] == "passage_required"
    got = s.get(f"/diary/deadlines/{ok_id}").json()
    assert got["source_passage"].startswith("The Buyer shall pay") and got["source_ref"]["page"] == 2 and "AI-identified" in got["label"]
    assert s.post(f"/diary/deadlines/{ok_id}/confirm", {"review_note": "Matches clause 4.2"}).json()["status"] == "confirmed"


def test_manual_deadlines_and_permissions(app, db, world):
    w = world
    body = {"matter_id": str(w["std"].id), "title": "Exchange of contracts", "due_date": "2027-01-20", "due_time": "17:00:00", "assumptions": "Per client instruction"}
    d = api_for(app, w["sol"]).post("/diary/deadlines", body).json()
    assert d["origin"] == "manual" and d["status"] == "confirmed" and d["authoritative"] and d["confirmed_by"] == str(w["sol"].id)
    # paralegal: entry is recorded but unconfirmed until a fee earner confirms it
    p = api_for(app, w["para"]).post("/diary/deadlines", {**body, "title": "Para entry"}).json()
    assert p["status"] == "suggested" and p["authoritative"] is False
    # confirmed deadline: changing the date needs confirm permission and a reason; met/missed likewise
    s = api_for(app, w["sol"])
    assert s.patch(f"/diary/deadlines/{d['id']}", {"expected_version": d["version"], "due_date": "2027-01-27"}).status_code == 422
    r = s.patch(f"/diary/deadlines/{d['id']}", {"expected_version": d["version"], "due_date": "2027-01-27", "reason": "Extension agreed by counterparty"})
    assert r.status_code == 200 and r.json()["calculation"]["changes"][0]["reason"].startswith("Extension")
    # optimistic concurrency
    assert s.patch(f"/diary/deadlines/{d['id']}", {"expected_version": d["version"], "title": "stale"}).status_code == 409
    assert api_for(app, w["para"]).patch(f"/diary/deadlines/{d['id']}", {"expected_version": r.json()["version"], "status": "met"}).status_code == 403
    assert s.patch(f"/diary/deadlines/{d['id']}", {"expected_version": r.json()["version"], "status": "met"}).json()["status"] == "met"


def test_deadline_visibility_filters_and_needs_attention(app, db, world):
    w = world
    s = api_for(app, w["sol"])
    s.post("/diary/deadlines", {"matter_id": str(w["restricted"].id), "title": "Secret deadline", "due_date": "2027-01-05"})
    sug = _calc(s, w).json()
    o = api_for(app, w["other"])  # not a member of the restricted matter
    assert [d["title"] for d in o.get("/diary/deadlines").json()["items"]] == [sug["title"]]
    assert o.post("/diary/deadlines", {"matter_id": str(w["restricted"].id), "title": "x", "due_date": "2027-01-05"}).status_code == 403
    items = s.get("/diary/deadlines?needs_attention=true").json()["items"]
    assert {i["title"] for i in items} >= {sug["title"]}
    assert s.get(f"/diary/deadlines?origin=calculated_suggestion&status=suggested&matter_id={w['std'].id}").json()["total"] == 1
    with new_session(w["firm"].id) as sess:
        ctx = Ctx.for_user(sess, w["other"])
        assert {d.title for d in dl.needs_attention(ctx, 30)} == {sug["title"]}
        ctx2 = Ctx.for_user(sess, w["sol"])
        assert "Secret deadline" in {d.title for d in dl.needs_attention(ctx2, 3650)}


def test_rules_crud_requires_config_permission(app, db, world):
    w = world
    p = api_for(app, w["partner"])
    r = p.post("/diary/deadline-rules", {"key": "custom_7", "name": "Custom 7 days", "offset_days": 7, "day_type": "calendar"})
    assert r.status_code == 201 and "Illustrative" in r.json()["source_note"]
    assert api_for(app, w["sol"]).post("/diary/deadline-rules", {"key": "x1", "name": "x", "offset_days": 1}).status_code == 403
    assert p.post("/diary/deadline-rules", {"key": "custom_7", "name": "dup", "offset_days": 7}).status_code == 422
    assert p.patch(f"/diary/deadline-rules/{r.json()['id']}", {"is_active": False}).json()["is_active"] is False
    assert _calc(api_for(app, w["sol"]), w, rule="custom_7").status_code == 404  # inactive rules are not usable
