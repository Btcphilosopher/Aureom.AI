"""Decimal arithmetic, balanced/immutable journals, four-eyes, client-money rules, agent prohibition."""
from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError

from app.errors import InvalidState, MatterAccessDenied, PermissionDenied, ValidationFailed, ApprovalRequired
from app.models import Journal, JournalLine, LedgerAccount
from app.money import q, time_amount, vat
from app.services import billing, ledger as led
from app.services.matter_finance import client_balance, unbilled_wip
from tests.factories import make_firm, make_matter
from tests.finance_world import World


@pytest.fixture()
def w(db):
    world = World(db)
    yield world
    world.close()


def test_decimal_rounding_half_up():
    assert time_amount(7, Decimal("250.00")) == Decimal("29.17")     # 29.1666…
    assert time_amount(1, Decimal("100.00")) == Decimal("1.67")      # 1.6666…
    assert time_amount(90, Decimal("200.00")) == Decimal("300.00")
    assert vat(Decimal("29.17"), Decimal("20")) == Decimal("5.83")   # 5.834
    assert vat(Decimal("0.25"), Decimal("10")) == Decimal("0.03")    # 0.025 rounds half-up
    assert isinstance(time_amount(6, Decimal("0.10")), Decimal)
    with pytest.raises(TypeError):
        from app.money import D
        D(1.1)  # floats are refused for money


def test_time_entry_uses_rate_card_and_decimal(w):
    te = billing.create_time_entry(w.ctx(w.solicitor), matter_id=w.matter.id, work_date=date.today(), minutes=7, narrative="Call with client")
    assert te.rate == Decimal("200.00") and te.amount == Decimal("23.33") and te.currency == "GBP"
    nb = billing.create_time_entry(w.ctx(w.solicitor), matter_id=w.matter.id, work_date=date.today(), minutes=30, narrative="Admin", billable=False)
    assert nb.amount == Decimal("0.00")


def test_chart_of_accounts_idempotent(w):
    before = w.s.execute(select(LedgerAccount).where(LedgerAccount.firm_id == w.firm.id)).scalars().all()
    led.ensure_chart_of_accounts(w.s, w.firm.id); w.commit()
    after = w.s.execute(select(LedgerAccount).where(LedgerAccount.firm_id == w.firm.id)).scalars().all()
    assert len(before) == len(after) == 8
    assert {a.ledger for a in after if a.system_key == "bank_client"} == {"client"}


def test_journal_validation_rules(w):
    c = w.ctx(w.fin_a)
    base = dict(ledger="office", reference="X", description="x", effective_date=date.today())
    with pytest.raises(ValidationFailed) as e:   # unbalanced
        led.create_journal(c, lines=[{"system_key": "bank_office", "debit": "100"}, {"system_key": "fee_income", "credit": "99.99"}], **base)
    assert e.value.code == "unbalanced_journal"
    with pytest.raises(ValidationFailed) as e:   # both sides on one line
        led.create_journal(c, lines=[{"system_key": "bank_office", "debit": "10", "credit": "10"}, {"system_key": "fee_income", "credit": "10"}], **base)
    assert e.value.code == "one_sided_line_required"
    with pytest.raises(ValidationFailed):        # a single line
        led.create_journal(c, lines=[{"system_key": "bank_office", "debit": "10"}], **base)
    with pytest.raises(ValidationFailed) as e:   # office + client funds mixed
        led.create_journal(c, lines=[{"system_key": "bank_office", "debit": "10"}, {"system_key": "bank_client", "credit": "10"}], **base)
    assert e.value.code == "ledger_mismatch"
    j = led.create_journal(c, lines=[{"system_key": "bank_office", "debit": "10"}, {"system_key": "fee_income", "credit": "10"}], **base)
    assert j.status == "draft"


def test_db_trigger_rejects_unbalanced_or_mixed_posting(w, owner_engine):
    """Independent of the service layer: the database itself refuses to post bad journals."""
    c = w.ctx(w.fin_a)
    j = led.create_journal(c, ledger="office", reference="T1", description="x", effective_date=date.today(),
                           lines=[{"system_key": "bank_office", "debit": "100"}, {"system_key": "fee_income", "credit": "100"}])
    w.commit()
    with owner_engine.begin() as conn:
        conn.execute(text("update journal_lines set credit = 90 where journal_id = :j and credit > 0"), {"j": j.id})
    with owner_engine.connect() as conn:
        with pytest.raises(DBAPIError) as e:
            conn.execute(text("update journals set status='posted', posted_by=:u, posted_at=now() where id=:j"), {"j": j.id, "u": w.fin_a.id})
        assert "unbalanced" in str(e.value)
        conn.rollback()
    # mixed ledger at DB level: client account line inside an office journal
    cj = led.create_journal(c, ledger="office", reference="T2", description="x", effective_date=date.today(),
                            lines=[{"system_key": "bank_office", "debit": "5"}, {"system_key": "fee_income", "credit": "5"}])
    w.commit()
    client_bank = led.system_account(w.s, w.firm.id, "bank_client", "client")
    with owner_engine.begin() as conn:
        conn.execute(text("update journal_lines set account_id=:a where journal_id=:j and credit>0"), {"a": client_bank.id, "j": cj.id})
    with owner_engine.connect() as conn:
        with pytest.raises(DBAPIError) as e:
            conn.execute(text("update journals set status='posted', posted_by=:u, posted_at=now() where id=:j"), {"j": cj.id, "u": w.fin_a.id})
        assert "mixes ledgers" in str(e.value)
        conn.rollback()


def test_posted_journal_is_immutable(w, owner_engine):
    jid = w.post_manual("office", [{"system_key": "bank_office", "debit": "250"}, {"system_key": "fee_income", "credit": "250"}])
    j = w.s.get(Journal, jid)
    assert j.status == "posted" and j.posted_by == w.fin_a.id
    with owner_engine.connect() as conn:
        for sql in ("update journal_lines set debit = 1 where journal_id = :j and debit > 0",
                    "delete from journal_lines where journal_id = :j",
                    "update journals set description = 'edited' where id = :j",
                    "delete from journals where id = :j"):
            with pytest.raises(DBAPIError):
                conn.execute(text(sql), {"j": jid})
            conn.rollback()
    # the app role cannot delete posted journals either
    with pytest.raises(DBAPIError):
        w.s.execute(text("delete from journals where id = :j"), {"j": jid})
    w.s.rollback()


def test_reversal_requires_its_own_authorisation(w):
    jid = w.post_manual("office", [{"system_key": "bank_office", "debit": "80"}, {"system_key": "fee_income", "credit": "80"}], reference="R1")
    rj = led.reverse_journal(w.ctx(w.fin_a), jid, "Posted in error")
    w.commit()
    assert rj.status == "pending_approval" and rj.source_type == "reversal"
    with pytest.raises(PermissionDenied):   # preparer is not the approver
        led.decide_approval(w.ctx(w.fin_a), rj.approval_id, approve=True)
    w.s.rollback()
    led.decide_approval(w.ctx(w.fin_b), rj.approval_id, approve=True); w.commit()
    led.post_journal(w.ctx(w.fin_a), rj.id); w.commit()
    assert w.s.get(Journal, jid).status == "reversed"
    bank = led.system_account(w.s, w.firm.id, "bank_office", "office")
    assert led.account_balance(w.s, bank) == Decimal("0.00")


def test_four_eyes_and_permissions_on_posting(w):
    c = w.ctx(w.fin_a)
    j = led.create_journal(c, ledger="office", reference="F1", description="x", effective_date=date.today(),
                           lines=[{"system_key": "bank_office", "debit": "10"}, {"system_key": "fee_income", "credit": "10"}], submit=True)
    w.commit()
    with pytest.raises(PermissionDenied) as e:                    # same person cannot approve
        led.decide_approval(w.ctx(w.fin_a), j.approval_id, approve=True)
    assert e.value.code == "four_eyes_required"; w.s.rollback()
    with pytest.raises(PermissionDenied):                         # a partner lacks ledger.approve
        led.decide_approval(w.ctx(w.partner), j.approval_id, approve=True)
    w.s.rollback()
    with pytest.raises(ApprovalRequired):                         # cannot post while pending
        led.post_journal(w.ctx(w.fin_a), j.id)
    w.s.rollback()
    with pytest.raises(PermissionDenied):                         # a fee earner cannot create journals
        led.create_journal(w.ctx(w.solicitor), ledger="office", reference="no", description="x", effective_date=date.today(),
                           lines=[{"system_key": "bank_office", "debit": "1"}, {"system_key": "fee_income", "credit": "1"}])
    w.s.rollback()


def test_approval_binds_to_exact_lines(w, owner_engine):
    c = w.ctx(w.fin_a)
    j = led.create_journal(c, ledger="office", reference="B1", description="x", effective_date=date.today(),
                           lines=[{"system_key": "bank_office", "debit": "100"}, {"system_key": "fee_income", "credit": "100"}], submit=True)
    w.commit()
    led.decide_approval(w.ctx(w.fin_b), j.approval_id, approve=True); w.commit()
    with owner_engine.begin() as conn:  # tamper with the lines after approval (both sides so it still balances)
        conn.execute(text("update journal_lines set debit = 500 where journal_id = :j and debit > 0"), {"j": j.id})
        conn.execute(text("update journal_lines set credit = 500 where journal_id = :j and credit > 0"), {"j": j.id})
    with pytest.raises(ApprovalRequired) as e:
        led.post_journal(w.ctx(w.fin_a), j.id)
    assert e.value.code == "approval_stale"


def test_client_account_can_never_go_overdrawn(w):
    pid = w.record_and_post_receipt("client", matter=w.matter, amount_index=0)   # SYN-C-0001: 10,000.00
    assert client_balance(w.s, w.matter.id) == Decimal("10000.00")
    acct = led.client_account_for_matter(w.ctx(w.fin_a), w.matter.id)
    lines = [{"account_id": acct.id, "debit": "10000.01"}, {"system_key": "bank_client", "credit": "10000.01"}]
    j = led.create_journal(w.ctx(w.fin_a), ledger="client", reference="OD", description="over", effective_date=date.today(), lines=lines, matter_id=w.matter.id, submit=True)
    w.commit()
    led.decide_approval(w.ctx(w.fin_b), j.approval_id, approve=True); w.commit()
    with pytest.raises(InvalidState) as e:
        led.post_journal(w.ctx(w.fin_a), j.id)
    assert e.value.code == "client_account_overdrawn"
    w.s.rollback()
    assert client_balance(w.s, w.matter.id) == Decimal("10000.00")


def test_agents_and_automation_cannot_post_or_approve(w):
    agent_ctx = w.ctx(w.fin_a)
    agent_ctx.actor_type = "agent"
    with pytest.raises(PermissionDenied) as e:
        led.create_journal(agent_ctx, ledger="office", reference="A", description="x", effective_date=date.today(),
                           lines=[{"system_key": "bank_office", "debit": "1"}, {"system_key": "fee_income", "credit": "1"}])
    assert e.value.code == "human_authorisation_required"
    inv_id = w.billed_invoice()
    for fn in (lambda: led.request_client_transfer(agent_ctx, inv_id, Decimal("1")), lambda: billing.issue_invoice(agent_ctx, inv_id),
               lambda: led.decide_approval(agent_ctx, inv_id, approve=True), lambda: led.request_revenue_recognition(agent_ctx, inv_id, Decimal("1"), "basis text")):
        with pytest.raises(PermissionDenied):
            fn()
        w.s.rollback()


def test_restricted_matter_blocks_finance_without_membership(w, db):
    restricted = make_matter(db, w.firm, w.client, w.partner, w.solicitor, access_level="restricted", reference="RESTR-1", title="Secret deal")
    w.s.expire_all()
    with pytest.raises(MatterAccessDenied):
        billing.create_time_entry(w.ctx(w.fin_a), matter_id=restricted.id, work_date=date.today(), minutes=10, narrative="x")
    with pytest.raises(MatterAccessDenied):
        led.create_journal(w.ctx(w.fin_a), ledger="office", reference="R", description="x", effective_date=date.today(), matter_id=restricted.id,
                           lines=[{"system_key": "bank_office", "debit": "1"}, {"system_key": "fee_income", "credit": "1"}])
    w.s.rollback()


def test_matter_finance_helpers(w):
    billing.create_time_entry(w.ctx(w.solicitor), matter_id=w.matter.id, work_date=date.today(), minutes=60, narrative="a")
    billing.create_expense(w.ctx(w.solicitor), matter_id=w.matter.id, expense_date=date.today(), description="Search fee", amount=Decimal("12.50"))
    w.commit()
    wip = unbilled_wip(w.s, w.matter.id)
    assert wip["time"] == Decimal("200.00") and wip["expenses"] == Decimal("12.50") and wip["count"] == 2
