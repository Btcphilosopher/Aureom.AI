from app.models import MatterMember
from tests._pm_helpers import apis, setup_firm
from tests.factories import make_contact, make_firm, make_matter, make_user


def test_cross_firm_matter_is_404_and_lists_are_isolated(app, db):
    ns1, ns2 = setup_firm(db), setup_firm(db)
    a1, a2 = apis(app, ns1), apis(app, ns2)
    c = make_contact(db, ns1.firm, "Firm1 Client")
    m = make_matter(db, ns1.firm, c, ns1.partner, title="Firm one matter")
    assert a2.partner.get(f"/matters/{m.id}").status_code == 404
    assert a2.partner.patch(f"/matters/{m.id}", {"expected_version": 1, "title": "hacked"}).status_code == 404
    assert a2.partner.get(f"/matters/{m.id}/activity").status_code == 404
    assert a2.partner.get("/matters").json()["total"] == 0
    assert a1.partner.get("/matters").json()["total"] == 1


def test_restricted_matter_hidden_from_lists_counts_and_403_by_id(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c = make_contact(db, ns.firm, "Client")
    std = make_matter(db, ns.firm, c, ns.partner, title="Open to all", reference="STD-1")
    res = make_matter(db, ns.firm, c, ns.partner, title="Highly sensitive deal", reference="RES-1", access_level="restricted", members=[ns.sol])
    from app.models import MatterParty
    db.add_all([MatterParty(firm_id=ns.firm.id, matter_id=x.id, contact_id=c.id, role="client") for x in (std, res)]); db.commit()
    # outsider solicitor (not a member): excluded from list, total and search; 403 by id without leaking title
    lst = a.sol_b.get("/matters").json()
    assert lst["total"] == 1 and [i["reference"] for i in lst["items"]] == ["STD-1"]
    assert a.sol_b.get("/matters", params={"q": "sensitive"}).json()["total"] == 0
    r = a.sol_b.get(f"/matters/{res.id}")
    assert r.status_code == 403 and r.json()["error"]["code"] == "matter_access_denied" and "sensitive" not in r.text
    for path in ("/summary", "/activity", "/chronology", "/transitions/available"):
        assert a.sol_b.get(f"/matters/{res.id}{path}").status_code == 403
    assert a.sol_b.post(f"/matters/{res.id}/parties", {"contact_id": str(c.id), "role": "witness"}).status_code == 403
    # contact detail does not reveal the restricted matter either
    d = a.sol_b.get(f"/clients/{c.id}").json()
    assert [x["reference"] for x in d["matters"]] == ["STD-1"] and d["restricted_matters_hidden"] == 1
    # member, responsible partner and fee earner see it
    assert a.sol.get("/matters").json()["total"] == 2
    assert a.partner.get(f"/matters/{res.id}").status_code == 200
    assert a.sol.get(f"/matters/{res.id}").status_code == 200
    # roles lacking matters.read see nothing at all
    assert a.admin.get("/matters").status_code == 403


def test_ethical_wall_deny_beats_responsible_partner_and_team(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c = make_contact(db, ns.firm, "Walled Client")
    m = make_matter(db, ns.firm, c, ns.partner, fee_earner=ns.sol, title="Walled matter", reference="W-1", access_level="restricted", members=[ns.sol_b])
    assert a.partner.get(f"/matters/{m.id}").status_code == 200
    # only matters.access_admin can change the wall
    assert a.sol.post(f"/matters/{m.id}/members", {"user_id": str(ns.sol.id), "access": "deny", "reason": "wall"}).status_code == 403
    r = a.partner.put(f"/matters/{m.id}/access", {"expected_version": a.partner.get(f"/matters/{m.id}").json()["version"], "access_level": "restricted",
                                                   "ethical_wall": True, "exports_allowed": False, "ai_retrieval_allowed": False, "reason": "Information barrier"})
    assert r.status_code == 200 and r.json()["ethical_wall"] is True and r.json()["exports_allowed"] is False
    # deny the fee earner (explicitly allow-listed + fee earner) -> still blocked; deny the whole litigation team -> sol_b blocked
    assert a.partner.post(f"/matters/{m.id}/members", {"user_id": str(ns.sol.id), "access": "deny", "reason": "Acted for counterparty"}).status_code == 201
    assert a.partner.post(f"/matters/{m.id}/members", {"team_id": str(ns.team_b.id), "access": "deny", "reason": "Team barrier"}).status_code == 201
    assert a.sol.get(f"/matters/{m.id}").status_code == 403
    assert a.sol_b.get(f"/matters/{m.id}").status_code == 403
    assert a.sol.get("/matters").json()["total"] == 0
    # deny beats being the responsible partner too
    assert a.partner2.post(f"/matters/{m.id}/members", {"user_id": str(ns.partner.id), "access": "deny", "reason": "x" * 6}).status_code == 403  # partner2 cannot even see it
    mid = a.partner.get(f"/matters/{m.id}").json()
    deny_p = db.execute(__import__("sqlalchemy").select(MatterMember).where(MatterMember.matter_id == m.id)).scalars().all()
    assert len(deny_p) >= 3
    # audited with reason
    acts = a.partner.get(f"/matters/{m.id}/activity").json()["items"]
    assert any(i["action"] == "matter.access_changed" and i["details"].get("reason") == "Acted for counterparty" for i in acts)
    # wall requires restricted
    assert a.partner.put(f"/matters/{m.id}/access", {"expected_version": mid["version"], "access_level": "standard", "ethical_wall": True, "reason": "bad combo"}).status_code == 422
