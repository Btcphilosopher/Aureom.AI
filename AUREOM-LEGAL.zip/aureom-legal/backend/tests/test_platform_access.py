"""Platform-level access tests: global search, home dashboard, admin, portal, approvals."""
import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

import pytest

from app.models import Document, DocumentChunk, DocumentVersion, Invoice, MatterMember, Payment, Team
from tests.factories import Api, api_for, make_contact, make_firm, make_matter, make_team, make_user


def _doc(db, firm, matter, user, title, text, client_visible=False, doc_type="agreement", scan="clean"):
    d = Document(firm_id=firm.id, matter_id=matter.id, title=title, doc_type=doc_type, created_by=user.id, current_version_no=1, client_visible=client_visible, status="draft")
    db.add(d); db.flush()
    v = DocumentVersion(firm_id=firm.id, document_id=d.id, version_no=1, storage_key=f"k/{uuid.uuid4().hex}", sha256="a" * 64, size_bytes=len(text),
                        content_type="text/plain", original_filename=f"{title}.txt", author_id=user.id, scan_status=scan, ocr_status="not_needed", index_status="done")
    db.add(v); db.flush()
    d.current_version_id = v.id
    db.add(DocumentChunk(firm_id=firm.id, version_id=v.id, document_id=d.id, matter_id=matter.id, ordinal=1, page=1, paragraph=1, text=text))
    db.commit()
    return d


@pytest.fixture()
def world(db):
    firm = make_firm(db)
    partner = make_user(db, firm, "partner"); sol = make_user(db, firm, "solicitor"); other = make_user(db, firm, "solicitor")
    finance = make_user(db, firm, "finance"); admin = make_user(db, firm, "admin")
    client = make_contact(db, firm, "Calder Textiles Ltd", "organisation")
    open_m = make_matter(db, firm, client, partner, sol, title="Supply agreement review", reference="PCS-COM-2026-0001")
    secret = make_matter(db, firm, client, partner, sol, title="Project Heron acquisition", reference="PCS-COR-2026-0009", access_level="restricted", members=[sol])
    _doc(db, firm, open_m, sol, "Supply Agreement", "The Supplier shall deliver the goods within fourteen days of the order.")
    _doc(db, firm, secret, sol, "Heron SPA draft", "The Purchaser shall pay the consideration for Project Heron on completion.")
    return dict(firm=firm, partner=partner, sol=sol, other=other, finance=finance, admin=admin, client=client, open_m=open_m, secret=secret)


def test_search_excludes_restricted_matters_documents_for_non_members(app, world):
    member, outsider = api_for(app, world["sol"]), api_for(app, world["other"])
    for who, expect in ((member, True), (outsider, False)):
        groups = {g["type"]: g for g in who.get("/search", params={"q": "Heron"}).json()["groups"]}
        found = bool(groups.get("matter")) or bool(groups.get("document"))
        assert found is expect, (who.me["user"]["name"], groups)
    # the open matter is visible to both
    assert any(g["type"] == "document" for g in outsider.get("/search", params={"q": "Supplier shall deliver"}).json()["groups"])


def test_search_respects_role_permissions_finance_has_no_document_search(app, world):
    groups = {g["type"] for g in api_for(app, world["finance"]).get("/search", params={"q": "Supplier"}).json()["groups"]}
    assert "document" not in groups and "correspondence" not in groups


def test_ethical_wall_deny_overrides_everything(app, db, world):
    db.add(MatterMember(firm_id=world["firm"].id, matter_id=world["open_m"].id, user_id=world["other"].id, access="deny")); db.commit()
    groups = api_for(app, world["other"]).get("/search", params={"q": "Supply agreement"}).json()["groups"]
    assert not any(g["type"] == "matter" for g in groups)
    # team-level deny
    team = make_team(db, world["firm"], "Team Walled")
    walled = make_user(db, world["firm"], "solicitor", team=team)
    db.add(MatterMember(firm_id=world["firm"].id, matter_id=world["open_m"].id, team_id=team.id, access="deny")); db.commit()
    assert not any(g["type"] == "matter" for g in api_for(app, walled).get("/search", params={"q": "Supply agreement"}).json()["groups"])


def test_home_shows_only_visible_matters_and_gates_financials(app, db, world):
    p = api_for(app, world["partner"]).get("/home", params={"scope": "firm"}).json()
    refs = {m["reference"] for m in p["matters"]["items"]}
    assert "PCS-COR-2026-0009" in refs  # partner is the responsible partner: allowed
    o = api_for(app, world["other"]).get("/home", params={"scope": "firm"}).json()
    assert "PCS-COR-2026-0009" not in {m["reference"] for m in o["matters"]["items"]}
    assert "financial" not in api_for(app, make_user(db, world["firm"], "paralegal")).get("/home").json()
    f = api_for(app, world["finance"]).get("/home", params={"scope": "firm", "period": "quarter"}).json()
    fin = f["financial"]
    assert fin["period"]["label"] == "Quarter to date" and fin["filters"]["currency"] == "GBP"
    assert all(m["basis"] for m in fin["metrics"]) and all(m["href"] for m in fin["metrics"])
    assert "documents" not in f  # finance has no document access


def test_home_exceptions_have_links(app, db, world):
    db.add(Payment(firm_id=world["firm"].id, ledger="office", matter_id=world["open_m"].id, amount=Decimal("500.00"), received_on=date.today(),
                   recorded_by=world["finance"].id, reference="UNALLOC")); db.commit()
    ex = {e["key"]: e for e in api_for(app, world["finance"]).get("/home", params={"scope": "firm"}).json()["exceptions"]}
    assert ex["unallocated_receipts"]["href"].startswith("/ledger") and ex["unallocated_receipts"]["count"] >= 1


def test_admin_cannot_read_matters_and_role_changes_are_audited(app, db, world):
    adm = api_for(app, world["admin"])
    assert not any(g["type"] == "matter" for g in adm.get("/search", params={"q": "Supply"}).json()["groups"])
    users = adm.get("/admin/users").json()["items"]
    target = next(u for u in users if u["id"] == str(world["other"].id))
    r = adm.patch(f"/admin/users/{target['id']}", json={"expected_version": target["version"], "role_key": "paralegal"})
    assert r.status_code == 200 and r.json()["role_key"] == "paralegal"
    stale = adm.patch(f"/admin/users/{target['id']}", json={"expected_version": target["version"], "name": "X Y"})
    assert stale.status_code == 409
    events = adm.get("/admin/audit", params={"action": "admin.permission_change"}).json()["items"]
    assert events and events[0]["details"]["to"] == "paralegal"
    assert adm.patch(f"/admin/users/{world['admin'].id}", json={"expected_version": 1, "role_key": "partner"}).status_code in (409, 422)
    assert api_for(app, world["sol"]).get("/admin/users").status_code == 403
    assert adm.get("/admin/audit/verify").json()["ok"] is True


def test_admin_cannot_enable_training_on_matter_content(app, world):
    r = api_for(app, world["admin"]).put("/admin/settings", json={"settings": {"ai": {"train_on_matter_content": True}}, "reason": "attempt"})
    assert r.status_code == 422


def test_portal_client_sees_only_own_client_visible_material(app, db, world):
    firm = world["firm"]
    c1, c2 = make_contact(db, firm, "Anna Hartley"), make_contact(db, firm, "Brian Ormerod")
    u1 = make_user(db, firm, "client", contact=c1)
    from app.models import MatterParty
    m1 = make_matter(db, firm, c1, world["partner"], world["sol"], title="Anna's will")
    m2 = make_matter(db, firm, c2, world["partner"], world["sol"], title="Brian's lease")
    for m, c in ((m1, c1), (m2, c2)):
        db.add(MatterParty(firm_id=firm.id, matter_id=m.id, contact_id=c.id, role="client"))
    db.commit()
    shown = _doc(db, firm, m1, world["sol"], "Draft will (for client)", "text", client_visible=True)
    _doc(db, firm, m1, world["sol"], "Internal strategy note", "text", client_visible=False)
    unscanned = _doc(db, firm, m1, world["sol"], "Unscanned", "text", client_visible=True, scan="pending")
    a = api_for(app, u1)
    assert [m["title"] for m in a.get("/portal/matters").json()["items"]] == ["Anna's will"]
    docs = a.get(f"/portal/matters/{m1.id}/documents").json()["items"]
    assert [d["title"] for d in docs] == ["Draft will (for client)"]
    assert a.get(f"/portal/matters/{m2.id}").status_code == 404
    assert a.get(f"/portal/documents/{unscanned.id}/download").status_code == 404
    assert a.get("/matters").status_code in (403, 404)          # no staff API access
    assert a.get("/search", params={"q": "Anna"}).json()["groups"] == []
    assert a.get("/admin/users").status_code == 403
