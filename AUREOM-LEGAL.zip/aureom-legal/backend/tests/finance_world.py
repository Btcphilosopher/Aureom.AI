"""Shared arrangement for finance tests: one firm, staff in each role, a client, an open matter, a default rate card.
Services run on an application-role session (RLS enforced), like the real API."""
from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from app.db.session import new_session
from app.deps import Ctx
from app.models import RateCard, RateCardEntry
from app.services import approvals, billing, ledger as led, reconciliation as rec
from tests.factories import make_contact, make_firm, make_matter, make_team, make_user


class World:
    def __init__(self, db):
        self.owner = db
        self.firm = make_firm(db)
        self.partner = make_user(db, self.firm, "partner", "Penny Partner")
        self.solicitor = make_user(db, self.firm, "solicitor", "Sam Solicitor")
        self.paralegal = make_user(db, self.firm, "paralegal", "Pat Paralegal")
        self.fin_a = make_user(db, self.firm, "finance", "Fran Finance")
        self.fin_b = make_user(db, self.firm, "finance", "Finn Finance")
        self.client = make_contact(db, self.firm, "Calder Mills Ltd", "organisation")
        self.matter = make_matter(db, self.firm, self.client, self.partner, self.solicitor, title="Supply agreement", budget_amount=Decimal("10000.00"),
                                  fixed_fee_amount=Decimal("2500.00"))
        rc = RateCard(firm_id=self.firm.id, name="Standard", is_default=True)
        db.add(rc); db.flush()
        for grade, rate in (("partner", "300.00"), ("solicitor", "200.00"), ("paralegal", "100.00")):
            db.add(RateCardEntry(firm_id=self.firm.id, rate_card_id=rc.id, grade=grade, hourly_rate=Decimal(rate)))
        db.commit()
        self.s = new_session(self.firm.id)

    def ctx(self, user) -> Ctx:
        self.s.expire_all()
        return Ctx.for_user(self.s, user)

    def commit(self):
        self.s.commit()

    def close(self):
        self.s.rollback(); self.s.close()

    # ---- flows
    def billed_invoice(self, minutes: int = 60, user=None, matter=None, narrative="Reviewing supply agreement", approve=True, issue=True):
        """time -> submitted -> draft invoice -> approved by partner -> issued by finance."""
        user = user or self.solicitor
        m = matter or self.matter
        te = billing.create_time_entry(self.ctx(user), matter_id=m.id, work_date=date.today(), minutes=minutes, narrative=narrative)
        billing.submit_time_entry(self.ctx(user), te.id)
        inv = billing.create_draft_invoice(self.ctx(user), matter_id=m.id, time_entry_ids=[te.id])
        billing.submit_invoice_for_approval(self.ctx(user), inv.id)
        self.commit()
        if approve:
            billing.decide_invoice(self.ctx(self.partner), inv.id, approve=True)
            self.commit()
        if issue:
            billing.issue_invoice(self.ctx(self.fin_a), inv.id)
            self.commit()
        return inv.id

    def post_manual(self, ledger, lines, matter_id=None, reference="J1", preparer=None, approver=None, poster=None, effective=None):
        preparer, approver = preparer or self.fin_a, approver or self.fin_b
        j = led.create_journal(self.ctx(preparer), ledger=ledger, reference=reference, description="Test journal", effective_date=effective or date.today(),
                               lines=lines, source_type="manual", matter_id=matter_id, submit=True)
        self.commit()
        led.decide_approval(self.ctx(approver), j.approval_id, approve=True)
        self.commit()
        led.post_journal(self.ctx(poster or preparer), j.id)
        self.commit()
        return j.id

    def record_and_post_receipt(self, ledger="office", matter=None, amount_index=0):
        """Synthetic bank feed -> receipt -> approved -> posted. Returns payment id."""
        res = rec.sync_bank_feed(self.ctx(self.fin_a), ledger)
        self.commit()
        from sqlalchemy import select
        from app.models import BankStatementLine
        lines = self.s.execute(select(BankStatementLine).where(BankStatementLine.firm_id == self.firm.id, BankStatementLine.ledger == ledger,
                                                               BankStatementLine.payment_id.is_(None)).order_by(BankStatementLine.external_id)).scalars().all()
        line = lines[amount_index]
        pay = rec.record_receipt(self.ctx(self.fin_a), line.id, matter_id=(matter or self.matter).id if ledger == "client" or matter else None)
        self.commit()
        from app.models import Journal
        j = self.s.get(Journal, pay.receipt_journal_id)
        led.decide_approval(self.ctx(self.fin_b), j.approval_id, approve=True)
        self.commit()
        led.post_journal(self.ctx(self.fin_a), j.id)
        self.commit()
        return pay.id
