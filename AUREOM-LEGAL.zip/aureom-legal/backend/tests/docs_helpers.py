"""Shared arrangement for documents/correspondence tests."""
from __future__ import annotations

from types import SimpleNamespace

from app import worker
from app.services import jobs
from tests.factories import Api, make_contact, make_firm, make_matter, make_team, make_user


def arrange(db, app):
    firm = make_firm(db)
    t = make_team(db, firm, "Commercial", "commercial")
    partner = make_user(db, firm, "partner", "Penelope Partner", team=t)
    fe = make_user(db, firm, "solicitor", "Sam Solicitor", team=t)
    other = make_user(db, firm, "solicitor", "Olive Other")
    para = make_user(db, firm, "paralegal", "Pat Paralegal", team=t)
    fin = make_user(db, firm, "finance", "Fin Finance")
    client = make_contact(db, firm, "Heron Valley Logistics Ltd", "organisation")
    std = make_matter(db, firm, client, partner, fe, title="Heron Valley supply agreement", practice_area="commercial", reference="HV-001")
    restricted = make_matter(db, firm, client, partner, fe, title="Restricted deal", access_level="restricted", reference="HV-RES", members=[para])
    ns = SimpleNamespace(firm=firm, partner=partner, fe=fe, other=other, para=para, fin=fin, client=client, std=std, restricted=restricted, db=db, app=app)
    ns.api = lambda u: Api(app).login(u)
    return ns


def drain():
    worker.load_handlers()
    return jobs.run_all_pending()


def upload(api, name, content, ctype="application/octet-stream", **form):
    data = {k: str(v) for k, v in form.items() if v is not None}
    return api.c.post("/api/v1/documents", files={"file": (name, content, ctype)}, data=data, headers={"X-CSRF-Token": api.csrf})


def add_version(api, doc_id, name, content, **form):
    return api.c.post(f"/api/v1/documents/{doc_id}/versions", files={"file": (name, content, "application/octet-stream")}, data={k: str(v) for k, v in form.items()},
                      headers={"X-CSRF-Token": api.csrf})


PNG = b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + b"\x00" * 40
AGREEMENT = (b"SUPPLY AGREEMENT (synthetic)\n\n1. Definitions. In this agreement the Supplier is Heron Valley Logistics Ltd.\n\n"
             b"2. Term. The agreement commences on 1 December 2026 and continues for three years.\n\x0c"
             b"9. Termination. Either party may terminate on thirty days written notice.\n\n11. Liability. The Supplier's liability shall not exceed the annual charges.\n")
