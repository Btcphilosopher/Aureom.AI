from app.models import ContactRelationship, MatterParty
from tests._pm_helpers import apis, new_client, onboard_and_clear, setup_firm, make_template
from tests.factories import make_contact, make_matter


def _world(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    existing = make_contact(db, ns.firm, "Hargreaves Holdings Limited", "organisation", aliases=["Hargreaves Group"])
    adv = make_contact(db, ns.firm, "Priya Nair")  # an individual who is director of a counterparty
    client_x = make_contact(db, ns.firm, "Existing Client Ltd", "organisation")
    m_vis = make_matter(db, ns.firm, client_x, ns.partner, title="Supply dispute", reference="VIS-1")
    m_res = make_matter(db, ns.firm, client_x, ns.partner2, title="SECRET acquisition", reference="RES-1", access_level="restricted")
    db.add_all([MatterParty(firm_id=ns.firm.id, matter_id=m_vis.id, contact_id=existing.id, role="counterparty"),
                MatterParty(firm_id=ns.firm.id, matter_id=m_res.id, contact_id=adv.id, role="counterparty"),
                ContactRelationship(firm_id=ns.firm.id, from_contact_id=adv.id, to_contact_id=existing.id, relation_type="director_of")]); db.commit()
    return ns, a, existing, adv


def test_search_finds_exact_alias_fuzzy_relationship_and_masks_restricted(app, db):
    ns, a, existing, adv = _world(app, db)
    s = a.sol.post("/conflicts/searches", {"terms": ["Hargreaves Holdings Ltd", "Hargreaves Group", "Existing Client Limited"]})
    assert s.status_code == 201
    body = s.json()
    types = {(m["searched_term"], m["match_type"]) for m in body["matches"]}
    assert ("Hargreaves Holdings Ltd", "name_exact") in types          # suffix-normalised exact
    assert ("Hargreaves Group", "alias") in types
    fz = a.sol.post("/conflicts/searches", {"terms": ["Priya Nayr"]}).json()  # typo -> fuzzy
    pairs = [(m["match_type"], m["evidence"]["contact"]["name"]) for m in fz["matches"]]
    assert ("name_fuzzy", "Priya Nair") in pairs and ("relationship", "Hargreaves Holdings Limited") in pairs  # she is a director of Hargreaves
    assert any(m["match_type"] == "relationship" for m in body["matches"])  # director of matched org
    assert body["status"] == "pending_review"  # never auto-cleared
    assert "never declares" in body["notice"]
    by_contact = {m["evidence"]["contact"]["name"]: m for m in body["matches"]}
    hh = by_contact["Hargreaves Holdings Limited"]
    assert hh["evidence"]["matters"][0]["masked"] is False and hh["evidence"]["matters"][0]["reference"] == "VIS-1" and hh["evidence"]["adverse_hint"] is True
    # Priya's only matter is restricted and the solicitor is not a member: evidence masked, no leak of title/reference
    pn = by_contact["Priya Nair"]["evidence"]["matters"][0]
    assert pn["masked"] is True and "Restricted matter - details withheld" in pn["label"] and "Peter Partner" in pn["label"]
    raw = str(body)
    assert "SECRET" not in raw and "RES-1" not in raw
    # a member of the restricted matter does see it
    partner2_view = a.partner2.get(f"/conflicts/searches/{body['id']}").json()
    pn2 = [m for m in partner2_view["matches"] if m["evidence"]["contact"]["name"] == "Priya Nair"][0]["evidence"]["matters"][0]
    assert pn2["masked"] is False and pn2["reference"] == "RES-1"


def test_review_workflow_history_and_no_auto_clear(app, db):
    ns, a, existing, adv = _world(app, db)
    s = a.sol.post("/conflicts/searches", {"terms": ["Hargreaves Holdings"]}).json()
    sid = s["id"]
    assert s["match_count"] >= 1 and s["unreviewed_matches"] == s["match_count"]
    # solicitors can run but not review
    assert a.sol.post(f"/conflicts/searches/{sid}/decision", {"decision": "cleared_by_reviewer", "note": "x"}).status_code == 403
    # cannot decide while matches are unreviewed
    r = a.compliance.post(f"/conflicts/searches/{sid}/decision", {"decision": "cleared_by_reviewer", "note": "x"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "matches_unreviewed"
    mid = s["matches"][0]["id"]
    assert a.compliance.patch(f"/conflicts/matches/{mid}", {"disposition": "potential_conflict"}).status_code == 422  # note required
    assert a.compliance.patch(f"/conflicts/matches/{mid}", {"disposition": "potential_conflict", "note": "Counterparty on live dispute"}).status_code == 200
    for m in s["matches"][1:]:
        a.compliance.patch(f"/conflicts/matches/{m['id']}", {"disposition": "false_positive", "note": "unrelated"})
    assert a.compliance.post(f"/conflicts/searches/{sid}/decision", {"decision": "cleared_by_reviewer"}).json()["error"]["code"] == "note_required"
    a.compliance.patch(f"/conflicts/matches/{mid}", {"disposition": "confirmed_conflict", "note": "Confirmed adverse"})
    assert a.compliance.post(f"/conflicts/searches/{sid}/decision", {"decision": "cleared_by_reviewer", "note": "n"}).status_code == 422
    done = a.compliance.post(f"/conflicts/searches/{sid}/decision", {"decision": "conflict_confirmed", "note": "Cannot act"})
    assert done.status_code == 200 and done.json()["status"] == "conflict_confirmed"
    hist = a.sol.get(f"/conflicts/searches/{sid}").json()["history"]
    events = [(h["event"], h["to"]) for h in hist]
    assert events[0] == ("search_created", "pending_review") and ("search_decision", "conflict_confirmed") in events
    assert [h["to"] for h in hist if h["event"] == "match_disposition"][:2] == ["potential_conflict", "false_positive"][:1] + [h["to"] for h in hist if h["event"] == "match_disposition"][1:2]
    assert all(h["actor"] for h in hist)
    # decided searches are final
    assert a.compliance.patch(f"/conflicts/matches/{mid}", {"disposition": "false_positive", "note": "x"}).status_code == 409


def test_no_matches_still_requires_human_decision_with_note(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    s = a.sol.post("/conflicts/searches", {"terms": ["Zzyzx Nonexistent Person"]}).json()
    assert s["match_count"] == 0 and s["status"] == "pending_review"
    assert a.compliance.post(f"/conflicts/searches/{s['id']}/decision", {"decision": "cleared_by_reviewer"}).status_code == 422
    ok = a.compliance.post(f"/conflicts/searches/{s['id']}/decision", {"decision": "cleared_by_reviewer", "note": "No matches in firm records"})
    assert ok.status_code == 200 and ok.json()["reviewed_by_name"] == "Cora Compliance"


def test_subject_relationships_are_searched(app, db):
    ns, a, existing, adv = _world(app, db)
    new = new_client(a.sol, "Newco Prospect Ltd")
    # new prospect's director is a person we already hold as counterparty director
    dup_person = new_client(a.sol, "Priya Nair", "individual")
    a.sol.post(f"/clients/{dup_person['id']}/relationships", {"to_contact_id": new["id"], "relation_type": "director_of"})
    s = a.sol.post("/conflicts/searches", {"subject_contact_id": new["id"]}).json()
    assert any(m["evidence"]["contact"]["name"] == "Priya Nair" and m["evidence"]["origin"].startswith("related_to_subject") for m in s["matches"])


def test_matter_cannot_open_without_cleared_search(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    tpl = make_template(a.partner)
    c = new_client(a.sol, "Open Test Ltd")
    m = a.sol.post("/matters", {"title": "Open test", "client_id": c["id"], "template_id": tpl["id"], "responsible_partner_id": str(ns.partner.id), "target_date": "2027-03-01"}).json()
    r = a.partner.post(f"/matters/{m['id']}/transitions", {"to_status": "open", "expected_version": m["version"]})
    assert r.status_code == 422
    codes = {b["code"] for b in r.json()["error"]["details"]["blockers"]}
    assert {"conflict_not_cleared", "onboarding_incomplete", "opening_checklist"} <= codes
