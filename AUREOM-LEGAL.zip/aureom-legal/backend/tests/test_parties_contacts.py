from sqlalchemy import select

from app.models import Contact, MatterParty
from tests._pm_helpers import apis, new_client, setup_firm
from tests.factories import Api, make_contact, make_firm, make_matter, make_user


def test_contact_crud_filters_and_concurrency(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c = new_client(a.sol, "Jane Q Public", "individual", first_name="Jane", last_name="Public", aliases=["J Public"], email="jane@example.test",
                   addresses=[{"line1": "1 High St", "postcode": "LS1 1AA", "is_primary": True}])
    assert c["status"] == "prospect" and c["client_ref"] is None and c["responsible_name"] == "Sam Solicitor"
    assert c["addresses"][0]["postcode"] == "LS1 1AA"
    r = a.sol.get("/clients", params={"q": "J Public"}).json()
    assert r["total"] == 1 and r["items"][0]["id"] == c["id"]
    assert a.sol.get("/clients", params={"is_client": "true"}).json()["total"] == 0
    # optimistic concurrency
    ok = a.sol.patch(f"/clients/{c['id']}", {"expected_version": c["version"], "phone": "0113 000 0000"})
    assert ok.status_code == 200 and ok.json()["version"] == c["version"] + 1
    stale = a.para.patch(f"/clients/{c['id']}", {"expected_version": c["version"], "phone": "999"})
    assert stale.status_code == 409 and stale.json()["error"]["code"] == "version_conflict"
    # relationships both directions
    org = new_client(a.sol, "Public Widgets Ltd")
    assert a.sol.post(f"/clients/{c['id']}/relationships", {"to_contact_id": org["id"], "relation_type": "director_of"}).status_code == 201
    assert a.sol.post(f"/clients/{c['id']}/relationships", {"to_contact_id": c["id"], "relation_type": "spouse_of"}).status_code == 422
    assert a.sol.post(f"/clients/{c['id']}/relationships", {"to_contact_id": org["id"], "relation_type": "bogus"}).status_code == 422
    d_org = a.sol.get(f"/clients/{org['id']}").json()
    assert d_org["relationships"][0]["direction"] == "incoming" and d_org["relationships"][0]["other"]["display_name"] == "Jane Q Public"
    # finance cannot write contacts; admin can read but not write
    assert a.finance.post("/clients", {"kind": "individual", "display_name": "X Y"}).status_code == 403
    assert a.admin.post("/clients", {"kind": "individual", "display_name": "X Y"}).status_code == 403


def test_cross_firm_contact_is_404(app, db):
    ns1, ns2 = setup_firm(db), setup_firm(db)
    a1, a2 = apis(app, ns1), apis(app, ns2)
    c = new_client(a1.sol, "Firm One Client", "individual")
    assert a2.sol.get(f"/clients/{c['id']}").status_code == 404
    assert a2.sol.patch(f"/clients/{c['id']}", {"expected_version": 1, "notes": "x"}).status_code == 404
    assert a2.sol.get("/clients", params={"q": "Firm One"}).json()["total"] == 0


def test_contact_holds_different_roles_on_different_matters(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c = make_contact(db, ns.firm, "Acme Supplies Ltd", "organisation")
    cl1 = make_contact(db, ns.firm, "Client One")
    cl2 = make_contact(db, ns.firm, "Client Two")
    m1 = make_matter(db, ns.firm, cl1, ns.partner, title="Dispute A", reference="R-1")
    m2 = make_matter(db, ns.firm, cl2, ns.partner, title="Contract B", reference="R-2")
    db.add_all([MatterParty(firm_id=ns.firm.id, matter_id=m1.id, contact_id=c.id, role="counterparty"),
                MatterParty(firm_id=ns.firm.id, matter_id=m2.id, contact_id=c.id, role="client"),
                MatterParty(firm_id=ns.firm.id, matter_id=m2.id, contact_id=c.id, role="payer")]); db.commit()
    d = a.sol.get(f"/clients/{c.id}").json()
    roles = {x["reference"]: sorted(x["roles"]) for x in d["matters"]}
    assert roles == {"R-1": ["counterparty"], "R-2": ["client", "payer"]}


def test_onboarding_is_simulated_and_needs_human_approval(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c = new_client(a.sol, "Olivia Onboard", "individual", first_name="Olivia", last_name="Onboard")
    cid = c["id"]
    assert a.sol.post(f"/clients/{cid}/onboarding/approve", {"note": "x"}).status_code == 403  # solicitor lacks onboarding.approve
    blocked = a.partner.post(f"/clients/{cid}/onboarding/approve", {"note": "x"})
    assert blocked.status_code == 409 or blocked.status_code == 422  # not started
    a.sol.put(f"/clients/{cid}/onboarding/form", {"form": {"source_of_funds": "salary", "note": "<script>alert(1)</script>"}})
    r = a.sol.post(f"/clients/{cid}/onboarding/checks", {"check_type": "id_individual"})
    assert r.status_code == 201
    ob = r.json()
    chk = ob["checks"][0]
    assert chk["simulated"] is True and chk["status"] == "passed_simulated" and "SIMULATED" in chk["result_summary"] and "simulated" in chk["status_label"].lower()
    assert "verified" not in {x["status"] for x in ob["checks"]}
    # sanctions check still missing -> approval blocked with a clear reason
    blocked = a.partner.post(f"/clients/{cid}/onboarding/approve", {"note": "x"})
    assert blocked.status_code == 422 and blocked.json()["error"]["code"] == "onboarding_blocked"
    assert any(b["check_type"] == "sanctions_pep" for b in blocked.json()["error"]["details"]["blockers"])
    # organisation-only check does not apply to an individual
    assert a.sol.post(f"/clients/{cid}/onboarding/checks", {"check_type": "company_kyb"}).status_code == 422
    a.sol.post(f"/clients/{cid}/onboarding/checks", {"check_type": "sanctions_pep"})
    ok = a.partner.post(f"/clients/{cid}/onboarding/approve", {"note": "reviewed", "risk_level": "low"})
    assert ok.status_code == 200
    assert ok.json()["contact"]["is_client"] is True and ok.json()["contact"]["client_ref"].startswith("PCS-C")
    assert ok.json()["onboarding"]["record"]["status"] == "approved"
    assert a.partner.post(f"/clients/{cid}/onboarding/approve", {}).status_code == 409  # already approved


def test_trigger_words_need_review_and_waiver_needs_reason(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    c = new_client(a.sol, "Rex Refer", "individual")
    a.sol.post(f"/clients/{c['id']}/onboarding/checks", {"check_type": "id_individual"})
    ob = a.sol.post(f"/clients/{c['id']}/onboarding/checks", {"check_type": "sanctions_pep"}).json()
    assert {x["check_type"]: x["status"] for x in ob["checks"]} == {"id_individual": "needs_review", "sanctions_pep": "needs_review"}
    assert a.partner.post(f"/clients/{c['id']}/onboarding/approve", {}).status_code == 422
    ids = {x["check_type"]: x["id"] for x in ob["checks"]}
    assert a.partner.post(f"/clients/{c['id']}/onboarding/checks/{ids['id_individual']}/waive", {"reason": "short"}).status_code == 422
    assert a.partner.post(f"/clients/{c['id']}/onboarding/checks/{ids['id_individual']}/waive", {"reason": "Identity evidenced in person at office"}).status_code == 200
    assert a.partner.post(f"/clients/{c['id']}/onboarding/checks/{ids['sanctions_pep']}/review", {"decision": "accept", "note": "Reviewed manually"}).status_code == 200
    assert a.partner.post(f"/clients/{c['id']}/onboarding/approve", {}).status_code == 200
    f = new_client(a.sol, "Fay Fail", "individual")
    ob = a.sol.post(f"/clients/{f['id']}/onboarding/checks", {"check_type": "id_individual"}).json()
    assert ob["checks"][0]["status"] == "failed"


def test_companies_house_integration_unavailable_state(app, db):
    ns = setup_firm(db); a = apis(app, ns)
    r = a.sol.get("/clients/lookup/companies-house", params={"number": "01234567"})
    assert r.status_code == 503 and r.json()["error"]["code"] == "integration_unavailable"
    assert "not available" in r.json()["error"]["message"].lower()
