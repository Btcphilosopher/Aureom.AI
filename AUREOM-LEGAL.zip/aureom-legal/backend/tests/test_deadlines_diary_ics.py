"""Diary events, combined feed, ICS export (only confirmed deadlines are authoritative) and mock calendar sync."""
from datetime import date, datetime, timezone

import pytest
from sqlalchemy import select

from app.models import IntegrationEvent
from app.services import deadlines as dl
from tests.factories import api_for, make_contact, make_firm, make_matter, make_user


@pytest.fixture()
def world(db):
    firm = make_firm(db)
    dl.ensure_default_rules(db, firm.id); db.commit()
    partner = make_user(db, firm, "partner", "Penny Partner")
    sol = make_user(db, firm, "solicitor", "Sam Solicitor")
    other = make_user(db, firm, "solicitor", "Olive Other")
    para = make_user(db, firm, "paralegal", "Pat Para")
    client = make_contact(db, firm, "Acme Widgets Ltd", "organisation")
    std = make_matter(db, firm, client, partner, sol, title="Supply agreement")
    restricted = make_matter(db, firm, client, partner, sol, access_level="restricted", title="Restricted")
    return dict(firm=firm, partner=partner, sol=sol, other=other, para=para, std=std, restricted=restricted)


def _unfold(ics: str) -> str:
    return ics.replace("\r\n ", "")


def test_event_crud_attendees_and_concurrency(app, db, world):
    w = world
    s = api_for(app, w["sol"])
    r = s.post("/diary/events", {"title": "Client meeting", "kind": "meeting", "start_at": "2026-12-02T10:00:00+00:00", "end_at": "2026-12-02T11:00:00+00:00",
                                 "matter_id": str(w["std"].id), "attendee_ids": [str(w["para"].id)], "location": "Leeds"})
    assert r.status_code == 201, r.text
    e = r.json()
    assert e["owner_name"] == "Sam Solicitor" and e["matter_reference"] == w["std"].reference
    # attendee sees it in their own diary; an unrelated user does not (scope=mine)
    day = "from=2026-12-01&to=2026-12-03"
    assert api_for(app, w["para"]).get(f"/diary/events?{day}").json()["total"] == 1
    assert api_for(app, w["other"]).get(f"/diary/events?{day}").json()["total"] == 0
    assert api_for(app, w["other"]).get(f"/diary/events?{day}&scope=all").json()["total"] == 1  # all = visible matter events
    # bad input
    assert s.post("/diary/events", {"title": "x", "start_at": "2026-12-02T10:00:00+00:00", "end_at": "2026-12-02T09:00:00+00:00"}).status_code == 422
    assert s.post("/diary/events", {"title": "x", "start_at": "2026-12-02T10:00:00+00:00", "attendee_ids": ["00000000-0000-0000-0000-000000000000"]}).status_code == 422
    # optimistic concurrency + organiser-only editing
    r = s.patch(f"/diary/events/{e['id']}", {"expected_version": 1, "title": "Client meeting (moved)", "start_at": "2026-12-03T10:00:00+00:00", "end_at": "2026-12-03T11:00:00+00:00"})
    assert r.status_code == 200 and r.json()["version"] == 2
    assert s.patch(f"/diary/events/{e['id']}", {"expected_version": 1, "title": "stale"}).status_code == 409
    assert api_for(app, w["para"]).patch(f"/diary/events/{e['id']}", {"expected_version": 2, "title": "hijack"}).status_code == 403
    assert s.delete(f"/diary/events/{e['id']}").status_code == 204
    assert s.get(f"/diary/events/{e['id']}").status_code == 404


def test_feed_types_deadline_authority_and_restricted_exclusion(app, db, world):
    w = world
    s = api_for(app, w["sol"])
    s.post("/diary/events", {"title": "Public hearing prep", "kind": "hearing", "start_at": "2026-12-10T09:00:00+00:00", "matter_id": str(w["std"].id)})
    s.post("/diary/events", {"title": "Wall-protected call", "kind": "call", "start_at": "2026-12-10T12:00:00+00:00", "matter_id": str(w["restricted"].id)})
    s.post("/tasks", {"title": "Send engagement letter", "matter_id": str(w["std"].id), "assignee_id": str(w["sol"].id), "due_at": "2026-12-11T09:00:00+00:00"})
    s.post("/diary/deadlines", {"matter_id": str(w["std"].id), "title": "Confirmed filing", "due_date": "2026-12-14"})
    s.post("/diary/deadlines", {"matter_id": str(w["restricted"].id), "title": "Restricted filing", "due_date": "2026-12-14"})
    sug = s.post("/diary/deadlines/calculate", {"matter_id": str(w["std"].id), "rule_key": "ack_14_calendar", "trigger_date": "2026-12-01"}).json()  # 15 Dec
    feed = s.get("/diary/feed?from=2026-12-01&to=2026-12-31").json()
    by = {i["title"]: i for i in feed}
    assert by["Public hearing prep"]["kind"] == "event" and by["Send engagement letter"]["kind"] == "task"
    assert by["Confirmed filing"]["kind"] == "deadline" and by["Confirmed filing"]["authoritative"] is True
    unconf = [i for i in feed if i["kind"] == "deadline" and i["authoritative"] is False]
    assert len(unconf) == 1 and unconf[0]["title"].startswith("[Unconfirmed]") and "Unconfirmed suggestion" in unconf[0]["label"] and unconf[0]["id"] == sug["id"]
    assert [i["start"] for i in feed] == sorted(i["start"] for i in feed)  # chronological
    # a non-member solicitor sees none of the restricted matter's items, even with scope=all
    o = api_for(app, w["other"]).get("/diary/feed?from=2026-12-01&to=2026-12-31&scope=all").json()
    titles = {i["title"] for i in o}
    assert "Public hearing prep" in titles and "Wall-protected call" not in titles and "Restricted filing" not in titles
    assert s.get("/diary/feed?from=2026-12-31&to=2026-12-01").status_code == 422


def test_ics_contains_only_confirmed_deadlines_and_excludes_restricted(app, db, world):
    w = world
    s = api_for(app, w["partner"])  # partner is responsible on both matters
    s.post("/diary/deadlines", {"matter_id": str(w["std"].id), "title": "Confirmed filing, with; punctuation", "due_date": "2026-12-14"})
    s.post("/diary/deadlines", {"matter_id": str(w["restricted"].id), "title": "Restricted filing", "due_date": "2026-12-14"})
    s.post("/diary/deadlines/calculate", {"matter_id": str(w["std"].id), "rule_key": "ack_14_calendar", "trigger_date": "2026-12-01", "title": "Suggested-only item"})
    s.post("/diary/events", {"title": "Board call", "start_at": "2026-12-12T15:00:00+00:00", "end_at": "2026-12-12T15:30:00+00:00", "location": "Teams, room 4"})
    r = s.get("/diary/ics?from=2026-12-01&to=2026-12-31")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/calendar") and "attachment" in r.headers["content-disposition"]
    ics = _unfold(r.text)
    assert ics.startswith("BEGIN:VCALENDAR\r\n") and ics.rstrip().endswith("END:VCALENDAR") and "PRODID:-//AUREOM LEGAL" in ics
    assert r"SUMMARY:DEADLINE: Confirmed filing\, with\; punctuation" in ics and "DTSTART;VALUE=DATE:20261214" in ics
    assert "Suggested-only item" not in ics  # unconfirmed suggestions never leave the application via ICS
    assert "SUMMARY:Board call" in ics and "LOCATION:Teams\\, room 4" in ics and "DTSTART:20261212T150000Z" in ics
    # restricted-matter items are excluded for a non-member (and the unconfirmed suggestion still is)
    o = api_for(app, w["other"]).get("/diary/ics?from=2026-12-01&to=2026-12-31&scope=all").text
    assert "Restricted filing" not in o and "Suggested-only item" not in o and "Confirmed filing" in _unfold(o)
    assert all(len(line.encode()) <= 75 for line in r.text.split("\r\n"))  # RFC 5545 folding


def test_mock_calendar_sync_is_clearly_simulated(app, db, world):
    w = world
    s = api_for(app, w["sol"])
    e = s.post("/diary/events", {"title": "Hearing", "kind": "hearing", "start_at": "2026-12-20T10:00:00+00:00"}).json()
    r = s.post(f"/diary/events/{e['id']}/sync")
    assert r.status_code == 200
    j = r.json()
    assert j["simulated"] is True and j["synced"] is False and "no external calendar" in j["message"].lower()
    assert j["provider"]["mode"] == "mock" and "MOCK" in j["provider"]["name"]
    ev = db.execute(select(IntegrationEvent).where(IntegrationEvent.firm_id == w["firm"].id, IntegrationEvent.integration == "calendar")).scalars().all()
    assert len(ev) == 1 and ev[0].status == "simulated" and ev[0].mode == "mock"
    from app.integrations import base
    assert base.get("calendar").info().mode == "mock"
