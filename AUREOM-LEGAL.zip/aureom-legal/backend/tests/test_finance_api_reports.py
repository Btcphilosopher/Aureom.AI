"""HTTP-level finance flow, permissions, restricted-matter and cross-firm exclusion, reports metadata, CSV export audit."""
from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.models import AuditEvent, Invoice, TimeEntry
from tests.factories import Api, make_contact, make_firm, make_matter, make_user
from tests.finance_world import World


@pytest.fixture()
def w(db):
    world = World(db)
    yield world
    world.close()


def login(app, u):
    return Api(app).login(u)


def test_end_to_end_finance_flow_over_http(app, w):
    sol, par, fa, fb = (login(app, u) for u in (w.solicitor, w.partner, w.fin_a, w.fin_b))
    r = sol.post("/time/entries", {"matter_id": str(w.matter.id), "work_date": date.today().isoformat(), "minutes": 90, "narrative": "Drafting heads of terms"})
    assert r.status_code == 201 and r.json()["amount"] == "300.00" and r.json()["rate"] == "200.00"
    te = r.json()["id"]
    assert sol.post(f"/time/entries/{te}/submit").json()["status"] == "submitted"
    inv = sol.post("/billing/invoices", {"matter_id": str(w.matter.id), "time_entry_ids": [te]})
    assert inv.status_code == 201, inv.text
    inv = inv.json(); assert inv["total"] == "360.00" and inv["status"] == "draft"
    assert fa.post(f"/billing/invoices/{inv['id']}/issue").status_code == 409                 # not approved
    assert sol.post(f"/billing/invoices/{inv['id']}/submit").json()["status"] == "pending_approval"
    assert sol.post(f"/billing/invoices/{inv['id']}/decision", {"approve": True}).status_code == 403   # fee earner cannot approve
    assert par.post(f"/billing/invoices/{inv['id']}/decision", {"approve": True}).json()["approval_status"] == "approved"
    issued = fa.post(f"/billing/invoices/{inv['id']}/issue").json()
    assert issued["status"] == "issued" and issued["number"].startswith("INV-") and issued["outstanding"] == "360.00"
    # receipt -> authorise -> post
    sync = fa.post("/ledger/bank-feed/sync", {"ledger": "office"}).json()
    assert sync["synthetic"] is True and sync["created"] == 3
    lines = fa.get("/ledger/bank-lines", params={"unrecorded": True, "ledger": "office"}).json()["items"]
    line = next(l for l in lines if l["amount"] == "1500.00")
    pay = fa.post("/ledger/payments", {"bank_line_id": line["id"]}).json()
    assert pay["status"] == "pending_authorisation" and "not earned revenue" in pay["note"]
    j = fa.get(f"/ledger/journals/{pay['receipt_journal_id']}").json()
    assert fa.post(f"/ledger/journals/{j['id']}/post").status_code == 409                      # unapproved
    assert fa.post(f"/ledger/journals/{j['id']}/decision", {"approve": True}).status_code == 403  # preparer cannot approve
    assert fb.post(f"/ledger/journals/{j['id']}/decision", {"approve": True}).status_code == 200
    assert fa.post(f"/ledger/journals/{j['id']}/post").json()["status"] == "posted"
    # allocation: request (202) -> authorise by another person -> execute (200)
    body = {"allocations": [{"invoice_id": inv["id"], "amount": "360.00"}]}
    req = fa.post(f"/ledger/payments/{pay['id']}/allocate", body)
    assert req.status_code == 202, req.text
    ap = req.json()["approval_id"]
    assert fb.post(f"/ledger/approvals/{ap}/decision", {"approve": True}).json()["status"] == "approved"
    done = fa.post(f"/ledger/payments/{pay['id']}/allocate", {**body, "approval_id": ap})
    assert done.status_code == 200 and done.json()["payment"]["allocated_amount"] == "360.00"
    assert fa.post(f"/ledger/payments/{pay['id']}/allocate", {**body, "approval_id": ap}).status_code == 409   # replay refused
    assert fa.get(f"/billing/invoices/{inv['id']}").json()["status"] == "paid"
    # trial balance: balanced, and no revenue yet
    tb = fa.get("/ledger/trial-balance", params={"ledger": "office"}).json()
    assert tb["total_debit"] == tb["total_credit"]
    assert next(a for a in tb["accounts"] if a["system_key"] == "fee_income")["balance"] == "0.00"
    # revenue recognition only through its own authorised step
    rr = fa.post("/ledger/revenue-recognition", {"invoice_id": inv["id"], "amount": "300.00", "basis": "Completed and billed"}).json()
    assert rr["status"] == "pending_approval"
    assert fb.post(f"/ledger/journals/{rr['id']}/decision", {"approve": True}).status_code == 200
    assert fa.post(f"/ledger/journals/{rr['id']}/post").status_code == 200
    rev = fa.get("/reports/recognised-revenue").json()
    assert rev["totals"]["recognised"] == "300.00"


def test_permissions_matrix(app, w):
    sol, para, fin, par = (login(app, u) for u in (w.solicitor, w.paralegal, w.fin_a, w.partner))
    assert para.get("/billing/invoices").status_code == 403              # no billing.read
    assert sol.get("/ledger/accounts").status_code == 403                # fee earners have no ledger.read
    assert sol.post("/ledger/journals", {"ledger": "office", "reference": "X", "description": "x", "effective_date": date.today().isoformat(),
                                         "lines": []}).status_code == 403
    assert sol.get("/reports/billing").status_code == 403                # financial report needs reports.financial
    assert para.get("/reports/aged-debtors").status_code == 403
    assert fin.get("/reports/billing").status_code == 200 and par.get("/reports/billing").status_code == 200
    assert fin.get("/reports/nope").status_code == 404
    # time visibility: paralegal sees own entries only
    other = sol.post("/time/entries", {"matter_id": str(w.matter.id), "work_date": date.today().isoformat(), "minutes": 6, "narrative": "n"}).json()
    mine = para.post("/time/entries", {"matter_id": str(w.matter.id), "work_date": date.today().isoformat(), "minutes": 12, "narrative": "n"}).json()
    ids = {e["id"] for e in para.get("/time/entries").json()["items"]}
    assert mine["id"] in ids and other["id"] not in ids
    assert {e["id"] for e in fin.get("/time/entries").json()["items"]} >= {mine["id"], other["id"]}   # finance (billing.read) sees all visible
    # unauthenticated
    assert Api(app).get("/billing/invoices").status_code == 401


def test_restricted_matter_and_cross_firm_isolation(app, w, db):
    restricted = make_matter(db, w.firm, w.client, w.partner, w.solicitor, access_level="restricted", reference="RESTR-9", title="Hush-hush acquisition")
    inv = Invoice(firm_id=w.firm.id, matter_id=restricted.id, client_id=w.client.id, kind="invoice", status="issued", number="INV-9999-0001", currency="GBP",
                  subtotal=Decimal("100.00"), vat_amount=Decimal("20.00"), total=Decimal("120.00"), created_by=w.partner.id)
    te = TimeEntry(firm_id=w.firm.id, matter_id=restricted.id, user_id=w.solicitor.id, work_date=date.today(), minutes=60, narrative="secret", rate=Decimal("200"),
                   amount=Decimal("200.00"), status="submitted")
    db.add_all([inv, te]); db.commit()
    fin, sol, par = login(app, w.fin_a), login(app, w.solicitor), login(app, w.partner)
    assert fin.get("/billing/invoices").json()["total"] == 0                                    # finance is not on the restricted matter
    r = fin.get(f"/billing/invoices/{inv.id}")
    assert r.status_code == 403 and r.json()["error"]["code"] == "matter_access_denied" and "Hush" not in r.text
    assert fin.post("/time/entries", {"matter_id": str(restricted.id), "work_date": date.today().isoformat(), "minutes": 5, "narrative": "x"}).status_code == 403
    wip = fin.get("/reports/wip").json()
    assert all(row["reference"] != "RESTR-9" for row in wip["rows"])
    assert fin.get("/reports/aged-debtors").json()["rows"] == []
    assert sol.get("/time/entries", params={"matter_id": str(restricted.id)}).json()["total"] == 1   # fee earner on the matter sees it
    assert par.get("/billing/invoices").json()["total"] == 1
    # cross-firm
    other_firm = make_firm(db)
    stranger = make_user(db, other_firm, "finance")
    sa = login(app, stranger)
    assert sa.get(f"/billing/invoices/{inv.id}").status_code == 404
    assert sa.get("/billing/invoices").json()["total"] == 0
    assert sa.get("/ledger/journals").json()["total"] == 0
    assert sa.get(f"/ledger/matters/{w.matter.id}/client-balance").status_code == 404


def test_reports_state_period_filters_basis_and_csv_is_audited(app, w, db):
    w.billed_invoice(minutes=60)
    fin = login(app, w.fin_a)
    for name in ("wip", "billing", "cash-received", "recognised-revenue", "aged-debtors", "client-money", "utilisation"):
        rep = fin.get(f"/reports/{name}")
        assert rep.status_code == 200, (name, rep.text)
        j = rep.json()
        assert j["basis"] and j["currency"] == "GBP" and "period" in j and "filters" in j and j["generated_at"], name
    billing = fin.get("/reports/billing").json()
    assert billing["totals"]["net"] == "200.00" and billing["totals"]["label"] == "billed, not revenue" and "NOT recognised revenue" in billing["basis"]
    aged = fin.get("/reports/aged-debtors").json()
    assert aged["totals"]["0-30"] == "240.00" and aged["rows"][0]["outstanding"] == "240.00"
    csv = fin.get("/reports/billing.csv")
    assert csv.status_code == 200 and csv.headers["content-type"].startswith("text/csv") and "INV-" in csv.text and "Basis:" in csv.text
    n = db.execute(select(AuditEvent).where(AuditEvent.firm_id == w.firm.id, AuditEvent.action == "report.exported")).scalars().all()
    assert len(n) == 1 and n[0].actor_user_id == w.fin_a.id
    # a solicitor sees own-matter WIP only and cannot export financial CSV
    sol = login(app, w.solicitor)
    assert sol.get("/reports/billing.csv").status_code == 403
    assert sol.get("/reports/wip").json()["filters"]["scope"] == "own matters only"


def test_home_summary_respects_permissions(app, w):
    sol, para = login(app, w.solicitor), login(app, w.paralegal)
    sol.post("/time/entries", {"matter_id": str(w.matter.id), "work_date": date.today().isoformat(), "minutes": 60, "narrative": "a"})
    para.post("/time/entries", {"matter_id": str(w.matter.id), "work_date": date.today().isoformat(), "minutes": 60, "narrative": "b"})
    s = sol.get("/time/home-summary").json()
    p = para.get("/time/home-summary").json()
    assert s["unbilled_time"]["amount"] == "300.00" and s["draft_invoices"] is not None      # solicitor: billing.read -> all visible
    assert p["unbilled_time"]["amount"] == "100.00" and p["draft_invoices"] is None           # paralegal: own time only, no invoices
    assert "not revenue" in s["basis"]


def test_budget_and_optimistic_concurrency(app, w):
    sol = login(app, w.solicitor)
    te = sol.post("/time/entries", {"matter_id": str(w.matter.id), "work_date": date.today().isoformat(), "minutes": 60, "narrative": "a"}).json()
    ok = sol.patch(f"/time/entries/{te['id']}", {"expected_version": te["version"], "minutes": 120})
    assert ok.status_code == 200 and ok.json()["amount"] == "400.00"
    stale = sol.patch(f"/time/entries/{te['id']}", {"expected_version": te["version"], "minutes": 30})
    assert stale.status_code == 409 and stale.json()["error"]["code"] == "version_conflict"
    b = sol.get(f"/time/matters/{w.matter.id}/budget").json()
    assert b["budget"] == "10000.00" and b["unbilled_wip"] == "400.00" and b["used_pct"] == "4.0" and b["over_budget"] is False
