"""Row-level security, append-only audit, immutable originals, balanced journals

Revision ID: 0002
Revises: 0001
"""
from pathlib import Path

from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

SQL = (Path(__file__).resolve().parents[2] / "app" / "db" / "safeguards.sql").read_text()


def upgrade() -> None:
    op.get_bind().exec_driver_sql(SQL.replace("%", "%%"))


def downgrade() -> None:
    raise NotImplementedError("Safeguards are intentionally not removable via downgrade; restore from backup instead.")
