# Backend conventions (contract between domain modules)

Modular monolith. `app/models/*` (frozen contract), `app/services/*` (business logic, take a `Ctx`), `app/api/*` (thin routers,
`router = APIRouter(prefix="/<name>", tags=[...])`, mounted at `/api/v1`), `app/schemas/*` (pydantic), `app/integrations/*`.

## Request context & permissions
* `from app.deps import Ctx, get_ctx, require` – `ctx: Ctx = Depends(require("matters.read"))`. `Ctx` has `db`, `user`, `firm_id`, `role_key`, `has()`, `require()`, `audit()`.
* Services that act for a user take `ctx` (never a bare Session) so permission/tenant rules can't be bypassed. Outside HTTP: `Ctx.for_user(db, user)`.
* Tenant: every business table has `firm_id`; ALWAYS filter by `ctx.firm_id` AND rely on RLS (the app role cannot see other firms). Cross-firm id => 404.
* Matter access: use `app.permissions.matter_clause(ctx)` / `visible_matter_ids(ctx)` in every list/search query touching matter content, and
  `can_access_matter / can_preview / can_export / can_ai_retrieve` for single records. Restricted/ethical-wall matter by id => `MatterAccessDenied` (403); it must never appear in lists, search, counts, notifications, AI retrieval.
  Documents/correspondence/tasks/time etc. belong to a matter (or a contact for onboarding docs) – check the parent matter's visibility.
* Role permissions live in `app/permissions.py` (catalogue; roles table may override). Finance has NO document/correspondence read.
* Errors: raise from `app.errors` (NotFound, PermissionDenied, MatterAccessDenied, InvalidState, VersionConflict, ValidationFailed, IntegrationUnavailable, ApprovalRequired, BudgetExceeded). Response shape `{"error": {"code","message","details"}}`.
* Optimistic concurrency: mutable entities have `version` (SQLAlchemy `version_id_col`). PATCH bodies carry `expected_version`; compare and raise `VersionConflict` on mismatch.
* Pagination: `from app.pagination import Page, PageParams, paginate` -> `{items,total,limit,offset}`.
* Money: `app.money` (Decimal only, `q()`, `time_amount()`, `vat()`); JSON money is serialised as strings; currency always explicit (GBP default).

## Audit, approvals, jobs, storage, notifications
* `ctx.audit(action, entity_type, entity_id, summary, matter_id=..., details={...})` for every record change, permission change, approval, sensitive export, agent tool action. NEVER put document/email text in details (keys like body/text/content/quote are redacted anyway).
* Approvals: `app.services.approvals.request_approval / decide / assert_approved` – bound to `canonical_hash(payload)`; content changes after approval => `ApprovalRequired(code=approval_stale)`. Four-eyes kinds are listed in `FOUR_EYES`.
* Jobs: `from app.services.jobs import enqueue, job_handler`; handlers `fn(db, job) -> dict|None` register at import in worker modules listed in `app/worker.py::HANDLER_MODULES`
  (`app.services.documents_jobs`, `app.services.export_jobs`, `app.services.task_jobs`, `app.agents.jobs`). Payloads carry ids only. Tests drain with `jobs.run_all_pending()` (call `app.worker.load_handlers()` first).
* Storage: `app.storage.get_storage()` (`put` is write-once). Notifications: `app.services.notify.notify(...)`.
* Integrations: provider classes subclass `Integration`, return `IntegrationInfo(mode="mock"|"live"|"unavailable")`, `register(...)` at import in `app/integrations/<name>.py` (names pre-listed in `integrations/__init__.py`). Mock providers must be clearly labelled in `info()` and in every user-visible result.

## Database
* Models are the contract. Do NOT create migration files (the initial migration is regenerated from the models by the integrator). If your module truly needs a schema change, edit the model in place (add nullable columns / constraints only), and list it in your final report.
* Tests build the schema from `Base.metadata` + `app/db/safeguards.sql`; the app role is non-superuser so RLS is enforced. Use `tests/factories.py` (`make_firm/make_user/make_contact/make_matter/Api`) – extend by adding new helper files, not by editing conftest/factories.
* No `float` for money. No confidential text in logs.

## Running
```
cd backend
export TEST_ADMIN_URL=postgresql+psycopg://postgres:postgres@localhost:5432/postgres   # a PostgreSQL superuser; tests create/drop throw-away databases
python -m pytest tests/<your files> -q
```
Do not `git commit`/push. Do not modify files owned by another module.

## Finance conventions (shared by finance, matters and seed)
Chart of accounts per firm (created by `app.services.ledger.ensure_chart_of_accounts(db, firm_id)`; idempotent):
office ledger: `bank_office` (asset, is_bank), `debtors` (asset), `unallocated_receipts` (liability), `fees_billed_unrecognised` (liability – billed, not yet recognised as revenue), `vat_output` (liability), `fee_income` (income), `disbursements_recoverable` (asset);
client ledger: `bank_client` (asset, is_bank) and one liability account per matter+client (`system_key="client_matter"`, `matter_id` set; created lazily by `ledger.client_account_for_matter`).
`app/services/matter_finance.py` (finance module) exports `client_balance(db, matter_id) -> Decimal` (posted client-ledger credits − debits for the matter) and `unbilled_wip(db, matter_id) -> {"time": Decimal, "expenses": Decimal, "count": int}`.
