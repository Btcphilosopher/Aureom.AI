#!/bin/sh
set -e
if [ "$1" = "api" ]; then
  echo "Applying migrations (owner connection)..."
  alembic upgrade head
  echo "Seeding demonstration data if the database is empty..."
  python -m app.seed.demo --if-empty
  exec uvicorn app.main:app --host 0.0.0.0 --port 8000
fi
exec "$@"
