# AUREOM LEGAL — frontend foundation

React 18 + TypeScript (strict) + Tailwind 3.4 + react-router 6 + TanStack Query 5 + lucide-react. System font stacks only (no external fonts/CDNs).

```bash
npm install
npm run dev          # http://localhost:5173  (proxies /api -> http://localhost:8000)
npm run typecheck    # tsc -p tsconfig.app.json --noEmit
npm run build        # tsc -b && vite build -> dist/
```
Docker: multi-stage `Dockerfile` (node build -> nginx with SPA fallback and `/api` proxy to `backend:8000`).
Hidden design reference: **/_kit** (every shared component in context).

## Layout
```
src/
  main.tsx, App.tsx          providers + routes (sections are lazy-loaded)
  lib/        api.ts (fetch wrapper, ApiError, useApiQuery/useApiMutation, qs()), auth.tsx (useAuth, useOffice),
              format.ts (exact-decimal money, en-GB dates), status.ts (status -> badge tone), a11y.ts, cn.ts
  hooks/      useDebounce, useLocalStorage, usePageTitle, useQueryParam(s), useNewParam, useMediaQuery
  types/api.ts  Me, Page<T>, SearchResponse, NotificationsResponse …  (add src/types/<domain>.ts for your pages)
  components/ui/  the UI kit — import everything from '@/components/ui'
  layout/     Shell, Sidebar, Topbar, CommandPalette, nav.ts (NAV + QUICK_CREATE), Breadcrumbs (useBreadcrumbs)
  pages/<section>/index.tsx   one directory per section — OWN YOUR DIRECTORY; do not edit shared files
```

## Rules for page authors
* **Each section's `index.tsx` default-exports a component that owns its nested `<Routes>`** (mounted at `/<section>/*`).
  Sections: home, clients, matters, documents, correspondence, tasks, billing, ledger, reports, ai, admin, portal, demo.
* **Data**: `const q = useApiQuery<Page<Matter>>(['matters', params], `/matters${qs(params)}`)` then
  `<QueryBoundary query={q}>{(data) => …}</QueryBoundary>`. QueryBoundary renders loading, 401 → /login, 403 → PermissionDenied
  (matter-specific text for `matter_access_denied`), 404 → NotFound, 503/`integration_unavailable` → IntegrationUnavailable, other errors → ErrorState with retry, and empty states.
  Include `useOffice().officeId` in query keys/params when the page should follow the office selector.
* **Mutations**: `useApiMutation((vars) => api.post('/x', vars), { invalidate: [['matters']], successMessage: 'Saved' })`.
  Errors toast by default (`errorToast: false` to handle `ApiError` inline; `err.code`, `err.details`, `err.isConflict` for 409 version conflicts).
  Always send `expected_version` on PATCH and handle 409 by reloading.
* **Tables**: `<DataTable caption columns rows rowKey loading error onRetry onRowClick sort onSortChange pagination={{total,limit,offset,onChange}} emptyTitle emptyAction />`.
  `Column<T>`: `{key, header, cell(row), numeric?, align?, sortable?, hideOnNarrow?}`. Use `numeric` for money columns.
* **Forms**: `<Field label hint error required><Input/></Field>` (wires id / aria-describedby / aria-invalid), or render-prop `{(p) => <Input {...p}/>}`.
* **Money**: values are decimal **strings**. Use `<Money value currency />` / `formatMoney()`; sum with `sumDecimal([...])` (BigInt, exact). Never `Number()`/`parseFloat()` money.
* **Status**: `<StatusBadge status="pending_approval" />`; add keys in `lib/status.ts` if needed. Use `<Badge tone="simulated">` / `<SimulatedBanner/>` for ANY mock/demonstration result (identity checks, e-signature, bank feed, OCR, AI mock provider) — never present these as verified.
* **Breadcrumbs**: `useBreadcrumbs([{label:'Matters',to:'/matters'},{label:matter.reference}])`. Title: `usePageTitle('…')`.
* **Quick-create** links open your section with a query string — handle them with `useNewParam()`:
  `/clients?new=1`, `/matters?new=1`, `/documents?new=1`, `/billing?new=time`, `/tasks?new=task`, `/tasks?new=event`, `/correspondence?new=1`, `/ai?new=1`.
* **Permissions**: `const { can } = useAuth(); can('ledger.post')` — UI hint only; the server enforces. Client-role users are redirected to `/portal`.
* **Dialogs**: `Dialog`, `ConfirmDialog` (`requireReason` for audited reasons), `Drawer` — focus-trapped, ESC to close, focus restored.
* **Evidence**: `<CitationChip documentTitle versionNo page paragraph quote onClick />` for AI/chronology citations.
* **Uploads**: `<FileDropzone accept maxSizeBytes onFiles/>` + `api.upload(path, files, fields)`. Client-side type/size checks are hints only.

## Backend contract assumed by the shell
`/auth/me|login|demo-login|personas|logout|office|sso/start`; `GET /search?q=` → `{groups:[{type,label,items:[{id,title,subtitle,href}]}]}`;
`GET /notifications` → `{items,unread}`; `POST /notifications/{id}/read`, `/notifications/read-all`. Errors: `{error:{code,message,details}}`.
CSRF: `X-CSRF-Token` (from `/auth/me`) is added to every non-GET request automatically.
