/** Formatting only. Money arrives as exact decimal strings; we format by string manipulation and never via Number(). */
const SYMBOL: Record<string, string> = { GBP: '£', EUR: '€', USD: '$' }

export function formatDecimal(value: string | number | null | undefined, opts: { dp?: number; group?: boolean } = {}): string {
  if (value === null || value === undefined || value === '') return '—'
  const dp = opts.dp ?? 2
  let s = typeof value === 'number' ? value.toFixed(dp) : String(value).trim()
  if (!/^-?\d+(\.\d+)?$/.test(s)) return s
  const neg = s.startsWith('-')
  if (neg) s = s.slice(1)
  let [int, frac = ''] = s.split('.')
  // round half-up on the string if the source has more precision than requested
  if (frac.length > dp) {
    const digits = (int + frac.slice(0, dp)).split('').map(Number)
    if (Number(frac[dp]) >= 5) {
      let i = digits.length - 1
      while (i >= 0) { if (digits[i] === 9) { digits[i] = 0; i-- } else { digits[i]++; break } }
      if (i < 0) digits.unshift(1)
    }
    const all = digits.join('')
    int = all.slice(0, all.length - dp) || '0'
    frac = all.slice(all.length - dp)
  } else frac = frac.padEnd(dp, '0')
  if (opts.group !== false) int = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  const out = dp > 0 ? `${int}.${frac}` : int
  return neg && /[1-9]/.test(out) ? `-${out}` : out
}

export function formatMoney(value: string | number | null | undefined, currency = 'GBP'): string {
  if (value === null || value === undefined || value === '') return '—'
  const body = formatDecimal(value)
  const sym = SYMBOL[currency] ?? `${currency} `
  return body.startsWith('-') ? `−${sym}${body.slice(1)}` : `${sym}${body}`
}

/** Exact decimal sum using BigInt (scale 4). Returns a decimal string with 2dp. */
export function sumDecimal(values: Array<string | null | undefined>): string {
  let total = 0n
  for (const v of values) {
    if (!v) continue
    const m = /^(-?)(\d+)(?:\.(\d+))?$/.exec(String(v).trim())
    if (!m) continue
    const scaled = BigInt(m[2] + (m[3] ?? '').padEnd(4, '0').slice(0, 4))
    total += m[1] ? -scaled : scaled
  }
  const neg = total < 0n
  const abs = (neg ? -total : total).toString().padStart(5, '0')
  const int = abs.slice(0, -4), frac = abs.slice(-4)
  // round half-up to 2dp
  const base = BigInt(int + frac.slice(0, 2)) + (Number(frac[2]) >= 5 ? 1n : 0n)
  const s = base.toString().padStart(3, '0')
  return `${neg && base !== 0n ? '-' : ''}${s.slice(0, -2)}.${s.slice(-2)}`
}

const TZ = 'Europe/London'
function toDate(v: string | Date): Date { return v instanceof Date ? v : new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v) }

export function formatDate(v: string | Date | null | undefined): string {
  if (!v) return '—'
  const d = toDate(v)
  if (isNaN(d.getTime())) return String(v)
  return new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: TZ }).format(d)
}
export function formatDateTime(v: string | Date | null | undefined): string {
  if (!v) return '—'
  const d = toDate(v)
  if (isNaN(d.getTime())) return String(v)
  return new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: TZ }).format(d)
}
export function formatTime(v: string | Date | null | undefined): string {
  if (!v) return '—'
  const d = toDate(v)
  return new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: TZ }).format(d)
}
export function relativeTime(v: string | Date | null | undefined, now: Date = new Date()): string {
  if (!v) return '—'
  const d = toDate(v)
  const diff = (d.getTime() - now.getTime()) / 1000
  const abs = Math.abs(diff)
  const rtf = new Intl.RelativeTimeFormat('en-GB', { numeric: 'auto' })
  if (abs < 60) return rtf.format(Math.round(diff), 'second')
  if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute')
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), 'hour')
  if (abs < 86400 * 30) return rtf.format(Math.round(diff / 86400), 'day')
  return formatDate(d)
}
export function formatHoursMinutes(minutes: number | null | undefined): string {
  if (minutes === null || minutes === undefined) return '—'
  const h = Math.floor(minutes / 60), m = Math.round(minutes % 60)
  return h ? (m ? `${h}h ${m}m` : `${h}h`) : `${m}m`
}
export function humanise(s: string | null | undefined): string {
  if (!s) return '—'
  const t = s.replace(/[_-]+/g, ' ').trim()
  return t.charAt(0).toUpperCase() + t.slice(1)
}
export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1048576).toFixed(1)} MB`
}
export function initialsOf(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join('')
}
