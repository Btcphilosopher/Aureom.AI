import { createContext, useCallback, useContext, useEffect, useMemo, type ReactNode } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { api, ApiError, setCsrfToken, setUnauthorizedHandler } from '@/lib/api'
import type { Me } from '@/types/api'

interface AuthState {
  me: Me | null
  loading: boolean
  permissions: ReadonlySet<string>
  /** can('matters.read') — UI hint only; the server enforces permissions again. */
  can: (perm: string) => boolean
  canAny: (...perms: string[]) => boolean
  isClientUser: boolean
  csrf: string | null
  login: (email: string, password: string) => Promise<Me>
  demoLogin: (email: string) => Promise<Me>
  logout: () => Promise<void>
  setOffice: (officeId: string | null) => Promise<void>
}

const Ctx = createContext<AuthState | null>(null)
const ME_KEY = ['auth', 'me']

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient()
  const q = useQuery<Me | null, ApiError>({
    queryKey: ME_KEY,
    queryFn: async () => { try { return await api.get<Me>('/auth/me') } catch (e) { if (e instanceof ApiError && e.status === 401) return null; throw e } },
    staleTime: 5 * 60_000, retry: false,
  })
  const me = q.data ?? null

  useEffect(() => { setCsrfToken(me?.csrf_token ?? null) }, [me])
  useEffect(() => {
    setUnauthorizedHandler(() => { setCsrfToken(null); qc.setQueryData(ME_KEY, null) })
    return () => setUnauthorizedHandler(null)
  }, [qc])

  // NB: never qc.clear() here - it detaches the live `me` observer. Drop only non-auth caches (previous user's data).
  const dropUserData = useCallback(() => qc.removeQueries({ predicate: (q) => q.queryKey[0] !== 'auth' }), [qc])
  const adopt = useCallback((m: Me) => { setCsrfToken(m.csrf_token); dropUserData(); qc.setQueryData(ME_KEY, m); return m }, [qc, dropUserData])

  const value = useMemo<AuthState>(() => {
    const permissions = new Set(me?.permissions ?? [])
    return {
      me, loading: q.isPending, permissions,
      can: (p) => permissions.has(p),
      canAny: (...ps) => ps.some((p) => permissions.has(p)),
      isClientUser: me?.role.key === 'client',
      csrf: me?.csrf_token ?? null,
      login: async (email, password) => adopt(await api.post<Me>('/auth/login', { email, password })),
      demoLogin: async (email) => adopt(await api.post<Me>('/auth/demo-login', { email })),
      logout: async () => { try { await api.post('/auth/logout') } finally { setCsrfToken(null); dropUserData(); qc.setQueryData(ME_KEY, null) } },
      setOffice: async (officeId) => {
        await api.post('/auth/office', { office_id: officeId })
        qc.setQueryData<Me | null>(ME_KEY, (m) => (m ? { ...m, active_office_id: officeId } : m))
        qc.invalidateQueries({ predicate: (query) => query.queryKey[0] !== 'auth' })
      },
    }
  }, [me, q.isPending, adopt, dropUserData, qc])

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth(): AuthState {
  const v = useContext(Ctx)
  if (!v) throw new Error('useAuth must be used inside <AuthProvider>')
  return v
}

/** Office / team selector state. Include `officeId` in query keys/params to filter by the selected office. */
export function useOffice() {
  const { me, setOffice } = useAuth()
  return { officeId: me?.active_office_id ?? null, offices: me?.offices ?? [], setOfficeId: setOffice, activeOffice: me?.offices.find((o) => o.id === me.active_office_id) ?? null }
}
