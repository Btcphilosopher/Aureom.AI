export type Tone = 'neutral' | 'info' | 'success' | 'warning' | 'danger' | 'brass' | 'simulated'

const MAP: Record<string, Tone> = {}
const set = (tone: Tone, ...keys: string[]) => keys.forEach((k) => (MAP[k] = tone))
set('success', 'approved', 'completed', 'paid', 'issued', 'signed', 'cleared_by_reviewer', 'clean', 'confirmed', 'done', 'executed', 'posted', 'reconciled',
  'signed_off', 'allocated', 'met', 'accepted', 'active', 'ready', 'sent', 'filed', 'false_positive', 'passed')
set('warning', 'pending', 'pending_approval', 'awaiting_review', 'in_review', 'suggested', 'paused', 'needs_review', 'partially_paid', 'awaiting_client',
  'proposed', 'received_unallocated', 'partially_allocated', 'unmatched', 'referred', 'pending_review', 'signature_requested', 'unreviewed', 'potential_conflict',
  'prospect', 'prospective', 'blocked', 'unavailable')
set('danger', 'failed', 'rejected', 'overdue', 'infected', 'conflict_confirmed', 'confirmed_conflict', 'missed', 'void', 'cancelled', 'denied', 'error', 'urgent')
set('info', 'open', 'queued', 'running', 'in_progress', 'executing', 'received', 'matched', 'building', 'draft_ai')
set('neutral', 'draft', 'closed', 'inactive', 'superseded', 'not_started', 'not_required', 'merged', 'waived', 'normal', 'low')
set('simulated', 'passed_simulated', 'simulated', 'mock')
set('brass', 'restricted', 'ethical_wall', 'legal_hold', 'high')

export function statusTone(status: string | null | undefined): Tone {
  return (status && MAP[status.toLowerCase()]) || 'neutral'
}
