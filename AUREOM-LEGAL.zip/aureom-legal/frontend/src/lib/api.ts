import { QueryClient, useMutation, useQuery, useQueryClient, type QueryKey, type UseMutationOptions, type UseQueryOptions } from '@tanstack/react-query'
import type { ApiErrorBody } from '@/types/api'
import { useToast } from '@/components/ui/Toast'

const BASE = `${import.meta.env.VITE_API_BASE ?? ''}/api/v1`

export class ApiError extends Error {
  status: number
  code: string
  details: Record<string, unknown>
  constructor(status: number, code: string, message: string, details: Record<string, unknown> = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = status; this.code = code; this.details = details
  }
  get isPermission() { return this.status === 403 }
  get isIntegrationUnavailable() { return this.status === 503 || this.code === 'integration_unavailable' }
  get isConflict() { return this.status === 409 }
}

let csrfToken: string | null = null
export function setCsrfToken(t: string | null) { csrfToken = t }

let unauthorizedHandler: (() => void) | null = null
export function setUnauthorizedHandler(fn: (() => void) | null) { unauthorizedHandler = fn }

const AUTH_PATHS = ['/auth/me', '/auth/login', '/auth/demo-login', '/auth/personas']

export function qs(params: Record<string, string | number | boolean | null | undefined | string[]>): string {
  const u = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === '') continue
    if (Array.isArray(v)) v.forEach((x) => u.append(k, x)); else u.set(k, String(v))
  }
  const s = u.toString()
  return s ? `?${s}` : ''
}

async function request<T>(method: string, path: string, body?: unknown, init: { form?: FormData; raw?: boolean } = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' }
  let payload: BodyInit | undefined
  if (init.form) payload = init.form
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body) }
  if (method !== 'GET' && csrfToken) headers['X-CSRF-Token'] = csrfToken
  let res: Response
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: payload, credentials: 'include' })
  } catch {
    throw new ApiError(0, 'network_error', 'Could not reach the server. Check your connection and try again.')
  }
  if (res.status === 204) return undefined as T
  const ctype = res.headers.get('content-type') ?? ''
  if (!res.ok) {
    let code = 'http_error', message = res.statusText || 'Request failed', details: Record<string, unknown> = {}
    if (ctype.includes('json')) {
      try {
        const j = (await res.json()) as Partial<ApiErrorBody> & { detail?: unknown }
        if (j.error) { code = j.error.code; message = j.error.message; details = j.error.details ?? {} }
        else if (j.detail) { code = 'validation_failed'; message = typeof j.detail === 'string' ? j.detail : 'The request was not valid.'; details = { detail: j.detail } }
      } catch { /* fall through */ }
    }
    if (res.status === 401 && !AUTH_PATHS.some((p) => path.startsWith(p))) unauthorizedHandler?.()
    throw new ApiError(res.status, code, message, details)
  }
  if (init.raw) return res as unknown as T
  return (ctype.includes('json') ? await res.json() : await res.text()) as T
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body ?? {}),
  patch: <T>(path: string, body?: unknown) => request<T>('PATCH', path, body ?? {}),
  put: <T>(path: string, body?: unknown) => request<T>('PUT', path, body ?? {}),
  delete: <T>(path: string) => request<T>('DELETE', path),
  /** multipart/form-data upload: fields are appended as strings, files as-is. */
  upload: <T>(path: string, files: File | File[] | Record<string, File | File[]>, fields: Record<string, string | number | boolean | null | undefined> = {}, fileField = 'file') => {
    const form = new FormData()
    for (const [k, v] of Object.entries(fields)) if (v !== undefined && v !== null) form.append(k, String(v))
    const add = (name: string, f: File | File[]) => (Array.isArray(f) ? f.forEach((x) => form.append(name, x)) : form.append(name, f))
    if (files instanceof File || Array.isArray(files)) add(fileField, files as File | File[])
    else for (const [k, v] of Object.entries(files)) add(k, v)
    return request<T>('POST', path, undefined, { form })
  },
  /** URL for browser navigation / downloads (cookie-authenticated GETs). */
  url: (path: string) => `${BASE}${path}`,
  /** Fetch a binary/text response without JSON parsing (e.g. CSV exports). */
  blob: async (path: string): Promise<Blob> => (await request<Response>('GET', path, undefined, { raw: true })).blob(),
}

const NO_RETRY = new Set([0, 400, 401, 403, 404, 409, 422, 429, 503])
export function makeQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { staleTime: 15_000, refetchOnWindowFocus: false, retry: (n, err) => !(err instanceof ApiError && NO_RETRY.has(err.status)) && n < 2 },
      mutations: { retry: false },
    },
  })
}

/** Thin wrapper: pass a path (GET) or a fetcher. Errors surface as ApiError; render with <QueryBoundary>. */
export function useApiQuery<T>(key: QueryKey, source: string | (() => Promise<T>), options: Omit<UseQueryOptions<T, ApiError, T, QueryKey>, 'queryKey' | 'queryFn'> = {}) {
  return useQuery<T, ApiError, T, QueryKey>({ queryKey: key, queryFn: typeof source === 'string' ? () => api.get<T>(source) : source, ...options })
}

export interface ApiMutationOptions<TData, TVars> extends Omit<UseMutationOptions<TData, ApiError, TVars>, 'mutationFn'> {
  /** Query keys (prefix match) to invalidate on success. */
  invalidate?: QueryKey[]
  successMessage?: string | ((data: TData) => string)
  /** Show a toast on error (default true). Set false to handle ApiError in the form. */
  errorToast?: boolean
}

export function useApiMutation<TData = unknown, TVars = void>(fn: (vars: TVars) => Promise<TData>, opts: ApiMutationOptions<TData, TVars> = {}) {
  const qc = useQueryClient()
  const toast = useToast()
  const { invalidate, successMessage, errorToast = true, onSuccess, onError, ...rest } = opts
  return useMutation<TData, ApiError, TVars>({
    mutationFn: fn,
    ...rest,
    onSuccess: (data, vars, ctx) => {
      invalidate?.forEach((k) => qc.invalidateQueries({ queryKey: k }))
      if (successMessage) toast.push({ tone: 'success', title: typeof successMessage === 'function' ? successMessage(data) : successMessage })
      return onSuccess?.(data, vars, ctx)
    },
    onError: (err, vars, ctx) => {
      if (errorToast && !(err.status === 401)) {
        toast.push({ tone: 'danger', title: err.status === 403 ? 'Not permitted' : err.isConflict ? 'Conflict' : 'Something went wrong', description: err.message })
      }
      return onError?.(err, vars, ctx)
    },
  })
}
