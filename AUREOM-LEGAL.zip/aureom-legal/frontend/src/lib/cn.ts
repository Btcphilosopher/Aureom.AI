export type ClassValue = string | false | null | undefined | ClassValue[]
export function cn(...v: ClassValue[]): string {
  const out: string[] = []
  const walk = (x: ClassValue) => { if (!x) return; if (Array.isArray(x)) x.forEach(walk); else out.push(x) }
  v.forEach(walk)
  return out.join(' ')
}
