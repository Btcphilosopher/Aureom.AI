import { NavLink } from 'react-router-dom'
import { PlayCircle } from 'lucide-react'
import { cn } from '@/lib/cn'
import { useAuth } from '@/lib/auth'
import { Tooltip } from '@/components/ui/Menu'
import { NAV, PORTAL_NAV, type NavEntry } from './nav'

export function Wordmark({ compact }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-navy-900 ring-1 ring-brass-500/60" aria-hidden>
        <svg viewBox="0 0 32 32" className="h-5 w-5"><path d="M16 6l8 18h-3.2l-1.6-3.8h-6.4L11.2 24H8l8-18zm0 6.2L13.8 17h4.4L16 12.2z" fill="#C9A961" /></svg>
      </span>
      {!compact && (
        <div className="leading-tight">
          <p className="font-serif text-[1.05rem] tracking-[0.12em] text-white">AUREOM LEGAL</p>
          <p className="text-2xs tracking-wide text-brass-300">Practice Database &amp; Intelligence</p>
        </div>
      )}
    </div>
  )
}

export function Sidebar() {
  const { can, canAny, isClientUser, me } = useAuth()
  const entries = isClientUser ? PORTAL_NAV : NAV
  const allowed = (e: NavEntry) => e.perms.length === 0 || canAny(...e.perms)
  const base = 'group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-300'
  return (
    <aside data-app-sidebar className="sticky top-0 flex h-screen w-16 shrink-0 flex-col bg-navy-950 text-navy-100 lg:w-64">
      <div className="flex h-16 items-center border-b border-white/10 px-3.5 lg:px-5"><span className="lg:hidden"><Wordmark compact /></span><span className="hidden lg:block"><Wordmark /></span></div>
      <nav aria-label="Primary" className="flex-1 space-y-0.5 overflow-y-auto px-2 py-4 lg:px-3">
        {entries.map((e) => {
          const Icon = e.icon
          const ok = allowed(e)
          const label = <span className="hidden truncate lg:inline">{e.label}</span>
          if (!ok) {
            return (
              <Tooltip key={e.to} side="right" text={`Requires permission: ${e.permHint}`}>
                <span role="link" aria-disabled="true" tabIndex={0} className={cn(base, 'cursor-not-allowed text-navy-400/70')}><Icon className="h-[18px] w-[18px] shrink-0" aria-hidden />{label}<span className="sr-only lg:hidden">{e.label}</span></span>
              </Tooltip>
            )
          }
          return (
            <NavLink key={e.to} to={e.to} end={e.to === '/'} title={e.label}
              className={({ isActive }) => cn(base, isActive ? 'bg-white/10 text-white shadow-[inset_3px_0_0_#C9A961]' : 'text-navy-200 hover:bg-white/5 hover:text-white')}>
              <Icon className="h-[18px] w-[18px] shrink-0" aria-hidden />{label}<span className="sr-only lg:hidden">{e.label}</span>
            </NavLink>
          )
        })}
      </nav>
      <div className="space-y-2 border-t border-white/10 p-3">
        {me?.demo_mode && !isClientUser && can('matters.read') && (
          <NavLink to="/demo" title="Guided demonstration" className={({ isActive }) => cn(base, 'text-brass-300 hover:bg-white/5', isActive && 'bg-white/10')}><PlayCircle className="h-[18px] w-[18px] shrink-0" aria-hidden /><span className="hidden lg:inline">Guided demonstration</span></NavLink>
        )}
        <p className="hidden px-3 text-2xs leading-snug text-navy-400 lg:block">{me?.firm.name}<br />Synthetic data · demonstration build</p>
      </div>
    </aside>
  )
}
