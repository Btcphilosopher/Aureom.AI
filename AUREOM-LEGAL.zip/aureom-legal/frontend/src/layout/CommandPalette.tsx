import { useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Loader2, Search } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { api, qs } from '@/lib/api'
import { useDebounce } from '@/hooks'
import { useFocusTrap } from '@/lib/a11y'
import { cn } from '@/lib/cn'
import type { SearchResponse } from '@/types/api'
import { ApiError } from '@/lib/api'

/** Global search palette (Ctrl/Cmd+K). Results are permission-filtered by the server (ethical walls included). */
export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState('')
  const [active, setActive] = useState(0)
  const dq = useDebounce(q.trim(), 200)
  const nav = useNavigate()
  const ref = useRef<HTMLDivElement>(null)
  useFocusTrap(ref, open, onClose)
  useEffect(() => { if (open) { setQ(''); setActive(0) } }, [open])
  const res = useQuery<SearchResponse, ApiError>({ queryKey: ['search', dq], queryFn: () => api.get<SearchResponse>(`/search${qs({ q: dq })}`), enabled: open && dq.length >= 2, staleTime: 10_000, retry: false })
  const flat = useMemo(() => (res.data?.groups ?? []).flatMap((g) => g.items.map((i) => ({ ...i, group: g.label }))), [res.data])
  useEffect(() => setActive(0), [dq])
  if (!open) return null
  const go = (href: string) => { onClose(); nav(href) }
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive((a) => Math.min(a + 1, flat.length - 1)) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)) }
    else if (e.key === 'Enter' && flat[active]) { e.preventDefault(); go(flat[active]!.href) }
  }
  let idx = -1
  return createPortal(
    <div className="fixed inset-0 z-[60] flex items-start justify-center bg-navy-950/55 p-4 pt-[12vh] animate-fade-in" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label="Global search" className="w-full max-w-xl animate-slide-up overflow-hidden rounded-lg bg-white shadow-pop" onKeyDown={onKey}>
        <div className="flex items-center gap-3 border-b border-stone-200 px-4">
          <Search className="h-4 w-4 text-stone-500" aria-hidden />
          <input data-autofocus value={q} onChange={(e) => setQ(e.target.value)} role="combobox" aria-expanded aria-controls="palette-results" aria-activedescendant={flat[active] ? `pal-${flat[active]!.id}` : undefined} aria-label="Search clients, matters, documents, correspondence"
            placeholder="Search clients, matters, documents, correspondence…" className="h-12 flex-1 bg-transparent text-sm text-navy-900 placeholder:text-stone-500 focus:outline-none" />
          {res.isFetching && <Loader2 className="h-4 w-4 animate-spin text-stone-500" aria-label="Searching" />}
          <kbd className="rounded border border-stone-300 px-1.5 text-2xs text-stone-600">Esc</kbd>
        </div>
        <div id="palette-results" role="listbox" className="max-h-[50vh] overflow-y-auto p-2">
          {dq.length < 2 && <p className="px-3 py-6 text-center text-sm text-stone-600">Type at least two characters. Results only include records you are permitted to see.</p>}
          {res.isError && <p role="alert" className="px-3 py-6 text-center text-sm text-bad-700">{res.error.status === 403 ? 'Search is not permitted for your role.' : res.error.message}</p>}
          {res.data && flat.length === 0 && dq.length >= 2 && !res.isFetching && <p className="px-3 py-6 text-center text-sm text-stone-600">No results for “{dq}”.</p>}
          {res.data?.groups.filter((g) => g.items.length).map((g) => (
            <div key={g.type} role="group" aria-label={g.label} className="mb-1">
              <p className="px-3 pb-1 pt-2 text-2xs font-semibold uppercase tracking-wider text-stone-600">{g.label}</p>
              {g.items.map((it) => {
                idx++; const i = idx
                return (
                  <button key={it.id} id={`pal-${it.id}`} role="option" aria-selected={i === active} onMouseEnter={() => setActive(i)} onClick={() => go(it.href)}
                    className={cn('flex w-full flex-col rounded-md px-3 py-2 text-left', i === active ? 'bg-brass-50 ring-1 ring-brass-300' : 'hover:bg-ivory-100')}>
                    <span className="text-sm text-navy-900">{it.title}</span>{it.subtitle && <span className="text-xs text-stone-600">{it.subtitle}</span>}
                  </button>
                )
              })}
            </div>
          ))}
        </div>
      </div>
    </div>, document.body)
}
