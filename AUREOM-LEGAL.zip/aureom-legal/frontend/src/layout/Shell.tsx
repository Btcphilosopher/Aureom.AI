import { Suspense } from 'react'
import { Outlet } from 'react-router-dom'
import { Breadcrumbs } from '@/components/ui/Nav'
import { LoadingState } from '@/components/ui/States'
import { useCrumbs } from './Breadcrumbs'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'

export function Shell() {
  const crumbs = useCrumbs()
  return (
    <div className="flex min-h-screen">
      <a href="#main" className="skip-link">Skip to main content</a>
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main id="main" tabIndex={-1} className="flex-1 px-6 py-6 focus:outline-none lg:px-10">
          <div className="mx-auto w-full max-w-[1400px]">
            {crumbs.length > 0 && <Breadcrumbs items={crumbs} className="mb-3" />}
            <Suspense fallback={<LoadingState label="Loading section…" />}><Outlet /></Suspense>
          </div>
        </main>
      </div>
    </div>
  )
}
