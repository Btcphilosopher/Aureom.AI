import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Crumb } from '@/components/ui/Nav'

interface Ctx { crumbs: Crumb[]; setCrumbs: (c: Crumb[]) => void }
const C = createContext<Ctx>({ crumbs: [], setCrumbs: () => undefined })

export function BreadcrumbProvider({ children }: { children: ReactNode }) {
  const [crumbs, setCrumbs] = useState<Crumb[]>([])
  const v = useMemo(() => ({ crumbs, setCrumbs }), [crumbs])
  return <C.Provider value={v}>{children}</C.Provider>
}
export const useCrumbs = () => useContext(C).crumbs

/** Pages call useBreadcrumbs([{label:'Matters', to:'/matters'}, {label: matter.reference}]) to fill the shell's breadcrumb outlet. */
export function useBreadcrumbs(items: Crumb[]) {
  const { setCrumbs } = useContext(C)
  const key = JSON.stringify(items)
  useEffect(() => { setCrumbs(JSON.parse(key) as Crumb[]); return () => setCrumbs([]) }, [key, setCrumbs])
}
