import { Bot, Briefcase, CalendarCheck, FileText, Home, Landmark, Mail, PieChart, Receipt, Settings, Users, type LucideIcon } from 'lucide-react'

export interface NavEntry { to: string; label: string; icon: LucideIcon; /** user needs ANY of these */ perms: string[]; permHint: string }

export const NAV: NavEntry[] = [
  { to: '/', label: 'Home', icon: Home, perms: [], permHint: '' },
  { to: '/clients', label: 'Clients', icon: Users, perms: ['clients.read'], permHint: 'clients.read' },
  { to: '/matters', label: 'Matters', icon: Briefcase, perms: ['matters.read'], permHint: 'matters.read' },
  { to: '/documents', label: 'Documents', icon: FileText, perms: ['documents.read'], permHint: 'documents.read' },
  { to: '/correspondence', label: 'Correspondence', icon: Mail, perms: ['correspondence.read'], permHint: 'correspondence.read' },
  { to: '/tasks', label: 'Tasks & Diary', icon: CalendarCheck, perms: ['tasks.read'], permHint: 'tasks.read' },
  { to: '/billing', label: 'Time & Billing', icon: Receipt, perms: ['billing.read', 'time.write'], permHint: 'billing.read or time.write' },
  { to: '/ledger', label: 'Client Ledger', icon: Landmark, perms: ['ledger.read'], permHint: 'ledger.read' },
  { to: '/reports', label: 'Reports', icon: PieChart, perms: ['reports.read', 'reports.financial'], permHint: 'reports.read' },
  { to: '/ai', label: 'AI Workspace', icon: Bot, perms: ['ai.use', 'ai.review', 'ai.admin'], permHint: 'ai.use' },
  { to: '/admin', label: 'Administration', icon: Settings, perms: ['admin.users', 'admin.settings', 'audit.read'], permHint: 'admin.settings or audit.read' },
]
export const PORTAL_NAV: NavEntry[] = [{ to: '/portal', label: 'My matters', icon: Briefcase, perms: [], permHint: '' }]

/** Quick-create targets. Page forks: each route must honour the query string (see useNewParam in src/hooks). */
export const QUICK_CREATE = [
  { label: 'New prospective client', to: '/clients?new=1', perm: 'clients.write' },
  { label: 'New matter', to: '/matters?new=1', perm: 'matters.create' },
  { label: 'Upload document', to: '/documents?new=1', perm: 'documents.write' },
  { label: 'Log time', to: '/billing?new=time', perm: 'time.write' },
  { label: 'New task', to: '/tasks?new=task', perm: 'tasks.write' },
  { label: 'New diary event', to: '/tasks?new=event', perm: 'tasks.write' },
  { label: 'Draft correspondence', to: '/correspondence?new=1', perm: 'correspondence.write' },
  { label: 'Start AI agent', to: '/ai?new=1', perm: 'ai.use' },
] as const
