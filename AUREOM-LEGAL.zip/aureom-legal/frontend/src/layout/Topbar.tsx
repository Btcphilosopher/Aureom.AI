import { useEffect, useState } from 'react'

import { Bell, Building2, ChevronDown, FlaskConical, LogOut, Plus, Search, UserCircle2 } from 'lucide-react'
import { useQueryClient } from '@tanstack/react-query'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth, useOffice } from '@/lib/auth'
import { relativeTime } from '@/lib/format'
import { cn } from '@/lib/cn'
import { Avatar } from '@/components/ui/Nav'
import { Button, IconButton } from '@/components/ui/Button'
import { DropdownMenu } from '@/components/ui/Menu'
import { Select } from '@/components/ui/Form'
import type { NotificationsResponse } from '@/types/api'
import { CommandPalette } from './CommandPalette'
import { QUICK_CREATE } from './nav'

function Notifications() {
  const qc = useQueryClient()
  const q = useApiQuery<NotificationsResponse>(['notifications'], '/notifications', { refetchInterval: 60_000, retry: false })
  const read = useApiMutation((id: string) => api.post(`/notifications/${id}/read`), { errorToast: false, onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }) })
  const readAll = useApiMutation(() => api.post('/notifications/read-all'), { errorToast: false, onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }) })
  const unread = q.data?.unread ?? 0
  return (
    <DropdownMenu label="Notifications" trigger={({ props }) => (
      <button {...props} aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`} className="relative flex h-9 w-9 items-center justify-center rounded-md text-stone-600 hover:bg-navy-50 hover:text-navy-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
        <Bell className="h-[18px] w-[18px]" aria-hidden />{unread > 0 && <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-brass-600 px-1 text-[10px] font-bold text-white">{unread > 9 ? '9+' : unread}</span>}
      </button>)}
      items={q.isError ? [{ label: 'Notifications unavailable', disabled: true }] : q.data?.items.length ? [
        ...q.data.items.slice(0, 8).map((n) => ({ key: n.id, label: <span className={cn('block max-w-[18rem] whitespace-normal', !n.read_at && 'font-semibold')}>{n.title}<span className="block text-xs font-normal text-stone-600">{relativeTime(n.created_at)}</span></span>, to: n.link ?? undefined, onSelect: () => { if (!n.read_at) read.mutate(n.id) } })),
        { key: 'all', label: 'Mark all as read', onSelect: () => readAll.mutate(), separatorBefore: true, disabled: unread === 0 },
      ] : [{ label: 'You are all caught up', disabled: true }]} />
  )
}

function OfficeSelector() {
  const { officeId, offices, setOfficeId } = useOffice()
  if (offices.length < 2) return null
  return (
    <label className="hidden w-44 shrink-0 items-center gap-2 md:flex">
      <Building2 className="h-4 w-4 text-stone-500" aria-hidden /><span className="sr-only">Office filter</span>
      <Select aria-label="Office filter" value={officeId ?? ''} onChange={(e) => void setOfficeId(e.target.value || null)} className="h-8 min-w-0 flex-1 text-xs">
        <option value="">All offices</option>{offices.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
      </Select>
    </label>
  )
}

export function Topbar() {
  const { me, can, logout, isClientUser } = useAuth()
  const [palette, setPalette] = useState(false)
  useEffect(() => {
    const f = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette((p) => !p) } }
    window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f)
  }, [])
  const create = QUICK_CREATE.filter((c) => can(c.perm))
  return (
    <header data-app-topbar className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-stone-200 bg-ivory-50/95 px-6 backdrop-blur">
      {!isClientUser && (
        <button onClick={() => setPalette(true)} className="flex h-9 w-full max-w-md items-center gap-2 rounded-md border border-stone-300 bg-white px-3 text-left text-sm text-stone-600 hover:border-brass-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500" aria-label="Open global search (Control K)">
          <Search className="h-4 w-4" aria-hidden /><span className="flex-1 truncate">Search clients, matters, documents…</span><kbd className="hidden rounded border border-stone-300 px-1.5 text-2xs sm:block">Ctrl K</kbd>
        </button>
      )}
      <div className="ml-auto flex items-center gap-2">
        {me?.demo_mode && <span className="hidden items-center gap-1 rounded border border-dashed border-sim-600/60 bg-sim-50 px-2 py-1 text-2xs font-semibold uppercase tracking-wide text-sim-700 xl:inline-flex" title="Synthetic data. Integrations are simulated."><FlaskConical className="h-3 w-3" aria-hidden />Demonstration</span>}
        {!isClientUser && <OfficeSelector />}
        {create.length > 0 && (
          <DropdownMenu label="Quick create" trigger={({ props }) => <Button {...props} size="md" variant="brass" icon={<Plus className="h-4 w-4" />}><span className="hidden sm:inline">New</span><ChevronDown className="h-3.5 w-3.5" aria-hidden /></Button>}
            items={create.map((c) => ({ key: c.label, label: c.label, to: c.to }))} />
        )}
        <Notifications />
        <DropdownMenu label="Account" trigger={({ props }) => (
          <button {...props} className="flex items-center gap-2 rounded-md p-1 pr-2 hover:bg-navy-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500" aria-label={`Account menu for ${me?.user.name}`}>
            <Avatar name={me?.user.name ?? '?'} /><span className="hidden text-left leading-tight md:block"><span className="block text-xs font-semibold text-navy-900">{me?.user.name}</span><span className="block text-2xs text-stone-600">{me?.role.name}</span></span>
          </button>)}
          items={[
            { key: 'who', label: <span><span className="block text-sm font-medium">{me?.user.email}</span><span className="block text-xs text-stone-600">{me?.firm.name} · data residency {me?.firm.data_residency.toUpperCase()}</span></span>, icon: <UserCircle2 className="h-4 w-4" />, disabled: true },
            { key: 'out', label: 'Sign out', icon: <LogOut className="h-4 w-4" />, onSelect: () => void logout(), separatorBefore: true },
          ]} />
      </div>
      <CommandPalette open={palette} onClose={() => setPalette(false)} />
    </header>
  )
}
