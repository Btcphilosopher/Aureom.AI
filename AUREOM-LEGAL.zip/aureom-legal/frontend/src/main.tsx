import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { ToastProvider } from '@/components/ui/Toast'
import { makeQueryClient } from '@/lib/api'
import { AuthProvider } from '@/lib/auth'
import { BreadcrumbProvider } from '@/layout/Breadcrumbs'
import './index.css'

const queryClient = makeQueryClient()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <ToastProvider>
          <AuthProvider>
            <BreadcrumbProvider>
              <App />
            </BreadcrumbProvider>
          </AuthProvider>
        </ToastProvider>
      </BrowserRouter>
    </QueryClientProvider>
  </StrictMode>,
)
