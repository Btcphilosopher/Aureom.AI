import { useCallback, useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'

export function useDebounce<T>(value: T, ms = 250): T {
  const [v, setV] = useState(value)
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t) }, [value, ms])
  return v
}

export function useLocalStorage<T>(key: string, initial: T): [T, (v: T) => void] {
  const [val, setVal] = useState<T>(() => {
    try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : initial } catch { return initial }
  })
  const set = useCallback((v: T) => { setVal(v); try { localStorage.setItem(key, JSON.stringify(v)) } catch { /* storage unavailable */ } }, [key])
  return [val, set]
}

export function usePageTitle(title: string) {
  useEffect(() => { const prev = document.title; document.title = `${title} · AUREOM LEGAL`; return () => { document.title = prev } }, [title])
}

/** Query-string state helper: const [q, setQ] = useQueryParam('q'); setQ(undefined) removes it. */
export function useQueryParam(name: string): [string | null, (v: string | null | undefined) => void] {
  const [params, setParams] = useSearchParams()
  const value = params.get(name)
  const set = useCallback((v: string | null | undefined) => {
    setParams((prev) => { const n = new URLSearchParams(prev); if (v === null || v === undefined || v === '') n.delete(name); else n.set(name, v); return n }, { replace: true })
  }, [name, setParams])
  return [value, set]
}

/** Several params at once. */
export function useQueryParams<K extends string>(names: readonly K[]): [Record<K, string | null>, (patch: Partial<Record<K, string | null | undefined>>) => void] {
  const [params, setParams] = useSearchParams()
  const values = useMemo(() => Object.fromEntries(names.map((n) => [n, params.get(n)])) as Record<K, string | null>, [params, names])
  const set = useCallback((patch: Partial<Record<K, string | null | undefined>>) => {
    setParams((prev) => {
      const n = new URLSearchParams(prev)
      for (const [k, v] of Object.entries(patch) as [string, string | null | undefined][]) { if (v === null || v === undefined || v === '') n.delete(k); else n.set(k, v) }
      return n
    }, { replace: true })
  }, [setParams])
  return [values, set]
}

/** True when the URL carries ?new=1 (quick-create entry point). `clear()` removes it. */
export function useNewParam(): { isNew: boolean; kind: string | null; clear: () => void } {
  const [params, setParams] = useSearchParams()
  const kind = params.get('new')
  return { isNew: !!kind, kind, clear: () => setParams((p) => { const n = new URLSearchParams(p); n.delete('new'); return n }, { replace: true }) }
}

export function useMediaQuery(query: string): boolean {
  const [m, setM] = useState(() => (typeof window !== 'undefined' ? window.matchMedia(query).matches : false))
  useEffect(() => { const mq = window.matchMedia(query); const f = () => setM(mq.matches); mq.addEventListener('change', f); return () => mq.removeEventListener('change', f) }, [query])
  return m
}
