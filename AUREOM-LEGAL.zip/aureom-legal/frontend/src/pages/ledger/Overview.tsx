import { Link } from 'react-router-dom'
import { ArrowRight, Landmark, ShieldAlert, Users } from 'lucide-react'
import { useApiQuery } from '@/lib/api'
import { Badge, Card, ErrorState, Money, Skeleton } from '@/components/ui'
import { subDecimal } from '@/pages/billing/shared'
import { FINANCE_KINDS } from './common'
import type { ApprovalRow, LedgerAccount, LedgerKey, Page, TrialBalance } from '@/types/finance'

function LedgerCard({ ledger }: { ledger: LedgerKey }) {
  const tb = useApiQuery<TrialBalance>(['ledger', 'tb', ledger], `/ledger/trial-balance?ledger=${ledger}`)
  const accts = useApiQuery<LedgerAccount[]>(['ledger', 'accounts', ledger], `/ledger/accounts?ledger=${ledger}`)
  const bank = accts.data?.find((a) => a.is_bank)
  const isClient = ledger === 'client'
  return (
    <Card className={isClient ? 'border-t-4 border-t-brass-500' : 'border-t-4 border-t-navy-600'}
      title={<span className="flex items-center gap-2">{isClient ? <Users className="h-4 w-4 text-brass-600" aria-hidden /> : <Landmark className="h-4 w-4 text-navy-600" aria-hidden />}{isClient ? 'Client funds ledger' : 'Office ledger'}</span>}
      description={isClient ? "Money held for clients. Never the firm's money; never revenue." : "The firm's own money: receivables, unallocated receipts, billed fees."}
      actions={<Link to={`/ledger/accounts?ledger=${ledger}`} className="inline-flex items-center gap-1 text-xs font-medium text-navy-700 hover:underline">Accounts <ArrowRight className="h-3 w-3" aria-hidden /></Link>}>
      {tb.isPending ? <Skeleton className="h-20" /> : tb.isError ? <ErrorState error={tb.error} onRetry={() => void tb.refetch()} /> : (
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between"><dt className="text-stone-700">Bank account balance (ledger)</dt><dd className="font-serif text-xl"><Money value={bank?.balance ?? '0.00'} /></dd></div>
          <div className="flex justify-between"><dt className="text-stone-700">Total debits</dt><dd><Money value={tb.data.total_debit} /></dd></div>
          <div className="flex justify-between"><dt className="text-stone-700">Total credits</dt><dd><Money value={tb.data.total_credit} /></dd></div>
          <div className="flex items-center justify-between border-t border-stone-200 pt-2"><dt className="font-medium">Trial balance</dt>
            <dd>{tb.data.balanced ? <Badge tone="success">Balanced</Badge> : <Badge tone="danger">Out by <Money value={subDecimal(tb.data.total_debit, tb.data.total_credit)} /></Badge>}</dd></div>
        </dl>)}
    </Card>
  )
}

export default function Overview() {
  const waiting = useApiQuery<{ items: ApprovalRow[] }>(['approvals', 'waiting', 'ledger'], '/approvals?scope=waiting_for_me&limit=100')
  const n = waiting.data?.items.filter((a) => (FINANCE_KINDS as readonly string[]).includes(a.kind)).length ?? 0
  return (
    <div className="space-y-6">
      <div className="grid gap-6 xl:grid-cols-2"><LedgerCard ledger="office" /><LedgerCard ledger="client" /></div>
      <Card title="Authorisations waiting for you" actions={<Link to="/ledger/authorisations" className="text-xs font-medium text-navy-700 hover:underline">Open <ArrowRight className="inline h-3 w-3" aria-hidden /></Link>}>
        <div className="flex items-center gap-3 text-sm"><ShieldAlert className="h-5 w-5 text-brass-600" aria-hidden />
          {waiting.isPending ? 'Checking…' : n === 0 ? 'Nothing is waiting for your authorisation.' : <span><strong className="tabular-nums">{n}</strong> posting{n === 1 ? '' : 's'} need your authorisation. You cannot authorise something you prepared yourself.</span>}</div>
      </Card>
      <Card title="How the pieces fit — billed, received, allocated, reconciled, recognised">
        <ol className="grid gap-3 text-sm sm:grid-cols-5">
          {[['Invoice issued', 'A receivable is recorded. Not revenue, not cash.'], ['Receipt recorded', 'Cash arrives and sits in “unallocated receipts”. Not earned.'], ['Allocated', 'A different person authorises matching the receipt to an invoice.'], ['Reconciled', 'Bank statement agrees to the ledger; signed off by a second person.'], ['Revenue recognised', 'A separate, separately authorised step with a stated basis.']].map(([t, d], i) => (
            <li key={t} className="rounded-md bg-ivory-100 p-3"><p className="text-2xs font-semibold uppercase tracking-wide text-brass-700">Step {i + 1}</p><p className="font-medium text-navy-900">{t}</p><p className="mt-1 text-xs text-stone-700">{d}</p></li>))}
        </ol>
      </Card>
    </div>
  )
}
