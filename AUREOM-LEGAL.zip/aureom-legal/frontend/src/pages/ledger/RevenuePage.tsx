import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, DataTable, DateTime, Dialog, Field, Input, Money, StatCard, Textarea, type Column } from '@/components/ui'
import { isMoneyInput, MatterLink, Notice, todayIso } from '@/pages/billing/shared'
import type { Invoice, Journal, Page, ReportData, RevenueRecognitionRow } from '@/types/finance'
import { useNavigate } from 'react-router-dom'

function RecogniseDialog({ inv, onClose }: { inv: Invoice | null; onClose: () => void }) {
  const nav = useNavigate()
  const [amount, setAmount] = useState('')
  const [basis, setBasis] = useState('')
  const [date, setDate] = useState(todayIso())
  const [err, setErr] = useState<ApiError | null>(null)
  const go = useApiMutation(() => api.post<Journal>('/ledger/revenue-recognition', { invoice_id: inv!.id, amount: amount.trim(), basis: basis.trim(), recognised_on: date }),
    { invalidate: [['ledger'], ['approvals']], errorToast: false, successMessage: 'Recognition journal prepared — awaiting authorisation', onSuccess: (j) => { onClose(); nav(`/ledger/journals/${j.id}`) }, onError: setErr })
  const sub = inv?.subtotal ?? '0.00'
  return (
    <Dialog open={!!inv} onClose={onClose} title={`Recognise revenue — ${inv?.number ?? ''}`}
      description="This is a separate accounting decision. It prepares a journal (Dr fees billed – not yet recognised / Cr fee income) that a different person must authorise and post."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!isMoneyInput(amount) || basis.trim().length < 5} loading={go.isPending} onClick={() => go.mutate()}>Prepare journal</Button></>}>
      {inv && <div className="space-y-4">
        <p className="text-sm text-stone-700">Invoice net fees: <Money value={sub} currency={inv.currency} />. VAT and any amount already recognised are not recognisable here; the server rejects amounts above what remains.</p>
        <div className="grid grid-cols-2 gap-3"><Field label="Amount to recognise (net, GBP)" required error={amount && !isMoneyInput(amount) ? 'Invalid' : undefined}><Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={sub} /></Field>
          <Field label="Recognition date"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field></div>
        <Field label="Basis for recognition" required hint="Why is this revenue earned? e.g. “work completed and billed under the fixed-fee arrangement”. Recorded in the audit trail."><Textarea rows={3} value={basis} onChange={(e) => setBasis(e.target.value)} /></Field>
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
      </div>}
    </Dialog>
  )
}

export default function RevenuePage() {
  const { can } = useAuth()
  const [target, setTarget] = useState<Invoice | null>(null)
  const billed = useApiQuery<ReportData>(['ledger', 'rev', 'billed'], '/reports/billing', { enabled: can('reports.financial'), retry: false })
  const cash = useApiQuery<ReportData>(['ledger', 'rev', 'cash'], '/reports/cash-received', { enabled: can('reports.financial'), retry: false })
  const rec = useApiQuery<ReportData>(['ledger', 'rev', 'recognised'], '/reports/recognised-revenue', { enabled: can('reports.financial'), retry: false })
  const list = useApiQuery<RevenueRecognitionRow[]>(['ledger', 'recognitions'], '/ledger/revenue-recognition')
  const issued = useApiQuery<Page<Invoice>>(['billing', 'invoices', 'rev-issued'], `/billing/invoices${qs({ kind: 'invoice', limit: 100 })}`, { enabled: can('billing.read') })
  const candidates = (issued.data?.items ?? []).filter((i) => ['issued', 'partially_paid', 'paid'].includes(i.status))
  const nums = new Map((issued.data?.items ?? []).map((i) => [i.id, i.number]))
  const cols: Column<Invoice>[] = [
    { key: 'n', header: 'Invoice', cell: (i) => <Link className="font-medium text-navy-700 underline-offset-2 hover:underline" to={`/billing/invoices/${i.id}`}>{i.number}</Link> },
    { key: 'm', header: 'Matter', cell: (i) => <MatterLink id={i.matter_id} reference={i.matter_reference} /> },
    { key: 'net', header: 'Net fees billed', numeric: true, cell: (i) => <Money value={i.subtotal} currency={i.currency} /> },
    { key: 'st', header: 'Cash position', cell: (i) => <Badge>{i.status.replace('_', ' ')}</Badge> },
    { key: 'a', header: <span className="sr-only">Action</span>, align: 'right', cell: (i) => can('ledger.post') ? <Button size="sm" variant="secondary" onClick={() => setTarget(i)}>Recognise…</Button> : null },
  ]
  const rcols: Column<RevenueRecognitionRow>[] = [
    { key: 'd', header: 'Recognised', className: 'whitespace-nowrap', cell: (r) => <DateTime value={r.recognised_on} mode="date" /> },
    { key: 'i', header: 'Invoice', cell: (r) => <Link className="text-navy-700 underline" to={`/billing/invoices/${r.invoice_id}`}>{nums.get(r.invoice_id) ?? 'Invoice'}</Link> },
    { key: 'a', header: 'Amount', numeric: true, cell: (r) => <Money value={r.amount} /> },
    { key: 'b', header: 'Basis', cell: (r) => r.basis },
  ]
  const tot = (r: typeof billed, k: string) => (r.data?.totals as Record<string, string> | undefined)?.[k]
  return (
    <div className="space-y-6">
      <Notice tone="brass" title="Four different things — never conflated">Revenue is only recognised through the explicit, separately authorised step on this page. Issuing a bill records a receivable. Receiving money records cash (and client money is not the firm's at all). Allocation and reconciliation are further, separate controls.</Notice>
      {can('reports.financial') && (
        <div className="grid gap-4 md:grid-cols-3">
          <StatCard label="Billed (net, this period)" value={<Money value={tot(billed, 'net')} />} hint="Invoices issued less credit notes" footnote={billed.data?.period.from ? `${billed.data.period.from} → ${billed.data.period.to}. Billed is not revenue.` : undefined} />
          <StatCard label="Cash received (office)" value={<Money value={tot(cash, 'office_receipts')} />} hint="Receipts recorded" footnote="Cash received is not earned revenue." />
          <StatCard label="Recognised revenue" tone="success" value={<Money value={tot(rec, 'recognised')} />} hint="Only via the authorised step below" footnote={rec.data?.basis.slice(0, 120) + '…'} />
        </div>)}
      <Card title="Recognise revenue on an issued invoice" description="Choose an issued invoice, state the basis, and prepare the journal for authorisation." padded={false}>
        <DataTable caption="Issued invoices" columns={cols} rows={candidates} rowKey={(i) => i.id} loading={issued.isPending} error={issued.error} className="rounded-none border-0 shadow-none" emptyTitle="No issued invoices" emptyDescription="Issue an invoice in Time & Billing first." />
      </Card>
      <Card title="Recognitions posted" padded={false}>
        <DataTable caption="Revenue recognitions" columns={rcols} rows={list.data} rowKey={(r) => r.id} loading={list.isPending} error={list.error} className="rounded-none border-0 shadow-none" emptyTitle="Nothing recognised yet" />
      </Card>
      <RecogniseDialog inv={target} onClose={() => setTarget(null)} />
    </div>
  )
}
