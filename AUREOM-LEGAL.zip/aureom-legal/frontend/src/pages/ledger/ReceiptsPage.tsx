import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRightLeft, RefreshCw } from 'lucide-react'
import { useQueryParam } from '@/hooks'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, DataTable, DateTime, Dialog, Field, Input, IntegrationUnavailable, Money, Select, SimulatedBanner, StatusBadge, type Column } from '@/components/ui'
import { cmp, isMoneyInput, isZero, MatterSelect, Notice, subDecimal } from '@/pages/billing/shared'
import { LedgerBadge } from './common'
import type { BankLine, BankSyncResult, Invoice, LedgerKey, Page, Payment } from '@/types/finance'

function RecordDialog({ line, onClose }: { line: BankLine | null; onClose: () => void }) {
  const [matter, setMatter] = useState('')
  const [ref, setRef] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const rec = useApiMutation(() => api.post<Payment>('/ledger/payments', { bank_line_id: line!.id, matter_id: matter || null, reference: ref || null }),
    { invalidate: [['ledger'], ['home']], errorToast: false, successMessage: 'Receipt recorded — awaiting authorisation of its journal', onSuccess: () => { setMatter(''); setRef(''); onClose() }, onError: setErr })
  const client = line?.ledger === 'client'
  return (
    <Dialog open={!!line} onClose={onClose} title="Record bank receipt" description="Recording a receipt does not make it revenue. Office receipts sit in “unallocated receipts”; client money is held for the client."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={client && !matter} loading={rec.isPending} onClick={() => rec.mutate()}>Record receipt</Button></>}>
      {line && <div className="space-y-4">
        <div className="rounded-md bg-ivory-100 px-4 py-3 text-sm"><div className="flex items-center justify-between"><LedgerBadge ledger={line.ledger} long /><strong><Money value={line.amount} currency={line.currency} /></strong></div><p className="mt-1">{line.description}</p><p className="text-xs text-stone-600">{line.reference} · <DateTime value={line.txn_date} mode="date" /></p></div>
        <Field label={client ? 'Matter (required for client money)' : 'Matter (optional)'} required={client}>{(p) => <MatterSelect {...p} value={matter} onChange={setMatter} />}</Field>
        <Field label="Reference"><Input value={ref} onChange={(e) => setRef(e.target.value)} /></Field>
        <p className="text-xs text-stone-600">The receipt is posted through a draft journal that a different person must authorise in <Link to="/ledger/authorisations" className="underline">Authorisations</Link>.</p>
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
      </div>}
    </Dialog>
  )
}

interface AllocRow { invoice_id: string; amount: string }
function AllocateDialog({ payment, onClose }: { payment: Payment | null; onClose: () => void }) {
  const issued = useApiQuery<Page<Invoice>>(['billing', 'invoices', 'open'], `/billing/invoices${qs({ status: 'issued', kind: 'invoice', limit: 100 })}`, { enabled: !!payment })
  const partial = useApiQuery<Page<Invoice>>(['billing', 'invoices', 'partial'], `/billing/invoices${qs({ status: 'partially_paid', kind: 'invoice', limit: 100 })}`, { enabled: !!payment })
  const invoices = [...(issued.data?.items ?? []), ...(partial.data?.items ?? [])].filter((i) => !isZero(i.outstanding))
  const [rows, setRows] = useState<AllocRow[]>([{ invoice_id: '', amount: '' }])
  const [err, setErr] = useState<ApiError | null>(null)
  const [done, setDone] = useState<{ approval_id: string; message: string } | null>(null)
  const unalloc = payment?.unallocated_amount ?? '0.00'
  const used = rows.filter((r) => isMoneyInput(r.amount)).map((r) => r.amount)
  const remaining = used.reduce((rem, a) => subDecimal(rem, a), unalloc)
  const byId = new Map(invoices.map((i) => [i.id, i]))
  const problems: string[] = []
  rows.forEach((r, n) => {
    const inv = byId.get(r.invoice_id)
    if (r.invoice_id && inv && isMoneyInput(r.amount) && cmp(r.amount, inv.outstanding) > 0) problems.push(`Line ${n + 1} is more than the outstanding balance of ${inv.outstanding}.`)
  })
  if (remaining.startsWith('-')) problems.push('Allocations exceed the unallocated balance of the receipt.')
  if (new Set(rows.map((r) => r.invoice_id).filter(Boolean)).size < rows.filter((r) => r.invoice_id).length) problems.push('An invoice appears twice — combine the amounts.')
  const ready = rows.length > 0 && rows.every((r) => r.invoice_id && isMoneyInput(r.amount) && !isZero(r.amount)) && problems.length === 0
  const send = useApiMutation(() => api.post<{ status: string; approval_id: string; message: string }>(`/ledger/payments/${payment!.id}/allocate`, { allocations: rows.map((r) => ({ invoice_id: r.invoice_id, amount: r.amount })) }),
    { invalidate: [['ledger'], ['approvals']], errorToast: false, onSuccess: (r) => setDone({ approval_id: r.approval_id, message: r.message }), onError: setErr })
  const close = () => { setRows([{ invoice_id: '', amount: '' }]); setDone(null); setErr(null); onClose() }
  return (
    <Dialog open={!!payment} onClose={close} size="lg" title="Allocate receipt to invoices" description="Allocation is the step that matches received money to a bill. It needs authorisation from a different person before it is applied."
      footer={done ? <Button onClick={close}>Close</Button> : <><Button variant="secondary" onClick={close}>Cancel</Button><Button disabled={!ready} loading={send.isPending} onClick={() => send.mutate()}>Request authorisation</Button></>}>
      {payment && (done ? (
        <div className="space-y-3 text-sm"><p className="rounded-md bg-ok-50 px-4 py-3 text-ok-700">{done.message}</p>
          <p>When it has been authorised, return to <Link className="underline" to="/ledger/authorisations">Authorisations</Link> and choose <strong>Apply</strong> to carry out the allocation.</p></div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3 rounded-md bg-ivory-100 px-4 py-3 text-sm"><div><p className="text-xs text-stone-600">Receipt</p><Money value={payment.amount} currency={payment.currency} /></div>
            <div><p className="text-xs text-stone-600">Already allocated</p><Money value={payment.allocated_amount} currency={payment.currency} /></div>
            <div><p className="text-xs text-stone-600">Left to allocate</p><strong aria-live="polite"><Money value={remaining} currency={payment.currency} /></strong></div></div>
          {(issued.isPending || partial.isPending) && <p className="text-sm text-stone-600">Loading open invoices…</p>}
          {(issued.isError) && <p role="alert" className="text-sm text-bad-700">Could not load invoices: {issued.error.message}</p>}
          {rows.map((r, i) => {
            const inv = byId.get(r.invoice_id)
            return (
              <div key={i} className="grid grid-cols-[1fr_9rem_auto] items-end gap-2">
                <Field label={i === 0 ? 'Invoice' : ' '}><Select aria-label={`Invoice for line ${i + 1}`} value={r.invoice_id} onChange={(e) => { const x = byId.get(e.target.value); setRows(rows.map((q, j) => (j === i ? { invoice_id: e.target.value, amount: x ? (cmp(x.outstanding, remaining) <= 0 ? x.outstanding : remaining.startsWith('-') ? '' : remaining) : '' } : q))) }}>
                  <option value="">Select an issued invoice…</option>{invoices.map((x) => <option key={x.id} value={x.id}>{x.number} · {x.matter_reference} · owes {x.outstanding}</option>)}</Select></Field>
                <Field label={i === 0 ? 'Amount' : ' '} error={r.amount && !isMoneyInput(r.amount) ? 'Invalid' : undefined}><Input aria-label={`Amount for line ${i + 1}`} inputMode="decimal" value={r.amount} onChange={(e) => setRows(rows.map((q, j) => (j === i ? { ...q, amount: e.target.value } : q)))} /></Field>
                <Button variant="ghost" size="sm" disabled={rows.length === 1} onClick={() => setRows(rows.filter((_, j) => j !== i))}>Remove</Button>
                {inv && <p className="col-span-3 -mt-1 text-xs text-stone-600">Outstanding on {inv.number}: <Money value={inv.outstanding} currency={inv.currency} /></p>}
              </div>)
          })}
          <Button size="sm" variant="secondary" onClick={() => setRows([...rows, { invoice_id: '', amount: '' }])}>Add another invoice</Button>
          {problems.length > 0 && <ul role="alert" className="list-disc space-y-1 pl-5 text-sm text-bad-700">{problems.map((p) => <li key={p}>{p}</li>)}</ul>}
          {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
          <p className="text-xs text-stone-600">A receipt is cash received — it is <strong>not earned revenue</strong>. Allocating it only matches it to bills.</p>
        </div>))}
    </Dialog>
  )
}

export default function ReceiptsPage() {
  const { can } = useAuth()
  const [lsel, setLsel] = useState<LedgerKey>('office')
  const [showAll, setShowAll] = useState(false)
  const [payOffset, setPayOffset] = useState(0)
  const [recLine, setRecLine] = useState<BankLine | null>(null)
  const [alloc, setAlloc] = useState<Payment | null>(null)
  const [syncRes, setSyncRes] = useState<BankSyncResult | null>(null)
  const [syncErr, setSyncErr] = useState<ApiError | null>(null)
  const [status] = useQueryParam('status')
  const lines = useApiQuery<Page<BankLine>>(['ledger', 'bank-lines', showAll], `/ledger/bank-lines${qs({ unrecorded: !showAll, limit: 50 })}`)
  const pays = useApiQuery<Page<Payment>>(['ledger', 'payments', status, payOffset], `/ledger/payments${qs({ limit: 25, offset: payOffset })}`)
  const sync = useApiMutation(() => api.post<BankSyncResult>('/ledger/bank-feed/sync', { ledger: lsel }), { invalidate: [['ledger']], errorToast: false, onSuccess: (r) => { setSyncRes(r); setSyncErr(null) }, onError: (e) => { setSyncErr(e); setSyncRes(null) } })

  const lineCols: Column<BankLine>[] = [
    { key: 'd', header: 'Date', className: 'whitespace-nowrap', cell: (l) => <DateTime value={l.txn_date} mode="date" /> },
    { key: 'l', header: 'Ledger', cell: (l) => <LedgerBadge ledger={l.ledger} /> },
    { key: 'desc', header: 'Statement description', cell: (l) => <div><span>{l.description}</span>{l.reference && <p className="text-xs text-stone-600">{l.reference}</p>}</div> },
    { key: 'amt', header: 'Amount', numeric: true, cell: (l) => <Money value={l.amount} currency={l.currency} /> },
    { key: 's', header: 'Status', cell: (l) => <div className="flex gap-1"><StatusBadge status={l.status} />{l.payment_id && <Badge tone="info">Receipt recorded</Badge>}</div> },
    { key: 'a', header: <span className="sr-only">Action</span>, align: 'right', cell: (l) => !l.payment_id && !l.amount.startsWith('-') && can('ledger.post') ? <Button size="sm" variant="secondary" aria-label={`Record ${l.description} as a receipt`} onClick={() => setRecLine(l)}>Record</Button> : null },
  ]
  const payCols: Column<Payment>[] = [
    { key: 'd', header: 'Received', className: 'whitespace-nowrap', cell: (p) => <DateTime value={p.received_on} mode="date" /> },
    { key: 'l', header: 'Ledger', cell: (p) => <LedgerBadge ledger={p.ledger} /> },
    { key: 'ref', header: 'Reference', cell: (p) => p.reference ?? '—' },
    { key: 'amt', header: 'Amount', numeric: true, cell: (p) => <Money value={p.amount} currency={p.currency} /> },
    { key: 'al', header: 'Allocated', numeric: true, cell: (p) => <Money value={p.allocated_amount} currency={p.currency} /> },
    { key: 'un', header: 'Unallocated', numeric: true, cell: (p) => <strong><Money value={p.unallocated_amount} currency={p.currency} /></strong> },
    { key: 's', header: 'Status', cell: (p) => <StatusBadge status={p.status} /> },
    { key: 'a', header: <span className="sr-only">Actions</span>, align: 'right', cell: (p) => (
      <div className="flex justify-end gap-2">
        {p.status === 'pending_authorisation' && p.receipt_journal_id && <Link className="text-xs font-medium text-navy-700 underline" to={`/ledger/journals/${p.receipt_journal_id}`}>Open journal</Link>}
        {p.ledger === 'office' && ['received_unallocated', 'partially_allocated'].includes(p.status) && can('ledger.post') && <Button size="sm" variant="secondary" icon={<ArrowRightLeft className="h-3.5 w-3.5" />} onClick={() => setAlloc(p)}>Allocate</Button>}
      </div>) },
  ]

  return (
    <div className="space-y-6">
      <Card title="Bank feed" description="Statement lines arrive from the bank-feed integration. In this build it is a synthetic provider."
        actions={<><Select aria-label="Ledger to sync" value={lsel} onChange={(e) => setLsel(e.target.value as LedgerKey)} className="w-48"><option value="office">Office account</option><option value="client">Client account</option></Select>
          {can('ledger.post') && <Button icon={<RefreshCw className="h-4 w-4" />} loading={sync.isPending} onClick={() => sync.mutate()}>Sync bank feed</Button>}</>}>
        <SimulatedBanner>The bank feed is a labelled mock that produces synthetic transactions. No real bank is connected, and payment initiation is deliberately not implemented.</SimulatedBanner>
        {syncErr && (syncErr.isIntegrationUnavailable ? <IntegrationUnavailable className="py-6" name="Bank feed" message={syncErr.message} setupHint={syncErr.details.setup_hint as string | undefined} mockAvailable /> : <p role="alert" className="mt-3 text-sm text-bad-700">{syncErr.message}</p>)}
        {syncRes && <p className="mt-3 text-sm" role="status">Provider <strong>{syncRes.provider}</strong> ({syncRes.mode}{syncRes.synthetic ? ', synthetic' : ''}): imported <strong>{String(syncRes.created ?? 0)}</strong> new line(s), skipped <strong>{String(syncRes.skipped ?? 0)}</strong> already present.</p>}
      </Card>

      <Card title="Bank statement lines" description={showAll ? 'All imported lines' : 'Incoming lines not yet recorded as receipts'} actions={<Button size="sm" variant="secondary" onClick={() => setShowAll(!showAll)}>{showAll ? 'Show unrecorded only' : 'Show all lines'}</Button>} padded={false}>
        <DataTable caption="Bank statement lines" columns={lineCols} rows={lines.data?.items} rowKey={(l) => l.id} loading={lines.isPending} error={lines.error} onRetry={() => void lines.refetch()} dense className="rounded-none border-0 shadow-none"
          emptyTitle="No statement lines" emptyDescription="Use “Sync bank feed” to import the synthetic statement." />
      </Card>

      <Card title="Receipts" description="Cash received. Not revenue." padded={false}>
        <DataTable caption="Receipts" columns={payCols} rows={pays.data?.items} rowKey={(p) => p.id} loading={pays.isPending} error={pays.error} onRetry={() => void pays.refetch()} dense className="rounded-none border-0 shadow-none"
          pagination={pays.data ? { total: pays.data.total, limit: pays.data.limit, offset: pays.data.offset, onChange: setPayOffset } : undefined} emptyTitle="No receipts recorded" />
      </Card>
      <Notice>Lifecycle: <strong>bank line</strong> → <strong>receipt recorded</strong> (draft journal, authorised by a second person) → <strong>allocated</strong> to invoices (authorised by a second person) → <strong>reconciled</strong>. Revenue recognition is a separate step on the Revenue page.</Notice>
      <RecordDialog line={recLine} onClose={() => setRecLine(null)} />
      <AllocateDialog payment={alloc} onClose={() => setAlloc(null)} />
    </div>
  )
}
