import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQueryParam } from '@/hooks'
import { useApiQuery } from '@/lib/api'
import { Badge, Card, DataTable, Field, Input, Money, type Column } from '@/components/ui'
import { subDecimal } from '@/pages/billing/shared'
import { LedgerBadge, LedgerSwitch } from './common'
import type { LedgerKey, TrialBalance } from '@/types/finance'

type Row = TrialBalance['accounts'][number]

export default function AccountsPage() {
  const [l, setL] = useQueryParam('ledger')
  const ledger: LedgerKey = l === 'client' ? 'client' : 'office'
  const [asOf, setAsOf] = useState('')
  const q = useApiQuery<TrialBalance>(['ledger', 'tb', ledger, asOf], `/ledger/trial-balance?ledger=${ledger}${asOf ? `&as_of=${asOf}` : ''}`)
  const cols: Column<Row>[] = [
    { key: 'code', header: 'Code', cell: (r) => <code className="font-mono text-xs">{r.code}</code> },
    { key: 'name', header: 'Account', cell: (r) => <span>{r.name}{r.matter_id && <Link className="ml-2 text-xs text-navy-700 underline" to={`/matters/${r.matter_id}`}>matter</Link>}</span> },
    { key: 'type', header: 'Type', hideOnNarrow: true, cell: (r) => <Badge>{r.type}</Badge> },
    { key: 'dr', header: 'Debit', numeric: true, cell: (r) => <Money value={r.debit} /> },
    { key: 'cr', header: 'Credit', numeric: true, cell: (r) => <Money value={r.credit} /> },
    { key: 'bal', header: 'Balance', numeric: true, cell: (r) => <strong><Money value={r.balance} /></strong> },
  ]
  const d = q.data
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-center gap-3"><LedgerSwitch value={ledger} onChange={(x) => setL(x)} /></div>
        <Field label="As at"><Input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} className="w-44" /></Field>
      </div>
      <Card title={<span className="flex items-center gap-2">Trial balance <LedgerBadge ledger={ledger} long /></span>} description="Posted journals only. Balance is on the account's natural side (assets: debit − credit; liabilities and income: credit − debit)." padded={false}>
        <DataTable caption={`${ledger} ledger trial balance`} columns={cols} rows={d?.accounts} rowKey={(r) => r.account_id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} dense className="rounded-none border-0 shadow-none" emptyTitle="No accounts" />
        {d && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-stone-300 bg-ivory-100 px-5 py-3 text-sm">
            <span className="font-semibold">Totals</span>
            <span className="flex items-center gap-6"><span>Debits <strong className="tabular-nums"><Money value={d.total_debit} /></strong></span><span>Credits <strong className="tabular-nums"><Money value={d.total_credit} /></strong></span>
              {d.balanced ? <Badge tone="success">Debits equal credits</Badge> : <Badge tone="danger">Out of balance by <Money value={subDecimal(d.total_debit, d.total_credit)} /></Badge>}</span>
          </div>)}
      </Card>
      {d && <p className="text-xs text-stone-600">{d.note}</p>}
    </div>
  )
}
