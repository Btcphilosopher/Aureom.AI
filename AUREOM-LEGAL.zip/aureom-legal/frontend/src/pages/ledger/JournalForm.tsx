import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { useQueryParam } from '@/hooks'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, Field, Input, Money, PageHeader, PermissionDenied, Select } from '@/components/ui'
import { sumDecimal } from '@/lib/format'
import { isMoneyInput, Notice, scaled, subDecimal, todayIso } from '@/pages/billing/shared'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { LedgerBadge, LedgerSwitch } from './common'
import type { Journal, LedgerAccount, LedgerKey } from '@/types/finance'

interface Line { account_id: string; debit: string; credit: string; narrative: string }
const blank = (): Line => ({ account_id: '', debit: '', credit: '', narrative: '' })

export default function JournalForm() {
  useBreadcrumbs([{ label: 'Client Ledger', to: '/ledger' }, { label: 'Journals', to: '/ledger/journals' }, { label: 'New manual journal' }])
  const { can } = useAuth()
  const nav = useNavigate()
  const [lq] = useQueryParam('ledger')
  const [ledger, setLedger] = useState<LedgerKey>(lq === 'client' ? 'client' : 'office')
  const [reference, setReference] = useState('')
  const [description, setDescription] = useState('')
  const [date, setDate] = useState(todayIso())
  const [lines, setLines] = useState<Line[]>([blank(), blank()])
  const [err, setErr] = useState<ApiError | null>(null)
  const accts = useApiQuery<LedgerAccount[]>(['ledger', 'accounts', ledger], `/ledger/accounts?ledger=${ledger}`)
  const usable = (accts.data ?? []).filter((a) => !a.matter_id) // per-matter client accounts are posted via receipts/transfers

  const num = (v: string) => (v.trim() === '' ? '0.00' : v.trim())
  const valid = (l: Line) => (l.debit.trim() === '' || isMoneyInput(l.debit)) && (l.credit.trim() === '' || isMoneyInput(l.credit))
  const totals = useMemo(() => {
    const ok = lines.filter(valid)
    const d = sumDecimal(ok.map((l) => num(l.debit))), c = sumDecimal(ok.map((l) => num(l.credit)))
    return { d, c, diff: subDecimal(d, c) }
  }, [lines]) // eslint-disable-line react-hooks/exhaustive-deps
  const populated = lines.filter((l) => l.account_id || l.debit || l.credit)
  const oneSided = populated.every((l) => valid(l) && !(scaled(num(l.debit))! > 0n && scaled(num(l.credit))! > 0n) && (scaled(num(l.debit))! > 0n || scaled(num(l.credit))! > 0n) && !!l.account_id)
  const balanced = scaled(totals.diff) === 0n && scaled(totals.d)! > 0n
  const ready = reference.trim() && description.trim() && populated.length >= 2 && oneSided && balanced

  const save = useApiMutation((submit: boolean) => api.post<Journal>('/ledger/journals', {
    ledger, reference, description, effective_date: date, currency: 'GBP', submit,
    lines: populated.map((l) => ({ account_id: l.account_id, debit: num(l.debit), credit: num(l.credit), narrative: l.narrative || null })),
  }), { invalidate: [['ledger']], errorToast: false, successMessage: (j) => `Journal ${j.reference} saved as ${j.status.replace('_', ' ')}`, onSuccess: (j) => nav(`/ledger/journals/${j.id}`), onError: setErr })

  const setLine = (i: number, patch: Partial<Line>) => setLines(lines.map((l, j) => (j === i ? { ...l, ...patch } : l)))
  if (!can('ledger.post')) return <PermissionDenied permission="ledger.post" />
  return (
    <>
      <PageHeader title="New manual journal" description="A journal is only a proposal until a different person authorises it and it is posted. Posted journals can never be edited — only reversed." />
      <div className="space-y-6">
        <Card title="Journal">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3"><span className="text-xs font-semibold uppercase tracking-wide text-stone-700">Ledger</span>
              <LedgerSwitch value={ledger} onChange={(l) => { setLedger(l); setLines([blank(), blank()]) }} /></div>
            <Notice tone="brass">Office money and client money are separate ledgers. Every line in this journal must use an account from the <strong>{ledger === 'client' ? 'client funds' : 'office'} ledger</strong>; the account lists below only show that ledger, and the database refuses to post a journal that mixes them.</Notice>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Reference" required><Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="e.g. ADJ-2026-001" /></Field>
              <Field label="Effective date" required><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
              <Field label="Description" required className="sm:col-span-3"><Input value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
            </div>
          </div>
        </Card>
        <Card title={<span className="flex items-center gap-2">Lines <LedgerBadge ledger={ledger} /></span>} padded={false}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm"><caption className="sr-only">Journal lines</caption>
              <thead><tr className="border-b border-stone-300 bg-ivory-200 text-xs uppercase tracking-wide text-stone-700"><th scope="col" className="px-4 py-2 text-left">Account</th><th scope="col" className="px-3 py-2 text-right">Debit</th><th scope="col" className="px-3 py-2 text-right">Credit</th><th scope="col" className="px-3 py-2 text-left">Narrative</th><th scope="col" className="px-2 py-2"><span className="sr-only">Remove</span></th></tr></thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={i} className="border-b border-stone-100 align-top">
                    <td className="min-w-[16rem] px-4 py-2"><Select aria-label={`Line ${i + 1} account`} value={l.account_id} onChange={(e) => setLine(i, { account_id: e.target.value })}><option value="">Select account…</option>{usable.map((a) => <option key={a.id} value={a.id}>{a.code} · {a.name}</option>)}</Select></td>
                    <td className="px-3 py-2"><Input aria-label={`Line ${i + 1} debit`} inputMode="decimal" className="text-right tabular-nums" value={l.debit} onChange={(e) => setLine(i, { debit: e.target.value, credit: e.target.value ? '' : l.credit })} aria-invalid={l.debit !== '' && !isMoneyInput(l.debit)} /></td>
                    <td className="px-3 py-2"><Input aria-label={`Line ${i + 1} credit`} inputMode="decimal" className="text-right tabular-nums" value={l.credit} onChange={(e) => setLine(i, { credit: e.target.value, debit: e.target.value ? '' : l.debit })} aria-invalid={l.credit !== '' && !isMoneyInput(l.credit)} /></td>
                    <td className="px-3 py-2"><Input aria-label={`Line ${i + 1} narrative`} value={l.narrative} onChange={(e) => setLine(i, { narrative: e.target.value })} /></td>
                    <td className="px-2 py-2"><Button variant="ghost" size="sm" aria-label={`Remove line ${i + 1}`} disabled={lines.length <= 2} onClick={() => setLines(lines.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4" /></Button></td>
                  </tr>))}
              </tbody>
              <tfoot><tr className="bg-ivory-100 font-semibold"><td className="px-4 py-2.5">Totals</td><td className="px-3 py-2.5 text-right tabular-nums"><Money value={totals.d} /></td><td className="px-3 py-2.5 text-right tabular-nums"><Money value={totals.c} /></td><td colSpan={2} className="px-3 py-2.5" aria-live="polite">
                {balanced ? <Badge tone="success">Balanced</Badge> : <Badge tone="danger">Out of balance by <Money value={totals.diff.replace('-', '')} /></Badge>}</td></tr></tfoot>
            </table>
          </div>
          <div className="border-t border-stone-200 px-5 py-3"><Button variant="secondary" size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setLines([...lines, blank()])}>Add line</Button></div>
        </Card>
        {!ready && populated.length > 0 && <p className="text-sm text-stone-700" aria-live="polite">To save: every line needs an account and a single positive debit <em>or</em> credit, there must be at least two lines, and debits must equal credits.</p>}
        {err && <p role="alert" className="rounded-md bg-bad-50 px-4 py-3 text-sm text-bad-700">{err.message}</p>}
        <div className="flex flex-wrap justify-end gap-2">
          <Button variant="secondary" onClick={() => nav('/ledger/journals')}>Cancel</Button>
          <Button variant="secondary" disabled={!ready} loading={save.isPending} onClick={() => save.mutate(false)}>Save as draft</Button>
          <Button disabled={!ready} loading={save.isPending} onClick={() => save.mutate(true)}>Save &amp; submit for authorisation</Button>
        </div>
      </div>
    </>
  )
}
