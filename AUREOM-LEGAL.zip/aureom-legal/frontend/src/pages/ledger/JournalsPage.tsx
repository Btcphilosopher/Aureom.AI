import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { useQueryParams } from '@/hooks'
import { qs, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, DataTable, DateTime, Money, Select, StatusBadge, type Column } from '@/components/ui'
import { LedgerBadge } from './common'
import type { Journal, Page } from '@/types/finance'

const P = ['ledger', 'status'] as const
const SOURCE: Record<string, string> = { invoice_issue: 'Invoice issue', receipt: 'Receipt', allocation: 'Allocation', revenue_recognition: 'Revenue recognition', client_transfer: 'Client transfer', manual: 'Manual' }

export default function JournalsPage() {
  const { can } = useAuth()
  const nav = useNavigate()
  const [p, setP] = useQueryParams(P)
  const [offset, setOffset] = useState(0)
  const q = useApiQuery<Page<Journal>>(['ledger', 'journals', p.ledger, p.status, offset], `/ledger/journals${qs({ ledger: p.ledger, status: p.status, limit: 25, offset })}`)
  const cols: Column<Journal>[] = [
    { key: 'ref', header: 'Reference', cell: (j) => <span className="font-medium">{j.reference}</span> },
    { key: 'ledger', header: 'Ledger', cell: (j) => <LedgerBadge ledger={j.ledger} /> },
    { key: 'desc', header: 'Description', cell: (j) => <span className="line-clamp-1 max-w-sm">{j.description}</span> },
    { key: 'src', header: 'Source', hideOnNarrow: true, cell: (j) => <Badge>{SOURCE[j.source_type ?? ''] ?? j.source_type ?? '—'}</Badge> },
    { key: 'date', header: 'Effective', className: 'whitespace-nowrap', cell: (j) => <DateTime value={j.effective_date} mode="date" /> },
    { key: 'status', header: 'Status', cell: (j) => <StatusBadge status={j.status} /> },
    { key: 'total', header: 'Amount', numeric: true, cell: (j) => <Money value={j.total} currency={j.currency} /> },
  ]
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-2">
          <Select aria-label="Ledger" value={p.ledger ?? ''} onChange={(e) => { setP({ ledger: e.target.value || null }); setOffset(0) }} className="w-52"><option value="">Both ledgers</option><option value="office">Office ledger</option><option value="client">Client funds ledger</option></Select>
          <Select aria-label="Status" value={p.status ?? ''} onChange={(e) => { setP({ status: e.target.value || null }); setOffset(0) }} className="w-48"><option value="">All statuses</option>{['draft', 'pending_approval', 'posted', 'reversed'].map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</Select>
        </div>
        {can('ledger.post') && <Button icon={<Plus className="h-4 w-4" />} onClick={() => nav(`/ledger/journals/new${p.ledger ? `?ledger=${p.ledger}` : ''}`)}>New manual journal</Button>}
      </div>
      <DataTable caption="Journals" columns={cols} rows={q.data?.items} rowKey={(j) => j.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(j) => nav(`/ledger/journals/${j.id}`)}
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} emptyTitle="No journals match" />
    </div>
  )
}
