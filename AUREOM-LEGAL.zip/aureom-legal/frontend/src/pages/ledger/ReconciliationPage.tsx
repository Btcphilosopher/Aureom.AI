import { useState } from 'react'
import { Link, Route, Routes, useNavigate, useParams } from 'react-router-dom'
import { CheckCheck, Plus, ShieldCheck, Wand2 } from 'lucide-react'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, DataTable, DateTime, Dialog, Field, Input, Money, NotFoundState, QueryBoundary, Select, StatusBadge, type Column } from '@/components/ui'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { isMoneyInput, isZero, Notice, todayIso } from '@/pages/billing/shared'
import { LedgerBadge } from './common'
import type { BankLine, LedgerAccount, Page, Reconciliation } from '@/types/finance'

function StartDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const nav = useNavigate()
  const accts = useApiQuery<LedgerAccount[]>(['ledger', 'accounts', 'all'], '/ledger/accounts', { enabled: open })
  const banks = (accts.data ?? []).filter((a) => a.is_bank)
  const [bank, setBank] = useState('')
  const [end, setEnd] = useState(todayIso())
  const [bal, setBal] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const create = useApiMutation(() => api.post<Reconciliation>('/ledger/reconciliations', { bank_account_id: bank, period_end: end, statement_balance: bal.trim() }),
    { invalidate: [['ledger', 'recs']], errorToast: false, onSuccess: (r) => { onClose(); nav(`/ledger/reconciliation/${r.id}`) }, onError: setErr })
  return (
    <Dialog open={open} onClose={onClose} title="Start a bank reconciliation" description="Compare the bank statement balance with the ledger's bank account. The difference must reach 0.00 before sign-off."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!bank || !isMoneyInput(bal.replace(/^-/, ''))} loading={create.isPending} onClick={() => create.mutate()}>Start</Button></>}>
      <div className="space-y-4">
        <Field label="Bank account" required><Select value={bank} onChange={(e) => setBank(e.target.value)}><option value="">Select…</option>{banks.map((b) => <option key={b.id} value={b.id}>{b.ledger === 'client' ? 'Client funds' : 'Office'} — {b.code} · {b.name}</option>)}</Select></Field>
        <div className="grid grid-cols-2 gap-3"><Field label="Period end" required><Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} /></Field>
          <Field label="Statement closing balance (GBP)" required error={bal && !isMoneyInput(bal.replace(/^-/, '')) ? 'Invalid' : undefined}><Input inputMode="decimal" value={bal} onChange={(e) => setBal(e.target.value)} /></Field></div>
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
      </div>
    </Dialog>
  )
}
function List() {
  const { can } = useAuth()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const [offset, setOffset] = useState(0)
  const q = useApiQuery<Page<Reconciliation>>(['ledger', 'recs', offset], `/ledger/reconciliations${qs({ limit: 25, offset })}`)
  const cols: Column<Reconciliation>[] = [
    { key: 'e', header: 'Period end', className: 'whitespace-nowrap', cell: (r) => <DateTime value={r.period_end} mode="date" /> },
    { key: 'l', header: 'Ledger', cell: (r) => <LedgerBadge ledger={r.ledger} long /> },
    { key: 'st', header: 'Statement balance', numeric: true, cell: (r) => <Money value={r.statement_balance} /> },
    { key: 'lb', header: 'Ledger balance', numeric: true, cell: (r) => <Money value={r.ledger_balance} /> },
    { key: 'df', header: 'Difference', numeric: true, cell: (r) => <span className={isZero(r.difference) ? 'text-ok-700' : 'font-semibold text-bad-700'}><Money value={r.difference} /></span> },
    { key: 's', header: 'Status', cell: (r) => <StatusBadge status={r.status} /> },
  ]
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3"><p className="text-sm text-stone-700">Reconcile each bank account (office and client) to its ledger. Sign-off is by a different person from the preparer.</p>
        {can('ledger.reconcile') && <Button icon={<Plus className="h-4 w-4" />} onClick={() => setOpen(true)}>Start reconciliation</Button>}</div>
      <DataTable caption="Bank reconciliations" columns={cols} rows={q.data?.items} rowKey={(r) => r.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(r) => nav(`/ledger/reconciliation/${r.id}`)}
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} emptyTitle="No reconciliations yet" emptyDescription="Start one to compare a bank statement balance with the ledger." />
      <StartDialog open={open} onClose={() => setOpen(false)} />
    </div>
  )
}

function Detail() {
  const { id } = useParams()
  const { can } = useAuth()
  const q = useApiQuery<Reconciliation>(['ledger', 'rec', id], `/ledger/reconciliations/${id}`)
  useBreadcrumbs([{ label: 'Client Ledger', to: '/ledger' }, { label: 'Reconciliation', to: '/ledger/reconciliation' }, { label: q.data ? `To ${q.data.period_end}` : 'Reconciliation' }])
  const [selBank, setSelBank] = useState<string | null>(null)
  const [selJl, setSelJl] = useState<string | null>(null)
  const [err, setErr] = useState<ApiError | null>(null)
  const opts = { invalidate: [['ledger']], errorToast: false as const, onError: (e: ApiError) => setErr(e) }
  const match = useApiMutation((v: { pairs?: { bank_line_id: string; journal_line_id: string }[]; apply_suggestions?: boolean }) => api.post<{ matched: number }>(`/ledger/reconciliations/${id}/match`, { pairs: v.pairs ?? [], apply_suggestions: !!v.apply_suggestions }),
    { ...opts, successMessage: (r) => `${r.matched} line(s) matched`, onSuccess: () => { setErr(null); setSelBank(null); setSelJl(null) } })
  const sign = useApiMutation(() => api.post(`/ledger/reconciliations/${id}/sign-off`), { ...opts, successMessage: 'Reconciliation signed off', onSuccess: () => setErr(null) })

  return (
    <QueryBoundary query={q} what="reconciliation">
      {(r) => {
        const draft = r.status === 'draft'
        const zero = isZero(r.difference)
        const sugg = r.suggestions ?? []
        const bcols: Column<BankLine>[] = [
          { key: 'pick', header: <span className="sr-only">Select</span>, cell: (l) => <input type="radio" name="bank" aria-label={`Select statement line ${l.description}`} checked={selBank === l.id} onChange={() => setSelBank(l.id)} className="h-4 w-4 accent-navy-800" /> },
          { key: 'd', header: 'Date', cell: (l) => <DateTime value={l.txn_date} mode="date" /> }, { key: 'desc', header: 'Statement line', cell: (l) => l.description },
          { key: 'a', header: 'Amount', numeric: true, cell: (l) => <Money value={l.amount} /> }]
        const jl = r.unreconciled_journal_lines ?? []
        const jcols: Column<(typeof jl)[number]>[] = [
          { key: 'pick', header: <span className="sr-only">Select</span>, cell: (l) => <input type="radio" name="jl" aria-label={`Select ledger line ${l.reference}`} checked={selJl === l.journal_line_id} onChange={() => setSelJl(l.journal_line_id)} className="h-4 w-4 accent-navy-800" /> },
          { key: 'd', header: 'Effective', cell: (l) => <DateTime value={l.effective_date} mode="date" /> }, { key: 'r', header: 'Journal', cell: (l) => <Link className="text-navy-700 underline" to={`/ledger/journals/${l.journal_id}`}>{l.reference}</Link> },
          { key: 'a', header: 'Amount', numeric: true, cell: (l) => <Money value={/^0+(\.0+)?$/.test(l.debit) ? '-' + l.credit : l.debit} /> }]
        return (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3"><LedgerBadge ledger={r.ledger} long /><StatusBadge status={r.status} /><span className="text-sm text-stone-700">Period end <DateTime value={r.period_end} mode="date" /></span></div>
              {draft && can('ledger.reconcile') && <Button icon={<ShieldCheck className="h-4 w-4" />} disabled={!zero || r.can_sign_off === false} loading={sign.isPending} onClick={() => sign.mutate()}>Sign off reconciliation</Button>}
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <Card title="Bank statement balance"><p className="font-serif text-2xl"><Money value={r.statement_balance} /></p></Card>
              <Card title="Ledger bank balance"><p className="font-serif text-2xl"><Money value={r.ledger_balance} /></p></Card>
              <Card title="Difference"><p className={`font-serif text-2xl ${zero ? 'text-ok-700' : 'text-bad-700'}`} aria-live="polite"><Money value={r.difference} /></p>
                <p className="mt-1 text-xs">{zero ? (r.can_sign_off === false ? 'Balances agree but lines remain unmatched.' : 'Agrees — ready for sign-off by a second person.') : 'Must reach 0.00 before sign-off.'}</p></Card>
            </div>
            {err && <p role="alert" className="rounded-md border border-bad-100 bg-bad-50 px-4 py-3 text-sm text-bad-700"><strong>{err.code === 'four_eyes_required' ? 'Four-eyes control: ' : ''}</strong>{err.message}</p>}
            {r.status === 'signed_off' && <Notice tone="brass">Signed off <DateTime value={r.signed_off_at} /> — lines on this reconciliation are marked reconciled.</Notice>}
            {draft && (
              <>
                <Card title="Suggested matches" description="Exact amount and direction; nearest date wins. Review before applying." actions={can('ledger.reconcile') && sugg.length > 0 ? <Button size="sm" icon={<Wand2 className="h-3.5 w-3.5" />} loading={match.isPending} onClick={() => match.mutate({ apply_suggestions: true })}>Apply all {sugg.length}</Button> : undefined} padded={false}>
                  {sugg.length === 0 ? <p className="px-5 py-4 text-sm text-stone-600">No automatic suggestions.</p> : (
                    <ul className="divide-y divide-stone-100">{sugg.map((s) => (
                      <li key={s.bank_line_id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-2.5 text-sm">
                        <span><strong>{String(s.statement_description)}</strong> ↔ {String(s.journal_reference)} <Badge className="ml-1">{String(s.date_gap_days)} day gap</Badge></span>
                        <span className="flex items-center gap-3"><Money value={String(s.amount)} />{can('ledger.reconcile') && <Button size="sm" variant="secondary" onClick={() => match.mutate({ pairs: [{ bank_line_id: s.bank_line_id, journal_line_id: s.journal_line_id }] })}>Match</Button>}</span></li>))}</ul>)}
                </Card>
                <div className="grid gap-6 xl:grid-cols-2">
                  <Card title="Unmatched statement lines" padded={false}><DataTable caption="Unmatched statement lines" columns={bcols} rows={r.unmatched_statement_lines ?? []} rowKey={(l) => l.id} dense className="rounded-none border-0 shadow-none" emptyTitle="All statement lines matched" /></Card>
                  <Card title="Unreconciled ledger lines" padded={false}><DataTable caption="Unreconciled ledger lines" columns={jcols} rows={jl} rowKey={(l) => l.journal_line_id} dense className="rounded-none border-0 shadow-none" emptyTitle="All ledger lines matched" /></Card>
                </div>
                {can('ledger.reconcile') && <div className="flex justify-end"><Button variant="secondary" icon={<CheckCheck className="h-4 w-4" />} disabled={!selBank || !selJl} loading={match.isPending} onClick={() => match.mutate({ pairs: [{ bank_line_id: selBank!, journal_line_id: selJl! }] })}>Match selected pair</Button></div>}
              </>)}
            <Notice>Sign-off needs a person different from the one who prepared the reconciliation, and the difference must be exactly 0.00 with nothing left unmatched. This demonstration does not replace the firm's reviewed reconciliation procedure.</Notice>
          </div>)
      }}
    </QueryBoundary>
  )
}

export default function ReconciliationPage() {
  return (
    <Routes>
      <Route index element={<List />} />
      <Route path=":id" element={<Detail />} />
      <Route path="*" element={<NotFoundState what="reconciliation" />} />
    </Routes>
  )
}
