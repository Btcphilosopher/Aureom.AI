import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Bot, Landmark } from 'lucide-react'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, DataTable, DateTime, Field, Input, Money, Select, StatusBadge, type Column } from '@/components/ui'
import { cmp, isMoneyInput, Notice } from '@/pages/billing/shared'
import { approvalSummary } from './common'
import type { ApprovalRow, Invoice, Page } from '@/types/finance'

export default function TransfersPage() {
  const { can } = useAuth()
  const [inv, setInv] = useState('')
  const [amount, setAmount] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const [done, setDone] = useState<string | null>(null)
  const issued = useApiQuery<Page<Invoice>>(['billing', 'invoices', 'issued-transfer'], `/billing/invoices${qs({ status: 'issued', kind: 'invoice', limit: 100 })}`, { enabled: can('billing.read') })
  const partial = useApiQuery<Page<Invoice>>(['billing', 'invoices', 'partial-transfer'], `/billing/invoices${qs({ status: 'partially_paid', kind: 'invoice', limit: 100 })}`, { enabled: can('billing.read') })
  const invoices = [...(issued.data?.items ?? []), ...(partial.data?.items ?? [])]
  const sel = invoices.find((i) => i.id === inv)
  const bal = useApiQuery<{ balance: string; currency: string }>(['ledger', 'client-balance', sel?.matter_id], `/ledger/matters/${sel?.matter_id}/client-balance`, { enabled: !!sel })
  const mine = useApiQuery<Page<ApprovalRow>>(['approvals', 'transfers', 'mine'], `/approvals${qs({ scope: 'requested_by_me', limit: 50 })}`)
  const transfers = (mine.data?.items ?? []).filter((a) => a.kind === 'client_funds_transfer')
  const over = !!sel && !!bal.data && isMoneyInput(amount) && cmp(amount, bal.data.balance) > 0
  const overInv = !!sel && isMoneyInput(amount) && cmp(amount, sel.outstanding) > 0
  const request = useApiMutation(() => api.post<{ status: string; approval_id: string }>('/ledger/client-transfers', { invoice_id: inv, amount: amount.trim() }),
    { invalidate: [['approvals']], errorToast: false, onSuccess: (r) => { setDone(r.approval_id); setErr(null); setAmount('') }, onError: (e) => { setErr(e); setDone(null) } })
  const apply = useApiMutation((a: ApprovalRow) => api.post('/ledger/client-transfers', { invoice_id: (a.payload as { invoice_id: string }).invoice_id, amount: (a.payload as { amount: string }).amount, approval_id: a.id }),
    { invalidate: [['approvals'], ['ledger'], ['billing']], errorToast: false, successMessage: 'Transfer carried out', onError: setErr })
  const cols: Column<ApprovalRow>[] = [
    { key: 'w', header: 'Transfer', cell: (a) => approvalSummary(a) },
    { key: 's', header: 'Authorisation', cell: (a) => <StatusBadge status={a.status} /> },
    { key: 'by', header: 'Authorised by', hideOnNarrow: true, cell: (a) => a.decided_by_name ?? '—' },
    { key: 'at', header: 'Requested', hideOnNarrow: true, cell: (a) => <DateTime value={a.created_at} mode="relative" /> },
    { key: 'act', header: <span className="sr-only">Action</span>, align: 'right', cell: (a) => a.status === 'approved' ? <Button size="sm" loading={apply.isPending} onClick={() => apply.mutate(a)}>Apply transfer</Button> : null },
  ]
  return (
    <div className="space-y-6">
      <Notice tone="brass" title="Releasing client money is a controlled act"><Bot className="mr-1 inline h-4 w-4" aria-hidden />AI agents can <strong>never</strong> request, authorise or carry out a client-money transfer. A transfer needs an issued invoice, a sufficient client balance on that matter, and the authorisation of a <strong>different person</strong> from the one who requested it.</Notice>
      {can('ledger.post') ? (
        <Card title={<span className="flex items-center gap-2"><Landmark className="h-4 w-4" aria-hidden />Request a client → office transfer</span>} description="Pays an issued invoice from money held for the client on the same matter.">
          <div className="grid gap-4 md:grid-cols-[1fr_12rem_auto] md:items-end">
            <Field label="Issued invoice" required><Select value={inv} onChange={(e) => { setInv(e.target.value); const x = invoices.find((i) => i.id === e.target.value); setAmount(x ? x.outstanding : ''); setDone(null); setErr(null) }}>
              <option value="">Select…</option>{invoices.map((i) => <option key={i.id} value={i.id}>{i.number} · {i.matter_reference} · owes {i.outstanding}</option>)}</Select></Field>
            <Field label="Amount (GBP)" required error={amount && !isMoneyInput(amount) ? 'Invalid amount' : undefined}><Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
            <Button disabled={!inv || !isMoneyInput(amount) || over || overInv} loading={request.isPending} onClick={() => request.mutate()}>Request authorisation</Button>
          </div>
          {sel && <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-3"><div><dt className="text-xs text-stone-600">Outstanding on invoice</dt><dd><Money value={sel.outstanding} currency={sel.currency} /></dd></div>
            <div><dt className="text-xs text-stone-600">Client money held on matter</dt><dd>{bal.data ? <Money value={bal.data.balance} currency={bal.data.currency} /> : '…'}</dd></div>
            <div><dt className="text-xs text-stone-600">Matter</dt><dd><Link className="text-navy-700 underline" to={`/matters/${sel.matter_id}`}>{sel.matter_reference}</Link></dd></div></dl>}
          {over && <p role="alert" className="mt-3 text-sm font-medium text-bad-700">That is more than the client money held on this matter. A client balance can never be overdrawn.</p>}
          {overInv && <p role="alert" className="mt-3 text-sm font-medium text-bad-700">That is more than the invoice's outstanding balance.</p>}
          {done && <p role="status" className="mt-3 rounded-md bg-ok-50 px-4 py-3 text-sm text-ok-700">Authorisation requested. A different person with <code>ledger.approve</code> must authorise it in <Link className="underline" to="/ledger/authorisations">Authorisations</Link>; then apply it from the list below.</p>}
          {err && <p role="alert" className="mt-3 rounded-md bg-bad-50 px-4 py-3 text-sm text-bad-700">{err.message}</p>}
        </Card>
      ) : <Notice>You can view transfers but your role cannot request them.</Notice>}
      <Card title="My transfer requests" padded={false}>
        <DataTable caption="My client-money transfer requests" columns={cols} rows={transfers} rowKey={(a) => a.id} loading={mine.isPending} error={mine.error} className="rounded-none border-0 shadow-none" emptyTitle="No transfer requests" />
      </Card>
      <p className="text-xs text-stone-600">Executed transfers appear as paired journals in the <Link className="underline" to="/ledger/journals?ledger=client">client funds</Link> and <Link className="underline" to="/ledger/journals?ledger=office">office</Link> ledgers. <Badge tone="brass">Demonstration</Badge></p>
    </div>
  )
}
