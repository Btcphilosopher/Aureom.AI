import { Route, Routes } from 'react-router-dom'
import { Navigate } from 'react-router-dom'
import { usePageTitle } from '@/hooks'
import { useAuth } from '@/lib/auth'
import { NotFoundState, PageHeader, PermissionDenied } from '@/components/ui'
import { FINANCE_NOTICE, Notice } from '@/pages/billing/shared'
import { LedgerNav } from './common'
import Overview from './Overview'
import AccountsPage from './AccountsPage'
import JournalsPage from './JournalsPage'
import JournalForm from './JournalForm'
import JournalDetail from './JournalDetail'
import ReceiptsPage from './ReceiptsPage'
import ClientMoneyPage from './ClientMoneyPage'
import TransfersPage from './TransfersPage'
import RevenuePage from './RevenuePage'
import ReconciliationPage from './ReconciliationPage'
import AuthorisationsPage from './AuthorisationsPage'

/** Client Ledger section: owns all nested routes under /ledger. */
export default function LedgerSection() {
  usePageTitle('Client Ledger')
  const { can } = useAuth()
  if (!can('ledger.read')) return <><PageHeader title="Client Ledger" /><PermissionDenied permission="ledger.read" message="The ledgers are available to finance and accounts roles." /></>
  return (
    <>
      <PageHeader eyebrow="Practice finance" title="Client Ledger" description="Two separate ledgers: the firm's own money (office) and money held for clients. Every posting needs a named human's authorisation; AI agents have no access." />
      <Notice tone="warning" title="Demonstration accounting — professional review required" className="mb-6">{FINANCE_NOTICE}</Notice>
      <div className="grid gap-6 lg:grid-cols-[15.5rem_minmax(0,1fr)]">
        <LedgerNav />
        <div className="min-w-0">
          <Routes>
            <Route index element={<Overview />} />
            <Route path="accounts" element={<AccountsPage />} />
            <Route path="journals" element={<JournalsPage />} />
            <Route path="journals/new" element={<JournalForm />} />
            <Route path="journals/:id" element={<JournalDetail />} />
            <Route path="receipts" element={<ReceiptsPage />} />
            <Route path="client-money" element={<ClientMoneyPage />} />
            <Route path="transfers" element={<TransfersPage />} />
            <Route path="revenue" element={<RevenuePage />} />
            <Route path="reconciliation/*" element={<ReconciliationPage />} />
            <Route path="authorisations" element={<AuthorisationsPage />} />
            <Route path="matters" element={<Navigate to="/ledger/client-money" replace />} />
            <Route path="*" element={<NotFoundState what="page" />} />
          </Routes>
        </div>
      </div>
    </>
  )
}
