import { Link } from 'react-router-dom'
import { ShieldCheck } from 'lucide-react'
import { useApiQuery } from '@/lib/api'
import { Badge, Card, DataTable, DateTime, Money, StatCard, type Column } from '@/components/ui'
import { Notice } from '@/pages/billing/shared'
import type { ReportData } from '@/types/finance'

interface Row { matter_id: string; reference: string | null; title: string | null; balance: string }

export default function ClientMoneyPage() {
  const q = useApiQuery<ReportData>(['ledger', 'client-money'], '/reports/client-money')
  const rows = (q.data?.rows ?? []) as unknown as Row[]
  const t = q.data?.totals as { client_money_held_visible?: string; client_bank_ledger_balance?: string; last_signed_off_reconciliation?: string | null; note?: string } | undefined
  const cols: Column<Row>[] = [
    { key: 'ref', header: 'Matter', cell: (r) => <div><Link className="font-medium text-navy-700 underline-offset-2 hover:underline" to={`/matters/${r.matter_id}`}>{r.reference}</Link><p className="max-w-md truncate text-xs text-stone-600">{r.title}</p></div> },
    { key: 'bal', header: 'Held for client', numeric: true, cell: (r) => <strong><Money value={r.balance} /></strong> },
    { key: 'st', header: 'Position', cell: (r) => (/^0+(\.0+)?$/.test(r.balance) ? <Badge tone="success">Nil balance</Badge> : <Badge tone="brass">Funds held</Badge>) },
  ]
  return (
    <div className="space-y-5">
      <Notice tone="brass" title="Client money is not the firm's money"><span className="inline-flex items-center gap-1"><ShieldCheck className="h-4 w-4" aria-hidden /></span> A matter's client balance can never be overdrawn: the system refuses any posting that would take it below nil. Client money is never counted as billed, received or revenue.</Notice>
      {q.data && (
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard label="Held on matters you can see" tone="brass" value={<Money value={t?.client_money_held_visible} />} />
          <StatCard label="Client bank ledger balance" value={<Money value={t?.client_bank_ledger_balance} />} hint="All matters, including restricted ones" />
          <StatCard label="Last signed-off reconciliation" value={t?.last_signed_off_reconciliation ? <DateTime value={t.last_signed_off_reconciliation} mode="date" /> : 'None'} to="/ledger/reconciliation" />
        </div>)}
      <Card title="Client money by matter" description={q.data ? `As at ${q.data.period.as_of ?? 'today'} · ${q.data.currency}` : undefined} padded={false}>
        <DataTable caption="Client money held by matter" columns={cols} rows={rows} rowKey={(r) => r.matter_id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} className="rounded-none border-0 shadow-none" emptyTitle="No client money held" />
      </Card>
      {q.data && <Notice title="Calculation basis">{q.data.basis} {t?.note}</Notice>}
    </div>
  )
}
