import { useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle2, Play, XCircle } from 'lucide-react'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, DataTable, DateTime, Dialog, Field, Money, Tabs, Textarea, StatusBadge, type Column } from '@/components/ui'
import { hash8, Notice } from '@/pages/billing/shared'
import { approvalSummary, FINANCE_KINDS, KIND_LABEL } from './common'
import type { ApprovalRow, Page } from '@/types/finance'

export default function AuthorisationsPage() {
  const { me } = useAuth()
  const [scope, setScope] = useState<'waiting_for_me' | 'requested_by_me'>('waiting_for_me')
  const [err, setErr] = useState<ApiError | null>(null)
  const [rejecting, setRejecting] = useState<ApprovalRow | null>(null)
  const [note, setNote] = useState('')
  const q = useApiQuery<Page<ApprovalRow>>(['approvals', 'ledger', scope], `/approvals${qs({ scope, limit: 100 })}`)
  const rows = (q.data?.items ?? []).filter((a) => (FINANCE_KINDS as readonly string[]).includes(a.kind))
  const opts = { invalidate: [['approvals'], ['ledger'], ['billing']], errorToast: false as const, onError: (e: ApiError) => setErr(e) }
  const decide = useApiMutation((v: { id: string; approve: boolean; note?: string }) => api.post(`/ledger/approvals/${v.id}/decision`, { approve: v.approve, note: v.note ?? null }), { ...opts, successMessage: 'Decision recorded', onSuccess: () => { setErr(null); setRejecting(null); setNote('') } })
  const apply = useApiMutation((a: ApprovalRow) => {
    const p = a.payload as { allocations?: { invoice_id: string; amount: string }[]; payment_id?: string; invoice_id?: string; amount?: string }
    if (a.kind === 'payment_allocation') return api.post(`/ledger/payments/${p.payment_id}/allocate`, { allocations: p.allocations, approval_id: a.id })
    return api.post('/ledger/client-transfers', { invoice_id: p.invoice_id, amount: p.amount, approval_id: a.id })
  }, { ...opts, successMessage: 'Applied', onSuccess: () => setErr(null) })

  const cols: Column<ApprovalRow>[] = [
    { key: 'k', header: 'Type', cell: (a) => <Badge tone={a.kind === 'client_funds_transfer' ? 'brass' : 'info'}>{KIND_LABEL[a.kind] ?? a.kind}</Badge> },
    { key: 'sum', header: 'What is being authorised', cell: (a) => <div><p>{approvalSummary(a)}</p>{a.kind === 'journal_post' || a.kind === 'revenue_recognition' ? (a.subject_id && <Link className="text-xs text-navy-700 underline" to={`/ledger/journals/${a.subject_id}`}>Review the journal lines</Link>) : null}</div> },
    { key: 'by', header: 'Prepared by', hideOnNarrow: true, cell: (a) => a.requested_by === me?.user.id ? 'You' : a.requested_by_name },
    { key: 'hash', header: 'Bound content', hideOnNarrow: true, cell: (a) => <code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-2xs" title="SHA-256 of the exact content authorised">{hash8(a.payload_hash)}…</code> },
    { key: 'st', header: 'Status', cell: (a) => <StatusBadge status={a.status} /> },
    { key: 'at', header: 'Requested', className: 'whitespace-nowrap', hideOnNarrow: true, cell: (a) => <DateTime value={a.created_at} mode="relative" /> },
    { key: 'act', header: <span className="sr-only">Actions</span>, align: 'right', cell: (a) => (
      <div className="flex justify-end gap-2">
        {scope === 'waiting_for_me' && a.status === 'pending' && <>
          <Button size="sm" variant="secondary" icon={<XCircle className="h-3.5 w-3.5" />} onClick={() => setRejecting(a)}>Reject</Button>
          <Button size="sm" icon={<CheckCircle2 className="h-3.5 w-3.5" />} loading={decide.isPending} onClick={() => decide.mutate({ id: a.id, approve: true })}>Authorise</Button></>}
        {scope === 'requested_by_me' && a.status === 'approved' && ['payment_allocation', 'client_funds_transfer'].includes(a.kind) && <Button size="sm" icon={<Play className="h-3.5 w-3.5" />} loading={apply.isPending} onClick={() => apply.mutate(a)}>Apply</Button>}
        {scope === 'requested_by_me' && a.status === 'approved' && ['journal_post', 'revenue_recognition'].includes(a.kind) && a.subject_id && <Link className="text-xs font-medium text-navy-700 underline" to={`/ledger/journals/${a.subject_id}`}>Open to post</Link>}
      </div>) },
  ]
  return (
    <div className="space-y-5">
      <Tabs label="Authorisations" tabs={[{ id: 'waiting_for_me', label: 'Waiting for me' }, { id: 'requested_by_me', label: 'Requested by me' }]} value={scope} onChange={(s) => setScope(s as typeof scope)} />
      {err && <p role="alert" className="rounded-md border border-bad-100 bg-bad-50 px-4 py-3 text-sm text-bad-700"><strong>{err.code === 'four_eyes_required' ? 'Four-eyes control: ' : ''}</strong>{err.message}</p>}
      <DataTable caption="Finance authorisations" columns={cols} rows={rows} rowKey={(a) => a.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
        emptyTitle={scope === 'waiting_for_me' ? 'Nothing waiting for you' : 'You have no open requests'} emptyDescription="Journals, receipt allocations, client-money transfers and revenue recognition appear here once someone prepares them." />
      <Notice>You can only authorise what a <strong>different person</strong> prepared. Authorisation applies to the exact content shown (see the bound-content hash); if it changes, a fresh authorisation is needed. AI agents cannot prepare, authorise, post, allocate or transfer anything.</Notice>
      <Dialog open={!!rejecting} onClose={() => setRejecting(null)} title="Reject authorisation" footer={<><Button variant="secondary" onClick={() => setRejecting(null)}>Cancel</Button><Button variant="danger" disabled={note.trim().length < 3} loading={decide.isPending} onClick={() => rejecting && decide.mutate({ id: rejecting.id, approve: false, note })}>Reject</Button></>}>
        <Field label="Reason" required><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
      </Dialog>
    </div>
  )
}
