import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { CheckCircle2, RotateCcw, Send, ShieldCheck, XCircle } from 'lucide-react'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { usePageTitle } from '@/hooks'
import { Badge, Button, Card, ConfirmDialog, DataTable, DateTime, Dialog, Field, KeyValue, Money, PageHeader, QueryBoundary, StatusBadge, Textarea, type Column } from '@/components/ui'
import { sumDecimal } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { hash8, Notice, subDecimal } from '@/pages/billing/shared'
import { LedgerBadge } from './common'
import type { ApprovalRow, Journal, JournalLine } from '@/types/finance'

export default function JournalDetail() {
  const { id } = useParams()
  const { can, me } = useAuth()
  const q = useApiQuery<Journal>(['ledger', 'journal', id], `/ledger/journals/${id}`)
  const j = q.data
  const ap = useApiQuery<ApprovalRow>(['approvals', j?.approval_id], `/approvals/${j?.approval_id}`, { enabled: !!j?.approval_id, retry: false })
  usePageTitle(j ? `Journal ${j.reference}` : 'Journal')
  useBreadcrumbs([{ label: 'Client Ledger', to: '/ledger' }, { label: 'Journals', to: '/ledger/journals' }, { label: j?.reference ?? 'Journal' }])
  const [err, setErr] = useState<ApiError | null>(null)
  const [reversing, setReversing] = useState(false)
  const [rejecting, setRejecting] = useState(false)
  const [note, setNote] = useState('')
  const opts = { invalidate: [['ledger'], ['approvals'], ['billing'], ['reports']], errorToast: false as const, onError: (e: ApiError) => setErr(e) }
  const submit = useApiMutation(() => api.post(`/ledger/journals/${id}/submit`), { ...opts, successMessage: 'Submitted for authorisation', onSuccess: () => setErr(null) })
  const decide = useApiMutation((v: { approve: boolean; note?: string }) => api.post(`/ledger/journals/${id}/decision`, v), { ...opts, successMessage: 'Decision recorded', onSuccess: () => { setErr(null); setRejecting(false); setNote('') } })
  const post = useApiMutation(() => api.post(`/ledger/journals/${id}/post`), { ...opts, successMessage: 'Journal posted', onSuccess: () => setErr(null) })
  const reverse = useApiMutation((reason: string) => api.post(`/ledger/journals/${id}/reverse`, { reason }), { ...opts, successMessage: 'Reversal journal created', onSuccess: () => { setErr(null); setReversing(false) } })

  const who = (uid: string | null): string => {
    if (!uid) return '—'
    if (uid === me?.user.id) return `${me.user.name} (you)`
    if (ap.data?.requested_by === uid) return ap.data.requested_by_name ?? 'A colleague'
    if (ap.data?.decided_by === uid) return ap.data.decided_by_name ?? 'A colleague'
    return 'A colleague'
  }
  const cols: Column<JournalLine>[] = [
    { key: 'acct', header: 'Account', cell: (l) => <span><code className="mr-2 font-mono text-xs">{l.account_code}</code>{l.account_name}</span> },
    { key: 'nar', header: 'Narrative', hideOnNarrow: true, cell: (l) => l.narrative ?? '' },
    { key: 'dr', header: 'Debit', numeric: true, cell: (l) => (/^0+(\.0+)?$/.test(l.debit) ? '' : <Money value={l.debit} />) },
    { key: 'cr', header: 'Credit', numeric: true, cell: (l) => (/^0+(\.0+)?$/.test(l.credit) ? '' : <Money value={l.credit} />) },
  ]
  return (
    <QueryBoundary query={q} what="journal">
      {(jr) => {
        const d = sumDecimal(jr.lines.map((l) => l.debit)), c = sumDecimal(jr.lines.map((l) => l.credit))
        const balanced = d === c
        const iPrepared = jr.prepared_by === me?.user.id
        return (
          <>
            <PageHeader eyebrow="Journal" title={jr.reference} description={jr.description} meta={<><LedgerBadge ledger={jr.ledger} long /><StatusBadge status={jr.status} />{jr.source_type && <Badge>{jr.source_type.replace('_', ' ')}</Badge>}{jr.reverses_journal_id && <Link to={`/ledger/journals/${jr.reverses_journal_id}`}><Badge tone="brass">Reversal of an earlier journal</Badge></Link>}</>}
              actions={<>
                {jr.status === 'draft' && can('ledger.post') && <Button icon={<Send className="h-4 w-4" />} loading={submit.isPending} onClick={() => submit.mutate()}>Submit for authorisation</Button>}
                {jr.status === 'pending_approval' && jr.approval_status === 'pending' && can('ledger.approve') && <>
                  <Button variant="secondary" icon={<XCircle className="h-4 w-4" />} onClick={() => setRejecting(true)}>Reject</Button>
                  <Button icon={<CheckCircle2 className="h-4 w-4" />} loading={decide.isPending} onClick={() => decide.mutate({ approve: true })}>Authorise this exact journal</Button></>}
                {jr.status === 'pending_approval' && jr.approval_status === 'approved' && can('ledger.post') && <Button icon={<ShieldCheck className="h-4 w-4" />} loading={post.isPending} onClick={() => post.mutate()}>Post journal</Button>}
                {jr.status === 'posted' && can('ledger.post') && !jr.reverses_journal_id && <Button variant="secondary" icon={<RotateCcw className="h-4 w-4" />} onClick={() => setReversing(true)}>Reverse…</Button>}
              </>} />
            {err && <p role="alert" className="mb-4 rounded-md border border-bad-100 bg-bad-50 px-4 py-3 text-sm text-bad-700"><strong>{err.code === 'four_eyes_required' ? 'Four-eyes control: ' : ''}</strong>{err.message}</p>}
            <div className="grid gap-6 xl:grid-cols-[1fr_20rem]">
              <Card title="Lines" padded={false}>
                <DataTable caption="Journal lines" columns={cols} rows={jr.lines} rowKey={(l) => l.id} className="rounded-none border-0 shadow-none" />
                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-stone-300 bg-ivory-100 px-5 py-3 text-sm">
                  <span className="font-semibold">Totals</span>
                  <span className="flex items-center gap-6"><span>Debits <strong><Money value={d} currency={jr.currency} /></strong></span><span>Credits <strong><Money value={c} currency={jr.currency} /></strong></span>
                    {balanced ? <Badge tone="success">Balanced</Badge> : <Badge tone="danger">Out by <Money value={subDecimal(d, c)} /></Badge>}</span>
                </div>
              </Card>
              <aside className="space-y-4">
                <Card title="Control record"><KeyValue items={[
                  { label: 'Effective date', value: <DateTime value={jr.effective_date} mode="date" /> },
                  { label: 'Prepared by', value: who(jr.prepared_by) },
                  { label: 'Authorised by', value: ap.data?.decided_by_name ?? (jr.approval_status === 'approved' ? 'A colleague' : '—') },
                  { label: 'Posted by', value: jr.posted_by ? <>{who(jr.posted_by)} · <DateTime value={jr.posted_at} /></> : 'Not posted' },
                  { label: 'Approval hash', value: jr.approval_id ? <code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-2xs">{hash8(ap.data?.payload_hash)}…</code> : '—' },
                ]} />
                  {jr.status === 'pending_approval' && jr.approval_status === 'pending' && iPrepared && <p className="mt-3 rounded bg-warn-50 px-2.5 py-2 text-xs text-warn-700">You prepared this journal. Four-eyes control: a different person with <code>ledger.approve</code> must authorise it.</p>}
                </Card>
                <Notice>Authorisation is bound to the exact lines and amounts. A posted journal is immutable; corrections are made by posting a reversal and a new journal.</Notice>
              </aside>
            </div>
            <ConfirmDialog open={reversing} onClose={() => setReversing(false)} title="Reverse this journal" description="Creates a new reversing journal (also subject to authorisation). The original is kept." requireReason="Reason for reversal" confirmLabel="Create reversal" onConfirm={(r) => { if (r) reverse.mutate(r) }} />
            <Dialog open={rejecting} onClose={() => setRejecting(false)} title="Reject journal" footer={<><Button variant="secondary" onClick={() => setRejecting(false)}>Cancel</Button><Button variant="danger" disabled={note.trim().length < 3} loading={decide.isPending} onClick={() => decide.mutate({ approve: false, note })}>Reject</Button></>}>
              <Field label="Reason" required><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
            </Dialog>
          </>)
      }}
    </QueryBoundary>
  )
}
