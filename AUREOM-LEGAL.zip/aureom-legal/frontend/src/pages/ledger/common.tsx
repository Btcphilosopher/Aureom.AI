import type { ReactNode } from 'react'
import { NavLink } from 'react-router-dom'
import { Landmark, Users } from 'lucide-react'
import { Badge } from '@/components/ui'
import { cn } from '@/lib/cn'
import type { ApprovalRow, LedgerKey } from '@/types/finance'

export const FINANCE_KINDS = ['journal_post', 'payment_allocation', 'client_funds_transfer', 'revenue_recognition'] as const
export const KIND_LABEL: Record<string, string> = {
  journal_post: 'Journal posting', payment_allocation: 'Receipt allocation', client_funds_transfer: 'Client → office transfer', revenue_recognition: 'Revenue recognition',
}

/** Always-visible ledger label: Office (firm money) vs Client funds (clients' money). Never colour-only. */
export function LedgerBadge({ ledger, long }: { ledger: LedgerKey; long?: boolean }) {
  return ledger === 'client'
    ? <Badge tone="brass"><Users className="h-3 w-3" aria-hidden />{long ? 'Client funds ledger' : 'Client funds'}</Badge>
    : <Badge tone="info"><Landmark className="h-3 w-3" aria-hidden />{long ? 'Office ledger' : 'Office'}</Badge>
}

export function LedgerSwitch({ value, onChange }: { value: LedgerKey; onChange: (l: LedgerKey) => void }) {
  return (
    <div role="group" aria-label="Ledger" className="inline-flex overflow-hidden rounded-md ring-1 ring-stone-300">
      {(['office', 'client'] as const).map((l) => (
        <button key={l} type="button" aria-pressed={value === l} onClick={() => onChange(l)}
          className={cn('px-3.5 py-1.5 text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500', value === l ? (l === 'client' ? 'bg-brass-600 text-white' : 'bg-navy-800 text-white') : 'bg-white text-navy-800 hover:bg-ivory-100')}>
          {l === 'office' ? 'Office ledger' : 'Client funds ledger'}
        </button>))}
    </div>
  )
}

function Item({ to, children, end }: { to: string; children: ReactNode; end?: boolean }) {
  return <NavLink to={to} end={end} className={({ isActive }) => cn('block rounded-md px-3 py-1.5 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500', isActive ? 'bg-navy-800 font-medium text-white' : 'text-navy-800 hover:bg-navy-50')}>{children}</NavLink>
}
function Group({ title, tone, children }: { title: string; tone: 'office' | 'client' | 'controls'; children: ReactNode }) {
  const bar = { office: 'border-navy-600', client: 'border-brass-500', controls: 'border-stone-400' }[tone]
  return (
    <div className={cn('rounded-md border-l-4 bg-white py-2 pl-2 pr-1 shadow-panel ring-1 ring-stone-200', bar)}>
      <p className="px-3 pb-1 pt-0.5 text-2xs font-semibold uppercase tracking-[0.12em] text-stone-600">{title}</p>
      <ul className="space-y-0.5">{children}</ul>
    </div>
  )
}

/** Sub-navigation: Office ledger and Client funds ledger are separate groups, always labelled. */
export function LedgerNav() {
  return (
    <nav aria-label="Ledger sections" className="grid content-start gap-3 self-start sm:grid-cols-3 lg:grid-cols-1">
      <Group title="Overview" tone="controls"><li><Item to="/ledger" end>Both ledgers</Item></li></Group>
      <Group title="Office ledger — the firm's money" tone="office">
        <li><Item to="/ledger/accounts?ledger=office">Accounts &amp; trial balance</Item></li>
        <li><Item to="/ledger/journals?ledger=office">Journals</Item></li>
        <li><Item to="/ledger/receipts">Receipts &amp; allocation</Item></li>
        <li><Item to="/ledger/revenue">Revenue recognition</Item></li>
      </Group>
      <Group title="Client funds ledger — clients' money" tone="client">
        <li><Item to="/ledger/accounts?ledger=client">Accounts &amp; trial balance</Item></li>
        <li><Item to="/ledger/journals?ledger=client">Journals</Item></li>
        <li><Item to="/ledger/client-money">Client money by matter</Item></li>
        <li><Item to="/ledger/transfers">Client → office transfers</Item></li>
      </Group>
      <Group title="Controls" tone="controls">
        <li><Item to="/ledger/authorisations">Authorisations</Item></li>
        <li><Item to="/ledger/reconciliation">Reconciliation</Item></li>
      </Group>
    </nav>
  )
}

export function approvalSummary(a: ApprovalRow): string {
  const p = a.payload as Record<string, unknown>
  if (a.kind === 'payment_allocation') {
    const al = (p.allocations as { amount: string }[] | undefined) ?? []
    return `Allocate receipt across ${al.length} invoice${al.length === 1 ? '' : 's'}`
  }
  if (a.kind === 'client_funds_transfer') return `Transfer ${String(p.amount ?? '')} ${String(p.currency ?? '')} from client account to office account`
  if (a.kind === 'revenue_recognition') return `Recognise ${String(p.amount ?? '')} of billed fees as revenue`
  const j = p.journal as { reference?: string; ledger?: string } | undefined
  return j ? `Post ${j.ledger ?? ''} journal ${j.reference ?? ''}`.replace(/\s+/g, ' ') : 'Post journal'
}
