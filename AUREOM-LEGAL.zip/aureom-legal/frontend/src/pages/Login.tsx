import { useState, type FormEvent } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import { FlaskConical, KeyRound, ShieldCheck } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { usePageTitle } from '@/hooks'
import type { Persona } from '@/types/api'
import { Button } from '@/components/ui/Button'
import { Field, Input } from '@/components/ui/Form'
import { IntegrationUnavailable, LoadingState, SimulatedBanner } from '@/components/ui/States'
import { Wordmark } from '@/layout/Sidebar'
import { Avatar } from '@/components/ui/Nav'

export default function Login() {
  usePageTitle('Sign in')
  const { me, login, demoLogin } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const from = (loc.state as { from?: string } | null)?.from ?? '/'
  const [email, setEmail] = useState(''), [password, setPassword] = useState('')
  const [err, setErr] = useState<string | null>(null), [busy, setBusy] = useState<string | null>(null)
  const [sso, setSso] = useState<ApiError | null>(null)
  const personas = useQuery<Persona[], ApiError>({ queryKey: ['auth', 'personas'], queryFn: () => api.get<Persona[]>('/auth/personas'), retry: false })

  if (me) return <Navigate to={from} replace />

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(null); setBusy('form')
    try { await login(email, password); nav(from, { replace: true }) } catch (x) { setErr(x instanceof ApiError ? x.message : 'Sign-in failed.') } finally { setBusy(null) }
  }
  const persona = async (p: Persona) => {
    setErr(null); setBusy(p.email)
    try { await demoLogin(p.email); nav(from, { replace: true }) } catch (x) { setErr(x instanceof ApiError ? x.message : 'Sign-in failed.') } finally { setBusy(null) }
  }
  const startSso = async () => { try { await api.get('/auth/sso/start') } catch (x) { if (x instanceof ApiError) setSso(x) } }

  const grouped = (personas.data ?? []).reduce<Record<string, Persona[]>>((a, p) => { (a[p.role] ??= []).push(p); return a }, {})

  return (
    <div className="grid min-h-screen lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-navy-950 p-12 text-white lg:flex">
        <div aria-hidden className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full border border-brass-500/20" />
        <div aria-hidden className="pointer-events-none absolute -right-8 top-24 h-64 w-64 rounded-full border border-brass-500/10" />
        <Wordmark />
        <div className="max-w-md">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-brass-300">Pennine &amp; Calder Solicitors</p>
          <h1 className="font-serif text-4xl leading-tight">One connected record for every matter.</h1>
          <p className="mt-4 text-sm leading-relaxed text-navy-200">Clients, parties, documents, correspondence, deadlines, billing and controlled AI assistance — each linked to the matter, each subject to your permissions.</p>
        </div>
        <p className="flex items-center gap-2 text-xs text-navy-300"><ShieldCheck className="h-4 w-4 text-brass-300" aria-hidden />Role- and matter-level access · audited · synthetic data only</p>
      </section>

      <main id="main" className="flex items-center justify-center bg-ivory-100 px-6 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden"><div className="inline-block rounded-md bg-navy-950 p-3"><Wordmark /></div></div>
          <h2 className="font-serif text-3xl text-navy-900">Sign in</h2>
          <p className="mt-1 text-sm text-stone-600">Use your firm credentials.</p>
          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            <Field label="Email" required><Input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
            <Field label="Password" required><Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
            {err && <p role="alert" className="rounded-md border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
            <Button type="submit" className="w-full" size="lg" loading={busy === 'form'} disabled={!email || !password}>Sign in</Button>
            <Button variant="secondary" className="w-full" icon={<KeyRound className="h-4 w-4" />} onClick={startSso}>Sign in with single sign-on</Button>
          </form>
          {sso && <div className="mt-3 rounded-lg border border-stone-200 bg-white"><IntegrationUnavailable name="Single sign-on" message={sso.message} setupHint={(sso.details.setup_hint as string | undefined) ?? 'Set SSO_ISSUER and SSO_CLIENT_ID on the backend and provide an OIDC adapter.'} className="py-6" /></div>}

          {(personas.isPending || personas.data) && (
            <section className="mt-8 border-t border-stone-300 pt-6" aria-labelledby="demo-h">
              <SimulatedBanner className="mb-4">Demonstration environment — synthetic data only. Pick a persona to explore with that role’s permissions.</SimulatedBanner>
              <h3 id="demo-h" className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-stone-700"><FlaskConical className="h-3.5 w-3.5" aria-hidden />Demo personas</h3>
              {personas.isPending && <LoadingState label="Loading personas…" className="py-4" />}
              <div className="max-h-72 space-y-4 overflow-y-auto pr-1">
                {Object.entries(grouped).map(([role, list]) => (
                  <div key={role}>
                    <p className="mb-1.5 text-2xs font-semibold uppercase tracking-wider text-stone-600">{role}</p>
                    <ul className="grid gap-1.5 sm:grid-cols-2">
                      {list.map((p) => (
                        <li key={p.email}>
                          <button onClick={() => persona(p)} disabled={!!busy} className="flex w-full items-center gap-2.5 rounded-md border border-stone-200 bg-white px-2.5 py-2 text-left transition-colors hover:border-brass-400 hover:bg-brass-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
                            <Avatar name={p.name} size="sm" /><span className="min-w-0"><span className="block truncate text-sm font-medium text-navy-900">{p.name}</span><span className="block truncate text-2xs text-stone-600">{busy === p.email ? 'Signing in…' : (p.job_title ?? role)}</span></span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  )
}
