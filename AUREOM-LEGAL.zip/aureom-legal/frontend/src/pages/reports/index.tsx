import { Link, Route, Routes } from 'react-router-dom'
import { ArrowUpRight, Lock } from 'lucide-react'
import { usePageTitle } from '@/hooks'
import { useAuth } from '@/lib/auth'
import { Badge, NotFoundState, PageHeader, PermissionDenied } from '@/components/ui'
import { Notice } from '@/pages/billing/shared'
import { REPORTS } from './catalogue'
import ReportPage from './ReportPage'

function Catalogue() {
  usePageTitle('Reports')
  const { can } = useAuth()
  if (!can('reports.read') && !can('reports.financial')) return <><PageHeader title="Reports" /><PermissionDenied permission="reports.read" /></>
  return (
    <>
      <PageHeader eyebrow="Practice intelligence" title="Reports" description="Every report states its period, filters, currency and calculation basis. Billed, received and recognised are always reported separately." />
      <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {REPORTS.map((r) => {
          const ok = can(r.financial ? 'reports.financial' : 'reports.read')
          const body = (
            <div className={`flex h-full flex-col rounded-lg border bg-white p-5 shadow-panel transition-colors ${ok ? 'border-stone-200 group-hover:border-brass-400' : 'border-stone-200 opacity-70'}`}>
              <div className="mb-2 flex items-start justify-between gap-2"><h2 className="font-serif text-lg text-navy-900">{r.title}</h2>{ok ? <ArrowUpRight className="h-4 w-4 text-stone-400 group-hover:text-brass-600" aria-hidden /> : <Lock className="h-4 w-4 text-stone-500" aria-label="Restricted" />}</div>
              <p className="flex-1 text-sm text-stone-700">{r.description}</p>
              <div className="mt-3 flex gap-2">{r.financial && <Badge tone="brass">Financial</Badge>}{!ok && <Badge tone="warning">Needs reports.financial</Badge>}</div>
            </div>)
          return <li key={r.name}>{ok ? <Link to={`/reports/${r.name}`} className="group block h-full rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500 focus-visible:ring-offset-2">{body}</Link> : <div title="Your role cannot run this report">{body}</div>}</li>
        })}
      </ul>
      <Notice className="mt-6">Reports only include matters and records you are permitted to see; restricted matters you are not on are never counted. Demonstration data is synthetic and the financial reports are illustrative until the firm's accounting procedures have been reviewed.</Notice>
    </>
  )
}

export default function ReportsSection() {
  return (
    <Routes>
      <Route index element={<Catalogue />} />
      <Route path=":name" element={<ReportPage />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
