import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Download, ShieldAlert } from 'lucide-react'
import { ApiError, api, qs, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { usePageTitle } from '@/hooks'
import { Badge, Button, Card, DataTable, DateTime, Field, Input, KeyValue, Money, NotFoundState, PageHeader, PermissionDenied, QueryBoundary, Select, StatCard, StatusBadge, type Column } from '@/components/ui'
import { formatDateTime, formatDecimal, humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { BudgetBar } from '@/pages/billing/WipTab'
import { cmp, Notice } from '@/pages/billing/shared'
import { LedgerBadge } from '@/pages/ledger/common'
import type { LedgerKey, ReportData } from '@/types/finance'
import { BarChart, type BarDatum } from './BarChart'
import { REPORTS } from './catalogue'

type Row = Record<string, unknown>
const s = (v: unknown) => (v === null || v === undefined ? '' : String(v))
const money = (key: string, header: string): Column<Row> => ({ key, header, numeric: true, cell: (r) => <Money value={s(r[key])} /> })
const link = (to: (r: Row) => string, text: (r: Row) => string) => (r: Row) => <Link className="font-medium text-navy-700 underline-offset-2 hover:underline" to={to(r)}>{text(r) || '—'}</Link>

function columnsFor(name: string): Column<Row>[] {
  switch (name) {
    case 'wip': return [
      { key: 'reference', header: 'Matter', cell: (r) => <div>{link((x) => `/matters/${s(x.matter_id)}`, (x) => s(x.reference))(r)}<p className="max-w-xs truncate text-xs text-stone-600">{s(r.title)}</p></div> },
      { key: 'fee_earner', header: 'Fee earner', hideOnNarrow: true, cell: (r) => s(r.fee_earner) || '—' },
      { key: 'hours', header: 'Hours', numeric: true, cell: (r) => s(r.hours) }, money('time', 'Time'), money('expenses', 'Expenses'), money('total', 'Unbilled'),
      { key: 'budget', header: 'Against budget', cell: (r) => <BudgetBar used={s(r.total)} budget={s(r.budget) || null} /> }]
    case 'billing': return [
      { key: 'number', header: 'Invoice', cell: link((r) => `/billing/invoices/${s(r.invoice_id)}`, (r) => s(r.number)) },
      { key: 'kind', header: 'Type', cell: (r) => (r.kind === 'credit_note' ? <Badge tone="brass">Credit note</Badge> : 'Invoice') },
      { key: 'matter', header: 'Matter', cell: (r) => s(r.matter) }, { key: 'issued_at', header: 'Issued', cell: (r) => <DateTime value={s(r.issued_at)} mode="date" /> },
      money('net', 'Net'), money('vat', 'VAT'), money('total', 'Total')]
    case 'cash-received': return [
      { key: 'received_on', header: 'Received', cell: (r) => <DateTime value={s(r.received_on)} mode="date" /> },
      { key: 'ledger', header: 'Ledger', cell: (r) => <LedgerBadge ledger={s(r.ledger) as LedgerKey} /> }, { key: 'reference', header: 'Reference', cell: (r) => s(r.reference) || '—' },
      money('amount', 'Amount'), money('allocated', 'Allocated'), money('unallocated', 'Unallocated'), { key: 'status', header: 'Status', cell: (r) => <StatusBadge status={s(r.status)} /> }]
    case 'recognised-revenue': return [
      { key: 'recognised_on', header: 'Recognised', cell: (r) => <DateTime value={s(r.recognised_on)} mode="date" /> },
      { key: 'invoice_id', header: 'Invoice', cell: link((r) => `/billing/invoices/${s(r.invoice_id)}`, () => 'Open invoice') }, money('amount', 'Amount'), { key: 'basis', header: 'Basis', cell: (r) => s(r.basis) }]
    case 'aged-debtors': return [
      { key: 'number', header: 'Invoice', cell: link((r) => `/billing/invoices/${s(r.invoice_id)}`, (r) => s(r.number)) }, { key: 'matter', header: 'Matter', cell: (r) => s(r.matter) },
      { key: 'issued_at', header: 'Issued', cell: (r) => <DateTime value={s(r.issued_at)} mode="date" /> }, { key: 'days', header: 'Days', numeric: true, cell: (r) => s(r.days) },
      { key: 'bucket', header: 'Age band', cell: (r) => <Badge tone={s(r.bucket) === '90+' ? 'danger' : s(r.bucket) === '61-90' ? 'warning' : 'neutral'}>{s(r.bucket)} days</Badge> },
      money('total', 'Total'), money('paid', 'Paid'), money('outstanding', 'Outstanding')]
    case 'client-money': return [
      { key: 'reference', header: 'Matter', cell: (r) => <div>{link((x) => `/matters/${s(x.matter_id)}`, (x) => s(x.reference))(r)}<p className="max-w-md truncate text-xs text-stone-600">{s(r.title)}</p></div> }, money('balance', 'Held for client')]
    case 'utilisation': return [
      { key: 'name', header: 'Fee earner', cell: (r) => s(r.name) }, { key: 'hours', header: 'Recorded hours', numeric: true, cell: (r) => s(r.hours) },
      { key: 'billable_hours', header: 'Billable hours', numeric: true, cell: (r) => s(r.billable_hours) },
      { key: 'billable_share_pct', header: 'Billable share', numeric: true, cell: (r) => (r.billable_share_pct ? `${s(r.billable_share_pct)}%` : '—') }, money('billable_value', 'Billable value')]
    default: return []
  }
}

function chartFor(name: string, rows: Row[], currency: string) {
  if (name === 'wip') return <BarChart title="Unbilled work by matter (top 10)" currency={currency} data={[...rows].sort((a, b) => cmp(s(b.total), s(a.total))).slice(0, 10).map((r): BarDatum => ({ label: s(r.reference), value: s(r.total) }))} />
  if (name === 'utilisation') return <BarChart title="Recorded and billable hours" unit="hours" label1="Recorded" label2="Billable" data={rows.map((r): BarDatum => ({ label: s(r.name), value: s(r.hours), value2: s(r.billable_hours) }))} />
  return null
}

function Totals({ name, t, currency }: { name: string; t: Record<string, unknown>; currency: string }) {
  const m = (k: string) => <Money value={s(t[k])} currency={currency} />
  if (name === 'wip') return <div className="grid gap-4 sm:grid-cols-3"><StatCard label="Unbilled time" value={m('time')} /><StatCard label="Unbilled expenses" value={m('expenses')} /><StatCard label="Total WIP" tone="brass" value={m('total')} footnote="Work in progress is not revenue." /></div>
  if (name === 'billing') return <div className="grid gap-4 sm:grid-cols-3"><StatCard label="Net billed" value={m('net')} /><StatCard label="VAT" value={m('vat')} /><StatCard label="Total billed" tone="brass" value={m('total')} footnote={`${s(t.label)} — not revenue, not cash.`} /></div>
  if (name === 'cash-received') return <div className="grid gap-4 sm:grid-cols-2"><StatCard label="Office receipts" value={m('office_receipts')} footnote="Cash received is not earned revenue." /><StatCard label="Client money receipts" tone="brass" value={m('client_money_receipts')} footnote="Held for clients — not the firm's money." /></div>
  if (name === 'recognised-revenue') return <div className="grid gap-4 sm:grid-cols-2"><StatCard label="Recognised in period" tone="success" value={m('recognised')} footnote="Only via the authorised recognition step." /></div>
  if (name === 'aged-debtors') return <div className="grid gap-4 sm:grid-cols-5">{['0-30', '31-60', '61-90', '90+'].map((b) => <StatCard key={b} label={`${b} days`} tone={b === '90+' ? 'danger' : 'neutral'} value={m(b)} />)}<StatCard label="Total outstanding" tone="brass" value={m('total')} /></div>
  if (name === 'client-money') return <div className="grid gap-4 sm:grid-cols-3"><StatCard label="Held on matters you can see" tone="brass" value={m('client_money_held_visible')} /><StatCard label="Client bank ledger balance" value={m('client_bank_ledger_balance')} hint="All matters" /><StatCard label="Last signed-off reconciliation" value={t.last_signed_off_reconciliation ? <DateTime value={s(t.last_signed_off_reconciliation)} mode="date" /> : 'None'} /></div>
  return null
}

const firstOfMonth = () => { const d = new Date(); return new Date(Date.UTC(d.getFullYear(), d.getMonth(), 1)).toISOString().slice(0, 10) }
const today = () => new Date().toISOString().slice(0, 10)

export default function ReportPage() {
  const { name = '' } = useParams()
  const meta = REPORTS.find((r) => r.name === name)
  usePageTitle(meta?.title ?? 'Report')
  useBreadcrumbs([{ label: 'Reports', to: '/reports' }, { label: meta?.title ?? 'Report' }])
  const { can } = useAuth()
  const [from, setFrom] = useState(firstOfMonth())
  const [to, setTo] = useState(today())
  const [asOf, setAsOf] = useState(today())
  const [area, setArea] = useState('')
  const [busy, setBusy] = useState(false)
  const [csvErr, setCsvErr] = useState<string | null>(null)

  const params = useMemo(() => ({
    date_from: meta?.period === 'range' ? from : undefined, date_to: meta?.period === 'range' ? to : undefined,
    as_of: meta?.period === 'asof' ? asOf : undefined, practice_area: meta?.filters.includes('practice_area') ? area || undefined : undefined,
  }), [meta, from, to, asOf, area])
  const q = useApiQuery<ReportData>(['reports', name, params], `/reports/${name}${qs(params)}`, { enabled: !!meta, retry: false })

  if (!meta) return <NotFoundState what="report" />
  const permitted = can(meta.financial ? 'reports.financial' : 'reports.read')

  const exportCsv = async () => {
    setBusy(true); setCsvErr(null)
    try {
      const blob = await api.blob(`/reports/${name}.csv${qs(params)}`)
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `${name}.csv`; a.click(); URL.revokeObjectURL(url)
    } catch (e) { setCsvErr(e instanceof ApiError ? e.message : 'Export failed') } finally { setBusy(false) }
  }
  const cols = columnsFor(name)
  return (
    <>
      <PageHeader eyebrow="Report" title={meta.title} description={meta.description}
        actions={permitted ? <Button variant="secondary" icon={<Download className="h-4 w-4" />} loading={busy} onClick={() => void exportCsv()}>Export CSV</Button> : undefined} />
      {!permitted ? <PermissionDenied permission={meta.financial ? 'reports.financial' : 'reports.read'} message={meta.financial ? 'Financial reports are available to partners and finance roles.' : undefined} /> : (
        <div className="space-y-6">
          <Card title="Period and filters">
            <div className="flex flex-wrap items-end gap-4">
              {meta.period === 'range' && <><Field label="From"><Input type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} className="w-44" /></Field><Field label="To"><Input type="date" value={to} min={from} onChange={(e) => setTo(e.target.value)} className="w-44" /></Field></>}
              {meta.period === 'asof' && <Field label="As at"><Input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} className="w-44" /></Field>}
              {meta.filters.includes('practice_area') && <Field label="Practice area"><Select value={area} onChange={(e) => setArea(e.target.value)} className="w-52"><option value="">All practice areas</option>{['commercial', 'property', 'litigation', 'employment', 'private_client', 'corporate'].map((a) => <option key={a} value={a}>{humanise(a)}</option>)}</Select></Field>}
              {meta.period === 'none' && !meta.filters.length && <p className="text-sm text-stone-600">This report is a current snapshot; it has no period or filter controls.</p>}
            </div>
          </Card>
          <QueryBoundary query={q} what="report" empty={null} isEmpty={() => false}>
            {(d) => (
              <>
                <Card title="Report definition" description="What this report covers and exactly how it is calculated">
                  <KeyValue columns={3} items={[
                    { label: 'Period', value: d.period.from ? `${d.period.from} → ${d.period.to}` : d.period.as_of ? `As at ${d.period.as_of}` : 'Current snapshot' },
                    { label: 'Filters', value: Object.keys(d.filters).length ? Object.entries(d.filters).map(([k, v]) => <Badge key={k} className="mr-1">{humanise(k)}: {s(v)}</Badge>) : 'None (all visible records)' },
                    { label: 'Currency', value: d.currency }, { label: 'Generated', value: formatDateTime(d.generated_at) }, { label: 'Rows', value: String(d.rows.length) }]} />
                  <Notice tone="brass" title="Calculation basis" className="mt-4">{d.basis}</Notice>
                </Card>
                <Totals name={name} t={d.totals} currency={d.currency} />
                {chartFor(name, d.rows, d.currency)}
                <Card title={meta.title} padded={false}>
                  <DataTable caption={meta.title} columns={cols} rows={d.rows} rowKey={(r) => s(r.invoice_id ?? r.payment_id ?? r.matter_id ?? r.id ?? r.user_id ?? JSON.stringify(r))} className="rounded-none border-0 shadow-none" emptyTitle="No rows for this period" emptyDescription="Try widening the period or clearing filters. Records you cannot access are never included." />
                </Card>
                {d.by_fee_earner && d.by_fee_earner.length > 0 && (
                  <Card title="By fee earner" padded={false}><DataTable caption="By fee earner" rowKey={(r) => s(r.user_id)} rows={d.by_fee_earner} className="rounded-none border-0 shadow-none"
                    columns={[{ key: 'name', header: 'Fee earner', cell: (r) => s(r.name) }, { key: 'hours', header: 'Hours', numeric: true, cell: (r) => formatDecimal(s(r.hours)) }, money('time', 'Unbilled time')]} /></Card>)}
                <p className="flex items-center gap-2 text-xs text-stone-600"><ShieldAlert className="h-3.5 w-3.5" aria-hidden />CSV export is audited as a sensitive export. Figures use only records you may see. {csvErr && <span role="alert" className="font-medium text-bad-700">{csvErr}</span>}</p>
              </>)}
          </QueryBoundary>
        </div>)}
    </>
  )
}
