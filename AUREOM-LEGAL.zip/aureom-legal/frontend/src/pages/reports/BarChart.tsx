import { formatMoney } from '@/lib/format'
import { pctOf } from '@/pages/billing/shared'

export interface BarDatum { label: string; value: string; value2?: string }

/**
 * Restrained horizontal bar chart (inline SVG). Zero baseline, direct value labels, no gridlines.
 * Bar lengths come from exact decimal ratios (BigInt) — no float arithmetic on money.
 * The full data is always available in the table beneath it; this component also exposes a text alternative.
 */
export function BarChart({ title, data, currency = 'GBP', unit = 'money', label2, label1 }: {
  title: string; data: BarDatum[]; currency?: string; unit?: 'money' | 'hours'; label1?: string; label2?: string
}) {
  if (data.length === 0) return null
  const max = data.reduce((m, d) => { const a = d.value, b = d.value2 ?? '0'; const big = (x: string, y: string) => (pctOf(x, y) ?? 0) >= 100 ? x : y; return big(m, big(a, b)) }, '0')
  const fmt = (v: string) => (unit === 'money' ? formatMoney(v, currency) : `${v} h`)
  const H = data.reduce((s, d) => s + (d.value2 !== undefined ? 40 : 28), 8)
  const W = 640, LBL = 150, VAL = 92, BAR = W - LBL - VAL
  let y = 4
  const alt = `${title}. ` + data.map((d) => `${d.label}: ${fmt(d.value)}${d.value2 !== undefined ? ` and ${fmt(d.value2)}` : ''}`).join('; ')
  return (
    <figure className="rounded-lg border border-stone-200 bg-white p-5 shadow-panel">
      <figcaption className="mb-3 flex flex-wrap items-center justify-between gap-2 text-sm font-semibold text-navy-900">
        <span>{title}</span>
        {label2 && <span className="flex items-center gap-3 text-xs font-normal text-stone-700"><span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm bg-navy-600" aria-hidden />{label1}</span><span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm bg-brass-500" aria-hidden />{label2}</span></span>}
      </figcaption>
      <svg role="img" aria-label={alt} viewBox={`0 0 ${W} ${H}`} className="h-auto w-full">
        <title>{title}</title>
        {data.map((d) => {
          const two = d.value2 !== undefined
          const h = two ? 40 : 28
          const w1 = Math.max(0, ((pctOf(d.value, max) ?? 0) / 100) * BAR)
          const w2 = two ? Math.max(0, ((pctOf(d.value2!, max) ?? 0) / 100) * BAR) : 0
          const top = y; y += h
          return (
            <g key={d.label} transform={`translate(0 ${top})`}>
              <text x={LBL - 8} y={two ? 18 : 18} textAnchor="end" className="fill-stone-800 text-[11px]">{d.label.length > 24 ? d.label.slice(0, 23) + '…' : d.label}</text>
              <rect x={LBL} y={6} width={w1 || 1} height={two ? 12 : 16} rx={2} className="fill-navy-600" />
              <text x={LBL + w1 + 6} y={two ? 16 : 19} className="fill-navy-900 text-[11px] tabular-nums">{fmt(d.value)}</text>
              {two && <><rect x={LBL} y={21} width={w2 || 1} height={12} rx={2} className="fill-brass-500" /><text x={LBL + w2 + 6} y={31} className="fill-navy-900 text-[11px] tabular-nums">{fmt(d.value2!)}</text></>}
            </g>)
        })}
        <line x1={LBL} y1={0} x2={LBL} y2={H} className="stroke-stone-300" />
      </svg>
    </figure>
  )
}
