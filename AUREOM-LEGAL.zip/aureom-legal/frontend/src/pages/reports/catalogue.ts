export interface ReportMeta { name: string; title: string; description: string; financial: boolean; period: 'range' | 'asof' | 'none'; filters: string[] }

export const REPORTS: ReportMeta[] = [
  { name: 'wip', title: 'Work in progress', description: 'Unbilled time and expenses by matter, with budget position. WIP is work done but not yet billed — not revenue.', financial: false, period: 'none', filters: ['practice_area'] },
  { name: 'billing', title: 'Billed', description: 'Invoices and credit notes issued in the period. “Billed” is not recognised revenue and not cash received.', financial: true, period: 'range', filters: ['practice_area'] },
  { name: 'cash-received', title: 'Cash received', description: 'Authorised receipts by date, split between office money and client money. Receipts are not earned revenue.', financial: true, period: 'range', filters: [] },
  { name: 'recognised-revenue', title: 'Recognised revenue', description: 'Revenue recognised through the explicit, separately authorised recognition step.', financial: true, period: 'range', filters: [] },
  { name: 'aged-debtors', title: 'Aged debtors', description: 'Issued invoices still owed, aged by days since issue.', financial: true, period: 'asof', filters: [] },
  { name: 'client-money', title: 'Client money by matter', description: 'Money held for clients per matter, against the latest signed-off client reconciliation.', financial: true, period: 'none', filters: [] },
  { name: 'utilisation', title: 'Fee-earner utilisation', description: 'Recorded and billable hours per fee earner. No target hours are assumed.', financial: false, period: 'range', filters: [] },
]
