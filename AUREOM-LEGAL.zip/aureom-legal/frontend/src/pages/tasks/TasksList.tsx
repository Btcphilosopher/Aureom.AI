import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { Badge, Button, Checkbox, DataTable, DateTime, EmptyState, Select, StatusBadge, type Column } from '@/components/ui'
import { qs, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { useQueryParams } from '@/hooks'
import type { Page } from '@/types/api'
import type { Task } from '@/types/tasks'
import { PRIORITIES, TASK_STATUSES, useMatterOptions, useStaff } from './shared'
import { TaskDrawer, TaskForm } from './TaskDrawer'

const PARAMS = ['assignee', 'status', 'matter', 'overdue', 'view'] as const

export function TasksList({ forceCreate, onCloseCreate }: { forceCreate?: boolean; onCloseCreate?: () => void }) {
  const { id } = useParams()
  const nav = useNavigate()
  const { me, can } = useAuth()
  const staff = useStaff()
  const matters = useMatterOptions()
  const [p, setP] = useQueryParams(PARAMS)
  const [offset, setOffset] = useState(0)
  const [creating, setCreating] = useState(false)
  const mineView = p.view !== 'all'
  const assignee = p.assignee === 'me' ? me?.user.id : p.assignee
  const params = {
    mine: mineView && !p.assignee ? true : undefined, assignee_id: !mineView || p.assignee ? assignee : undefined,
    matter_id: p.matter, status: p.status === 'open' ? 'open,in_progress,blocked' : p.status, overdue: p.overdue === '1' ? true : undefined, limit: 25, offset,
  }
  const q = useApiQuery<Page<Task>>(['tasks', params], `/tasks${qs(params)}`)
  const cols: Column<Task>[] = [
    { key: 'title', header: 'Task', cell: (t) => (
      <span className="block min-w-0"><span className="block truncate font-medium text-navy-900">{t.title}</span>
        <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-stone-600">
          {t.matter_reference ? <span className="font-mono">{t.matter_reference}</span> : <span>No matter</span>}
          {t.blocked_by.length > 0 && <Badge tone="warning">Blocked by {t.blocked_by.length}</Badge>}
          {t.recurrence && <Badge tone="neutral">Repeats {t.recurrence.freq}</Badge>}
          {t.source === 'agent' && <Badge tone="info">From AI proposal</Badge>}
        </span></span>) },
    { key: 'assignee', header: 'Assignee', hideOnNarrow: true, cell: (t) => t.assignee_name ?? <span className="text-stone-500">Unassigned</span> },
    { key: 'due', header: 'Due', cell: (t) => <span className={t.is_overdue ? 'font-semibold text-bad-700' : ''}>{t.is_overdue && <span className="sr-only">Overdue: </span>}<DateTime value={t.due_at} /></span> },
    { key: 'priority', header: 'Priority', hideOnNarrow: true, cell: (t) => <StatusBadge status={t.priority} /> },
    { key: 'status', header: 'Status', cell: (t) => <StatusBadge status={t.status} /> },
  ]
  const clear = () => { setP({ assignee: null, status: null, matter: null, overdue: null }); setOffset(0) }
  return (
    <>
      <div className="mb-4 flex flex-wrap items-end gap-3 rounded-lg border border-stone-200 bg-white px-4 py-3 shadow-panel" role="search" aria-label="Task filters">
        <div className="space-y-1"><label htmlFor="t-view" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">View</label>
          <Select id="t-view" value={mineView ? 'mine' : 'all'} onChange={(e) => { setP({ view: e.target.value === 'all' ? 'all' : null }); setOffset(0) }} className="w-36"><option value="mine">My tasks</option><option value="all">All tasks</option></Select></div>
        {!mineView && <div className="space-y-1"><label htmlFor="t-ass" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Assignee</label>
          <Select id="t-ass" value={p.assignee ?? ''} onChange={(e) => { setP({ assignee: e.target.value || null }); setOffset(0) }} className="w-44"><option value="">Anyone</option><option value="me">Me</option>{staff.filter((s) => s.id !== me?.user.id).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></div>}
        <div className="space-y-1"><label htmlFor="t-status" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Status</label>
          <Select id="t-status" value={p.status ?? ''} onChange={(e) => { setP({ status: e.target.value || null }); setOffset(0) }} className="w-40"><option value="">Any</option><option value="open">Not finished</option>{TASK_STATUSES.map((s) => <option key={s} value={s}>{humanise(s)}</option>)}</Select></div>
        <div className="space-y-1"><label htmlFor="t-matter" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Matter</label>
          <Select id="t-matter" value={p.matter ?? ''} onChange={(e) => { setP({ matter: e.target.value || null }); setOffset(0) }} className="w-56"><option value="">All matters</option>{matters.map((m) => <option key={m.id} value={m.id}>{m.reference} · {m.title.slice(0, 32)}</option>)}</Select></div>
        <div className="pb-2"><Checkbox label="Overdue only" checked={p.overdue === '1'} onChange={(e) => { setP({ overdue: e.target.checked ? '1' : null }); setOffset(0) }} /></div>
        <Button variant="ghost" size="sm" onClick={clear}>Clear filters</Button>
        {can('tasks.write') && <Button className="ml-auto" icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(true)}>New task</Button>}
      </div>
      <DataTable caption="Tasks" columns={cols} rows={q.data?.items} rowKey={(t) => t.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
        onRowClick={(t) => nav(`/tasks/${t.id}${window.location.search}`)}
        emptyTitle={mineView ? 'No tasks assigned to you' : 'No tasks match these filters'} emptyDescription="Tasks you create or that are assigned to you appear here." emptyAction={can('tasks.write') ? <Button size="sm" onClick={() => setCreating(true)}>Create a task</Button> : undefined}
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} />
      {!can('tasks.write') && <EmptyState className="mt-4" title="Read-only access" description="Your role can view tasks but not create or change them." />}
      <TaskForm open={creating || !!forceCreate} onClose={() => { setCreating(false); onCloseCreate?.() }} />
      <TaskDrawer taskId={id} onClose={() => nav(`/tasks${window.location.search}`)} />
    </>
  )
}
