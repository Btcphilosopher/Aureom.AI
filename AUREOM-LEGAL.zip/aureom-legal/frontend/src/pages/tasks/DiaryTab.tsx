import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react'
import { Link } from 'react-router-dom'
import { CalendarClock, CalendarDays, ChevronLeft, ChevronRight, Download, Plus, RefreshCw, Trash2 } from 'lucide-react'
import { Badge, Button, Checkbox, ConfirmDialog, DateTime, Dialog, Field, Input, LoadingState, Select, SimulatedBanner, Textarea, ErrorState, Card } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatTime, humanise } from '@/lib/format'
import { cn } from '@/lib/cn'
import { useNewParam, useQueryParam } from '@/hooks'
import type { DiaryEvent, FeedItem } from '@/types/tasks'
import { fromLocalInput, toLocalInput, useMatterOptions, useStaff, ymd } from './shared'

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
const KINDS = ['appointment', 'hearing', 'meeting', 'call'] as const
const startOfWeek = (d: Date) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x }
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
const itemDay = (it: FeedItem) => (it.all_day || /^\d{4}-\d{2}-\d{2}$/.test(it.start) ? it.start.slice(0, 10) : ymd(new Date(it.start)))

const KIND_STYLE: Record<FeedItem['kind'], string> = {
  event: 'bg-navy-50 text-navy-800 ring-navy-200', task: 'bg-ivory-200 text-stone-800 ring-stone-300', deadline: 'bg-brass-50 text-brass-700 ring-brass-200',
}

function chipLabel(it: FeedItem) {
  if (it.kind === 'deadline') return it.authoritative ? `Deadline: ${it.title}` : it.title
  if (it.kind === 'task') return `Task: ${it.title}`
  return `${formatTime(it.start)} ${it.title}`
}

export function DiaryTab() {
  const { can } = useAuth()
  const { isNew, clear } = useNewParam()
  const [eventParam, setEventParam] = useQueryParam('event')
  const [cursor, setCursor] = useState(() => new Date())
  const [selected, setSelected] = useState(() => ymd(new Date()))
  const [view, setView] = useState<'month' | 'week'>('month')
  const [scope, setScope] = useState<'mine' | 'all'>('mine')
  const [editing, setEditing] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  useEffect(() => { if (isNew) { setCreating(true); clear() } }, [isNew]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (eventParam) { setEditing(eventParam); setEventParam(null) } }, [eventParam]) // eslint-disable-line react-hooks/exhaustive-deps

  const { from, to, days } = useMemo(() => {
    if (view === 'week') { const s = startOfWeek(cursor); return { from: s, to: addDays(s, 6), days: Array.from({ length: 7 }, (_, i) => addDays(s, i)) } }
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1)
    const s = startOfWeek(first)
    const last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)
    const e = addDays(startOfWeek(last), 6)
    const n = Math.round((e.getTime() - s.getTime()) / 86400000) + 1
    return { from: s, to: e, days: Array.from({ length: n }, (_, i) => addDays(s, i)) }
  }, [cursor, view])
  const q = useApiQuery<FeedItem[]>(['diary', 'feed', ymd(from), ymd(to), scope], `/diary/feed${qs({ from: ymd(from), to: ymd(to), scope })}`)
  const byDay = useMemo(() => {
    const m = new Map<string, FeedItem[]>()
    q.data?.forEach((it) => { const k = itemDay(it); m.set(k, [...(m.get(k) ?? []), it]) })
    m.forEach((v) => v.sort((a, b) => a.start.localeCompare(b.start)))
    return m
  }, [q.data])
  const refs = useRef<Record<string, HTMLButtonElement | null>>({})
  const title = view === 'month' ? cursor.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }) : `Week of ${from.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}`
  const step = (dir: -1 | 1) => setCursor((c) => view === 'month' ? new Date(c.getFullYear(), c.getMonth() + dir, 1) : addDays(c, 7 * dir))

  const moveSel = (delta: number) => {
    const cur = new Date(selected + 'T12:00:00')
    const next = addDays(cur, delta)
    const key = ymd(next)
    setSelected(key)
    if (next < from || next > to) setCursor(next)
    setTimeout(() => refs.current[key]?.focus(), 0)
  }
  const onKey = (e: KeyboardEvent) => {
    const map: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }
    if (e.key in map) { e.preventDefault(); moveSel(map[e.key]!) }
  }
  const [exporting, setExporting] = useState(false)
  const [exportErr, setExportErr] = useState<string | null>(null)
  const exportIcs = async () => {
    setExporting(true); setExportErr(null)
    try {
      const blob = await api.blob(`/diary/ics${qs({ from: ymd(from), to: ymd(to), scope })}`)
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'aureom-diary.ics'; a.click(); URL.revokeObjectURL(a.href)
    } catch (e) { setExportErr((e as Error).message) } finally { setExporting(false) }
  }
  const sel = byDay.get(selected) ?? []
  const todayKey = ymd(new Date())
  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1" role="group" aria-label="Change period">
          <Button variant="secondary" size="sm" aria-label="Previous period" onClick={() => step(-1)} icon={<ChevronLeft className="h-4 w-4" />} />
          <Button variant="secondary" size="sm" onClick={() => { setCursor(new Date()); setSelected(todayKey) }}>Today</Button>
          <Button variant="secondary" size="sm" aria-label="Next period" onClick={() => step(1)} icon={<ChevronRight className="h-4 w-4" />} />
        </div>
        <h2 className="font-serif text-2xl text-navy-900" aria-live="polite">{title}</h2>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="w-28"><Select aria-label="View" value={view} onChange={(e) => setView(e.target.value as 'month' | 'week')}><option value="month">Month</option><option value="week">Week</option></Select></div>
          <div className="w-44"><Select aria-label="Whose diary" value={scope} onChange={(e) => setScope(e.target.value as 'mine' | 'all')}><option value="mine">My diary</option><option value="all">Everyone visible</option></Select></div>
          <Button variant="secondary" size="sm" icon={<Download className="h-4 w-4" />} loading={exporting} onClick={() => void exportIcs()}>Export .ics</Button>
          {can('tasks.write') && <Button size="sm" icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(true)}>New event</Button>}
        </div>
      </div>
      {exportErr && <p role="alert" className="mb-3 rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{exportErr}</p>}
      <div className="grid gap-5 xl:grid-cols-[1fr_20rem]">
        <div>
          {q.isError ? <ErrorState error={q.error} onRetry={() => void q.refetch()} /> : (
            <div role="grid" aria-label={`Diary, ${title}`} aria-busy={q.isPending} onKeyDown={onKey} className="overflow-hidden rounded-lg border border-stone-200 bg-white shadow-panel">
              <div role="row" className="grid grid-cols-7 border-b border-stone-300 bg-ivory-200">
                {WEEKDAYS.map((d) => <div key={d} role="columnheader" className="px-2 py-2 text-center text-xs font-semibold uppercase tracking-wide text-stone-700">{d}</div>)}
              </div>
              {Array.from({ length: days.length / 7 }, (_, w) => (
                <div key={w} role="row" className="grid grid-cols-7">
                  {days.slice(w * 7, w * 7 + 7).map((d) => {
                    const key = ymd(d); const items = byDay.get(key) ?? []
                    const outside = view === 'month' && d.getMonth() !== cursor.getMonth()
                    const isSel = key === selected
                    return (
                      <div key={key} role="gridcell" aria-selected={isSel} className={cn('min-h-[6.5rem] border-b border-r border-stone-100 last:border-r-0', view === 'week' && 'min-h-[20rem]', outside && 'bg-stone-50')}>
                        <button ref={(el) => { refs.current[key] = el }} type="button" tabIndex={isSel ? 0 : -1} onClick={() => setSelected(key)}
                          aria-label={`${d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}, ${items.length} item${items.length === 1 ? '' : 's'}`}
                          className={cn('flex h-full w-full flex-col items-stretch gap-1 p-1.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500', isSel && 'bg-brass-50')}>
                          <span className={cn('inline-flex h-6 w-6 items-center justify-center self-start rounded-full text-xs tabular-nums', key === todayKey ? 'bg-navy-800 font-semibold text-white' : outside ? 'text-stone-500' : 'text-navy-900')}>{d.getDate()}</span>
                          {items.slice(0, view === 'week' ? 12 : 3).map((it) => (
                            <span key={it.kind + it.id} className={cn('truncate rounded px-1.5 py-0.5 text-2xs ring-1 ring-inset', KIND_STYLE[it.kind], it.kind === 'deadline' && !it.authoritative && 'border border-dashed border-warn-600 ring-0 bg-warn-50 text-warn-700')}>{chipLabel(it)}</span>))}
                          {items.length > (view === 'week' ? 12 : 3) && <span className="text-2xs text-stone-600">+{items.length - (view === 'week' ? 12 : 3)} more</span>}
                        </button>
                      </div>)
                  })}
                </div>))}
            </div>)}
          <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-stone-600" aria-label="Legend">
            <li><span className="mr-1 inline-block h-2.5 w-2.5 rounded-sm bg-navy-200 align-middle" />Appointment / hearing</li>
            <li><span className="mr-1 inline-block h-2.5 w-2.5 rounded-sm bg-stone-300 align-middle" />Task due</li>
            <li><span className="mr-1 inline-block h-2.5 w-2.5 rounded-sm bg-brass-200 align-middle" />Confirmed deadline</li>
            <li><span className="mr-1 inline-block h-2.5 w-2.5 rounded-sm border border-dashed border-warn-600 bg-warn-50 align-middle" />Unconfirmed suggestion (not authoritative)</li>
          </ul>
        </div>
        <aside aria-label="Selected day" aria-live="polite">
          <Card title={<span className="flex items-center gap-2"><CalendarDays className="h-4 w-4 text-brass-600" aria-hidden />{new Date(selected + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</span>} padded={false}>
            {q.isPending ? <LoadingState rows={2} /> : sel.length === 0 ? <p className="px-5 py-8 text-center text-sm text-stone-600">Nothing scheduled.</p> : (
              <ul>{sel.map((it) => (
                <li key={it.kind + it.id} className="border-b border-stone-100 px-5 py-3 last:border-b-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      {it.kind === 'event'
                        ? <button className="text-left text-sm font-medium text-navy-900 hover:text-brass-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500" onClick={() => setEditing(it.id)}>{it.title}</button>
                        : <Link className="text-sm font-medium text-navy-900 hover:text-brass-700" to={it.kind === 'deadline' ? `/tasks/deadlines/${it.id}` : `/tasks/${it.id}`}>{it.title}</Link>}
                      <p className="mt-0.5 text-xs text-stone-600">{it.kind === 'event' ? <>{formatTime(it.start)}{it.end ? `–${formatTime(it.end)}` : ''} · </> : null}{it.matter_reference ?? 'No matter'}</p>
                    </div>
                    {it.kind === 'deadline' ? (it.authoritative ? <Badge tone="success">Confirmed</Badge> : <Badge tone="warning">Unconfirmed</Badge>) : <Badge tone="neutral">{it.label ?? humanise(it.kind)}</Badge>}
                  </div>
                </li>))}</ul>)}
          </Card>
          <p className="mt-3 flex items-start gap-1.5 text-xs text-stone-600"><CalendarClock className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />Deadlines only appear as authoritative once a responsible solicitor has confirmed them.</p>
        </aside>
      </div>
      <EventDialog open={creating || !!editing} eventId={editing} defaultDate={selected} onClose={() => { setCreating(false); setEditing(null) }} />
    </div>
  )
}

interface EvState { title: string; kind: string; start: string; end: string; matter_id: string; location: string; attendee_ids: string[]; description: string }

function EventDialog({ open, eventId, defaultDate, onClose }: { open: boolean; eventId: string | null; defaultDate: string; onClose: () => void }) {
  const { can } = useAuth()
  const staff = useStaff()
  const matters = useMatterOptions()
  const ev = useApiQuery<DiaryEvent>(['diary', 'event', eventId], `/diary/events/${eventId}`, { enabled: !!eventId && open })
  const [f, setF] = useState<EvState>({ title: '', kind: 'appointment', start: '', end: '', matter_id: '', location: '', attendee_ids: [], description: '' })
  const [err, setErr] = useState<string | null>(null)
  const [conflict, setConflict] = useState(false)
  const [confirmDel, setConfirmDel] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [syncRes, setSyncRes] = useState<Record<string, unknown> | null>(null)
  const e = ev.data
  useEffect(() => {
    if (!open) return
    setErr(null); setConflict(false); setSubmitted(false); setSyncRes(null)
    if (eventId) { if (e) setF({ title: e.title, kind: e.kind, start: toLocalInput(e.start_at), end: toLocalInput(e.end_at), matter_id: e.matter_id ?? '', location: e.location ?? '', attendee_ids: e.attendee_ids, description: e.description ?? '' }) }
    else setF({ title: '', kind: 'appointment', start: `${defaultDate}T09:00`, end: `${defaultDate}T10:00`, matter_id: '', location: '', attendee_ids: [], description: '' })
  }, [open, eventId, e, defaultDate])
  const set = (p: Partial<EvState>) => setF((x) => ({ ...x, ...p }))
  const inv = [['diary'], ['home']]
  const body = () => ({ title: f.title.trim(), kind: f.kind, start_at: fromLocalInput(f.start), end_at: fromLocalInput(f.end), matter_id: f.matter_id || null, location: f.location || null, attendee_ids: f.attendee_ids, description: f.description || null })
  const save = useApiMutation(() => (eventId ? api.patch<DiaryEvent>(`/diary/events/${eventId}`, { ...body(), expected_version: e!.version }) : api.post<DiaryEvent>('/diary/events', body())),
    { invalidate: inv, successMessage: eventId ? 'Event saved' : 'Event created', errorToast: false, onSuccess: () => onClose(), onError: (x) => { if (x.isConflict) setConflict(true); else setErr(x.message) } })
  const del = useApiMutation(() => api.delete(`/diary/events/${eventId}`), { invalidate: inv, successMessage: 'Event deleted', onSuccess: () => { setConfirmDel(false); onClose() } })
  const sync = useApiMutation(() => api.post<Record<string, unknown>>(`/diary/events/${eventId}/sync`), { invalidate: inv, errorToast: false, onSuccess: (r) => setSyncRes(r), onError: (x) => setErr(x.isIntegrationUnavailable ? `Calendar integration unavailable: ${x.message}` : x.message) })
  const titleErr = submitted && !f.title.trim() ? 'A title is required.' : undefined
  const endErr = submitted && f.end && f.start && f.end < f.start ? 'End must be after the start.' : undefined
  const writable = can('tasks.write')
  const submit = () => { setSubmitted(true); if (!f.title.trim() || !f.start || (f.end && f.end < f.start)) return; save.mutate() }
  return (
    <Dialog open={open} onClose={onClose} size="lg" title={eventId ? 'Diary event' : 'New diary event'}
      footer={<>
        {eventId && writable && <Button variant="ghost" icon={<Trash2 className="h-4 w-4" />} onClick={() => setConfirmDel(true)} className="mr-auto">Delete</Button>}
        <Button variant="secondary" onClick={onClose}>Close</Button>
        {writable && <Button loading={save.isPending} onClick={submit} disabled={!!eventId && !e}>Save</Button>}</>}>
      {eventId && ev.isPending ? <LoadingState rows={3} /> : eventId && ev.isError ? <ErrorState error={ev.error} onRetry={() => void ev.refetch()} /> : (
        <div className="space-y-4">
          {conflict && <div role="alert" className="rounded border border-warn-100 bg-warn-50 px-3 py-2 text-sm text-warn-700">This event was changed by someone else. <button className="font-semibold underline" onClick={() => { void ev.refetch(); setConflict(false) }}>Reload the latest version</button> (your edits will be discarded).</div>}
          {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
          <Field label="Title" required error={titleErr}><Input value={f.title} onChange={(x) => set({ title: x.target.value })} data-autofocus disabled={!writable} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Type"><Select value={f.kind} disabled={!writable} onChange={(x) => set({ kind: x.target.value })}>{KINDS.map((k) => <option key={k} value={k}>{humanise(k)}</option>)}</Select></Field>
            <Field label="Matter"><Select value={f.matter_id} disabled={!writable} onChange={(x) => set({ matter_id: x.target.value })}><option value="">No matter</option>{matters.map((m) => <option key={m.id} value={m.id}>{m.reference} · {m.title.slice(0, 36)}</option>)}</Select></Field>
            <Field label="Starts" required><Input type="datetime-local" value={f.start} disabled={!writable} onChange={(x) => set({ start: x.target.value })} /></Field>
            <Field label="Ends" error={endErr}><Input type="datetime-local" value={f.end} disabled={!writable} onChange={(x) => set({ end: x.target.value })} /></Field>
          </div>
          <Field label="Location"><Input value={f.location} disabled={!writable} onChange={(x) => set({ location: x.target.value })} /></Field>
          <fieldset><legend className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-stone-700">Attendees</legend>
            <div className="grid max-h-36 gap-1 overflow-y-auto rounded border border-stone-200 p-2 sm:grid-cols-2">
              {staff.map((s) => <Checkbox key={s.id} label={s.name} disabled={!writable} checked={f.attendee_ids.includes(s.id)} onChange={(x) => set({ attendee_ids: x.target.checked ? [...f.attendee_ids, s.id] : f.attendee_ids.filter((i) => i !== s.id) })} />)}
            </div></fieldset>
          <Field label="Notes"><Textarea rows={3} value={f.description} disabled={!writable} onChange={(x) => set({ description: x.target.value })} /></Field>
          {eventId && e && (
            <div className="rounded-md border border-stone-200 bg-ivory-100 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm text-stone-700">Owner: <strong>{e.owner_name}</strong> · {e.external_calendar_ref ? <>Calendar ref <span className="font-mono text-xs">{e.external_calendar_ref}</span></> : 'Not synced to an external calendar'}</p>
                {writable && <Button size="sm" variant="secondary" icon={<RefreshCw className="h-3.5 w-3.5" />} loading={sync.isPending} onClick={() => sync.mutate()}>Sync to calendar (mock)</Button>}
              </div>
              {syncRes && (
                <div className="mt-3 space-y-2" role="status">
                  <SimulatedBanner>MOCK calendar integration — no external calendar (Microsoft 365 / Google) is connected. This sync was recorded locally only.</SimulatedBanner>
                  <p className="text-xs text-stone-700">{typeof syncRes.message === 'string' ? syncRes.message : 'Sync recorded (simulated).'}</p>
                </div>)}
            </div>)}
          <p className="text-2xs text-stone-500">{e && <>Version {e.version} · last start <DateTime value={e.start_at} /></>}</p>
        </div>)}
      <ConfirmDialog open={confirmDel} onClose={() => setConfirmDel(false)} title="Delete this event?" description="This removes the diary entry. It cannot be undone." confirmLabel="Delete event" tone="danger" loading={del.isPending} onConfirm={() => del.mutate()} />
    </Dialog>
  )
}
