import { useEffect } from 'react'
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { PageHeader, Tabs, NotFoundState } from '@/components/ui'
import { useAuth } from '@/lib/auth'
import { useNewParam, usePageTitle } from '@/hooks'
import { CalendarsTab, RulesTab } from './CalendarsTab'
import { DeadlinesTab } from './DeadlinesTab'
import { DiaryTab } from './DiaryTab'
import { TasksList } from './TasksList'

const TAB_PATHS = { tasks: '/tasks', diary: '/tasks/diary', deadlines: '/tasks/deadlines', calendars: '/tasks/calendars', rules: '/tasks/rules' } as const

function tabOf(path: string): keyof typeof TAB_PATHS {
  if (path.startsWith('/tasks/diary')) return 'diary'
  if (path.startsWith('/tasks/deadlines')) return 'deadlines'
  if (path.startsWith('/tasks/calendars')) return 'calendars'
  if (path.startsWith('/tasks/rules')) return 'rules'
  return 'tasks'
}

function Frame({ children }: { children: React.ReactNode }) {
  const loc = useLocation()
  const nav = useNavigate()
  const { can } = useAuth()
  usePageTitle('Tasks & Diary')
  const tab = tabOf(loc.pathname)
  return (
    <>
      <PageHeader eyebrow="Tasks & Diary" title="Tasks, diary and deadlines" description="Assign work, run your diary and keep legal deadlines honest: suggestions stay unconfirmed until a solicitor confirms them." />
      <Tabs label="Tasks and diary sections" value={tab} onChange={(id) => nav(TAB_PATHS[id as keyof typeof TAB_PATHS])} className="mb-5"
        tabs={[{ id: 'tasks', label: 'Tasks' }, { id: 'diary', label: 'Diary' }, { id: 'deadlines', label: 'Deadlines' }, { id: 'calendars', label: 'Calendars & holidays' }, { id: 'rules', label: 'Deadline rules' }]} />
      <div role="tabpanel">{children}</div>
      {!can('tasks.read') && null}
    </>
  )
}

/** Handles the quick-create links (?new=task | ?new=event) and old deep-link query forms (?tab=diary&event=…). */
function Redirects() {
  const loc = useLocation()
  const nav = useNavigate()
  const { kind } = useNewParam()
  const params = new URLSearchParams(loc.search)
  const tab = params.get('tab')
  useEffect(() => {
    if (tab === 'diary') { params.delete('tab'); nav(`/tasks/diary${params.toString() ? `?${params}` : ''}`, { replace: true }) }
    else if (kind === 'event' && !loc.pathname.startsWith('/tasks/diary')) nav('/tasks/diary?new=event', { replace: true })
  }, [tab, kind]) // eslint-disable-line react-hooks/exhaustive-deps
  return null
}

function TasksPage({ withId }: { withId?: boolean }) {
  const { kind, clear } = useNewParam()
  void withId
  return <TasksList forceCreate={kind === 'task'} onCloseCreate={clear} />
}

export default function TasksSection() {
  return (
    <Frame>
      <Redirects />
      <Routes>
        <Route index element={<TasksPage />} />
        <Route path="diary" element={<DiaryTab />} />
        <Route path="deadlines" element={<DeadlinesTab />} />
        <Route path="deadlines/:id" element={<DeadlinesTab />} />
        <Route path="calendars" element={<CalendarsTab />} />
        <Route path="rules" element={<RulesTab />} />
        <Route path=":id" element={<TasksPage withId />} />
        <Route path="*" element={<NotFoundState what="page" action={<Navigate to="/tasks" replace />} />} />
      </Routes>
    </Frame>
  )
}
