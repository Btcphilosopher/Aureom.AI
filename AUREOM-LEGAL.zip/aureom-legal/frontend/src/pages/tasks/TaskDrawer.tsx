import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle2, Link2, Play, RotateCcw, Trash2, XCircle } from 'lucide-react'
import { Badge, Button, ConfirmDialog, DateTime, Dialog, Drawer, Field, Input, KeyValue, LoadingState, Select, StatusBadge, Textarea, ErrorState } from '@/components/ui'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { Task, TaskDeps } from '@/types/tasks'
import { PRIORITIES, fromLocalInput, toLocalInput, useMatterOptions, useStaff } from './shared'

interface FormState {
  title: string; description: string; matter_id: string; assignee_id: string; due: string; priority: string
  recFreq: string; recInterval: string; recUntil: string; reminders: string; escalate_to_id: string; escalate_after_hours: string
}
const blank: FormState = { title: '', description: '', matter_id: '', assignee_id: '', due: '', priority: 'normal', recFreq: '', recInterval: '1', recUntil: '', reminders: '', escalate_to_id: '', escalate_after_hours: '' }
const fromTask = (t: Task): FormState => ({
  title: t.title, description: t.description ?? '', matter_id: t.matter_id ?? '', assignee_id: t.assignee_id ?? '', due: toLocalInput(t.due_at), priority: t.priority,
  recFreq: t.recurrence?.freq ?? '', recInterval: String(t.recurrence?.interval ?? 1), recUntil: t.recurrence?.until ?? '', reminders: t.reminder_offsets_minutes.join(', '),
  escalate_to_id: t.escalate_to_id ?? '', escalate_after_hours: t.escalate_after_hours ? String(t.escalate_after_hours) : '',
})
function parseReminders(s: string): number[] | null {
  if (!s.trim()) return []
  const parts = s.split(',').map((x) => x.trim())
  const nums = parts.map((x) => (/^\d+$/.test(x) ? parseInt(x, 10) : NaN))
  return nums.some(Number.isNaN) ? null : nums
}

function TaskFields({ f, set, lockMatter, errors }: { f: FormState; set: (p: Partial<FormState>) => void; lockMatter?: boolean; errors: Partial<Record<keyof FormState, string>> }) {
  const staff = useStaff()
  const matters = useMatterOptions()
  return (
    <div className="space-y-4">
      <Field label="Title" required error={errors.title}><Input value={f.title} onChange={(e) => set({ title: e.target.value })} maxLength={300} data-autofocus /></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Matter"><Select value={f.matter_id} disabled={lockMatter} onChange={(e) => set({ matter_id: e.target.value })}><option value="">No matter</option>{matters.map((m) => <option key={m.id} value={m.id}>{m.reference} · {m.title.slice(0, 40)}</option>)}</Select></Field>
        <Field label="Assignee"><Select value={f.assignee_id} onChange={(e) => set({ assignee_id: e.target.value })}><option value="">Unassigned</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
        <Field label="Due"><Input type="datetime-local" value={f.due} onChange={(e) => set({ due: e.target.value })} /></Field>
        <Field label="Priority"><Select value={f.priority} onChange={(e) => set({ priority: e.target.value })}>{PRIORITIES.map((p) => <option key={p} value={p}>{humanise(p)}</option>)}</Select></Field>
      </div>
      <Field label="Description"><Textarea rows={3} value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field>
      <fieldset className="rounded-md border border-stone-200 p-3">
        <legend className="px-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Recurrence</legend>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Repeats"><Select value={f.recFreq} onChange={(e) => set({ recFreq: e.target.value })}><option value="">Does not repeat</option><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></Select></Field>
          <Field label="Every (interval)" error={errors.recInterval}><Input type="number" min={1} max={52} value={f.recInterval} disabled={!f.recFreq} onChange={(e) => set({ recInterval: e.target.value })} /></Field>
          <Field label="Until"><Input type="date" value={f.recUntil} disabled={!f.recFreq} onChange={(e) => set({ recUntil: e.target.value })} /></Field>
        </div>
        <p className="mt-2 text-xs text-stone-600">Completing a recurring task creates exactly one next occurrence.</p>
      </fieldset>
      <fieldset className="rounded-md border border-stone-200 p-3">
        <legend className="px-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Reminders &amp; escalation</legend>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Remind (minutes before due)" hint="Comma-separated, e.g. 60, 1440" error={errors.reminders}><Input value={f.reminders} onChange={(e) => set({ reminders: e.target.value })} inputMode="numeric" /></Field>
          <Field label="Escalate to"><Select value={f.escalate_to_id} onChange={(e) => set({ escalate_to_id: e.target.value })}><option value="">No escalation</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
          <Field label="After (hours overdue)" error={errors.escalate_after_hours}><Input type="number" min={1} value={f.escalate_after_hours} disabled={!f.escalate_to_id} onChange={(e) => set({ escalate_after_hours: e.target.value })} /></Field>
        </div>
      </fieldset>
    </div>
  )
}

function validate(f: FormState): { errors: Partial<Record<keyof FormState, string>>; reminders: number[] | null } {
  const errors: Partial<Record<keyof FormState, string>> = {}
  if (!f.title.trim()) errors.title = 'A title is required.'
  const reminders = parseReminders(f.reminders)
  if (reminders === null) errors.reminders = 'Use whole numbers separated by commas.'
  if (f.recFreq && !(parseInt(f.recInterval, 10) >= 1)) errors.recInterval = 'Interval must be at least 1.'
  if (f.escalate_to_id && !(parseInt(f.escalate_after_hours, 10) >= 1)) errors.escalate_after_hours = 'Enter the hours after which to escalate.'
  return { errors, reminders }
}

/** Create-task dialog. Supports ?new=task via the parent. */
export function TaskForm({ open, onClose, defaultMatterId }: { open: boolean; onClose: () => void; defaultMatterId?: string }) {
  const [f, setF] = useState<FormState>({ ...blank, matter_id: defaultMatterId ?? '' })
  const [submitted, setSubmitted] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)
  const { me } = useAuth()
  useEffect(() => { if (open) { setF({ ...blank, assignee_id: me?.user.id ?? '', matter_id: defaultMatterId ?? '' }); setSubmitted(false); setServerError(null) } }, [open, me, defaultMatterId])
  const { errors, reminders } = validate(f)
  const create = useApiMutation((body: Record<string, unknown>) => api.post<Task>('/tasks', body), { invalidate: [['tasks'], ['home'], ['diary']], successMessage: 'Task created', errorToast: false,
    onSuccess: () => onClose(), onError: (e) => setServerError(e.message) })
  const submit = () => {
    setSubmitted(true)
    if (Object.keys(errors).length) return
    create.mutate({
      title: f.title.trim(), description: f.description || null, matter_id: f.matter_id || null, assignee_id: f.assignee_id || null, due_at: fromLocalInput(f.due), priority: f.priority,
      recurrence: f.recFreq ? { freq: f.recFreq, interval: parseInt(f.recInterval, 10), until: f.recUntil || null } : null, reminder_offsets_minutes: reminders ?? [],
      escalate_to_id: f.escalate_to_id || null, escalate_after_hours: f.escalate_to_id ? parseInt(f.escalate_after_hours, 10) : null,
    })
  }
  return (
    <Dialog open={open} onClose={onClose} title="New task" size="lg"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={create.isPending} onClick={submit}>Create task</Button></>}>
      {serverError && <p role="alert" className="mb-3 rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{serverError}</p>}
      <TaskFields f={f} set={(p) => setF((x) => ({ ...x, ...p }))} errors={submitted ? errors : {}} />
    </Dialog>
  )
}

/** Task detail & edit drawer (route /tasks/:id). */
export function TaskDrawer({ taskId, onClose }: { taskId?: string; onClose: () => void }) {
  const { can } = useAuth()
  const q = useApiQuery<Task>(['tasks', 'one', taskId], `/tasks/${taskId}`, { enabled: !!taskId })
  const deps = useApiQuery<TaskDeps>(['tasks', 'deps', taskId], `/tasks/${taskId}/dependencies`, { enabled: !!taskId })
  const [f, setF] = useState<FormState>(blank)
  const [dirty, setDirty] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [conflict, setConflict] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)
  const [confirmCancel, setConfirmCancel] = useState(false)
  const [depChoice, setDepChoice] = useState('')
  const t = q.data
  useEffect(() => { if (t) { setF(fromTask(t)); setDirty(false); setConflict(false) } }, [t])
  const writable = can('tasks.write')
  const inv = [['tasks'], ['home'], ['diary']]
  const save = useApiMutation((body: Record<string, unknown>) => api.patch<Task>(`/tasks/${taskId}`, body), { invalidate: inv, successMessage: 'Task saved', errorToast: false,
    onSuccess: () => setServerError(null), onError: (e) => { if (e.isConflict) setConflict(true); else setServerError(e.message) } })
  const act = useApiMutation((a: 'start' | 'complete' | 'reopen' | 'cancel') => api.post<unknown>(`/tasks/${taskId}/${a}`), { invalidate: inv, errorToast: false,
    onSuccess: (r, a) => { setServerError(null); const next = (r as { next_occurrence?: Task | null })?.next_occurrence; if (a === 'complete' && next) setServerError(`Completed. The next occurrence was created for ${new Date(next.due_at ?? '').toLocaleDateString('en-GB')}.`) },
    onError: (e) => setServerError(e.message) })
  const addDep = useApiMutation((id: string) => api.post(`/tasks/${taskId}/dependencies`, { depends_on_task_id: id }), { invalidate: [['tasks']], errorToast: false, onError: (e) => setServerError(e.message), onSuccess: () => setDepChoice('') })
  const rmDep = useApiMutation((id: string) => api.delete(`/tasks/${taskId}/dependencies/${id}`), { invalidate: [['tasks']] })
  const candidates = useApiQuery<Page<Task>>(['tasks', 'cands', t?.matter_id], `/tasks${qs({ matter_id: t?.matter_id, open_only: true, limit: 100 })}`, { enabled: !!t && writable })
  const { errors, reminders } = validate(f)

  const onSave = () => {
    if (!t) return
    setSubmitted(true)
    if (Object.keys(errors).length) return
    const orig = fromTask(t)
    const body: Record<string, unknown> = { expected_version: t.version }
    if (f.title !== orig.title) body.title = f.title.trim()
    if (f.description !== orig.description) body.description = f.description
    if (f.assignee_id !== orig.assignee_id) body.assignee_id = f.assignee_id || null
    if (f.due !== orig.due) body.due_at = fromLocalInput(f.due)
    if (f.priority !== orig.priority) body.priority = f.priority
    if (f.recFreq !== orig.recFreq || f.recInterval !== orig.recInterval || f.recUntil !== orig.recUntil) body.recurrence = f.recFreq ? { freq: f.recFreq, interval: parseInt(f.recInterval, 10), until: f.recUntil || null } : null
    if (f.reminders !== orig.reminders) body.reminder_offsets_minutes = reminders ?? []
    if (f.escalate_to_id !== orig.escalate_to_id) body.escalate_to_id = f.escalate_to_id || null
    if (f.escalate_after_hours !== orig.escalate_after_hours) body.escalate_after_hours = f.escalate_after_hours ? parseInt(f.escalate_after_hours, 10) : null
    save.mutate(body)
  }
  const done = t && (t.status === 'done' || t.status === 'cancelled')
  const depIds = new Set(deps.data?.depends_on.map((d) => d.id))
  return (
    <Drawer open={!!taskId} onClose={onClose} width="max-w-2xl" title={t?.title ?? 'Task'}
      footer={t && writable ? <>
        <Button variant="secondary" onClick={onClose}>Close</Button>
        <Button disabled={!dirty || !!done} loading={save.isPending} onClick={onSave}>Save changes</Button></> : <Button variant="secondary" onClick={onClose}>Close</Button>}>
      {q.isPending && <LoadingState rows={4} />}
      {q.isError && <ErrorState error={q.error} onRetry={() => void q.refetch()} />}
      {t && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={t.status} /><StatusBadge status={t.priority} />
            {t.is_overdue && <Badge tone="danger">Overdue</Badge>}
            {t.matter_id && <Link className="text-xs font-semibold text-navy-700 hover:text-brass-700" to={`/matters/${t.matter_id}`}>{t.matter_reference} · {t.matter_title}</Link>}
            {t.deadline_id && <Link className="text-xs font-semibold text-navy-700 hover:text-brass-700" to={`/tasks/deadlines/${t.deadline_id}`}>Linked deadline →</Link>}
          </div>
          {conflict && (
            <div role="alert" className="rounded border border-warn-100 bg-warn-50 px-3 py-2 text-sm text-warn-700">
              Someone else changed this task while you were editing. <button className="ml-1 font-semibold underline" onClick={() => void q.refetch()}>Reload the latest version</button> (your edits will be discarded).
            </div>)}
          {serverError && <p role="status" className="rounded border border-stone-200 bg-ivory-100 px-3 py-2 text-sm text-stone-800">{serverError}</p>}
          {t.blocked_by.length > 0 && (
            <div className="rounded border border-warn-100 bg-warn-50 px-3 py-2 text-sm text-warn-700">
              <p className="font-semibold">Blocked: this task cannot be started or completed until these are done</p>
              <ul className="mt-1 list-disc pl-5">{t.blocked_by.map((b) => <li key={b.id}><Link to={`/tasks/${b.id}`} className="underline">{b.title}</Link> ({humanise(b.status)})</li>)}</ul>
            </div>)}

          {writable && (
            <div className="flex flex-wrap gap-2" role="group" aria-label="Task actions">
              {t.status === 'open' && <Button size="sm" variant="secondary" icon={<Play className="h-3.5 w-3.5" />} loading={act.isPending} onClick={() => act.mutate('start')}>Start</Button>}
              {!done && <Button size="sm" icon={<CheckCircle2 className="h-3.5 w-3.5" />} loading={act.isPending} onClick={() => act.mutate('complete')}>Complete</Button>}
              {done && <Button size="sm" variant="secondary" icon={<RotateCcw className="h-3.5 w-3.5" />} loading={act.isPending} onClick={() => act.mutate('reopen')}>Reopen</Button>}
              {!done && <Button size="sm" variant="ghost" icon={<XCircle className="h-3.5 w-3.5" />} onClick={() => setConfirmCancel(true)}>Cancel task</Button>}
            </div>)}

          {writable && !done ? (
            <TaskFields f={f} set={(p) => { setF((x) => ({ ...x, ...p })); setDirty(true) }} lockMatter errors={submitted ? errors : {}} />
          ) : (
            <KeyValue columns={2} items={[
              { label: 'Assignee', value: t.assignee_name ?? 'Unassigned' }, { label: 'Due', value: <DateTime value={t.due_at} /> },
              { label: 'Recurrence', value: t.recurrence ? `${humanise(t.recurrence.freq)} every ${t.recurrence.interval}` : 'None' },
              { label: 'Completed', value: <DateTime value={t.completed_at} /> }, { label: 'Description', value: t.description ?? '—' }]} />)}

          <section aria-labelledby="dep-h">
            <h3 id="dep-h" className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-stone-700"><Link2 className="h-3.5 w-3.5" aria-hidden />Dependencies</h3>
            {deps.isPending ? <LoadingState rows={1} /> : deps.isError ? <ErrorState title="Dependencies could not be loaded" error={deps.error} onRetry={() => void deps.refetch()} /> : (
              <>
                {(deps.data?.depends_on.length ?? 0) === 0 ? <p className="text-sm text-stone-600">This task does not wait on any other task.</p> : (
                  <ul className="divide-y divide-stone-100 rounded border border-stone-200">
                    {deps.data!.depends_on.map((d) => (
                      <li key={d.id} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
                        <Link to={`/tasks/${d.id}`} className="min-w-0 truncate text-navy-800 hover:text-brass-700">{d.title}</Link>
                        <span className="flex items-center gap-2"><StatusBadge status={d.status} />{writable && <button aria-label={`Remove dependency on ${d.title}`} className="rounded p-1 text-stone-500 hover:text-bad-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500" onClick={() => rmDep.mutate(d.id)}><Trash2 className="h-3.5 w-3.5" /></button>}</span>
                      </li>))}
                  </ul>)}
                {(deps.data?.required_by.length ?? 0) > 0 && <p className="mt-2 text-xs text-stone-600">Required by: {deps.data!.required_by.map((d) => d.title).join('; ')}</p>}
                {writable && !done && (
                  <div className="mt-3 flex items-end gap-2">
                    <Field label="Add prerequisite" className="flex-1"><Select value={depChoice} onChange={(e) => setDepChoice(e.target.value)}><option value="">Choose a task on this matter…</option>
                      {candidates.data?.items.filter((c) => c.id !== t.id && !depIds.has(c.id)).map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</Select></Field>
                    <Button variant="secondary" disabled={!depChoice} loading={addDep.isPending} onClick={() => addDep.mutate(depChoice)}>Add</Button>
                  </div>)}
                <p className="mt-2 text-xs text-stone-600">Circular dependencies are rejected by the server.</p>
              </>)}
          </section>
          <p className="text-2xs text-stone-500">Version {t.version} · created <DateTime value={t.created_at} />{t.escalated_at && <> · escalated <DateTime value={t.escalated_at} /></>}</p>
        </div>)}
      <ConfirmDialog open={confirmCancel} onClose={() => setConfirmCancel(false)} title="Cancel this task?" description="The task will be marked cancelled and will no longer block dependants." confirmLabel="Cancel task" tone="danger"
        onConfirm={() => { act.mutate('cancel'); setConfirmCancel(false) }} />
    </Drawer>
  )
}
export { ApiError }
