import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { AlertTriangle, Calculator, CheckCircle2, Info, Plus, ShieldAlert, XCircle } from 'lucide-react'
import { Badge, Button, Checkbox, CitationChip, DataTable, DateTime, Dialog, Drawer, ErrorState, Field, Input, KeyValue, LoadingState, Select, StatusBadge, Textarea, type Column } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { useQueryParams } from '@/hooks'
import type { Page } from '@/types/api'
import type { BusinessCalendar, Deadline, DeadlineRule } from '@/types/tasks'
import { jurisdictionLabel, useMatterOptions } from './shared'

const ORIGIN_LABEL: Record<Deadline['origin'], string> = { manual: 'Manual entry', calculated_suggestion: 'Calculated suggestion', ai_suggestion: 'AI suggestion' }
const ORIGIN_TONE: Record<Deadline['origin'], 'neutral' | 'info' | 'simulated'> = { manual: 'neutral', calculated_suggestion: 'info', ai_suggestion: 'simulated' }
const PARAMS = ['needs_attention', 'status', 'origin', 'matter'] as const

export function OriginBadge({ origin }: { origin: Deadline['origin'] }) { return <Badge tone={ORIGIN_TONE[origin]}>{ORIGIN_LABEL[origin]}</Badge> }

export function DeadlinesTab() {
  const { id } = useParams()
  const nav = useNavigate()
  const { can } = useAuth()
  const matters = useMatterOptions()
  const [p, setP] = useQueryParams(PARAMS)
  const [offset, setOffset] = useState(0)
  const [calc, setCalc] = useState(false)
  const [manual, setManual] = useState(false)
  const params = { needs_attention: p.needs_attention === '1' ? true : undefined, status: p.status, origin: p.origin, matter_id: p.matter, limit: 25, offset }
  const q = useApiQuery<Page<Deadline>>(['deadlines', params], `/diary/deadlines${qs(params)}`)
  const cols: Column<Deadline>[] = [
    { key: 'title', header: 'Deadline', cell: (d) => (
      <span className="block min-w-0"><span className="block truncate font-medium text-navy-900">{d.title}</span>
        <span className="text-xs text-stone-600"><span className="font-mono">{d.matter_reference}</span>{d.jurisdiction ? ` · ${jurisdictionLabel(d.jurisdiction)}` : ''} · {d.timezone}</span></span>) },
    { key: 'due', header: 'Due', cell: (d) => <span className="whitespace-nowrap"><DateTime value={d.due_date} mode="date" />{d.due_time ? ` ${d.due_time.slice(0, 5)}` : ''}</span> },
    { key: 'origin', header: 'Origin', hideOnNarrow: true, cell: (d) => <OriginBadge origin={d.origin} /> },
    { key: 'status', header: 'Authority', cell: (d) => d.authoritative ? <Badge tone="success">Confirmed</Badge> : d.status === 'suggested' ? <Badge tone="warning" dot>Needs confirmation</Badge> : <StatusBadge status={d.status} /> },
  ]
  return (
    <>
      <div className="mb-4 flex flex-wrap items-end gap-3 rounded-lg border border-stone-200 bg-white px-4 py-3 shadow-panel" role="search" aria-label="Deadline filters">
        <div className="pb-2"><Checkbox label="Needs attention" hint="" checked={p.needs_attention === '1'} onChange={(e) => { setP({ needs_attention: e.target.checked ? '1' : null }); setOffset(0) }} /></div>
        <div className="space-y-1"><label htmlFor="d-status" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Status</label>
          <Select id="d-status" className="w-40" value={p.status ?? ''} onChange={(e) => { setP({ status: e.target.value || null }); setOffset(0) }}><option value="">Any</option>{['suggested', 'confirmed', 'rejected', 'met', 'missed'].map((s) => <option key={s} value={s}>{humanise(s)}</option>)}</Select></div>
        <div className="space-y-1"><label htmlFor="d-origin" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Origin</label>
          <Select id="d-origin" className="w-52" value={p.origin ?? ''} onChange={(e) => { setP({ origin: e.target.value || null }); setOffset(0) }}><option value="">Any</option>{(Object.keys(ORIGIN_LABEL) as Deadline['origin'][]).map((o) => <option key={o} value={o}>{ORIGIN_LABEL[o]}</option>)}</Select></div>
        <div className="space-y-1"><label htmlFor="d-matter" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Matter</label>
          <Select id="d-matter" className="w-56" value={p.matter ?? ''} onChange={(e) => { setP({ matter: e.target.value || null }); setOffset(0) }}><option value="">All matters</option>{matters.map((m) => <option key={m.id} value={m.id}>{m.reference} · {m.title.slice(0, 30)}</option>)}</Select></div>
        <div className="ml-auto flex gap-2">
          {can('tasks.write') && <><Button variant="secondary" icon={<Calculator className="h-4 w-4" />} onClick={() => setCalc(true)}>Calculate from rule</Button>
            <Button icon={<Plus className="h-4 w-4" />} onClick={() => setManual(true)}>Enter deadline</Button></>}
        </div>
      </div>
      {!can('deadlines.confirm') && (
        <p className="mb-4 flex items-start gap-2 rounded-lg border border-stone-200 bg-ivory-100 px-4 py-3 text-sm text-stone-700"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-brass-600" aria-hidden />
          Suggested deadlines can only be confirmed by a user holding the <code className="rounded bg-white px-1 font-mono text-xs">deadlines.confirm</code> permission (a fee earner or partner). You can view them and request confirmation.</p>)}
      <DataTable caption="Deadlines" columns={cols} rows={q.data?.items} rowKey={(d) => d.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
        onRowClick={(d) => nav(`/tasks/deadlines/${d.id}${window.location.search}`)} rowClassName={(d) => (d.status === 'suggested' ? 'bg-warn-50/40' : undefined)}
        emptyTitle="No deadlines match" emptyDescription="Deadlines entered manually, calculated from rules, or suggested by AI from documents appear here."
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} />
      <DeadlineDrawer deadlineId={id} onClose={() => nav(`/tasks/deadlines${window.location.search}`)} />
      <CalculateDialog open={calc} onClose={() => setCalc(false)} />
      <ManualDialog open={manual} onClose={() => setManual(false)} />
    </>
  )
}

function CalcSteps({ calc }: { calc: Record<string, unknown> }) {
  const steps = Array.isArray(calc.steps) ? (calc.steps as unknown[]).map(String) : []
  const inputs = (calc.inputs ?? null) as Record<string, unknown> | null
  const cal = (inputs?.calendar ?? null) as Record<string, unknown> | null
  const skipped = Array.isArray(calc.skipped_days) ? (calc.skipped_days as unknown[]) : []
  const adj = (calc.adjustment ?? null) as Record<string, string> | null
  if (!steps.length && !inputs && !adj && !calc.manual_entry) return null
  return (
    <div className="space-y-3 text-sm">
      {inputs && <KeyValue columns={2} items={[
        { label: 'Rule', value: String(inputs.rule_name ?? inputs.rule_key ?? '—') }, { label: 'Trigger date', value: <DateTime value={String(inputs.trigger_date ?? '')} mode="date" /> },
        { label: 'Offset', value: `${String(inputs.offset_days)} ${String(inputs.day_type)} days ${String(inputs.direction)}` }, { label: 'Roll convention', value: humanise(String(inputs.roll_convention ?? '')) },
        { label: 'Calendar', value: cal ? `${String(cal.name)} (${String(cal.timezone)})` : '—' }, { label: 'Holiday data source', value: String(cal?.holiday_source ?? '—') }]} />}
      {steps.length > 0 && <ol className="list-decimal space-y-0.5 rounded border border-stone-200 bg-ivory-100 py-2 pl-8 pr-3 text-xs text-stone-800">{steps.map((s, i) => <li key={i}>{s}</li>)}</ol>}
      {skipped.length > 0 && <p className="text-xs text-stone-600">Days skipped (weekends/holidays): {skipped.map((s) => (typeof s === 'string' ? s : JSON.stringify(s))).join(', ')}</p>}
      {adj && <p className="rounded border border-warn-100 bg-warn-50 px-3 py-2 text-xs text-warn-700">Adjusted by a reviewer from {adj.from} to {adj.to}. Reason: {adj.reason}</p>}
      {calc.manual_entry === true && <p className="text-xs text-stone-600">Entered manually by a person; no calculation was performed.</p>}
    </div>
  )
}

export function DeadlineDrawer({ deadlineId, onClose }: { deadlineId?: string; onClose: () => void }) {
  const { can, me } = useAuth()
  const q = useApiQuery<Deadline>(['deadlines', 'one', deadlineId], `/diary/deadlines/${deadlineId}`, { enabled: !!deadlineId })
  const [confirming, setConfirming] = useState(false)
  const [rejecting, setRejecting] = useState(false)
  const d = q.data
  const canConfirm = can('deadlines.confirm')
  const missingPassage = d?.origin === 'ai_suggestion' && !(d.source_passage ?? '').trim()
  return (
    <Drawer open={!!deadlineId} onClose={onClose} width="max-w-2xl" title={d?.title ?? 'Deadline'}
      footer={d?.status === 'suggested' ? (
        canConfirm ? <><Button variant="secondary" onClick={onClose}>Close</Button><Button variant="danger" icon={<XCircle className="h-4 w-4" />} onClick={() => setRejecting(true)}>Reject</Button>
          <Button variant="brass" icon={<CheckCircle2 className="h-4 w-4" />} disabled={missingPassage} onClick={() => setConfirming(true)}>Review &amp; confirm</Button></>
          : <Button variant="secondary" onClick={onClose}>Close</Button>) : <Button variant="secondary" onClick={onClose}>Close</Button>}>
      {q.isPending && <LoadingState rows={5} />}
      {q.isError && <ErrorState error={q.error} onRetry={() => void q.refetch()} />}
      {d && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-2"><OriginBadge origin={d.origin} />
            {d.authoritative ? <Badge tone="success">Confirmed — authoritative</Badge> : d.status === 'suggested' ? <Badge tone="warning" dot>Unconfirmed suggestion — not authoritative</Badge> : <StatusBadge status={d.status} />}
            <Link className="text-xs font-semibold text-navy-700 hover:text-brass-700" to={`/matters/${d.matter_id}`}>{d.matter_reference}</Link></div>
          <p className="text-sm text-stone-700">{d.label}</p>
          {d.status === 'suggested' && !canConfirm && (
            <p role="note" className="flex items-start gap-2 rounded border border-stone-200 bg-ivory-100 px-3 py-2 text-sm text-stone-700"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-brass-600" aria-hidden />You do not hold <code className="font-mono text-xs">deadlines.confirm</code>. Ask the responsible solicitor to review and confirm this suggestion.</p>)}
          <KeyValue columns={2} items={[
            { label: 'Due date', value: <strong className="text-navy-900"><DateTime value={d.due_date} mode="date" />{d.due_time ? ` at ${d.due_time.slice(0, 5)}` : ''}</strong> }, { label: 'Timezone', value: d.timezone },
            { label: 'Jurisdiction', value: jurisdictionLabel(d.jurisdiction) }, { label: 'Trigger date', value: d.trigger_date ? <DateTime value={d.trigger_date} mode="date" /> : '—' },
            { label: 'Rule', value: d.rule_key ?? '—' }, { label: 'Business calendar', value: d.calendar_name ?? '—' },
            { label: 'Confirmed by', value: d.confirmed_by_name ? <>{d.confirmed_by_name} · <DateTime value={d.confirmed_at} /></> : '—' }, { label: 'Review note', value: d.review_note ?? '—' }]} />
          <section aria-labelledby="as-h"><h3 id="as-h" className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-stone-700">Assumptions</h3>
            <p className="whitespace-pre-wrap rounded border border-stone-200 bg-white p-3 text-sm text-stone-800">{d.assumptions || 'No assumptions were recorded.'}</p></section>
          {d.origin === 'ai_suggestion' && (
            <section aria-labelledby="ps-h">
              <h3 id="ps-h" className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-stone-700">Supporting passage (identified by AI)</h3>
              {missingPassage ? (
                <p role="alert" className="flex items-start gap-2 rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />No supporting passage was recorded, so this AI suggestion cannot be confirmed.</p>
              ) : (
                <figure className="rounded border border-sim-100 bg-sim-50/50 p-3">
                  <blockquote className="border-l-2 border-sim-600 pl-3 text-sm italic text-stone-900">“{d.source_passage}”</blockquote>
                  <figcaption className="mt-2 flex flex-wrap items-center gap-2 text-xs text-stone-600">
                    <CitationChip documentTitle={String(d.source_ref.document_title ?? 'Source document')} versionNo={d.source_ref.version_no ?? null} page={d.source_ref.page ?? null} paragraph={d.source_ref.paragraph ?? null} />
                    {d.source_document_id && <Link className="font-semibold text-navy-700 hover:text-brass-700" to={`/documents/${d.source_document_id}`}>Open document</Link>}
                    {d.agent_run_id && <Link className="font-semibold text-navy-700 hover:text-brass-700" to={`/ai/runs/${d.agent_run_id}`}>View AI run</Link>}</figcaption>
                </figure>)}
              <p className="mt-2 flex items-start gap-1.5 text-xs text-stone-600"><Info className="mt-0.5 h-3 w-3 shrink-0" aria-hidden />AI suggestions are drafts. Read the passage in context before confirming — you take responsibility for the date.</p>
            </section>)}
          <section aria-labelledby="cs-h"><h3 id="cs-h" className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-stone-700">Calculation record</h3>
            <CalcSteps calc={d.calculation} />{Object.keys(d.calculation).length === 0 && <p className="text-sm text-stone-600">No calculation record.</p>}</section>
          <p className="text-2xs text-stone-500">Version {d.version}{me ? ` · viewing as ${me.user.name}` : ''}</p>
        </div>)}
      {d && <ConfirmDeadlineDialog open={confirming} onClose={() => setConfirming(false)} deadline={d} onDone={onClose} />}
      {d && <RejectDialog open={rejecting} onClose={() => setRejecting(false)} deadline={d} onDone={onClose} />}
    </Drawer>
  )
}

function ConfirmDeadlineDialog({ open, onClose, deadline, onDone }: { open: boolean; onClose: () => void; deadline: Deadline; onDone: () => void }) {
  const { me } = useAuth()
  const [date, setDate] = useState(deadline.due_date)
  const [reason, setReason] = useState('')
  const [note, setNote] = useState('')
  const [task, setTask] = useState(false)
  const [ack, setAck] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => { if (open) { setDate(deadline.due_date); setReason(''); setNote(''); setTask(false); setAck(false); setErr(null) } }, [open, deadline])
  const changed = date !== deadline.due_date
  const m = useApiMutation(() => api.post(`/diary/deadlines/${deadline.id}/confirm`, { review_note: note || null, adjusted_due_date: changed ? date : null, adjustment_reason: changed ? reason : null, create_task: task, expected_version: deadline.version }),
    { invalidate: [['deadlines'], ['diary'], ['home'], ['tasks']], successMessage: 'Deadline confirmed — now authoritative', errorToast: false, onSuccess: () => { onClose(); onDone() }, onError: (e) => setErr(e.code === 'version_conflict' ? 'This deadline changed while you were reviewing it. Close and reopen it to see the latest version.' : e.message) })
  const invalid = (changed && reason.trim().length < 3) || !ack
  return (
    <Dialog open={open} onClose={onClose} size="md" title="Confirm this deadline" description="Confirming makes this date authoritative in diaries, reminders and reports."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant="brass" disabled={invalid} loading={m.isPending} onClick={() => m.mutate()}>Confirm deadline</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <p className="rounded border border-stone-200 bg-ivory-100 px-3 py-2 text-sm">Confirming as <strong>{me?.user.name}</strong> ({me?.role.name}). Your name and the time are recorded on the deadline and in the audit trail.</p>
        <Field label="Due date" hint={`Suggested date: ${deadline.due_date}. Change it only if the governing rule or agreement requires it.`}><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} data-autofocus /></Field>
        {changed && <Field label="Reason for changing the date" required error={reason.trim().length < 3 ? 'A reason is required when the date is changed.' : undefined}><Textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>}
        <Field label="Review note" hint="Optional. How you verified the date (e.g. the clause or order relied on)."><Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
        <Checkbox label="Also create a task for this deadline" checked={task} onChange={(e) => setTask(e.target.checked)} />
        <Checkbox label="I have checked the source, assumptions and calendar, and I accept responsibility for this date." checked={ack} onChange={(e) => setAck(e.target.checked)} />
      </div>
    </Dialog>
  )
}

function RejectDialog({ open, onClose, deadline, onDone }: { open: boolean; onClose: () => void; deadline: Deadline; onDone: () => void }) {
  const [note, setNote] = useState('')
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => { if (open) { setNote(''); setErr(null) } }, [open])
  const m = useApiMutation(() => api.post(`/diary/deadlines/${deadline.id}/reject`, { review_note: note }), { invalidate: [['deadlines'], ['diary'], ['home']], successMessage: 'Suggestion rejected', errorToast: false, onSuccess: () => { onClose(); onDone() }, onError: (e) => setErr(e.message) })
  return (
    <Dialog open={open} onClose={onClose} size="sm" title="Reject this suggestion" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant="danger" disabled={note.trim().length < 3} loading={m.isPending} onClick={() => m.mutate()}>Reject</Button></>}>
      {err && <p role="alert" className="mb-3 text-sm text-bad-700">{err}</p>}
      <Field label="Why is it rejected?" required hint="Recorded with your name."><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} data-autofocus /></Field>
    </Dialog>
  )
}

function CalculateDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const matters = useMatterOptions()
  const rules = useApiQuery<DeadlineRule[]>(['deadline-rules', 'active'], '/diary/deadline-rules?active_only=true', { enabled: open })
  const cals = useApiQuery<BusinessCalendar[]>(['calendars'], '/diary/calendars', { enabled: open })
  const nav = useNavigate()
  const [f, setF] = useState({ matter_id: '', rule_key: '', trigger_date: '', calendar_id: '', title: '', assumptions: '' })
  const [err, setErr] = useState<string | null>(null)
  const [sub, setSub] = useState(false)
  useEffect(() => { if (open) { setF({ matter_id: '', rule_key: '', trigger_date: '', calendar_id: '', title: '', assumptions: '' }); setErr(null); setSub(false) } }, [open])
  const rule = rules.data?.find((r) => r.key === f.rule_key)
  const m = useApiMutation(() => api.post<Deadline>('/diary/deadlines/calculate', { matter_id: f.matter_id, rule_key: f.rule_key, trigger_date: f.trigger_date, calendar_id: f.calendar_id || null, title: f.title || null, assumptions: f.assumptions || null }),
    { invalidate: [['deadlines'], ['diary'], ['home']], successMessage: 'Suggestion created — awaiting confirmation', errorToast: false, onSuccess: (d) => { onClose(); nav(`/tasks/deadlines/${d.id}`) }, onError: (e) => setErr(e.message) })
  const bad = !f.matter_id || !f.rule_key || !f.trigger_date
  return (
    <Dialog open={open} onClose={onClose} size="lg" title="Calculate a deadline from a rule" description="Creates an unconfirmed suggestion with its full calculation record. A solicitor must confirm it before it is authoritative."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={m.isPending} onClick={() => { setSub(true); if (!bad) m.mutate() }}>Calculate suggestion</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Matter" required error={sub && !f.matter_id ? 'Choose a matter.' : undefined}><Select value={f.matter_id} onChange={(e) => setF({ ...f, matter_id: e.target.value })}><option value="">Select…</option>{matters.map((x) => <option key={x.id} value={x.id}>{x.reference} · {x.title.slice(0, 34)}</option>)}</Select></Field>
          <Field label="Rule" required error={sub && !f.rule_key ? 'Choose a rule.' : undefined}><Select value={f.rule_key} onChange={(e) => setF({ ...f, rule_key: e.target.value })}><option value="">Select…</option>{rules.data?.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}</Select></Field>
          <Field label="Trigger date" required error={sub && !f.trigger_date ? 'Enter the date the period runs from.' : undefined}><Input type="date" value={f.trigger_date} onChange={(e) => setF({ ...f, trigger_date: e.target.value })} /></Field>
          <Field label="Business calendar" hint="Default calendar for the rule's jurisdiction if left blank."><Select value={f.calendar_id} onChange={(e) => setF({ ...f, calendar_id: e.target.value })}><option value="">Default</option>{cals.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
        </div>
        {rule && <p className="rounded border border-warn-100 bg-warn-50 px-3 py-2 text-xs text-warn-700"><strong>Illustrative rule:</strong> {rule.offset_days} {rule.day_type} days {rule.direction}, roll: {humanise(rule.roll_convention)}. {rule.source_note}</p>}
        <Field label="Title (optional)"><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <Field label="Additional assumptions (optional)"><Textarea rows={2} value={f.assumptions} onChange={(e) => setF({ ...f, assumptions: e.target.value })} /></Field>
      </div>
    </Dialog>
  )
}

function ManualDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { can } = useAuth()
  const matters = useMatterOptions()
  const [f, setF] = useState({ matter_id: '', title: '', due_date: '', due_time: '', jurisdiction: '', assumptions: '', create_task: false })
  const [err, setErr] = useState<string | null>(null)
  const [sub, setSub] = useState(false)
  useEffect(() => { if (open) { setF({ matter_id: '', title: '', due_date: '', due_time: '', jurisdiction: '', assumptions: '', create_task: false }); setErr(null); setSub(false) } }, [open])
  const m = useApiMutation(() => api.post<Deadline>('/diary/deadlines', { matter_id: f.matter_id, title: f.title.trim(), due_date: f.due_date, due_time: f.due_time || null, jurisdiction: f.jurisdiction || null, assumptions: f.assumptions || null, create_task: f.create_task }),
    { invalidate: [['deadlines'], ['diary'], ['home'], ['tasks']], successMessage: (d) => (d.authoritative ? 'Deadline recorded' : 'Recorded as unconfirmed — a solicitor must confirm it'), errorToast: false, onSuccess: () => onClose(), onError: (e) => setErr(e.message) })
  const bad = !f.matter_id || !f.title.trim() || !f.due_date
  return (
    <Dialog open={open} onClose={onClose} size="md" title="Enter a deadline" description={can('deadlines.confirm') ? 'As a fee earner your manual entry is recorded as confirmed by you.' : 'Your role cannot confirm deadlines: this will be saved as unconfirmed until a solicitor confirms it.'}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={m.isPending} onClick={() => { setSub(true); if (!bad) m.mutate() }}>Save deadline</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <Field label="Matter" required error={sub && !f.matter_id ? 'Choose a matter.' : undefined}><Select value={f.matter_id} onChange={(e) => setF({ ...f, matter_id: e.target.value })}><option value="">Select…</option>{matters.map((x) => <option key={x.id} value={x.id}>{x.reference} · {x.title.slice(0, 40)}</option>)}</Select></Field>
        <Field label="Title" required error={sub && !f.title.trim() ? 'A title is required.' : undefined}><Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Due date" required error={sub && !f.due_date ? 'Enter a date.' : undefined}><Input type="date" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></Field>
          <Field label="Time (optional)"><Input type="time" value={f.due_time} onChange={(e) => setF({ ...f, due_time: e.target.value })} /></Field>
        </div>
        <Field label="Jurisdiction (optional)"><Input value={f.jurisdiction} onChange={(e) => setF({ ...f, jurisdiction: e.target.value })} placeholder="england_and_wales" /></Field>
        <Field label="Source / assumptions" hint="Record where the date comes from (order, rule, agreement clause)."><Textarea rows={2} value={f.assumptions} onChange={(e) => setF({ ...f, assumptions: e.target.value })} /></Field>
        <Checkbox label="Also create a task" checked={f.create_task} onChange={(e) => setF({ ...f, create_task: e.target.checked })} />
      </div>
    </Dialog>
  )
}
