import { useEffect, useState } from 'react'
import { Trash2, Upload } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, DataTable, DateTime, Dialog, Field, Input, PermissionDenied, Select, Textarea, type Column } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import type { BusinessCalendar, DeadlineRule, Holiday } from '@/types/tasks'
import { jurisdictionLabel } from './shared'

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

function useCanManage() { const { can } = useAuth(); return can('admin.settings') || can('matters.approve') }

export function CalendarsTab() {
  const manage = useCanManage()
  const cals = useApiQuery<BusinessCalendar[]>(['calendars'], '/diary/calendars')
  const [sel, setSel] = useState<string>('')
  const [year, setYear] = useState<string>('')
  const [del, setDel] = useState<Holiday | null>(null)
  const [imp, setImp] = useState(false)
  const [hDate, setHDate] = useState(''); const [hName, setHName] = useState('')
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => { if (!sel && cals.data?.length) setSel((cals.data.find((c) => c.is_default) ?? cals.data[0]!).id) }, [cals.data, sel])
  const cal = cals.data?.find((c) => c.id === sel)
  const hol = useApiQuery<Holiday[]>(['calendars', sel, 'holidays', year], `/diary/calendars/${sel}/holidays${year ? `?year=${year}` : ''}`, { enabled: !!sel })
  const inv = [['calendars']]
  const add = useApiMutation(() => api.post(`/diary/calendars/${sel}/holidays`, { date: hDate, name: hName.trim() }), { invalidate: inv, successMessage: 'Holiday added', errorToast: false, onSuccess: () => { setHDate(''); setHName(''); setErr(null) }, onError: (e) => setErr(e.message) })
  const rm = useApiMutation((id: string) => api.delete(`/diary/calendars/${sel}/holidays/${id}`), { invalidate: inv, successMessage: 'Holiday removed', onSuccess: () => setDel(null) })
  const cols: Column<Holiday>[] = [
    { key: 'd', header: 'Date', cell: (h) => <span className="font-medium"><DateTime value={h.date} mode="date" /> <span className="text-xs text-stone-500">({DAYS[(new Date(h.date + 'T12:00:00').getDay() + 6) % 7]})</span></span> },
    { key: 'n', header: 'Holiday', cell: (h) => h.name },
    ...(manage ? [{ key: 'x', header: <span className="sr-only">Remove</span>, align: 'right' as const, cell: (h: Holiday) => <button aria-label={`Remove ${h.name}`} onClick={() => setDel(h)} className="rounded p-1 text-stone-500 hover:text-bad-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500"><Trash2 className="h-4 w-4" /></button> }] : []),
  ]
  return (
    <div className="space-y-5">
      <p className="rounded-lg border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700"><strong>Holiday data is administrator-supplied input.</strong> The platform does not ship authoritative bank-holiday data. Verify dates against official sources before relying on any calculated deadline.</p>
      {!manage && <p className="text-sm text-stone-700">You can view calendars. Changing calendars and holidays needs administrator (<code className="font-mono text-xs">admin.settings</code>) or partner (<code className="font-mono text-xs">matters.approve</code>) permissions.</p>}
      <div className="grid gap-5 lg:grid-cols-[18rem_1fr]">
        <Card title="Business calendars" padded={false}>
          {cals.isPending ? <p className="p-5 text-sm text-stone-600">Loading…</p> : cals.isError ? <p className="p-5 text-sm text-bad-700">{cals.error.message}</p> : (
            <ul role="listbox" aria-label="Calendars">{cals.data?.map((c) => (
              <li key={c.id} role="option" aria-selected={c.id === sel}>
                <button className={`w-full border-b border-stone-100 px-5 py-3 text-left hover:bg-ivory-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500 ${c.id === sel ? 'bg-brass-50' : ''}`} onClick={() => setSel(c.id)}>
                  <span className="flex items-center justify-between gap-2 text-sm font-medium text-navy-900">{c.name}{c.is_default && <Badge tone="brass">Default</Badge>}</span>
                  <span className="text-xs text-stone-600">{jurisdictionLabel(c.jurisdiction)} · {c.timezone} · {c.holiday_count} holidays</span>
                </button></li>))}</ul>)}
        </Card>
        {cal && (
          <Card title={cal.name} description={`Weekend days: ${cal.weekend_days.map((d) => DAYS[d]).join(', ')} · Source: ${cal.source_note ?? 'not recorded'}`}
            actions={manage ? <Button size="sm" variant="secondary" icon={<Upload className="h-3.5 w-3.5" />} onClick={() => setImp(true)}>Import JSON</Button> : undefined}>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div className="space-y-1"><label htmlFor="h-year" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Year</label>
                <Select id="h-year" value={year} onChange={(e) => setYear(e.target.value)} className="w-28"><option value="">All</option>{[2026, 2027, 2028].map((y) => <option key={y}>{y}</option>)}</Select></div>
              {manage && <form className="ml-auto flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); if (hDate && hName.trim()) add.mutate() }} aria-label="Add holiday">
                <Field label="Date"><Input type="date" value={hDate} onChange={(e) => setHDate(e.target.value)} /></Field>
                <Field label="Name"><Input value={hName} onChange={(e) => setHName(e.target.value)} placeholder="e.g. Spring bank holiday" /></Field>
                <Button type="submit" disabled={!hDate || !hName.trim()} loading={add.isPending}>Add holiday</Button></form>}
            </div>
            {err && <p role="alert" className="mb-3 text-sm text-bad-700">{err}</p>}
            <DataTable caption={`Holidays in ${cal.name}`} columns={cols} rows={hol.data} rowKey={(h) => h.id} loading={hol.isPending} error={hol.error} onRetry={() => void hol.refetch()} emptyTitle="No holidays loaded" emptyDescription="Weekends are still excluded from business-day calculations; add bank holidays from an official source." dense />
          </Card>)}
      </div>
      <ConfirmDialog open={!!del} onClose={() => setDel(null)} title={`Remove ${del?.name}?`} description="Business-day calculations will treat this date as a working day." confirmLabel="Remove" tone="danger" loading={rm.isPending} onConfirm={() => { if (del) rm.mutate(del.id) }} />
      {cal && <ImportDialog open={imp} onClose={() => setImp(false)} calendarId={cal.id} />}
    </div>
  )
}

function ImportDialog({ open, onClose, calendarId }: { open: boolean; onClose: () => void; calendarId: string }) {
  const [text, setText] = useState('[\n  {"date": "2027-12-27", "name": "Christmas Day (substitute)"}\n]')
  const [source, setSource] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [res, setRes] = useState<string | null>(null)
  useEffect(() => { if (open) { setErr(null); setRes(null) } }, [open])
  const m = useApiMutation((body: unknown) => api.post<{ added: number; skipped_existing: number }>(`/diary/calendars/${calendarId}/holidays/import`, body), { invalidate: [['calendars']], errorToast: false,
    onSuccess: (r) => setRes(`${r.added} added, ${r.skipped_existing} already present.`), onError: (e) => setErr(e.message) })
  const go = () => {
    setErr(null); setRes(null)
    let parsed: unknown
    try { parsed = JSON.parse(text) } catch { setErr('That is not valid JSON.'); return }
    if (!Array.isArray(parsed) || parsed.some((x) => typeof x !== 'object' || !x || typeof (x as Record<string, unknown>).date !== 'string' || typeof (x as Record<string, unknown>).name !== 'string')) { setErr('Expected a JSON array of {"date": "YYYY-MM-DD", "name": "…"}.'); return }
    m.mutate({ holidays: parsed, source_note: source.trim() || null })
  }
  return (
    <Dialog open={open} onClose={onClose} size="lg" title="Import holidays (JSON)" description="Bank-holiday data is your input. Record where it came from."
      footer={<><Button variant="secondary" onClick={onClose}>Close</Button><Button loading={m.isPending} onClick={go}>Import</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        {res && <p role="status" className="rounded border border-ok-100 bg-ok-50 px-3 py-2 text-sm text-ok-700">{res}</p>}
        <Field label="Source note" hint="e.g. 'Official government list, retrieved 12 Nov 2026'. Stored on the calendar."><Input value={source} onChange={(e) => setSource(e.target.value)} /></Field>
        <Field label="Holidays (JSON array)"><Textarea rows={8} className="font-mono text-xs" value={text} onChange={(e) => setText(e.target.value)} spellCheck={false} /></Field>
      </div>
    </Dialog>
  )
}

export function RulesTab() {
  const manage = useCanManage()
  const q = useApiQuery<DeadlineRule[]>(['deadline-rules'], '/diary/deadline-rules')
  const toggle = useApiMutation((r: DeadlineRule) => api.patch(`/diary/deadline-rules/${r.id}`, { is_active: !r.is_active }), { invalidate: [['deadline-rules']], successMessage: 'Rule updated' })
  const cols: Column<DeadlineRule>[] = [
    { key: 'n', header: 'Rule', cell: (r) => <span className="block"><span className="font-medium text-navy-900">{r.name}</span><span className="block font-mono text-2xs text-stone-500">{r.key}</span></span> },
    { key: 'o', header: 'Offset', cell: (r) => `${r.offset_days} ${r.day_type} days ${r.direction}` },
    { key: 'j', header: 'Jurisdiction', hideOnNarrow: true, cell: (r) => jurisdictionLabel(r.jurisdiction) },
    { key: 'r', header: 'Roll', hideOnNarrow: true, cell: (r) => humanise(r.roll_convention) },
    { key: 's', header: 'Source note', hideOnNarrow: true, cell: (r) => <span className="text-xs text-stone-700">{r.source_note}</span> },
    { key: 'a', header: 'Active', cell: (r) => manage ? <Button size="sm" variant={r.is_active ? 'secondary' : 'ghost'} onClick={() => toggle.mutate(r)} aria-pressed={r.is_active}>{r.is_active ? 'Active' : 'Inactive'}</Button> : <Badge tone={r.is_active ? 'success' : 'neutral'}>{r.is_active ? 'Active' : 'Inactive'}</Badge> },
  ]
  return (
    <div className="space-y-4">
      <p className="rounded-lg border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700"><strong>Illustrative rules only.</strong> These configurable rules demonstrate calculation and are not legal advice or authoritative procedural rules. Every calculated deadline is an unconfirmed suggestion until a responsible solicitor confirms it.</p>
      <DataTable caption="Deadline calculation rules" columns={cols} rows={q.data} rowKey={(r) => r.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} emptyTitle="No rules configured" />
    </div>
  )
}
export { PermissionDenied }
