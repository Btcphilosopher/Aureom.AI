import { useMemo } from 'react'
import { useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import type { Page } from '@/types/api'
import type { MatterOption, StaffOption, Task } from '@/types/tasks'

/** ISO datetime -> value for <input type="datetime-local"> in the browser's zone. */
export function toLocalInput(iso: string | null | undefined): string {
  if (!iso) return ''
  const d = new Date(iso)
  if (isNaN(d.getTime())) return ''
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`
}
export function fromLocalInput(v: string): string | null { return v ? new Date(v).toISOString() : null }
export function ymd(d: Date): string { const p = (n: number) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}` }

/** Staff people-picker options from the firm directory (names and roles only; available to every staff user). */
export function useStaff(): StaffOption[] {
  const dir = useApiQuery<{ users: { id: string; name: string }[] }>(['directory'], '/auth/directory', { staleTime: 60_000 })
  return useMemo(() => (dir.data?.users ?? []).map((u) => ({ id: u.id, name: u.name })).sort((a, b) => a.name.localeCompare(b.name)), [dir.data])
}

export function useMatterOptions(): MatterOption[] {
  const { can } = useAuth()
  const q = useApiQuery<Page<MatterOption>>(['matter-options'], '/matters?limit=200', { enabled: can('matters.read'), staleTime: 60_000 })
  return q.data?.items ?? []
}

export const PRIORITIES = ['low', 'normal', 'high', 'urgent'] as const
export const TASK_STATUSES = ['open', 'in_progress', 'blocked', 'done', 'cancelled'] as const

/** "england_and_wales" -> "England & Wales" (humanise() would lower-case the proper nouns). */
export function jurisdictionLabel(j: string | null | undefined): string {
  if (!j) return '—'
  return j.split('_').map((w) => (w === 'and' ? '&' : w.charAt(0).toUpperCase() + w.slice(1))).join(' ')
}
