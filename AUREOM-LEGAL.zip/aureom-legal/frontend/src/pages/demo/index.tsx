import { useState } from 'react'
import { Link, Route, Routes, useNavigate } from 'react-router-dom'
import { Check, FlaskConical, LogIn, RotateCcw, Server, ShieldCheck } from 'lucide-react'
import { Badge, Button, Card, Checkbox, NotFoundState, PageHeader } from '@/components/ui'
import { useLocalStorage, usePageTitle } from '@/hooks'
import { useAuth } from '@/lib/auth'
import { cn } from '@/lib/cn'
import { LEGEND, PERSONAS, STEPS, type DemoStep, type StepAction } from './steps'

function SignInAs({ personaKey, to }: { personaKey: string; to?: string }) {
  const p = PERSONAS[personaKey]
  const { me, demoLogin } = useAuth()
  const nav = useNavigate()
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const current = me?.user.email === p.email
  if (!me?.demo_mode) return <span className="text-xs text-stone-500">Demo mode is off</span>
  return (
    <span className="inline-flex flex-col">
      <Button size="sm" variant={current ? 'secondary' : 'brass'} disabled={busy} loading={busy} onClick={async () => {
        setBusy(true); setErr(null)
        try { await demoLogin(p.email); if (to) nav(to) } catch (e) { setErr(e instanceof Error ? e.message : 'Could not sign in') } finally { setBusy(false) }
      }}>{current ? <><Check className="h-3.5 w-3.5" aria-hidden />Signed in as {p.name.split(' ')[0]}</> : <><LogIn className="h-3.5 w-3.5" aria-hidden />Sign in as {p.name.split(' ')[0]}</>}</Button>
      {err && <span role="alert" className="mt-1 text-xs text-bad-700">{err}</span>}
    </span>
  )
}

function ActionRow({ a }: { a: StepAction }) {
  const p = PERSONAS[a.persona]
  const { me } = useAuth()
  const mine = me?.user.email === p.email
  return (
    <li className="grid gap-2 py-2.5 sm:grid-cols-[13rem_minmax(0,1fr)]">
      <div><p className="text-sm font-semibold text-navy-900">{p.name}</p><p className="text-xs text-stone-600">{p.role}</p></div>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <p className="min-w-0 flex-1 text-sm text-stone-800">{a.do}</p>
        <span className="flex flex-wrap items-center gap-2">
          {a.to && (mine ? <Link to={a.to}><Button size="sm" variant="secondary">{a.toLabel ?? 'Open'}</Button></Link> : null)}
          <SignInAs personaKey={a.persona} to={a.to} />
        </span>
      </div>
    </li>
  )
}

function StepCard({ s, done, onToggle }: { s: DemoStep; done: boolean; onToggle: (v: boolean) => void }) {
  return (
    <li id={`step-${s.n}`} className={cn('rounded-lg border bg-white shadow-panel', done ? 'border-ok-100' : 'border-stone-300')}>
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-200 px-5 py-4">
        <div className="flex items-start gap-3">
          <span aria-hidden className={cn('mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-serif text-base', done ? 'bg-ok-50 text-ok-700 ring-1 ring-ok-100' : 'bg-navy-900 text-ivory-50')}>{done ? <Check className="h-4 w-4" /> : s.n}</span>
          <div><h2 className="font-serif text-xl text-navy-900"><span className="sr-only">Step {s.n}: </span>{s.title}</h2><p className="text-sm text-stone-700">{s.summary}</p></div>
        </div>
        <Checkbox label="Done" checked={done} onChange={(e) => onToggle(e.target.checked)} />
      </div>
      <div className="space-y-4 px-5 py-4">
        <section aria-label={`Step ${s.n} actions`}><h3 className="text-2xs font-semibold uppercase tracking-wide text-stone-600">Who does what</h3><ul className="divide-y divide-stone-200">{s.actions.map((a, i) => <ActionRow key={i} a={a} />)}</ul></section>
        {s.data && <section aria-label="Suggested data"><h3 className="mb-1 text-2xs font-semibold uppercase tracking-wide text-stone-600">Suggested data</h3>
          <dl className="space-y-1.5 rounded border border-stone-200 bg-ivory-50 p-3 text-sm">{s.data.map((d) => <div key={d.label} className="grid gap-1 sm:grid-cols-[12rem_1fr]"><dt className="font-medium text-navy-900">{d.label}</dt><dd className="text-stone-800">{d.value}</dd></div>)}</dl></section>}
        <section aria-label="What to look for"><h3 className="mb-1 text-2xs font-semibold uppercase tracking-wide text-stone-600">What to look for</h3>
          <ul className="list-disc space-y-1 pl-5 text-sm text-stone-800">{s.lookFor.map((l, i) => <li key={i}>{l}</li>)}</ul></section>
        {s.simulated && <p role="note" className="flex items-start gap-2 rounded border border-dashed border-sim-600/60 bg-sim-50 px-3 py-2 text-sm text-sim-700"><FlaskConical className="mt-0.5 h-4 w-4 shrink-0" aria-hidden /><span><strong>Simulated: </strong>{s.simulated}</span></p>}
      </div>
    </li>
  )
}

function Guide() {
  usePageTitle('Guided demonstration')
  const { me } = useAuth()
  const [done, setDone] = useLocalStorage<number[]>('aureom.demo.done', [])
  const count = done.filter((n) => STEPS.some((s) => s.n === n)).length
  const toggle = (n: number, v: boolean) => setDone(v ? [...new Set([...done, n])] : done.filter((x) => x !== n))
  return (
    <>
      <PageHeader title="Guided demonstration" description="An end-to-end walkthrough of Pennine & Calder Solicitors’ matter lifecycle: from a prospective client to a closed matter with retention instructions. All data is fictional."
        actions={count > 0 && <Button variant="secondary" onClick={() => setDone([])}><RotateCcw className="h-4 w-4" aria-hidden />Reset ticks</Button>} />
      {!me?.demo_mode && <p role="note" className="mb-4 rounded-md border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700"><strong>Demo mode is off in this environment</strong>, so persona sign-in buttons are unavailable. Use each person’s own credentials, or enable DEMO_MODE for a demonstration (never in production).</p>}
      <div className="mb-5 rounded-lg border border-stone-200 bg-white p-4 shadow-panel">
        <div className="flex flex-wrap items-center justify-between gap-2 text-sm"><span className="font-medium text-navy-900">Progress</span><span className="tabular-nums text-stone-700">{count} of {STEPS.length} steps ticked</span></div>
        <div className="mt-2 h-2 overflow-hidden rounded bg-stone-200" role="progressbar" aria-label="Demonstration progress" aria-valuemin={0} aria-valuemax={STEPS.length} aria-valuenow={count}><div className="h-full bg-brass-500 transition-all" style={{ width: `${(count / STEPS.length) * 100}%` }} /></div>
        <p className="mt-2 text-xs text-stone-600">Currently signed in as <strong>{me?.user.name}</strong> ({me?.role.name}). Each step names who should act; “Sign in as…” switches persona (demo mode only). Ticks are saved in this browser.</p>
        <nav aria-label="Steps" className="mt-3 flex flex-wrap gap-1.5">{STEPS.map((s) => <a key={s.n} href={`#step-${s.n}`} className={cn('rounded border px-2 py-0.5 text-xs tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500', done.includes(s.n) ? 'border-ok-100 bg-ok-50 text-ok-700' : 'border-stone-300 text-navy-800 hover:bg-brass-50')}>{s.n}. {s.title.split(' ').slice(0, 3).join(' ')}…</a>)}</nav>
      </div>
      <ol className="space-y-5">{STEPS.map((s) => <StepCard key={s.n} s={s} done={done.includes(s.n)} onToggle={(v) => toggle(s.n, v)} />)}</ol>
      <section aria-label="What is real, simulated and external" className="mt-8">
        <h2 className="mb-1 font-serif text-2xl text-navy-900">What is real, simulated, or depends on an external service</h2>
        <p className="mb-3 text-sm text-stone-600">Nothing simulated is ever presented as verified. Report anything that looks otherwise.</p>
        <div className="grid gap-4 md:grid-cols-3">
          <Card title={<span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-ok-700" aria-hidden />Implemented (real in this build)</span>}><ul className="list-disc space-y-1 pl-5 text-sm text-stone-800">{LEGEND.real.map((x) => <li key={x}>{x}</li>)}</ul></Card>
          <Card title={<span className="flex items-center gap-2"><Badge tone="simulated">Simulated</Badge>Labelled mocks</span>}><ul className="list-disc space-y-1 pl-5 text-sm text-stone-800">{LEGEND.simulated.map((x) => <li key={x}>{x}</li>)}</ul></Card>
          <Card title={<span className="flex items-center gap-2"><Server className="h-4 w-4 text-navy-700" aria-hidden />Needs an external service</span>}><ul className="list-disc space-y-1 pl-5 text-sm text-stone-800">{LEGEND.external.map((x) => <li key={x}>{x}</li>)}</ul></Card>
        </div>
        <p className="mt-4 text-xs text-stone-600">See Administration → Integrations for the live status of each integration, and <code>docs/COMPLIANCE_REVIEW.md</code> for the professional and regulatory review needed before real use.</p>
      </section>
    </>
  )
}

export default function DemoSection() {
  return (
    <Routes>
      <Route index element={<Guide />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
