export interface Persona { key: string; name: string; role: string; email: string }
const D = 'pennine-calder.example'
export const PERSONAS: Record<string, Persona> = {
  daniel: { key: 'daniel', name: 'Daniel Rhodes', role: 'Solicitor (fee earner)', email: `daniel.rhodes@${D}` },
  margaret: { key: 'margaret', name: 'Margaret Thackray', role: 'Compliance (COLP & MLRO)', email: `margaret.thackray@${D}` },
  eleanor: { key: 'eleanor', name: 'Eleanor Whitcombe', role: 'Partner (responsible partner)', email: `eleanor.whitcombe@${D}` },
  priya: { key: 'priya', name: 'Priya Venkataraman', role: 'Partner (second approver)', email: `priya.venkataraman@${D}` },
  ben: { key: 'ben', name: 'Ben Holroyd', role: 'Paralegal', email: `ben.holroyd@${D}` },
  nadia: { key: 'nadia', name: 'Nadia Siddiqui', role: 'Finance manager', email: `nadia.siddiqui@${D}` },
  colin: { key: 'colin', name: 'Colin Whitaker', role: 'Cashier (finance)', email: `colin.whitaker@${D}` },
  thomas: { key: 'thomas', name: 'Thomas Bagshaw', role: 'Solicitor, Litigation (not on the matter)', email: `thomas.bagshaw@${D}` },
  oliver: { key: 'oliver', name: 'Oliver Bancroft', role: 'Administrator', email: `oliver.bancroft@${D}` },
}

export interface StepAction { persona: string; do: string; to?: string; toLabel?: string }
export interface DemoStep {
  n: number; id: string; title: string; summary: string
  actions: StepAction[]
  data?: { label: string; value: string }[]
  lookFor: string[]
  simulated?: string
}

export const STEPS: DemoStep[] = [
  { n: 1, id: 'client', title: 'Create a prospective client', summary: 'Record a new organisation and its director. Nothing makes them a client until onboarding is approved.',
    actions: [
      { persona: 'daniel', do: 'Open “New prospective client” and create the organisation.', to: '/clients?new=1', toLabel: 'New client' },
      { persona: 'daniel', do: 'Create the director as an individual, then add a “director of” relationship from the client page (Relationships tab).', to: '/clients?new=1', toLabel: 'New contact' },
      { persona: 'daniel', do: 'Create the counterparty as an organisation so it can be added to the matter later.', to: '/clients?new=1', toLabel: 'New contact' },
    ],
    data: [{ label: 'Client (organisation)', value: 'Hebden Bridge Brewing Company Ltd — company number 09876543 — rebecca.ellison@hebden-brewing.example — registered office Mill Lane, Hebden Bridge HX7 8AA' },
      { label: 'Director (individual)', value: 'Martin Ackroyd — born 2 Nov 1975 — martin@hebden-brewing.example' }, { label: 'Counterparty', value: 'Northern Taprooms Distribution Limited — company number 07123456' }],
    lookFor: ['Status is “Prospect” and there is no client reference yet.', 'Duplicates & merges (Clients → Duplicates) may flag the new “Martin Ackroyd” against an existing client: merging needs a second, different reviewer and keeps history.'] },
  { n: 2, id: 'conflict', title: 'Review a potential conflict match', summary: 'Run a conflict search; a human reviews each supporting match. The system never declares anyone conflict-free by itself.',
    actions: [
      { persona: 'daniel', do: 'Run a conflict search for the three names (and tick the new client as the subject).', to: '/clients/conflicts', toLabel: 'Conflict searches' },
      { persona: 'daniel', do: 'Try to record a decision — you cannot (solicitors lack conflicts.review).' },
      { persona: 'margaret', do: 'Open the search, read the supporting evidence for each match, record a disposition and note, then record the decision.', to: '/clients/conflicts', toLabel: 'Conflict searches' },
    ],
    data: [{ label: 'Search terms', value: 'Hebden Bridge Brewing Company Ltd · Northern Taprooms Distribution Limited · Martin Ackroyd' },
      { label: 'Expected matches', value: 'A fuzzy match of “Hebden Brewing Co” (an organisation on another matter) and the name Martin Ackroyd (existing contacts). Record “false positive” with a reason only after checking the records.' }],
    lookFor: ['A search with no clear outcome stays “pending review” until a human decides.', 'Every disposition and the final decision appear in the review history with who and when.', 'Evidence about matters you cannot access is withheld, not shown.'] },
  { n: 3, id: 'onboarding', title: 'Complete simulated onboarding', summary: 'Run the identity and screening checks (a simulated adapter) and approve onboarding as a human reviewer.',
    actions: [
      { persona: 'daniel', do: 'On the client page open Onboarding, start it, and run each available check.', to: '/clients', toLabel: 'Clients' },
      { persona: 'margaret', do: 'Review each check result, then approve onboarding (record a risk level).', to: '/clients', toLabel: 'Clients' },
    ],
    lookFor: ['Every check is labelled SIMULATED and never described as verified identity.', 'Only a user with onboarding.approve can approve; the client then becomes Active with a client reference.'],
    simulated: 'The identity provider is a simulated adapter. Results are demonstration outputs, not verified identity checks.' },
  { n: 4, id: 'matter', title: 'Open a restricted commercial matter', summary: 'Create the matter from the commercial template, restrict access, satisfy the opening requirements and get partner approval.',
    actions: [
      { persona: 'daniel', do: 'Create the matter with the wizard (Commercial contract template). Add the counterparty as a party.', to: '/matters?new=1', toLabel: 'New matter' },
      { persona: 'eleanor', do: 'Set access to “restricted” on the Access tab (a reason is required).', to: '/matters', toLabel: 'Matters' },
      { persona: 'daniel', do: 'Run a matter-scoped conflict search; Margaret clears it. Tick the opening checklist, then request “Open”.', to: '/clients/conflicts', toLabel: 'Conflict searches' },
      { persona: 'eleanor', do: 'Approve the pending request to open. Add Ben Holroyd, Nadia Siddiqui and Colin Whitaker as members (Access tab).', to: '/approvals', toLabel: 'Approvals inbox' },
      { persona: 'thomas', do: 'Search for the matter or open its link — it is hidden and access is refused without revealing its title.', to: '/matters', toLabel: 'Matters' },
    ],
    data: [{ label: 'Title', value: 'Distribution agreement — Hebden Bridge Brewing / Northern Taprooms' }, { label: 'Partner / fee earner', value: 'Eleanor Whitcombe / Daniel Rhodes' }],
    lookFor: ['The matter cannot open until a human-cleared conflict search, approved onboarding and required checklist items exist (blockers are listed).', 'A fee earner’s request becomes a pending approval bound to the matter version; who changed each state is recorded.', 'Restricted matters are excluded from lists, search, notifications and AI retrieval for non-members.'] },
  { n: 5, id: 'documents', title: 'Upload and version a fictional agreement', summary: 'Upload draft v1 of the distribution agreement, then upload v2 as a new version of the same document.',
    actions: [
      { persona: 'daniel', do: 'Upload “Distribution Agreement v1 (draft).pdf” (from the repo’s sample-docs folder) to the matter.', to: '/documents?new=1', toLabel: 'Upload' },
      { persona: 'daniel', do: 'On the document page upload “Distribution Agreement v2 (revised).pdf” as a new version, then open Compare (v1 → v2).', to: '/documents', toLabel: 'Documents' },
      { persona: 'daniel', do: 'Search the text for “minimum purchase”. Then file the unfiled “New instruction” email to the matter (Correspondence → Sync demo mailbox first if needed).', to: '/correspondence', toLabel: 'Correspondence' },
    ],
    lookFor: ['Versions are immutable with author and SHA-256; the scan and text extraction run in the background.', 'The preview is extracted text by page and paragraph, never the raw file. Try uploading a .exe or a fake PDF — both are refused.', 'Compare shows 90 → 120 days, 2,000 → 2,400 cases and the liability and payment-term changes.'],
    simulated: 'Malware scanning and OCR are labelled mock providers; the mailbox is a mock.' },
  { n: 6, id: 'agents', title: 'Run the document-review and chronology agents', summary: 'Let the agents read the matter (as Daniel) and report with citations. They only propose.',
    actions: [
      { persona: 'daniel', do: 'Start the Document review agent on the matter, then the Chronology agent.', to: '/ai?new=1', toLabel: 'Start an agent' },
      { persona: 'daniel', do: 'Read the run: facts with document · version · page ¶ citations, inferences, contradictions, missing information, and the proposed actions.', to: '/ai/runs', toLabel: 'AI runs' },
    ],
    lookFor: ['Every fact carries a citation and a verbatim quote; the start date appears twice with different values (1 March vs 1 April 2027), flagged as a contradiction.', 'Inferred dates are labelled “inferred — check”; the chronology separates explicit and inferred dates.', 'Nothing has been applied yet. Events show retrievals and policy decisions — no model reasoning is stored.'],
    simulated: 'The AI provider is the local mock (heuristic extraction), clearly labelled; nothing leaves the application.' },
  { n: 7, id: 'task', title: 'Confirm a suggested task and deadline', summary: 'Approve the agent’s proposed task, then confirm (or reject) the suggested deadline as a human.',
    actions: [
      { persona: 'daniel', do: 'On the document-review run, approve the proposed task and the deadline suggestion (check the supporting passage), then submit your decisions.', to: '/ai/runs?status=awaiting_review', toLabel: 'Runs awaiting review' },
      { persona: 'ben', do: 'Open the deadline suggestion — a paralegal cannot confirm it.', to: '/tasks/deadlines', toLabel: 'Deadlines' },
      { persona: 'daniel', do: 'Confirm the deadline (add a review note; optionally create a linked task).', to: '/tasks/deadlines', toLabel: 'Deadlines' },
    ],
    lookFor: ['The suggested deadline is “unconfirmed” and shows its supporting passage and source until a person with deadlines.confirm confirms it.', 'Try editing an approved action: its approval is cleared and a new approval is required (the content hash changes).'] },
  { n: 8, id: 'message', title: 'Review and approve a draft client message', summary: 'Have the drafting agent prepare a client update from an approved template; edit it; get it approved; send (simulated).',
    actions: [
      { persona: 'daniel', do: 'Start the Drafting agent (client message) with your instructions; approve the draft on the run page.', to: '/ai?new=1', toLabel: 'Start an agent' },
      { persona: 'daniel', do: 'Open the saved draft in Correspondence, edit it, tick client-visible, and request approval.', to: '/correspondence', toLabel: 'Correspondence' },
      { persona: 'eleanor', do: 'Approve the message (note the bound content hash).', to: '/correspondence', toLabel: 'Correspondence' },
      { persona: 'daniel', do: 'Edit the text once more — sending is blocked until re-approved. Re-request, approve, then send.', to: '/correspondence', toLabel: 'Correspondence' },
    ],
    lookFor: ['The agent only saves a draft; it can never send. The client-visible thread never shows internal notes.', 'The send is a labelled SIMULATED delivery by the mock email provider.'],
    simulated: 'Email delivery is a mock provider: no message leaves the application.' },
  { n: 9, id: 'billing', title: 'Record time and prepare a draft invoice', summary: 'Record exact time, approve it, build a draft invoice, and have it approved and issued by different people.',
    actions: [
      { persona: 'ben', do: 'Record 384 minutes (6.4 hours) on the matter with a narrative, and submit it.', to: '/billing?new=time', toLabel: 'Log time' },
      { persona: 'eleanor', do: 'Approve the time, open WIP, select it and create a draft invoice, then submit it for approval.', to: '/billing?tab=wip', toLabel: 'WIP' },
      { persona: 'eleanor', do: 'Try to approve your own invoice — four-eyes blocks it. Priya Venkataraman (added as a member) approves instead.', to: '/billing?tab=invoices', toLabel: 'Invoices' },
      { persona: 'nadia', do: 'Issue the approved invoice.', to: '/billing?tab=invoices', toLabel: 'Invoices' },
    ],
    data: [{ label: 'Expected amounts', value: '6.4 h × £125.00 = £800.00 net + £160.00 VAT = £960.00 total (decimal arithmetic)' }],
    lookFor: ['Issuing creates a receivable — it is not revenue recognition. Editing the invoice after approval invalidates the approval.'] },
  { n: 10, id: 'ledger', title: 'Allocate a synthetic receipt and reconcile it', summary: 'Record a bank receipt, authorise it, allocate it to the invoice, and reconcile the office account.',
    actions: [
      { persona: 'colin', do: 'Sync the (synthetic) bank feed and record receipt SYN-O-0003 (£960.00) from the client.', to: '/ledger/receipts', toLabel: 'Receipts' },
      { persona: 'nadia', do: 'Authorise the receipt journal (Authorisations inbox); Colin then posts it.', to: '/ledger', toLabel: 'Client ledger' },
      { persona: 'colin', do: 'Request an allocation of £960.00 to the invoice; Nadia approves; Colin applies it. Applying the same approval twice is refused.', to: '/ledger/receipts', toLabel: 'Receipts' },
      { persona: 'colin', do: 'Start a reconciliation for the office bank account (statement balance = all synthetic lines), match lines and prepare it.', to: '/ledger/reconciliation', toLabel: 'Reconciliation' },
      { persona: 'nadia', do: 'Sign off the reconciliation once the difference is £0.00 (the preparer cannot). Optionally recognise the revenue as a separate step.', to: '/ledger/revenue', toLabel: 'Revenue recognition' },
    ],
    lookFor: ['Receipt, allocation, reconciliation and revenue recognition are four separate, individually authorised steps. A receipt is not earned revenue.', 'Office and client funds are separate ledgers; journals must balance (also enforced by the database).'],
    simulated: 'The bank feed is a synthetic mock. Nothing here is real accounting; see the professional-review notice in the Client Ledger.' },
  { n: 11, id: 'close', title: 'Close the matter with retention instructions', summary: 'Complete the closing checklist, choose a retention policy and close with partner approval.',
    actions: [
      { persona: 'daniel', do: 'On the matter’s Closure tab complete the closing checklist, choose “General files – 6 years”, and request Close.', to: '/matters', toLabel: 'Matters' },
      { persona: 'eleanor', do: 'Approve the closure. (A legal hold, unbilled WIP or a client balance would each block it.)', to: '/approvals', toLabel: 'Approvals inbox' },
      { persona: 'margaret', do: 'Open Administration → Audit log and “Verify chain” to confirm the tamper-evident audit trail is intact.', to: '/admin', toLabel: 'Administration' },
    ],
    lookFor: ['The closed date and retention-until date are recorded; each state change shows who requested, approved and why.', 'The audit chain verifies: audit rows cannot be edited or deleted by ordinary users.'] },
]

export const LEGEND = {
  real: ['All records, permissions, restricted matters and ethical walls', 'Approvals bound to exact content, four-eyes controls, audit chain', 'Document storage, versions, full-text search, extraction', 'Time, invoices, double-entry ledgers, allocations, reconciliation (demonstration accounting)'],
  simulated: ['Identity and screening checks (simulated adapter)', 'Email, calendar and e-signature providers (labelled mocks)', 'Bank feed (synthetic transactions)', 'Malware scanning and OCR (mock providers)', 'AI agents (local mock provider — heuristic, no language model)'],
  external: ['A regulated identity-verification provider and Companies House lookup', 'A real mail server, calendar and e-signature service', 'A bank / open-banking feed (payments can never be initiated by AI)', 'ClamAV or similar malware scanning and an OCR engine', 'A live language model and an external legal-research source (explicitly configured, with source and date)', 'SSO / identity provider'],
}
