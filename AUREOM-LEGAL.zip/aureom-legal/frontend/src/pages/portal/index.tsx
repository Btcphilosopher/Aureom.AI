import { Link, Route, Routes, useParams } from 'react-router-dom'
import { ArrowRight, Download, FileText, Mail, Receipt, UserRound } from 'lucide-react'
import { Badge, DateTime, EmptyState, LoadingState, Money, NotFoundState, PermissionDenied, QueryBoundary, StatusBadge } from '@/components/ui'
import { api, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise, formatBytes } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle } from '@/hooks'
import type { DecimalString } from '@/types/api'

interface PMatter { id: string; reference: string; title: string; status: string; stage: string | null; opened_at: string | null }
interface PMatterDetail extends PMatter { description: string | null; target_date: string | null; responsible_partner: string | null; fee_earner: string | null }
interface PDoc { id: string; title: string; doc_type: string; status: string; version_no: number; filename: string; size_bytes: number; updated_at: string }
interface PMail { id: string; subject: string; direction: string; body_text: string; sent_at: string | null }
interface PInvoice { id: string; number: string | null; kind: string; status: string; currency: string; total: DecimalString; amount_paid: DecimalString; issued_at: string | null; due_date: string | null }

function PortalFrame({ children }: { children: React.ReactNode }) {
  const { me } = useAuth()
  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-8 rounded-xl border border-brass-200 bg-gradient-to-b from-ivory-50 to-ivory-200 px-7 py-6">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-brass-600">{me?.firm.name} · Client portal</p>
        <h1 className="mt-1 font-serif text-3xl text-navy-900">Welcome, {me?.user.name.split(' ')[0]}</h1>
        <p className="mt-1.5 max-w-xl text-sm text-stone-700">Here you can follow the progress of your matters, download documents we have shared with you and see your invoices. For anything urgent, please contact your solicitor directly.</p>
      </div>
      {children}
    </div>
  )
}

function Matters() {
  usePageTitle('Your matters')
  const q = useApiQuery<{ items: PMatter[] }>(['portal', 'matters'], '/portal/matters')
  return (
    <PortalFrame>
      <h2 className="mb-3 font-serif text-xl text-navy-900">Your matters</h2>
      <QueryBoundary query={q} empty={<EmptyState title="No matters to show yet" description="When we open a matter for you it will appear here." />}>
        {(d) => (
          <ul className="space-y-3">{d.items.map((m) => (
            <li key={m.id}>
              <Link to={`/portal/matters/${m.id}`} className="group flex items-center justify-between gap-4 rounded-xl border border-stone-200 bg-white px-5 py-4 shadow-panel hover:border-brass-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
                <span className="min-w-0"><span className="block font-serif text-lg text-navy-900">{m.title}</span>
                  <span className="mt-0.5 block text-xs text-stone-600"><span className="font-mono">{m.reference}</span>{m.stage ? ` · Stage: ${humanise(m.stage)}` : ''}{m.opened_at ? <> · Opened <DateTime value={m.opened_at} mode="date" /></> : null}</span></span>
                <span className="flex shrink-0 items-center gap-3"><StatusBadge status={m.status} /><ArrowRight className="h-4 w-4 text-stone-400 group-hover:text-brass-600" aria-hidden /></span>
              </Link></li>))}</ul>)}
      </QueryBoundary>
    </PortalFrame>
  )
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <section className="mb-7" aria-label={title}>
      <h2 className="mb-2 flex items-center gap-2 font-serif text-xl text-navy-900"><span className="text-brass-600" aria-hidden>{icon}</span>{title}</h2>
      {children}
    </section>
  )
}

function MatterView() {
  const { id = '' } = useParams()
  const m = useApiQuery<PMatterDetail>(['portal', 'matter', id], `/portal/matters/${id}`)
  const docs = useApiQuery<{ items: PDoc[] }>(['portal', 'docs', id], `/portal/matters/${id}/documents`, { enabled: !!m.data })
  const mail = useApiQuery<{ items: PMail[] }>(['portal', 'mail', id], `/portal/matters/${id}/correspondence`, { enabled: !!m.data })
  const inv = useApiQuery<{ items: PInvoice[] }>(['portal', 'inv', id], `/portal/matters/${id}/invoices`, { enabled: !!m.data })
  useBreadcrumbs([{ label: 'Client portal', to: '/portal' }, { label: m.data?.reference ?? 'Matter' }])
  usePageTitle(m.data?.title ?? 'Matter')
  return (
    <PortalFrame>
      <QueryBoundary query={m} what="matter">{(d) => (
        <>
          <div className="mb-7 rounded-xl border border-stone-200 bg-white p-6 shadow-panel">
            <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-mono text-xs text-stone-600">{d.reference}</p><h2 className="font-serif text-2xl text-navy-900">{d.title}</h2></div><StatusBadge status={d.status} /></div>
            {d.description && <p className="mt-3 text-sm text-stone-800">{d.description}</p>}
            <dl className="mt-4 grid gap-4 border-t border-stone-100 pt-4 text-sm sm:grid-cols-4">
              <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Current stage</dt><dd className="mt-0.5">{d.stage ? humanise(d.stage) : '—'}</dd></div>
              <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Partner</dt><dd className="mt-0.5 flex items-center gap-1"><UserRound className="h-3.5 w-3.5 text-stone-500" aria-hidden />{d.responsible_partner ?? '—'}</dd></div>
              <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Your solicitor</dt><dd className="mt-0.5 flex items-center gap-1"><UserRound className="h-3.5 w-3.5 text-stone-500" aria-hidden />{d.fee_earner ?? '—'}</dd></div>
              <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Target date</dt><dd className="mt-0.5"><DateTime value={d.target_date} mode="date" /></dd></div>
            </dl>
          </div>

          <Section icon={<FileText className="h-5 w-5" />} title="Documents shared with you">
            {docs.isPending ? <LoadingState rows={2} /> : docs.isError ? <p role="alert" className="text-sm text-bad-700">We could not load documents: {docs.error.message}</p> : docs.data.items.length === 0 ? <p className="rounded-lg border border-dashed border-stone-300 bg-white px-4 py-5 text-sm text-stone-600">No documents have been shared with you yet. Documents appear here once they have been checked and released by your solicitor.</p> : (
              <ul className="divide-y divide-stone-100 rounded-xl border border-stone-200 bg-white shadow-panel">{docs.data.items.map((x) => (
                <li key={x.id} className="flex items-center justify-between gap-3 px-5 py-3">
                  <span className="min-w-0"><span className="block truncate text-sm font-medium text-navy-900">{x.title}</span><span className="text-xs text-stone-600">{humanise(x.doc_type)} · version {x.version_no} · {formatBytes(x.size_bytes)} · updated <DateTime value={x.updated_at} mode="date" /></span></span>
                  <a href={api.url(`/portal/documents/${x.id}/download`)} download className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-stone-300 px-3 py-1.5 text-xs font-semibold text-navy-800 hover:bg-ivory-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500"><Download className="h-3.5 w-3.5" aria-hidden />Download</a>
                </li>))}</ul>)}
          </Section>

          <Section icon={<Mail className="h-5 w-5" />} title="Messages from us">
            {mail.isPending ? <LoadingState rows={2} /> : mail.isError ? <p role="alert" className="text-sm text-bad-700">We could not load messages: {mail.error.message}</p> : mail.data.items.length === 0 ? <p className="rounded-lg border border-dashed border-stone-300 bg-white px-4 py-5 text-sm text-stone-600">No messages yet.</p> : (
              <ul className="space-y-3">{mail.data.items.map((x) => (
                <li key={x.id} className="rounded-xl border border-stone-200 bg-white p-4 shadow-panel">
                  <div className="flex items-start justify-between gap-3"><h3 className="text-sm font-semibold text-navy-900">{x.subject}</h3><span className="shrink-0 text-xs text-stone-600"><DateTime value={x.sent_at} mode="date" /></span></div>
                  <p className="mt-1 text-xs text-stone-500">{x.direction === 'outbound' ? 'From your solicitors' : 'Received from you'}</p>
                  <p className="mt-2 whitespace-pre-wrap text-sm text-stone-800">{x.body_text}</p></li>))}</ul>)}
          </Section>

          <Section icon={<Receipt className="h-5 w-5" />} title="Invoices">
            {inv.isPending ? <LoadingState rows={2} /> : inv.isError ? <p role="alert" className="text-sm text-bad-700">We could not load invoices: {inv.error.message}</p> : inv.data.items.length === 0 ? <p className="rounded-lg border border-dashed border-stone-300 bg-white px-4 py-5 text-sm text-stone-600">No invoices have been issued.</p> : (
              <div className="overflow-auto rounded-xl border border-stone-200 bg-white shadow-panel">
                <table className="w-full text-sm"><caption className="sr-only">Invoices for this matter</caption>
                  <thead className="bg-ivory-200 text-xs uppercase tracking-wide text-stone-700"><tr><th scope="col" className="px-4 py-2.5 text-left">Number</th><th scope="col" className="px-4 py-2.5 text-left">Issued</th><th scope="col" className="px-4 py-2.5 text-left">Due</th><th scope="col" className="px-4 py-2.5 text-right">Total</th><th scope="col" className="px-4 py-2.5 text-right">Paid</th><th scope="col" className="px-4 py-2.5 text-left">Status</th></tr></thead>
                  <tbody>{inv.data.items.map((i) => (
                    <tr key={i.id} className="border-t border-stone-100"><th scope="row" className="px-4 py-2.5 text-left font-mono text-xs font-normal">{i.number ?? '—'}{i.kind === 'credit_note' && <Badge className="ml-2" tone="neutral">Credit note</Badge>}</th>
                      <td className="px-4 py-2.5"><DateTime value={i.issued_at} mode="date" /></td><td className="px-4 py-2.5"><DateTime value={i.due_date} mode="date" /></td>
                      <td className="px-4 py-2.5 text-right"><Money value={i.total} currency={i.currency} /></td><td className="px-4 py-2.5 text-right"><Money value={i.amount_paid} currency={i.currency} /></td><td className="px-4 py-2.5"><StatusBadge status={i.status} /></td></tr>))}</tbody></table>
              </div>)}
          </Section>
          <p className="text-xs text-stone-500">Your solicitors' internal notes and working documents are never shown here.</p>
        </>)}</QueryBoundary>
    </PortalFrame>
  )
}

export default function PortalSection() {
  const { me, isClientUser } = useAuth()
  if (me && !isClientUser) return <PermissionDenied message="The client portal is for authorised clients. Staff use the main sections." permission="portal.read" />
  return (
    <Routes>
      <Route index element={<Matters />} />
      <Route path="matters/:id" element={<MatterView />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
