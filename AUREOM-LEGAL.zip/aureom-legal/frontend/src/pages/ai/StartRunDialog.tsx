import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Checkbox, Dialog, Field, Input, Select, Textarea } from '@/components/ui'
import { api, useApiMutation, useApiQuery, type ApiError } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import type { Page } from '@/types/api'
import type { AgentCatalogItem, RunDetail } from '@/types/ai'
import type { Contact } from '@/types/clients'
import type { DocItem, DocTemplate } from '@/types/documents'
import { ACTIVE_STATES, useMatterOptions } from './common'

export interface StartRunProps { agent: AgentCatalogItem | null; open: boolean; onClose: () => void; matterId?: string | null; lockMatter?: boolean }

const KINDS = [{ v: 'correspondence', l: 'Client message / letter' }, { v: 'attendance_note', l: 'Attendance-note summary' }, { v: 'document', l: 'Document draft' }]

/** Starts an agent run. In non-production environments runs are processed inline (?sync=true) so results appear immediately;
 *  in production the worker picks the run up and the run page polls. */
export function StartRunDialog({ agent, open, onClose, matterId, lockMatter }: StartRunProps) {
  const nav = useNavigate()
  const { me } = useAuth()
  const matters = useMatterOptions(open && !!agent?.requires_matter)
  const [matter, setMatter] = useState(matterId ?? '')
  const [docIds, setDocIds] = useState<string[]>([])
  const [templateId, setTemplateId] = useState('')
  const [kind, setKind] = useState('correspondence')
  const [instructions, setInstructions] = useState('')
  const [subject, setSubject] = useState('')
  const [query, setQuery] = useState('')
  const [external, setExternal] = useState(false)
  const [contact, setContact] = useState('')
  const [minutes, setMinutes] = useState('')
  const [workDate, setWorkDate] = useState(new Date().toISOString().slice(0, 10))
  const [hint, setHint] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const key = agent?.key

  useEffect(() => { if (open) { setMatter(matterId ?? ''); setErr(null) } }, [open, matterId])
  const docs = useApiQuery<Page<DocItem>>(['ai', 'docs', matter], `/documents?matter_id=${matter}&limit=100`, { enabled: open && !!matter && (key === 'document_review' || key === 'chronology') })
  const templates = useApiQuery<DocTemplate[]>(['ai', 'templates'], '/documents/templates?approved_only=true', { enabled: open && key === 'drafting' })
  const contacts = useApiQuery<Page<Contact>>(['ai', 'contacts'], '/clients?limit=100', { enabled: open && key === 'intake' })

  const inline = me?.environment !== 'production'
  const start = useApiMutation(
    (body: Record<string, unknown>) => api.post<RunDetail>(`/agents/runs${inline ? '?sync=true' : ''}`, body),
    { errorToast: false, invalidate: [['ai', 'runs']], onSuccess: (r) => { onClose(); nav(`/ai/runs/${r.id}`) }, onError: (e) => setErr(e) },
  )

  const valid = useMemo(() => {
    if (!agent) return false
    if (agent.requires_matter && !matter) return false
    if (key === 'knowledge') return query.trim().length >= 2
    if (key === 'intake') return !!contact
    if (key === 'billing_assistant') return !minutes || (Number(minutes) > 0 && Number.isInteger(Number(minutes)))
    return true
  }, [agent, matter, key, query, contact, minutes])

  if (!agent) return null
  const submit = () => {
    setErr(null)
    const input: Record<string, unknown> = {}
    if ((key === 'document_review' || key === 'chronology') && docIds.length) input.document_ids = docIds
    if (key === 'drafting') { input.kind = kind; if (templateId) input.template_id = templateId; if (instructions.trim()) input.instructions = instructions.trim(); if (subject.trim()) input.subject = subject.trim() }
    if (key === 'knowledge') { input.query = query.trim(); if (external) input.external_research = true }
    if (key === 'billing_assistant' && minutes) input.entries = [{ work_date: workDate, minutes: Number(minutes), ...(hint.trim() ? { narrative_hint: hint.trim() } : {}) }]
    start.mutate({ agent_type: agent.key, matter_id: agent.requires_matter ? matter : null, contact_id: key === 'intake' ? contact : null, input })
  }

  return (
    <Dialog open={open} onClose={onClose} size="lg" title={`Start: ${agent.name}`}
      description={agent.read_only ? 'Read-only: this agent cannot propose changes.' : `May propose (for your review): ${agent.proposes_actions.map((a) => a.replace(/_/g, ' ')).join(', ')}.`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={submit} loading={start.isPending} disabled={!valid}>Start run</Button></>}>
      <div className="space-y-4">
        <p className="rounded-md bg-ivory-100 px-3 py-2 text-xs text-stone-700">The run uses <strong>your</strong> permissions and retrieves only records you are allowed to see. Prompt template <span className="tabular-nums">{agent.prompt_template_version}</span>.
          {inline ? ' In this environment the run is processed immediately.' : ' The run is queued and processed by the background worker.'}</p>
        {agent.requires_matter && (
          <Field label="Matter" required hint="Only matters you can access, and that permit AI retrieval, can be used.">
            {(p) => <Select {...p} value={matter} onChange={(e) => { setMatter(e.target.value); setDocIds([]) }} disabled={lockMatter}>
              <option value="">Select a matter…</option>{matters.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
              {lockMatter && matterId && !matters.some((m) => m.id === matterId) && <option value={matterId}>This matter</option>}</Select>}
          </Field>)}

        {(key === 'document_review' || key === 'chronology') && matter && (
          <fieldset className="space-y-1">
            <legend className="mb-1 text-sm font-medium text-navy-900">Documents <span className="font-normal text-stone-600">(none selected = all documents on the matter)</span></legend>
            {docs.isPending ? <p className="text-sm text-stone-600">Loading documents…</p> : (docs.data?.items ?? []).length === 0 ? <p className="text-sm text-stone-600">This matter has no documents you can read.</p> :
              <div className="max-h-48 space-y-1 overflow-y-auto rounded border border-stone-200 p-2">
                {(docs.data?.items ?? []).map((d) => <Checkbox key={d.id} label={`${d.title} (v${d.current_version_no})`} checked={docIds.includes(d.id)}
                  onChange={(e) => setDocIds((x) => e.target.checked ? [...x, d.id] : x.filter((i) => i !== d.id))} />)}</div>}
          </fieldset>)}

        {key === 'drafting' && (<>
          <Field label="What to prepare">{(p) => <Select {...p} value={kind} onChange={(e) => setKind(e.target.value)}>{KINDS.map((k) => <option key={k.v} value={k.v}>{k.l}</option>)}</Select>}</Field>
          <Field label="Approved template" hint="Only templates approved by a partner are offered. Leave blank to let the agent choose a matching approved template.">
            {(p) => <Select {...p} value={templateId} onChange={(e) => setTemplateId(e.target.value)}><option value="">Choose automatically</option>{(templates.data ?? []).filter((t) => t.approved).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select>}</Field>
          <Field label="Subject (optional)">{(p) => <Input {...p} value={subject} onChange={(e) => setSubject(e.target.value)} />}</Field>
          <Field label="Your instructions and facts" hint="Only facts you give here or that come from the matter records are used. Unresolved fields are marked for you to complete.">
            {(p) => <Textarea {...p} rows={4} value={instructions} onChange={(e) => setInstructions(e.target.value)} />}</Field>
          <p className="text-xs text-stone-600">The result is a saved <strong>draft</strong> after you approve it. Nothing is sent or shared by the agent.</p>
        </>)}

        {key === 'knowledge' && (<>
          <Field label="What are you looking for?" required hint="Searches approved internal precedents and practice notes only.">{(p) => <Input {...p} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. distribution agreement termination notice" />}</Field>
          <Checkbox label="Also ask the external legal research source" hint="Requires a configured research adapter; otherwise the run will state that it is not configured. No authorities are ever invented." checked={external} onChange={(e) => setExternal(e.target.checked)} />
        </>)}

        {key === 'intake' && (
          <Field label="Contact" required hint="Reads the contact and their submitted onboarding form (treated as untrusted data).">
            {(p) => <Select {...p} value={contact} onChange={(e) => setContact(e.target.value)}><option value="">Select a contact…</option>{(contacts.data?.items ?? []).map((c) => <option key={c.id} value={c.id}>{c.display_name}</option>)}</Select>}</Field>)}

        {key === 'billing_assistant' && (<>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Date worked">{(p) => <Input {...p} type="date" value={workDate} onChange={(e) => setWorkDate(e.target.value)} />}</Field>
            <Field label="Minutes you actually worked (optional)" hint="Leave blank to receive only gap flags.">{(p) => <Input {...p} inputMode="numeric" value={minutes} onChange={(e) => setMinutes(e.target.value)} placeholder="e.g. 36" />}</Field>
          </div>
          <Field label="What you did (optional)">{(p) => <Textarea {...p} rows={2} value={hint} onChange={(e) => setHint(e.target.value)} />}</Field>
          <p className="rounded-md border border-stone-200 bg-white px-3 py-2 text-xs text-stone-700"><strong>This assistant never invents work performed or time spent.</strong> It only structures what is already recorded or what you type here, and flags “minutes required” where you have not said.</p>
        </>)}

        {err && <div role="alert" className="rounded-md border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}{err.code === 'budget_exceeded' && ' (budgets are set under Administration → Firm settings)'}</div>}
      </div>
    </Dialog>
  )
}
export { ACTIVE_STATES }
