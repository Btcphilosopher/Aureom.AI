import { Link, useNavigate } from 'react-router-dom'
import { Button, DataTable, DateTime, Field, PageHeader, Select, type Column } from '@/components/ui'
import { useApiQuery, qs } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useQueryParams, usePageTitle } from '@/hooks'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { RunSummary } from '@/types/ai'
import { ACTIVE_STATES, ProviderBadge, RunStatus, STATUS_FILTERS, useCatalog, useMatterOptions } from './common'

export default function RunsList() {
  usePageTitle('AI runs')
  const nav = useNavigate()
  const { can } = useAuth()
  const [p, setP] = useQueryParams(['status', 'agent', 'matter', 'mine', 'offset'] as const)
  const catalog = useCatalog()
  const matters = useMatterOptions(true)
  const limit = 25
  const offset = Number(p.offset ?? 0)
  const params = { status: p.status, agent_type: p.agent, matter_id: p.matter, mine: p.mine === '1' ? 'true' : undefined, limit, offset }
  const q = useApiQuery<Page<RunSummary>>(['ai', 'runs', params], `/agents/runs${qs(params)}`, {
    refetchInterval: (query) => ((query.state.data as Page<RunSummary> | undefined)?.items.some((r) => ACTIVE_STATES.has(r.status)) ? 2500 : false),
  })
  const cols: Column<RunSummary>[] = [
    { key: 'agent', header: 'Agent', cell: (r) => <span><Link to={`/ai/runs/${r.id}`} className="font-medium text-navy-800 underline decoration-brass-500/60 underline-offset-2">{r.agent_name}</Link><span className="block text-2xs tabular-nums text-stone-500">{r.id.slice(0, 8)}</span></span> },
    { key: 'status', header: 'State', cell: (r) => <span className="flex flex-col items-start gap-1"><RunStatus status={r.status} />{r.pending_actions > 0 && <span className="text-2xs text-warn-700">{r.pending_actions} to review</span>}</span> },
    { key: 'matter', header: 'Matter', cell: (r) => r.matter_reference ? <Link to={`/matters/${r.matter_id}`} className="tabular-nums underline">{r.matter_reference}</Link> : <span className="text-stone-500">—</span> },
    { key: 'by', header: 'Requested by', cell: (r) => r.requested_by_name ?? '—', hideOnNarrow: true },
    { key: 'model', header: 'Provider / model', cell: (r) => <span className="flex flex-col items-start gap-1"><ProviderBadge provider={r.provider} /><span className="text-2xs text-stone-600">{r.model}</span></span>, hideOnNarrow: true },
    { key: 'cost', header: 'Cost', numeric: true, cell: (r) => <span className="tabular-nums">£{r.cost_gbp}</span>, hideOnNarrow: true },
    { key: 'at', header: 'Started', cell: (r) => <DateTime value={r.created_at} mode="relative" /> },
  ]
  return (
    <>
      <PageHeader title="AI runs" description="Every agent run with its state, scope, provider and cost. Runs awaiting review need a human decision before anything changes."
        actions={can('ai.use') && <Link to="/ai?new=1"><Button>Start a run</Button></Link>} />
      <div className="mb-4 grid gap-3 rounded-lg border border-stone-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="State">{(f) => <Select {...f} value={p.status ?? ''} onChange={(e) => setP({ status: e.target.value || null, offset: null })}><option value="">All states</option>{STATUS_FILTERS.map((s) => <option key={s} value={s}>{humanise(s)}</option>)}</Select>}</Field>
        <Field label="Agent">{(f) => <Select {...f} value={p.agent ?? ''} onChange={(e) => setP({ agent: e.target.value || null, offset: null })}><option value="">All agents</option>{(catalog.data?.agents ?? []).map((a) => <option key={a.key} value={a.key}>{a.name}</option>)}</Select>}</Field>
        <Field label="Matter">{(f) => <Select {...f} value={p.matter ?? ''} onChange={(e) => setP({ matter: e.target.value || null, offset: null })}><option value="">All matters</option>{matters.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</Select>}</Field>
        <Field label="Requested by">{(f) => <Select {...f} value={p.mine ?? ''} onChange={(e) => setP({ mine: e.target.value || null, offset: null })}><option value="">Everyone I can see</option><option value="1">Only me</option></Select>}</Field>
      </div>
      <DataTable caption="Agent runs" columns={cols} rows={q.data?.items ?? []} rowKey={(r) => r.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
        onRowClick={(r) => nav(`/ai/runs/${r.id}`)} emptyTitle="No runs match" emptyDescription="Start a run from the AI Workspace catalogue, or clear the filters."
        pagination={q.data ? { total: q.data.total, limit, offset, onChange: (o) => setP({ offset: o ? String(o) : null }) } : undefined} />
    </>
  )
}
