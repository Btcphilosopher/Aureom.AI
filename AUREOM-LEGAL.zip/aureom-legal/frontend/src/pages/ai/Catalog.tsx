import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Eye, GitPullRequestArrow, ShieldCheck } from 'lucide-react'
import { Badge, Button, Card, Dialog, PageHeader, QueryBoundary } from '@/components/ui'
import { useAuth } from '@/lib/auth'
import { usePageTitle, useNewParam } from '@/hooks'
import { humanise } from '@/lib/format'
import type { AgentCatalogItem } from '@/types/ai'
import { ACTION_LABEL, AGENT_BLURB, AGENT_ICON, useCatalog } from './common'
import { StartRunDialog } from './StartRunDialog'

export function PrincipleStrip() {
  const items = ['Operates within your permissions', 'Cites its evidence', 'Separates facts / inferences / recommendations', 'Proposes, never executes', 'You approve']
  return (
    <ul aria-label="How the AI workspace behaves" className="mb-5 flex flex-wrap items-center gap-x-1 gap-y-1 rounded-md border border-brass-200 bg-brass-50 px-4 py-2.5 text-sm text-navy-900">
      <ShieldCheck className="mr-2 h-4 w-4 text-brass-600" aria-hidden />
      {items.map((t, i) => <li key={t} className="flex items-center">{i > 0 && <span className="mx-2 text-brass-600" aria-hidden>•</span>}<span className="font-medium">{t}</span></li>)}
    </ul>
  )
}

export default function Catalog() {
  usePageTitle('AI Workspace')
  const { can } = useAuth()
  const q = useCatalog()
  const [agent, setAgent] = useState<AgentCatalogItem | null>(null)
  const nw = useNewParam()
  const [picking, setPicking] = useState(false)
  useEffect(() => { if (nw.isNew) setPicking(true) }, [nw.isNew])
  const catalog = q.data
  return (
    <>
      <PageHeader title="AI Workspace" description="Seven controlled agents. They read only what you may read, cite what they rely on, and propose changes that you review and approve."
        actions={<><Link to="/ai/runs?status=awaiting_review"><Button variant="secondary">Runs awaiting review</Button></Link><Link to="/ai/runs"><Button variant="secondary">All runs</Button></Link></>} />
      <PrincipleStrip />
      {!can('ai.use') ? <Card><p className="text-sm text-stone-700">Your role cannot start AI runs (it lacks <code>ai.use</code>). You can still read the knowledge base and usage policy if permitted.</p></Card> : (
        <QueryBoundary query={q} what="AI catalogue">{(c) => (
          <>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {c.agents.map((a) => {
                const Icon = AGENT_ICON[a.key]
                return (
                  <Card key={a.key} className="flex flex-col" bodyClassName="flex flex-1 flex-col">
                    <div className="mb-2 flex items-start justify-between gap-3">
                      <h2 className="flex items-center gap-2 font-serif text-lg text-navy-900">{Icon && <Icon className="h-5 w-5 text-brass-600" aria-hidden />}{a.name}</h2>
                      {a.read_only ? <Badge tone="success"><Eye className="h-3 w-3" aria-hidden />Read-only</Badge> : <Badge tone="brass"><GitPullRequestArrow className="h-3 w-3" aria-hidden />Proposes changes</Badge>}
                    </div>
                    <p className="text-sm text-stone-700">{AGENT_BLURB[a.key] ?? a.description}</p>
                    <dl className="mt-3 space-y-2 text-xs text-stone-700">
                      <div><dt className="font-semibold text-navy-900">Retrieves</dt><dd>{a.retrieves.join(' · ')}</dd></div>
                      <div><dt className="font-semibold text-navy-900">{a.read_only ? 'Output' : 'May propose (you approve each)'}</dt>
                        <dd>{a.read_only ? 'Cited briefing / results only; nothing to approve.' : a.proposes_actions.map((x) => ACTION_LABEL[x] ?? humanise(x)).join(' · ')}</dd></div>
                      <div><dt className="font-semibold text-navy-900">Needs a matter</dt><dd>{a.requires_matter ? 'Yes — a matter you can access that permits AI' : 'No'}</dd></div>
                    </dl>
                    <div className="mt-auto flex items-center justify-between pt-4"><span className="text-2xs text-stone-500">Prompt template {a.prompt_template_version}</span><Button size="sm" onClick={() => setAgent(a)}>Start run…</Button></div>
                  </Card>)
              })}
            </div>
            <Card className="mt-5" title="Prohibited for every agent" description="Enforced by the policy layer and again at execution time. Any attempt is denied and audited.">
              <p className="flex flex-wrap gap-1.5">{c.prohibited_tools.map((t) => <Badge key={t} tone="danger">{t.replace(/_/g, ' ')}</Badge>)}</p>
              <p className="mt-3 text-xs text-stone-600">{c.notice}</p>
            </Card>
          </>)}</QueryBoundary>)}
      <Dialog open={picking && !!catalog} onClose={() => { setPicking(false); nw.clear() }} title="Choose an agent" description="Each run uses your permissions and ends with results you review.">
        <ul className="grid gap-2">{(catalog?.agents ?? []).map((a) => { const Icon = AGENT_ICON[a.key]; return (
          <li key={a.key}><button type="button" className="flex w-full items-start gap-3 rounded-md border border-stone-200 px-3 py-2.5 text-left hover:border-brass-500 hover:bg-brass-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500"
            onClick={() => { setPicking(false); nw.clear(); setAgent(a) }}>{Icon && <Icon className="mt-0.5 h-4 w-4 shrink-0 text-brass-600" aria-hidden />}<span><span className="block text-sm font-semibold text-navy-900">{a.name}</span><span className="block text-xs text-stone-600">{AGENT_BLURB[a.key]}</span></span></button></li>) })}</ul>
      </Dialog>
      <StartRunDialog agent={agent} open={!!agent} onClose={() => setAgent(null)} />
    </>
  )
}
