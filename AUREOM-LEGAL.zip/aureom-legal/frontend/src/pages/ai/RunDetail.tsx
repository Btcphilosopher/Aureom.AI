import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Ban, Check, RotateCcw, X } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, DateTime, KeyValue, PageHeader, QueryBoundary, StatusStepper, Timeline, type TimelineItem } from '@/components/ui'
import { usePageTitle } from '@/hooks'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import type { RunDetail as Run, RunEvent } from '@/types/ai'
import { ActionCard, type Decision } from './ActionCard'
import { ACTIVE_STATES, AGENT_ICON, ProviderBadge, RUN_STATES, RunStatus } from './common'
import { ResultView } from './ResultView'

const EVENT_TONE: Record<string, TimelineItem['tone']> = { policy_denied: 'danger', injection_flag: 'warning', human_edit: 'brass', human_decision: 'info', execution: 'success', state_change: 'neutral', retrieval: 'neutral', tool_call: 'neutral', budget: 'warning' }

function detailLine(e: RunEvent): string | undefined {
  const parts = Object.entries(e.details ?? {}).filter(([, v]) => v !== null && v !== undefined && (typeof v === 'number' || typeof v === 'boolean' || (typeof v === 'string' && v.length <= 60)))
    .map(([k, v]) => `${humanise(k)}: ${typeof v === 'string' && /^[0-9a-f]{64}$/.test(v) ? v.slice(0, 12) : String(v)}`)
  return parts.length ? parts.slice(0, 6).join(' · ') : undefined
}

export default function RunDetailPage() {
  const { id } = useParams()
  const q = useApiQuery<Run>(['ai', 'run', id], `/agents/runs/${id}`, { refetchInterval: (query) => (ACTIVE_STATES.has((query.state.data as Run | undefined)?.status ?? '') ? 2000 : false) })
  return <QueryBoundary query={q} what="AI run">{(run) => <RunView run={run} />}</QueryBoundary>
}

function RunView({ run }: { run: Run }) {
  usePageTitle(`${run.agent_name} run`)
  useBreadcrumbs([{ label: 'AI Workspace', to: '/ai' }, { label: 'Runs', to: '/ai/runs' }, { label: `${run.agent_name} ${run.id.slice(0, 8)}` }])
  const { can, me } = useAuth()
  const Icon = AGENT_ICON[run.agent_type]
  const inline = me?.environment !== 'production'
  const [decisions, setDecisions] = useState<Record<string, Decision>>({})
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [cancelOpen, setCancelOpen] = useState(false)
  const keys = [['ai', 'run', run.id], ['ai', 'runs']] as never[]
  const review = useApiMutation((execute: boolean) => api.post<Run>(`/agents/runs/${run.id}/review`, {
    execute, decisions: Object.entries(decisions).map(([action_id, d]) => ({ action_id, decision: d.decision, note: d.note || null })) }),
    { invalidate: keys, successMessage: 'Decisions recorded', onSuccess: () => { setDecisions({}); setSelected(new Set()) } })
  const edit = useApiMutation(({ aid, params, version }: { aid: string; params: Record<string, unknown>; version: number }) => api.patch<Run>(`/agents/runs/${run.id}/actions/${aid}`, { params, expected_version: version }),
    { invalidate: keys, successMessage: 'Correction saved — approval must be given for the new content' })
  const cancel = useApiMutation(() => api.post<Run>(`/agents/runs/${run.id}/cancel`), { invalidate: keys, successMessage: 'Run cancelled', onSuccess: () => setCancelOpen(false) })
  const retry = useApiMutation(() => api.post<Run>(`/agents/runs/${run.id}/retry${inline ? '?sync=true' : ''}`), { invalidate: keys, successMessage: 'Run retried' })

  const canReview = can('ai.review')
  const pending = run.actions.filter((a) => a.status === 'proposed')
  const decided = Object.keys(decisions).length
  const awaiting = run.status === 'awaiting_review'
  const done = ['completed', 'rejected', 'failed', 'cancelled'].includes(run.status)

  const setAll = (d: 'approve' | 'reject', onlySelected: boolean) => {
    const ids = (onlySelected ? pending.filter((a) => selected.has(a.id)) : pending).map((a) => a.id)
    setDecisions((cur) => ({ ...cur, ...Object.fromEntries(ids.map((i) => [i, { decision: d, note: cur[i]?.note ?? '' }])) }))
  }
  const events = useMemo<TimelineItem[]>(() => run.events.map((e) => ({ id: e.id, title: e.summary, tone: EVENT_TONE[e.kind] ?? 'neutral', time: <DateTime value={e.created_at} mode="datetime" />,
    meta: <>{humanise(e.kind)}{e.actor_name ? ` · ${e.actor_name}` : ''}</>, description: detailLine(e) })), [run.events])
  const executionBlocked = run.actions.some((a) => a.status === 'failed')

  return (
    <>
      <PageHeader eyebrow={<span className="tabular-nums">Run {run.id.slice(0, 8)}</span>} title={<span className="flex items-center gap-2">{Icon && <Icon className="h-6 w-6 text-brass-600" aria-hidden />}{run.agent_name}</span>}
        meta={<span className="flex flex-wrap items-center gap-2 text-sm"><RunStatus status={run.status} /><ProviderBadge provider={run.provider} />
          {run.matter_reference && <Link to={`/matters/${run.matter_id}`} className="tabular-nums underline">{run.matter_reference}</Link>}<span className="text-stone-600">Requested by {run.requested_by_name ?? '—'}</span></span>}
        actions={<>
          {['queued', 'running', 'awaiting_review'].includes(run.status) && <Button variant="secondary" onClick={() => setCancelOpen(true)}><Ban className="h-4 w-4" aria-hidden />Cancel run</Button>}
          {run.status === 'failed' && run.attempts < run.max_attempts && <Button variant="secondary" loading={retry.isPending} onClick={() => retry.mutate()}><RotateCcw className="h-4 w-4" aria-hidden />Retry ({run.attempts}/{run.max_attempts} used)</Button>}
        </>} />

      {run.provider_notice && <p role="note" className="mb-4 rounded-md border border-dashed border-sim-600/60 bg-sim-50 px-3.5 py-2 text-sm text-sim-700"><strong>SIMULATED / DEMONSTRATION.</strong> {run.provider_notice} Nothing left the application.</p>}

      <div className="mb-5 rounded-lg border border-stone-200 bg-white px-5 py-3 shadow-panel">
        {['rejected', 'failed', 'cancelled'].includes(run.status)
          ? <p className="flex items-center gap-2 text-sm"><RunStatus status={run.status} />{run.status === 'failed' && run.error && <span className="text-bad-700">{run.error}</span>}{run.status === 'rejected' && <span className="text-stone-700">All proposed actions were rejected; nothing was changed.</span>}</p>
          : <StatusStepper steps={RUN_STATES} current={run.status} />}
      </div>

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="min-w-0 space-y-5">
          {ACTIVE_STATES.has(run.status) && run.status !== 'executing' ? <Card><p role="status" aria-live="polite" className="text-sm text-stone-700">This run is {humanise(run.status).toLowerCase()}. The page updates automatically.</p></Card>
            : run.status === 'executing' ? <Card><p role="status" aria-live="polite" className="text-sm text-stone-700">Approved actions are being applied. The page updates automatically.</p></Card> : null}

          {run.result && <ResultView result={run.result} />}
          {!run.result && !ACTIVE_STATES.has(run.status) && <Card><p className="text-sm text-stone-600">This run produced no result{run.error ? `: ${run.error}` : '.'}</p></Card>}

          {run.actions.length > 0 && (
            <section aria-label="Proposed actions">
              <div className="mb-2 flex flex-wrap items-end justify-between gap-3">
                <div><h2 className="font-serif text-xl text-navy-900">Proposed actions</h2>
                  <p className="text-sm text-stone-600">The agent proposed these; <strong>nothing has been applied</strong> until you approve. Each approval is bound to the exact content shown.</p></div>
                {awaiting && canReview && pending.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2">
                    <Button size="sm" variant="secondary" disabled={selected.size === 0} onClick={() => setAll('approve', true)}><Check className="h-3.5 w-3.5" aria-hidden />Approve selected</Button>
                    <Button size="sm" variant="secondary" onClick={() => { setAll('reject', false) }}><X className="h-3.5 w-3.5" aria-hidden />Reject all</Button>
                  </div>)}
              </div>
              {awaiting && !canReview && <p className="mb-2 rounded border border-stone-200 bg-ivory-100 px-3 py-2 text-sm text-stone-700">You can read this run, but approving needs the <code>ai.review</code> permission.</p>}
              <ul className="space-y-4">
                {run.actions.map((a) => (
                  <ActionCard key={`${a.id}:${a.version}`} run={run} action={a} canReview={canReview} decision={decisions[a.id]} selected={selected.has(a.id)}
                    onSelect={(v) => setSelected((s) => { const n = new Set(s); if (v) n.add(a.id); else n.delete(a.id); return n })}
                    onDecide={(d) => setDecisions((cur) => { const n = { ...cur }; if (d) n[a.id] = d; else delete n[a.id]; return n })}
                    saving={edit.isPending} onSaveEdit={(params) => edit.mutate({ aid: a.id, params, version: a.version })} />))}
              </ul>
              {awaiting && canReview && decided > 0 && (
                <div className="sticky bottom-3 mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-brass-300 bg-white px-4 py-3 shadow-pop">
                  <p className="text-sm text-navy-900"><strong>{decided}</strong> of {pending.length} decision(s) ready — {Object.values(decisions).filter((d) => d.decision === 'approve').length} approve, {Object.values(decisions).filter((d) => d.decision === 'reject').length} reject. Undecided actions stay pending.</p>
                  <div className="flex gap-2"><Button variant="secondary" onClick={() => setDecisions({})}>Clear</Button><Button loading={review.isPending} onClick={() => review.mutate(inline)}>Submit decisions</Button></div>
                </div>)}
              {run.status === 'approved' && <p role="status" className="mt-3 text-sm text-stone-700">Approved. {inline ? 'Applying…' : 'Waiting for the background worker to apply the approved actions.'}</p>}
            </section>)}

          {awaiting && run.actions.length === 0 && canReview && (
            <Card title="Nothing proposed" description="Policy asked for a human to look at this result."><Button loading={review.isPending} onClick={() => review.mutate(false)}>Acknowledge and complete</Button></Card>)}

          {executionBlocked && <p role="note" className="rounded-md border border-bad-100 bg-bad-50 px-3.5 py-2.5 text-sm text-bad-700">One or more approved actions were not applied. Permissions are re-checked at execution time, so an action fails if the approver no longer holds the required permission or matter access.</p>}
          {run.execution_result && done && <Card title="Execution result"><pre className="overflow-x-auto rounded bg-stone-100 p-3 text-xs text-stone-700">{JSON.stringify(run.execution_result, null, 2)}</pre></Card>}
        </div>

        <aside className="space-y-5" aria-label="Run details">
          <Card title="Run record">
            <KeyValue items={[
              { label: 'Run ID', value: <code className="break-all text-xs">{run.id}</code> },
              { label: 'Requested by', value: run.requested_by_name ?? '—' },
              { label: 'Matter scope', value: run.matter_reference ? <Link to={`/matters/${run.matter_id}`} className="underline">{run.matter_reference}</Link> : 'None (firm knowledge / contact)' },
              { label: 'Provider · model', value: <span className="flex flex-wrap items-center gap-1.5"><ProviderBadge provider={run.provider} />{run.model}</span> },
              { label: 'Prompt template version', value: <span className="tabular-nums">{run.prompt_template_version}</span> },
              { label: 'Approval state', value: <Badge tone={run.approval_state === 'approved' ? 'success' : run.approval_state === 'rejected' ? 'danger' : run.approval_state === 'pending' ? 'warning' : 'neutral'}>{humanise(run.approval_state)}</Badge> },
              { label: 'Cost · tokens', value: <span className="tabular-nums">£{run.cost_gbp} · {run.tokens_in} in / {run.tokens_out} out</span> },
              { label: 'Attempts', value: `${run.attempts} of ${run.max_attempts} (timeout ${run.timeout_seconds}s)` },
              { label: 'Created', value: <DateTime value={run.created_at} /> }, { label: 'Started', value: <DateTime value={run.started_at} /> }, { label: 'Finished', value: <DateTime value={run.finished_at} /> },
              { label: 'Reviewed', value: run.reviewed_at ? <span><DateTime value={run.reviewed_at} /> by {run.reviewed_by_name}</span> : '—' },
            ]} />
          </Card>
          <Card title="Source versions" description="Exactly what this run read.">
            {run.source_versions.length === 0 ? <p className="text-sm text-stone-600">No documents were read.</p> : (
              <ul className="space-y-1.5 text-sm">{run.source_versions.map((s, i) => (
                <li key={i} className="flex items-center justify-between gap-2"><span className="truncate">{s.type === 'document' && s.id ? <Link to={`/documents/${s.id}`} className="underline">{s.title ?? 'Document'}</Link> : (s.title ?? humanise(s.type))}</span>
                  {s.version_no != null ? <Badge tone="info">v{s.version_no}</Badge> : <Badge>{humanise(s.type)}</Badge>}</li>))}</ul>)}
          </Card>
          <Card title="Activity & evidence log" description="Retrievals, tool calls, policy decisions and human actions.">
            {events.length ? <Timeline items={events} /> : <p className="text-sm text-stone-600">No events yet.</p>}
            <p className="mt-3 text-2xs text-stone-500">No model reasoning is stored. Events record ids, counts, tool calls, policy decisions and human actions only; document text is never logged.</p>
          </Card>
        </aside>
      </div>
      <ConfirmDialog open={cancelOpen} onClose={() => setCancelOpen(false)} title="Cancel this run?" description="Nothing proposed by the run will be applied." confirmLabel="Cancel run" tone="danger" loading={cancel.isPending} onConfirm={() => cancel.mutate()} />
    </>
  )
}
