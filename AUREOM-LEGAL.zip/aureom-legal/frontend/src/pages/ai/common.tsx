import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { Bot, ClipboardCheck, FileSearch, FileText, GitBranch, Lightbulb, PenLine, Receipt, UserPlus, type LucideIcon } from 'lucide-react'
import { Badge, CitationChip, StatusBadge } from '@/components/ui'
import { useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { AgentCatalog, AgentCitation } from '@/types/ai'
import type { MatterListItem } from '@/types/matters'

export const AGENT_ICON: Record<string, LucideIcon> = {
  matter_briefing: ClipboardCheck, document_review: FileSearch, chronology: GitBranch, drafting: PenLine, knowledge: Lightbulb, intake: UserPlus, billing_assistant: Receipt,
}
export const AGENT_BLURB: Record<string, string> = {
  matter_briefing: 'A cited summary of where the matter stands: stage, outstanding tasks, deadlines and what information is missing.',
  document_review: 'Extracts parties, dates, obligations and clauses with document version and page/paragraph references; may propose tasks and deadline suggestions.',
  chronology: 'Builds an editable timeline from documents and correspondence, marking explicit dates apart from inferred ones.',
  drafting: 'Prepares an editable client message, attendance-note summary or document draft from approved templates. Never sends anything.',
  knowledge: 'Searches approved internal precedents and practice notes and shows their sources and dates. Does not invent authorities.',
  intake: 'Suggests structured contact fields and lists missing onboarding information from a submitted form.',
  billing_assistant: 'Suggests time narratives from recorded activity and flags missing information. It never invents work or minutes.',
}
export const ACTION_LABEL: Record<string, string> = {
  create_task: 'Create task', suggest_deadline: 'Suggest deadline (unconfirmed)', add_chronology_entries: 'Add chronology entries', create_correspondence_draft: 'Save correspondence draft (not sent)',
  create_document_draft: 'Save document draft', create_time_entry: 'Create draft time entry', update_time_narrative: 'Update time narrative', update_contact_fields: 'Update contact fields',
}
export const RUN_STATES = [
  { key: 'queued', label: 'Queued' }, { key: 'running', label: 'Running' }, { key: 'awaiting_review', label: 'Awaiting review' },
  { key: 'approved', label: 'Approved' }, { key: 'executing', label: 'Executing' }, { key: 'completed', label: 'Completed' },
]
export const ACTIVE_STATES = new Set(['queued', 'running', 'executing'])
export const STATUS_FILTERS = ['queued', 'running', 'awaiting_review', 'approved', 'rejected', 'executing', 'completed', 'failed', 'cancelled']

export function agentName(key: string, catalog?: AgentCatalog | null): string {
  return catalog?.agents.find((a) => a.key === key)?.name ?? humanise(key)
}

export function ProviderBadge({ provider }: { provider: string }) {
  return provider === 'mock' ? <Badge tone="simulated">Mock provider</Badge> : <Badge tone="info">{provider}</Badge>
}
export function RunStatus({ status }: { status: string }) {
  return <StatusBadge status={status} label={status === 'awaiting_review' ? 'Awaiting review' : undefined} />
}

/** Citation chip for any evidence: documents link to the document; knowledge/user input render as plain labels. */
export function Cite({ c }: { c: AgentCitation }) {
  if (c.invalid) return <Badge tone="danger">Unverified reference withheld</Badge>
  if (c.source_type === 'document_chunk' || c.document_id) {
    const chip = <CitationChip documentTitle={c.title ?? 'Document'} versionNo={c.version_no} page={c.page} paragraph={c.paragraph} quote={c.quote} />
    return c.document_id ? <Link to={`/documents/${c.document_id}`} className="rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">{chip}</Link> : chip
  }
  const label = c.source_type === 'knowledge' ? `Knowledge: ${c.title ?? c.source_id}` : c.source_type === 'user_input' ? `Your input: ${c.title ?? ''}` : `${humanise(c.source_type)}: ${c.title ?? c.source_id.slice(0, 8)}`
  const dates = [c.meta?.effective_date && `effective ${c.meta.effective_date}`, c.meta?.last_reviewed && `reviewed ${c.meta.last_reviewed}`, c.meta?.retrieved_at && `retrieved ${c.meta.retrieved_at}`].filter(Boolean).join(' · ')
  return <span title={c.quote ?? undefined} className="inline-flex items-center gap-1 rounded border border-stone-300 bg-white px-1.5 py-0.5 text-xs text-navy-800"><FileText className="h-3 w-3 text-stone-500" aria-hidden />{label}{dates && <span className="text-stone-600">· {dates}</span>}</span>
}

export function useCatalog() {
  return useApiQuery<AgentCatalog>(['ai', 'catalog'], '/agents', { staleTime: 5 * 60_000 })
}

export function useMatterOptions(enabled = true) {
  const q = useApiQuery<Page<MatterListItem>>(['ai', 'matter-options'], '/matters?limit=200&status=open', { enabled, staleTime: 60_000 })
  return useMemo(() => (q.data?.items ?? []).map((m) => ({ id: m.id, label: `${m.reference} · ${m.title}`, ai: true })), [q.data])
}

export const AI_ICON = Bot
