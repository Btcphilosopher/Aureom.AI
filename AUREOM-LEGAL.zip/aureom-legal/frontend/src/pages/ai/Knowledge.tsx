import { useState } from 'react'
import { BookOpen, Plus, Search } from 'lucide-react'
import { Badge, Button, Card, DataTable, DateTime, Dialog, Drawer, Field, IntegrationUnavailable, Input, PageHeader, Select, StatusBadge, Textarea, type Column } from '@/components/ui'
import { useDebounce, usePageTitle } from '@/hooks'
import { api, qs, useApiMutation, useApiQuery, type ApiError } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { KnowledgeItem, KnowledgeSearch } from '@/types/ai'

const KINDS = ['precedent', 'practice_note', 'policy', 'checklist']
const AREAS = ['commercial', 'property', 'litigation', 'employment', 'private_client', 'corporate']

function ItemDrawer({ id, onClose }: { id: string | null; onClose: () => void }) {
  const q = useApiQuery<KnowledgeItem>(['ai', 'knowledge', id], `/knowledge/${id}`, { enabled: !!id })
  const k = q.data
  return (
    <Drawer open={!!id} onClose={onClose} title={k?.title ?? 'Knowledge item'} width="max-w-2xl">
      {q.isPending ? <p className="text-sm text-stone-600">Loading…</p> : q.isError ? <p className="text-sm text-bad-700">{q.error.message}</p> : k && (
        <div className="space-y-4">
          <p className="flex flex-wrap gap-2"><Badge tone={k.approved ? 'success' : 'warning'}>{k.approved ? 'Approved for AI use' : 'Not approved — excluded from AI use'}</Badge><Badge>{humanise(k.kind)}</Badge>{k.practice_area && <Badge tone="info">{humanise(k.practice_area)}</Badge>}</p>
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div><dt className="text-2xs font-semibold uppercase text-stone-600">Source reference</dt><dd>{k.source_ref ?? '—'}</dd></div>
            <div><dt className="text-2xs font-semibold uppercase text-stone-600">Effective date</dt><dd><DateTime value={k.effective_date} mode="date" /></dd></div>
            <div><dt className="text-2xs font-semibold uppercase text-stone-600">Last reviewed</dt><dd>{k.last_reviewed ? <DateTime value={k.last_reviewed} mode="date" /> : 'Not recorded'}</dd></div>
          </dl>
          <div className="whitespace-pre-wrap rounded border border-stone-200 bg-ivory-50 p-3 text-sm text-navy-950">{k.body}</div>
          <p className="text-xs text-stone-600">Internal practice material. Check the dates above; this is not legal authority.</p>
        </div>)}
    </Drawer>
  )
}

function Editor({ item, open, onClose }: { item: KnowledgeItem | null; open: boolean; onClose: () => void }) {
  const full = useApiQuery<KnowledgeItem>(['ai', 'knowledge', item?.id], `/knowledge/${item?.id}`, { enabled: open && !!item })
  const [f, setF] = useState({ title: '', kind: 'precedent', practice_area: '', body: '', source_ref: '', effective_date: new Date().toISOString().slice(0, 10), last_reviewed: '' })
  const [loadedFor, setLoadedFor] = useState<string | null>(null)
  const [err, setErr] = useState<ApiError | null>(null)
  if (open && item && full.data && loadedFor !== full.data.id + full.data.updated_at) {
    const k = full.data
    setLoadedFor(k.id + k.updated_at)
    setF({ title: k.title, kind: k.kind, practice_area: k.practice_area ?? '', body: k.body ?? '', source_ref: k.source_ref ?? '', effective_date: k.effective_date.slice(0, 10), last_reviewed: k.last_reviewed?.slice(0, 10) ?? '' })
  }
  if (open && !item && loadedFor) { setLoadedFor(null); setF({ title: '', kind: 'precedent', practice_area: '', body: '', source_ref: '', effective_date: new Date().toISOString().slice(0, 10), last_reviewed: '' }) }
  const save = useApiMutation(() => {
    const body = { ...f, practice_area: f.practice_area || null, source_ref: f.source_ref || null, last_reviewed: f.last_reviewed || null }
    return item ? api.patch<KnowledgeItem>(`/knowledge/${item.id}`, body) : api.post<KnowledgeItem>('/knowledge', body)
  }, { errorToast: false, invalidate: [['ai', 'knowledge']], successMessage: item ? 'Saved — changing an approved item withdraws its approval' : 'Created as unapproved', onSuccess: () => onClose(), onError: (e) => setErr(e) })
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }))
  return (
    <Dialog open={open} onClose={onClose} size="lg" title={item ? 'Edit knowledge item' : 'New knowledge item'} description="New and edited items are not available to AI agents until a knowledge manager approves them."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={save.isPending} disabled={f.title.length < 3 || !f.body} onClick={() => { setErr(null); save.mutate() }}>Save</Button></>}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Title" required className="sm:col-span-2">{(p) => <Input {...p} value={f.title} onChange={set('title')} />}</Field>
        <Field label="Kind">{(p) => <Select {...p} value={f.kind} onChange={set('kind')}>{KINDS.map((k) => <option key={k} value={k}>{humanise(k)}</option>)}</Select>}</Field>
        <Field label="Practice area">{(p) => <Select {...p} value={f.practice_area} onChange={set('practice_area')}><option value="">All / none</option>{AREAS.map((k) => <option key={k} value={k}>{humanise(k)}</option>)}</Select>}</Field>
        <Field label="Source reference">{(p) => <Input {...p} value={f.source_ref} onChange={set('source_ref')} placeholder="e.g. PCS/PREC/COM/001" />}</Field>
        <Field label="Effective date" required>{(p) => <Input {...p} type="date" value={f.effective_date} onChange={set('effective_date')} />}</Field>
        <Field label="Last reviewed">{(p) => <Input {...p} type="date" value={f.last_reviewed} onChange={set('last_reviewed')} />}</Field>
        <Field label="Content" required className="sm:col-span-2">{(p) => <Textarea {...p} rows={10} value={f.body} onChange={set('body')} />}</Field>
      </div>
      {err && <p role="alert" className="mt-3 text-sm text-bad-700">{err.message}</p>}
    </Dialog>
  )
}

function ExternalResearch() {
  const q = useApiQuery<{ items: { key: string; name: string; mode: string; description: string; data_leaves_application: string; setup_hint?: string }[] }>(['integrations'], '/integrations')
  const lr = q.data?.items.find((i) => i.key === 'legal_research')
  return (
    <Card title="External legal research" description="Case law and statute research must come from an explicitly configured source adapter that states its source and retrieval date.">
      {q.isPending ? <p className="text-sm text-stone-600">Checking…</p> : !lr ? <p className="text-sm text-stone-600">Integration status is unavailable to your role.</p>
        : lr.mode === 'unavailable' ? <IntegrationUnavailable name={lr.name} setupHint={lr.setup_hint} message="No external research source is configured. The knowledge agent will say so rather than guess; it never invents case citations, authorities or quotations." />
          : <div className="text-sm text-stone-700"><Badge tone={lr.mode === 'mock' ? 'simulated' : 'success'}>{lr.mode}</Badge><p className="mt-2">{lr.description}</p><p className="mt-1 text-xs">Results show their source and retrieval date. {lr.data_leaves_application}</p></div>}
    </Card>
  )
}

export default function KnowledgePage() {
  usePageTitle('Knowledge')
  const { can } = useAuth()
  const manage = can('knowledge.manage')
  const [text, setText] = useState('')
  const q = useDebounce(text.trim(), 350)
  const [kind, setKind] = useState('')
  const [area, setArea] = useState('')
  const [view, setView] = useState<string | null>(null)
  const [edit, setEdit] = useState<KnowledgeItem | 'new' | null>(null)
  const [appr, setAppr] = useState('')
  const [offset, setOffset] = useState(0)
  const search = useApiQuery<KnowledgeSearch>(['ai', 'knowledge', 'search', q, kind, area], `/knowledge/search${qs({ q, kind, practice_area: area, limit: 12 })}`, { enabled: q.length >= 2 })
  const list = useApiQuery<Page<KnowledgeItem>>(['ai', 'knowledge', 'list', kind, area, appr, offset], `/knowledge${qs({ kind, practice_area: area, approved: appr, limit: 15, offset })}`)
  const approve = useApiMutation(({ id, approved }: { id: string; approved: boolean }) => api.post(`/knowledge/${id}/approval`, { approved }), { invalidate: [['ai', 'knowledge']], successMessage: 'Updated' })
  const cols: Column<KnowledgeItem>[] = [
    { key: 't', header: 'Title', cell: (k) => <button type="button" className="text-left font-medium text-navy-800 underline decoration-brass-500/60 underline-offset-2" onClick={() => setView(k.id)}>{k.title}</button> },
    { key: 'k', header: 'Kind', cell: (k) => humanise(k.kind), hideOnNarrow: true },
    { key: 'a', header: 'Area', cell: (k) => k.practice_area ? humanise(k.practice_area) : 'All', hideOnNarrow: true },
    { key: 'e', header: 'Effective', cell: (k) => <DateTime value={k.effective_date} mode="date" /> },
    { key: 'r', header: 'Last reviewed', cell: (k) => k.last_reviewed ? <DateTime value={k.last_reviewed} mode="date" /> : <span className="text-warn-700">Not recorded</span>, hideOnNarrow: true },
    { key: 's', header: 'AI use', cell: (k) => k.approved ? <StatusBadge status="approved" label="Approved" /> : <Badge tone="warning">Not approved — excluded</Badge> },
    ...(manage ? [{ key: 'm', header: '', cell: (k: KnowledgeItem) => <span className="flex gap-1.5"><Button size="sm" variant="secondary" onClick={() => setEdit(k)}>Edit</Button>
      <Button size="sm" variant={k.approved ? 'ghost' : 'primary'} loading={approve.isPending && approve.variables?.id === k.id} onClick={() => approve.mutate({ id: k.id, approved: !k.approved })}>{k.approved ? 'Withdraw' : 'Approve'}</Button></span> }] : []),
  ]
  return (
    <>
      <PageHeader title="Knowledge" description="Approved internal precedents and practice materials. The knowledge agent searches only these, and always shows their source and dates."
        actions={manage && <Button onClick={() => setEdit('new')}><Plus className="h-4 w-4" aria-hidden />New item</Button>} />
      <div className="mb-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <Card title="Search approved materials" description="Unapproved items never appear here and are never used by agents.">
          <div className="grid gap-3 sm:grid-cols-[1fr_9rem_10rem]">
            <Field label="Search" hint="e.g. termination notice, restrictive covenant">{(p) => <div className="relative"><Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-stone-500" aria-hidden /><Input {...p} className="pl-8" value={text} onChange={(e) => setText(e.target.value)} /></div>}</Field>
            <Field label="Kind">{(p) => <Select {...p} value={kind} onChange={(e) => { setKind(e.target.value); setOffset(0) }}><option value="">All</option>{KINDS.map((k) => <option key={k} value={k}>{humanise(k)}</option>)}</Select>}</Field>
            <Field label="Practice area">{(p) => <Select {...p} value={area} onChange={(e) => { setArea(e.target.value); setOffset(0) }}><option value="">All</option>{AREAS.map((k) => <option key={k} value={k}>{humanise(k)}</option>)}</Select>}</Field>
          </div>
          {q.length >= 2 && (
            <div className="mt-4" aria-live="polite">
              {search.isPending ? <p className="text-sm text-stone-600">Searching…</p> : search.isError ? <p className="text-sm text-bad-700">{search.error.message}</p> : search.data!.results.length === 0 ? <p className="text-sm text-stone-600">No approved material matches “{q}”. The agent would report this as missing evidence rather than guess.</p> : (
                <ul className="space-y-3">{search.data!.results.map((k) => (
                  <li key={k.id} className="rounded-md border border-stone-200 bg-white px-3.5 py-2.5">
                    <button type="button" onClick={() => setView(k.id)} className="flex items-center gap-1.5 text-left font-serif text-base text-navy-900 underline decoration-brass-500/60 underline-offset-2"><BookOpen className="h-4 w-4 text-brass-600" aria-hidden />{k.title}</button>
                    {k.snippet && <p className="mt-1 text-sm text-stone-700">…{k.snippet}…</p>}
                    <p className="mt-1 text-xs text-stone-600">{humanise(k.kind)} · {k.source_ref ?? 'no reference'} · effective <DateTime value={k.effective_date} mode="date" /> · {k.last_reviewed ? <>reviewed <DateTime value={k.last_reviewed} mode="date" /></> : 'review date not recorded'}</p>
                  </li>))}</ul>)}
              {search.data && <p className="mt-3 text-xs text-stone-500">{search.data.notice}</p>}
            </div>)}
        </Card>
        <ExternalResearch />
      </div>
      <h2 className="mb-2 font-serif text-xl text-navy-900">{manage ? 'All knowledge items' : 'Approved knowledge items'}</h2>
      {manage && <div className="mb-3 max-w-xs"><Field label="Approval status">{(p) => <Select {...p} value={appr} onChange={(e) => { setAppr(e.target.value); setOffset(0) }}><option value="">All</option><option value="true">Approved</option><option value="false">Not approved</option></Select>}</Field></div>}
      <DataTable caption="Knowledge items" columns={cols} rows={list.data?.items ?? []} rowKey={(k) => k.id} loading={list.isPending} error={list.error} onRetry={() => void list.refetch()}
        emptyTitle="No knowledge items" pagination={list.data ? { total: list.data.total, limit: 15, offset, onChange: setOffset } : undefined} />
      <ItemDrawer id={view} onClose={() => setView(null)} />
      <Editor item={edit && edit !== 'new' ? edit : null} open={edit !== null} onClose={() => setEdit(null)} />
    </>
  )
}
