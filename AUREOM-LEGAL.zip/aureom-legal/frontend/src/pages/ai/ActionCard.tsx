import { useState } from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle, Check, Hash, Pencil, X } from 'lucide-react'
import { Badge, Button, Checkbox, Field, Input, Select, StatusBadge, Textarea } from '@/components/ui'
import { cn } from '@/lib/cn'
import { humanise } from '@/lib/format'
import type { ProposedAction, RunDetail } from '@/types/ai'
import { ACTION_LABEL, Cite } from './common'

const READONLY_KEY = /(^|_)(id|ids|hash)$|^source|^evidence$|^template_id$|^thread_id$/
const LONG = /(body|content|description|narrative|summary|passage|instructions)/i

/** Recursive editor for proposed-action parameters. Reference ids stay read-only so a correction can change content, not scope. */
function ParamEditor({ value, onChange, name = '', depth = 0, readOnly = false }: { value: unknown; onChange: (v: unknown) => void; name?: string; depth?: number; readOnly?: boolean }) {
  if (value === null || value === undefined) return <span className="text-xs text-stone-500">—</span>
  if (readOnly && (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean')) return <p className="whitespace-pre-wrap break-words text-sm text-navy-950">{String(value)}</p>
  if (readOnly && Array.isArray(value) && value.every((x) => typeof x === 'string')) return <p className="text-sm text-navy-950">{value.length ? value.join(', ') : '—'}</p>
  if (typeof value === 'boolean') return <Checkbox label={humanise(name)} checked={value} onChange={(e) => onChange(e.target.checked)} />
  if (typeof value === 'number') return <Input type="number" value={String(value)} onChange={(e) => onChange(e.target.value === '' ? 0 : Number(e.target.value))} aria-label={humanise(name)} />
  if (typeof value === 'string') {
    if (name === 'priority') return <Select aria-label="Priority" value={value} onChange={(e) => onChange(e.target.value)}>{['low', 'normal', 'high', 'urgent'].map((x) => <option key={x}>{x}</option>)}</Select>
    if (name === 'due_date' || name === 'event_date' || name === 'work_date') return <Input type="date" value={value.slice(0, 10)} onChange={(e) => onChange(e.target.value)} aria-label={humanise(name)} />
    return value.length > 90 || value.includes('\n') || LONG.test(name) ? <Textarea rows={Math.min(10, Math.max(3, Math.ceil(value.length / 90)))} value={value} onChange={(e) => onChange(e.target.value)} aria-label={humanise(name)} />
      : <Input value={value} onChange={(e) => onChange(e.target.value)} aria-label={humanise(name)} />
  }
  if (Array.isArray(value)) {
    if (value.every((x) => typeof x === 'string')) return <Input value={value.join(', ')} onChange={(e) => onChange(e.target.value.split(',').map((x) => x.trim()).filter(Boolean))} aria-label={`${humanise(name)} (comma separated)`} />
    return (
      <ol className="space-y-3">{value.map((v, i) => (
        <li key={i} className="rounded border border-stone-200 bg-white p-2.5"><ParamEditor readOnly={readOnly} value={v} name={`${name}_${i + 1}`} depth={depth + 1} onChange={(nv) => onChange(value.map((x, j) => (j === i ? nv : x)))} /></li>))}</ol>)
  }
  const obj = value as Record<string, unknown>
  return (
    <dl className={cn('space-y-2', depth > 0 && 'text-sm')}>
      {Object.entries(obj).map(([k, v]) => (
        <div key={k}>
          <dt className="mb-0.5 text-2xs font-semibold uppercase tracking-wide text-stone-600">{humanise(k)}</dt>
          <dd>{READONLY_KEY.test(k) || (typeof v === 'object' && v !== null && !Array.isArray(v) && /source/.test(k))
            ? <code className="block break-all rounded bg-stone-100 px-2 py-1 text-xs text-stone-700">{typeof v === 'string' ? v : JSON.stringify(v)}</code>
            : <ParamEditor readOnly={readOnly} value={v} name={k} depth={depth + 1} onChange={(nv) => onChange({ ...obj, [k]: nv })} />}</dd>
        </div>))}
    </dl>
  )
}

function ResultLink({ a, run }: { a: ProposedAction; run: RunDetail }) {
  const r = a.result
  if (!r) return null
  const t = r.type, id = r.id
  const to = t === 'task' ? `/tasks/${id}` : t === 'deadline' ? `/tasks/deadlines/${id}` : t === 'chronology_entries' ? `/matters/${run.matter_id}?tab=chronology` : t === 'correspondence_draft' ? `/correspondence/${id}`
    : t === 'document_draft' ? `/documents/${id}` : t === 'time_entry' ? '/billing?tab=time' : t === 'contact' ? `/clients/${id}` : null
  const label = t === 'task' ? 'Open the created task' : t === 'deadline' ? 'Open the deadline suggestion (needs human confirmation)' : t === 'chronology_entries' ? `View ${r.ids?.length ?? ''} chronology entries` : t === 'correspondence_draft' ? 'Open the saved draft (not sent)'
    : t === 'document_draft' ? 'Open the saved document draft' : t === 'time_entry' ? 'Open time & billing (draft entry)' : t === 'contact' ? `Open contact (changed: ${(r.fields_changed ?? []).join(', ')})` : 'Result'
  return to ? <Link to={to} className="text-sm font-medium text-navy-800 underline decoration-brass-500/60 underline-offset-2">{label}</Link> : <span className="text-sm">{label}</span>
}

export interface Decision { decision: 'approve' | 'reject'; note: string }

export function ActionCard({ run, action: a, canReview, decision, onDecide, onSaveEdit, saving, selected, onSelect }: {
  run: RunDetail; action: ProposedAction; canReview: boolean; decision?: Decision; onDecide: (d: Decision | null) => void
  onSaveEdit: (params: Record<string, unknown>) => void; saving: boolean; selected: boolean; onSelect: (v: boolean) => void
}) {
  const [draft, setDraft] = useState<Record<string, unknown> | null>(null)
  const [editing, setEditing] = useState(false)
  const reviewable = run.status === 'awaiting_review' && a.status === 'proposed' && canReview
  const dirty = draft !== null && JSON.stringify(draft) !== JSON.stringify(a.params)
  const resetAfterApproval = a.status === 'proposed' && a.edit_history.some((h) => h.was_approved)
  const blockedAtExecution = a.status === 'failed' && !!a.error
  return (
    <li className="rounded-lg border border-stone-300 bg-white shadow-panel">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-200 px-4 py-3">
        <div className="flex items-start gap-3">
          {reviewable && <Checkbox label={<span className="sr-only">Select this action</span>} checked={selected} onChange={(e) => onSelect(e.target.checked)} />}
          <div><h4 className="font-serif text-base text-navy-900">{ACTION_LABEL[a.action_type] ?? humanise(a.action_type)}</h4><p className="text-sm text-stone-700">{a.summary}</p></div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5"><Badge tone={a.risk === 'high' ? 'danger' : a.risk === 'medium' ? 'warning' : 'neutral'}>{a.risk} risk</Badge><StatusBadge status={a.status} /></div>
      </div>
      <div className="space-y-3 px-4 py-3">
        {resetAfterApproval && <p role="status" className="flex items-start gap-2 rounded border border-brass-200 bg-brass-50 px-3 py-2 text-sm text-navy-900"><AlertTriangle className="mt-0.5 h-4 w-4 text-brass-600" aria-hidden />Edited after approval — the earlier approval no longer applies. Renewed approval is required.</p>}
        {a.edit_count > 0 && !resetAfterApproval && <p className="text-xs text-stone-600"><Pencil className="mr-1 inline h-3 w-3" aria-hidden />Edited by a reviewer {a.edit_count} time(s); before/after values are kept in the history.</p>}

        <div>
          <div className="mb-1 flex items-center justify-between"><h5 className="text-2xs font-semibold uppercase tracking-wide text-stone-600">Exactly what will be applied</h5>
            {reviewable && !editing && <Button size="sm" variant="ghost" onClick={() => { setDraft(structuredClone(a.params)); setEditing(true) }}><Pencil className="h-3.5 w-3.5" aria-hidden />Correct before deciding</Button>}</div>
          <div className="rounded border border-stone-200 bg-ivory-50 p-3">
            {editing && draft ? <ParamEditor value={draft} onChange={(v) => setDraft(v as Record<string, unknown>)} /> : <ParamEditor readOnly value={a.params} onChange={() => undefined} />}
            {!editing && <p className="mt-2 text-2xs text-stone-500">Read-only preview of the stored parameters. Use “Correct before deciding” to change them.</p>}
          </div>
          {editing && (
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Button size="sm" disabled={!dirty} loading={saving} onClick={() => { onSaveEdit(draft!); setEditing(false); setDraft(null) }}>Save correction</Button>
              <Button size="sm" variant="secondary" onClick={() => { setEditing(false); setDraft(null) }}>Discard</Button>
              <span className="text-xs text-stone-600">{dirty ? 'Saving changes the content hash, so any approval must be given again.' : 'No changes yet.'}</span>
            </div>)}
        </div>

        <p className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-stone-600">
          <span className="inline-flex items-center gap-1"><Hash className="h-3 w-3" aria-hidden />Content hash <code className="rounded bg-stone-100 px-1 tabular-nums">{a.params_hash.slice(0, 12)}</code></span>
          {a.approved_hash && <span>Approved against <code className="rounded bg-stone-100 px-1 tabular-nums">{a.approved_hash.slice(0, 12)}</code> by {a.approved_by_name ?? 'a reviewer'}</span>}
        </p>

        {a.evidence.length > 0 && <div><h5 className="mb-1 text-2xs font-semibold uppercase tracking-wide text-stone-600">Supporting evidence</h5>
          <div className="space-y-1.5">{a.evidence.map((c, i) => <div key={i}><Cite c={c} />{c.quote && <blockquote className="mt-1 border-l-2 border-brass-500/70 pl-2 text-xs italic text-stone-700">“{c.quote}”</blockquote>}</div>)}</div></div>}

        {a.status === 'executed' && <div className="flex items-center gap-2 rounded border border-ok-100 bg-ok-50 px-3 py-2 text-sm text-ok-700"><Check className="h-4 w-4" aria-hidden />Applied{a.executed_at ? '' : ''}. <ResultLink a={a} run={run} /></div>}
        {blockedAtExecution && <div role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700"><strong>Not applied.</strong> {a.error} <span className="block text-xs">Permissions are checked again at the moment of execution, for the person who approved.</span></div>}
        {a.decision_note && a.status !== 'proposed' && <p className="text-xs text-stone-600">Reviewer note: “{a.decision_note}”</p>}

        {reviewable && (
          <div className="border-t border-stone-200 pt-3">
            <Field label="Decision note (optional)">{(p) => <Input {...p} value={decision?.note ?? ''} onChange={(e) => onDecide({ decision: decision?.decision ?? 'approve', note: e.target.value })} placeholder="Why you are approving or rejecting" />}</Field>
            <div className="mt-2 flex flex-wrap items-center gap-2" role="group" aria-label="Decision">
              <Button size="sm" variant={decision?.decision === 'approve' ? 'primary' : 'secondary'} aria-pressed={decision?.decision === 'approve'} disabled={dirty || editing} onClick={() => onDecide({ decision: 'approve', note: decision?.note ?? '' })}><Check className="h-3.5 w-3.5" aria-hidden />Approve this exact content</Button>
              <Button size="sm" variant={decision?.decision === 'reject' ? 'danger' : 'secondary'} aria-pressed={decision?.decision === 'reject'} onClick={() => onDecide({ decision: 'reject', note: decision?.note ?? '' })}><X className="h-3.5 w-3.5" aria-hidden />Reject</Button>
              {decision && <button type="button" className="text-xs text-stone-600 underline" onClick={() => onDecide(null)}>Clear</button>}
              {(dirty || editing) && <span className="text-xs text-warn-700">Save or discard your correction before approving.</span>}
            </div>
          </div>)}
      </div>
    </li>
  )
}
