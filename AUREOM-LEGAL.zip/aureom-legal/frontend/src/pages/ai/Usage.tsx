import { Ban, Eye, Hash, ShieldCheck } from 'lucide-react'
import { Badge, Card, DataTable, KeyValue, PageHeader, QueryBoundary, SimulatedBanner } from '@/components/ui'
import { usePageTitle } from '@/hooks'
import { useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { AiUsage, ProviderInfo } from '@/types/ai'
import { agentName, useCatalog } from './common'

/** Exact-decimal percentage of budget (strings -> BigInt micro-units; no float money maths). */
function pct(spent: string, budget: string): number {
  const toMicro = (s: string) => { const [i, f = ''] = s.split('.'); return BigInt(i || '0') * 1_000_000n + BigInt((f + '000000').slice(0, 6)) }
  const b = toMicro(budget); if (b <= 0n) return 0
  return Math.min(100, Number((toMicro(spent) * 10000n) / b) / 100)
}

function UsageCard() {
  const q = useApiQuery<AiUsage>(['ai', 'usage'], '/agents/usage')
  const cat = useCatalog()
  return (
    <QueryBoundary query={q} what="AI usage">{(u) => {
      const p = pct(u.spent_gbp, u.monthly_budget_gbp)
      return (
        <Card title="Usage & budgets" description={`Since ${u.period_start}`}>
          <div className="mb-4">
            <div className="flex items-baseline justify-between text-sm"><span className="text-stone-700">Firm spend this month</span><span className="tabular-nums font-semibold text-navy-900">£{u.spent_gbp} of £{u.monthly_budget_gbp}</span></div>
            <div className="mt-1 h-2 overflow-hidden rounded bg-stone-200" role="progressbar" aria-valuenow={Math.round(p)} aria-valuemin={0} aria-valuemax={100} aria-label="Monthly AI budget used"><div className={p > 85 ? 'h-full bg-bad-600' : 'h-full bg-navy-700'} style={{ width: `${p}%` }} /></div>
            <p className="mt-1 text-xs text-stone-600">{u.basis}</p>
          </div>
          <KeyValue columns={2} items={[{ label: 'Per-run budget', value: <span className="tabular-nums">£{u.per_run_budget_gbp}</span> }, { label: 'Your runs today', value: `${u.your_runs_today} of ${u.user_daily_runs_limit}` }]} />
          {u.by_agent.length > 0 && <div className="mt-4"><DataTable caption="Usage by agent" rows={u.by_agent} rowKey={(r) => r.agent_type} columns={[
            { key: 'a', header: 'Agent', cell: (r) => agentName(r.agent_type, cat.data) }, { key: 'n', header: 'Runs', numeric: true, cell: (r) => r.runs }, { key: 'c', header: 'Cost (GBP)', numeric: true, cell: (r) => `£${r.cost_gbp}` }]} /></div>}
        </Card>)
    }}</QueryBoundary>
  )
}

function ProviderCard() {
  const q = useApiQuery<ProviderInfo>(['ai', 'provider'], '/agents/provider')
  const cat = useCatalog()
  return (
    <QueryBoundary query={q} what="AI provider" integration="AI provider">{(p) => (
      <Card title="Provider configuration" description="What is configured, and exactly what would leave the application.">
        {p.integration.mode === 'mock' && <SimulatedBanner className="mb-4">The local mock provider is active: heuristic extraction, no language model, and nothing leaves the application.</SimulatedBanner>}
        <KeyValue columns={2} items={[
          { label: 'Provider', value: <span className="flex items-center gap-1.5">{p.integration.name}<Badge tone={p.integration.mode === 'mock' ? 'simulated' : p.integration.mode === 'live' ? 'success' : 'warning'}>{p.integration.mode}</Badge></span> },
          { label: 'Model', value: p.model ?? '—' }, { label: 'Data residency', value: p.data_residency.toUpperCase() },
          { label: 'Training on matter content', value: <Badge tone="success">Never — disabled</Badge> },
        ]} />
        <p className="mt-3 text-sm text-stone-700">{p.training_note}</p>
        <h3 className="mt-5 text-sm font-semibold text-navy-900">What would leave the application if a live provider is used</h3>
        <p className="mt-1 text-sm text-stone-700">{p.integration.data_leaves_application}</p>
        <div className="mt-3 grid gap-4 md:grid-cols-2">
          <div><h4 className="mb-1 text-2xs font-semibold uppercase tracking-wide text-stone-600">Content classes sent, by agent</h4>
            <ul className="space-y-1.5 text-sm">{Object.entries(p.egress_by_agent).map(([k, v]) => <li key={k}><strong className="text-navy-900">{agentName(k, cat.data)}:</strong> <span className="text-stone-700">{v.join(', ')}</span></li>)}</ul></div>
          <div><h4 className="mb-1 text-2xs font-semibold uppercase tracking-wide text-stone-600">Never sent</h4><ul className="list-disc space-y-1 pl-5 text-sm text-stone-700">{p.never_sent.map((n) => <li key={n}>{n}</li>)}</ul></div>
        </div>
        <p className="mt-4 text-xs text-stone-600">{p.logging}</p>
        {p.integration.setup_hint && <p className="mt-2 text-xs text-stone-600"><strong>To change provider:</strong> {p.integration.setup_hint}</p>}
        <h3 className="mt-5 text-sm font-semibold text-navy-900">Policy settings</h3>
        <KeyValue columns={3} items={[
          { label: 'AI enabled', value: p.settings.enabled ? 'Yes' : 'No' }, { label: 'Read-only runs finish without review', value: p.settings.auto_complete_readonly ? 'Yes' : 'No' },
          { label: 'Daily runs per user', value: p.settings.user_daily_runs }, { label: 'Monthly budget', value: <span className="tabular-nums">£{p.settings.monthly_budget_gbp}</span> }, { label: 'Per-run budget', value: <span className="tabular-nums">£{p.settings.per_run_budget_gbp}</span> },
          { label: 'Enabled agents', value: p.settings.allowed_agents.map((a) => agentName(a, cat.data)).join(', ') },
        ]} />
      </Card>)}</QueryBoundary>
  )
}

export default function UsagePage() {
  usePageTitle('AI usage & controls')
  const cat = useCatalog()
  return (
    <>
      <PageHeader title="Usage & controls" description="Budgets, provider configuration and the policy that governs every agent." />
      <div className="space-y-5">
        <ProviderCard />
        <UsageCard />
        <Card title="Policy summary" description="Applied by the application, not by the model. Enforced again when each tool or action executes.">
          <ul className="grid gap-3 md:grid-cols-3">
            <li className="rounded border border-stone-200 p-3 text-sm"><Eye className="mb-1 h-4 w-4 text-navy-700" aria-hidden /><strong className="block text-navy-900">Read-only by default</strong>Agents get a narrow allowlist of read tools and may only <em>propose</em> changes.</li>
            <li className="rounded border border-stone-200 p-3 text-sm"><Hash className="mb-1 h-4 w-4 text-navy-700" aria-hidden /><strong className="block text-navy-900">Approval binds to exact content</strong>Editing a proposal after approval clears the approval; a hash mismatch refuses execution; each action runs once.</li>
            <li className="rounded border border-stone-200 p-3 text-sm"><ShieldCheck className="mb-1 h-4 w-4 text-navy-700" aria-hidden /><strong className="block text-navy-900">Your permissions, your matters</strong>Restricted matters, ethical walls and “no AI” matters are never retrieved. Retrieved text is treated as data, never instructions.</li>
          </ul>
          <h3 className="mb-1.5 mt-4 flex items-center gap-1.5 text-sm font-semibold text-navy-900"><Ban className="h-4 w-4 text-bad-600" aria-hidden />Prohibited for every agent</h3>
          <p className="flex flex-wrap gap-1.5">{(cat.data?.prohibited_tools ?? []).map((t) => <Badge key={t} tone="danger">{humanise(t)}</Badge>)}</p>
        </Card>
      </div>
    </>
  )
}
