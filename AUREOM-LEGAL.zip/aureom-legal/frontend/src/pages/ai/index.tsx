import { NavLink, Route, Routes } from 'react-router-dom'
import { NotFoundState } from '@/components/ui'
import { cn } from '@/lib/cn'
import { useAuth } from '@/lib/auth'
import Catalog from './Catalog'
import Knowledge from './Knowledge'
import RunDetail from './RunDetail'
import RunsList from './RunsList'
import Usage from './Usage'

function SubNav() {
  const { can } = useAuth()
  const items = [{ to: '/ai', label: 'Agents', end: true }, { to: '/ai/runs', label: 'Runs' }, { to: '/ai/knowledge', label: 'Knowledge' }, { to: '/ai/usage', label: 'Usage & controls' }]
  return (
    <nav aria-label="AI workspace" className="mb-5 flex gap-1 border-b border-stone-300">
      {items.filter((i) => i.to !== '/ai/runs' || can('ai.use')).map((i) => (
        <NavLink key={i.to} to={i.to} end={i.end} className={({ isActive }) => cn('-mb-px border-b-2 px-3 py-2 text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500', isActive ? 'border-brass-500 text-navy-900' : 'border-transparent text-stone-600 hover:text-navy-900')}>{i.label}</NavLink>))}
    </nav>
  )
}

export default function AiSection() {
  return (
    <>
      <SubNav />
      <Routes>
        <Route index element={<Catalog />} />
        <Route path="runs" element={<RunsList />} />
        <Route path="runs/:id" element={<RunDetail />} />
        <Route path="knowledge" element={<Knowledge />} />
        <Route path="usage" element={<Usage />} />
        <Route path="*" element={<NotFoundState what="page" />} />
      </Routes>
    </>
  )
}
