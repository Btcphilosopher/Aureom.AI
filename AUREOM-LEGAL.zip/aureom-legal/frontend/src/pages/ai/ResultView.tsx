import type { ReactNode } from 'react'
import { AlertTriangle, ListChecks, Lightbulb, Quote, ScanSearch, ShieldAlert, SearchX } from 'lucide-react'
import { Badge, Card } from '@/components/ui'
import type { AgentCitation, AgentResult, ResultItem, ResultWarning } from '@/types/ai'
import { Cite } from './common'

function Quoted({ c }: { c: AgentCitation }) {
  if (!c.quote) return null
  return <blockquote className="mt-1 border-l-2 border-brass-500/70 pl-2 text-xs italic text-stone-700"><Quote className="mr-1 inline h-3 w-3 text-brass-600" aria-hidden />“{c.quote}”</blockquote>
}

function ItemList({ items, tone }: { items: ResultItem[]; tone: 'fact' | 'inference' }) {
  return (
    <ul className="space-y-3">
      {items.map((it, i) => (
        <li key={i} className={tone === 'fact' ? 'rounded-md border border-stone-200 border-l-4 border-l-navy-700 bg-white px-3.5 py-2.5' : 'rounded-md border border-dashed border-warn-100 bg-warn-50/60 px-3.5 py-2.5'}>
          <p className="text-sm text-navy-950">{tone === 'inference' && <Badge tone="warning" className="mr-2">inferred — check</Badge>}{it.statement}
            {it.confidence && <span className="ml-2 text-2xs uppercase tracking-wide text-stone-500">confidence: {it.confidence}</span>}</p>
          {it.citations.length > 0 ? (
            <div className="mt-2 space-y-1.5">{it.citations.map((c, j) => <div key={j}><Cite c={c} /><Quoted c={c} /></div>)}</div>
          ) : <p className="mt-1.5 text-xs text-bad-700">No citation attached.</p>}
        </li>))}
    </ul>
  )
}

function Section({ title, hint, icon, children, tone = 'neutral' }: { title: string; hint?: string; icon?: ReactNode; children: ReactNode; tone?: 'neutral' | 'warn' }) {
  return (
    <section aria-label={title} className={tone === 'warn' ? 'rounded-lg border border-warn-100 bg-warn-50/40 p-4' : 'rounded-lg border border-stone-200 bg-ivory-50 p-4'}>
      <h3 className="mb-0.5 flex items-center gap-2 font-serif text-base text-navy-900">{icon}{title}</h3>
      {hint && <p className="mb-3 text-xs text-stone-600">{hint}</p>}
      {children}
    </section>
  )
}

function Warning({ w }: { w: ResultWarning }) {
  const injection = w.type === 'instruction_like_content'
  return (
    <li className={injection ? 'rounded-md border border-bad-100 bg-bad-50 px-3.5 py-2.5 text-sm text-bad-700' : 'rounded-md border border-warn-100 bg-warn-50 px-3.5 py-2.5 text-sm text-warn-700'}>
      <p className="flex items-start gap-2"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
        <span><strong>{injection ? 'Instruction-like text found in retrieved content.' : w.type === 'tool_call_denied' ? 'A tool call was denied by policy.' : w.type === 'claim_rejected' ? 'A claim was withheld by the citation verifier.' : w.type === 'proposal_rejected' ? 'A proposed change was discarded.' : 'Warning.'}</strong>{' '}
          {injection ? 'This content contains instruction-like text. It was treated as data and ignored: it could not change any tool, action or recipient.' : w.message}
          {w.patterns && w.patterns.length > 0 && <span className="mt-1 block text-xs">Matched patterns: {w.patterns.join(', ')}</span>}
          {w.reason && !injection && <span className="mt-1 block text-xs">Reason: {w.reason.replace(/_/g, ' ')}</span>}</span></p>
      {w.citation && <div className="mt-2"><Cite c={w.citation} /></div>}
    </li>
  )
}

export function ResultView({ result }: { result: AgentResult }) {
  const empty = !result.facts.length && !result.inferences.length && !result.contradictions.length
  return (
    <div className="space-y-4">
      {result.summary && <Card title="Summary" description="Assembled only from the cited facts below."><p className="text-sm text-navy-950">{result.summary}</p></Card>}
      {result.warnings.length > 0 && <Section tone="warn" title="Warnings" icon={<AlertTriangle className="h-4 w-4 text-warn-700" aria-hidden />}><ul className="space-y-2">{result.warnings.map((w, i) => <Warning key={i} w={w} />)}</ul></Section>}
      <Section title="Facts" hint="Extracted from the records, each with its source (document, version, page ¶ paragraph) and a verbatim quote." icon={<ScanSearch className="h-4 w-4 text-navy-700" aria-hidden />}>
        {result.facts.length ? <ItemList items={result.facts} tone="fact" /> : <p className="text-sm text-stone-600">No cited facts were established.{empty && ' See “Missing information” below.'}</p>}
      </Section>
      {result.contradictions.length > 0 && (
        <Section tone="warn" title="Possible contradictions" hint="Sources that appear to disagree. Resolve against the originals before relying on either." icon={<SearchX className="h-4 w-4 text-warn-700" aria-hidden />}>
          <ul className="space-y-3">{result.contradictions.map((c, i) => (
            <li key={i} className="rounded-md border border-warn-100 bg-white px-3.5 py-2.5"><p className="text-sm font-medium text-navy-950">{c.statement}</p>
              <div className="mt-2 grid gap-3 sm:grid-cols-2">{c.citations.map((ct, j) => <div key={j} className="rounded border border-stone-200 bg-ivory-50 p-2"><Cite c={ct} /><Quoted c={ct} /></div>)}</div></li>))}</ul>
        </Section>)}
      {result.inferences.length > 0 && <Section title="Inferences" hint="Reasoned from the facts, not stated in the sources. Treat as suggestions to check." icon={<Lightbulb className="h-4 w-4 text-warn-700" aria-hidden />}><ItemList items={result.inferences} tone="inference" /></Section>}
      {result.recommendations.length > 0 && <Section title="Recommendations" hint="Suggestions for you. Nothing is applied unless you approve a proposed action." icon={<ListChecks className="h-4 w-4 text-brass-600" aria-hidden />}><ul className="list-disc space-y-1 pl-5 text-sm text-navy-950">{result.recommendations.map((r, i) => <li key={i}>{r.statement}</li>)}</ul></Section>}
      <Section title="Missing information" hint="Evidence the agent looked for and could not find, or was not permitted to retrieve." icon={<SearchX className="h-4 w-4 text-stone-600" aria-hidden />}>
        {result.missing_information.length ? <ul className="list-disc space-y-1 pl-5 text-sm text-navy-950">{result.missing_information.map((m, i) => <li key={i}>{m}</li>)}</ul> : <p className="text-sm text-stone-600">None flagged.</p>}
      </Section>
      <p className="text-xs text-stone-600">
        <strong>Verification:</strong> {result.evidence_summary ? `${result.evidence_summary.items_retrieved} item(s) retrieved. ` : ''}{result.rejected_claims.length === 0 ? 'Every cited reference and quotation matched the retrieved sources.' : `${result.rejected_claims.length} claim(s) were withheld because their citation could not be verified (${[...new Set(result.rejected_claims.map((r) => r.reason.replace(/_/g, ' ')))].join('; ')}).`}
        {result.sections_note && <span className="mt-1 block">{result.sections_note}</span>}
      </p>
    </div>
  )
}
