import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Building2, Plus, User } from 'lucide-react'
import { Badge, Button, DataTable, Dialog, Field, Input, PageHeader, Select, SearchInput, StatusBadge, Textarea, type Column } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth, useOffice } from '@/lib/auth'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { useDebounce, useNewParam, usePageTitle, useQueryParams } from '@/hooks'
import type { Page } from '@/types/api'
import type { Contact, ContactDetail, ContactKind } from '@/types/clients'
import { ClientsSubnav, errMsg, useStaff } from './common'
import { ContactPicker } from './ContactPicker'

const RELATIONS = ['director_of', 'shareholder_of', 'subsidiary_of', 'parent_of', 'spouse_of', 'partner_of', 'employee_of', 'trustee_of', 'beneficiary_of', 'guarantor_of', 'associate_of', 'sibling_of', 'child_of', 'other']
const FILTERS = ['q', 'kind', 'status', 'client', 'onboarding', 'offset'] as const

export default function ClientsList() {
  usePageTitle('Clients & contacts')
  useBreadcrumbs([{ label: 'Clients' }])
  const { can } = useAuth()
  const nav = useNavigate()
  const { isNew, clear } = useNewParam()
  const [p, setP] = useQueryParams(FILTERS)
  const [qText, setQText] = useState(p.q ?? '')
  const dq = useDebounce(qText, 300)
  const limit = 25, offset = Number(p.offset ?? 0)
  // "incomplete onboarding" = contacts still at prospect status (approval of onboarding is what activates a contact)
  const status = p.onboarding === 'incomplete' ? 'prospect' : p.status
  const params = { q: dq, kind: p.kind, status, is_client: p.client === 'yes' ? true : p.client === 'no' ? false : undefined, limit, offset }
  const query = useApiQuery<Page<Contact>>(['clients', params], `/clients${qs(params)}`)

  const cols: Column<Contact>[] = [
    { key: 'name', header: 'Name', cell: (c) => (
      <div className="flex items-center gap-2.5">
        {c.kind === 'organisation' ? <Building2 className="h-4 w-4 shrink-0 text-stone-500" aria-label="Organisation" /> : <User className="h-4 w-4 shrink-0 text-stone-500" aria-label="Individual" />}
        <div className="min-w-0"><p className="truncate font-medium text-navy-900">{c.display_name}</p>{c.aliases.length > 0 && <p className="truncate text-xs text-stone-600">aka {c.aliases.join(', ')}</p>}</div>
      </div>) },
    { key: 'ref', header: 'Client ref', cell: (c) => <span className="tabular-nums">{c.client_ref ?? '—'}</span> },
    { key: 'status', header: 'Status', cell: (c) => <span className="inline-flex gap-1"><StatusBadge status={c.status} />{c.is_client && <Badge tone="info">Client</Badge>}</span> },
    { key: 'resp', header: 'Responsible', hideOnNarrow: true, cell: (c) => c.responsible_name ?? '—' },
    { key: 'contact', header: 'Contact', hideOnNarrow: true, cell: (c) => <span className="text-xs">{c.email ?? '—'}<br />{c.phone ?? ''}</span> },
  ]

  return (
    <>
      <PageHeader title="Clients & parties" description="Individuals and organisations, their relationships, onboarding and conflict history. A contact can hold different roles on different matters."
        actions={can('clients.write') && <Button icon={<Plus className="h-4 w-4" />} onClick={() => nav('/clients?new=1')}>New prospective client</Button>} />
      <ClientsSubnav />
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <SearchInput className="w-64 shrink-0" value={qText} onValueChange={(v) => { setQText(v); setP({ q: v, offset: null }) }} placeholder="Search name, alias, reference, email…" />
        <Field label="Type" className="w-40"><Select value={p.kind ?? ''} onChange={(e) => setP({ kind: e.target.value, offset: null })}><option value="">All</option><option value="individual">Individuals</option><option value="organisation">Organisations</option></Select></Field>
        <Field label="Status" className="w-40"><Select value={p.status ?? ''} disabled={p.onboarding === 'incomplete'} onChange={(e) => setP({ status: e.target.value, offset: null })}><option value="">Any (excl. merged)</option><option value="prospect">Prospect</option><option value="active">Active</option><option value="inactive">Inactive</option><option value="merged">Merged</option></Select></Field>
        <Field label="Client" className="w-40"><Select value={p.client ?? ''} onChange={(e) => setP({ client: e.target.value, offset: null })}><option value="">All contacts</option><option value="yes">Clients only</option><option value="no">Not clients</option></Select></Field>
        <Field label="Onboarding" className="w-40"><Select value={p.onboarding ?? ''} onChange={(e) => setP({ onboarding: e.target.value, offset: null })}><option value="">Any</option><option value="incomplete">Incomplete (prospects)</option></Select></Field>
      </div>
      <DataTable caption="Clients and contacts" columns={cols} rows={query.data?.items} rowKey={(c) => c.id} loading={query.isPending} error={query.error} onRetry={() => void query.refetch()}
        onRowClick={(c) => nav(`/clients/${c.id}`)} emptyTitle="No contacts match these filters" emptyDescription="Try clearing filters, or create a prospective client."
        pagination={query.data ? { total: query.data.total, limit, offset, onChange: (o) => setP({ offset: String(o) }) } : undefined} />
      <NewClientDialog open={isNew} onClose={clear} />
    </>
  )
}

function NewClientDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const nav = useNavigate()
  const { staff } = useStaff()
  const { offices } = useOffice()
  const [kind, setKind] = useState<ContactKind>('individual')
  const [f, setF] = useState({ title: '', first_name: '', last_name: '', date_of_birth: '', org_name: '', company_number: '', email: '', phone: '', preferred_channel: 'email', aliases: '', responsible_user_id: '', office_id: '', notes: '', line1: '', city: '', postcode: '', addrKind: 'correspondence' })
  const [rel, setRel] = useState<{ contact: { id: string; display_name: string } | null; type: string }>({ contact: null, type: 'director_of' })
  const [err, setErr] = useState<string | null>(null)
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))
  const create = useApiMutation(async () => {
    const display = kind === 'organisation' ? f.org_name.trim() : `${f.first_name.trim()} ${f.last_name.trim()}`.trim()
    const body = {
      kind, display_name: display, title: f.title || null, first_name: kind === 'individual' ? f.first_name.trim() || null : null, last_name: kind === 'individual' ? f.last_name.trim() || null : null,
      date_of_birth: kind === 'individual' && f.date_of_birth ? f.date_of_birth : null, org_name: kind === 'organisation' ? f.org_name.trim() : null, company_number: kind === 'organisation' ? f.company_number || null : null,
      email: f.email || null, phone: f.phone || null, preferred_channel: f.preferred_channel, aliases: f.aliases.split(',').map((a) => a.trim()).filter(Boolean),
      responsible_user_id: f.responsible_user_id || null, office_id: f.office_id || null, notes: f.notes || null,
      addresses: f.line1.trim() ? [{ kind: f.addrKind, line1: f.line1.trim(), city: f.city || null, postcode: f.postcode || null, is_primary: true }] : [],
    }
    const c = await api.post<ContactDetail>('/clients', body)
    if (rel.contact) await api.post(`/clients/${c.id}/relationships`, { to_contact_id: rel.contact.id, relation_type: rel.type })
    return c
  }, { invalidate: [['clients']], successMessage: 'Prospective client created', errorToast: false,
    onSuccess: (c) => { onClose(); nav(`/clients/${c.id}`) }, onError: (e) => setErr(errMsg(e)) })
  const valid = kind === 'organisation' ? f.org_name.trim().length > 1 : f.first_name.trim() && f.last_name.trim()
  return (
    <Dialog open={open} onClose={onClose} size="lg" title="New prospective client" description="Creates a prospect. Run a conflict search and complete onboarding before opening a matter."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={create.isPending} disabled={!valid} onClick={() => { setErr(null); create.mutate() }}>Create prospect</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <fieldset className="flex gap-4"><legend className="sr-only">Type of client</legend>
          {(['individual', 'organisation'] as const).map((k) => (
            <label key={k} className="flex items-center gap-2 text-sm"><input type="radio" name="kind" checked={kind === k} onChange={() => setKind(k)} className="accent-navy-800" />{k === 'individual' ? 'Individual' : 'Organisation'}</label>
          ))}
        </fieldset>
        {kind === 'individual' ? (
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="Title"><Input value={f.title} onChange={set('title')} /></Field>
            <Field label="First name" required className="sm:col-span-1"><Input value={f.first_name} onChange={set('first_name')} /></Field>
            <Field label="Last name" required className="sm:col-span-1"><Input value={f.last_name} onChange={set('last_name')} /></Field>
            <Field label="Date of birth"><Input type="date" value={f.date_of_birth} onChange={set('date_of_birth')} /></Field>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Organisation name" required><Input value={f.org_name} onChange={set('org_name')} /></Field>
            <Field label="Company number"><Input value={f.company_number} onChange={set('company_number')} /></Field>
          </div>
        )}
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Email"><Input type="email" value={f.email} onChange={set('email')} /></Field>
          <Field label="Telephone"><Input value={f.phone} onChange={set('phone')} /></Field>
          <Field label="Preferred channel"><Select value={f.preferred_channel} onChange={set('preferred_channel')}><option value="email">Email</option><option value="phone">Phone</option><option value="post">Post</option><option value="portal">Client portal</option></Select></Field>
        </div>
        <Field label="Aliases / former names" hint="Comma-separated. Aliases are used by conflict searches."><Input value={f.aliases} onChange={set('aliases')} /></Field>
        <div className="grid gap-3 sm:grid-cols-4">
          <Field label="Address line 1" className="sm:col-span-2"><Input value={f.line1} onChange={set('line1')} /></Field>
          <Field label="Town / city"><Input value={f.city} onChange={set('city')} /></Field>
          <Field label="Postcode"><Input value={f.postcode} onChange={set('postcode')} /></Field>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Responsible staff member"><Select value={f.responsible_user_id} onChange={set('responsible_user_id')}><option value="">Unassigned</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
          <Field label="Office"><Select value={f.office_id} onChange={set('office_id')}><option value="">—</option>{offices.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select></Field>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Related entity (optional)" hint="e.g. this person is a director of an existing company."><ContactPicker value={rel.contact} onChange={(c) => setRel((r) => ({ ...r, contact: c ? { id: c.id, display_name: c.display_name } : null }))} /></Field>
          <Field label="Relationship"><Select value={rel.type} disabled={!rel.contact} onChange={(e) => setRel((r) => ({ ...r, type: e.target.value }))}>{RELATIONS.map((r) => <option key={r} value={r}>{r.replace(/_/g, ' ')}</option>)}</Select></Field>
        </div>
        <Field label="Notes"><Textarea rows={2} value={f.notes} onChange={set('notes')} /></Field>
      </div>
    </Dialog>
  )
}
