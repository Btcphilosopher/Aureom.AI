import { useId, useState } from 'react'
import { Building2, User, X } from 'lucide-react'
import { Input, Spinner } from '@/components/ui'
import { useApiQuery, qs } from '@/lib/api'
import { useDebounce } from '@/hooks'
import type { Page } from '@/types/api'
import type { Contact } from '@/types/clients'

/** Typeahead for choosing an existing contact. Controlled by `value` (id) + `onChange(contact|null)`. */
export function ContactPicker({ value, onChange, excludeId, kind, placeholder = 'Search by name, reference, company number…', id, ...aria }: {
  value: { id: string; display_name: string } | null; onChange: (c: Contact | null) => void; excludeId?: string; kind?: string; placeholder?: string; id?: string
  'aria-describedby'?: string; 'aria-invalid'?: boolean
}) {
  const [q, setQ] = useState('')
  const dq = useDebounce(q, 250)
  const list = useId()
  const res = useApiQuery<Page<Contact>>(['contact-picker', dq, kind], `/clients${qs({ q: dq, kind, limit: 8 })}`, { enabled: dq.trim().length >= 2 })
  if (value) {
    return (
      <div className="flex h-9 items-center justify-between rounded-md border border-stone-300 bg-white px-3 text-sm">
        <span className="truncate text-navy-900">{value.display_name}</span>
        <button type="button" onClick={() => onChange(null)} aria-label={`Clear ${value.display_name}`} className="rounded p-1 text-stone-500 hover:text-navy-900"><X className="h-3.5 w-3.5" /></button>
      </div>
    )
  }
  const items = (res.data?.items ?? []).filter((c) => c.id !== excludeId)
  return (
    <div className="relative">
      <Input id={id} role="combobox" aria-expanded={dq.trim().length >= 2} aria-controls={list} aria-autocomplete="list" value={q} onChange={(e) => setQ(e.target.value)} placeholder={placeholder} autoComplete="off" {...aria} />
      {dq.trim().length >= 2 && (
        <ul id={list} role="listbox" className="absolute z-20 mt-1 max-h-56 w-full overflow-auto rounded-md border border-stone-200 bg-white py-1 shadow-pop">
          {res.isPending && <li className="flex items-center gap-2 px-3 py-2 text-xs text-stone-600"><Spinner className="h-3.5 w-3.5" />Searching…</li>}
          {res.isError && <li className="px-3 py-2 text-xs text-bad-700">Search failed.</li>}
          {!res.isPending && !items.length && !res.isError && <li className="px-3 py-2 text-xs text-stone-600">No matching contacts.</li>}
          {items.map((c) => (
            <li key={c.id} role="option" aria-selected={false}>
              <button type="button" onClick={() => { onChange(c); setQ('') }} className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm hover:bg-navy-50 focus-visible:bg-navy-50 focus-visible:outline-none">
                {c.kind === 'organisation' ? <Building2 className="h-4 w-4 text-stone-500" aria-hidden /> : <User className="h-4 w-4 text-stone-500" aria-hidden />}
                <span className="truncate">{c.display_name}</span><span className="ml-auto text-xs text-stone-600">{c.client_ref ?? c.status}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
