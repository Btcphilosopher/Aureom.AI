import { Route, Routes } from 'react-router-dom'
import { NotFoundState } from '@/components/ui/States'
import ClientsList from './ClientsList'
import ClientDetail from './ClientDetail'
import DuplicatesPage from './Duplicates'
import { ConflictSearchPage, ConflictsList } from './Conflicts'

/** /clients/* — list, duplicates & merges, conflict searches, client detail. */
export default function ClientsSection() {
  return (
    <Routes>
      <Route index element={<ClientsList />} />
      <Route path="duplicates" element={<DuplicatesPage />} />
      <Route path="conflicts" element={<ConflictsList />} />
      <Route path="conflicts/:id" element={<ConflictSearchPage />} />
      <Route path=":id" element={<ClientDetail />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
