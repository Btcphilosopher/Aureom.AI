import { useState } from 'react'
import { ClipboardCheck, FlaskConical, Play } from 'lucide-react'
import { Badge, Button, Card, Dialog, Field, KeyValue, Select, SimulatedBanner, StatusBadge, Textarea, Tooltip } from '@/components/ui'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatDateTime, humanise } from '@/lib/format'
import { QueryBoundary } from '@/components/ui'
import type { ContactDetail, Onboarding, OnboardingCheck } from '@/types/clients'
import { blockerText } from './common'

/** Identity & onboarding. Every check result here is SIMULATED (demonstration adapter) - never presented as a verified identity. */
export function OnboardingPanel({ contact }: { contact: ContactDetail }) {
  const { can } = useAuth()
  const key = ['onboarding', contact.id]
  const q = useApiQuery<Onboarding>(key, `/clients/${contact.id}/onboarding`)
  const base = `/clients/${contact.id}/onboarding`
  const inv = [key, ['client', contact.id], ['clients']]
  const [review, setReview] = useState<OnboardingCheck | null>(null)
  const [waive, setWaive] = useState<OnboardingCheck | null>(null)
  const [decide, setDecide] = useState<'approve' | 'reject' | null>(null)
  const [formOpen, setFormOpen] = useState(false)

  const start = useApiMutation(() => api.post(base), { invalidate: inv, successMessage: 'Onboarding started' })
  const run = useApiMutation((check_type: string) => api.post(`${base}/checks`, { check_type }), { invalidate: inv, successMessage: 'Simulated check recorded' })
  const submit = useApiMutation(() => api.post(`${base}/submit`), { invalidate: inv, successMessage: 'Submitted for human review' })

  return (
    <QueryBoundary query={q} what="onboarding record">
      {(ob) => {
        const done = ob.status === 'approved' || ob.status === 'rejected'
        return (
          <div className="space-y-5">
            <SimulatedBanner>{ob.simulated_notice}</SimulatedBanner>
            <Card title="Onboarding record" actions={<>
              {!ob.record && can('onboarding.manage') && <Button size="sm" icon={<ClipboardCheck className="h-4 w-4" />} loading={start.isPending} onClick={() => start.mutate()}>Start onboarding</Button>}
              {ob.record && !done && can('onboarding.manage') && <Button size="sm" variant="secondary" loading={submit.isPending} onClick={() => submit.mutate()}>Submit for review</Button>}
              {ob.record && !done && can('onboarding.approve') && <><Button size="sm" variant="danger" onClick={() => setDecide('reject')}>Reject</Button><Button size="sm" onClick={() => setDecide('approve')}>Approve (human decision)</Button></>}
            </>}>
              <KeyValue columns={3} items={[
                { label: 'Status', value: <StatusBadge status={ob.status} label={ob.record?.status_label} /> },
                { label: 'Risk level', value: ob.record?.risk_level ? humanise(ob.record.risk_level) : 'Not assessed' },
                { label: 'Reviewed', value: ob.record?.reviewed_at ? formatDateTime(ob.record.reviewed_at) : 'Not yet' },
              ]} />
              {ob.record?.notes && <p className="mt-3 text-sm text-stone-700">{ob.record.notes}</p>}
              {!can('onboarding.approve') && !done && <p className="mt-3 text-xs text-stone-600">Approving onboarding needs the <code className="rounded bg-stone-100 px-1">onboarding.approve</code> permission (partner or compliance). You can run checks and submit for review.</p>}
              {ob.blockers.length > 0 && !done && (
                <div className="mt-4 rounded-md border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700">
                  <p className="font-semibold">Before this can be approved:</p>
                  <ul className="mt-1 list-disc pl-5">{ob.blockers.map((b, i) => <li key={i}>{blockerText(b)}</li>)}</ul>
                </div>
              )}
            </Card>

            <Card title="Checks" description="Configured in firm settings. Required checks must be passed (simulated) or waived with a reason by an authorised reviewer.">
              <ul className="divide-y divide-stone-200">
                {ob.check_types.filter((t) => t.applicable).map((t) => {
                  const c = ob.checks.find((x) => x.check_type === t.key)
                  return (
                    <li key={t.key} className="flex flex-wrap items-start justify-between gap-3 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-navy-900">{t.label} {t.required && <Badge tone="neutral">Required</Badge>}</p>
                        {c ? (
                          <div className="mt-1 space-y-1 text-sm text-stone-700">
                            <p className="flex flex-wrap items-center gap-1.5"><StatusBadge status={c.status} label={c.status_label} /><Badge tone="simulated">Simulated · {c.provider}</Badge>{c.external_ref && <span className="text-xs tabular-nums text-stone-500">{c.external_ref}</span>}</p>
                            {c.result_summary && <p className="text-xs">{c.result_summary}</p>}
                            {c.review_note && <p className="text-xs text-stone-600">Reviewer note: {c.review_note}</p>}
                            <p className="text-xs text-stone-500">{c.performed_at ? `Run ${formatDateTime(c.performed_at)}` : ''}</p>
                          </div>
                        ) : <p className="mt-1 text-xs text-stone-600">Not run yet.</p>}
                      </div>
                      <div className="flex shrink-0 gap-2">
                        {!done && can('onboarding.manage') && <Button size="sm" variant="secondary" icon={<Play className="h-3.5 w-3.5" />} loading={run.isPending && run.variables === t.key} onClick={() => run.mutate(t.key)}>{c ? 'Re-run simulated check' : 'Run simulated check'}</Button>}
                        {!done && c && can('onboarding.approve') && <><Button size="sm" variant="ghost" onClick={() => setReview(c)}>Review</Button><Button size="sm" variant="ghost" onClick={() => setWaive(c)}>Waive…</Button></>}
                        {!done && c && !can('onboarding.approve') && <Tooltip text="Review and waiver need onboarding.approve"><span><Button size="sm" variant="ghost" disabled>Review</Button></span></Tooltip>}
                      </div>
                    </li>
                  )
                })}
              </ul>
              <p className="mt-3 flex items-center gap-1.5 text-xs text-sim-700"><FlaskConical className="h-3.5 w-3.5" aria-hidden />Results come from a simulated provider adapter. Try a name containing “refer” or “fail” to see the other outcomes.</p>
            </Card>

            <Card title="Submitted intake form" description="Untrusted input from the client: shown as plain text only."
              actions={can('onboarding.manage') && !done && ob.record ? <Button size="sm" variant="secondary" onClick={() => setFormOpen(true)}>Edit form data</Button> : undefined}>
              {ob.record && Object.keys(ob.record.submitted_form ?? {}).length > 0
                ? <KeyValue columns={2} items={Object.entries(ob.record.submitted_form).map(([k, v]) => ({ label: humanise(k), value: <span className="whitespace-pre-wrap">{typeof v === 'string' ? v : JSON.stringify(v)}</span> }))} />
                : <p className="text-sm text-stone-600">No intake form has been submitted.</p>}
            </Card>

            <CheckReviewDialog check={review} base={base} inv={inv} onClose={() => setReview(null)} />
            <WaiveDialog check={waive} base={base} inv={inv} onClose={() => setWaive(null)} />
            <DecisionDialog mode={decide} base={base} inv={inv} onClose={() => setDecide(null)} />
            <FormDialog open={formOpen} onClose={() => setFormOpen(false)} base={base} inv={inv} initial={ob.record?.submitted_form ?? {}} />
          </div>
        )
      }}
    </QueryBoundary>
  )
}

function CheckReviewDialog({ check, base, inv, onClose }: { check: OnboardingCheck | null; base: string; inv: unknown[][]; onClose: () => void }) {
  const [decision, setDecision] = useState<'accept' | 'reject'>('accept')
  const [note, setNote] = useState('')
  const m = useApiMutation(() => api.post(`${base}/checks/${check!.id}/review`, { decision, note }), { invalidate: inv as never, successMessage: 'Review recorded', onSuccess: () => { setNote(''); onClose() } })
  return (
    <Dialog open={!!check} onClose={onClose} title="Review simulated check" description="A human reviewer records whether the (simulated) result is accepted. This is not an identity verification."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={note.trim().length < 3} loading={m.isPending} onClick={() => m.mutate()}>Record review</Button></>}>
      <div className="space-y-3">
        <Field label="Decision"><Select value={decision} onChange={(e) => setDecision(e.target.value as 'accept' | 'reject')}><option value="accept">Accept the simulated result</option><option value="reject">Reject / needs more evidence</option></Select></Field>
        <Field label="Reviewer note" required><Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} /></Field>
      </div>
    </Dialog>
  )
}
function WaiveDialog({ check, base, inv, onClose }: { check: OnboardingCheck | null; base: string; inv: unknown[][]; onClose: () => void }) {
  const [reason, setReason] = useState('')
  const m = useApiMutation(() => api.post(`${base}/checks/${check!.id}/waive`, { reason: reason.trim() }), { invalidate: inv as never, successMessage: 'Check waived with recorded reason', onSuccess: () => { setReason(''); onClose() } })
  return (
    <Dialog open={!!check} onClose={onClose} title="Waive this check" description="Waiving a check is a recorded exception. State why it is justified."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={reason.trim().length < 10} loading={m.isPending} onClick={() => m.mutate()}>Waive check</Button></>}>
      <Field label="Reason for waiver" required hint="At least 10 characters. Recorded in the audit trail."><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
    </Dialog>
  )
}
function DecisionDialog({ mode, base, inv, onClose }: { mode: 'approve' | 'reject' | null; base: string; inv: unknown[][]; onClose: () => void }) {
  const [note, setNote] = useState(''); const [risk, setRisk] = useState('low'); const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post(`${base}/${mode}`, { note: note || null, risk_level: mode === 'approve' ? risk : null }), { invalidate: inv as never, errorToast: false,
    successMessage: mode === 'approve' ? 'Onboarding approved by reviewer' : 'Onboarding rejected', onSuccess: () => { setNote(''); setErr(null); onClose() }, onError: (e) => setErr(e instanceof ApiError ? e.message : 'Failed') })
  return (
    <Dialog open={!!mode} onClose={onClose} title={mode === 'approve' ? 'Approve onboarding' : 'Reject onboarding'}
      description={mode === 'approve' ? 'You are recording a human decision based on the (simulated) check results and your own review.' : 'The prospect stays at prospect status.'}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant={mode === 'reject' ? 'danger' : 'primary'} loading={m.isPending} onClick={() => m.mutate()}>{mode === 'approve' ? 'Approve' : 'Reject'}</Button></>}>
      <div className="space-y-3">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        {mode === 'approve' && <Field label="Risk level (human assessment)"><Select value={risk} onChange={(e) => setRisk(e.target.value)}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></Select></Field>}
        <Field label="Note"><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
      </div>
    </Dialog>
  )
}
function FormDialog({ open, onClose, base, inv, initial }: { open: boolean; onClose: () => void; base: string; inv: unknown[][]; initial: Record<string, unknown> }) {
  const [text, setText] = useState(() => JSON.stringify(initial, null, 2)); const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation((form: Record<string, unknown>) => api.put(`${base}/form`, { form }), { invalidate: inv as never, successMessage: 'Intake form saved', onSuccess: onClose })
  return (
    <Dialog open={open} onClose={onClose} title="Edit intake form data" description="Stored as submitted. Treated as untrusted data."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={m.isPending} onClick={() => { try { const v = JSON.parse(text); if (typeof v !== 'object' || Array.isArray(v) || v === null) throw new Error('Must be a JSON object'); setErr(null); m.mutate(v) } catch (e) { setErr((e as Error).message) } }}>Save</Button></>}>
      <Field label="Form fields (JSON object)" error={err ?? undefined}><Textarea rows={10} className="font-mono text-xs" value={text} onChange={(e) => setText(e.target.value)} /></Field>
    </Dialog>
  )
}
