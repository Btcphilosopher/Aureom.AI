import { useMemo, type ReactNode } from 'react'
import { NavLink } from 'react-router-dom'
import { Lock } from 'lucide-react'
import { Badge } from '@/components/ui'
import { ApiError, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { cn } from '@/lib/cn'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { AdminUser, MatterListItem, MatterTemplate, RetentionPolicy, Team } from '@/types/matters'

export const PARTY_ROLES = ['client', 'payer', 'beneficiary', 'counterparty', 'counterparty_solicitor', 'witness', 'other'] as const
export const PRACTICE_AREAS = ['commercial', 'property', 'litigation', 'employment', 'private_client', 'corporate'] as const
export const MATTER_STATUSES = ['prospective', 'open', 'paused', 'closed'] as const

const ROLE_TONE: Record<string, 'info' | 'brass' | 'success' | 'warning' | 'danger' | 'neutral'> = {
  client: 'info', payer: 'brass', beneficiary: 'success', counterparty: 'danger', counterparty_solicitor: 'warning', witness: 'neutral', other: 'neutral',
}
export function RoleBadge({ role }: { role: string }) {
  return <Badge tone={ROLE_TONE[role] ?? 'neutral'}>{humanise(role)}</Badge>
}

export function AccessBadges({ access, wall, hold, showStandard = false }: { access?: string; wall?: boolean; hold?: boolean; showStandard?: boolean }) {
  return (
    <span className="inline-flex flex-wrap items-center gap-1">
      {showStandard && access === 'standard' && !wall && <Badge tone="neutral">Standard</Badge>}
      {access === 'restricted' && <Badge tone="brass"><Lock className="h-3 w-3" aria-hidden />Restricted</Badge>}
      {wall && <Badge tone="brass"><Lock className="h-3 w-3" aria-hidden />Ethical wall</Badge>}
      {hold && <Badge tone="danger">Legal hold</Badge>}
    </span>
  )
}

export function errMsg(e: unknown): string { return e instanceof ApiError ? e.message : e instanceof Error ? e.message : 'Something went wrong.' }

/** Blockers may be strings or {message|label}. */
export function blockerText(b: unknown): string {
  if (typeof b === 'string') return b
  if (b && typeof b === 'object') { const o = b as Record<string, unknown>; return String(o.message ?? o.label ?? o.code ?? JSON.stringify(b)) }
  return String(b)
}

export function ClientsSubnav() {
  const item = (to: string, label: string, end = false) => (
    <NavLink key={to} to={to} end={end} className={({ isActive }) => cn('rounded-md px-3 py-1.5 text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500', isActive ? 'bg-navy-800 text-white' : 'text-navy-800 hover:bg-navy-50')}>{label}</NavLink>
  )
  return <nav aria-label="Clients sections" className="mb-5 flex flex-wrap gap-1">{item('/clients', 'Clients & contacts', true)}{item('/clients/duplicates', 'Duplicates & merges')}{item('/clients/conflicts', 'Conflict searches')}</nav>
}

export function Section({ title, children, actions }: { title: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between gap-3"><h3 className="text-sm font-semibold uppercase tracking-wide text-stone-700">{title}</h3>{actions}</div>
      {children}
    </section>
  )
}

/* ------------------------------------------------------------------------------------------------------------------------------
 * Directory hooks backed by GET /auth/directory (names/roles/teams/retention keys only; any staff user).
 * ---------------------------------------------------------------------------------------------------------------------------- */
export interface StaffMember { id: string; name: string; role?: string | null; team_id?: string | null }
interface Directory { users: { id: string; name: string; role_key: string; team_id: string | null }[]; teams: Team[]; retention_policies: { key: string; name: string; years: number }[] }

function useDirectory() {
  return useApiQuery<Directory>(['directory'], '/auth/directory', { staleTime: 60_000 })
}

export function useStaff() {
  const dir = useDirectory()
  return useMemo(() => ({
    staff: (dir.data?.users ?? []).map((u) => ({ id: u.id, name: u.name, role: u.role_key, team_id: u.team_id })).sort((a, b) => a.name.localeCompare(b.name)) as StaffMember[],
    source: 'admin' as 'admin' | 'derived',
    loading: dir.isPending,
  }), [dir.data, dir.isPending])
}

export function useTeams() {
  const dir = useDirectory()
  return { teams: (dir.data?.teams ?? []) as Team[], available: true }
}

export function useRetentionPolicies() {
  const dir = useDirectory()
  return useMemo(() => (dir.data?.retention_policies ?? []).map((p) => ({ ...p, label: `${p.name} (${p.years} years)` })), [dir.data])
}

export function personName(p: { name?: string | null } | null | undefined) { return p?.name ?? '—' }
