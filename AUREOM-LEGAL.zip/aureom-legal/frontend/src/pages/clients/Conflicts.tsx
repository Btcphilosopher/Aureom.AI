import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { AlertTriangle, Lock, Plus, ShieldAlert } from 'lucide-react'
import { Badge, Button, Card, DataTable, Dialog, EmptyState, Field, Input, PageHeader, QueryBoundary, Select, StatusBadge, Textarea, Timeline, type Column } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatDateTime, humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle, useQueryParam } from '@/hooks'
import type { Page } from '@/types/api'
import type { ConflictMatch, ConflictSearch, ConflictSearchRow } from '@/types/clients'
import { ClientsSubnav, errMsg } from './common'
import { ContactPicker } from './ContactPicker'

const NEVER_AUTO = 'The system never declares a matter conflict-free. Matches are flagged for authorised human review, and only a person can record the outcome.'

/* ---------------------------------------------------------------------------------------------- run-search dialog */
export function RunConflictDialog({ open, onClose, subject, matterId, onCreated }: { open: boolean; onClose: () => void; subject?: { id: string; display_name: string } | null; matterId?: string; onCreated?: (s: ConflictSearch) => void }) {
  const nav = useNavigate()
  const [terms, setTerms] = useState('')
  const [subj, setSubj] = useState<{ id: string; display_name: string } | null>(subject ?? null)
  const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post<ConflictSearch>('/conflicts/searches', { terms: terms.split('\n').map((t) => t.trim()).filter(Boolean), subject_contact_id: (subject ?? subj)?.id ?? null, matter_id: matterId ?? null }),
    { invalidate: [['conflicts']], errorToast: false, onSuccess: (s) => { setTerms(''); setErr(null); onClose(); if (onCreated) onCreated(s); else nav(`/clients/conflicts/${s.id}`) }, onError: (e) => setErr(errMsg(e)) })
  return (
    <Dialog open={open} onClose={onClose} title="Run conflict search" description="Searches names, aliases, organisations, relationships (e.g. directors) and parties on matters across the firm."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={m.isPending} disabled={!terms.trim() && !(subject ?? subj)} onClick={() => { setErr(null); m.mutate() }}>Run search</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <Field label="Subject contact" hint="Their name, aliases and related entities are searched automatically.">
          {subject ? <Input readOnly value={subject.display_name} /> : (p) => <ContactPicker id={p.id} value={subj} onChange={(c) => setSubj(c ? { id: c.id, display_name: c.display_name } : null)} />}
        </Field>
        <Field label="Additional names to search" hint="One per line: counterparties, directors, former names…"><Textarea rows={4} value={terms} onChange={(e) => setTerms(e.target.value)} /></Field>
        <p className="rounded-md bg-ivory-100 px-3 py-2 text-xs text-stone-700">{NEVER_AUTO}</p>
      </div>
    </Dialog>
  )
}

/* ---------------------------------------------------------------------------------------------- list page */
export function ConflictsList() {
  usePageTitle('Conflict searches')
  useBreadcrumbs([{ label: 'Clients', to: '/clients' }, { label: 'Conflict searches' }])
  const { can } = useAuth()
  const nav = useNavigate()
  const [status, setStatus] = useQueryParam('status')
  const [offset, setOffset] = useState(0)
  const [run, setRun] = useState(false)
  const query = useApiQuery<Page<ConflictSearchRow>>(['conflicts', 'list', status, offset], `/conflicts/searches${qs({ status, limit: 25, offset })}`)
  const cols: Column<ConflictSearchRow>[] = [
    { key: 'terms', header: 'Searched', cell: (r) => <span className="line-clamp-2 max-w-md text-sm">{r.terms.slice(0, 4).join(' · ')}{r.terms.length > 4 ? ` +${r.terms.length - 4}` : ''}</span> },
    { key: 'status', header: 'Outcome', cell: (r) => <StatusBadge status={r.status} /> },
    { key: 'matches', header: 'Matches', numeric: true, cell: (r) => r.match_count },
    { key: 'by', header: 'Requested by', hideOnNarrow: true, cell: (r) => r.requested_by_name ?? '—' },
    { key: 'rev', header: 'Reviewed by', hideOnNarrow: true, cell: (r) => r.reviewed_by_name ?? <span className="text-stone-500">Awaiting reviewer</span> },
    { key: 'at', header: 'Run', cell: (r) => formatDateTime(r.created_at) },
  ]
  return (
    <>
      <PageHeader title="Conflict searches" description="Decision support only. Every search needs a recorded human decision before a matter can be opened."
        actions={can('conflicts.run') && <Button icon={<Plus className="h-4 w-4" />} onClick={() => setRun(true)}>Run conflict search</Button>} />
      <ClientsSubnav />
      <div className="mb-4 max-w-xs"><Field label="Outcome"><Select value={status ?? ''} onChange={(e) => { setStatus(e.target.value); setOffset(0) }}>
        <option value="">All</option><option value="pending_review">Pending human review</option><option value="cleared_by_reviewer">Cleared by reviewer</option><option value="conflict_confirmed">Conflict confirmed</option><option value="referred">Referred</option></Select></Field></div>
      <QueryBoundary query={query} what="conflict searches" empty={<EmptyState title="No conflict searches" description="Run a search for a new client or party before opening a matter." />}>
        {(d) => <DataTable caption="Conflict searches" columns={cols} rows={d.items} rowKey={(r) => r.id} onRowClick={(r) => nav(`/clients/conflicts/${r.id}`)} pagination={{ total: d.total, limit: d.limit, offset: d.offset, onChange: setOffset }} />}
      </QueryBoundary>
      <RunConflictDialog open={run} onClose={() => setRun(false)} />
    </>
  )
}

/* ---------------------------------------------------------------------------------------------- detail page */
export function ConflictSearchPage() {
  const { id } = useParams()
  const query = useApiQuery<ConflictSearch>(['conflicts', 'search', id], `/conflicts/searches/${id}`)
  usePageTitle('Conflict search')
  useBreadcrumbs([{ label: 'Clients', to: '/clients' }, { label: 'Conflict searches', to: '/clients/conflicts' }, { label: 'Search' }])
  return (
    <>
      <PageHeader title="Conflict search review" description="Review each match against its supporting records, then record the final human decision." />
      <ClientsSubnav />
      <QueryBoundary query={query} what="conflict search">{(s) => <ConflictSearchView search={s} />}</QueryBoundary>
    </>
  )
}

export function ConflictSearchView({ search }: { search: ConflictSearch }) {
  const { can } = useAuth()
  const pending = search.status === 'pending_review'
  return (
    <div className="space-y-5">
      <div role="note" className="flex items-start gap-2.5 rounded-md border border-brass-300 bg-brass-50 px-4 py-3 text-sm text-navy-900">
        <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-brass-600" aria-hidden /><p><strong>{NEVER_AUTO}</strong></p>
      </div>
      <Card title="Search" actions={<StatusBadge status={search.status} />}>
        <dl className="grid gap-4 text-sm sm:grid-cols-3">
          <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Subject</dt><dd>{search.subject_contact ? <Link className="text-navy-700 underline" to={`/clients/${search.subject_contact.id}`}>{search.subject_contact.name}</Link> : '—'}</dd></div>
          <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Run by</dt><dd>{search.requested_by_name} · {formatDateTime(search.created_at)}</dd></div>
          <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Reviewed by</dt><dd>{search.reviewed_by_name ? `${search.reviewed_by_name} · ${formatDateTime(search.reviewed_at)}` : 'Awaiting a human reviewer'}</dd></div>
        </dl>
        <div className="mt-3 flex flex-wrap gap-1.5" aria-label="Terms searched">{search.terms.map((t) => <Badge key={t} tone="neutral">{t}</Badge>)}</div>
        {search.review_note && <p className="mt-3 rounded bg-ivory-100 px-3 py-2 text-sm">Decision note: {search.review_note}</p>}
      </Card>

      <section aria-label="Matches" className="space-y-3">
        <h3 className="text-sm font-semibold uppercase tracking-wide text-stone-700">Matches ({search.matches.length}){search.unreviewed_matches > 0 && <span className="ml-2 text-warn-700">· {search.unreviewed_matches} unreviewed</span>}</h3>
        {search.matches.length === 0
          ? <EmptyState icon={<AlertTriangle className="h-5 w-5" />} title="No matches found — a human decision is still required" description="An empty result does not mean there is no conflict (e.g. unrecorded relationships). A reviewer must still record the outcome below." />
          : search.matches.map((m) => <MatchCard key={m.id} match={m} canReview={can('conflicts.review')} editable={pending} />)}
      </section>

      {pending && <DecisionCard search={search} canReview={can('conflicts.review')} />}

      <Card title="Review history" description="Append-only: every disposition and decision is recorded with who, when and why.">
        <Timeline items={search.history.map((h) => ({ id: h.id, title: `${humanise(h.event)}${h.to ? ` → ${humanise(h.to)}` : ''}`, meta: `${h.actor ?? 'System'}${h.from ? ` · was ${humanise(h.from)}` : ''}`, description: h.note ?? undefined, time: formatDateTime(h.at),
          tone: h.to === 'cleared_by_reviewer' || h.to === 'false_positive' ? 'success' : h.to?.includes('conflict') ? 'danger' : 'neutral' }))} />
      </Card>
    </div>
  )
}

function MatchCard({ match: m, canReview, editable }: { match: ConflictMatch; canReview: boolean; editable: boolean }) {
  const [note, setNote] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const ev = m.evidence
  const set = useApiMutation((disposition: string) => api.patch(`/conflicts/matches/${m.id}`, { disposition, note: note.trim() || null }), {
    invalidate: [['conflicts']], errorToast: false, successMessage: 'Disposition recorded', onSuccess: () => { setNote(''); setErr(null) }, onError: (e) => setErr(errMsg(e)) })
  const act = (d: string) => { if (note.trim().length < 3) { setErr('Add a short reason for your decision.'); return } setErr(null); set.mutate(d) }
  return (
    <article className="rounded-lg border border-stone-200 bg-white shadow-panel" aria-label={`Match ${ev.contact?.name ?? m.searched_term}`}>
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-200 px-5 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <h4 className="font-medium text-navy-900">{ev.contact?.name ?? m.searched_term}</h4>
          <Badge tone="info">{humanise(m.match_type)}</Badge>
          <span className="text-xs tabular-nums text-stone-600" title="Similarity score">score {(m.score * 100).toFixed(0)}%</span>
          {ev.adverse_hint === true && <Badge tone="danger">Adverse role on a matter</Badge>}
        </div>
        <StatusBadge status={m.disposition} />
      </header>
      <div className="grid gap-5 px-5 py-4 md:grid-cols-2">
        <div>
          <h5 className="text-xs font-semibold uppercase tracking-wide text-stone-600">Searched for</h5>
          <p className="mt-1 text-sm"><span className="rounded bg-ivory-200 px-1.5 py-0.5">{m.searched_term}</span> <span className="text-xs text-stone-600">({humanise(String(ev.origin ?? 'entered'))})</span></p>
          {ev.matched_on !== undefined && <p className="mt-2 text-sm">Matched on <strong>{humanise(String(ev.matched_on))}</strong>: <span className="rounded bg-brass-50 px-1.5 py-0.5">{String(ev.matched_value ?? '')}</span></p>}
          {typeof ev.relationship === 'string' && <p className="mt-2 text-sm">Relationship: <strong>{ev.relationship}</strong></p>}
        </div>
        <div>
          <h5 className="text-xs font-semibold uppercase tracking-wide text-stone-600">Supporting records</h5>
          {ev.contact && <p className="mt-1 text-sm"><Link className="text-navy-700 underline" to={`/clients/${ev.contact.id}`}>{ev.contact.name}</Link> <span className="text-xs text-stone-600">· {ev.contact.kind} · {ev.contact.client_ref ?? ev.contact.status}</span></p>}
          <ul className="mt-2 space-y-1.5">
            {(ev.matters ?? []).length === 0 && <li className="text-xs text-stone-600">No matter involvement recorded.</li>}
            {(ev.matters ?? []).map((mt, i) => mt.masked
              ? <li key={i} className="flex items-start gap-2 rounded bg-brass-50 px-2.5 py-1.5 text-xs text-navy-900"><Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brass-600" aria-hidden /><span>{mt.label} <span className="text-stone-600">(role: {humanise(mt.role)})</span></span></li>
              : <li key={i} className="text-sm"><Link className="text-navy-700 underline" to={`/matters/${mt.matter_id}`}>{mt.reference}</Link> · {mt.title} <Badge tone="neutral">{humanise(mt.role)}</Badge> <StatusBadge status={mt.status} /></li>)}
          </ul>
        </div>
      </div>
      {m.note && <p className="border-t border-stone-100 px-5 py-2 text-sm text-stone-700">Reviewer note ({m.reviewed_by_name}): {m.note}</p>}
      {editable && (
        <footer className="space-y-2 border-t border-stone-200 bg-ivory-50 px-5 py-3">
          {canReview ? <>
            <Field label="Reason for disposition" error={err ?? undefined}><Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Different company number and registered address; unrelated entity." /></Field>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="secondary" loading={set.isPending} onClick={() => act('false_positive')}>False positive</Button>
              <Button size="sm" variant="secondary" loading={set.isPending} onClick={() => act('potential_conflict')}>Potential conflict</Button>
              <Button size="sm" variant="danger" loading={set.isPending} onClick={() => act('confirmed_conflict')}>Confirmed conflict</Button>
            </div></> : <p className="text-xs text-stone-600">Recording a disposition needs the <code className="rounded bg-stone-100 px-1">conflicts.review</code> permission (partner or compliance).</p>}
        </footer>
      )}
    </article>
  )
}

function DecisionCard({ search, canReview }: { search: ConflictSearch; canReview: boolean }) {
  const [decision, setDecision] = useState('cleared_by_reviewer'); const [note, setNote] = useState(''); const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post(`/conflicts/searches/${search.id}/decision`, { decision, note: note.trim(), expected_version: search.version }), {
    invalidate: [['conflicts']], errorToast: false, successMessage: 'Decision recorded', onError: (e) => setErr(errMsg(e)) })
  const blocked = decision === 'cleared_by_reviewer' && search.unreviewed_matches > 0
  return (
    <Card title="Final human decision" description="Recorded against your name with the note below. Needed before a matter can be opened.">
      {!canReview ? <p className="text-sm text-stone-700">You can run searches but the final decision needs <code className="rounded bg-stone-100 px-1">conflicts.review</code>. Ask a partner or the compliance team to review this search.</p> : (
        <div className="space-y-3">
          {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
          <Field label="Decision"><Select value={decision} onChange={(e) => setDecision(e.target.value)}>
            <option value="cleared_by_reviewer">Cleared by reviewer (no conflict identified)</option><option value="conflict_confirmed">Conflict confirmed — do not proceed</option><option value="referred">Referred for further review</option></Select></Field>
          <Field label="Decision note" required hint="Explain the basis for your decision."><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
          {blocked && <p className="text-xs text-warn-700">Disposition every match above first ({search.unreviewed_matches} unreviewed).</p>}
          <Button disabled={blocked || note.trim().length < 3} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Record decision</Button>
        </div>)}
    </Card>
  )
}

