import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowRight, Pencil, Plus, ShieldAlert, Trash2 } from 'lucide-react'
import { Badge, Button, Card, ConfirmDialog, DataTable, Dialog, EmptyState, Field, IconButton, Input, KeyValue, PageHeader, QueryBoundary, Select, StatusBadge, TabPanel, Tabs, Textarea, type Column } from '@/components/ui'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth, useOffice } from '@/lib/auth'
import { formatDate, formatDateTime, humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle, useQueryParam } from '@/hooks'
import type { Page } from '@/types/api'
import type { Address, Contact, ContactDetail, ContactMatterRoles, ConflictSearchRow, Relationship } from '@/types/clients'
import { ClientsSubnav, RoleBadge, errMsg, useStaff } from './common'
import { ContactPicker } from './ContactPicker'
import { OnboardingPanel } from './OnboardingPanel'
import { RunConflictDialog } from './Conflicts'

const RELATIONS = ['director_of', 'shareholder_of', 'subsidiary_of', 'parent_of', 'spouse_of', 'partner_of', 'employee_of', 'trustee_of', 'beneficiary_of', 'guarantor_of', 'associate_of', 'sibling_of', 'child_of', 'other']

export default function ClientDetail() {
  const { id } = useParams()
  const query = useApiQuery<ContactDetail>(['client', id], `/clients/${id}`)
  return <QueryBoundary query={query} what="client">{(c) => <Detail c={c} />}</QueryBoundary>
}

function Detail({ c }: { c: ContactDetail }) {
  usePageTitle(c.display_name)
  useBreadcrumbs([{ label: 'Clients', to: '/clients' }, { label: c.display_name }])
  const { can } = useAuth()
  const [tab, setTab] = useQueryParam('tab')
  const t = tab ?? 'overview'
  const [edit, setEdit] = useState(false)
  const merged = c.status === 'merged'
  return (
    <>
      <PageHeader eyebrow={`${c.kind === 'organisation' ? 'Organisation' : 'Individual'}${c.client_ref ? ` · ${c.client_ref}` : ''}`} title={c.display_name}
        meta={<span className="flex flex-wrap items-center gap-1.5"><StatusBadge status={c.status} />{c.is_client && <Badge tone="info">Client</Badge>}<Badge tone={c.onboarding.status === 'approved' ? 'success' : 'warning'}>Onboarding: {humanise(c.onboarding.status)}</Badge></span>}
        actions={can('clients.write') && !merged && <Button variant="secondary" icon={<Pencil className="h-4 w-4" />} onClick={() => setEdit(true)}>Edit details</Button>} />
      <ClientsSubnav />
      {merged && (
        <div role="note" className="mb-4 rounded-md border border-stone-300 bg-stone-100 px-4 py-3 text-sm">
          This record was merged into {c.merged_into ? <Link className="font-medium text-navy-700 underline" to={`/clients/${c.merged_into.id}`}>{c.merged_into.display_name}</Link> : 'another contact'}. It is kept for history; all references now point to the surviving record.
        </div>)}
      <Tabs value={t} onChange={setTab} tabs={[
        { id: 'overview', label: 'Overview' }, { id: 'roles', label: 'Roles on matters', badge: c.matters.length }, { id: 'relationships', label: 'Relationships', badge: c.relationships.length },
        { id: 'onboarding', label: 'Onboarding' }, { id: 'conflicts', label: 'Conflicts' }]} />
      <TabPanel id="overview" value={t}><Overview c={c} /></TabPanel>
      <TabPanel id="roles" value={t}><Roles c={c} /></TabPanel>
      <TabPanel id="relationships" value={t}><Relationships c={c} /></TabPanel>
      <TabPanel id="onboarding" value={t}><OnboardingPanel contact={c} /></TabPanel>
      <TabPanel id="conflicts" value={t}><ConflictTab c={c} /></TabPanel>
      {edit && <EditDialog c={c} onClose={() => setEdit(false)} />}
    </>
  )
}

/* ----------------------------------------------------------------------------------------------------------- overview */
function Overview({ c }: { c: ContactDetail }) {
  const { can } = useAuth()
  const [adding, setAdding] = useState(false)
  const del = useApiMutation((aid: string) => api.delete(`/clients/${c.id}/addresses/${aid}`), { invalidate: [['client', c.id]], successMessage: 'Address removed' })
  const [rm, setRm] = useState<Address | null>(null)
  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <Card title="Details" className="lg:col-span-2">
        <KeyValue columns={2} items={[
          { label: 'Client reference', value: c.client_ref ?? 'Not yet a client' }, { label: 'Preferred channel', value: humanise(c.preferred_channel) },
          { label: 'Email', value: c.email }, { label: 'Telephone', value: c.phone },
          ...(c.kind === 'individual' ? [{ label: 'Date of birth', value: c.date_of_birth ? formatDate(c.date_of_birth) : '—' }, { label: 'Title', value: c.title }] : [{ label: 'Company number', value: c.company_number }, { label: 'Registered name', value: c.org_name }]),
          { label: 'Responsible staff', value: c.responsible_name ?? 'Unassigned' }, { label: 'Aliases / former names', value: c.aliases.length ? c.aliases.join(', ') : '—' },
          { label: 'Created', value: formatDateTime(c.created_at) }, { label: 'Last updated', value: formatDateTime(c.updated_at) },
        ]} />
        {c.notes && <p className="mt-4 whitespace-pre-wrap border-t border-stone-100 pt-3 text-sm text-stone-700">{c.notes}</p>}
      </Card>
      <Card title="Addresses" actions={can('clients.write') && c.status !== 'merged' ? <Button size="sm" variant="secondary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setAdding(true)}>Add</Button> : undefined}>
        {c.addresses.length === 0 ? <p className="text-sm text-stone-600">No addresses recorded.</p> : (
          <ul className="space-y-4">{c.addresses.map((a) => (
            <li key={a.id} className="flex items-start justify-between gap-2 text-sm">
              <address className="not-italic"><span className="mb-0.5 flex gap-1"><Badge tone="neutral">{humanise(a.kind)}</Badge>{a.is_primary && <Badge tone="brass">Primary</Badge>}</span>{[a.line1, a.line2, a.city, a.county, a.postcode, a.country].filter(Boolean).join(', ')}</address>
              {can('clients.write') && <IconButton aria-label={`Remove address ${a.line1}`} size="sm" onClick={() => setRm(a)}><Trash2 className="h-3.5 w-3.5" /></IconButton>}
            </li>))}</ul>)}
      </Card>
      <AddAddressDialog open={adding} onClose={() => setAdding(false)} id={c.id} />
      <ConfirmDialog open={!!rm} onClose={() => setRm(null)} title="Remove this address?" confirmLabel="Remove" tone="danger" onConfirm={() => { del.mutate(rm!.id); setRm(null) }} />
    </div>
  )
}

function AddAddressDialog({ open, onClose, id }: { open: boolean; onClose: () => void; id: string }) {
  const [f, setF] = useState({ kind: 'correspondence', line1: '', line2: '', city: '', county: '', postcode: '', country: 'United Kingdom', is_primary: false })
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))
  const m = useApiMutation(() => api.post(`/clients/${id}/addresses`, { ...f, line2: f.line2 || null, city: f.city || null, county: f.county || null, postcode: f.postcode || null }), { invalidate: [['client', id]], successMessage: 'Address added', onSuccess: onClose })
  return (
    <Dialog open={open} onClose={onClose} title="Add address" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.line1.trim()} loading={m.isPending} onClick={() => m.mutate()}>Add address</Button></>}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Type"><Select value={f.kind} onChange={set('kind')}><option value="correspondence">Correspondence</option><option value="registered">Registered</option><option value="residential">Residential</option><option value="trading">Trading</option></Select></Field>
        <Field label="Address line 1" required><Input value={f.line1} onChange={set('line1')} /></Field>
        <Field label="Address line 2"><Input value={f.line2} onChange={set('line2')} /></Field><Field label="Town / city"><Input value={f.city} onChange={set('city')} /></Field>
        <Field label="County"><Input value={f.county} onChange={set('county')} /></Field><Field label="Postcode"><Input value={f.postcode} onChange={set('postcode')} /></Field>
      </div>
    </Dialog>
  )
}

/* ----------------------------------------------------------------------------------------------------------- edit */
function EditDialog({ c, onClose }: { c: ContactDetail; onClose: () => void }) {
  const { staff } = useStaff()
  const [f, setF] = useState({ display_name: c.display_name, email: c.email ?? '', phone: c.phone ?? '', preferred_channel: c.preferred_channel, aliases: c.aliases.join(', '), responsible_user_id: c.responsible_user_id ?? '', notes: c.notes ?? '', company_number: c.company_number ?? '', status: c.status })
  const [err, setErr] = useState<ApiError | null>(null)
  const qc = useApiQuery<ContactDetail>(['client', c.id], `/clients/${c.id}`, { enabled: false })
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))
  const m = useApiMutation(() => api.patch(`/clients/${c.id}`, { expected_version: c.version, display_name: f.display_name, email: f.email || null, phone: f.phone || null, preferred_channel: f.preferred_channel,
    aliases: f.aliases.split(',').map((a) => a.trim()).filter(Boolean), responsible_user_id: f.responsible_user_id || null, notes: f.notes || null, company_number: c.kind === 'organisation' ? f.company_number || null : undefined, status: f.status }),
    { invalidate: [['client', c.id], ['clients']], successMessage: 'Details saved', errorToast: false, onSuccess: onClose, onError: (e) => setErr(e) })
  return (
    <Dialog open onClose={onClose} size="lg" title="Edit details" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Save changes</Button></>}>
      <div className="space-y-3">
        {err && <div role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}{err.isConflict && err.code === 'version_conflict' && <> <button className="ml-1 font-semibold underline" onClick={() => { void qc.refetch(); onClose() }}>Reload latest</button></>}</div>}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Display name"><Input value={f.display_name} onChange={set('display_name')} /></Field>
          {c.kind === 'organisation' && <Field label="Company number"><Input value={f.company_number} onChange={set('company_number')} /></Field>}
          <Field label="Email"><Input type="email" value={f.email} onChange={set('email')} /></Field><Field label="Telephone"><Input value={f.phone} onChange={set('phone')} /></Field>
          <Field label="Preferred channel"><Select value={f.preferred_channel} onChange={set('preferred_channel')}><option value="email">Email</option><option value="phone">Phone</option><option value="post">Post</option><option value="portal">Client portal</option></Select></Field>
          <Field label="Responsible staff"><Select value={f.responsible_user_id} onChange={set('responsible_user_id')}><option value="">Unassigned</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
          <Field label="Status" hint="Onboarding approval sets a contact active."><Select value={f.status} onChange={set('status')}><option value="prospect">Prospect</option><option value="active">Active</option><option value="inactive">Inactive</option></Select></Field>
        </div>
        <Field label="Aliases / former names" hint="Comma-separated; used by conflict searches."><Input value={f.aliases} onChange={set('aliases')} /></Field>
        <Field label="Notes"><Textarea rows={3} value={f.notes} onChange={set('notes')} /></Field>
      </div>
    </Dialog>
  )
}

/* ----------------------------------------------------------------------------------------------------------- roles */
function Roles({ c }: { c: ContactDetail }) {
  const nav = useNavigate()
  const cols: Column<ContactMatterRoles>[] = [
    { key: 'ref', header: 'Matter', cell: (m) => <span className="tabular-nums font-medium">{m.reference}</span> },
    { key: 'title', header: 'Title', cell: (m) => m.title },
    { key: 'roles', header: 'Role(s) on this matter', cell: (m) => <span className="inline-flex flex-wrap gap-1">{m.roles.map((r) => <RoleBadge key={r} role={r} />)}</span> },
    { key: 'status', header: 'Matter status', cell: (m) => <StatusBadge status={m.status} /> },
  ]
  return (
    <div className="space-y-3">
      <p className="text-sm text-stone-700">Roles belong to the matter, not the contact: the same person can be the client on one matter, a counterparty on another, or a witness on a third.</p>
      <DataTable caption={`Matters involving ${c.display_name}`} columns={cols} rows={c.matters} rowKey={(m) => m.matter_id} onRowClick={(m) => nav(`/matters/${m.matter_id}`)} emptyTitle="Not yet a party to any matter you can see" />
      {c.restricted_matters_hidden > 0 && <p role="note" className="rounded-md bg-brass-50 px-4 py-2.5 text-sm text-navy-900">{c.restricted_matters_hidden} further matter{c.restricted_matters_hidden === 1 ? ' is' : 's are'} restricted and not shown to you. Their details are withheld by access controls.</p>}
    </div>
  )
}

/* ----------------------------------------------------------------------------------------------------------- relationships */
function Relationships({ c }: { c: ContactDetail }) {
  const { can } = useAuth()
  const [open, setOpen] = useState(false)
  const [rm, setRm] = useState<Relationship | null>(null)
  const del = useApiMutation((rid: string) => api.delete(`/clients/${c.id}/relationships/${rid}`), { invalidate: [['client', c.id]], successMessage: 'Relationship removed' })
  return (
    <Card title="Related entities & people" description="Relationships are searched by conflict checks (for example directors and spouses of a matched party)."
      actions={can('clients.write') && c.status !== 'merged' ? <Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setOpen(true)}>Add relationship</Button> : undefined}>
      {c.relationships.length === 0 ? <EmptyState title="No relationships recorded" description="Add directors, shareholders, spouses, trustees or other related parties." /> : (
        <ul className="divide-y divide-stone-200">{c.relationships.map((r) => (
          <li key={r.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
            <p className="flex flex-wrap items-center gap-1.5">
              {r.direction === 'outgoing' ? <><strong>{c.display_name}</strong><ArrowRight className="h-3.5 w-3.5 text-stone-500" aria-label="is" /><Badge tone="brass">{humanise(r.relation_type)}</Badge><Link className="text-navy-700 underline" to={`/clients/${r.other.id}`}>{r.other.display_name}</Link></>
                : <><Link className="text-navy-700 underline" to={`/clients/${r.other.id}`}>{r.other.display_name}</Link><ArrowRight className="h-3.5 w-3.5 text-stone-500" aria-label="is" /><Badge tone="brass">{humanise(r.relation_type)}</Badge><strong>{c.display_name}</strong></>}
              {r.start_date && <span className="text-xs text-stone-600">from {formatDate(r.start_date)}</span>}
            </p>
            {can('clients.write') && <IconButton aria-label="Remove relationship" size="sm" onClick={() => setRm(r)}><Trash2 className="h-3.5 w-3.5" /></IconButton>}
          </li>))}</ul>)}
      <AddRelationship open={open} onClose={() => setOpen(false)} c={c} />
      <ConfirmDialog open={!!rm} onClose={() => setRm(null)} title="Remove this relationship?" confirmLabel="Remove" tone="danger" onConfirm={() => { del.mutate(rm!.id); setRm(null) }} />
    </Card>
  )
}
function AddRelationship({ open, onClose, c }: { open: boolean; onClose: () => void; c: ContactDetail }) {
  const [other, setOther] = useState<{ id: string; display_name: string } | null>(null); const [type, setType] = useState('director_of'); const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post(`/clients/${c.id}/relationships`, { to_contact_id: other!.id, relation_type: type }), { invalidate: [['client', c.id]], errorToast: false, successMessage: 'Relationship added', onSuccess: () => { setOther(null); onClose() }, onError: (e) => setErr(errMsg(e)) })
  return (
    <Dialog open={open} onClose={onClose} title="Add relationship" description={`${c.display_name} is …`} footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!other} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Add</Button></>}>
      <div className="space-y-3">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Relationship"><Select value={type} onChange={(e) => setType(e.target.value)}>{RELATIONS.map((r) => <option key={r} value={r}>{humanise(r)}</option>)}</Select></Field>
        <Field label="Of / to (existing contact)" required>{(p) => <ContactPicker id={p.id} value={other} excludeId={c.id} onChange={(x) => setOther(x ? { id: x.id, display_name: x.display_name } : null)} />}</Field>
      </div>
    </Dialog>
  )
}

/* ----------------------------------------------------------------------------------------------------------- conflicts */
function ConflictTab({ c }: { c: Contact }) {
  const { can } = useAuth()
  const nav = useNavigate()
  const [run, setRun] = useState(false)
  const q = useApiQuery<Page<ConflictSearchRow>>(['conflicts', 'subject', c.id], `/conflicts/searches${qs({ subject_contact_id: c.id, limit: 20 })}`, { enabled: can('conflicts.run') })
  if (!can('conflicts.run')) return <EmptyState icon={<ShieldAlert className="h-5 w-5" />} title="Conflict searches need permission" description="Your role cannot run or view conflict searches (conflicts.run)." />
  const cols: Column<ConflictSearchRow>[] = [
    { key: 'at', header: 'Run', cell: (r) => formatDateTime(r.created_at) }, { key: 'by', header: 'By', cell: (r) => r.requested_by_name ?? '—' },
    { key: 'm', header: 'Matches', numeric: true, cell: (r) => r.match_count }, { key: 's', header: 'Outcome', cell: (r) => <StatusBadge status={r.status} /> }, { key: 'rv', header: 'Reviewer', cell: (r) => r.reviewed_by_name ?? 'Awaiting reviewer' },
  ]
  return (
    <Card title="Conflict searches for this contact" description="A human reviewer must record the outcome of a search before a matter can be opened for this client."
      actions={<Button size="sm" icon={<ShieldAlert className="h-4 w-4" />} onClick={() => setRun(true)}>Run conflict search</Button>}>
      <QueryBoundary query={q} what="conflict searches" empty={<EmptyState title="No searches yet" description="Run a search against this contact’s name, aliases and related entities." />}>
        {(d) => <DataTable caption="Conflict searches" columns={cols} rows={d.items} rowKey={(r) => r.id} onRowClick={(r) => nav(`/clients/conflicts/${r.id}`)} />}
      </QueryBoundary>
      <RunConflictDialog open={run} onClose={() => setRun(false)} subject={{ id: c.id, display_name: c.display_name }} />
    </Card>
  )
}
