import { useState } from 'react'
import { Link } from 'react-router-dom'
import { GitMerge } from 'lucide-react'
import { Badge, Button, Card, Dialog, EmptyState, Field, PageHeader, QueryBoundary, Tabs, TabPanel, StatusBadge, Textarea, ConfirmDialog } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatDateTime, humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle, useQueryParam } from '@/hooks'
import type { Page } from '@/types/api'
import type { Contact, DuplicatePair, MergeRecord } from '@/types/clients'
import { ClientsSubnav, errMsg } from './common'

const FIELDS: (keyof Contact)[] = ['display_name', 'title', 'first_name', 'last_name', 'org_name', 'company_number', 'email', 'phone', 'date_of_birth', 'preferred_channel', 'notes']
const WHAT_IS_PRESERVED = [
  'Every reference is re-pointed to the surviving record: matter parties and client links, relationships, addresses, onboarding records, documents, invoices and conflict history.',
  'The merged name and its aliases are added to the survivor’s aliases so future conflict searches still find them.',
  'The merged record is kept (status “merged”, linked to the survivor) with a full snapshot — nothing is deleted and the merge is audited.',
]

export default function DuplicatesPage() {
  usePageTitle('Duplicates & merges')
  useBreadcrumbs([{ label: 'Clients', to: '/clients' }, { label: 'Duplicates & merges' }])
  const [tab, setTab] = useQueryParam('tab')
  const t = tab ?? 'candidates'
  return (
    <>
      <PageHeader title="Duplicates & merges" description="Possible duplicate contacts are scored for review. Merging is a two-person workflow: one person proposes, a different authorised reviewer completes it." />
      <ClientsSubnav />
      <Tabs value={t} onChange={setTab} tabs={[{ id: 'candidates', label: 'Candidate duplicates' }, { id: 'merges', label: 'Merge requests' }]} />
      <TabPanel id="candidates" value={t}><Candidates /></TabPanel>
      <TabPanel id="merges" value={t}><Merges /></TabPanel>
    </>
  )
}

function Candidates() {
  const { can } = useAuth()
  const q = useApiQuery<{ items: DuplicatePair[]; basis: string }>(['clients', 'duplicates'], '/clients/duplicates')
  const [pair, setPair] = useState<DuplicatePair | null>(null)
  return (
    <QueryBoundary query={q} what="duplicates" empty={<EmptyState title="No likely duplicates" description="No contact pairs scored above the review threshold." />}>
      {(d) => (
        <div className="space-y-4">
          <p className="text-xs text-stone-600">{d.basis}</p>
          {d.items.map((p) => (
            <article key={p.a.id + p.b.id} className="rounded-lg border border-stone-200 bg-white shadow-panel">
              <header className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-200 px-5 py-3">
                <div className="flex items-center gap-2"><Badge tone={p.score >= 0.85 ? 'danger' : 'warning'}>Score {(p.score * 100).toFixed(0)}%</Badge>{p.reasons.map((r) => <Badge key={r} tone="neutral">{r}</Badge>)}</div>
                {p.merge_pending ? <Badge tone="info">Merge pending review</Badge> : can('clients.write') ? <Button size="sm" icon={<GitMerge className="h-4 w-4" />} onClick={() => setPair(p)}>Propose merge…</Button> : null}
              </header>
              <div className="grid gap-4 p-5 sm:grid-cols-2">{[p.a, p.b].map((c) => <ContactSummary key={c.id} c={c} />)}</div>
            </article>
          ))}
          {pair && <ProposeDialog pair={pair} onClose={() => setPair(null)} />}
        </div>
      )}
    </QueryBoundary>
  )
}

function ContactSummary({ c }: { c: Contact }) {
  return (
    <div className="text-sm">
      <Link to={`/clients/${c.id}`} className="font-medium text-navy-700 underline">{c.display_name}</Link> <StatusBadge status={c.status} /> {c.is_client && <Badge tone="info">Client</Badge>}
      <dl className="mt-1 grid grid-cols-[7rem_1fr] gap-x-2 gap-y-0.5 text-xs text-stone-700">
        <dt>Reference</dt><dd>{c.client_ref ?? '—'}</dd><dt>Email</dt><dd>{c.email ?? '—'}</dd><dt>Phone</dt><dd>{c.phone ?? '—'}</dd>
        <dt>{c.kind === 'organisation' ? 'Company no.' : 'Date of birth'}</dt><dd>{c.kind === 'organisation' ? c.company_number ?? '—' : c.date_of_birth ?? '—'}</dd>
        <dt>Created</dt><dd>{formatDateTime(c.created_at)}</dd>
      </dl>
    </div>
  )
}

function ProposeDialog({ pair, onClose }: { pair: DuplicatePair; onClose: () => void }) {
  const [survivorIsA, setSurvivorIsA] = useState(true)
  const [choices, setChoices] = useState<Record<string, 'survivor' | 'merged'>>({})
  const [reason, setReason] = useState(''); const [err, setErr] = useState<string | null>(null)
  const survivor = survivorIsA ? pair.a : pair.b, merged = survivorIsA ? pair.b : pair.a
  const differing = FIELDS.filter((f) => (survivor[f] ?? null) !== (merged[f] ?? null) && (survivor[f] || merged[f]))
  const m = useApiMutation(() => api.post('/clients/merges', { survivor_id: survivor.id, merged_id: merged.id, field_choices: Object.fromEntries(differing.map((f) => [f, choices[f] ?? 'survivor'])), reason: reason.trim() }),
    { invalidate: [['clients']], errorToast: false, successMessage: 'Merge proposed — awaiting a different reviewer', onSuccess: onClose, onError: (e) => setErr(errMsg(e)) })
  return (
    <Dialog open onClose={onClose} size="xl" title="Propose merge" description="Choose which record survives and, for each field that differs, which value to keep. Nothing changes until another authorised person completes the merge."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={reason.trim().length < 5} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Propose merge</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <fieldset className="grid gap-3 sm:grid-cols-2"><legend className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Surviving record</legend>
          {[true, false].map((isA) => (
            <label key={String(isA)} className={`flex cursor-pointer gap-3 rounded-md border p-3 ${survivorIsA === isA ? 'border-brass-500 bg-brass-50' : 'border-stone-300'}`}>
              <input type="radio" name="survivor" checked={survivorIsA === isA} onChange={() => setSurvivorIsA(isA)} className="mt-1 accent-navy-800" /><ContactSummary c={isA ? pair.a : pair.b} />
            </label>))}
        </fieldset>
        {differing.length > 0 && (
          <div>
            <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Fields that differ</h4>
            <table className="w-full text-sm"><caption className="sr-only">Per-field choices</caption><thead><tr className="text-left text-xs text-stone-600"><th className="py-1">Field</th><th>Survivor’s value</th><th>Merged record’s value</th></tr></thead>
              <tbody>{differing.map((f) => (
                <tr key={f} className="border-t border-stone-100"><th scope="row" className="py-1.5 pr-3 text-left font-medium">{humanise(f)}</th>
                  {(['survivor', 'merged'] as const).map((side) => (
                    <td key={side} className="py-1.5 pr-3"><label className="flex items-center gap-2"><input type="radio" name={`f-${f}`} className="accent-navy-800" checked={(choices[f] ?? 'survivor') === side} onChange={() => setChoices((c) => ({ ...c, [f]: side }))} />{String((side === 'survivor' ? survivor : merged)[f] ?? '—')}</label></td>))}
                </tr>))}</tbody></table>
          </div>)}
        <Field label="Reason for merge" required><Textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
        <ul className="list-disc space-y-1 rounded-md bg-ivory-100 py-3 pl-8 pr-4 text-xs text-stone-700"><li className="font-semibold list-none -ml-4">What is preserved</li>{WHAT_IS_PRESERVED.map((w) => <li key={w}>{w}</li>)}</ul>
      </div>
    </Dialog>
  )
}

function Merges() {
  const { can, me } = useAuth()
  const q = useApiQuery<Page<MergeRecord>>(['clients', 'merges'], '/clients/merges?limit=50')
  const [act, setAct] = useState<{ m: MergeRecord; kind: 'complete' | 'reject' } | null>(null)
  const run = useApiMutation(({ m, kind, note }: { m: MergeRecord; kind: 'complete' | 'reject'; note?: string }) => api.post(`/clients/merges/${m.id}/${kind}`, { note: note ?? null }),
    { invalidate: [['clients']], successMessage: (d) => ((d as MergeRecord).status === 'completed' ? 'Merge completed — references re-pointed' : 'Merge rejected'), onSuccess: () => setAct(null) })
  return (
    <QueryBoundary query={q} what="merge requests" empty={<EmptyState title="No merge requests" description="Propose a merge from the candidate duplicates tab." />}>
      {(d) => (
        <div className="space-y-4">
          {d.items.map((m) => {
            const own = m.requested_by === me?.user.id
            return (
              <Card key={m.id} title={<span className="flex items-center gap-2">Merge “{m.snapshot.display_name ?? 'record'}” <StatusBadge status={m.status} /></span>} description={`Proposed by ${m.requested_by_name} on ${formatDateTime(m.created_at)}`}
                actions={m.status === 'pending' && can('clients.merge') ? <><Button size="sm" variant="secondary" onClick={() => setAct({ m, kind: 'reject' })}>Reject</Button><Button size="sm" disabled={own} title={own ? 'A different reviewer must complete this merge' : undefined} onClick={() => setAct({ m, kind: 'complete' })}>Complete merge</Button></> : undefined}>
                <p className="text-sm">{m.reason}</p>
                <p className="mt-2 text-xs text-stone-600">Survivor: <Link className="text-navy-700 underline" to={`/clients/${m.survivor_id}`}>open surviving record</Link> · Merged record: <Link className="text-navy-700 underline" to={`/clients/${m.merged_id}`}>{m.snapshot.display_name ?? 'open'}</Link></p>
                {m.status === 'pending' && !can('clients.merge') && <p className="mt-2 text-xs text-stone-600">Completing a merge needs <code className="rounded bg-stone-100 px-1">clients.merge</code> and must be done by someone other than the proposer.</p>}
                {m.status === 'pending' && own && can('clients.merge') && <p className="mt-2 text-xs text-warn-700">You proposed this merge, so a different reviewer must complete it (four-eyes).</p>}
                {m.status === 'completed' && (
                  <div className="mt-3 rounded-md bg-ok-50 px-4 py-3 text-sm text-ok-700"><p className="font-semibold">Completed {formatDateTime(m.completed_at)} by {m.reviewed_by_name}. References re-pointed:</p>
                    <ul className="mt-1 flex flex-wrap gap-2">{Object.entries(m.repointed).map(([k, v]) => <li key={k}><Badge tone="success">{humanise(k)}: {v}</Badge></li>)}{Object.keys(m.repointed).length === 0 && <li>No dependent records needed re-pointing.</li>}</ul>
                    <p className="mt-2 text-xs">History preserved: the merged record remains retrievable and is linked to the survivor.</p></div>)}
              </Card>
            )
          })}
          <ConfirmDialog open={act?.kind === 'complete'} onClose={() => setAct(null)} tone="primary" confirmLabel="Complete merge" loading={run.isPending} title="Complete this merge?" requireReason="Reviewer note"
            description={<ul className="mt-2 list-disc space-y-1 pl-5 text-left text-xs">{WHAT_IS_PRESERVED.map((w) => <li key={w}>{w}</li>)}</ul>} onConfirm={(note) => run.mutate({ m: act!.m, kind: 'complete', note })} />
          <ConfirmDialog open={act?.kind === 'reject'} onClose={() => setAct(null)} tone="danger" confirmLabel="Reject merge" loading={run.isPending} title="Reject this merge?" requireReason="Reason" onConfirm={(note) => run.mutate({ m: act!.m, kind: 'reject', note })} />
        </div>
      )}
    </QueryBoundary>
  )
}
