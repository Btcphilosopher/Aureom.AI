import { useState } from 'react'
import { Link, Route, Routes } from 'react-router-dom'
import { ArrowUpRight, ShieldCheck } from 'lucide-react'
import { Badge, DataTable, DateTime, NotFoundState, PageHeader, StatusBadge, Tabs, type Column } from '@/components/ui'
import { qs, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { usePageTitle, useQueryParam } from '@/hooks'
import type { Page } from '@/types/api'
import type { ApprovalRow } from '@/types/admin'

const SCOPES = [['waiting_for_me', 'Waiting for me'], ['requested_by_me', 'Requested by me'], ['all', 'All (audit)']] as const

/** One-line summary of an approval payload: scalar values only, truncated. Payloads never hold confidential text. */
function summarise(p: Record<string, unknown>): string {
  const parts = Object.entries(p).filter(([, v]) => ['string', 'number', 'boolean'].includes(typeof v) && String(v).length < 60).slice(0, 4).map(([k, v]) => `${humanise(k)}: ${String(v)}`)
  return parts.join(' · ') || 'No summary recorded'
}

function Inbox() {
  usePageTitle('Approvals')
  const { can } = useAuth()
  const [scopeParam, setScope] = useQueryParam('scope')
  const [status, setStatus] = useQueryParam('status')
  const [offset, setOffset] = useState(0)
  const scope = SCOPES.find(([k]) => k === scopeParam)?.[0] ?? 'waiting_for_me'
  const q = useApiQuery<Page<ApprovalRow>>(['approvals', scope, status, offset], `/approvals${qs({ scope, status, limit: 25, offset })}`)
  const cols: Column<ApprovalRow>[] = [
    { key: 'k', header: 'Approval', cell: (a) => <span className="block"><span className="font-medium text-navy-900">{humanise(a.kind)}</span><span className="block text-xs text-stone-600">{humanise(a.subject_type)}{a.subject_id ? ` · ${a.subject_id.slice(0, 8)}…` : ''}</span></span> },
    { key: 'p', header: 'What is being approved', hideOnNarrow: true, cell: (a) => <span className="text-xs text-stone-700">{summarise(a.payload)}</span> },
    { key: 'r', header: 'Requested by', cell: (a) => <span className="block text-sm">{a.requested_by_name ?? '—'}<span className="block text-xs text-stone-500"><DateTime value={a.created_at} mode="relative" /></span></span> },
    { key: 'h', header: 'Bound to', hideOnNarrow: true, cell: (a) => <span title="SHA-256 of the exact content approved. If the content changes, this approval no longer applies." className="font-mono text-2xs text-stone-600">{a.payload_hash.slice(0, 10)}…</span> },
    { key: 's', header: 'Status', cell: (a) => <span className="block"><StatusBadge status={a.status} />{a.decided_by_name && <span className="mt-0.5 block text-2xs text-stone-500">by {a.decided_by_name}</span>}</span> },
    { key: 'o', header: <span className="sr-only">Open</span>, align: 'right', cell: (a) => a.href ? <Link to={a.href} onClick={(e) => e.stopPropagation()} className="inline-flex items-center gap-1 rounded text-xs font-semibold text-navy-700 hover:text-brass-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">{a.status === 'pending' ? 'Review & decide' : 'Open'}<ArrowUpRight className="h-3.5 w-3.5" aria-hidden /></Link> : <span className="text-xs text-stone-500">—</span> },
  ]
  return (
    <>
      <PageHeader eyebrow="Governance" title="Approvals" description="Actions waiting for a second person. Each approval is bound to the exact content it covers; if the content changes, a fresh approval is required. Decisions are made on the owning screen so the approved action runs with its own checks." />
      <Tabs label="Approval views" className="mb-4" value={scope} onChange={(id) => { setScope(id === 'waiting_for_me' ? null : id); setOffset(0) }}
        tabs={SCOPES.map(([id, label]) => ({ id, label, disabled: id === 'all' && !can('audit.read') }))} />
      <div className="mb-4 flex items-center gap-3 text-sm">
        <label htmlFor="ap-status" className="text-xs font-semibold uppercase tracking-wide text-stone-700">Status</label>
        <select id="ap-status" value={status ?? ''} onChange={(e) => { setStatus(e.target.value || null); setOffset(0) }} className="h-9 rounded-md border border-stone-300 bg-white px-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
          <option value="">{scope === 'waiting_for_me' ? 'Pending' : 'Any'}</option>{['pending', 'approved', 'rejected', 'superseded', 'cancelled'].map((s) => <option key={s} value={s}>{humanise(s)}</option>)}</select>
        {scope === 'waiting_for_me' && <Badge tone="neutral"><ShieldCheck className="mr-1 inline h-3 w-3" aria-hidden />Only items you have permission to decide and did not request yourself</Badge>}
      </div>
      <DataTable caption="Approvals" columns={cols} rows={q.data?.items} rowKey={(a) => a.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
        emptyTitle={scope === 'waiting_for_me' ? 'Nothing is waiting for your approval' : 'No approvals to show'} emptyDescription="Matter changes, invoice issues, journal postings, exports and AI-proposed actions needing a second person appear here."
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} />
    </>
  )
}

export default function ApprovalsSection() {
  return (
    <Routes>
      <Route index element={<Inbox />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
