import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Checkbox, Dialog, Field, Input, Textarea } from '@/components/ui'
import { useApiMutation } from '@/lib/api'
import { api } from '@/lib/api'
import type { CorrDetail } from '@/types/correspondence'
import { MatterSelect } from '@/pages/documents/common'
import { parseAddrs, validAddr } from './common'

export interface ComposeSeed { matterId?: string; replyTo?: CorrDetail }

/** Creates a DRAFT. Nothing is ever sent from here: sending needs a separate approval bound to the exact content. */
export function ComposeDialog({ open, onClose, seed }: { open: boolean; onClose: () => void; seed?: ComposeSeed }) {
  const nav = useNavigate()
  const [matter, setMatter] = useState(''), [to, setTo] = useState(''), [cc, setCc] = useState(''), [subject, setSubject] = useState(''), [body, setBody] = useState(''), [cv, setCv] = useState(false)
  useEffect(() => {
    if (!open) return
    const r = seed?.replyTo
    setMatter(r?.matter_id ?? seed?.matterId ?? ''); setTo(r ? (r.direction === 'inbound' ? r.from_addr : r.to_addrs.join(', ')) : ''); setCc('')
    setSubject(r ? (/^re:/i.test(r.subject) ? r.subject : `Re: ${r.subject}`) : ''); setBody(''); setCv(false)
  }, [open, seed])
  const bad = [...parseAddrs(to), ...parseAddrs(cc)].filter((a) => !validAddr(a))
  const create = useApiMutation(() => api.post<CorrDetail>('/correspondence', { matter_id: matter || null, reply_to_id: seed?.replyTo?.id ?? null, to_addrs: parseAddrs(to), cc_addrs: parseAddrs(cc), subject: subject.trim(), body_text: body, client_visible: cv }),
    { invalidate: [['correspondence']], successMessage: 'Draft saved — not sent', onSuccess: (c) => { onClose(); nav(`/correspondence/${c.id}`) } })
  return (
    <Dialog open={open} onClose={onClose} size="lg" title={seed?.replyTo ? 'Reply (draft)' : 'New draft'} description="Saved as a draft. It can only be sent after a person with approval rights approves this exact content."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={create.isPending} disabled={!subject.trim() || bad.length > 0} onClick={() => create.mutate()}>Save draft</Button></>}>
      <div className="space-y-4">
        <Field label="Matter" hint="Optional now; required before client-visible correspondence is useful.">{(p) => <MatterSelect {...p} value={matter} onChange={setMatter} emptyLabel="Not filed to a matter" />}</Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="To" hint="Comma-separated email addresses." error={bad.length ? `Not a valid address: ${bad[0]}` : undefined}>{(p) => <Input {...p} value={to} onChange={(e) => setTo(e.target.value)} />}</Field>
          <Field label="Cc">{(p) => <Input {...p} value={cc} onChange={(e) => setCc(e.target.value)} />}</Field>
        </div>
        <Field label="Subject" required>{(p) => <Input {...p} value={subject} onChange={(e) => setSubject(e.target.value)} />}</Field>
        <Field label="Message" hint="Plain text only.">{(p) => <Textarea {...p} rows={9} value={body} onChange={(e) => setBody(e.target.value)} />}</Field>
        <Checkbox label="Client-visible" hint="Appears in the client’s portal once sent. Internal comments never do — use internal notes for those." checked={cv} onChange={(e) => setCv(e.target.checked)} />
      </div>
    </Dialog>
  )
}
