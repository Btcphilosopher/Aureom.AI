import { useEffect, useState } from 'react'
import { Link, Outlet, useLocation, useParams } from 'react-router-dom'
import { Inbox as InboxIcon, Mail, MailPlus, Paperclip, RefreshCw, Search } from 'lucide-react'
import { Badge, Button, EmptyState, Field, Input, IntegrationUnavailable, PageHeader, Pagination, QueryBoundary, Select, SimulatedBanner, Tooltip, useToast } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useDebounce, useNewParam, usePageTitle, useQueryParams } from '@/hooks'
import { relativeTime } from '@/lib/format'
import type { Page } from '@/types/api'
import type { CorrItem } from '@/types/correspondence'
import type { IntegrationInfo } from '@/types/documents'
import { MatterSelect } from '@/pages/documents/common'
import { ComposeDialog } from './Compose'
import { CorrStatus } from './common'

const PARAMS = ['view', 'matter', 'direction', 'status', 'q', 'offset'] as const
const LIMIT = 20

export function Placeholder() {
  return <div className="hidden h-full min-h-[18rem] items-center justify-center rounded-lg border border-dashed border-stone-300 bg-white lg:flex"><EmptyState icon={<Mail className="h-8 w-8 text-stone-400" />} title="Select a message" description="Choose a message from the list to read it, file it to a matter, add internal notes or prepare a reply." /></div>
}

export default function Inbox() {
  usePageTitle('Correspondence')
  const { can } = useAuth()
  const toast = useToast()
  const { id } = useParams()
  const loc = useLocation()
  const { isNew, clear } = useNewParam()
  const [compose, setCompose] = useState(isNew)
  useEffect(() => { if (isNew) setCompose(true) }, [isNew])
  const [p, setP] = useQueryParams(PARAMS)
  const [qText, setQText] = useState(p.q ?? '')
  const dq = useDebounce(qText, 350)
  useEffect(() => { if ((p.q ?? '') !== dq) setP({ q: dq || null, offset: null }) }, [dq]) // eslint-disable-line react-hooks/exhaustive-deps
  const offset = Number(p.offset ?? 0) || 0
  const path = `/correspondence${qs({ unfiled: p.view === 'unfiled' ? true : p.view === 'filed' ? false : undefined, matter_id: p.matter, direction: p.direction, status: p.status, q: p.q, limit: LIMIT, offset })}`
  const list = useApiQuery<Page<CorrItem>>(['correspondence', 'list', path], path)
  const mail = useApiQuery<IntegrationInfo>(['integration', 'email'], '/integrations/email', { retry: false })
  const sync = useApiMutation(() => api.post<{ created: number; skipped: number; provider: string; mode: string; notice: string }>('/correspondence/sync'),
    { invalidate: [['correspondence']], onSuccess: (r) => toast.push({ tone: 'success', title: `Mailbox sync: ${r.created} new, ${r.skipped} already present`, description: r.notice || `Provider: ${r.provider}` }) })
  const unavailable = mail.data && !mail.data.available
  const filtered = !!(p.view || p.matter || p.direction || p.status || p.q)

  return (
    <div>
      <PageHeader title="Correspondence" description="Inbox, filing to matters, drafts and approved sending. Internal notes stay separate from client-visible communications."
        actions={<>
          {unavailable ? null : can('correspondence.write') ? <Button variant="secondary" onClick={() => sync.mutate()} loading={sync.isPending}><RefreshCw className="h-4 w-4" aria-hidden />Sync demo mailbox</Button>
            : <Tooltip text="Needs correspondence.write"><span><Button variant="secondary" disabled>Sync demo mailbox</Button></span></Tooltip>}
          {can('correspondence.write') && <Button onClick={() => setCompose(true)}><MailPlus className="h-4 w-4" aria-hidden />New draft</Button>}
        </>} />
      {unavailable ? <IntegrationUnavailable name={mail.data?.name ?? 'Email'} setupHint={mail.data?.setup_hint} message="The email integration is not available, so the mailbox cannot be synchronised. Existing messages and drafts remain accessible." className="mb-4" />
        : mail.data?.mode === 'mock' && <SimulatedBanner className="mb-4"><strong>{mail.data.name}:</strong> a labelled MOCK mailbox. Synced messages are synthetic demonstration e-mails and “sent” messages are only recorded — nothing leaves the system. <span className="text-xs">If live: {mail.data.data_leaves_application}</span></SimulatedBanner>}

      <div className="grid gap-4 lg:grid-cols-[minmax(20rem,26rem)_1fr]">
        <div className={`${id ? 'hidden lg:block' : ''} min-w-0`}>
          <div className="mb-3 space-y-3 rounded-lg border border-stone-200 bg-white p-3 shadow-panel" role="search" aria-label="Filter correspondence">
            <div className="relative"><label htmlFor="corr-q" className="sr-only">Search correspondence</label><Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-stone-500" aria-hidden /><Input id="corr-q" className="pl-8" placeholder="Search subject and text" value={qText} onChange={(e) => setQText(e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-2">
              <Field label="Filing">{(f) => <Select {...f} value={p.view ?? ''} onChange={(e) => setP({ view: e.target.value || null, offset: null })}><option value="">All</option><option value="unfiled">Unfiled</option><option value="filed">Filed to a matter</option></Select>}</Field>
              <Field label="Direction">{(f) => <Select {...f} value={p.direction ?? ''} onChange={(e) => setP({ direction: e.target.value || null, offset: null })}><option value="">Both</option><option value="inbound">Inbound</option><option value="outbound">Outbound</option></Select>}</Field>
              <Field label="Status">{(f) => <Select {...f} value={p.status ?? ''} onChange={(e) => setP({ status: e.target.value || null, offset: null })}><option value="">Any</option>{['received', 'filed', 'draft', 'pending_approval', 'approved', 'sent', 'failed'].map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</Select>}</Field>
              <Field label="Matter">{(f) => <MatterSelect {...f} value={p.matter ?? ''} onChange={(v) => setP({ matter: v || null, offset: null })} />}</Field>
            </div>
            {filtered && <Button size="sm" variant="ghost" onClick={() => { setQText(''); setP({ view: null, matter: null, direction: null, status: null, q: null, offset: null }) }}>Clear filters</Button>}
          </div>

          <QueryBoundary query={list} what="inbox" empty={<EmptyState icon={<InboxIcon className="h-8 w-8 text-stone-400" />} title={filtered ? 'No messages match these filters' : 'Your inbox is empty'}
            description={filtered ? 'Clear a filter to see more. Messages on restricted matters you cannot access are never listed.' : 'Use “Sync demo mailbox” to pull in synthetic demonstration e-mails.'} />}>
            {(d) => (
              <>
                <ul className="divide-y divide-stone-200 overflow-hidden rounded-lg border border-stone-200 bg-white shadow-panel" aria-label="Messages">
                  {d.items.map((c) => {
                    const active = c.id === id
                    return (
                      <li key={c.id}>
                        <Link to={{ pathname: `/correspondence/${c.id}`, search: loc.search }} aria-current={active ? 'true' : undefined}
                          className={`block px-4 py-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500 ${active ? 'bg-brass-50' : 'hover:bg-ivory-100'}`}>
                          <div className="flex items-start justify-between gap-2">
                            <p className={`min-w-0 truncate text-sm ${!c.is_read && c.direction === 'inbound' ? 'font-bold text-navy-950' : 'font-medium text-navy-900'}`}>
                              {!c.is_read && c.direction === 'inbound' && <span className="mr-1.5 inline-block h-2 w-2 rounded-full bg-brass-500 align-middle" aria-label="Unread" />}{c.subject}</p>
                            <span className="shrink-0 text-2xs text-stone-600">{relativeTime(c.received_at ?? c.sent_at ?? c.created_at)}</span>
                          </div>
                          <p className="truncate text-xs text-stone-600">{c.direction === 'inbound' ? c.from_addr : `To ${c.to_addrs.join(', ') || '—'}`}</p>
                          <p className="mt-0.5 line-clamp-2 text-xs text-stone-700">{c.preview}</p>
                          <div className="mt-1.5 flex flex-wrap items-center gap-1.5"><CorrStatus status={c.status} />{c.matter_reference ? <Badge>{c.matter_reference}</Badge> : <Badge tone="warning">Unfiled</Badge>}
                            {c.has_attachments && <span className="inline-flex items-center gap-0.5 text-2xs text-stone-600"><Paperclip className="h-3 w-3" aria-hidden /><span className="sr-only">Has attachments</span></span>}
                            {c.client_visible && <Badge tone="info">Client-visible</Badge>}</div>
                        </Link>
                      </li>
                    )
                  })}
                </ul>
                <div className="mt-2"><Pagination total={d.total} limit={LIMIT} offset={offset} onChange={(o) => setP({ offset: o ? String(o) : null })} /></div>
              </>
            )}
          </QueryBoundary>
        </div>
        <div className={`${id ? '' : 'hidden lg:block'} min-w-0`}><Outlet /></div>
      </div>
      <ComposeDialog open={compose} onClose={() => { setCompose(false); clear() }} />
    </div>
  )
}
