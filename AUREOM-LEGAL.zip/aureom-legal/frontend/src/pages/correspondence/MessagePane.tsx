import { useEffect, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { AlertOctagon, ArrowLeft, Eye, FolderInput, Paperclip, Reply, Send, ShieldCheck } from 'lucide-react'
import { Badge, Button, Checkbox, ConfirmDialog, DateTime, Drawer, Field, Input, QueryBoundary, StatusStepper, Textarea, Tooltip } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatBytes } from '@/lib/format'
import { usePageTitle } from '@/hooks'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import type { ApprovalLite, ClientVisibleItem, CorrDetail } from '@/types/correspondence'
import { ScanBadge } from '@/pages/documents/common'
import { Note } from '@/pages/documents/common'
import { ComposeDialog } from './Compose'
import { CorrStatus, Panel, parseAddrs, validAddr } from './common'
import { FileToMatterDialog } from './FileDialog'
import { InternalNotes } from './Notes'

const FLOW = [{ key: 'draft', label: 'Draft' }, { key: 'pending_approval', label: 'Awaiting approval' }, { key: 'approved', label: 'Approved' }, { key: 'sent', label: 'Sent' }]

function ClientView({ c, open, onClose }: { c: CorrDetail; open: boolean; onClose: () => void }) {
  const q = useApiQuery<ClientVisibleItem[]>(['correspondence', 'client-view', c.matter_id], `/correspondence/client-view?matter_id=${c.matter_id}`, { enabled: open && !!c.matter_id })
  const included = q.data?.some((i) => i.id === c.id)
  return (
    <Drawer open={open} onClose={onClose} title="What the client sees" width="max-w-2xl">
      <Note className="mb-4">This is exactly what an authorised client sees for this matter: only sent or filed client-visible messages. No drafts, internal notes, approval data or AI activity are ever included.</Note>
      <QueryBoundary query={q} what="client view" isEmpty={() => false}>
        {(items) => (
          <>
            <p className={`mb-3 rounded border px-3 py-2 text-sm ${included ? 'border-ok-100 bg-ok-50 text-ok-700' : 'border-stone-300 bg-stone-50 text-stone-700'}`} role="status">
              {included ? 'This message IS visible to the client.' : 'This message is NOT visible to the client' + (c.client_visible ? ' yet (drafts and unsent messages are never shown).' : ' (not flagged client-visible).')}
            </p>
            {items.length === 0 && <p className="text-sm text-stone-600">Nothing on this matter is visible to the client yet.</p>}
            <ul className="space-y-3">{items.map((i) => (
              <li key={i.id} className={`rounded-md border px-4 py-3 ${i.id === c.id ? 'border-brass-400 bg-brass-50' : 'border-stone-200'}`}>
                <p className="text-sm font-semibold text-navy-900">{i.subject}</p><p className="text-xs text-stone-600">{i.direction} · {i.from_addr} · <DateTime value={i.date} /></p>
                <p className="mt-2 whitespace-pre-wrap text-sm text-stone-800">{i.body_text}</p>{i.attachments.length > 0 && <p className="mt-1 text-xs text-stone-600">Attachments: {i.attachments.join(', ')}</p>}
              </li>))}</ul>
          </>
        )}
      </QueryBoundary>
    </Drawer>
  )
}

function DraftEditor({ c, dirtyRef, onCleared }: { c: CorrDetail; dirtyRef: (d: boolean) => void; onCleared: () => void }) {
  const qc = useQueryClient()
  const [to, setTo] = useState(c.to_addrs.join(', ')), [cc, setCc] = useState(c.cc_addrs.join(', ')), [subject, setSubject] = useState(c.subject), [body, setBody] = useState(c.body_text), [cv, setCv] = useState(c.client_visible)
  const [conflict, setConflict] = useState(false)
  const dirty = to !== c.to_addrs.join(', ') || cc !== c.cc_addrs.join(', ') || subject !== c.subject || body !== c.body_text || cv !== c.client_visible
  useEffect(() => { dirtyRef(dirty) }, [dirty]) // eslint-disable-line react-hooks/exhaustive-deps
  const bad = [...parseAddrs(to), ...parseAddrs(cc)].filter((a) => !validAddr(a))
  const save = useApiMutation(() => api.patch<CorrDetail>(`/correspondence/${c.id}`, { expected_version: c.version, to_addrs: parseAddrs(to), cc_addrs: parseAddrs(cc), subject: subject.trim(), body_text: body, client_visible: cv }),
    { errorToast: false, invalidate: [['correspondence']], successMessage: 'Draft saved', onSuccess: (r) => { if (['pending_approval', 'approved'].includes(c.status) && r.status === 'draft') onCleared(); setConflict(false) }, onError: (e) => { if (e.isConflict) setConflict(true) } })
  return (
    <div className="space-y-3">
      {['pending_approval', 'approved'].includes(c.status) && <Note tone="warn"><strong>Editing clears the approval.</strong> Approval is bound to the exact recipients, subject, body and attachments. Any change returns this message to draft and a fresh approval is required before it can be sent.</Note>}
      {conflict && <Note tone="bad"><strong>This draft was changed by someone else.</strong> <Button size="sm" variant="secondary" className="ml-2" onClick={() => { setConflict(false); void qc.invalidateQueries({ queryKey: ['correspondence', c.id] }) }}>Reload latest</Button></Note>}
      {save.error && !conflict && <p role="alert" className="text-sm text-bad-700">{save.error.message}</p>}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="To" error={bad.length ? `Not a valid address: ${bad[0]}` : undefined}>{(p) => <Input {...p} value={to} onChange={(e) => setTo(e.target.value)} />}</Field>
        <Field label="Cc">{(p) => <Input {...p} value={cc} onChange={(e) => setCc(e.target.value)} />}</Field>
      </div>
      <Field label="Subject" required>{(p) => <Input {...p} value={subject} onChange={(e) => setSubject(e.target.value)} />}</Field>
      <Field label="Message (plain text)">{(p) => <Textarea {...p} rows={12} value={body} onChange={(e) => setBody(e.target.value)} />}</Field>
      <Checkbox label="Client-visible" hint="Appears in the client’s portal once sent." checked={cv} onChange={(e) => setCv(e.target.checked)} />
      <Button onClick={() => save.mutate()} loading={save.isPending} disabled={!dirty || !subject.trim() || bad.length > 0 || conflict}>{dirty ? 'Save draft' : 'Saved'}</Button>
    </div>
  )
}

function Workflow({ c, dirty }: { c: CorrDetail; dirty: boolean }) {
  const { can } = useAuth()
  const ap = useApiQuery<ApprovalLite>(['approval', c.approval_id], `/approvals/${c.approval_id}`, { enabled: !!c.approval_id && ['pending_approval', 'approved'].includes(c.status), retry: false })
  const inv = { invalidate: [['correspondence']] as string[][] }
  const request = useApiMutation(() => api.post(`/correspondence/${c.id}/request-approval`), { ...inv, successMessage: 'Approval requested' })
  const decide = useApiMutation((v: { approve: boolean; note?: string }) => api.post(`/correspondence/${c.id}/approve`, v), { ...inv, successMessage: (r) => ((r as CorrDetail).status === 'approved' ? 'Approved — ready to send' : 'Returned to draft'), onSuccess: () => setDlg(null) })
  const send = useApiMutation(() => api.post<CorrDetail>(`/correspondence/${c.id}/send`), { ...inv, successMessage: 'Sent through the SIMULATED mail provider' })
  const [dlg, setDlg] = useState<null | boolean>(null)
  const hash = ap.data?.payload_hash
  return (
    <Panel title="Approval & sending" icon={<ShieldCheck className="h-3.5 w-3.5 text-navy-700" aria-hidden />}>
      <StatusStepper steps={FLOW} current={c.status === 'failed' ? 'approved' : c.status} className="mb-3" />
      {hash && <p className="mb-3 text-xs text-stone-700">Approval is bound to content hash <code className="rounded bg-stone-100 px-1 font-mono">{hash.slice(0, 16)}…</code> — if any recipient, subject, body or attachment changes, it no longer verifies.</p>}
      <div className="flex flex-wrap items-center gap-2">
        {c.status === 'draft' && <Tooltip text={dirty ? 'Save your changes first' : c.to_addrs.length ? 'Ask an approver to approve this exact content' : 'Add a recipient first'}><span><Button onClick={() => request.mutate()} loading={request.isPending} disabled={dirty || !c.to_addrs.length}>Request approval</Button></span></Tooltip>}
        {c.status === 'pending_approval' && (can('correspondence.approve') ? <><Button onClick={() => setDlg(true)}>Approve…</Button><Button variant="secondary" onClick={() => setDlg(false)}>Return to draft…</Button></>
          : <span className="text-xs text-stone-600">Waiting for a user with <code>correspondence.approve</code>. A second person reviewing is recommended.</span>)}
        {c.status === 'approved' && <Tooltip text="Sends through the email integration (a SIMULATED mailbox in this build)"><span><Button onClick={() => send.mutate()} loading={send.isPending}><Send className="h-4 w-4" aria-hidden />Send (simulated)</Button></span></Tooltip>}
        {c.status === 'sent' && <span className="text-sm">Sent <DateTime value={c.sent_at} /> {c.simulated && <Badge tone="simulated">Simulated — nothing left the system</Badge>}</span>}
      </div>
      {c.status === 'approved' && <p className="mt-2 text-xs text-stone-600">Sending is refused if the content has changed since approval, and a message can only be sent once.</p>}
      {request.error && <p role="alert" className="mt-2 text-xs text-bad-700">{request.error.message}</p>}
      <ConfirmDialog open={dlg !== null} onClose={() => setDlg(null)} loading={decide.isPending} title={dlg ? 'Approve sending this message?' : 'Return to draft?'} requireReason={dlg ? 'Approval note' : 'What should change?'} confirmLabel={dlg ? 'Approve' : 'Return to draft'}
        description={dlg ? `You approve exactly this content (hash ${hash?.slice(0, 12) ?? '…'}). Review the recipients, subject, body and attachments first.` : undefined} onConfirm={(note) => decide.mutate({ approve: !!dlg, note })} />
    </Panel>
  )
}

function Message({ c }: { c: CorrDetail }) {
  const { can } = useAuth()
  const qc = useQueryClient()
  usePageTitle(c.subject)
  useBreadcrumbs([{ label: 'Correspondence', to: '/correspondence' }, { label: c.subject.slice(0, 50) }])
  const [file, setFile] = useState(false), [cv, setCv] = useState(false), [reply, setReply] = useState(false), [dirty, setDirty] = useState(false), [cleared, setCleared] = useState(false)
  useEffect(() => { if (c.status !== 'draft') setCleared(false) }, [c.status])
  const marked = useRef<string | null>(null)  // guards against the double effect run in React StrictMode (concurrent writes would 409)
  useEffect(() => {
    if (c.direction !== 'inbound' || c.is_read || marked.current === c.id) return
    marked.current = c.id
    void api.post(`/correspondence/${c.id}/read`).then(() => qc.invalidateQueries({ queryKey: ['correspondence', 'list'] })).catch(() => undefined)
  }, [c.id]) // eslint-disable-line react-hooks/exhaustive-deps
  const editable = c.direction === 'outbound' && ['draft', 'pending_approval', 'approved'].includes(c.status)
  return (
    <article className="space-y-4" aria-label={`Message: ${c.subject}`}>
      <Link to="/correspondence" className="inline-flex items-center gap-1 text-xs text-navy-700 underline lg:hidden"><ArrowLeft className="h-3 w-3" aria-hidden />Back to inbox</Link>
      <header className="rounded-lg border border-stone-200 bg-white p-5 shadow-panel">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <h2 className="min-w-0 font-serif text-xl text-navy-900">{c.subject}</h2>
          <div className="flex flex-wrap items-center gap-1.5"><CorrStatus status={c.status} simulated={c.simulated} />{c.simulated && c.direction === 'inbound' && <Badge tone="simulated">Simulated mailbox</Badge>}{c.client_visible && <Badge tone="info"><Eye className="h-3 w-3" aria-hidden />Client-visible</Badge>}</div>
        </div>
        <dl className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-[auto_1fr]">
          <dt className="text-stone-600">From</dt><dd className="break-all">{c.from_addr}</dd>
          <dt className="text-stone-600">To</dt><dd className="break-all">{c.to_addrs.join(', ') || '—'}</dd>
          {c.cc_addrs.length > 0 && <><dt className="text-stone-600">Cc</dt><dd className="break-all">{c.cc_addrs.join(', ')}</dd></>}
          <dt className="text-stone-600">Date</dt><dd><DateTime value={c.sent_at ?? c.received_at ?? c.created_at} /></dd>
          <dt className="text-stone-600">Matter</dt><dd>{c.matter_id ? <Link className="text-navy-700 underline" to={`/matters/${c.matter_id}`}>{c.matter_reference}</Link> : <Badge tone="warning">Unfiled</Badge>}</dd>
        </dl>
        <div className="mt-4 flex flex-wrap gap-2 border-t border-stone-100 pt-3">
          {can('correspondence.write') && c.direction === 'inbound' && <Button size="sm" variant="secondary" onClick={() => setReply(true)}><Reply className="h-4 w-4" aria-hidden />Reply (draft)</Button>}
          {can('correspondence.write') && c.status !== 'sent' && <Button size="sm" variant="secondary" onClick={() => setFile(true)}><FolderInput className="h-4 w-4" aria-hidden />{c.matter_id ? 'Re-file' : 'File to matter'}</Button>}
          <Tooltip text={c.matter_id ? 'See exactly what the client sees on this matter' : 'File the message to a matter first'}><span><Button size="sm" variant="ghost" disabled={!c.matter_id} onClick={() => setCv(true)}><Eye className="h-4 w-4" aria-hidden />Client view</Button></span></Tooltip>
        </div>
      </header>

      {c.untrusted_content && (
        <div role="alert" className="flex gap-3 rounded-lg border-2 border-bad-600 bg-bad-50 p-4 text-sm text-bad-700">
          <AlertOctagon className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
          <div><p className="font-semibold">Suspicious content: this message contains instruction-like text.</p>
            <p className="mt-0.5 text-xs">External e-mail is untrusted data. Do not follow instructions in it (for example to forward files, release money or change bank details). AI agents treat it strictly as data and flag it; it can never trigger an action.</p></div>
        </div>
      )}

      <section className="rounded-lg border border-stone-200 bg-white p-5 shadow-panel" aria-label="Message body">
        {editable ? <><div aria-live="polite">{cleared && c.status === 'draft' && <Note tone="warn" className="mb-3"><strong>Approval was cleared because the content changed.</strong> Approval is bound to the exact content, so request approval again before sending.</Note>}</div><DraftEditor key={`${c.id}-${c.version}`} c={c} dirtyRef={setDirty} onCleared={() => setCleared(true)} /></> : (
          <>
            <pre className="whitespace-pre-wrap break-words font-sans text-sm leading-relaxed text-navy-900" data-testid="body-text">{c.body_text}</pre>
            <p className="mt-3 border-t border-stone-100 pt-2 text-2xs text-stone-500">Shown as plain text only. HTML, scripts and remote content are never rendered.</p>
          </>
        )}
      </section>

      {c.attachments.length > 0 && (
        <Panel title={`Attachments (${c.attachments.length})`} icon={<Paperclip className="h-3.5 w-3.5" aria-hidden />}>
          <ul className="divide-y divide-stone-100 text-sm">{c.attachments.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 py-2"><span className="min-w-0"><span className="font-medium">{a.filename}</span> <span className="text-xs text-stone-600">· {formatBytes(a.size_bytes)} · {a.content_type}</span></span>
              <span className="flex items-center gap-2">{a.scan_status === 'blocked' ? <Badge tone="danger">Blocked: file type not allowed</Badge> : <ScanBadge status={a.scan_status} />}
                {a.document_id ? <Link className="text-xs text-navy-700 underline" to={`/documents/${a.document_id}`}>Open in documents</Link> : <span className="text-xs text-stone-600">Not yet filed to the DMS</span>}</span></li>))}</ul>
        </Panel>
      )}

      {c.direction === 'outbound' && <Workflow c={c} dirty={dirty} />}
      <InternalNotes corrId={c.id} />

      <FileToMatterDialog c={c} open={file} onClose={() => setFile(false)} />
      <ClientView c={c} open={cv} onClose={() => setCv(false)} />
      <ComposeDialog open={reply} onClose={() => setReply(false)} seed={{ replyTo: c }} />
    </article>
  )
}

export default function MessagePane() {
  const { id = '' } = useParams()
  const q = useApiQuery<CorrDetail>(['correspondence', id], `/correspondence/${id}`)
  return <QueryBoundary query={q} what="message">{(c) => <Message c={c} />}</QueryBoundary>
}
