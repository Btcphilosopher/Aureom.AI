import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button, Dialog, Field } from '@/components/ui'
import { api, useApiMutation } from '@/lib/api'
import type { CorrDetail } from '@/types/correspondence'
import { MatterSelect } from '@/pages/documents/common'

interface FileResult { filed_documents: { filename: string; document_id: string }[]; skipped_attachments: { filename: string; reason: string }[] }

export function FileToMatterDialog({ c, open, onClose }: { c: CorrDetail; open: boolean; onClose: () => void }) {
  const [matter, setMatter] = useState(c.matter_id ?? '')
  const [result, setResult] = useState<FileResult | null>(null)
  const [refile, setRefile] = useState(!!c.matter_id)
  // reset only when the dialog opens: filing changes c.matter_id and must not wipe the result panel
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (open) { setMatter(c.matter_id ?? ''); setResult(null); setRefile(!!c.matter_id) } }, [open])
  const file = useApiMutation(() => api.post<FileResult>(`/correspondence/${c.id}/file`, { matter_id: matter }), { invalidate: [['correspondence'], ['documents']], successMessage: 'Filed to matter', onSuccess: setResult })
  return (
    <Dialog open={open} onClose={onClose} title={refile ? 'Re-file to another matter' : 'File to matter'} description="The message is filed to the matter and its clean attachments are saved to the document system as new documents."
      footer={result ? <Button onClick={onClose}>Done</Button> : <><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={file.isPending} disabled={!matter} onClick={() => file.mutate()}>File message</Button></>}>
      {result ? (
        <div className="space-y-3 text-sm" aria-live="polite">
          <p className="font-medium text-ok-700">Filed.</p>
          {result.filed_documents.length > 0 && <div><p className="text-xs font-semibold uppercase text-stone-600">Attachments saved as documents</p><ul className="list-inside list-disc">{result.filed_documents.map((d) => <li key={d.document_id}><Link className="text-navy-700 underline" to={`/documents/${d.document_id}`}>{d.filename}</Link></li>)}</ul></div>}
          {result.skipped_attachments.length > 0 && <div><p className="text-xs font-semibold uppercase text-warn-700">Attachments not filed</p><ul className="list-inside list-disc text-warn-700">{result.skipped_attachments.map((d) => <li key={d.filename}>{d.filename} — {d.reason}</li>)}</ul></div>}
          {!result.filed_documents.length && !result.skipped_attachments.length && <p className="text-stone-600">This message had no attachments to file.</p>}
        </div>
      ) : <Field label="Matter" required hint="Restricted matters you cannot access are not listed.">{(p) => <MatterSelect {...p} value={matter} onChange={setMatter} allowEmpty={false} />}</Field>}
    </Dialog>
  )
}
