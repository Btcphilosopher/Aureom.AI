import type { ReactNode } from 'react'
import { Badge } from '@/components/ui'
import type { Tone } from '@/lib/status'

export const parseAddrs = (s: string): string[] => s.split(/[;,\n]/).map((x) => x.trim()).filter(Boolean)
/** Accepts `person@firm.example` and `Display Name <person@firm.example>` (the forms the API accepts). */
export const validAddr = (a: string) => {
  const m = a.match(/<([^<>]+)>\s*$/)
  return /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test((m ? m[1]! : a).trim())
}

const LABEL: Record<string, string> = { received: 'Received', filed: 'Filed', draft: 'Draft', pending_approval: 'Awaiting approval', approved: 'Approved to send', sent: 'Sent', failed: 'Failed' }
const TONE: Record<string, Tone> = { received: 'info', filed: 'success', draft: 'neutral', pending_approval: 'warning', approved: 'success', sent: 'success', failed: 'danger' }
export function CorrStatus({ status, simulated }: { status: string; simulated?: boolean }) {
  return <span className="inline-flex gap-1"><Badge tone={TONE[status] ?? 'neutral'}>{LABEL[status] ?? status}</Badge>{status === 'sent' && simulated && <Badge tone="simulated">Simulated send</Badge>}</span>
}

export function Panel({ title, icon, tone = 'plain', children, className = '' }: { title: ReactNode; icon?: ReactNode; tone?: 'plain' | 'internal'; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border p-4 ${tone === 'internal' ? 'border-dashed border-brass-400 bg-brass-50/50' : 'border-stone-200 bg-white shadow-panel'} ${className}`}>
      <h3 className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-navy-900">{icon}{title}</h3>
      {children}
    </section>
  )
}
