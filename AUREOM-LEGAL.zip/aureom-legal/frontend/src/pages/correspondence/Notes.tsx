import { useState } from 'react'
import { Lock } from 'lucide-react'
import { Button, DateTime, QueryBoundary, Textarea } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import type { Note } from '@/types/correspondence'
import { Panel } from './common'

/** Internal notes: visually and structurally separate from client-visible correspondence. */
export function InternalNotes({ corrId }: { corrId: string }) {
  const { can } = useAuth()
  const [text, setText] = useState('')
  const q = useApiQuery<Note[]>(['correspondence', corrId, 'notes'], `/correspondence/${corrId}/notes`)
  const add = useApiMutation(() => api.post(`/correspondence/${corrId}/notes`, { body: text.trim() }), { invalidate: [['correspondence', corrId, 'notes']], successMessage: 'Internal note added', onSuccess: () => setText('') })
  return (
    <Panel tone="internal" title={<>Internal notes <span className="font-normal normal-case text-brass-700">— Internal: never sent, not visible to the client</span></>} icon={<Lock className="h-3.5 w-3.5 text-brass-600" aria-hidden />}>
      <QueryBoundary query={q} what="notes" loading={<p className="text-xs text-stone-600">Loading notes…</p>} empty={<p className="text-xs text-stone-600">No internal notes on this message.</p>}>
        {(notes) => <ul className="space-y-2">{notes.map((n) => <li key={n.id} className="rounded border border-brass-200 bg-white px-3 py-2 text-sm"><p className="whitespace-pre-wrap text-navy-900">{n.body}</p><p className="mt-1 text-2xs text-stone-600">{n.author_name} · <DateTime value={n.created_at} /></p></li>)}</ul>}
      </QueryBoundary>
      {can('correspondence.write') && (
        <div className="mt-3 space-y-2">
          <label htmlFor={`note-${corrId}`} className="sr-only">Add an internal note</label>
          <Textarea id={`note-${corrId}`} rows={2} value={text} onChange={(e) => setText(e.target.value)} placeholder="Add an internal note (never sent to anyone)…" />
          <Button size="sm" variant="secondary" disabled={!text.trim()} loading={add.isPending} onClick={() => add.mutate()}>Add internal note</Button>
        </div>
      )}
    </Panel>
  )
}
