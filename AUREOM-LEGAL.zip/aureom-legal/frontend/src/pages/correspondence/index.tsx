import { Route, Routes } from 'react-router-dom'
import { NotFoundState } from '@/components/ui'
import Inbox, { Placeholder } from './Inbox'
import MessagePane from './MessagePane'

export default function CorrespondenceSection() {
  return (
    <Routes>
      <Route element={<Inbox />}>
        <Route index element={<Placeholder />} />
        <Route path=":id" element={<MessagePane />} />
      </Route>
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
