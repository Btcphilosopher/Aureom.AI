import { useState, type ReactNode } from 'react'
import { Link, Navigate, Route, Routes } from 'react-router-dom'
import { AlertTriangle, ArrowUpRight, Bot, CalendarClock, FileText, Gavel, Inbox, Info, ListChecks, Mail, ShieldCheck, Wallet } from 'lucide-react'
import { Badge, Card, DateTime, Money, NotFoundState, PageHeader, Select, Skeleton, StatusBadge } from '@/components/ui'
import { ApiError, qs, useApiQuery } from '@/lib/api'
import { useAuth, useOffice } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { cn } from '@/lib/cn'
import { usePageTitle, useQueryParams } from '@/hooks'
import type { HomeData } from '@/types/home'

const PERIODS = [['month', 'Month to date'], ['quarter', 'Quarter to date'], ['ytd', 'Year to date'], ['30d', 'Last 30 days']] as const
const PARAMS = ['scope', 'period'] as const
const ORIGIN: Record<string, string> = { manual: 'Manual entry', calculated_suggestion: 'Calculated suggestion', ai_suggestion: 'AI suggestion' }

function greeting(): string {
  const h = new Date().getHours()
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'
}

function HomeSkeleton() {
  return (
    <div className="grid grid-cols-12 gap-5" aria-busy="true" aria-label="Loading dashboard">
      {[8, 4, 6, 6, 6, 6].map((span, i) => (
        <div key={i} className={cn('rounded-lg border border-stone-200 bg-white p-5 shadow-panel', span === 8 ? 'col-span-12 xl:col-span-8' : span === 4 ? 'col-span-12 xl:col-span-4' : 'col-span-12 lg:col-span-6')}>
          <Skeleton className="mb-4 h-4 w-40" />
          <Skeleton className="mb-2 h-3 w-full" /><Skeleton className="mb-2 h-3 w-5/6" /><Skeleton className="h-3 w-2/3" />
        </div>
      ))}
    </div>
  )
}

/** A dashboard card whose header links to the full list. */
function DashCard({ title, icon, count, href, hrefLabel = 'Open all', tone, children, className }: {
  title: string; icon: ReactNode; count?: ReactNode; href?: string; hrefLabel?: string; tone?: 'danger' | 'warning'; children: ReactNode; className?: string
}) {
  return (
    <Card as="section" padded={false} className={className}
      title={<span className="flex items-center gap-2"><span className="text-brass-600" aria-hidden>{icon}</span>{title}{count !== undefined && <Badge tone={tone === 'danger' ? 'danger' : tone === 'warning' ? 'warning' : 'neutral'}>{count}</Badge>}</span>}
      actions={href && <Link to={href} className="inline-flex items-center gap-1 rounded text-xs font-semibold text-navy-700 hover:text-brass-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">{hrefLabel}<ArrowUpRight className="h-3.5 w-3.5" aria-hidden /></Link>}>
      {children}
    </Card>
  )
}

function RowLink({ to, children, className }: { to: string; children: ReactNode; className?: string }) {
  return (
    <li>
      <Link to={to} className={cn('flex items-start justify-between gap-3 border-b border-stone-100 px-5 py-2.5 text-sm last:border-b-0 hover:bg-ivory-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500', className)}>{children}</Link>
    </li>
  )
}
const Empty = ({ text }: { text: string }) => <p className="px-5 py-6 text-center text-sm text-stone-600">{text}</p>

function Dashboard({ d }: { d: HomeData }) {
  const fin = d.financial
  return (
    <div className="grid grid-cols-12 gap-5">
      {/* Financial block first when present: period, filters and basis are always visible */}
      {fin && (
        <section aria-labelledby="fin-h" className="col-span-12 rounded-lg border border-stone-200 bg-white shadow-panel">
          <header className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-200 px-5 py-3.5">
            <div>
              <h2 id="fin-h" className="flex items-center gap-2 text-sm font-semibold tracking-wide text-navy-900"><Wallet className="h-4 w-4 text-brass-600" aria-hidden />Unbilled time &amp; billing</h2>
              <p className="mt-0.5 text-xs text-stone-600">Reporting period: <strong className="font-semibold text-navy-800">{fin.period.label}</strong> ({fin.period.from} → {fin.period.to}) · Scope: <strong className="font-semibold text-navy-800">{fin.filters.scope === 'firm' ? 'Whole firm' : 'My matters'}</strong>{fin.filters.office_id ? ' · Office filter applied' : ''} · Currency {fin.filters.currency}</p>
            </div>
            <Link to={fin.draft_invoices.href} className="text-xs font-semibold text-navy-700 hover:text-brass-700">Open billing →</Link>
          </header>
          <div className={cn('grid md:grid-cols-2', fin.metrics.length >= 3 ? 'xl:grid-cols-4' : 'xl:grid-cols-3')}>
            {fin.metrics.map((m) => (
              <div key={m.key} className="border-b border-stone-200 p-5 xl:border-b-0 xl:border-r xl:last:border-r-0">
                <Link to={m.href} className="group block rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
                  <p className="text-xs font-semibold uppercase tracking-wide text-stone-600">{m.label}</p>
                  <p className="mt-2 font-serif text-3xl text-navy-900 group-hover:text-brass-700"><Money value={m.value} currency={m.currency} /></p>
                </Link>
                <details className="mt-3 text-xs text-stone-600">
                  <summary className="cursor-pointer select-none rounded font-semibold text-navy-700 hover:text-brass-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500"><Info className="mr-1 inline h-3 w-3" aria-hidden />Calculation basis</summary>
                  <p className="mt-1.5 leading-snug">{m.basis}</p>
                </details>
              </div>
            ))}
            <div className="p-5">
              <Link to={fin.draft_invoices.href} className="group block rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
                <p className="text-xs font-semibold uppercase tracking-wide text-stone-600">Draft invoices</p>
                <p className="mt-2 font-serif text-3xl text-navy-900 group-hover:text-brass-700">{fin.draft_invoices.count}</p>
                <p className="mt-0.5 text-xs text-stone-600">worth <Money value={fin.draft_invoices.total} /> (VAT-inclusive, not yet issued)</p>
              </Link>
              <ul className="mt-2 space-y-0.5 text-xs">
                {fin.draft_invoices.items.map((i) => <li key={i.id}><Link className="inline-flex items-center gap-2 text-navy-700 hover:text-brass-700" to={i.href}><StatusBadge status={i.status} /><Money value={i.total} /></Link></li>)}
              </ul>
            </div>
          </div>
          <p className="border-t border-stone-200 bg-ivory-100 px-5 py-2.5 text-xs text-stone-700"><Info className="mr-1 inline h-3 w-3" aria-hidden />{fin.basis_note} Receipts and billed amounts are shown separately from recognised revenue; neither is treated as earned income here.</p>
        </section>
      )}

      {d.matters && (
        <DashCard className="col-span-12 xl:col-span-8" title="My active matters" icon={<Gavel className="h-4 w-4" />} count={d.matters.count} href={d.matters.href}>
          {d.matters.items.length === 0 ? <Empty text="No active matters in this view." /> : (
            <ul>{d.matters.items.map((m) => (
              <RowLink key={m.id} to={m.href}>
                <span className="min-w-0"><span className="block truncate font-medium text-navy-900">{m.title}</span>
                  <span className="text-xs text-stone-600"><span className="font-mono">{m.reference}</span> · {m.client} · {humanise(m.practice_area)}{m.stage ? ` · ${humanise(m.stage)}` : ''}</span></span>
                <span className="flex shrink-0 items-center gap-2">{m.restricted && <Badge tone="brass">Restricted</Badge>}<StatusBadge status={m.status} /></span>
              </RowLink>))}</ul>)}
        </DashCard>
      )}

      {d.tasks && (
        <DashCard className="col-span-12 xl:col-span-4" title="My tasks" icon={<ListChecks className="h-4 w-4" />} count={d.tasks.count} href={d.tasks.href}
          tone={d.tasks.overdue ? 'danger' : undefined}>
          {d.tasks.overdue > 0 && <p className="border-b border-bad-100 bg-bad-50 px-5 py-2 text-xs font-semibold text-bad-700" role="status">{d.tasks.overdue} overdue</p>}
          {d.tasks.items.length === 0 ? <Empty text="Nothing assigned to you." /> : (
            <ul>{d.tasks.items.map((t) => (
              <RowLink key={t.id} to={t.href}>
                <span className="min-w-0"><span className="block truncate font-medium text-navy-900">{t.title}</span>
                  <span className="text-xs text-stone-600">{t.matter_reference ?? 'No matter'}</span></span>
                <span className={cn('shrink-0 text-xs tabular-nums', t.overdue ? 'font-semibold text-bad-700' : 'text-stone-600')}>{t.overdue && <span className="sr-only">Overdue: </span>}<DateTime value={t.due_at} mode="date" /></span>
              </RowLink>))}</ul>)}
        </DashCard>
      )}

      {d.deadlines && (
        <DashCard className="col-span-12 lg:col-span-6" title="Deadlines requiring attention" icon={<CalendarClock className="h-4 w-4" />} count={d.deadlines.count} href={d.deadlines.href}
          tone={d.deadlines.items.some((x) => x.needs_confirmation) ? 'warning' : undefined}>
          {d.deadlines.items.length === 0 ? <Empty text="No deadlines need attention." /> : (
            <ul>{d.deadlines.items.map((x) => (
              <RowLink key={x.id} to={x.href}>
                <span className="min-w-0"><span className="block truncate font-medium text-navy-900">{x.title}</span>
                  <span className="text-xs text-stone-600">{x.matter_reference} · {ORIGIN[x.origin] ?? humanise(x.origin)}</span></span>
                <span className="flex shrink-0 flex-col items-end gap-1 text-xs">
                  <span className="tabular-nums text-navy-800"><DateTime value={x.due_date} mode="date" /> · {x.days_left < 0 ? `${-x.days_left}d ago` : x.days_left === 0 ? 'today' : `${x.days_left}d`}</span>
                  {x.needs_confirmation ? <Badge tone="warning">Needs confirmation</Badge> : <StatusBadge status={x.status} />}
                </span>
              </RowLink>))}</ul>)}
        </DashCard>
      )}

      {d.documents && (
        <DashCard className="col-span-12 lg:col-span-6" title="Documents awaiting review or signature" icon={<FileText className="h-4 w-4" />}
          count={d.documents.awaiting_review + d.documents.awaiting_signature} href={d.documents.href}>
          <p className="flex gap-4 border-b border-stone-100 px-5 py-2 text-xs text-stone-700"><span><strong className="tabular-nums">{d.documents.awaiting_review}</strong> in review</span><span><strong className="tabular-nums">{d.documents.awaiting_signature}</strong> awaiting signature</span></p>
          {d.documents.items.length === 0 ? <Empty text="No documents are waiting." /> : (
            <ul>{d.documents.items.map((x) => (
              <RowLink key={x.id} to={x.href}>
                <span className="min-w-0"><span className="block truncate font-medium text-navy-900">{x.title}</span><span className="text-xs text-stone-600">{x.matter_reference} · v{x.version_no}</span></span>
                <StatusBadge status={x.status} />
              </RowLink>))}</ul>)}
        </DashCard>
      )}

      {d.correspondence && (
        <DashCard className="col-span-12 lg:col-span-6" title="Recent correspondence" icon={<Mail className="h-4 w-4" />} href={d.correspondence.href}
          count={d.correspondence.unfiled ? `${d.correspondence.unfiled} unfiled` : undefined} tone={d.correspondence.unfiled ? 'warning' : undefined}>
          {d.correspondence.items.length === 0 ? <Empty text="No recent correspondence on your matters." /> : (
            <ul>{d.correspondence.items.map((x) => (
              <RowLink key={x.id} to={x.href}>
                <span className="min-w-0"><span className="block truncate font-medium text-navy-900">{x.subject}</span><span className="truncate text-xs text-stone-600">{humanise(x.direction)} · {x.from}</span></span>
                <span className="flex shrink-0 flex-col items-end gap-1"><StatusBadge status={x.status} /><span className="text-2xs text-stone-600"><DateTime value={x.at} mode="relative" /></span></span>
              </RowLink>))}</ul>)}
          {d.correspondence.unfiled > 0 && <Link to={`${d.correspondence.href}?filter=unfiled`} className="block border-t border-stone-100 px-5 py-2.5 text-xs font-semibold text-navy-700 hover:bg-ivory-100">{d.correspondence.unfiled} unfiled message{d.correspondence.unfiled === 1 ? '' : 's'} in the shared inbox →</Link>}
        </DashCard>
      )}

      {d.ai_drafts && (
        <DashCard className="col-span-12 lg:col-span-6" title="AI drafts awaiting human review" icon={<Bot className="h-4 w-4" />} count={d.ai_drafts.count} href={d.ai_drafts.href}
          tone={d.ai_drafts.count ? 'warning' : undefined}>
          {d.ai_drafts.items.length === 0 ? <Empty text="No AI output is waiting for review." /> : (
            <ul>{d.ai_drafts.items.map((x) => (
              <RowLink key={x.id} to={x.href}>
                <span className="min-w-0"><span className="block truncate font-medium text-navy-900">{humanise(x.agent_type)}</span><span className="text-xs text-stone-600">{x.matter_reference ?? 'No matter'}</span></span>
                <span className="shrink-0 text-xs text-stone-600"><DateTime value={x.created_at} mode="relative" /></span>
              </RowLink>))}</ul>)}
          <p className="border-t border-stone-100 px-5 py-2 text-2xs text-stone-600">AI output is a draft. Nothing is applied, sent or confirmed until a person approves it.</p>
        </DashCard>
      )}

      {d.approvals && (
        <section className="col-span-12 lg:col-span-6">
          <Link to={d.approvals.href} className="group flex h-full items-center justify-between gap-4 rounded-lg border border-stone-200 bg-white p-5 shadow-panel hover:border-brass-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">
            <span className="flex items-center gap-3"><ShieldCheck className="h-5 w-5 text-brass-600" aria-hidden />
              <span><span className="block text-sm font-semibold text-navy-900">Approvals waiting for me</span><span className="text-xs text-stone-600">Invoices, journals, exports, matter changes and more</span></span></span>
            <span className="font-serif text-3xl tabular-nums text-navy-900 group-hover:text-brass-700">{d.approvals.count}</span>
          </Link>
        </section>
      )}

      <section className="col-span-12" aria-labelledby="exc-h">
        <Card as="div" padded={false} title={<span id="exc-h" className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-warn-600" aria-hidden />Exceptions</span>}
          description="Items that need attention before they become problems. Each links to the underlying records.">
          {d.exceptions.length === 0 ? <Empty text="No exceptions. Missing documents, unallocated receipts and incomplete onboarding would appear here." /> : (
            <ul className="grid md:grid-cols-2 xl:grid-cols-3">
              {d.exceptions.map((e) => (
                <li key={e.key} className="border-b border-stone-100 md:border-r md:[&:nth-child(2n)]:border-r-0 xl:[&:nth-child(2n)]:border-r xl:[&:nth-child(3n)]:border-r-0">
                  <Link to={e.href} className="flex items-start justify-between gap-3 px-5 py-3 hover:bg-ivory-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500">
                    <span className="text-sm font-medium text-navy-900">{e.label}</span>
                    <Badge tone={e.severity === 'danger' ? 'danger' : 'warning'}>{e.count}</Badge>
                  </Link>
                  {e.items.length > 0 && <ul className="border-t border-stone-100 px-5 pb-2 pt-1">{e.items.slice(0, 3).map((i) => <li key={i.href}><Link to={i.href} className="block truncate py-0.5 text-xs text-stone-700 hover:text-brass-700">{i.label}</Link></li>)}</ul>}
                </li>))}
            </ul>)}
        </Card>
      </section>
    </div>
  )
}

function HomePage() {
  usePageTitle('Home')
  const { me, can } = useAuth()
  const { officeId, activeOffice } = useOffice()
  const [p, setP] = useQueryParams(PARAMS)
  const scope = p.scope === 'firm' ? 'firm' : 'mine'
  const period = PERIODS.find(([k]) => k === p.period)?.[0] ?? 'month'
  const canFirm = can('reports.read') || can('matters.approve')
  const q = useApiQuery<HomeData>(['home', scope, period, officeId], `/home${qs({ scope, period, office_id: officeId })}`)
  const [showFilters] = useState(true)
  const firstName = me?.user.name.split(' ')[0] ?? ''
  const err = q.error instanceof ApiError ? q.error : null

  if (q.data?.role === 'client') return <Navigate to="/portal" replace />
  return (
    <>
      <PageHeader eyebrow={<DateTime value={q.data?.as_of ?? new Date()} mode="date" />} title={`${greeting()}, ${firstName}`}
        description="Your matters, deadlines, reviews and exceptions at a glance. Every card opens the records behind it."
        meta={<><Badge tone="neutral">{me?.role.name}</Badge>{activeOffice && <Badge tone="brass">{activeOffice.name}</Badge>}</>} />
      {showFilters && (
        <form role="search" aria-label="Dashboard filters" className="mb-5 flex flex-wrap items-end gap-4 rounded-lg border border-stone-200 bg-white px-4 py-3 shadow-panel" onSubmit={(e) => e.preventDefault()}>
          <div className="space-y-1"><label htmlFor="f-scope" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Show</label>
            <Select id="f-scope" value={scope} onChange={(e) => setP({ scope: e.target.value === 'mine' ? null : e.target.value })} className="w-44">
              <option value="mine">My matters</option>{canFirm && <option value="firm">Whole firm (visible to me)</option>}
            </Select></div>
          <div className="space-y-1"><label htmlFor="f-period" className="block text-2xs font-semibold uppercase tracking-wide text-stone-700">Financial period</label>
            <Select id="f-period" value={period} onChange={(e) => setP({ period: e.target.value === 'month' ? null : e.target.value })} className="w-44">
              {PERIODS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select></div>
          <p className="ml-auto max-w-md text-xs text-stone-600">Office: <strong className="text-navy-800">{activeOffice ? activeOffice.name : 'All offices'}</strong> (change in the top bar). Figures include only records you are permitted to see.</p>
        </form>
      )}
      {q.isPending ? <HomeSkeleton /> : err ? (
        err.status === 403 ? <Card><p className="text-sm text-stone-700">Your role does not include a dashboard. Use the sidebar to open a section.</p></Card>
          : <Card><div role="alert" className="flex items-center justify-between gap-4 text-sm"><span>We could not load your dashboard: {err.message}</span><button className="rounded border border-stone-300 px-3 py-1 font-semibold text-navy-800 hover:bg-ivory-100" onClick={() => void q.refetch()}>Retry</button></div></Card>
      ) : q.data ? <Dashboard d={q.data} /> : null}
      <p className="mt-6 flex items-center gap-1.5 text-2xs text-stone-600"><Inbox className="h-3 w-3" aria-hidden />Generated <DateTime value={q.data?.generated_at} /> · All data in this demonstration is synthetic.</p>
    </>
  )
}

export default function HomeSection() {
  return (
    <Routes>
      <Route index element={<HomePage />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
