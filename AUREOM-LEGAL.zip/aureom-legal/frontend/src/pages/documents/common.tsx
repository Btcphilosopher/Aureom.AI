import { Fragment, type ReactNode } from 'react'
import { AlertTriangle, Lock } from 'lucide-react'
import { Badge, Select, StatusBadge, useToast } from '@/components/ui'
import { ApiError, api, useApiQuery } from '@/lib/api'
import type { MatterOption } from '@/types/documents'
import type { Page } from '@/types/api'
import type { Tone } from '@/lib/status'
import { humanise } from '@/lib/format'

export const DOC_TYPES = ['agreement', 'engagement_letter', 'letter', 'advice', 'attendance_note', 'contract_draft', 'contract', 'lease', 'schedule', 'enquiries', 'pleading', 'note', 'email_attachment', 'id_document', 'financial', 'template_output', 'other']
const TYPE_LABELS: Record<string, string> = { id_document: 'ID document', email_attachment: 'Email attachment', contract_draft: 'Contract (draft)', template_output: 'Generated from template', enquiries: 'Enquiries / replies' }
/** Readable label for a document type key (falls back to sentence case). */
export const docTypeLabel = (t: string | null | undefined) => (t && TYPE_LABELS[t]) || humanise(t)
export const DOC_STATUSES = ['draft', 'in_review', 'approved', 'signature_requested', 'signed', 'superseded']
export const ACCEPT = '.pdf,.docx,.txt,.md,.csv,.png,.jpg,.jpeg,.eml'
export const MAX_UPLOAD = 25 * 1024 * 1024
export const DOC_FLOW = [
  { key: 'draft', label: 'Draft' }, { key: 'in_review', label: 'In review' }, { key: 'approved', label: 'Approved' },
  { key: 'signature_requested', label: 'Signature requested' }, { key: 'signed', label: 'Signed' },
]

export const shortHash = (h: string | null | undefined) => (h ? `${h.slice(0, 12)}…` : '—')

/** Matters the user may see (the API already excludes restricted/walled matters the user cannot access). */
export function useMatterOptions() {
  const q = useApiQuery<Page<MatterOption>>(['matters', 'options'], '/matters?limit=200', { staleTime: 60_000 })
  const items = q.data?.items ?? []
  const byId = new Map(items.map((m) => [m.id, m]))
  return { items, byId, isError: q.isError, isPending: q.isPending, error: q.error }
}

export function MatterSelect({ value, onChange, id, required, allowEmpty = true, emptyLabel = 'All matters', ...rest }: {
  value: string; onChange: (v: string) => void; id?: string; required?: boolean; allowEmpty?: boolean; emptyLabel?: string; 'aria-describedby'?: string; 'aria-invalid'?: boolean
}) {
  const { items, isError, isPending } = useMatterOptions()
  return (
    <>
      <Select id={id} value={value} onChange={(e) => onChange(e.target.value)} required={required} disabled={isError} {...rest}>
        {allowEmpty && <option value="">{isPending ? 'Loading matters…' : emptyLabel}</option>}
        {!allowEmpty && !value && <option value="" disabled>{isPending ? 'Loading matters…' : 'Choose a matter…'}</option>}
        {items.map((m) => <option key={m.id} value={m.id}>{m.access_level === 'restricted' ? '🔒 ' : ''}{m.reference} · {m.title}</option>)}
      </Select>
      {isError && <p className="mt-1 text-xs text-warn-700">The matter list is unavailable right now, so matters cannot be chosen here.</p>}
    </>
  )
}

export function RestrictedBadge({ level, wall }: { level?: string; wall?: boolean }) {
  if (level !== 'restricted' && !wall) return null
  return <Badge tone="brass"><Lock className="h-3 w-3" aria-hidden />{wall ? 'Ethical wall' : 'Restricted matter'}</Badge>
}

export function ScanBadge({ status }: { status: string | undefined }) {
  if (!status) return null
  const tone: Tone = status === 'clean' ? 'success' : status === 'infected' || status === 'error' ? 'danger' : 'warning'
  const label = status === 'clean' ? 'Scanned: clean' : status === 'pending' ? 'Scan pending' : status === 'infected' ? 'Malware found' : status === 'unavailable' ? 'Scanner unavailable' : `Scan ${status}`
  return <Badge tone={tone}>{status !== 'clean' && <AlertTriangle className="h-3 w-3" aria-hidden />}{label}</Badge>
}

export function OcrBadge({ status }: { status: string | undefined }) {
  if (!status || status === 'not_needed') return null
  if (status === 'simulated') return <Badge tone="simulated">OCR simulated</Badge>
  const tone: Tone = status === 'done' ? 'success' : status === 'failed' ? 'danger' : 'warning'
  return <Badge tone={tone}>{status === 'done' ? 'OCR done' : status === 'pending' ? 'OCR pending' : `OCR ${status}`}</Badge>
}

export function DocStatusBadge({ status }: { status: string }) {
  return <StatusBadge status={status} />
}

/** Renders full-text snippets whose matches are wrapped in ⟦ ⟧ markers as TEXT with <mark> (never as HTML). */
export function Snippet({ text }: { text: string }) {
  const parts = text.split(/(⟦[^⟧]*⟧)/g)
  return (
    <>
      {parts.map((p, i) => p.startsWith('⟦') ? <mark key={i} className="rounded bg-brass-100 px-0.5 font-medium text-navy-900">{p.slice(1, -1)}</mark> : <Fragment key={i}>{p}</Fragment>)}
    </>
  )
}

/** Download via fetch so that server refusals (scan gate, export blocked) show a message instead of navigating to a JSON error page. */
export function useDownload() {
  const toast = useToast()
  return async (path: string, filename: string) => {
    try {
      const blob = await api.blob(path)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 5000)
    } catch (e) {
      const err = e as ApiError
      toast.push({ tone: 'danger', title: err.code === 'export_blocked' ? 'Downloads are disabled for this matter' : 'Download refused', description: err.message })
    }
  }
}

export function Note({ icon, tone = 'info', children, className = '' }: { icon?: ReactNode; tone?: 'info' | 'warn' | 'bad'; children: ReactNode; className?: string }) {
  const cls = { info: 'border-navy-200 bg-navy-50 text-navy-800', warn: 'border-warn-100 bg-warn-50 text-warn-700', bad: 'border-bad-100 bg-bad-50 text-bad-700' }[tone]
  return <div role="note" className={`flex gap-2 rounded-md border px-3 py-2 text-xs leading-snug ${cls} ${className}`}>{icon}<div>{children}</div></div>
}
