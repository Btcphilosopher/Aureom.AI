import { useEffect } from 'react'
import { Copy, FileWarning, Link2, RefreshCw, ShieldAlert } from 'lucide-react'
import { Badge, Button, CitationChip, EmptyState, QueryBoundary, useToast } from '@/components/ui'
import { ApiError, useApiQuery } from '@/lib/api'
import type { Preview } from '@/types/documents'
import { Note, OcrBadge, ScanBadge, shortHash } from './common'

const SCAN_CODES = ['scan_pending', 'scan_infected', 'scan_unavailable', 'scan_failed']

/** SAFE preview: extracted plain text only, by page and paragraph. The original file is never rendered in the browser. */
export function PreviewPane({ documentId, title, versionNo, hlPage, hlPara, onCite }: {
  documentId: string; title: string; versionNo: number; hlPage?: number; hlPara?: number; onCite: (page: number, para: number) => void
}) {
  const toast = useToast()
  const q = useApiQuery<Preview>(['document', documentId, 'preview', versionNo], `/documents/${documentId}/versions/${versionNo}/preview`, { retry: false })

  useEffect(() => {
    if (!q.data || !hlPage || !hlPara) return
    document.getElementById(`cite-${hlPage}-${hlPara}`)?.scrollIntoView({ block: 'center', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' })
  }, [q.data, hlPage, hlPara])

  if (q.isError && q.error instanceof ApiError && SCAN_CODES.includes(q.error.code)) {
    const infected = q.error.code === 'scan_infected'
    return (
      <div role="alert" className={`rounded-lg border p-5 ${infected ? 'border-bad-100 bg-bad-50' : 'border-warn-100 bg-warn-50'}`}>
        <div className="flex items-start gap-3"><ShieldAlert className={`mt-0.5 h-5 w-5 ${infected ? 'text-bad-700' : 'text-warn-700'}`} aria-hidden />
          <div><h3 className="font-serif text-lg text-navy-900">{infected ? 'Preview blocked: malware detected' : 'Preview not available yet'}</h3>
            <p className="mt-1 text-sm text-stone-700">{q.error.message}</p>
            <p className="mt-1 text-xs text-stone-600">{q.error.code === 'scan_unavailable' ? 'The malware scanner integration is not reachable, so files stay blocked rather than being served unscanned.' : q.error.code === 'scan_pending' ? 'The background worker scans every upload before it can be previewed or downloaded.' : 'The file stays quarantined; the original is retained for investigation.'}</p>
            {!infected && <Button className="mt-3" size="sm" variant="secondary" onClick={() => void q.refetch()}><RefreshCw className="h-4 w-4" aria-hidden />Check again</Button>}</div></div>
      </div>
    )
  }
  return (
    <QueryBoundary query={q} what="preview" loading={<p className="text-sm text-stone-600">Loading preview…</p>}>
      {(d) => (
        <div>
          <Note icon={<FileWarning className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />} className="mb-4">
            <strong>Text preview only — originals are not rendered.</strong> {d.notice} Version {d.version_no} · {d.filename} · SHA-256 <code className="font-mono">{shortHash(d.sha256)}</code>
            <span className="ml-2 inline-flex gap-1 align-middle"><ScanBadge status={d.scan_status} /><OcrBadge status={d.ocr_status} /></span>
          </Note>
          {d.simulated_ocr && <Note tone="warn" className="mb-4"><strong>SIMULATED OCR.</strong> No OCR engine is configured in this demonstration: text from images or scanned pages is placeholder output and must not be relied on.</Note>}
          {!d.text_available ? (
            <EmptyState title="No extractable text yet" description={d.ocr_status === 'pending' || d.ocr_status === undefined ? 'Text extraction / OCR runs in the background worker. Check again shortly.' : 'This file type has no text layer to preview. Download the original (if permitted) to view it.'}
              action={<Button size="sm" variant="secondary" onClick={() => void q.refetch()}>Refresh</Button>} />
          ) : (
            <div className="space-y-6">
              {d.pages.map((pg) => (
                <section key={pg.page} aria-label={`Page ${pg.page}`}>
                  <h3 className="mb-2 border-b border-stone-200 pb-1 text-xs font-semibold uppercase tracking-wider text-stone-600">Page {pg.page}</h3>
                  <ol className="space-y-2">
                    {pg.paragraphs.map((pp) => {
                      const hl = hlPage === pg.page && hlPara === pp.paragraph
                      return (
                        <li key={pp.chunk_id} id={`cite-${pg.page}-${pp.paragraph}`} className={`group relative flex gap-3 rounded-md px-3 py-2 ${hl ? 'bg-brass-50 ring-2 ring-brass-400' : 'hover:bg-ivory-100'}`}>
                          <a href={`#cite-${pg.page}-${pp.paragraph}`} onClick={(e) => { e.preventDefault(); onCite(pg.page, pp.paragraph) }} className="w-10 shrink-0 pt-0.5 text-right font-mono text-2xs text-stone-500 hover:text-navy-800" aria-label={`Link to page ${pg.page} paragraph ${pp.paragraph}`}>¶{pp.paragraph}</a>
                          <p className="min-w-0 flex-1 whitespace-pre-wrap text-sm leading-relaxed text-navy-900">{pp.text}{pp.is_ocr && <Badge tone="simulated" className="ml-2">OCR</Badge>}</p>
                          <span className="flex shrink-0 gap-1 self-start opacity-0 focus-within:opacity-100 group-hover:opacity-100">
                            <button type="button" aria-label={`Copy citation for page ${pg.page} paragraph ${pp.paragraph}`} className="rounded p-1 text-stone-500 hover:bg-white hover:text-navy-800"
                              onClick={() => { void navigator.clipboard?.writeText(`${title} · v${d.version_no} · p.${pg.page} ¶${pp.paragraph}`).then(() => toast.push({ tone: 'success', title: 'Citation copied', description: `${title} · v${d.version_no} · p.${pg.page} ¶${pp.paragraph}` }), () => toast.push({ tone: 'warning', title: 'Could not copy' })) }}><Copy className="h-3.5 w-3.5" /></button>
                            <button type="button" aria-label="Pin this paragraph in the address bar" className="rounded p-1 text-stone-500 hover:bg-white hover:text-navy-800" onClick={() => onCite(pg.page, pp.paragraph)}><Link2 className="h-3.5 w-3.5" /></button>
                          </span>
                        </li>
                      )
                    })}
                  </ol>
                </section>
              ))}
              {hlPage && hlPara && <p className="text-xs text-stone-600">Citation: <CitationChip documentTitle={title} versionNo={d.version_no} page={hlPage} paragraph={hlPara} /></p>}
            </div>
          )}
        </div>
      )}
    </QueryBoundary>
  )
}
