import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FilePlus2, FolderPlus, Folder as FolderIcon, FolderOpen, Gavel, Pencil, Search, Trash2, UserRound } from 'lucide-react'
import { Badge, Button, Card, CitationChip, ConfirmDialog, DataTable, DateTime, Dialog, Field, Input, PermissionDenied, QueryBoundary, Select, Tooltip, type Column, useToast } from '@/components/ui'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useDebounce, useNewParam, useQueryParams } from '@/hooks'
import { humanise } from '@/lib/format'
import type { DocItem, Folder, SearchHit } from '@/types/documents'
import type { Page } from '@/types/api'
import { DOC_STATUSES, DOC_TYPES, DocStatusBadge, docTypeLabel, MatterSelect, OcrBadge, RestrictedBadge, ScanBadge, Snippet, useMatterOptions } from './common'
import { UploadDialog } from './UploadDialog'

const PARAMS = ['matter', 'type', 'status', 'tag', 'scan', 'q', 'folder', 'offset'] as const
const LIMIT = 25

function FolderPanel({ matterId, folder, onPick }: { matterId: string; folder: string | null; onPick: (id: string | null) => void }) {
  const { can } = useAuth()
  const toast = useToast()
  const q = useApiQuery<Folder[]>(['folders', matterId], `/documents/folders?matter_id=${matterId}`)
  const [dlg, setDlg] = useState<{ mode: 'create' | 'rename'; folder?: Folder } | null>(null)
  const [name, setName] = useState('')
  const [del, setDel] = useState<Folder | null>(null)
  const save = useApiMutation((v: { mode: 'create' | 'rename'; id?: string; name: string }) =>
    v.mode === 'create' ? api.post('/documents/folders', { matter_id: matterId, name: v.name }) : api.patch(`/documents/folders/${v.id}`, { name: v.name }),
  { invalidate: [['folders', matterId], ['documents']], successMessage: 'Folder saved', onSuccess: () => setDlg(null) })
  const remove = useApiMutation((id: string) => api.delete(`/documents/folders/${id}`), { invalidate: [['folders', matterId]], successMessage: 'Folder deleted', onSuccess: () => { setDel(null); onPick(null) },
    onError: (e) => { setDel(null); toast.push({ tone: 'warning', title: e.code === 'folder_not_empty' ? 'Folder is not empty' : 'Could not delete', description: e.message }) }, errorToast: false })
  const canWrite = can('documents.write')
  return (
    <Card title="Matter folders" padded={false} actions={canWrite ? <Button size="sm" variant="ghost" onClick={() => { setName(''); setDlg({ mode: 'create' }) }}><FolderPlus className="h-4 w-4" aria-hidden />New</Button> : undefined}>
      <QueryBoundary query={q} loading={<p className="p-4 text-xs text-stone-600">Loading folders…</p>} empty={<p className="p-4 text-xs text-stone-600">No folders yet. Documents sit at the matter root.</p>}>
        {(folders) => (
          <ul className="p-2 text-sm">
            <li><button type="button" onClick={() => onPick(null)} aria-current={!folder} className={`flex w-full items-center gap-2 rounded px-2 py-1.5 text-left hover:bg-ivory-200 ${!folder ? 'bg-ivory-200 font-medium' : ''}`}><FolderOpen className="h-4 w-4 text-brass-600" aria-hidden />All documents</button></li>
            {folders.map((f) => (
              <li key={f.id} className="group flex items-center">
                <button type="button" onClick={() => onPick(f.id)} aria-current={folder === f.id} className={`flex min-w-0 flex-1 items-center gap-2 rounded px-2 py-1.5 text-left hover:bg-ivory-200 ${folder === f.id ? 'bg-ivory-200 font-medium' : ''}`}><FolderIcon className="h-4 w-4 shrink-0 text-stone-500" aria-hidden /><span className="truncate">{f.name}</span></button>
                {canWrite && <span className="flex opacity-0 focus-within:opacity-100 group-hover:opacity-100">
                  <button type="button" aria-label={`Rename folder ${f.name}`} className="rounded p-1 text-stone-500 hover:text-navy-800" onClick={() => { setName(f.name); setDlg({ mode: 'rename', folder: f }) }}><Pencil className="h-3.5 w-3.5" /></button>
                  <button type="button" aria-label={`Delete folder ${f.name}`} className="rounded p-1 text-stone-500 hover:text-bad-700" onClick={() => setDel(f)}><Trash2 className="h-3.5 w-3.5" /></button></span>}
              </li>
            ))}
          </ul>
        )}
      </QueryBoundary>
      <Dialog open={!!dlg} onClose={() => setDlg(null)} size="sm" title={dlg?.mode === 'create' ? 'New folder' : 'Rename folder'}
        footer={<><Button variant="secondary" onClick={() => setDlg(null)}>Cancel</Button><Button loading={save.isPending} disabled={!name.trim()} onClick={() => dlg && save.mutate({ mode: dlg.mode, id: dlg.folder?.id, name: name.trim() })}>Save</Button></>}>
        <Field label="Folder name" required>{(p) => <Input {...p} value={name} onChange={(e) => setName(e.target.value)} data-autofocus />}</Field>
      </Dialog>
      <ConfirmDialog open={!!del} onClose={() => setDel(null)} title={`Delete folder “${del?.name}”?`} description="Only empty folders can be deleted. Documents are never deleted by this action." tone="danger" confirmLabel="Delete folder" loading={remove.isPending} onConfirm={() => { if (del) remove.mutate(del.id) }} />
    </Card>
  )
}

function ContentHits({ q, matter }: { q: string; matter: string }) {
  const nav = useNavigate()
  const hits = useApiQuery<Page<SearchHit>>(['documents', 'search', q, matter], `/documents/search${qs({ q, matter_id: matter, limit: 8 })}`, { enabled: q.length >= 2 })
  if (q.length < 2) return null
  return (
    <Card title="Matches inside documents" description="Full-text search of extracted text (current versions, scanned-clean files you may see). Click a match to open it at that paragraph." className="mb-4">
      <QueryBoundary query={hits} loading={<p className="text-sm text-stone-600">Searching…</p>} empty={<p className="text-sm text-stone-600">No text matches. Title matches appear in the table below; documents still being scanned or OCR’d are not searchable yet.</p>}>
        {(d) => (
          <ul className="divide-y divide-stone-100">
            {d.items.map((h) => (
              <li key={h.chunk_id} className="py-2.5">
                <button type="button" className="block w-full text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500" onClick={() => nav(`/documents/${h.document_id}?tab=preview&v=${h.version_no}&page=${h.page}&para=${h.paragraph}`)}>
                  <span className="flex flex-wrap items-center gap-2 text-sm font-medium text-navy-900">
                    {h.title}<CitationChip documentTitle={h.matter_reference ?? h.doc_type} versionNo={h.version_no} page={h.page} paragraph={h.paragraph} />
                    {h.is_ocr && <Badge tone="simulated">OCR text</Badge>}
                  </span>
                  <span className="mt-1 block text-xs leading-relaxed text-stone-700"><Snippet text={h.snippet} /></span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </QueryBoundary>
    </Card>
  )
}

export default function Library() {
  const nav = useNavigate()
  const { can } = useAuth()
  const [p, setP] = useQueryParams(PARAMS)
  const { isNew, clear } = useNewParam()
  const [upload, setUpload] = useState(isNew)
  const [qText, setQText] = useState(p.q ?? '')
  const dq = useDebounce(qText, 350)
  const { byId } = useMatterOptions()
  useEffect(() => { if (isNew) setUpload(true) }, [isNew])
  useEffect(() => { if ((p.q ?? '') !== dq) setP({ q: dq || null, offset: null }) }, [dq]) // eslint-disable-line react-hooks/exhaustive-deps

  const offset = Number(p.offset ?? 0) || 0
  const path = `/documents${qs({ matter_id: p.matter, doc_type: p.type, status: p.status, tag: p.tag, q: p.q, folder_id: p.folder, limit: LIMIT, offset })}`
  const q = useApiQuery<Page<DocItem>>(['documents', 'list', path], path)
  const rows = (q.data?.items ?? []).filter((d) => {
    const s = d.current?.scan_status
    if (!p.scan) return true
    if (p.scan === 'failed') return s === 'infected' || s === 'error'
    return s === p.scan
  })

  if (q.error instanceof ApiError && q.error.status === 403) return <PermissionDenied permission={(q.error.details.required as string[] | undefined) ?? 'documents.read'} message={q.error.message} />

  const cols: Column<DocItem>[] = [
    { key: 'title', header: 'Document', cell: (d) => (
      <div className="min-w-0"><p className="truncate font-medium text-navy-900">{d.title}</p>
        <p className="flex flex-wrap items-center gap-1.5 text-xs text-stone-600">{d.current?.original_filename}
          {d.legal_hold && <Badge tone="brass"><Gavel className="h-3 w-3" aria-hidden />Legal hold</Badge>}
          {d.client_visible && <Badge tone="info"><UserRound className="h-3 w-3" aria-hidden />Client-visible</Badge>}
          <RestrictedBadge level={d.matter_id ? byId.get(d.matter_id)?.access_level : undefined} wall={d.matter_id ? byId.get(d.matter_id)?.ethical_wall : undefined} /></p></div>) },
    { key: 'matter', header: 'Matter', hideOnNarrow: true, cell: (d) => <span className="whitespace-nowrap text-sm">{d.matter_reference ?? <span className="text-stone-500">Client-level</span>}</span> },
    { key: 'type', header: 'Type', hideOnNarrow: true, cell: (d) => docTypeLabel(d.doc_type) },
    { key: 'v', header: 'Ver.', cell: (d) => <span className="tabular-nums">v{d.current_version_no}</span> },
    { key: 'status', header: 'Status', cell: (d) => <DocStatusBadge status={d.status} /> },
    { key: 'scan', header: 'Checks', cell: (d) => <div className="flex flex-col items-start gap-1"><ScanBadge status={d.current?.scan_status} /><OcrBadge status={d.current?.ocr_status} /></div> },
    { key: 'upd', header: 'Updated', hideOnNarrow: true, cell: (d) => <DateTime value={d.updated_at} mode="relative" /> },
  ]
  const clear1 = () => { setQText(''); setP({ matter: null, type: null, status: null, tag: null, scan: null, q: null, folder: null, offset: null }) }
  const filtered = !!(p.matter || p.type || p.status || p.tag || p.scan || p.q || p.folder)

  return (
    <div>
      <div className="mb-4 grid gap-3 rounded-lg border border-stone-200 bg-white p-4 shadow-panel sm:grid-cols-2 lg:grid-cols-6" role="search" aria-label="Filter documents">
        <Field label="Search" className="lg:col-span-2" hint="Titles and document text">{(f) => <div className="relative"><Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-stone-500" aria-hidden /><Input {...f} className="pl-8" value={qText} onChange={(e) => setQText(e.target.value)} placeholder="e.g. termination notice" /></div>}</Field>
        <Field label="Matter" className="lg:col-span-2">{(f) => <MatterSelect {...f} value={p.matter ?? ''} onChange={(v) => setP({ matter: v || null, folder: null, offset: null })} />}</Field>
        <Field label="Type">{(f) => <Select {...f} value={p.type ?? ''} onChange={(e) => setP({ type: e.target.value || null, offset: null })}><option value="">All types</option>{DOC_TYPES.map((t) => <option key={t} value={t}>{docTypeLabel(t)}</option>)}</Select>}</Field>
        <Field label="Status">{(f) => <Select {...f} value={p.status ?? ''} onChange={(e) => setP({ status: e.target.value || null, offset: null })}><option value="">Any status</option>{DOC_STATUSES.map((t) => <option key={t} value={t}>{humanise(t)}</option>)}</Select>}</Field>
        <Field label="Tag">{(f) => <Input {...f} value={p.tag ?? ''} onChange={(e) => setP({ tag: e.target.value || null, offset: null })} placeholder="tag" />}</Field>
        <Field label="Scan state" hint="Filters this page">{(f) => <Select {...f} value={p.scan ?? ''} onChange={(e) => setP({ scan: e.target.value || null })}><option value="">Any</option><option value="clean">Clean</option><option value="pending">Pending</option><option value="failed">Failed / infected</option><option value="unavailable">Scanner unavailable</option></Select>}</Field>
        <div className="flex items-end gap-2 lg:col-span-2">
          {filtered && <Button variant="ghost" size="sm" onClick={clear1}>Clear filters</Button>}
        </div>
        <div className="flex items-end justify-end sm:col-span-2 lg:col-span-2">
          {can('documents.write') ? <Button onClick={() => setUpload(true)}><FilePlus2 className="h-4 w-4" aria-hidden />Upload documents</Button>
            : <Tooltip text="Your role cannot upload documents (documents.write)."><span><Button disabled>Upload documents</Button></span></Tooltip>}
        </div>
      </div>

      {p.q && p.q.length >= 2 && <ContentHits q={p.q} matter={p.matter ?? ''} />}

      <div className="grid gap-4 lg:grid-cols-[15rem_1fr]">
        {p.matter ? <FolderPanel matterId={p.matter} folder={p.folder} onPick={(id) => setP({ folder: id, offset: null })} />
          : <Card title="Matter folders"><p className="text-xs text-stone-600">Choose a matter in the filter bar to browse and manage its folders.</p></Card>}
        <DataTable caption="Documents" columns={cols} rows={rows} rowKey={(d) => d.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
          onRowClick={(d) => nav(`/documents/${d.id}`)} emptyTitle={filtered ? 'No documents match these filters' : 'No documents yet'}
          emptyDescription={filtered ? 'Try clearing a filter. Documents in restricted matters you cannot access are never listed.' : 'Upload a document to a matter to start its file.'}
          emptyAction={can('documents.write') ? <Button onClick={() => setUpload(true)}>Upload documents</Button> : undefined}
          pagination={q.data ? { total: q.data.total, limit: LIMIT, offset, onChange: (o) => setP({ offset: o ? String(o) : null }) } : undefined} />
      </div>

      <UploadDialog key={`${p.matter}-${p.folder}`} open={upload} onClose={() => { setUpload(false); clear() }} defaultMatterId={p.matter ?? undefined} defaultFolderId={p.folder ?? undefined} />
    </div>
  )
}
