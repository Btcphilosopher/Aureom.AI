import { Navigate, Route, Routes, useParams } from 'react-router-dom'
import { NotFoundState } from '@/components/ui'
import { PageHeader, Tabs, TabPanel } from '@/components/ui'
import { useQueryParam, usePageTitle } from '@/hooks'
import { useAuth } from '@/lib/auth'
import { PermissionDenied } from '@/components/ui'
import { DocumentDetailPage } from './DocumentDetail'
import ExportsTab from './Exports'
import Library from './Library'
import TemplatesTab from './Templates'

function Home() {
  usePageTitle('Documents')
  const { can } = useAuth()
  const [tab, setTab] = useQueryParam('tab')
  const [exportId] = useQueryParam('export')
  const t = tab === 'templates' || tab === 'exports' ? tab : 'library'
  return (
    <div>
      <PageHeader title="Documents" description="Matter folders, immutable versions, safe previews, full-text search, review, signature and controlled export." />
      <Tabs label="Document areas" value={t} onChange={(x) => setTab(x === 'library' ? null : x)} className="mb-5"
        tabs={[{ id: 'library', label: 'Library' }, { id: 'templates', label: 'Templates' }, { id: 'exports', label: 'Exports' }]} />
      <TabPanel id="library" value={t}><Library /></TabPanel>
      <TabPanel id="templates" value={t}><TemplatesTab /></TabPanel>
      <TabPanel id="exports" value={t}>{can('documents.export') ? <ExportsTab highlight={exportId} /> : <PermissionDenied permission="documents.export" message="Exports need the documents.export permission." />}</TabPanel>
    </div>
  )
}

/** /documents/exports/:id (linked from the approvals inbox) opens the Exports tab. */
function ExportRedirect() {
  const { id } = useParams()
  return <Navigate to={`/documents?tab=exports&export=${id}`} replace />
}

export default function DocumentsSection() {
  return (
    <Routes>
      <Route index element={<Home />} />
      <Route path="exports/:id" element={<ExportRedirect />} />
      <Route path=":id" element={<DocumentDetailPage />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
