import { useMemo, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { CheckCircle2, Loader2, XCircle } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Button, Checkbox, Dialog, Field, FileDropzone, Input, Select, Textarea } from '@/components/ui'
import { ApiError, api, useApiQuery } from '@/lib/api'
import { formatBytes } from '@/lib/format'
import type { DocDetail, Folder } from '@/types/documents'
import { ACCEPT, DOC_TYPES, MAX_UPLOAD, MatterSelect, docTypeLabel } from './common'
import { humanise } from '@/lib/format'

interface Item { id: string; file: File; state: 'queued' | 'uploading' | 'done' | 'error'; message?: string; docId?: string }
let seq = 0

/** Drag-and-drop upload of one or many files. Each file is POSTed separately so one rejection never blocks the rest. */
export function UploadDialog({ open, onClose, defaultMatterId, defaultFolderId }: { open: boolean; onClose: () => void; defaultMatterId?: string; defaultFolderId?: string }) {
  const qc = useQueryClient()
  const [items, setItems] = useState<Item[]>([])
  const [matterId, setMatterId] = useState(defaultMatterId ?? '')
  const [folderId, setFolderId] = useState(defaultFolderId ?? '')
  const [docType, setDocType] = useState('other')
  const [title, setTitle] = useState('')
  const [tags, setTags] = useState('')
  const [clientVisible, setClientVisible] = useState(false)
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [rejected, setRejected] = useState<string[]>([])
  const folders = useApiQuery<Folder[]>(['folders', matterId], `/documents/folders?matter_id=${matterId}`, { enabled: !!matterId })

  const add = (files: File[]) => setItems((cur) => [...cur, ...files.map((file) => ({ id: `f${++seq}`, file, state: 'queued' as const }))])
  const patch = (id: string, p: Partial<Item>) => setItems((cur) => cur.map((i) => (i.id === id ? { ...i, ...p } : i)))
  const queued = items.filter((i) => i.state === 'queued' || i.state === 'error')
  const done = items.filter((i) => i.state === 'done').length
  const failed = items.filter((i) => i.state === 'error').length
  const summary = useMemo(() => (items.length ? `${done} of ${items.length} uploaded${failed ? `, ${failed} failed` : ''}${busy ? ' — uploading…' : ''}` : ''), [items, done, failed, busy])

  const run = async () => {
    setBusy(true)
    for (const it of queued) {
      patch(it.id, { state: 'uploading', message: undefined })
      try {
        const doc = await api.upload<DocDetail>('/documents', it.file, {
          matter_id: matterId, folder_id: folderId || undefined, doc_type: docType, title: items.length === 1 && title.trim() ? title.trim() : it.file.name.replace(/\.[^.]+$/, ''),
          tags: tags.split(',').map((t) => t.trim()).filter(Boolean).join(','), client_visible: clientVisible, change_note: note.trim() || undefined,
        })
        patch(it.id, { state: 'done', docId: doc.id, message: `Stored as version 1. Scanning, text extraction and indexing run in the background.` })
      } catch (e) {
        const err = e as ApiError
        patch(it.id, { state: 'error', message: err.status === 0 ? err.message : `${err.message}${err.code && err.code !== 'http_error' ? ` (${humanise(err.code)})` : ''}` })
      }
    }
    setBusy(false)
    void qc.invalidateQueries({ queryKey: ['documents'] })
  }
  const close = () => { if (!busy) { setItems([]); setRejected([]); onClose() } }

  return (
    <Dialog open={open} onClose={close} size="lg" title="Upload documents" dismissible={!busy}
      description="Files are validated by type and content, stored as immutable originals, then scanned for malware, text-extracted (OCR where needed) and indexed."
      footer={<><Button variant="secondary" onClick={close} disabled={busy}>{done && !queued.length ? 'Close' : 'Cancel'}</Button>
        <Button onClick={run} loading={busy} disabled={!matterId || !queued.length}>{queued.length ? `Upload ${queued.length} file${queued.length > 1 ? 's' : ''}` : 'Upload'}</Button></>}>
      <div className="space-y-4">
        <FileDropzone onFiles={add} accept={ACCEPT} maxSizeBytes={MAX_UPLOAD} busy={busy} hint={`Accepted: PDF, DOCX, TXT, MD, CSV, PNG, JPG, EML · max ${formatBytes(MAX_UPLOAD)} each`} onReject={(r) => setRejected(r.map((x) => x.reason))} />
        {rejected.length > 0 && <p className="text-xs text-bad-700">Some files were not added: they fail the client-side hint. The server decides authoritatively.</p>}

        <div aria-live="polite" className="sr-only">{summary}</div>
        {items.length > 0 && (
          <ul className="divide-y divide-stone-200 rounded-md border border-stone-200" aria-label="Files to upload">
            {items.map((i) => (
              <li key={i.id} className="flex items-start gap-3 px-3 py-2 text-sm">
                <span className="mt-0.5">{i.state === 'uploading' ? <Loader2 className="h-4 w-4 animate-spin text-navy-600" aria-label="Uploading" /> : i.state === 'done' ? <CheckCircle2 className="h-4 w-4 text-ok-600" aria-label="Uploaded" /> : i.state === 'error' ? <XCircle className="h-4 w-4 text-bad-600" aria-label="Failed" /> : <span className="block h-4 w-4 rounded-full border border-stone-300" aria-label="Queued" />}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-navy-900">{i.file.name} <span className="font-normal text-stone-500">· {formatBytes(i.file.size)}</span></p>
                  {i.message && <p className={`text-xs ${i.state === 'error' ? 'text-bad-700' : 'text-stone-600'}`}>{i.message} {i.docId && <Link className="underline" to={`/documents/${i.docId}`} onClick={onClose}>Open</Link>}</p>}
                </div>
                {(i.state === 'queued' || i.state === 'error') && !busy && <Button size="sm" variant="ghost" onClick={() => setItems((c) => c.filter((x) => x.id !== i.id))}>Remove</Button>}
              </li>
            ))}
          </ul>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Matter" required hint="Restricted matters you cannot access are not listed.">{(p) => <MatterSelect {...p} value={matterId} onChange={(v) => { setMatterId(v); setFolderId('') }} allowEmpty={false} />}</Field>
          <Field label="Folder" hint={matterId ? undefined : 'Choose a matter first.'}>
            {(p) => <Select {...p} value={folderId} onChange={(e) => setFolderId(e.target.value)} disabled={!matterId}><option value="">Matter root</option>{(folders.data ?? []).map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}</Select>}
          </Field>
          <Field label="Document type">{(p) => <Select {...p} value={docType} onChange={(e) => setDocType(e.target.value)}>{DOC_TYPES.map((t) => <option key={t} value={t}>{docTypeLabel(t)}</option>)}</Select>}</Field>
          <Field label="Tags" hint="Comma-separated.">{(p) => <Input {...p} value={tags} onChange={(e) => setTags(e.target.value)} placeholder="draft, client-review" />}</Field>
          {items.length <= 1 && <Field label="Title" hint="Defaults to the file name." className="sm:col-span-2">{(p) => <Input {...p} value={title} onChange={(e) => setTitle(e.target.value)} />}</Field>}
          <Field label="Change note" hint="Recorded on the version history." className="sm:col-span-2">{(p) => <Textarea {...p} rows={2} value={note} onChange={(e) => setNote(e.target.value)} />}</Field>
          <div className="sm:col-span-2"><Checkbox label="Visible to the client in the portal" hint="Only scanned-clean files are ever shown to the client." checked={clientVisible} onChange={(e) => setClientVisible(e.target.checked)} /></div>
        </div>
      </div>
    </Dialog>
  )
}

export function NewVersionDialog({ open, onClose, documentId, currentNo, onDone }: { open: boolean; onClose: () => void; documentId: string; currentNo: number; onDone: () => void }) {
  const [file, setFile] = useState<File | null>(null)
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const submit = async () => {
    if (!file) return
    setBusy(true); setError(null)
    try { await api.upload<DocDetail>(`/documents/${documentId}/versions`, file, { change_note: note.trim() || undefined }); setFile(null); setNote(''); onDone(); onClose() }
    catch (e) { setError((e as ApiError).message) } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onClose={() => !busy && onClose()} title={`Upload version ${currentNo + 1}`} description="Uploading creates a new immutable version. Earlier versions are kept unchanged; an approved or signed document returns to draft."
      footer={<><Button variant="secondary" onClick={onClose} disabled={busy}>Cancel</Button><Button onClick={submit} loading={busy} disabled={!file}>Upload version</Button></>}>
      <div className="space-y-4">
        <FileDropzone multiple={false} onFiles={(f) => setFile(f[0] ?? null)} accept={ACCEPT} maxSizeBytes={MAX_UPLOAD} busy={busy} />
        {file && <p className="text-sm text-navy-900">Selected: <strong>{file.name}</strong> ({formatBytes(file.size)})</p>}
        <Field label="Change note" hint="What changed in this version?">{(p) => <Textarea {...p} rows={2} value={note} onChange={(e) => setNote(e.target.value)} />}</Field>
        {error && <p role="alert" className="text-sm text-bad-700">{error}</p>}
      </div>
    </Dialog>
  )
}
