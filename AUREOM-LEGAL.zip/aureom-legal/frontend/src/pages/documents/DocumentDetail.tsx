import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { Download, FileCheck2, FilePlus2, Gavel, Lock, PackageOpen, PenLine, PenTool, Plus, Send, Trash2, Undo2 } from 'lucide-react'
import {
  Badge, Button, Card, Checkbox, ConfirmDialog, DataTable, DateTime, Dialog, Field, Input, IntegrationUnavailable, KeyValue, PageHeader, QueryBoundary, Select, SimulatedBanner, StatusStepper,
  TabPanel, Tabs, Textarea, Tooltip, type Column, useToast,
} from '@/components/ui'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useQueryParam, useQueryParams, usePageTitle } from '@/hooks'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { formatBytes, humanise } from '@/lib/format'
import type { DocDetail, DocVersion, Folder, IntegrationInfo } from '@/types/documents'
import { DOC_FLOW, DOC_TYPES, DocStatusBadge, docTypeLabel, Note, OcrBadge, RestrictedBadge, ScanBadge, shortHash, useDownload, useMatterOptions } from './common'
import { ComparePane } from './Compare'
import { PreviewPane } from './Preview'
import { NewVersionDialog } from './UploadDialog'

const TABS = ['overview', 'preview', 'versions', 'compare'] as const

function MetadataDialog({ d, open, onClose }: { d: DocDetail; open: boolean; onClose: () => void }) {
  const qc = useQueryClient()
  const [title, setTitle] = useState(d.title)
  const [docType, setDocType] = useState(d.doc_type)
  const [tags, setTags] = useState(d.tags.join(', '))
  const [cv, setCv] = useState(d.client_visible)
  const [folder, setFolder] = useState(d.folder_id ?? '')
  const [conflict, setConflict] = useState(false)
  const folders = useApiQuery<Folder[]>(['folders', d.matter_id], `/documents/folders?matter_id=${d.matter_id}`, { enabled: open && !!d.matter_id })
  const save = useApiMutation(() => api.patch<DocDetail>(`/documents/${d.id}`, { expected_version: d.version, title, doc_type: docType, tags: tags.split(',').map((t) => t.trim()).filter(Boolean), client_visible: cv, folder_id: folder || null }),
    { errorToast: false, successMessage: 'Document updated', invalidate: [['documents'], ['document', d.id]], onSuccess: () => onClose(), onError: (e) => { if (e.isConflict) setConflict(true) } })
  return (
    <Dialog open={open} onClose={onClose} title="Edit document details" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={save.isPending} disabled={!title.trim() || conflict} onClick={() => save.mutate()}>Save changes</Button></>}>
      <div className="space-y-4">
        {conflict && <Note tone="warn"><strong>This document was changed by someone else.</strong> Reload to see the latest details before editing again. <Button size="sm" variant="secondary" className="ml-2" onClick={() => { setConflict(false); void qc.invalidateQueries({ queryKey: ['document', d.id] }); onClose() }}>Reload</Button></Note>}
        {save.error && !conflict && <p role="alert" className="text-sm text-bad-700">{save.error.message}</p>}
        <Field label="Title" required>{(p) => <Input {...p} value={title} onChange={(e) => setTitle(e.target.value)} />}</Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Type">{(p) => <Select {...p} value={docType} onChange={(e) => setDocType(e.target.value)}>{DOC_TYPES.map((t) => <option key={t} value={t}>{docTypeLabel(t)}</option>)}</Select>}</Field>
          <Field label="Folder">{(p) => <Select {...p} value={folder} onChange={(e) => setFolder(e.target.value)} disabled={!d.matter_id}><option value="">Matter root</option>{(folders.data ?? []).map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}</Select>}</Field>
        </div>
        <Field label="Tags" hint="Comma-separated.">{(p) => <Input {...p} value={tags} onChange={(e) => setTags(e.target.value)} />}</Field>
        <Checkbox label="Visible to the client in the portal" hint="Only the current version, and only once scanned clean." checked={cv} onChange={(e) => setCv(e.target.checked)} />
      </div>
    </Dialog>
  )
}

function SignatureDialog({ d, open, onClose }: { d: DocDetail; open: boolean; onClose: () => void }) {
  const [signers, setSigners] = useState([{ name: '', email: '' }])
  const info = useApiQuery<IntegrationInfo>(['integration', 'esign'], '/integrations/esign', { enabled: open, retry: false })
  const send = useApiMutation(() => api.post<{ notice: string }>(`/documents/${d.id}/signature-request`, { signers: signers.filter((s) => s.name.trim() && s.email.trim()) }),
    { invalidate: [['document', d.id], ['documents']], successMessage: (r) => r.notice || 'Signature requested', onSuccess: onClose })
  const unavailable = info.data && !info.data.available
  const valid = signers.some((s) => s.name.trim() && /.+@.+/.test(s.email))
  return (
    <Dialog open={open} onClose={onClose} size="lg" title="Request signature" description={`Version ${d.current_version_no} (SHA-256 ${shortHash(d.current?.sha256)}) will be sent for signature.`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={send.isPending} disabled={!valid || !!unavailable} onClick={() => send.mutate()}><Send className="h-4 w-4" aria-hidden />Request signature</Button></>}>
      {unavailable ? <IntegrationUnavailable name={info.data?.name} setupHint={info.data?.setup_hint} mockAvailable={false} /> : (
        <div className="space-y-4">
          <SimulatedBanner>E-signature provider: {info.data?.name ?? 'mock provider'}. No envelope is sent to any signer and signatures have no legal effect. {info.data?.data_leaves_application && <span className="block text-xs">If live: {info.data.data_leaves_application}</span>}</SimulatedBanner>
          {signers.map((s, i) => (
            <div key={i} className="grid items-end gap-3 sm:grid-cols-[1fr_1fr_auto]">
              <Field label={`Signer ${i + 1} name`}>{(p) => <Input {...p} value={s.name} onChange={(e) => setSigners((c) => c.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />}</Field>
              <Field label="Email">{(p) => <Input {...p} type="email" value={s.email} onChange={(e) => setSigners((c) => c.map((x, j) => (j === i ? { ...x, email: e.target.value } : x)))} />}</Field>
              <Button variant="ghost" size="sm" aria-label={`Remove signer ${i + 1}`} disabled={signers.length === 1} onClick={() => setSigners((c) => c.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4" /></Button>
            </div>
          ))}
          <Button variant="secondary" size="sm" onClick={() => setSigners((c) => [...c, { name: '', email: '' }])}><Plus className="h-4 w-4" aria-hidden />Add signer</Button>
        </div>
      )}
    </Dialog>
  )
}

function ExportDialog({ d, open, onClose }: { d: DocDetail; open: boolean; onClose: () => void }) {
  const [reason, setReason] = useState('')
  const req = useApiMutation(() => api.post('/documents/exports', { matter_id: d.matter_id, document_ids: [d.id], reason: reason.trim() }), { invalidate: [['exports']], successMessage: 'Export requested — awaiting approval', onSuccess: () => { setReason(''); onClose() } })
  return (
    <Dialog open={open} onClose={onClose} title="Request controlled export" description="Exports leave the system and are therefore approval-gated, built by the background worker, time-limited and fully audited."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={req.isPending} disabled={reason.trim().length < 5} onClick={() => req.mutate()}>Request export</Button></>}>
      <Field label="Reason for export" required hint="Shown to the approver and recorded in the audit trail.">{(p) => <Textarea {...p} rows={3} value={reason} onChange={(e) => setReason(e.target.value)} />}</Field>
      <p className="mt-3 text-xs text-stone-600">The export bundle contains the current version of this document and a manifest with SHA-256 hashes. A second authorised person must approve it. Track it on the Exports tab.</p>
    </Dialog>
  )
}

function Overview({ d }: { d: DocDetail }) {
  const { can } = useAuth()
  const { byId } = useMatterOptions()
  const matter = d.matter_id ? byId.get(d.matter_id) : undefined
  const [holdDlg, setHoldDlg] = useState(false)
  const [ret, setRet] = useState(d.retention_until ?? '')
  const hold = useApiMutation((v: { hold: boolean; reason?: string }) => api.post(`/documents/${d.id}/legal-hold`, v), { invalidate: [['document', d.id], ['documents']], successMessage: 'Legal hold updated', onSuccess: () => setHoldDlg(false) })
  const retention = useApiMutation(() => api.post(`/documents/${d.id}/retention`, { retention_until: ret || null }), { invalidate: [['document', d.id]], successMessage: 'Retention date saved' })
  const simulate = useApiMutation((id: string) => api.post<{ notice: string }>(`/documents/signature-requests/${id}/simulate-complete`), { invalidate: [['document', d.id], ['documents']], successMessage: (r) => r.notice })
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Details" className="lg:col-span-2">
        <KeyValue columns={2} items={[
          { label: 'Matter', value: d.matter_id ? <Link className="text-navy-700 underline" to={`/matters/${d.matter_id}`}>{d.matter_reference} · {d.matter_title}</Link> : 'Client-level document' },
          { label: 'Type', value: docTypeLabel(d.doc_type) }, { label: 'Source', value: humanise(d.source) },
          { label: 'Tags', value: d.tags.length ? <span className="flex flex-wrap gap-1">{d.tags.map((t) => <Badge key={t}>{t}</Badge>)}</span> : '—' },
          { label: 'Client portal', value: d.client_visible ? 'Visible to client (when scanned clean)' : 'Internal only' },
          { label: 'Current version', value: <>v{d.current_version_no} · {d.current?.original_filename} · {d.current ? formatBytes(d.current.size_bytes) : ''}</> },
          { label: 'Created', value: <DateTime value={d.created_at} /> }, { label: 'Last updated', value: <DateTime value={d.updated_at} /> },
        ]} />
        {matter && <p className="mt-3"><RestrictedBadge level={matter.access_level} wall={matter.ethical_wall} /></p>}
      </Card>
      <Card title="Retention & legal hold">
        <div className="space-y-3 text-sm">
          <p className="flex items-center gap-2">{d.legal_hold ? <Badge tone="brass"><Gavel className="h-3 w-3" aria-hidden />Legal hold active</Badge> : <Badge>No legal hold</Badge>}</p>
          <p className="text-xs text-stone-600">A legal hold overrides any retention expiry: the document must be preserved until the hold is lifted. Retention periods are inherited from the matter’s policy; expiry triggers review, not automatic destruction.</p>
          <KeyValue items={[{ label: 'Retention until', value: d.retention_until ? <DateTime value={d.retention_until} mode="date" /> : 'Inherits from matter' }]} />
          {can('matters.approve') ? (
            <div className="space-y-2 border-t border-stone-100 pt-3">
              <Button size="sm" variant={d.legal_hold ? 'secondary' : 'brass'} onClick={() => setHoldDlg(true)}><Gavel className="h-4 w-4" aria-hidden />{d.legal_hold ? 'Lift legal hold' : 'Place legal hold'}</Button>
              <div className="flex items-end gap-2"><Field label="Override retention date" className="flex-1">{(p) => <Input {...p} type="date" value={ret} onChange={(e) => setRet(e.target.value)} />}</Field><Button size="sm" variant="secondary" loading={retention.isPending} onClick={() => retention.mutate()}>Save</Button></div>
            </div>
          ) : <p className="border-t border-stone-100 pt-3 text-xs text-stone-600">Changing legal hold or retention needs <code>matters.approve</code> (partner or compliance).</p>}
        </div>
        <ConfirmDialog open={holdDlg} onClose={() => setHoldDlg(false)} title={d.legal_hold ? 'Lift legal hold?' : 'Place legal hold?'} requireReason={d.legal_hold ? 'Reason for lifting' : 'Reason for hold'} confirmLabel={d.legal_hold ? 'Lift hold' : 'Place hold'} loading={hold.isPending}
          description={d.legal_hold ? 'The document returns to normal retention rules.' : 'The document will be preserved regardless of retention expiry.'} onConfirm={(reason) => hold.mutate({ hold: !d.legal_hold, reason })} />
      </Card>
      <Card title="Signature requests" className="lg:col-span-3" description="Signatures are requested through the e-signature integration interface.">
        {d.signature_requests.length === 0 ? <p className="text-sm text-stone-600">No signature requests. An approved document can be sent for signature.</p> : (
          <ul className="divide-y divide-stone-100">
            {d.signature_requests.map((s) => (
              <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
                <div><p className="flex flex-wrap items-center gap-2 font-medium text-navy-900">{s.provider}{s.simulated && <Badge tone="simulated">Simulated</Badge>}<DocStatusBadge status={s.status} /></p>
                  <p className="text-xs text-stone-600">{s.signers.map((x) => `${x.name} <${x.email}>${x.status ? ` — ${x.status}` : ''}`).join(' · ')} · requested <DateTime value={s.created_at} mode="relative" /></p></div>
                {s.simulated && s.status === 'sent' && (can('documents.sign') ? <Button size="sm" variant="secondary" loading={simulate.isPending} onClick={() => simulate.mutate(s.id)}><PenTool className="h-4 w-4" aria-hidden />Simulate signer completes</Button> : <span className="text-xs text-stone-600">Needs documents.sign to simulate completion.</span>)}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}

function VersionsTable({ d, onPreview }: { d: DocDetail; onPreview: (n: number) => void }) {
  const dl = useDownload()
  const cols: Column<DocVersion>[] = [
    { key: 'v', header: 'Version', cell: (v) => <span className="font-medium tabular-nums">v{v.version_no}{v.version_no === d.current_version_no && <Badge tone="info" className="ml-2">Current</Badge>}</span> },
    { key: 'f', header: 'File', cell: (v) => <div className="min-w-0"><p className="truncate">{v.original_filename}</p><p className="text-xs text-stone-600">{formatBytes(v.size_bytes)} · {v.page_count ? `${v.page_count} pp.` : 'pages n/a'}</p></div> },
    { key: 'a', header: 'Author', hideOnNarrow: true, cell: (v) => v.author_name ?? '—' },
    { key: 'c', header: 'Uploaded', cell: (v) => <DateTime value={v.created_at} /> },
    { key: 'h', header: 'SHA-256', hideOnNarrow: true, cell: (v) => <code className="font-mono text-xs" title={v.sha256}>{shortHash(v.sha256)}</code> },
    { key: 's', header: 'Checks', cell: (v) => <div className="flex flex-col items-start gap-1"><ScanBadge status={v.scan_status} /><OcrBadge status={v.ocr_status} /><Badge>{`Index ${v.index_status}`}</Badge></div> },
    { key: 'n', header: 'Change note', hideOnNarrow: true, cell: (v) => v.change_note ?? <span className="text-stone-500">—</span> },
    { key: 'x', header: <span className="sr-only">Actions</span>, align: 'right', cell: (v) => (
      <div className="flex justify-end gap-1"><Button size="sm" variant="ghost" onClick={() => onPreview(v.version_no)}>Preview</Button>
        <Tooltip text={v.scan_status === 'clean' ? 'Download the immutable original' : 'Blocked until the file is scanned clean'}><span><Button size="sm" variant="secondary" disabled={v.scan_status !== 'clean'} onClick={() => void dl(`/documents/${d.id}/versions/${v.version_no}/download`, v.original_filename)}><Download className="h-4 w-4" aria-hidden /><span className="sr-only">Download v{v.version_no}</span></Button></span></Tooltip></div>) },
  ]
  return (
    <div>
      <Note icon={<Lock className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />} className="mb-3"><strong>Originals are immutable.</strong> Every upload is stored write-once and recorded with its author, size and SHA-256. A version can never be edited or deleted; corrections are made by uploading a new version.</Note>
      <DataTable caption="Version history" columns={cols} rows={d.versions} rowKey={(v) => v.id} />
    </div>
  )
}

export function DocumentDetailPage() {
  const { id = '' } = useParams()
  const q = useApiQuery<DocDetail>(['document', id], `/documents/${id}`, { refetchInterval: (query) => (query.state.data?.current && ['pending'].includes(query.state.data.current.scan_status) ? 4000 : false) })
  return <QueryBoundary query={q} what="document">{(d) => <Body d={d} />}</QueryBoundary>
}

function Body({ d }: { d: DocDetail }) {
  const { can } = useAuth()
  const toast = useToast()
  const dl = useDownload()
  usePageTitle(d.title)
  useBreadcrumbs([{ label: 'Documents', to: '/documents' }, ...(d.matter_id ? [{ label: d.matter_reference ?? 'Matter', to: `/documents?matter=${d.matter_id}` }] : []), { label: d.title }])
  const [tabParam, setTab] = useQueryParam('tab')
  const [cite, setCite] = useQueryParams(['v', 'page', 'para'] as const)
  const tab = (TABS as readonly string[]).includes(tabParam ?? '') ? (tabParam as string) : cite.page ? 'preview' : 'overview'
  const { byId } = useMatterOptions()
  const matter = d.matter_id ? byId.get(d.matter_id) : undefined
  const [edit, setEdit] = useState(false), [sig, setSig] = useState(false), [exp, setExp] = useState(false), [ver, setVer] = useState(false)
  const [decide, setDecide] = useState<null | boolean>(null)
  const [sup, setSup] = useState(false)
  const qc = useQueryClient()
  const inv = { invalidate: [['document', d.id], ['documents']] as string[][] }
  const review = useApiMutation(() => api.post(`/documents/${d.id}/review-request`), { ...inv, successMessage: 'Sent for review' })
  const approve = useApiMutation((v: { approve: boolean; note?: string }) => api.post(`/documents/${d.id}/approve`, v), { ...inv, successMessage: (r) => ((r as DocDetail).status === 'approved' ? 'Document approved' : 'Review declined — returned to draft'), onSuccess: () => setDecide(null) })
  const supersede = useApiMutation((note?: string) => api.post(`/documents/${d.id}/supersede`, { note }), { ...inv, successMessage: 'Document superseded', onSuccess: () => setSup(false) })

  const cur = d.current
  const previewNo = Number(cite.v) || d.current_version_no
  const flowStatus = d.status === 'superseded' ? 'draft' : d.status
  const canDownload = !!cur && cur.scan_status === 'clean'

  return (
    <div>
      <PageHeader eyebrow={d.matter_reference ?? 'Client-level document'} title={d.title}
        description={<span className="flex flex-wrap items-center gap-2"><DocStatusBadge status={d.status} /><span className="text-xs">v{d.current_version_no}</span>{cur && <ScanBadge status={cur.scan_status} />}{cur && <OcrBadge status={cur.ocr_status} />}
          {d.legal_hold && <Badge tone="brass"><Gavel className="h-3 w-3" aria-hidden />Legal hold</Badge>}<RestrictedBadge level={matter?.access_level} wall={matter?.ethical_wall} /></span>}
        actions={<>
          <Tooltip text={canDownload ? 'Download the immutable original of the current version' : cur ? `Blocked: malware scan status is “${cur.scan_status}”` : 'No file'}><span><Button variant="secondary" disabled={!canDownload} onClick={() => cur && void dl(`/documents/${d.id}/versions/${cur.version_no}/download`, cur.original_filename)}><Download className="h-4 w-4" aria-hidden />Download original</Button></span></Tooltip>
          {can('documents.write') && <Button variant="secondary" onClick={() => setVer(true)}><FilePlus2 className="h-4 w-4" aria-hidden />New version</Button>}
          {can('documents.write') && <Button variant="secondary" onClick={() => setEdit(true)}><PenLine className="h-4 w-4" aria-hidden />Edit details</Button>}
          <Tooltip text={can('documents.export') ? 'Request an approval-gated export' : 'Needs documents.export'}><span><Button variant="ghost" disabled={!can('documents.export') || !d.matter_id} onClick={() => setExp(true)}><PackageOpen className="h-4 w-4" aria-hidden />Request export</Button></span></Tooltip>
        </>} />

      <Card className="mb-4" title="Review & signature" description="Draft → in review → approved → signature requested → signed. Uploading a new version returns the document to draft.">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {d.status === 'superseded' ? <Badge tone="neutral">Superseded — a later document replaces this one</Badge> : <StatusStepper steps={DOC_FLOW} current={flowStatus} />}
          <div className="flex flex-wrap items-center gap-2">
            {d.status === 'draft' && (can('documents.write') ? <Button onClick={() => review.mutate()} loading={review.isPending}><FileCheck2 className="h-4 w-4" aria-hidden />Request review</Button> : <span className="text-xs text-stone-600">Needs documents.write to request review.</span>)}
            {d.status === 'in_review' && (can('documents.approve') ? <><Button onClick={() => setDecide(true)}>Approve…</Button><Button variant="secondary" onClick={() => setDecide(false)}><Undo2 className="h-4 w-4" aria-hidden />Return to draft…</Button></> : <span className="text-xs text-stone-600">Waiting for a reviewer with documents.approve. Approval binds to this exact version and hash.</span>)}
            {d.status === 'approved' && (<>{can('documents.sign') ? <Button onClick={() => setSig(true)}><Send className="h-4 w-4" aria-hidden />Request signature</Button> : <span className="text-xs text-stone-600">Needs documents.sign to request signature.</span>}
              {can('documents.approve') && <Button variant="ghost" onClick={() => setSup(true)}>Supersede</Button>}</>)}
            {d.status === 'signature_requested' && <span className="text-xs text-stone-600">Awaiting signers — see Signature requests on the Overview tab.</span>}
            {d.status === 'signed' && <Badge tone="success">Signed{d.signature_requests.some((s) => s.simulated) ? ' (simulated)' : ''}</Badge>}
            {['draft', 'approved', 'signed'].includes(d.status) && can('documents.approve') && d.status !== 'approved' && <Button variant="ghost" onClick={() => setSup(true)}>Supersede</Button>}
          </div>
        </div>
      </Card>

      <Tabs label="Document sections" value={tab} onChange={(t) => setTab(t === 'overview' ? null : t)} className="mb-4"
        tabs={[{ id: 'overview', label: 'Overview' }, { id: 'preview', label: 'Preview' }, { id: 'versions', label: 'Versions', badge: <Badge>{d.versions.length}</Badge> }, { id: 'compare', label: 'Compare', disabled: d.versions.length < 2 }]} />
      <TabPanel id="overview" value={tab}><Overview d={d} /></TabPanel>
      <TabPanel id="preview" value={tab}>
        <div className="mb-3 flex flex-wrap items-end gap-3">
          <Field label="Version" className="w-64">{(p) => <Select {...p} value={previewNo} onChange={(e) => setCite({ v: e.target.value, page: null, para: null })}>{d.versions.map((v) => <option key={v.id} value={v.version_no}>v{v.version_no} · {v.original_filename}</option>)}</Select>}</Field>
        </div>
        <Card><PreviewPane documentId={d.id} title={d.title} versionNo={previewNo} hlPage={Number(cite.page) || undefined} hlPara={Number(cite.para) || undefined}
          onCite={(page, para) => { setCite({ v: String(previewNo), page: String(page), para: String(para) }); toast.push({ tone: 'info', title: `Pinned page ${page} ¶${para}`, description: 'The address bar now links straight to this paragraph.' }) }} /></Card>
      </TabPanel>
      <TabPanel id="versions" value={tab}><VersionsTable d={d} onPreview={(n) => { setCite({ v: String(n), page: null, para: null }); setTab('preview') }} /></TabPanel>
      <TabPanel id="compare" value={tab}><Card><ComparePane documentId={d.id} versions={d.versions} /></Card></TabPanel>

      <MetadataDialog key={`m-${d.version}`} d={d} open={edit} onClose={() => setEdit(false)} />
      <SignatureDialog d={d} open={sig} onClose={() => setSig(false)} />
      <ExportDialog d={d} open={exp} onClose={() => setExp(false)} />
      <NewVersionDialog open={ver} onClose={() => setVer(false)} documentId={d.id} currentNo={d.current_version_no}
        onDone={() => { toast.push({ tone: 'success', title: `Version ${d.current_version_no + 1} stored`, description: 'It will be scanned and indexed in the background.' }); void qc.invalidateQueries({ queryKey: ['document', d.id] }); void qc.invalidateQueries({ queryKey: ['documents'] }) }} />
      <ConfirmDialog open={decide !== null} onClose={() => setDecide(null)} title={decide ? 'Approve this version?' : 'Return to draft?'} requireReason={decide ? 'Approval note' : 'Reason'} confirmLabel={decide ? 'Approve' : 'Return to draft'} loading={approve.isPending}
        description={decide ? `Your approval is bound to version ${d.current_version_no} (SHA-256 ${shortHash(cur?.sha256)}). A later version needs a fresh review.` : 'The author is told what to change.'} onConfirm={(note) => approve.mutate({ approve: !!decide, note })} />
      <ConfirmDialog open={sup} onClose={() => setSup(false)} title="Mark as superseded?" requireReason="Why is it superseded?" confirmLabel="Supersede" loading={supersede.isPending} description="Superseded documents are kept for the record but no longer current." onConfirm={(n) => supersede.mutate(n)} />
    </div>
  )
}
