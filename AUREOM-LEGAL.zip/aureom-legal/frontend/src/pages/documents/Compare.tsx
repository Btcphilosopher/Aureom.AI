import { useState } from 'react'
import { Minus, PenLine, Plus } from 'lucide-react'
import { EmptyState, Field, Select, QueryBoundary } from '@/components/ui'
import { ApiError, qs, useApiQuery } from '@/lib/api'
import type { CompareOp, CompareResult, DocVersion } from '@/types/documents'
import { Note, shortHash } from './common'

const para = (p: { page: number; paragraph: number; text: string }) => (
  <div key={`${p.page}-${p.paragraph}`} className="flex gap-2"><span className="w-14 shrink-0 text-right font-mono text-2xs text-stone-500">p.{p.page} ¶{p.paragraph}</span><p className="whitespace-pre-wrap text-sm leading-relaxed">{p.text}</p></div>
)

function Op({ op }: { op: CompareOp }) {
  if (op.op === 'equal') return <div className="rounded border border-dashed border-stone-300 px-3 py-1.5 text-xs text-stone-600">{op.count} unchanged paragraph{op.count === 1 ? '' : 's'}</div>
  const meta = { added: { icon: Plus, label: 'Added', cls: 'border-ok-600 bg-ok-50' }, removed: { icon: Minus, label: 'Removed', cls: 'border-bad-600 bg-bad-50' }, changed: { icon: PenLine, label: 'Changed', cls: 'border-warn-600 bg-warn-50' } }[op.op]
  const Icon = meta.icon
  return (
    <section className={`rounded-md border-l-4 ${meta.cls} p-3`} aria-label={meta.label}>
      <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-navy-900"><Icon className="h-3.5 w-3.5" aria-hidden />{meta.label}</p>
      <div className="grid gap-3 md:grid-cols-2">
        <div><p className="mb-1 text-2xs font-semibold uppercase text-stone-600">Earlier</p>{op.from?.length ? <div className="space-y-1.5 line-through decoration-bad-600/60 decoration-1">{op.from.map(para)}</div> : <p className="text-xs italic text-stone-500">— nothing —</p>}</div>
        <div><p className="mb-1 text-2xs font-semibold uppercase text-stone-600">Later</p>{op.to?.length ? <div className="space-y-1.5">{op.to.map(para)}</div> : <p className="text-xs italic text-stone-500">— nothing —</p>}</div>
      </div>
    </section>
  )
}

/** Paragraph-level comparison of two versions (only where text has been extracted from both). */
export function ComparePane({ documentId, versions }: { documentId: string; versions: DocVersion[] }) {
  const sorted = [...versions].sort((a, b) => b.version_no - a.version_no)
  const [to, setTo] = useState(sorted[0]?.version_no ?? 1)
  const [from, setFrom] = useState(sorted[1]?.version_no ?? 1)
  const q = useApiQuery<CompareResult>(['document', documentId, 'compare', from, to], `/documents/${documentId}/compare${qs({ from, to })}`, { enabled: versions.length > 1 && from !== to, retry: false })
  if (versions.length < 2) return <EmptyState title="Only one version" description="Upload a new version to compare it with the earlier one." />
  return (
    <div>
      <div className="mb-4 grid max-w-xl gap-3 sm:grid-cols-2">
        <Field label="Earlier version">{(p) => <Select {...p} value={from} onChange={(e) => setFrom(Number(e.target.value))}>{sorted.map((v) => <option key={v.id} value={v.version_no}>v{v.version_no} · {v.original_filename}</option>)}</Select>}</Field>
        <Field label="Later version">{(p) => <Select {...p} value={to} onChange={(e) => setTo(Number(e.target.value))}>{sorted.map((v) => <option key={v.id} value={v.version_no}>v{v.version_no} · {v.original_filename}</option>)}</Select>}</Field>
      </div>
      {from === to ? <Note>Choose two different versions to compare.</Note> : q.isError && q.error instanceof ApiError && q.error.code === 'compare_unsupported' ? (
        <Note tone="warn"><strong>Comparison is not supported for these versions.</strong> {q.error.message}</Note>
      ) : (
        <QueryBoundary query={q} what="comparison" isEmpty={() => false}>
          {(r) => (
            <div>
              <p className="mb-3 flex flex-wrap gap-x-5 gap-y-1 text-sm" aria-label="Comparison summary">
                <span><strong className="tabular-nums">{r.summary.added}</strong> added</span><span><strong className="tabular-nums">{r.summary.removed}</strong> removed</span>
                <span><strong className="tabular-nums">{r.summary.changed}</strong> changed</span><span className="text-stone-600"><span className="tabular-nums">{r.summary.unchanged}</span> unchanged</span>
                <span className="text-xs text-stone-600">v{r.from_version} <code className="font-mono">{shortHash(r.from_sha256)}</code> → v{r.to_version} <code className="font-mono">{shortHash(r.to_sha256)}</code></span>
              </p>
              <div className="space-y-2">{r.operations.map((o, i) => <Op key={i} op={o} />)}</div>
            </div>
          )}
        </QueryBoundary>
      )}
    </div>
  )
}
