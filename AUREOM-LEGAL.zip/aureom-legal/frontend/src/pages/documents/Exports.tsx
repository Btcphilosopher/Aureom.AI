import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Download, ShieldCheck } from 'lucide-react'
import { Badge, Button, ConfirmDialog, DataTable, DateTime, QueryBoundary, Tooltip, type Column } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import type { ExportRow } from '@/types/documents'
import { Note, shortHash, useDownload, useMatterOptions } from './common'

const tone = (s: string) => (s === 'ready' ? 'success' : s === 'failed' || s === 'rejected' ? 'danger' : s === 'pending_approval' ? 'warning' : s === 'expired' ? 'neutral' : 'info') as 'success' | 'danger' | 'warning' | 'neutral' | 'info'

export default function ExportsTab({ highlight }: { highlight?: string | null }) {
  const { can } = useAuth()
  const dl = useDownload()
  const { byId } = useMatterOptions()
  const q = useApiQuery<ExportRow[]>(['exports'], '/documents/exports', { refetchInterval: (query) => (query.state.data?.some((e) => ['approved', 'building'].includes(e.status)) ? 3000 : false) })
  const [decision, setDecision] = useState<{ row: ExportRow; approve: boolean } | null>(null)
  const decide = useApiMutation((v: { id: string; approve: boolean; note?: string }) => api.post(`/documents/exports/${v.id}/decision`, { approve: v.approve, note: v.note }),
    { invalidate: [['exports']], successMessage: 'Decision recorded', onSuccess: () => setDecision(null), onError: () => setDecision(null) })
  const cols: Column<ExportRow>[] = [
    { key: 'm', header: 'Matter', cell: (e) => { const m = byId.get(e.matter_id); return <div className={highlight === e.id ? 'rounded bg-brass-50 px-1 ring-1 ring-brass-400' : ''}><Link className="font-medium text-navy-800 underline" to={`/documents?matter=${e.matter_id}`}>{m?.reference ?? 'Matter'}</Link><p className="text-xs text-stone-600">{e.document_ids.length} document{e.document_ids.length === 1 ? '' : 's'}</p></div> } },
    { key: 'r', header: 'Reason', cell: (e) => <span className="line-clamp-2 text-sm">{e.reason}</span> },
    { key: 's', header: 'Status', cell: (e) => <div><Badge tone={tone(e.status)}>{e.status.replace(/_/g, ' ')}</Badge>{e.error && <p className="mt-1 text-xs text-bad-700">{e.error}</p>}</div> },
    { key: 'h', header: 'Bundle SHA-256', hideOnNarrow: true, cell: (e) => <code className="font-mono text-xs">{shortHash(e.sha256)}</code> },
    { key: 'e', header: 'Expires', hideOnNarrow: true, cell: (e) => (e.expires_at ? <DateTime value={e.expires_at} /> : '—') },
    { key: 'd', header: 'Downloads', numeric: true, cell: (e) => e.download_count },
    { key: 'x', header: <span className="sr-only">Actions</span>, align: 'right', cell: (e) => (
      <div className="flex justify-end gap-1.5">
        {e.status === 'pending_approval' && (can('documents.export_approve') ? <><Button size="sm" onClick={() => setDecision({ row: e, approve: true })}>Approve</Button><Button size="sm" variant="secondary" onClick={() => setDecision({ row: e, approve: false })}>Reject</Button></>
          : <span className="text-xs text-stone-600">Awaiting approver</span>)}
        {e.status === 'ready' && <Tooltip text="Time-limited, audited download"><span><Button size="sm" variant="secondary" onClick={() => void dl(`/documents/exports/${e.id}/download`, `export-${e.id.slice(0, 8)}.zip`).then(() => q.refetch())}><Download className="h-4 w-4" aria-hidden />Download</Button></span></Tooltip>}
      </div>) },
  ]
  return (
    <div>
      <Note icon={<ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />} className="mb-4"><strong>Controlled export.</strong> Exports need a documented reason and approval from a second authorised person (four-eyes), are built asynchronously with a manifest of SHA-256 hashes, expire, and every download is audited. Matters with exports disabled (ethical walls, client instructions) cannot be exported.</Note>
      <QueryBoundary query={q} what="exports" empty={<p className="rounded-lg border border-stone-200 bg-white p-6 text-sm text-stone-600">No export requests. Request one from a document’s page.</p>}>
        {(rows) => <DataTable caption="Export requests" columns={cols} rows={rows} rowKey={(e) => e.id} />}
      </QueryBoundary>
      <ConfirmDialog open={!!decision} onClose={() => setDecision(null)} title={decision?.approve ? 'Approve this export?' : 'Reject this export?'} requireReason={decision?.approve ? 'Approval note' : 'Reason for rejecting'} confirmLabel={decision?.approve ? 'Approve export' : 'Reject'} tone={decision?.approve ? 'primary' : 'danger'} loading={decide.isPending}
        description={decision ? `Reason given by the requester: “${decision.row.reason}”. You cannot approve an export you requested yourself.` : undefined} onConfirm={(note) => { if (decision) decide.mutate({ id: decision.row.id, approve: decision.approve, note }) }} />
    </div>
  )
}
