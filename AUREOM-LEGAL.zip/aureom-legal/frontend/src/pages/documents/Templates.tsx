import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { BadgeCheck, FilePlus2, Plus, Trash2, Wand2 } from 'lucide-react'
import { Badge, Button, Card, Checkbox, DataTable, DateTime, Dialog, Field, Input, QueryBoundary, Select, Textarea, Tooltip, type Column } from '@/components/ui'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useDebounce } from '@/hooks'
import { humanise } from '@/lib/format'
import type { DocDetail, DocTemplate, TemplateField, TemplatePreview } from '@/types/documents'
import { DOC_TYPES, MatterSelect, Note, docTypeLabel } from './common'

const PLACEHOLDER = /\{\{\s*([\w.]+)\s*\}\}/g
const BUILTIN = ['today', 'matter.reference', 'matter.title', 'client.name', 'client.address', 'partner.name', 'fee_earner.name']
const keysOf = (body: string) => Array.from(new Set(Array.from(body.matchAll(PLACEHOLDER), (m) => m[1]!)))

function TemplateEditor({ tpl, open, onClose }: { tpl: DocTemplate | null; open: boolean; onClose: () => void }) {
  const [name, setName] = useState(''), [docType, setDocType] = useState('letter'), [area, setArea] = useState(''), [body, setBody] = useState('')
  const [fields, setFields] = useState<TemplateField[]>([])
  useEffect(() => { if (open) { setName(tpl?.name ?? ''); setDocType(tpl?.doc_type ?? 'letter'); setArea(tpl?.practice_area ?? ''); setBody(tpl?.body ?? ''); setFields(tpl?.fields ?? []) } }, [open, tpl])
  const found = useMemo(() => keysOf(body), [body])
  const custom = found.filter((k) => !BUILTIN.includes(k))
  const save = useApiMutation(() => {
    const payload = { name: name.trim(), doc_type: docType, practice_area: area || null, body, fields: custom.map((k) => ({ source: 'custom', ...(fields.find((f) => f.key === k) ?? {}), key: k, label: fields.find((f) => f.key === k)?.label || humanise(k) })) }
    return tpl ? api.patch<DocTemplate>(`/documents/templates/${tpl.id}`, payload) : api.post<DocTemplate>('/documents/templates', payload)
  }, { invalidate: [['templates']], successMessage: tpl ? 'Template saved — approval reset' : 'Template created (not yet approved)', onSuccess: onClose })
  const setField = (k: string, patch: Partial<TemplateField>) => setFields((cur) => (cur.some((f) => f.key === k) ? cur.map((f) => (f.key === k ? { ...f, ...patch } : f)) : [...cur, { key: k, source: 'custom', ...patch }]))
  return (
    <Dialog open={open} onClose={onClose} size="xl" title={tpl ? `Edit template: ${tpl.name}` : 'New template'} description="Use {{placeholders}}. Values are inserted as plain text — templates cannot run code."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={save.isPending} disabled={!name.trim() || !body.trim()} onClick={() => save.mutate()}>Save template</Button></>}>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-4">
          <Field label="Name" required>{(p) => <Input {...p} value={name} onChange={(e) => setName(e.target.value)} />}</Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Type">{(p) => <Select {...p} value={docType} onChange={(e) => setDocType(e.target.value)}>{[...new Set(['letter', 'attendance_note', ...DOC_TYPES])].map((t) => <option key={t} value={t}>{docTypeLabel(t)}</option>)}</Select>}</Field>
            <Field label="Practice area">{(p) => <Select {...p} value={area} onChange={(e) => setArea(e.target.value)}><option value="">Any</option>{['commercial', 'property', 'litigation', 'employment', 'private_client', 'corporate'].map((t) => <option key={t} value={t}>{humanise(t)}</option>)}</Select>}</Field>
          </div>
          <Field label="Body" required hint="e.g. Dear {{client.name}}, re {{matter.reference}} …">{(p) => <Textarea {...p} rows={14} className="font-mono text-xs" value={body} onChange={(e) => setBody(e.target.value)} />}</Field>
        </div>
        <div className="space-y-3">
          <div><h3 className="text-sm font-semibold text-navy-900">Built-in placeholders</h3>
            <p className="mb-1 text-xs text-stone-600">Filled automatically from the chosen matter. Click to insert at the end.</p>
            <div className="flex flex-wrap gap-1.5">{BUILTIN.map((k) => <button key={k} type="button" className="rounded border border-stone-300 bg-ivory-50 px-1.5 py-0.5 font-mono text-2xs hover:border-brass-400" onClick={() => setBody((b) => `${b}{{${k}}}`)}>{`{{${k}}}`}</button>)}</div></div>
          <div><h3 className="text-sm font-semibold text-navy-900">Fields found in the body</h3>
            {found.length === 0 ? <p className="text-xs text-stone-600">None yet.</p> : (
              <ul className="space-y-2">{found.map((k) => {
                const builtin = BUILTIN.includes(k); const f = fields.find((x) => x.key === k)
                return (<li key={k} className="flex flex-wrap items-center gap-2 text-xs"><code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono">{k}</code>
                  {builtin ? <Badge tone="info">automatic</Badge> : <><Input aria-label={`Label for ${k}`} className="h-8 max-w-[12rem] text-xs" placeholder="Label" value={f?.label ?? ''} onChange={(e) => setField(k, { label: e.target.value })} />
                    <Checkbox label="required" checked={!!f?.required} onChange={(e) => setField(k, { required: e.target.checked })} /></>}</li>)
              })}</ul>)}
          </div>
          <Note>Editing a template resets its approval. Only approved templates can generate documents or be used by the drafting agent.</Note>
        </div>
      </div>
    </Dialog>
  )
}

function PreviewDialog({ tpl, open, onClose }: { tpl: DocTemplate | null; open: boolean; onClose: () => void }) {
  const nav = useNavigate()
  const [matterId, setMatterId] = useState('')
  const [custom, setCustom] = useState<Record<string, string>>({})
  const [title, setTitle] = useState('')
  const [incomplete, setIncomplete] = useState(false)
  useEffect(() => { if (open) { setMatterId(''); setCustom({}); setTitle(''); setIncomplete(false) } }, [open, tpl?.id])
  const dc = useDebounce(custom, 400)
  const prev = useApiQuery<TemplatePreview>(['templates', 'preview', tpl?.id, matterId, JSON.stringify(dc)], () => api.post<TemplatePreview>(`/documents/templates/${tpl!.id}/preview`, { matter_id: matterId || null, custom: dc }), { enabled: open && !!tpl, retry: false })
  const gen = useApiMutation(() => api.post<DocDetail>(`/documents/templates/${tpl!.id}/generate`, { matter_id: matterId, custom, title: title.trim() || undefined, allow_incomplete: incomplete }),
    { errorToast: false, successMessage: 'Draft document generated', invalidate: [['documents']], onSuccess: (d) => { onClose(); nav(`/documents/${d.id}`) } })
  const missing = prev.data?.missing ?? []
  return (
    <Dialog open={open} onClose={onClose} size="xl" title={`Preview & generate: ${tpl?.name ?? ''}`} description="Preview shows exactly how fields will be substituted. Nothing is stored until you generate."
      footer={<><Button variant="secondary" onClick={onClose}>Close</Button>
        <Tooltip text={!tpl?.approved ? 'Only approved templates can generate documents' : !matterId ? 'Choose a matter' : missing.length && !incomplete ? 'Fill the missing fields or allow incomplete' : 'Create a draft document (v1)'}>
          <span><Button loading={gen.isPending} disabled={!tpl?.approved || !matterId || (missing.length > 0 && !incomplete)} onClick={() => gen.mutate()}><FilePlus2 className="h-4 w-4" aria-hidden />Generate draft</Button></span></Tooltip></>}>
      <div className="grid gap-4 lg:grid-cols-[18rem_1fr]">
        <div className="space-y-3">
          <Field label="Matter" hint="Supplies the matter, client and fee-earner values.">{(p) => <MatterSelect {...p} value={matterId} onChange={setMatterId} emptyLabel="No matter (preview only)" />}</Field>
          <Field label="Title for the new document">{(p) => <Input {...p} value={title} onChange={(e) => setTitle(e.target.value)} placeholder={tpl?.name} />}</Field>
          <h3 className="pt-1 text-sm font-semibold text-navy-900">Fields</h3>
          {prev.data?.fields.map((f) => (
            <Field key={f.key} label={`${f.key}${f.required ? ' *' : ''}`} error={f.missing ? 'No value — will show as [[MISSING]]' : undefined}>
              {(p) => <Input {...p} value={custom[f.key] ?? ''} placeholder={f.value && !(f.key in custom) ? f.value : ''} onChange={(e) => setCustom((c) => ({ ...c, [f.key]: e.target.value }))} />}
            </Field>
          ))}
          <Checkbox label="Allow incomplete (leave [[MISSING]] markers)" checked={incomplete} onChange={(e) => setIncomplete(e.target.checked)} />
          {gen.error && <p role="alert" className="text-xs text-bad-700">{gen.error.message}{Array.isArray(gen.error.details.missing) ? ` Missing: ${(gen.error.details.missing as string[]).join(', ')}` : ''}</p>}
        </div>
        <div>
          <QueryBoundary query={prev} what="preview" loading={<p className="text-sm text-stone-600">Rendering preview…</p>} isEmpty={() => false}>
            {(r) => (
              <div>
                <p className="mb-2 flex items-center gap-2 text-xs text-stone-600">Template v{r.template_version} {r.approved ? <Badge tone="success">Approved</Badge> : <Badge tone="warning">Not approved</Badge>}{missing.length > 0 && <Badge tone="warning">{missing.length} unresolved</Badge>}</p>
                <pre className="max-h-[26rem] overflow-auto whitespace-pre-wrap rounded-md border border-stone-200 bg-ivory-50 p-4 font-sans text-sm leading-relaxed text-navy-900" aria-label="Rendered preview">
                  {r.text.split(/(\[\[MISSING: [\w.]+\]\])/g).map((part, i) => part.startsWith('[[MISSING') ? <mark key={i} className="rounded bg-warn-100 px-1 font-semibold text-warn-700 outline outline-1 outline-warn-600">{part}</mark> : <span key={i}>{part}</span>)}
                </pre>
              </div>
            )}
          </QueryBoundary>
        </div>
      </div>
    </Dialog>
  )
}

export default function TemplatesTab() {
  const { can } = useAuth()
  const q = useApiQuery<DocTemplate[]>(['templates'], '/documents/templates')
  const [edit, setEdit] = useState<{ tpl: DocTemplate | null } | null>(null)
  const [prev, setPrev] = useState<DocTemplate | null>(null)
  const approve = useApiMutation((id: string) => api.post(`/documents/templates/${id}/approve`), { invalidate: [['templates']], successMessage: 'Template approved for use' })
  const cols: Column<DocTemplate>[] = [
    { key: 'n', header: 'Template', cell: (t) => <div><p className="font-medium text-navy-900">{t.name}</p><p className="text-xs text-stone-600">{docTypeLabel(t.doc_type)}{t.practice_area ? ` · ${humanise(t.practice_area)}` : ''} · v{t.template_version} · {keysOf(t.body).length} placeholders</p></div> },
    { key: 'a', header: 'Status', cell: (t) => (t.approved ? <Badge tone="success"><BadgeCheck className="h-3 w-3" aria-hidden />Approved</Badge> : <Badge tone="warning">Not approved</Badge>) },
    { key: 'u', header: 'Updated', hideOnNarrow: true, cell: (t) => <DateTime value={t.updated_at} mode="relative" /> },
    { key: 'x', header: <span className="sr-only">Actions</span>, align: 'right', cell: (t) => (
      <div className="flex flex-wrap justify-end gap-1.5">
        <Button size="sm" variant="secondary" onClick={() => setPrev(t)}><Wand2 className="h-4 w-4" aria-hidden />Preview / generate</Button>
        {can('documents.templates') && <Button size="sm" variant="ghost" onClick={() => setEdit({ tpl: t })}>Edit</Button>}
        {!t.approved && (can('documents.templates') && can('documents.approve') ? <Button size="sm" onClick={() => approve.mutate(t.id)} loading={approve.isPending && approve.variables === t.id}>Approve</Button>
          : <Tooltip text="Approval needs documents.templates and documents.approve"><span><Button size="sm" disabled>Approve</Button></span></Tooltip>)}
      </div>) },
  ]
  return (
    <div>
      <Note className="mb-4"><strong>Reusable templates.</strong> Only approved templates generate documents or feed the drafting agent. Substitution is previewed first; unresolved fields are highlighted and block generation unless you explicitly allow incomplete output.</Note>
      <div className="mb-3 flex justify-end">{can('documents.templates') ? <Button onClick={() => setEdit({ tpl: null })}><Plus className="h-4 w-4" aria-hidden />New template</Button> : <Tooltip text="Needs documents.templates"><span><Button disabled>New template</Button></span></Tooltip>}</div>
      <QueryBoundary query={q} what="templates" empty={<Card><p className="text-sm text-stone-600">No templates yet.</p></Card>}>
        {(rows) => <DataTable caption="Document templates" columns={cols} rows={rows} rowKey={(t) => t.id} />}
      </QueryBoundary>
      <TemplateEditor tpl={edit?.tpl ?? null} open={!!edit} onClose={() => setEdit(null)} />
      <PreviewDialog tpl={prev} open={!!prev} onClose={() => setPrev(null)} />
    </div>
  )
}
