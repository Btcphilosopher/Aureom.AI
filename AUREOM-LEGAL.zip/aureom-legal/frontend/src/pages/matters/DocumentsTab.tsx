import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Lock } from 'lucide-react'
import { Badge, Card, DataTable, DateTime, EmptyState, Field, FileDropzone, Select, StatusBadge, type Column } from '@/components/ui'
import { api, qs, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useQueryClient } from '@tanstack/react-query'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { MatterDetail } from '@/types/matters'
import { errMsg } from '../clients/common'

interface Doc { id: string; title: string; doc_type: string; status: string; current_version_no: number; client_visible: boolean; updated_at: string; legal_hold: boolean; current: { scan_status: string; ocr_status: string; original_filename: string } | null }
const DOC_TYPES = ['agreement', 'letter', 'advice', 'engagement_letter', 'pleading', 'evidence', 'identity', 'financial', 'note', 'other']
const ACCEPT = '.pdf,.docx,.txt,.md,.csv,.png,.jpg,.jpeg,.eml'

export default function DocumentsTab({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const nav = useNavigate()
  const qc = useQueryClient()
  const [docType, setDocType] = useState('other')
  const [results, setResults] = useState<{ name: string; ok: boolean; msg: string }[]>([])
  const [busy, setBusy] = useState(false)
  const q = useApiQuery<Page<Doc>>(['documents', 'matter', m.id], `/documents${qs({ matter_id: m.id, limit: 50 })}`, { enabled: can('documents.read') })
  if (!can('documents.read')) return <EmptyState icon={<Lock className="h-5 w-5" />} title="Documents are not available to your role" description="Finance and administrator roles cannot read matter documents (documents.read)." />
  const upload = async (files: File[]) => {
    setBusy(true); const out: typeof results = []
    for (const f of files) {
      try { await api.upload('/documents', f, { matter_id: m.id, doc_type: docType, title: f.name.replace(/\.[^.]+$/, '') }); out.push({ name: f.name, ok: true, msg: 'Uploaded — scanning, text extraction and indexing run in the background.' }) }
      catch (e) { out.push({ name: f.name, ok: false, msg: errMsg(e) }) }
    }
    setResults(out); setBusy(false); void qc.invalidateQueries({ queryKey: ['documents'] }); void qc.invalidateQueries({ queryKey: ['matter', m.id, 'summary'] })
  }
  const cols: Column<Doc>[] = [
    { key: 't', header: 'Document', cell: (d) => <div><p className="font-medium text-navy-900">{d.title}</p><p className="text-xs text-stone-600">{d.current?.original_filename}</p></div> },
    { key: 'type', header: 'Type', cell: (d) => humanise(d.doc_type) },
    { key: 'v', header: 'Version', numeric: true, cell: (d) => `v${d.current_version_no}` },
    { key: 's', header: 'Status', cell: (d) => <span className="inline-flex flex-wrap gap-1"><StatusBadge status={d.status} />{d.client_visible && <Badge tone="info">Client-visible</Badge>}{d.legal_hold && <Badge tone="danger">Hold</Badge>}</span> },
    { key: 'scan', header: 'Scan', hideOnNarrow: true, cell: (d) => <StatusBadge status={d.current?.scan_status} /> },
    { key: 'u', header: 'Updated', hideOnNarrow: true, cell: (d) => <DateTime value={d.updated_at} mode="date" /> },
  ]
  return (
    <div className="space-y-5">
      {can('documents.write') && m.status !== 'closed' && (
        <Card title="Upload" description="Drag files here or browse. Originals are stored immutably; each upload is scanned before it can be previewed or downloaded.">
          <div className="grid gap-4 sm:grid-cols-[14rem_1fr] sm:items-start">
            <Field label="Document type"><Select value={docType} onChange={(e) => setDocType(e.target.value)}>{DOC_TYPES.map((t) => <option key={t} value={t}>{humanise(t)}</option>)}</Select></Field>
            <FileDropzone accept={ACCEPT} maxSizeBytes={25 * 1024 * 1024} busy={busy} onFiles={upload} hint="PDF, Word (.docx), text, CSV, images and .eml — up to 25 MB. The server checks file content, not just the extension." />
          </div>
          <ul aria-live="polite" className="mt-3 space-y-1">{results.map((r) => <li key={r.name} className={`text-sm ${r.ok ? 'text-ok-700' : 'text-bad-700'}`}>{r.name}: {r.msg}</li>)}</ul>
        </Card>)}
      <DataTable caption={`Documents on ${m.reference}`} columns={cols} rows={q.data?.items} rowKey={(d) => d.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(d) => nav(`/documents/${d.id}`)}
        emptyTitle="No documents yet" emptyDescription="Upload an engagement letter, agreement or any matter file." />
    </div>
  )
}
