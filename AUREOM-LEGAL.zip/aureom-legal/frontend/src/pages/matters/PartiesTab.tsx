import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { Button, Card, ConfirmDialog, Dialog, Field, IconButton, Input, Select, StatusBadge } from '@/components/ui'
import { api, useApiMutation } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import type { PartyRole } from '@/types/clients'
import type { MatterDetail, MatterParty } from '@/types/matters'
import { ContactPicker } from '../clients/ContactPicker'
import { PARTY_ROLES, RoleBadge, errMsg } from '../clients/common'

export default function PartiesTab({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const [add, setAdd] = useState(false)
  const [rm, setRm] = useState<MatterParty | null>(null)
  const inv = [['matter', m.id]] as never
  const del = useApiMutation((pid: string) => api.delete(`/matters/${m.id}/parties/${pid}`), { invalidate: inv, successMessage: 'Party removed' })
  const byContact = new Map<string, MatterParty[]>()
  m.parties.forEach((p) => byContact.set(p.contact.id, [...(byContact.get(p.contact.id) ?? []), p]))
  return (
    <Card title="Parties on this matter" description="The same contact can hold several roles here, and different roles on other matters."
      actions={can('matters.write') && m.status !== 'closed' ? <Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setAdd(true)}>Add party</Button> : undefined}>
      <ul className="divide-y divide-stone-200">
        {[...byContact.values()].map((ps) => (
          <li key={ps[0]!.contact.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
            <div><Link to={`/clients/${ps[0]!.contact.id}`} className="font-medium text-navy-700 underline">{ps[0]!.contact.name}</Link> <span className="text-xs text-stone-600">{humanise(ps[0]!.contact.kind)}</span> <StatusBadge status={ps[0]!.contact.status} />
              {ps.some((p) => p.notes) && <p className="mt-0.5 text-xs text-stone-600">{ps.map((p) => p.notes).filter(Boolean).join(' · ')}</p>}</div>
            <div className="flex flex-wrap items-center gap-1.5">{ps.map((p) => (
              <span key={p.id} className="inline-flex items-center gap-0.5"><RoleBadge role={p.role} />{can('matters.write') && p.role !== 'client' && <IconButton aria-label={`Remove ${humanise(p.role)} role for ${p.contact.name}`} size="sm" onClick={() => setRm(p)}><Trash2 className="h-3 w-3" /></IconButton>}</span>))}</div>
          </li>))}
      </ul>
      {m.parties.length === 0 && <p className="text-sm text-stone-600">No parties recorded.</p>}
      <AddParty open={add} onClose={() => setAdd(false)} matterId={m.id} />
      <ConfirmDialog open={!!rm} onClose={() => setRm(null)} title="Remove this role?" description={rm ? `${rm.contact.name} will no longer be recorded as ${humanise(rm.role)} on this matter.` : undefined} confirmLabel="Remove" tone="danger" onConfirm={() => { del.mutate(rm!.id); setRm(null) }} />
    </Card>
  )
}

function AddParty({ open, onClose, matterId }: { open: boolean; onClose: () => void; matterId: string }) {
  const [c, setC] = useState<{ id: string; display_name: string } | null>(null); const [role, setRole] = useState<PartyRole>('counterparty'); const [notes, setNotes] = useState(''); const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post(`/matters/${matterId}/parties`, { contact_id: c!.id, role, notes: notes || null }), { invalidate: [['matter', matterId]] as never, errorToast: false, successMessage: 'Party added', onSuccess: () => { setC(null); setNotes(''); onClose() }, onError: (e) => setErr(errMsg(e)) })
  return (
    <Dialog open={open} onClose={onClose} title="Add party" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!c} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Add party</Button></>}>
      <div className="space-y-3">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Contact" required>{(p) => <ContactPicker id={p.id} value={c} onChange={(x) => setC(x ? { id: x.id, display_name: x.display_name } : null)} />}</Field>
        <Field label="Role on this matter"><Select value={role} onChange={(e) => setRole(e.target.value as PartyRole)}>{PARTY_ROLES.map((r) => <option key={r} value={r}>{humanise(r)}</option>)}</Select></Field>
        <Field label="Notes"><Input value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
      </div>
    </Dialog>
  )
}
