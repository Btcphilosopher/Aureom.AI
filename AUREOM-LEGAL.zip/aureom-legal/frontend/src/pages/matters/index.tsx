import { Route, Routes } from 'react-router-dom'
import { NotFoundState } from '@/components/ui/States'
import MatterWorkspace from './MatterWorkspace'
import MattersList from './MattersList'
import TemplatesAdmin from './TemplatesAdmin'

/** /matters/* — list (+ ?new=1 wizard), templates admin, matter workspace. */
export default function MattersSection() {
  return (
    <Routes>
      <Route index element={<MattersList />} />
      <Route path="templates" element={<TemplatesAdmin />} />
      <Route path=":id" element={<MatterWorkspace />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
