import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { Badge, Button, Card, DateTime, Dialog, EmptyState, Field, Input, QueryBoundary, Select, StatusBadge, Textarea } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { MatterDetail } from '@/types/matters'
import { errMsg, useStaff } from '../clients/common'

interface TaskRow { id: string; title: string; status: string; priority: string; due_at: string | null; assignee_name: string | null; is_overdue: boolean; version: number; blocked_by: { id: string; title: string }[] }
interface DeadlineRow { id: string; title: string; due_date: string; status: string; origin: string; authoritative: boolean; label: string; source_passage: string | null }

export default function TasksTab({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const [create, setCreate] = useState(false)
  const ok = can('tasks.read')
  const tasks = useApiQuery<Page<TaskRow>>(['tasks', 'matter', m.id], `/tasks${qs({ matter_id: m.id, limit: 50 })}`, { enabled: ok })
  const dls = useApiQuery<Page<DeadlineRow>>(['deadlines', 'matter', m.id], `/diary/deadlines${qs({ matter_id: m.id, limit: 50 })}`, { enabled: ok })
  const done = useApiMutation((t: TaskRow) => api.post(`/tasks/${t.id}/complete`), { invalidate: [['tasks'], ['matter', m.id, 'summary']] as never, successMessage: 'Task completed' })
  if (!ok) return <EmptyState title="Tasks are not available to your role" description="Your role does not include tasks.read." />
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card title="Tasks" actions={can('tasks.write') && m.status !== 'closed' ? <Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setCreate(true)}>New task</Button> : undefined}>
        <QueryBoundary query={tasks} what="tasks" empty={<p className="text-sm text-stone-600">No tasks on this matter.</p>}>
          {(d) => <ul className="divide-y divide-stone-200">{d.items.map((t) => (
            <li key={t.id} className="flex items-start justify-between gap-3 py-2.5">
              <div className="min-w-0"><Link to={`/tasks/${t.id}`} className={`text-sm font-medium underline-offset-2 hover:underline ${t.status === 'done' ? 'text-stone-500 line-through' : 'text-navy-900'}`}>{t.title}</Link>
                <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-stone-600">{t.assignee_name ?? 'Unassigned'} · due <DateTime value={t.due_at} mode="date" />{t.is_overdue && <Badge tone="danger">Overdue</Badge>}{t.priority !== 'normal' && <StatusBadge status={t.priority} />}{t.blocked_by.length > 0 && <Badge tone="warning">Blocked by {t.blocked_by.length}</Badge>}</p></div>
              {t.status !== 'done' && t.status !== 'cancelled' && can('tasks.write') && <Button size="sm" variant="ghost" disabled={t.blocked_by.length > 0} title={t.blocked_by.length ? 'Complete the blocking task first' : undefined} onClick={() => done.mutate(t)}>Complete</Button>}
              {(t.status === 'done' || t.status === 'cancelled') && <StatusBadge status={t.status} />}
            </li>))}</ul>}
        </QueryBoundary>
        <p className="mt-3 text-xs"><Link className="text-navy-700 underline" to={`/tasks?matter_id=${m.id}`}>Open in Tasks & Diary</Link></p>
      </Card>
      <Card title="Deadlines" description="Only confirmed deadlines are authoritative. Suggestions need human confirmation.">
        <QueryBoundary query={dls} what="deadlines" empty={<p className="text-sm text-stone-600">No deadlines recorded.</p>}>
          {(d) => <ul className="divide-y divide-stone-200">{d.items.map((x) => (
            <li key={x.id} className="py-2.5">
              <div className="flex items-start justify-between gap-2"><Link to={`/tasks/deadlines/${x.id}`} className="text-sm font-medium text-navy-900 underline-offset-2 hover:underline">{x.title}</Link><span className="shrink-0 text-sm tabular-nums"><DateTime value={x.due_date} mode="date" /></span></div>
              <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-stone-600">{x.authoritative ? <Badge tone="success">Confirmed</Badge> : <StatusBadge status={x.status} />}<Badge tone="neutral">{humanise(x.origin)}</Badge>{!x.authoritative && x.status === 'suggested' && <span className="font-medium text-warn-700">Unconfirmed suggestion</span>}</p>
              {x.source_passage && <blockquote className="mt-1.5 border-l-2 border-brass-300 pl-2 text-xs italic text-stone-700">“{x.source_passage}”</blockquote>}
            </li>))}</ul>}
        </QueryBoundary>
      </Card>
      <NewTask open={create} onClose={() => setCreate(false)} matterId={m.id} />
    </div>
  )
}

function NewTask({ open, onClose, matterId }: { open: boolean; onClose: () => void; matterId: string }) {
  const { staff } = useStaff()
  const [f, setF] = useState({ title: '', description: '', assignee_id: '', due: '', priority: 'normal' }); const [err, setErr] = useState<string | null>(null)
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))
  const m = useApiMutation(() => api.post('/tasks', { title: f.title.trim(), matter_id: matterId, description: f.description || null, assignee_id: f.assignee_id || null, due_at: f.due ? new Date(`${f.due}T17:00:00`).toISOString() : null, priority: f.priority }),
    { invalidate: [['tasks'], ['matter', matterId, 'summary']] as never, errorToast: false, successMessage: 'Task created', onSuccess: () => { setF({ title: '', description: '', assignee_id: '', due: '', priority: 'normal' }); onClose() }, onError: (e) => setErr(errMsg(e)) })
  return (
    <Dialog open={open} onClose={onClose} title="New task" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.title.trim()} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Create task</Button></>}>
      <div className="space-y-3">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Title" required><Input value={f.title} onChange={set('title')} /></Field>
        <Field label="Description"><Textarea rows={2} value={f.description} onChange={set('description')} /></Field>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Assignee"><Select value={f.assignee_id} onChange={set('assignee_id')}><option value="">Unassigned</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
          <Field label="Due date"><Input type="date" value={f.due} onChange={set('due')} /></Field>
          <Field label="Priority"><Select value={f.priority} onChange={set('priority')}><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></Select></Field>
        </div>
      </div>
    </Dialog>
  )
}
