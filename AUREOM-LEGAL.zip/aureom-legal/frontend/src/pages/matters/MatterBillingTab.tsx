import { MatterBillingPanel } from '@/pages/billing/MatterBillingPanel'
import type { MatterDetail } from '@/types/matters'

/** Time, expenses, WIP vs budget, invoices and client-ledger position for this matter (finance module). */
export default function MatterBillingTab({ matter }: { matter: MatterDetail }) {
  return <MatterBillingPanel matterId={matter.id} matterReference={matter.reference} />
}
