import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Check, XCircle } from 'lucide-react'
import { Badge, Button, Dialog, Field, Select, Textarea } from '@/components/ui'
import { ApiError, api, useApiMutation } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { AvailableTransition, Blocker, MatterDetail, TransitionResult } from '@/types/matters'
import { blockerText, useRetentionPolicies } from '../clients/common'

export const TRANSITION_LABEL: Record<string, string> = { open: 'Open matter', paused: 'Pause matter', closed: 'Close matter' }
export function transitionLabel(from: string, to: string) { return from === 'closed' && to === 'open' ? 'Reopen matter' : TRANSITION_LABEL[to] ?? humanise(to) }

/** Validated state transition. Shows blockers from /transitions/available, handles 202 pending-approval and 409 conflicts. */
export function TransitionDialog({ matter, transition, onClose }: { matter: MatterDetail; transition: AvailableTransition | null; onClose: () => void }) {
  const retention = useRetentionPolicies()
  const [reason, setReason] = useState('')
  const [policy, setPolicy] = useState(matter.retention_policy_key ?? '')
  const [err, setErr] = useState<ApiError | null>(null)
  const [done, setDone] = useState<TransitionResult | null>(null)
  const closing = transition?.to_status === 'closed'
  const m = useApiMutation(() => api.post<TransitionResult>(`/matters/${matter.id}/transitions`, { to_status: transition!.to_status, reason: reason.trim() || null, expected_version: matter.version, retention_policy_key: closing ? policy || null : null }),
    { invalidate: [['matter', matter.id], ['matters']], errorToast: false, onSuccess: (r) => setDone(r), onError: (e) => setErr(e) })
  if (!transition) return null
  const close = () => { setDone(null); setErr(null); setReason(''); onClose() }
  const label = transitionLabel(matter.status, transition.to_status)
  const serverBlockers = (err?.details?.blockers as Blocker[] | undefined) ?? []
  const blockers = [...transition.blockers, ...serverBlockers.filter((b) => !transition.blockers.some((t) => blockerText(t) === blockerText(b)))]
  const needReason = transition.reason_required
  const ready = transition.allowed && transition.can_request && (!needReason || reason.trim().length >= 3) && (!closing || !!policy)
  return (
    <Dialog open onClose={close} title={label} description={`${matter.reference} · ${matter.title}`}
      footer={done ? <Button onClick={close}>Close</Button> : <><Button variant="secondary" onClick={close}>Cancel</Button><Button disabled={!ready} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>{transition.needs_approval_from_partner ? 'Request approval' : label}</Button></>}>
      {done ? (
        <div className="space-y-3 text-sm" role="status">
          {done.executed
            ? <p className="flex items-center gap-2 text-ok-700"><Check className="h-4 w-4" aria-hidden />Done. The matter is now <strong>{humanise(done.matter.status)}</strong>. This change is recorded with your name and reason.</p>
            : <><p className="flex items-center gap-2 text-warn-700"><XCircle className="hidden" aria-hidden /><Badge tone="warning">Pending approval</Badge> A partner must approve this change before the matter moves to <strong>{humanise(transition.to_status)}</strong>.</p>
              <p className="text-xs text-stone-600">Approval reference {done.approval_id.slice(0, 8)}… · <Link className="text-navy-700 underline" to="/approvals">Open approvals inbox</Link></p></>}
        </div>
      ) : (
        <div className="space-y-4">
          {err && !serverBlockers.length && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}{err.code === 'version_conflict' && ' Reload the matter and try again.'}</p>}
          {blockers.length > 0 && (
            <div role="alert" className="rounded-md border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700"><p className="font-semibold">This cannot proceed yet:</p><ul className="mt-1 list-disc pl-5">{blockers.map((b, i) => <li key={i}>{blockerText(b)}</li>)}</ul></div>)}
          {!transition.can_request && <p className="text-sm text-stone-700">Your role cannot request this change (needs <code className="rounded bg-stone-100 px-1">matters.transition</code>).</p>}
          {transition.needs_approval_from_partner && transition.allowed && <p className="rounded-md bg-ivory-100 px-3 py-2 text-xs text-stone-700">You will submit this for partner approval. The approval is bound to the matter’s current version; editing the matter first invalidates it.</p>}
          {closing && <Field label="Retention policy" required hint="Retention runs from the closure date; a legal hold overrides it.">
            <Select value={policy} onChange={(e) => setPolicy(e.target.value)}><option value="">Select…</option>{retention.map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}</Select></Field>}
          <Field label={needReason ? 'Reason' : 'Reason (recommended)'} required={needReason} hint="Recorded in the matter history and audit trail."><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
        </div>)}
    </Dialog>
  )
}

/** Approver decision on a pending transition. */
export function DecideTransitionDialog({ matter, approve, onClose }: { matter: MatterDetail; approve: boolean | null; onClose: () => void }) {
  const [note, setNote] = useState(''); const [err, setErr] = useState<ApiError | null>(null)
  const p = matter.pending_transition
  const m = useApiMutation(() => api.post<TransitionResult>(`/matters/${matter.id}/transitions/${p!.approval_id}/decide`, { approve, note: note.trim() || null }),
    { invalidate: [['matter', matter.id], ['matters'], ['approvals']], errorToast: false, successMessage: (r) => (r.executed ? 'Approved — matter updated' : 'Decision recorded'), onSuccess: onClose, onError: setErr })
  if (approve === null || !p) return null
  const blockers = (err?.details?.blockers as Blocker[] | undefined) ?? []
  return (
    <Dialog open onClose={onClose} title={approve ? 'Approve transition' : 'Reject transition'} description={`Move to ${humanise(p.to_status)}${p.reason ? ` — “${p.reason}”` : ''}`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant={approve ? 'primary' : 'danger'} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>{approve ? 'Approve and apply' : 'Reject'}</Button></>}>
      <div className="space-y-3">
        {err && <div role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}{blockers.length > 0 && <ul className="mt-1 list-disc pl-5">{blockers.map((b, i) => <li key={i}>{blockerText(b)}</li>)}</ul>}{err.code === 'approval_stale' && ' The matter changed after the request; ask for a fresh approval.'}</div>}
        <p className="text-xs text-stone-600">Preconditions are re-checked when the change is applied.</p>
        <Field label="Note"><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
      </div>
    </Dialog>
  )
}
