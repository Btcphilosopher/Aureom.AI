import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Clock, Lock } from 'lucide-react'
import { Button, PageHeader, QueryBoundary, Select, StatusBadge, StatusStepper, TabPanel, Tabs } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle, useQueryParam } from '@/hooks'
import type { AvailableTransition, MatterDetail, TransitionsAvailable } from '@/types/matters'
import { AccessBadges, blockerText } from '../clients/common'
import AccessTab from './AccessTab'
import ActivityTab from './ActivityTab'
import ChronologyTab from './ChronologyTab'
import ClosureTab from './ClosureTab'
import CorrespondenceTab from './CorrespondenceTab'
import DocumentsTab from './DocumentsTab'
import MatterAiTab from './MatterAiTab'
import MatterBillingTab from './MatterBillingTab'
import OverviewTab from './OverviewTab'
import PartiesTab from './PartiesTab'
import TasksTab from './TasksTab'
import { DecideTransitionDialog, TransitionDialog, transitionLabel } from './TransitionDialog'

export default function MatterWorkspace() {
  const { id } = useParams()
  const q = useApiQuery<MatterDetail>(['matter', id], `/matters/${id}`)
  return <QueryBoundary query={q} what="matter">{(m) => <Workspace m={m} />}</QueryBoundary>
}

function Workspace({ m }: { m: MatterDetail }) {
  usePageTitle(`${m.reference} · ${m.title}`)
  useBreadcrumbs([{ label: 'Matters', to: '/matters' }, { label: m.reference }])
  const { can, me } = useAuth()
  const [tab, setTab] = useQueryParam('tab')
  const t = tab ?? 'overview'
  const [trans, setTrans] = useState<AvailableTransition | null>(null)
  const [decide, setDecide] = useState<boolean | null>(null)
  const av = useApiQuery<TransitionsAvailable>(['matter', m.id, 'transitions', m.version, m.status], `/matters/${m.id}/transitions/available`)
  const transitions = av.data?.transitions ?? []
  const openT = transitions.find((x) => x.to_status === 'open')
  const stages = m.template?.stages ?? []
  const stage = useApiMutation((stage: string) => api.post(`/matters/${m.id}/stage`, { stage, expected_version: m.version }), { invalidate: [['matter', m.id], ['matters']] as never, successMessage: 'Stage updated' })
  const p = m.pending_transition
  const tabs = [
    { id: 'overview', label: 'Overview' }, { id: 'parties', label: 'Parties', badge: new Set(m.parties.map((x) => x.contact.id)).size }, { id: 'documents', label: 'Documents' }, { id: 'correspondence', label: 'Correspondence' },
    { id: 'tasks', label: 'Tasks & deadlines' }, { id: 'billing', label: 'Time & billing' }, { id: 'ai', label: 'AI', disabled: !can('ai.use') && !can('ai.review') }, { id: 'chronology', label: 'Chronology' },
    { id: 'activity', label: 'Activity' }, { id: 'access', label: 'Access' }, { id: 'closure', label: 'Closure' },
  ]
  return (
    <>
      <PageHeader eyebrow={<span className="tabular-nums">{m.reference} · {humanise(m.practice_area)}</span>} title={m.title}
        meta={<span className="flex flex-wrap items-center gap-2 text-sm"><StatusBadge status={m.status} /><AccessBadges access={m.access_level} wall={m.ethical_wall} hold={m.legal_hold} />
          <span>Client: <Link className="font-medium text-navy-700 underline" to={`/clients/${m.client.id}`}>{m.client.name}</Link></span>
          <span className="text-stone-600">Partner {m.responsible_partner.name} · Fee earner {m.fee_earner.name} · {m.office.name}</span></span>}
        actions={can('matters.transition') && transitions.filter((x) => !(x.to_status === 'closed')).map((x) => <Button key={x.to_status} variant={x.to_status === 'open' ? 'primary' : 'secondary'} onClick={() => setTrans(x)}>{transitionLabel(m.status, x.to_status)}</Button>)} />

      {stages.length > 0 && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-stone-200 bg-white px-5 py-3 shadow-panel">
          <StatusStepper steps={stages.map((s) => ({ key: s.key, label: s.name }))} current={m.stage ?? ''} />
          {can('matters.write') && (m.status === 'open' || m.status === 'paused') && (
            <label className="flex items-center gap-2 text-xs text-stone-700">Move stage
              <Select className="h-8 w-48" aria-label="Move matter stage" value={m.stage ?? ''} onChange={(e) => stage.mutate(e.target.value)} disabled={stage.isPending}>{stages.map((s) => <option key={s.key} value={s.key}>{s.name}</option>)}</Select></label>)}
        </div>)}

      {p && (
        <div role="status" className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-md border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700">
          <p className="flex items-center gap-2"><Clock className="h-4 w-4" aria-hidden /><span><strong>Pending approval:</strong> move to <strong>{humanise(p.to_status)}</strong>{p.reason ? ` — “${p.reason}”` : ''}. <Link className="underline" to="/approvals">Approvals inbox</Link></span></p>
          {can('matters.approve') ? <span className="flex gap-2"><Button size="sm" variant="secondary" onClick={() => setDecide(false)}>Reject</Button><Button size="sm" disabled={p.requested_by === me?.user.id} title={p.requested_by === me?.user.id ? 'Another approver should decide your own request' : undefined} onClick={() => setDecide(true)}>Approve…</Button></span> : <span className="text-xs">Waiting for a partner to decide.</span>}
        </div>)}

      {m.status === 'prospective' && openT && openT.blockers.length > 0 && (
        <div role="note" className="mb-4 rounded-md border border-stone-300 bg-ivory-100 px-4 py-3 text-sm">
          <p className="font-semibold text-navy-900"><Lock className="mr-1 inline h-4 w-4 text-brass-600" aria-hidden />This matter is prospective and cannot be opened yet:</p>
          <ul className="mt-1 list-disc pl-6 text-stone-700">{openT.blockers.map((b, i) => <li key={i}>{blockerText(b)}</li>)}</ul>
          <p className="mt-2 text-xs text-stone-600">Conflict outcomes and onboarding are decided by authorised people — <Link className="underline" to={`/clients/${m.client.id}?tab=conflicts`}>conflicts</Link> · <Link className="underline" to={`/clients/${m.client.id}?tab=onboarding`}>onboarding</Link>.</p>
        </div>)}

      <Tabs value={t} onChange={setTab} tabs={tabs} label="Matter sections" />
      <TabPanel id="overview" value={t}><OverviewTab m={m} /></TabPanel>
      <TabPanel id="parties" value={t}><PartiesTab m={m} /></TabPanel>
      <TabPanel id="documents" value={t}><DocumentsTab m={m} /></TabPanel>
      <TabPanel id="correspondence" value={t}><CorrespondenceTab m={m} /></TabPanel>
      <TabPanel id="tasks" value={t}><TasksTab m={m} /></TabPanel>
      <TabPanel id="billing" value={t}><MatterBillingTab matter={m} /></TabPanel>
      <TabPanel id="ai" value={t}><MatterAiTab matter={m} /></TabPanel>
      <TabPanel id="chronology" value={t}><ChronologyTab m={m} /></TabPanel>
      <TabPanel id="activity" value={t}><ActivityTab m={m} /></TabPanel>
      <TabPanel id="access" value={t}><AccessTab m={m} /></TabPanel>
      <TabPanel id="closure" value={t}><ClosureTab m={m} transitions={transitions} onTransition={setTrans} /></TabPanel>
      {trans && <TransitionDialog matter={m} transition={trans} onClose={() => setTrans(null)} />}
      <DecideTransitionDialog matter={m} approve={decide} onClose={() => setDecide(null)} />
    </>
  )
}
