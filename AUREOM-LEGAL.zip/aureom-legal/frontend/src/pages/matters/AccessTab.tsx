import { useState } from 'react'
import { Lock, Plus, ShieldCheck, Trash2 } from 'lucide-react'
import { Badge, Button, Card, Checkbox, ConfirmDialog, Dialog, Field, IconButton, Input, Select, Textarea } from '@/components/ui'
import { ApiError, api, useApiMutation } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import type { MatterDetail, MatterMember } from '@/types/matters'
import { AccessBadges, errMsg, useStaff, useTeams } from '../clients/common'

const EFFECTS = [
  ['Search', 'Hidden from global search, document search and counts for everyone not on the access list.'],
  ['Document previews & downloads', 'Blocked for non-members; downloads also need the matter’s exports setting.'],
  ['Exports', 'Bulk exports are refused when exports are switched off for the matter.'],
  ['AI retrieval', 'AI agents retrieve only what the requesting user may see, and nothing at all if AI retrieval is switched off for the matter.'],
] as const

export default function AccessTab({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const admin = can('matters.access_admin')
  const [settings, setSettings] = useState(false); const [add, setAdd] = useState(false); const [rm, setRm] = useState<MatterMember | null>(null)
  const del = useApiMutation(({ mm, reason }: { mm: MatterMember; reason: string }) => api.delete(`/matters/${m.id}/members/${mm.id}?reason=${encodeURIComponent(reason)}`), { invalidate: [['matter', m.id]] as never, successMessage: 'Access entry removed' })
  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-3">
        <Card title="Access settings" className="lg:col-span-2" actions={admin ? <Button size="sm" variant="secondary" onClick={() => setSettings(true)}>Change settings…</Button> : undefined}>
          <dl className="grid gap-4 text-sm sm:grid-cols-4">
            <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Access level</dt><dd className="mt-1"><AccessBadges access={m.access_level} wall={m.ethical_wall} showStandard /></dd></div>
            <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Ethical wall</dt><dd className="mt-1">{m.ethical_wall ? 'In force' : 'None'}</dd></div>
            <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">Exports</dt><dd className="mt-1">{m.exports_allowed ? 'Allowed' : <Badge tone="danger">Blocked</Badge>}</dd></div>
            <div><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">AI retrieval</dt><dd className="mt-1">{m.ai_retrieval_allowed ? 'Allowed' : <Badge tone="danger">Blocked</Badge>}</dd></div>
          </dl>
          {!admin && <p className="mt-4 text-xs text-stone-600">Changing access needs <code className="rounded bg-stone-100 px-1">matters.access_admin</code> (partner or compliance). Every change is audited with a reason.</p>}
        </Card>
        <Card title="What restricted means" description="Applies to restricted matters and ethical walls.">
          <ul className="space-y-2 text-xs text-stone-700">{EFFECTS.map(([k, v]) => <li key={k}><ShieldCheck className="mr-1 inline h-3.5 w-3.5 text-brass-600" aria-hidden /><strong>{k}:</strong> {v}</li>)}</ul>
        </Card>
      </div>
      <Card title="Access list & exclusions" description="Allow entries grant access to a restricted matter. Deny entries (a person or a whole team) always win — even over the responsible partner."
        actions={admin ? <Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setAdd(true)}>Add entry</Button> : undefined}>
        <div className="mb-3 flex flex-wrap gap-2 text-xs text-stone-700"><span>Always has access (unless denied): responsible partner <strong>{m.responsible_partner.name}</strong> and fee earner <strong>{m.fee_earner.name}</strong>.</span></div>
        {m.members.length === 0 ? <p className="text-sm text-stone-600">No explicit entries.</p> : (
          <ul className="divide-y divide-stone-200">{m.members.map((x) => (
            <li key={x.id} className="flex flex-wrap items-start justify-between gap-2 py-3">
              <div><p className="flex items-center gap-2 text-sm font-medium">{x.access === 'deny' ? <Lock className="h-3.5 w-3.5 text-bad-700" aria-hidden /> : <ShieldCheck className="h-3.5 w-3.5 text-ok-700" aria-hidden />}{x.user?.name ?? `Team: ${x.team?.name}`}<Badge tone={x.access === 'allow' ? 'success' : 'danger'}>{x.access === 'allow' ? 'Allowed' : 'Excluded'}</Badge>{x.member_role && <Badge tone="neutral">{x.member_role}</Badge>}</p>{x.reason && <p className="mt-0.5 text-xs text-stone-600">Reason: {x.reason}</p>}</div>
              {admin && <IconButton aria-label={`Remove access entry for ${x.user?.name ?? x.team?.name}`} size="sm" onClick={() => setRm(x)}><Trash2 className="h-3.5 w-3.5" /></IconButton>}
            </li>))}</ul>)}
      </Card>
      {settings && <SettingsDialog m={m} onClose={() => setSettings(false)} />}
      {add && <AddMember m={m} onClose={() => setAdd(false)} />}
      <ConfirmDialog open={!!rm} onClose={() => setRm(null)} title="Remove this access entry?" requireReason="Reason for removal (min 5 characters)" confirmLabel="Remove" tone="danger" onConfirm={(reason) => { if ((reason ?? '').length >= 5) { del.mutate({ mm: rm!, reason: reason! }); setRm(null) } }} />
    </div>
  )
}

function SettingsDialog({ m, onClose }: { m: MatterDetail; onClose: () => void }) {
  const [f, setF] = useState({ access_level: m.access_level, ethical_wall: m.ethical_wall, exports_allowed: m.exports_allowed, ai_retrieval_allowed: m.ai_retrieval_allowed, reason: '' }); const [err, setErr] = useState<ApiError | null>(null)
  const mu = useApiMutation(() => api.put(`/matters/${m.id}/access`, { ...f, expected_version: m.version }), { invalidate: [['matter', m.id], ['matters']] as never, errorToast: false, successMessage: 'Access settings updated', onSuccess: onClose, onError: setErr })
  return (
    <Dialog open onClose={onClose} title="Access settings" description="Recorded in the audit trail with your reason."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={f.reason.trim().length < 5} loading={mu.isPending} onClick={() => { setErr(null); mu.mutate() }}>Save settings</Button></>}>
      <div className="space-y-3">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}{err.isConflict && ' Close and reopen to load the latest version.'}</p>}
        <Field label="Access level"><Select value={f.access_level} onChange={(e) => setF((s) => ({ ...s, access_level: e.target.value as 'standard' | 'restricted' }))}><option value="standard">Standard</option><option value="restricted">Restricted (access list only)</option></Select></Field>
        <Checkbox label="Ethical wall in force" hint="Marks the matter as walled; use deny entries to exclude people or teams." checked={f.ethical_wall} onChange={(e) => setF((s) => ({ ...s, ethical_wall: e.target.checked }))} />
        <Checkbox label="Allow exports" checked={f.exports_allowed} onChange={(e) => setF((s) => ({ ...s, exports_allowed: e.target.checked }))} />
        <Checkbox label="Allow AI retrieval" hint="Switch off where the client or policy prohibits AI use on this matter." checked={f.ai_retrieval_allowed} onChange={(e) => setF((s) => ({ ...s, ai_retrieval_allowed: e.target.checked }))} />
        <Field label="Reason" required><Textarea rows={2} value={f.reason} onChange={(e) => setF((s) => ({ ...s, reason: e.target.value }))} /></Field>
      </div>
    </Dialog>
  )
}

function AddMember({ m, onClose }: { m: MatterDetail; onClose: () => void }) {
  const { staff } = useStaff(); const { teams, available } = useTeams()
  const [f, setF] = useState({ who: '', access: 'allow', reason: '', role: '' }); const [err, setErr] = useState<string | null>(null)
  const mu = useApiMutation(() => { const [k, id] = f.who.split(':'); return api.post(`/matters/${m.id}/members`, { user_id: k === 'u' ? id : null, team_id: k === 't' ? id : null, access: f.access, member_role: f.role || null, reason: f.reason.trim() }) },
    { invalidate: [['matter', m.id]] as never, errorToast: false, successMessage: 'Access entry added', onSuccess: onClose, onError: (e) => setErr(errMsg(e)) })
  return (
    <Dialog open onClose={onClose} title="Add access entry" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.who || f.reason.trim().length < 5} loading={mu.isPending} onClick={() => { setErr(null); mu.mutate() }}>Add entry</Button></>}>
      <div className="space-y-3">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Effect"><Select value={f.access} onChange={(e) => setF((s) => ({ ...s, access: e.target.value, who: '' }))}><option value="allow">Allow access</option><option value="deny">Exclude (ethical wall)</option></Select></Field>
        <Field label="Person or team" hint={!available && f.access === 'deny' ? 'Team exclusions need administrator access to list teams.' : undefined}><Select value={f.who} onChange={(e) => setF((s) => ({ ...s, who: e.target.value }))}><option value="">Select…</option>{staff.map((s) => <option key={s.id} value={`u:${s.id}`}>{s.name}</option>)}{f.access === 'deny' && teams.map((t) => <option key={t.id} value={`t:${t.id}`}>Team: {t.name}</option>)}</Select></Field>
        {f.access === 'allow' && <Field label="Role on the matter"><Input value={f.role} onChange={(e) => setF((s) => ({ ...s, role: e.target.value }))} placeholder="e.g. team, finance, supervisor" /></Field>}
        <Field label="Reason" required hint="At least 5 characters."><Textarea rows={2} value={f.reason} onChange={(e) => setF((s) => ({ ...s, reason: e.target.value }))} /></Field>
      </div>
    </Dialog>
  )
}
