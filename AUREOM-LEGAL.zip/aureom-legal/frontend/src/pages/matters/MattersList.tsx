import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { Button, DataTable, Field, PageHeader, SearchInput, Select, StatusBadge, type Column } from '@/components/ui'
import { DateTime } from '@/components/ui'
import { ContactPicker } from '../clients/ContactPicker'
import { AccessBadges, MATTER_STATUSES, PRACTICE_AREAS, useStaff } from '../clients/common'
import { qs, useApiQuery } from '@/lib/api'
import { useAuth, useOffice } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { useDebounce, useNewParam, usePageTitle, useQueryParams } from '@/hooks'
import type { Page } from '@/types/api'
import type { MatterListItem } from '@/types/matters'
import MatterWizard from './MatterWizard'

const KEYS = ['q', 'status', 'practice_area', 'office_id', 'partner_id', 'fee_earner_id', 'client_id', 'mine', 'missing', 'offset'] as const

export default function MattersList() {
  usePageTitle('Matters')
  useBreadcrumbs([{ label: 'Matters' }])
  const nav = useNavigate()
  const { can } = useAuth()
  const { offices, officeId } = useOffice()
  const { isNew, clear } = useNewParam()
  const { staff } = useStaff()
  const [p, setP] = useQueryParams(KEYS)
  const [qText, setQText] = useState(p.q ?? '')
  const dq = useDebounce(qText, 300)
  const [clientPick, setClientPick] = useState<{ id: string; display_name: string } | null>(null)
  const limit = 25, offset = Number(p.offset ?? 0)
  const params = { q: dq, status: p.status ?? (p.missing ? 'open' : undefined), practice_area: p.practice_area, office_id: p.office_id ?? officeId ?? undefined, partner_id: p.partner_id, fee_earner_id: p.fee_earner_id, client_id: p.client_id, mine: p.mine === '1' ? true : undefined, limit, offset }
  const query = useApiQuery<Page<MatterListItem>>(['matters', params], `/matters${qs(params)}`)

  const cols: Column<MatterListItem>[] = [
    { key: 'ref', header: 'Reference', cell: (m) => <span className="tabular-nums font-medium text-navy-900">{m.reference}</span> },
    { key: 'title', header: 'Matter', cell: (m) => <div className="min-w-0"><p className="truncate font-medium text-navy-900">{m.title}</p><p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-stone-600">{m.client.name} · {humanise(m.practice_area)}<AccessBadges access={m.access_level} wall={m.ethical_wall} hold={m.legal_hold} /></p></div> },
    { key: 'status', header: 'Status', cell: (m) => <StatusBadge status={m.status} /> },
    { key: 'stage', header: 'Stage', hideOnNarrow: true, cell: (m) => humanise(m.stage) },
    { key: 'people', header: 'Partner / fee earner', hideOnNarrow: true, cell: (m) => <span className="text-xs">{m.responsible_partner.name}<br /><span className="text-stone-600">{m.fee_earner.name}</span></span> },
    { key: 'office', header: 'Office', hideOnNarrow: true, cell: (m) => m.office.name },
    { key: 'target', header: 'Target', cell: (m) => <DateTime value={m.target_date} mode="date" /> },
  ]
  return (
    <>
      <PageHeader title="Matters" description="Everything connects to the matter: clients, parties, documents, correspondence, tasks, time, money and AI activity. Restricted matters you cannot access never appear."
        actions={<><Button variant="secondary" onClick={() => nav('/matters/templates')}>Matter templates</Button>{can('matters.create') && <Button icon={<Plus className="h-4 w-4" />} onClick={() => nav('/matters?new=1')}>New matter</Button>}</>} />
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <SearchInput className="w-64" value={qText} onValueChange={(v) => { setQText(v); setP({ q: v, offset: null }) }} placeholder="Reference, title or client…" />
        <Field label="Status"><Select value={p.status ?? ''} onChange={(e) => setP({ status: e.target.value, offset: null })}><option value="">All</option>{MATTER_STATUSES.map((s) => <option key={s} value={s}>{humanise(s)}</option>)}</Select></Field>
        <Field label="Practice area"><Select value={p.practice_area ?? ''} onChange={(e) => setP({ practice_area: e.target.value, offset: null })}><option value="">All</option>{PRACTICE_AREAS.map((s) => <option key={s} value={s}>{humanise(s)}</option>)}</Select></Field>
        <Field label="Office"><Select value={p.office_id ?? ''} onChange={(e) => setP({ office_id: e.target.value, offset: null })}><option value="">{officeId ? 'Selected office' : 'All offices'}</option>{offices.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select></Field>
        <Field label="Partner"><Select value={p.partner_id ?? ''} onChange={(e) => setP({ partner_id: e.target.value, offset: null })}><option value="">Any</option>{staff.filter((s) => s.role === 'partner').map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
        <Field label="Fee earner"><Select value={p.fee_earner_id ?? ''} onChange={(e) => setP({ fee_earner_id: e.target.value, offset: null })}><option value="">Any</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
        <Field label="Client">{(f) => <div className="w-56"><ContactPicker id={f.id} value={p.client_id ? clientPick ?? { id: p.client_id, display_name: 'Selected client' } : null} onChange={(c) => { setClientPick(c ? { id: c.id, display_name: c.display_name } : null); setP({ client_id: c?.id ?? null, offset: null }) }} /></div>}</Field>
        <label className="mb-1 flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-navy-800" checked={p.mine === '1'} onChange={(e) => setP({ mine: e.target.checked ? '1' : null, offset: null })} />My matters</label>
      </div>
      {p.missing && <p role="note" className="mb-3 rounded-md bg-ivory-100 px-4 py-2 text-sm text-stone-700">Showing open matters. The “missing {humanise(p.missing)}” filter is not available in the matter list; check each matter’s Documents tab.</p>}
      <DataTable caption="Matters" columns={cols} rows={query.data?.items} rowKey={(m) => m.id} loading={query.isPending} error={query.error} onRetry={() => void query.refetch()} onRowClick={(m) => nav(`/matters/${m.id}`)}
        emptyTitle="No matters match these filters" emptyDescription="Matters you are not permitted to see are never listed or counted."
        pagination={query.data ? { total: query.data.total, limit, offset, onChange: (o) => setP({ offset: String(o) }) } : undefined} />
      {isNew && <MatterWizard onClose={clear} />}
    </>
  )
}
