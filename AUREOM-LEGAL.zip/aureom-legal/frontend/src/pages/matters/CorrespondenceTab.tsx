import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Lock, StickyNote } from 'lucide-react'
import { Button, DataTable, DateTime, EmptyState, Field, StatusBadge, Textarea, QueryBoundary, type Column } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatDateTime } from '@/lib/format'
import type { Page } from '@/types/api'
import type { MatterDetail } from '@/types/matters'

interface Corr { id: string; subject: string; direction: string; status: string; from_addr: string; preview: string; client_visible: boolean; has_attachments: boolean; received_at: string | null; sent_at: string | null; created_at: string }
interface Note { id: string; author_name: string | null; body: string; created_at: string }

export default function CorrespondenceTab({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const nav = useNavigate()
  const ok = can('correspondence.read')
  const q = useApiQuery<Page<Corr>>(['correspondence', 'matter', m.id], `/correspondence${qs({ matter_id: m.id, limit: 25 })}`, { enabled: ok })
  if (!ok) return <EmptyState icon={<Lock className="h-5 w-5" />} title="Correspondence is not available to your role" description="Your role does not include correspondence.read." />
  const cols: Column<Corr>[] = [
    { key: 'subj', header: 'Subject', cell: (c) => <div className="min-w-0"><p className="truncate font-medium text-navy-900">{c.subject}</p><p className="truncate text-xs text-stone-600">{c.preview}</p></div> },
    { key: 'dir', header: 'Direction', cell: (c) => <StatusBadge status={c.direction} tone={c.direction === 'inbound' ? 'info' : 'neutral'} /> },
    { key: 'st', header: 'Status', cell: (c) => <span className="inline-flex gap-1"><StatusBadge status={c.status} />{c.client_visible && <StatusBadge status="client_visible" tone="brass" />}</span> },
    { key: 'from', header: 'From', hideOnNarrow: true, cell: (c) => c.from_addr },
    { key: 'at', header: 'Date', cell: (c) => <DateTime value={c.sent_at ?? c.received_at ?? c.created_at} mode="date" /> },
  ]
  return (
    <div className="space-y-6">
      <DataTable caption={`Correspondence on ${m.reference}`} columns={cols} rows={q.data?.items} rowKey={(c) => c.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(c) => nav(`/correspondence/${c.id}`)}
        emptyTitle="No correspondence filed to this matter" emptyDescription="File emails from the inbox, or draft a reply." />
      <InternalNotes m={m} />
    </div>
  )
}

/** Internal notes are visually distinct and never sent or shown to the client. */
function InternalNotes({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const [body, setBody] = useState('')
  const q = useApiQuery<Note[]>(['matter-notes', m.id], `/correspondence/matter-notes${qs({ matter_id: m.id })}`)
  const add = useApiMutation(() => api.post('/correspondence/matter-notes', { body: body.trim(), matter_id: m.id }), { invalidate: [['matter-notes', m.id]], successMessage: 'Internal note added', onSuccess: () => setBody('') })
  return (
    <section aria-label="Internal notes" className="rounded-lg border-2 border-dashed border-brass-400 bg-brass-50/60">
      <header className="flex items-center gap-2 border-b border-brass-200 px-5 py-3"><StickyNote className="h-4 w-4 text-brass-700" aria-hidden /><h3 className="text-sm font-semibold text-navy-900">Internal notes</h3><span className="ml-auto text-xs font-medium text-brass-700">Internal — never sent, never visible to the client</span></header>
      <div className="space-y-3 p-5">
        <QueryBoundary query={q} what="notes" empty={<p className="text-sm text-stone-600">No internal notes yet.</p>}>
          {(notes) => <ul className="space-y-3">{notes.map((n) => <li key={n.id} className="rounded-md bg-white px-4 py-3 text-sm shadow-panel"><p className="whitespace-pre-wrap">{n.body}</p><p className="mt-1 text-xs text-stone-600">{n.author_name} · {formatDateTime(n.created_at)}</p></li>)}</ul>}
        </QueryBoundary>
        {can('correspondence.write') && (<><Field label="Add an internal note"><Textarea rows={2} value={body} onChange={(e) => setBody(e.target.value)} /></Field><Button size="sm" disabled={!body.trim()} loading={add.isPending} onClick={() => add.mutate()}>Add internal note</Button></>)}
      </div>
    </section>
  )
}
