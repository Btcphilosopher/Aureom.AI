import { Link } from 'react-router-dom'
import { Card, KeyValue, Money, StatCard, StatusBadge, Timeline } from '@/components/ui'
import { DateTime } from '@/components/ui'
import { useApiQuery } from '@/lib/api'
import { sumDecimal, formatDateTime, humanise } from '@/lib/format'
import type { MatterDetail, MatterSummary } from '@/types/matters'
import { AccessBadges } from '../clients/common'

/** exact percentage from decimal strings without floating-point money arithmetic */
function pct(part: string, whole: string): number | null {
  const toCents = (s: string) => { const [i, d = ''] = s.replace('-', '').split('.'); return BigInt(i || '0') * 100n + BigInt((d + '00').slice(0, 2)) }
  const w = toCents(whole); if (w === 0n) return null
  return Number((toCents(part) * 1000n) / w) / 10
}

export default function OverviewTab({ m }: { m: MatterDetail }) {
  const s = useApiQuery<MatterSummary>(['matter', m.id, 'summary'], `/matters/${m.id}/summary`)
  const fin = m.financial
  const wip = fin ? sumDecimal([fin.unbilled_time, fin.unbilled_expenses]) : null
  const used = fin?.budget_amount && wip ? pct(wip, fin.budget_amount) : null
  const d = s.data
  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard label="Documents" value={d?.documents ?? '—'} to={`?tab=documents`} hint={d?.documents == null ? 'Not visible to your role' : undefined} />
        <StatCard label="Open tasks" value={d?.open_tasks ?? '—'} to="?tab=tasks" />
        <StatCard label="Deadlines (30 days)" value={d?.upcoming_deadlines ?? '—'} to="?tab=tasks" tone={d?.suggested_deadlines_unconfirmed ? 'warning' : 'neutral'}
          hint={d?.suggested_deadlines_unconfirmed ? `${d.suggested_deadlines_unconfirmed} unconfirmed suggestion(s)` : 'Confirmed only'} />
        <StatCard label="Unbilled WIP" value={d?.unbilled_wip != null ? <Money value={d.unbilled_wip} currency={m.currency} /> : '—'} to="?tab=billing" hint={d?.unbilled_wip == null ? 'Not visible to your role' : `${d.unbilled_entries ?? 0} entries`} />
        <StatCard label="Client balance" value={d?.client_balance != null ? <Money value={d.client_balance} currency={m.currency} /> : '—'} to="?tab=billing" tone="brass" hint="Client ledger" />
      </div>
      {d?.basis && <p className="text-xs text-stone-600">Basis: {d.basis}</p>}

      <div className="grid gap-5 lg:grid-cols-3">
        <Card title="Matter details" className="lg:col-span-2">
          {m.description && <p className="mb-4 whitespace-pre-wrap text-sm text-stone-800">{m.description}</p>}
          <KeyValue columns={3} items={[
            { label: 'Type', value: m.matter_type }, { label: 'Practice area', value: humanise(m.practice_area) }, { label: 'Jurisdiction', value: humanise(m.jurisdiction) },
            { label: 'Office', value: m.office.name }, { label: 'Template', value: m.template?.name ?? 'None' }, { label: 'Access', value: <AccessBadges access={m.access_level} wall={m.ethical_wall} hold={m.legal_hold} showStandard /> },
            { label: 'Opened', value: <DateTime value={m.opened_at} mode="date" /> }, { label: 'Target', value: <DateTime value={m.target_date} mode="date" /> }, { label: 'Closed', value: <DateTime value={m.closed_at} mode="date" /> },
          ]} />
        </Card>
        <Card title="Fees & budget">
          <KeyValue items={[{ label: 'Fee arrangement', value: humanise(m.fee_arrangement) },
            ...(fin ? [{ label: 'Fixed / capped fee', value: fin.fixed_fee_amount ? <Money value={fin.fixed_fee_amount} currency={fin.currency} /> : '—' }, { label: 'Budget', value: fin.budget_amount ? <Money value={fin.budget_amount} currency={fin.currency} /> : 'Not set' }] : [])]} />
          {fin ? (
            <div className="mt-4 border-t border-stone-100 pt-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-stone-600">Unbilled work in progress</p>
              <p className="mt-1 font-serif text-2xl text-navy-900"><Money value={wip} currency={fin.currency} /></p>
              <p className="text-xs text-stone-600">Time <Money value={fin.unbilled_time} currency={fin.currency} /> · expenses <Money value={fin.unbilled_expenses} currency={fin.currency} /></p>
              {used !== null && (<div className="mt-3"><div className="h-2 overflow-hidden rounded-full bg-stone-200" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.min(100, Math.round(used))} aria-label="WIP as a share of budget"><div className={`h-full ${used > 100 ? 'bg-bad-600' : used > 80 ? 'bg-warn-600' : 'bg-ok-600'}`} style={{ width: `${Math.min(100, used)}%` }} /></div>
                <p className="mt-1 text-xs text-stone-600">{used}% of budget (WIP basis)</p></div>)}
              <p className="mt-3 text-2xs leading-snug text-stone-600">{fin.basis}</p>
            </div>) : <p className="mt-3 text-xs text-stone-600">Financial figures are visible to billing and finance roles.</p>}
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Retention & legal hold">
          <KeyValue columns={2} items={[{ label: 'Retention policy', value: m.retention_policy_key ? humanise(m.retention_policy_key) : 'Not set' }, { label: 'Retention until', value: m.retention_until ? <DateTime value={m.retention_until} mode="date" /> : m.status === 'closed' ? 'Held (legal hold)' : 'Set on closure' },
            { label: 'Legal hold', value: m.legal_hold ? <span className="text-bad-700">Active — {m.legal_hold_reason}</span> : 'None' }]} />
          <p className="mt-3 text-xs text-stone-600">Manage on the <Link className="text-navy-700 underline" to="?tab=closure">Closure tab</Link>.</p>
        </Card>
        <Card title="Status history" description="Every opening, pause, closure and reopening: who, when, why.">
          {m.state_history.length === 0 ? <p className="text-sm text-stone-600">No transitions yet.</p> : (
            <Timeline items={[...m.state_history].reverse().map((e, i) => ({ id: String(i), title: <span className="flex items-center gap-1.5">{e.from ? <StatusBadge status={e.from} /> : null}→<StatusBadge status={e.to} /></span>,
              meta: `${e.actor}${e.approved_by ? ` · approved by ${e.approved_by}` : ''}`, description: e.reason ?? undefined, time: formatDateTime(e.at) }))} />)}
        </Card>
      </div>
      <OpeningChecklist m={m} />
    </div>
  )
}

function OpeningChecklist({ m }: { m: MatterDetail }) {
  const items = m.checklist.filter((c) => c.phase === 'opening')
  if (!items.length) return null
  const outstanding = items.filter((i) => i.required && !i.completed).length
  return (
    <Card title="Opening checklist" description={outstanding ? `${outstanding} required item(s) outstanding` : 'All required items complete'}>
      <ul className="grid gap-1.5 sm:grid-cols-2">{items.map((c) => <li key={c.id} className="flex items-center gap-2 text-sm"><StatusBadge status={c.completed ? 'done' : c.required ? 'pending' : 'not_started'} label={c.completed ? 'Done' : c.required ? 'Required' : 'Optional'} />{c.label}</li>)}</ul>
      <p className="mt-3 text-xs text-stone-600">Tick items off on the <Link className="text-navy-700 underline" to="?tab=closure">Closure tab</Link>.</p>
    </Card>
  )
}
