import { useState } from 'react'
import { DataTable, DateTime, type Column } from '@/components/ui'
import { useApiQuery } from '@/lib/api'
import type { Page } from '@/types/api'
import type { ActivityItem, MatterDetail } from '@/types/matters'

export default function ActivityTab({ m }: { m: MatterDetail }) {
  const [offset, setOffset] = useState(0)
  const q = useApiQuery<Page<ActivityItem>>(['matter', m.id, 'activity', offset], `/matters/${m.id}/activity?limit=25&offset=${offset}`)
  const cols: Column<ActivityItem>[] = [
    { key: 'at', header: 'When', cell: (a) => <DateTime value={a.at} /> },
    { key: 'who', header: 'Who', cell: (a) => <span>{a.actor}{a.actor_type === 'agent' && <span className="ml-1 text-xs text-sim-700">(AI agent)</span>}</span> },
    { key: 's', header: 'What', cell: (a) => <span className="text-sm">{a.summary}</span> },
    { key: 'a', header: 'Action', hideOnNarrow: true, cell: (a) => <code className="text-2xs text-stone-600">{a.action}</code> },
  ]
  return (
    <div className="space-y-2">
      <p className="text-xs text-stone-600">A tamper-evident audit feed of changes to this matter. It records what happened and who did it, never the content of documents or emails.</p>
      <DataTable caption="Matter activity" columns={cols} rows={q.data?.items} rowKey={(a) => String(a.id)} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} emptyTitle="No activity recorded"
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} />
    </div>
  )
}
