import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { Badge, Button, Card, Checkbox, ConfirmDialog, Dialog, EmptyState, Field, IconButton, Input, PageHeader, QueryBoundary, Select, Textarea } from '@/components/ui'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { humanise } from '@/lib/format'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle } from '@/hooks'
import type { MatterTemplate } from '@/types/matters'
import { PRACTICE_AREAS, useRetentionPolicies } from '../clients/common'

const REQUIRED_OPTIONS = ['responsible_partner_id', 'fee_earner_id', 'description', 'target_date', 'budget_amount', 'office_id', 'team_id']

export default function TemplatesAdmin() {
  usePageTitle('Matter templates')
  useBreadcrumbs([{ label: 'Matters', to: '/matters' }, { label: 'Templates' }])
  const { can } = useAuth()
  const q = useApiQuery<{ items: MatterTemplate[] }>(['matter-templates', 'all'], '/matters/templates?include_inactive=true')
  const [edit, setEdit] = useState<MatterTemplate | 'new' | null>(null)
  const [off, setOff] = useState<MatterTemplate | null>(null)
  const writable = can('matters.approve') || can('admin.settings')
  const deact = useApiMutation((t: MatterTemplate) => api.delete(`/matters/templates/${t.id}`), { invalidate: [['matter-templates']], successMessage: 'Template deactivated' })
  return (
    <>
      <PageHeader title="Matter templates" description="Configurable stages, checklists, required information and default tasks. Templates only apply to matters created after a change."
        actions={<><Link to="/matters"><Button variant="secondary">Back to matters</Button></Link>{writable && <Button icon={<Plus className="h-4 w-4" />} onClick={() => setEdit('new')}>New template</Button>}</>} />
      {!writable && <p role="note" className="mb-4 rounded-md bg-ivory-100 px-4 py-2.5 text-sm text-stone-700">Editing templates needs <code className="rounded bg-stone-100 px-1">matters.approve</code> or <code className="rounded bg-stone-100 px-1">admin.settings</code>. You can view them.</p>}
      <QueryBoundary query={q} what="templates" empty={<EmptyState title="No templates" description="Create a template to standardise how matters are opened." />}>
        {(d) => (
          <div className="grid gap-4 lg:grid-cols-2">{d.items.map((t) => (
            <Card key={t.id} title={<span className="flex items-center gap-2">{t.name}{!t.is_active && <Badge tone="neutral">Inactive</Badge>}</span>} description={`${humanise(t.practice_area)} · ${t.matter_type} · default fee: ${humanise(t.default_fee_arrangement)}`}
              actions={writable && <><Button size="sm" variant="secondary" onClick={() => setEdit(t)}>Edit</Button>{t.is_active && <Button size="sm" variant="ghost" onClick={() => setOff(t)}>Deactivate</Button>}</>}>
              <p className="text-xs font-semibold uppercase tracking-wide text-stone-600">Stages</p><p className="mt-1 text-sm">{t.stages.map((s) => s.name).join(' → ') || '—'}</p>
              <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-stone-600">Checklists</p><p className="mt-1 text-sm">{t.opening_checklist.length} opening · {t.closing_checklist.length} closing items</p>
              <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-stone-600">Required information</p><p className="mt-1 text-sm">{t.required_fields.map(humanise).join(', ') || 'None'}</p>
              <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-stone-600">Default tasks · retention</p><p className="mt-1 text-sm">{t.default_tasks.map((x) => x.title).join('; ') || 'None'} · {t.default_retention_key ? humanise(t.default_retention_key) : 'no retention default'}</p>
            </Card>))}</div>)}
      </QueryBoundary>
      {edit && <TemplateDialog template={edit === 'new' ? null : edit} onClose={() => setEdit(null)} />}
      <ConfirmDialog open={!!off} onClose={() => setOff(null)} title="Deactivate this template?" description="Existing matters are unaffected; new matters can no longer use it." confirmLabel="Deactivate" tone="danger" onConfirm={() => { deact.mutate(off!); setOff(null) }} />
    </>
  )
}

interface ListRow { label: string; required: boolean }
function TemplateDialog({ template: t, onClose }: { template: MatterTemplate | null; onClose: () => void }) {
  const retention = useRetentionPolicies()
  const [f, setF] = useState({ name: t?.name ?? '', practice_area: t?.practice_area ?? 'commercial', matter_type: t?.matter_type ?? '', description: t?.description ?? '', default_fee_arrangement: t?.default_fee_arrangement ?? 'hourly', default_retention_key: t?.default_retention_key ?? '', is_active: t?.is_active ?? true })
  const [stages, setStages] = useState(t?.stages ?? [{ key: 'instructions', name: 'Instructions' }])
  const [opening, setOpening] = useState<ListRow[]>(t?.opening_checklist ?? []); const [closing, setClosing] = useState<ListRow[]>(t?.closing_checklist ?? [])
  const [req, setReq] = useState<string[]>(t?.required_fields ?? []); const [tasks, setTasks] = useState(t?.default_tasks ?? [])
  const [err, setErr] = useState<ApiError | null>(null)
  const body = { ...f, description: f.description || null, default_retention_key: f.default_retention_key || null, stages, opening_checklist: opening, closing_checklist: closing, required_fields: req, default_tasks: tasks }
  const m = useApiMutation(() => (t ? api.put(`/matters/templates/${t.id}`, body) : api.post('/matters/templates', body)), { invalidate: [['matter-templates']], errorToast: false, successMessage: 'Template saved', onSuccess: onClose, onError: setErr })
  const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')
  const list = (title: string, rows: ListRow[], set: (r: ListRow[]) => void) => (
    <div><h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-700">{title}</h4>
      <ul className="space-y-1.5">{rows.map((r, i) => <li key={i} className="flex items-center gap-2"><Input aria-label={`${title} item ${i + 1}`} value={r.label} onChange={(e) => set(rows.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} /><Checkbox label="Req." checked={r.required} onChange={(e) => set(rows.map((x, j) => (j === i ? { ...x, required: e.target.checked } : x)))} /><IconButton aria-label="Remove item" size="sm" onClick={() => set(rows.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></IconButton></li>)}</ul>
      <Button size="sm" variant="ghost" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => set([...rows, { label: '', required: true }])}>Add item</Button></div>)
  return (
    <Dialog open onClose={onClose} size="xl" title={t ? 'Edit template' : 'New matter template'}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.name.trim() || !f.matter_type.trim() || stages.some((s) => !s.name.trim())} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Save template</Button></>}>
      <div className="space-y-5">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Name" required><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="Practice area"><Select value={f.practice_area} onChange={(e) => setF({ ...f, practice_area: e.target.value })}>{PRACTICE_AREAS.map((a) => <option key={a} value={a}>{humanise(a)}</option>)}</Select></Field>
          <Field label="Matter type" required><Input value={f.matter_type} onChange={(e) => setF({ ...f, matter_type: e.target.value })} /></Field>
          <Field label="Default fee arrangement"><Select value={f.default_fee_arrangement} onChange={(e) => setF({ ...f, default_fee_arrangement: e.target.value })}><option value="hourly">Hourly</option><option value="fixed">Fixed</option><option value="capped">Capped</option><option value="retainer">Retainer</option></Select></Field>
          <Field label="Default retention policy"><Select value={f.default_retention_key} onChange={(e) => setF({ ...f, default_retention_key: e.target.value })}><option value="">None</option>{retention.map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}</Select></Field>
          <Checkbox className="self-end pb-2" label="Active" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} />
        </div>
        <Field label="Description"><Textarea rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        <div><h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Stages (in order)</h4>
          <ul className="space-y-1.5">{stages.map((s, i) => <li key={i} className="flex items-center gap-2"><span className="w-5 text-xs tabular-nums text-stone-500">{i + 1}.</span><Input aria-label={`Stage ${i + 1} name`} value={s.name} onChange={(e) => setStages(stages.map((x, j) => (j === i ? { key: slug(e.target.value) || x.key, name: e.target.value } : x)))} /><IconButton aria-label="Remove stage" size="sm" onClick={() => setStages(stages.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></IconButton></li>)}</ul>
          <Button size="sm" variant="ghost" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setStages([...stages, { key: `stage_${stages.length + 1}`, name: '' }])}>Add stage</Button></div>
        <div className="grid gap-5 md:grid-cols-2">{list('Opening checklist', opening, setOpening)}{list('Closing checklist', closing, setClosing)}</div>
        <div><h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Required information before opening</h4>
          <div className="flex flex-wrap gap-x-5 gap-y-2">{REQUIRED_OPTIONS.map((k) => <Checkbox key={k} label={humanise(k)} checked={req.includes(k)} onChange={(e) => setReq(e.target.checked ? [...req, k] : req.filter((x) => x !== k))} />)}</div></div>
        <div><h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Default tasks</h4>
          <ul className="space-y-1.5">{tasks.map((x, i) => <li key={i} className="flex items-center gap-2"><Input aria-label={`Task ${i + 1} title`} value={x.title} onChange={(e) => setTasks(tasks.map((y, j) => (j === i ? { ...y, title: e.target.value } : y)))} /><Input aria-label="Due in days" type="number" min={0} className="w-24" value={x.due_in_days} onChange={(e) => setTasks(tasks.map((y, j) => (j === i ? { ...y, due_in_days: Number(e.target.value) } : y)))} /><span className="text-xs text-stone-600">days</span><IconButton aria-label="Remove task" size="sm" onClick={() => setTasks(tasks.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></IconButton></li>)}</ul>
          <Button size="sm" variant="ghost" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setTasks([...tasks, { title: '', due_in_days: 7 }])}>Add task</Button></div>
      </div>
    </Dialog>
  )
}
