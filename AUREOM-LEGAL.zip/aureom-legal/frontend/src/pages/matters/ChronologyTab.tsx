import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Pencil, Plus, Trash2 } from 'lucide-react'
import { Badge, Button, Card, CitationChip, ConfirmDialog, Dialog, Field, IconButton, Input, QueryBoundary, Select, Textarea } from '@/components/ui'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatDate } from '@/lib/format'
import type { ChronologyEntry, MatterDetail } from '@/types/matters'

export default function ChronologyTab({ m }: { m: MatterDetail }) {
  const { can } = useAuth()
  const nav = useNavigate()
  const [showRejected, setShowRejected] = useState(false)
  const [edit, setEdit] = useState<ChronologyEntry | 'new' | null>(null)
  const [rm, setRm] = useState<ChronologyEntry | null>(null)
  const key = ['chronology', m.id, showRejected]
  const q = useApiQuery<{ items: ChronologyEntry[]; note: string }>(key, `/matters/${m.id}/chronology${showRejected ? '?include_rejected=true' : ''}`)
  const del = useApiMutation((e: ChronologyEntry) => api.delete(`/matters/${m.id}/chronology/${e.id}`), { invalidate: [['chronology', m.id]], successMessage: 'Entry rejected (kept in history)' })
  const writable = can('matters.write') && m.status !== 'closed'
  return (
    <Card title="Chronology" description="An editable timeline. Explicit dates are stated in a source; inferred dates are estimates and need human confirmation."
      actions={<><label className="flex items-center gap-1.5 text-xs text-stone-700"><input type="checkbox" className="accent-navy-800" checked={showRejected} onChange={(e) => setShowRejected(e.target.checked)} />Show rejected</label>{writable && <Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEdit('new')}>Add entry</Button>}</>}>
      <QueryBoundary query={q} what="chronology" empty={<p className="text-sm text-stone-600">No chronology entries yet. Add one manually, or ask the chronology agent to propose entries from the file (you review them first).</p>}>
        {(d) => (
          <ol className="relative space-y-4 border-l border-stone-300 pl-6">
            {d.items.map((e) => (
              <li key={e.id} className={`relative ${e.status === 'rejected' ? 'opacity-60' : ''}`}>
                <span className={`absolute -left-[1.9rem] top-1.5 h-3.5 w-3.5 rounded-full ring-4 ring-white ${e.date_basis === 'explicit' ? 'bg-navy-600' : 'border-2 border-dashed border-brass-500 bg-white'}`} aria-hidden />
                <div className="flex flex-wrap items-center gap-2">
                  <time className="text-sm font-semibold tabular-nums text-navy-900">{e.event_date ? formatDate(e.event_date) : e.date_text ?? 'Undated'}</time>
                  {e.event_date && e.date_text && e.date_text !== e.event_date && <span className="text-xs text-stone-600">written “{e.date_text}”</span>}
                  <Badge tone={e.date_basis === 'explicit' ? 'info' : 'brass'}>{e.date_basis === 'explicit' ? 'Explicit date' : 'Inferred date'}</Badge>
                  <Badge tone={e.origin === 'agent' ? 'simulated' : 'neutral'}>{e.origin === 'agent' ? 'AI-proposed, human-reviewed' : 'Manual'}</Badge>
                  {e.status === 'edited' && <Badge tone="neutral">Edited{e.edited_by_name ? ` by ${e.edited_by_name}` : ''}</Badge>}
                  {e.status === 'rejected' && <Badge tone="danger">Rejected</Badge>}
                  {writable && e.status !== 'rejected' && <span className="ml-auto flex"><IconButton aria-label="Edit entry" size="sm" onClick={() => setEdit(e)}><Pencil className="h-3.5 w-3.5" /></IconButton><IconButton aria-label="Reject entry" size="sm" onClick={() => setRm(e)}><Trash2 className="h-3.5 w-3.5" /></IconButton></span>}
                </div>
                <p className="mt-1 text-sm text-stone-800">{e.description}</p>
                {(e.source?.document_title || e.source?.title || e.source?.quote) && (
                  <div className="mt-1.5"><CitationChip documentTitle={String(e.source.document_title ?? e.source.title ?? 'Source')} versionNo={e.source.version_no} page={e.source.page} paragraph={e.source.paragraph} quote={e.source.quote}
                    onClick={e.source.type === 'document' && e.source.id ? () => nav(`/documents/${e.source.id}`) : undefined} />{e.source.quote && <blockquote className="mt-1 border-l-2 border-brass-300 pl-2 text-xs italic text-stone-700">“{e.source.quote}”</blockquote>}</div>)}
              </li>))}
          </ol>)}
      </QueryBoundary>
      {edit && <EntryDialog matterId={m.id} entry={edit === 'new' ? null : edit} onClose={() => setEdit(null)} />}
      <ConfirmDialog open={!!rm} onClose={() => setRm(null)} title="Reject this entry?" description="It is hidden from the timeline but kept in history." confirmLabel="Reject entry" tone="danger" onConfirm={() => { del.mutate(rm!); setRm(null) }} />
    </Card>
  )
}

function EntryDialog({ matterId, entry, onClose }: { matterId: string; entry: ChronologyEntry | null; onClose: () => void }) {
  const [f, setF] = useState({ event_date: entry?.event_date ?? '', date_text: entry?.date_text ?? '', date_basis: entry?.date_basis ?? 'explicit', description: entry?.description ?? '', quote: String(entry?.source?.quote ?? ''), src: String(entry?.source?.document_title ?? entry?.source?.title ?? '') })
  const [err, setErr] = useState<ApiError | null>(null)
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))
  const source = { ...(entry?.source ?? {}), ...(f.src ? { document_title: f.src } : {}), ...(f.quote ? { quote: f.quote } : {}) }
  const body = { event_date: f.event_date || null, date_text: f.date_text || null, date_basis: f.date_basis, description: f.description.trim(), source }
  const m = useApiMutation(() => (entry ? api.patch(`/matters/${matterId}/chronology/${entry.id}`, { ...body, expected_version: entry.version }) : api.post(`/matters/${matterId}/chronology`, body)),
    { invalidate: [['chronology', matterId]], errorToast: false, successMessage: entry ? 'Entry updated' : 'Entry added', onSuccess: onClose, onError: setErr })
  return (
    <Dialog open onClose={onClose} title={entry ? 'Edit chronology entry' : 'Add chronology entry'} footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={f.description.trim().length < 3} loading={m.isPending} onClick={() => { setErr(null); m.mutate() }}>Save</Button></>}>
      <div className="space-y-3">
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}{err.isConflict && ' Close this dialog to reload the latest version.'}</p>}
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Date"><Input type="date" value={f.event_date} onChange={set('event_date')} /></Field>
          <Field label="Date as written" hint="e.g. “end of Q1”"><Input value={f.date_text} onChange={set('date_text')} /></Field>
          <Field label="Date basis"><Select value={f.date_basis} onChange={set('date_basis')}><option value="explicit">Explicit (stated in a source)</option><option value="inferred">Inferred (estimated)</option></Select></Field>
        </div>
        <Field label="What happened" required><Textarea rows={3} value={f.description} onChange={set('description')} /></Field>
        <div className="grid gap-3 sm:grid-cols-2"><Field label="Source (document or email title)"><Input value={f.src} onChange={set('src')} /></Field><Field label="Supporting quote"><Input value={f.quote} onChange={set('quote')} /></Field></div>
      </div>
    </Dialog>
  )
}
