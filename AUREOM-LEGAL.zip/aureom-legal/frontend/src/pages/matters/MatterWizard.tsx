import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { Badge, Button, Dialog, useToast, Field, IconButton, Input, KeyValue, Select, StatusBadge, StatusStepper, Textarea } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth, useOffice } from '@/lib/auth'
import { humanise } from '@/lib/format'
import type { Page } from '@/types/api'
import type { ConflictSearchRow, ContactDetail, PartyRole } from '@/types/clients'
import type { MatterDetail, MatterTemplate } from '@/types/matters'
import { ContactPicker } from '../clients/ContactPicker'
import { PARTY_ROLES, PRACTICE_AREAS, RoleBadge, errMsg, useRetentionPolicies, useStaff, useTeams } from '../clients/common'

const STEPS = [{ key: 'client', label: 'Client & template' }, { key: 'details', label: 'Details & team' }, { key: 'fees', label: 'Fees & access' }, { key: 'parties', label: 'Parties & review' }]
const DECIMAL = /^\d{1,12}(\.\d{1,2})?$/

interface PartyDraft { contact: { id: string; display_name: string }; role: PartyRole }
interface MemberDraft { user_id?: string; team_id?: string; access: 'allow' | 'deny'; reason: string; label: string }

/** Matter-opening wizard. Creates a PROSPECTIVE matter; opening it is a separate, validated state transition (conflicts, onboarding, checklist). */
export default function MatterWizard({ onClose }: { onClose: () => void }) {
  const nav = useNavigate()
  const toast = useToast()
  const { can, me } = useAuth()
  const { offices } = useOffice()
  const { staff, source } = useStaff()
  const { teams, available: teamsAvailable } = useTeams()
  const retention = useRetentionPolicies()
  const [step, setStep] = useState('client')
  const [client, setClient] = useState<{ id: string; display_name: string } | null>(null)
  const [tplId, setTplId] = useState('')
  const [f, setF] = useState({ title: '', matter_type: '', practice_area: '', description: '', office_id: me?.user.office_id ?? '', team_id: '', responsible_partner_id: '', fee_earner_id: me?.user.id ?? '', jurisdiction: 'england_and_wales', target_date: '',
    fee_arrangement: 'hourly', fixed_fee_amount: '', budget_amount: '', retention_policy_key: '', access_level: 'standard' })
  const [parties, setParties] = useState<PartyDraft[]>([]); const [members, setMembers] = useState<MemberDraft[]>([])
  const [newParty, setNewParty] = useState<{ contact: { id: string; display_name: string } | null; role: PartyRole }>({ contact: null, role: 'counterparty' })
  const [newMember, setNewMember] = useState({ who: '', access: 'allow' as 'allow' | 'deny', reason: '' })
  const [err, setErr] = useState<string | null>(null)
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))

  const tpls = useApiQuery<{ items: MatterTemplate[] }>(['matter-templates'], '/matters/templates')
  const tpl = tpls.data?.items.find((t) => t.id === tplId)
  const cd = useApiQuery<ContactDetail>(['client', client?.id], `/clients/${client?.id}`, { enabled: !!client })
  const searches = useApiQuery<Page<ConflictSearchRow>>(['conflicts', 'subject', client?.id], `/conflicts/searches${qs({ subject_contact_id: client?.id, limit: 20 })}`, { enabled: !!client && can('conflicts.run') })
  const cleared = searches.data?.items.find((s) => s.status === 'cleared_by_reviewer')
  const pending = searches.data?.items.find((s) => s.status === 'pending_review')
  const onboarded = cd.data?.onboarding.status === 'approved'

  const pickTemplate = (id: string) => {
    setTplId(id)
    const t = tpls.data?.items.find((x) => x.id === id)
    if (t) setF((s) => ({ ...s, practice_area: t.practice_area, matter_type: t.matter_type, fee_arrangement: t.default_fee_arrangement, retention_policy_key: t.default_retention_key ?? s.retention_policy_key }))
  }
  const requiredField = (k: string) => !!tpl?.required_fields.includes(k)
  const missingRequired = (tpl?.required_fields ?? []).filter((k) => ['description', 'target_date', 'budget_amount', 'office_id', 'team_id', 'matter_type'].includes(k) && !(f as Record<string, string>)[k]?.trim())
  const feeOk = (!f.fixed_fee_amount || DECIMAL.test(f.fixed_fee_amount)) && (!f.budget_amount || DECIMAL.test(f.budget_amount))
  const stepOk: Record<string, boolean> = {
    client: !!client && !!f.practice_area,
    details: f.title.trim().length >= 3 && !!f.responsible_partner_id && !!f.office_id && missingRequired.length === 0,
    fees: feeOk, parties: true,
  }
  const idx = STEPS.findIndex((s) => s.key === step)

  const create = useApiMutation(async () => {
    const m = await api.post<MatterDetail>('/matters', {
      title: f.title.trim(), client_id: client!.id, template_id: tplId || null, matter_type: f.matter_type || null, practice_area: f.practice_area || null, description: f.description || null,
      office_id: f.office_id || null, team_id: f.team_id || null, responsible_partner_id: f.responsible_partner_id, fee_earner_id: f.fee_earner_id || null, jurisdiction: f.jurisdiction,
      target_date: f.target_date || null, fee_arrangement: f.fee_arrangement, fixed_fee_amount: f.fixed_fee_amount || null, budget_amount: f.budget_amount || null,
      retention_policy_key: f.retention_policy_key || null, access_level: f.access_level, conflict_search_id: cleared?.id ?? null })
    // The matter now exists: never roll back, so a failure adding parties/members is reported instead of creating duplicates on retry.
    const failed: string[] = []
    for (const p of parties) { try { await api.post(`/matters/${m.id}/parties`, { contact_id: p.contact.id, role: p.role }) } catch (e) { failed.push(`${p.contact.display_name}: ${errMsg(e)}`) } }
    for (const mm of members) { try { await api.post(`/matters/${m.id}/members`, { user_id: mm.user_id ?? null, team_id: mm.team_id ?? null, access: mm.access, reason: mm.reason }) } catch (e) { failed.push(`${mm.label}: ${errMsg(e)}`) } }
    if (failed.length) toast.push({ tone: 'warning', title: 'Matter created, but some entries were not added', description: failed.join(' · ') })
    return m
  }, { invalidate: [['matters']], errorToast: false, successMessage: (m) => `Matter ${m.reference} created (prospective)`, onSuccess: (m) => { onClose(); nav(`/matters/${m.id}`) }, onError: (e) => setErr(errMsg(e)) })

  const addMember = () => {
    if (!newMember.who || newMember.reason.trim().length < 5) return
    const [kind, id] = newMember.who.split(':') as ['u' | 't', string]
    const label = kind === 'u' ? staff.find((s) => s.id === id)?.name ?? id : teams.find((t) => t.id === id)?.name ?? id
    setMembers((m) => [...m, { [kind === 'u' ? 'user_id' : 'team_id']: id, access: newMember.access, reason: newMember.reason.trim(), label } as MemberDraft])
    setNewMember({ who: '', access: 'allow', reason: '' })
  }

  return (
    <Dialog open onClose={onClose} size="xl" title="Open a new matter" description="Creates a prospective matter. Opening it later is a validated step: conflict search cleared by a human, onboarding approved, checklist complete."
      footer={<>
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        {idx > 0 && <Button variant="secondary" onClick={() => setStep(STEPS[idx - 1]!.key)}>Back</Button>}
        {idx < STEPS.length - 1 ? <Button disabled={!stepOk[step]} onClick={() => setStep(STEPS[idx + 1]!.key)}>Continue</Button>
          : <Button loading={create.isPending} disabled={!stepOk.client || !stepOk.details || !stepOk.fees} onClick={() => { setErr(null); create.mutate() }}>Create prospective matter</Button>}
      </>}>
      <div className="space-y-5">
        <StatusStepper steps={STEPS} current={step} />
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}

        {step === 'client' && (
          <div className="space-y-4">
            <Field label="Client" required hint="Create the client first (Clients → New prospective client) if they are not listed.">{(p) => <ContactPicker id={p.id} value={client} onChange={(c) => setClient(c ? { id: c.id, display_name: c.display_name } : null)} />}</Field>
            {client && (
              <div className="rounded-md border border-stone-200 bg-ivory-50 p-4 text-sm" aria-live="polite">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-stone-700">Readiness to open</p>
                <ul className="space-y-1.5">
                  <li>Onboarding: {cd.isPending ? '…' : <><StatusBadge status={cd.data?.onboarding.status} /> {!onboarded && <Link className="ml-1 text-navy-700 underline" to={`/clients/${client.id}?tab=onboarding`} target="_blank">Complete onboarding</Link>}</>}</li>
                  <li>Conflict search: {!can('conflicts.run') ? <span className="text-stone-600">not visible to your role</span> : searches.isPending ? '…' : cleared ? <Badge tone="success">Cleared by a human reviewer</Badge> : pending ? <><Badge tone="warning">Awaiting reviewer</Badge> <Link className="ml-1 text-navy-700 underline" to={`/clients/conflicts/${pending.id}`} target="_blank">Open search</Link></> : <><Badge tone="warning">None run</Badge> <Link className="ml-1 text-navy-700 underline" to={`/clients/${client.id}?tab=conflicts`} target="_blank">Run from the client’s Conflicts tab</Link></>}</li>
                </ul>
                <p className="mt-2 text-xs text-stone-600">You can create the matter now; it stays prospective and cannot be opened until both are complete.</p>
              </div>)}
            <Field label="Matter template" hint="Provides stages, checklists, default tasks and required information.">
              <Select value={tplId} onChange={(e) => pickTemplate(e.target.value)}><option value="">No template (choose practice area manually)</option>{tpls.data?.items.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select></Field>
            {!tpl && <Field label="Practice area" required><Select value={f.practice_area} onChange={set('practice_area')}><option value="">Select…</option>{PRACTICE_AREAS.map((a) => <option key={a} value={a}>{humanise(a)}</option>)}</Select></Field>}
            {tpl && (
              <div className="grid gap-4 rounded-md border border-stone-200 p-4 text-sm sm:grid-cols-2">
                <div><h4 className="text-xs font-semibold uppercase tracking-wide text-stone-700">Stages</h4><ol className="mt-1 list-decimal pl-5">{tpl.stages.map((s) => <li key={s.key}>{s.name}</li>)}</ol>
                  <h4 className="mt-3 text-xs font-semibold uppercase tracking-wide text-stone-700">Required information to open</h4><p className="mt-1 text-xs">{tpl.required_fields.map(humanise).join(', ') || 'None'}</p></div>
                <div><h4 className="text-xs font-semibold uppercase tracking-wide text-stone-700">Opening checklist</h4><ul className="mt-1 list-disc pl-5">{tpl.opening_checklist.map((c) => <li key={c.label}>{c.label}{c.required && <span className="text-xs text-stone-600"> (required)</span>}</li>)}</ul>
                  <h4 className="mt-3 text-xs font-semibold uppercase tracking-wide text-stone-700">Default tasks</h4><ul className="mt-1 list-disc pl-5">{tpl.default_tasks.map((t) => <li key={t.title}>{t.title} <span className="text-xs text-stone-600">(+{t.due_in_days}d)</span></li>)}</ul></div>
              </div>)}
          </div>)}

        {step === 'details' && (
          <div className="space-y-4">
            <Field label="Matter title" required><Input value={f.title} onChange={set('title')} /></Field>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Matter type"><Input value={f.matter_type} onChange={set('matter_type')} /></Field>
              <Field label="Jurisdiction"><Select value={f.jurisdiction} onChange={set('jurisdiction')}><option value="england_and_wales">England & Wales</option><option value="scotland">Scotland</option><option value="northern_ireland">Northern Ireland</option></Select></Field>
              <Field label="Target date" required={requiredField('target_date')}><Input type="date" value={f.target_date} onChange={set('target_date')} /></Field>
            </div>
            <Field label="Description" required={requiredField('description')}><Textarea rows={3} value={f.description} onChange={set('description')} /></Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Responsible partner" required hint={source === 'derived' ? 'Showing partners visible on matters you can see.' : undefined}><Select value={f.responsible_partner_id} onChange={set('responsible_partner_id')}><option value="">Select…</option>{staff.filter((s) => s.role === 'partner').map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
              <Field label="Fee earner"><Select value={f.fee_earner_id} onChange={set('fee_earner_id')}><option value="">Me</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
              <Field label="Office" required><Select value={f.office_id} onChange={set('office_id')}><option value="">Select…</option>{offices.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select></Field>
              <Field label="Team" hint={teamsAvailable ? undefined : 'Defaults to the partner’s team (team list needs administrator access).'}><Select value={f.team_id} onChange={set('team_id')} disabled={!teamsAvailable}><option value="">Partner’s team</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select></Field>
            </div>
            {missingRequired.length > 0 && <p className="text-xs text-warn-700">This template requires: {missingRequired.map(humanise).join(', ')}.</p>}
          </div>)}

        {step === 'fees' && (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Fee arrangement"><Select value={f.fee_arrangement} onChange={set('fee_arrangement')}><option value="hourly">Hourly rates</option><option value="fixed">Fixed fee</option><option value="capped">Capped fee</option><option value="retainer">Retainer</option></Select></Field>
              <Field label="Fixed / capped fee (GBP)" error={f.fixed_fee_amount && !DECIMAL.test(f.fixed_fee_amount) ? 'Enter an amount like 1850.00' : undefined}><Input inputMode="decimal" value={f.fixed_fee_amount} onChange={set('fixed_fee_amount')} disabled={f.fee_arrangement === 'hourly'} /></Field>
              <Field label="Budget (GBP)" required={requiredField('budget_amount')} error={f.budget_amount && !DECIMAL.test(f.budget_amount) ? 'Enter an amount like 18000.00' : undefined}><Input inputMode="decimal" value={f.budget_amount} onChange={set('budget_amount')} /></Field>
            </div>
            <Field label="Retention policy" hint="Applied when the matter closes."><Select value={f.retention_policy_key} onChange={set('retention_policy_key')}><option value="">Template default</option>{retention.map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}</Select></Field>
            <fieldset className="rounded-md border border-stone-200 p-4"><legend className="px-1 text-xs font-semibold uppercase tracking-wide text-stone-700">Access</legend>
              <div className="space-y-2">
                <label className="flex items-start gap-2 text-sm"><input type="radio" name="access" className="mt-1 accent-navy-800" checked={f.access_level === 'standard'} onChange={() => setF((s) => ({ ...s, access_level: 'standard' }))} /><span><strong>Standard</strong> — visible to fee-earning staff in the firm.</span></label>
                <label className="flex items-start gap-2 text-sm"><input type="radio" name="access" className="mt-1 accent-navy-800" disabled={!can('matters.access_admin')} checked={f.access_level === 'restricted'} onChange={() => setF((s) => ({ ...s, access_level: 'restricted' }))} /><span><strong>Restricted</strong> — only the responsible partner, fee earner and an explicit access list can see it. Hidden from search, previews, exports and AI retrieval for everyone else.{!can('matters.access_admin') && <span className="block text-xs text-stone-600">Creating a restricted matter needs <code className="rounded bg-stone-100 px-1">matters.access_admin</code> (partner or compliance). Create it as standard and ask a partner to restrict it.</span>}</span></label>
              </div>
              {f.access_level === 'restricted' && (can('matters.access_admin') ? (
                <div className="mt-4 space-y-3 border-t border-stone-200 pt-3">
                  <p className="text-xs text-stone-700">Access list / ethical-wall exclusions (optional now; editable later). Exclusions always win.</p>
                  {members.map((m, i) => <p key={i} className="flex items-center gap-2 text-sm"><Badge tone={m.access === 'allow' ? 'success' : 'danger'}>{m.access}</Badge>{m.label}<span className="text-xs text-stone-600">— {m.reason}</span><IconButton aria-label={`Remove ${m.label}`} size="sm" onClick={() => setMembers((x) => x.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></IconButton></p>)}
                  <div className="grid gap-2 sm:grid-cols-[1fr_8rem_1fr_auto] sm:items-end">
                    <Field label="Person or team"><Select value={newMember.who} onChange={(e) => setNewMember((s) => ({ ...s, who: e.target.value }))}><option value="">Select…</option>{staff.map((s) => <option key={s.id} value={`u:${s.id}`}>{s.name}</option>)}{newMember.access === 'deny' && teams.map((t) => <option key={t.id} value={`t:${t.id}`}>Team: {t.name}</option>)}</Select></Field>
                    <Field label="Access"><Select value={newMember.access} onChange={(e) => setNewMember((s) => ({ ...s, access: e.target.value as 'allow' | 'deny', who: '' }))}><option value="allow">Allow</option><option value="deny">Deny (wall)</option></Select></Field>
                    <Field label="Reason (min 5 chars)"><Input value={newMember.reason} onChange={(e) => setNewMember((s) => ({ ...s, reason: e.target.value }))} /></Field>
                    <Button variant="secondary" icon={<Plus className="h-4 w-4" />} onClick={addMember} disabled={!newMember.who || newMember.reason.trim().length < 5}>Add</Button>
                  </div>
                </div>) : <p className="mt-3 text-xs text-stone-600">Adding other people to the access list needs <code className="rounded bg-stone-100 px-1">matters.access_admin</code> (partner or compliance). The responsible partner and fee earner always have access.</p>)}
            </fieldset>
          </div>)}

        {step === 'parties' && (
          <div className="space-y-4">
            <div>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-stone-700">Other parties (optional)</h4>
              <ul className="mb-3 space-y-1.5">{parties.map((p, i) => <li key={i} className="flex items-center gap-2 text-sm"><RoleBadge role={p.role} />{p.contact.display_name}<IconButton aria-label={`Remove ${p.contact.display_name}`} size="sm" onClick={() => setParties((x) => x.filter((_, j) => j !== i))}><Trash2 className="h-3.5 w-3.5" /></IconButton></li>)}
                {parties.length === 0 && <li className="text-xs text-stone-600">The client is added as a party automatically. Add counterparties, payers, beneficiaries or witnesses.</li>}</ul>
              <div className="grid gap-2 sm:grid-cols-[1fr_12rem_auto] sm:items-end">
                <Field label="Contact">{(p) => <ContactPicker id={p.id} value={newParty.contact} onChange={(c) => setNewParty((s) => ({ ...s, contact: c ? { id: c.id, display_name: c.display_name } : null }))} />}</Field>
                <Field label="Role"><Select value={newParty.role} onChange={(e) => setNewParty((s) => ({ ...s, role: e.target.value as PartyRole }))}>{PARTY_ROLES.map((r) => <option key={r} value={r}>{humanise(r)}</option>)}</Select></Field>
                <Button variant="secondary" icon={<Plus className="h-4 w-4" />} disabled={!newParty.contact} onClick={() => { setParties((p) => [...p, { contact: newParty.contact!, role: newParty.role }]); setNewParty({ contact: null, role: 'counterparty' }) }}>Add</Button>
              </div>
            </div>
            <div className="rounded-md border border-stone-200 bg-ivory-50 p-4"><h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-stone-700">Review</h4>
              <KeyValue columns={2} items={[{ label: 'Client', value: client?.display_name }, { label: 'Title', value: f.title }, { label: 'Practice area', value: humanise(f.practice_area) }, { label: 'Template', value: tpl?.name ?? 'None' },
                { label: 'Partner', value: staff.find((s) => s.id === f.responsible_partner_id)?.name }, { label: 'Fee earner', value: staff.find((s) => s.id === f.fee_earner_id)?.name ?? 'Me' },
                { label: 'Fee arrangement', value: humanise(f.fee_arrangement) }, { label: 'Access', value: humanise(f.access_level) }]} />
              <p className="mt-3 text-xs text-stone-600">Status after creation: <strong>Prospective</strong>. {cleared ? 'A cleared conflict search will be linked.' : 'No cleared conflict search yet — one is required to open the matter.'}</p></div>
          </div>)}
      </div>
    </Dialog>
  )
}
