import { useState } from 'react'
import { AlertTriangle } from 'lucide-react'
import { Badge, Button, Card, Checkbox, Dialog, Field, Select, StatusBadge, Textarea } from '@/components/ui'
import { DateTime } from '@/components/ui'
import { ApiError, api, useApiMutation } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { formatDateTime } from '@/lib/format'
import type { AvailableTransition, ChecklistItem, MatterDetail } from '@/types/matters'
import { blockerText, useRetentionPolicies } from '../clients/common'
import { transitionLabel } from './TransitionDialog'

export default function ClosureTab({ m, transitions, onTransition }: { m: MatterDetail; transitions: AvailableTransition[]; onTransition: (t: AvailableTransition) => void }) {
  const { can } = useAuth()
  const policies = useRetentionPolicies()
  const [policy, setPolicy] = useState(m.retention_policy_key ?? '')
  const [hold, setHold] = useState(false)
  const inv = [['matter', m.id], ['matters']] as never
  const toggle = useApiMutation(({ it, completed }: { it: ChecklistItem; completed: boolean }) => api.post(`/matters/${m.id}/checklist/${it.id}`, { completed }), { invalidate: inv })
  const setRet = useApiMutation(() => api.put(`/matters/${m.id}/retention`, { policy_key: policy }), { invalidate: inv, successMessage: 'Retention policy saved' })
  const closeT = transitions.find((t) => t.to_status === 'closed')
  const canEdit = can('matters.write') && m.status !== 'closed'
  const section = (phase: 'opening' | 'closing', title: string) => {
    const items = m.checklist.filter((c) => c.phase === phase)
    return (
      <Card title={title} description={items.length ? `${items.filter((i) => i.completed).length} of ${items.length} complete` : undefined}>
        {items.length === 0 ? <p className="text-sm text-stone-600">No items.</p> : <ul className="space-y-2.5">{items.map((c) => (
          <li key={c.id} className="flex items-start justify-between gap-3">
            <Checkbox label={<span>{c.label} {c.required ? <Badge tone="neutral">Required</Badge> : <span className="text-xs text-stone-500">optional</span>}</span>} hint={c.completed ? `Done ${formatDateTime(c.completed_at)}${c.completed_by ? ` by ${c.completed_by}` : ''}` : undefined}
              checked={toggle.isPending && toggle.variables?.it.id === c.id ? toggle.variables.completed : c.completed} disabled={!canEdit || toggle.isPending} onChange={(e) => toggle.mutate({ it: c, completed: e.target.checked })} />
          </li>))}</ul>}
        {!canEdit && m.status === 'closed' && <p className="mt-3 text-xs text-stone-600">Closed matters’ checklists are read-only. Reopen the matter to change them.</p>}
      </Card>
    )
  }
  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-2">{section('closing', 'Closure checklist')}{section('opening', 'Opening checklist')}</div>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Retention policy" description="Retention runs from the closure date. Retention expiry is calculated and displayed; destruction is never automatic.">
          <div className="flex items-end gap-3">
            <Field label="Policy" className="flex-1"><Select value={policy} onChange={(e) => setPolicy(e.target.value)} disabled={!canEdit}><option value="">Not set</option>{policies.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}{m.retention_policy_key && !policies.some((p) => p.key === m.retention_policy_key) && <option value={m.retention_policy_key}>{m.retention_policy_key}</option>}</Select></Field>
            <Button variant="secondary" disabled={!canEdit || !policy || policy === m.retention_policy_key} loading={setRet.isPending} onClick={() => setRet.mutate()}>Save</Button>
          </div>
          <p className="mt-3 text-sm">Retention until: {m.retention_until ? <strong><DateTime value={m.retention_until} mode="date" /></strong> : <span className="text-stone-600">{m.status === 'closed' ? 'held (legal hold) or not set' : 'calculated when the matter closes'}</span>}</p>
        </Card>
        <Card title="Legal hold" description="A legal hold blocks closure and overrides any retention expiry." actions={can('matters.approve') ? <Button size="sm" variant={m.legal_hold ? 'secondary' : 'danger'} onClick={() => setHold(true)}>{m.legal_hold ? 'Release hold…' : 'Place legal hold…'}</Button> : undefined}>
          {m.legal_hold ? <p className="text-sm"><Badge tone="danger">Legal hold active</Badge> <span className="ml-1">{m.legal_hold_reason}</span></p> : <p className="text-sm text-stone-600">No legal hold on this matter.</p>}
          {!can('matters.approve') && <p className="mt-2 text-xs text-stone-600">Placing or releasing a hold needs <code className="rounded bg-stone-100 px-1">matters.approve</code> (partner or compliance).</p>}
        </Card>
      </div>
      <Card title="Status & closure" description="State changes are validated and recorded with who changed them.">
        <div className="flex flex-wrap items-center gap-3"><span className="text-sm">Current status:</span><StatusBadge status={m.status} />
          {transitions.map((t) => <Button key={t.to_status} size="sm" variant={t.to_status === 'closed' ? 'primary' : 'secondary'} onClick={() => onTransition(t)}>{transitionLabel(m.status, t.to_status)}{!t.allowed && ' …'}</Button>)}</div>
        {closeT && closeT.blockers.length > 0 && (
          <div className="mt-4 rounded-md border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700"><p className="flex items-center gap-1.5 font-semibold"><AlertTriangle className="h-4 w-4" aria-hidden />Blocking closure:</p><ul className="mt-1 list-disc pl-5">{closeT.blockers.map((b, i) => <li key={i}>{blockerText(b)}</li>)}</ul></div>)}
        {closeT && closeT.blockers.length === 0 && m.status !== 'closed' && <p className="mt-4 text-sm text-ok-700">No blockers: this matter can be submitted for closure.</p>}
      </Card>
      {hold && <HoldDialog m={m} onClose={() => setHold(false)} />}
    </div>
  )
}

function HoldDialog({ m, onClose }: { m: MatterDetail; onClose: () => void }) {
  const [reason, setReason] = useState(''); const [err, setErr] = useState<ApiError | null>(null)
  const mu = useApiMutation(() => api.post(`/matters/${m.id}/legal-hold`, { active: !m.legal_hold, reason: reason.trim() }), { invalidate: [['matter', m.id], ['matters']] as never, errorToast: false, successMessage: m.legal_hold ? 'Legal hold released' : 'Legal hold placed', onSuccess: onClose, onError: setErr })
  return (
    <Dialog open onClose={onClose} title={m.legal_hold ? 'Release legal hold' : 'Place legal hold'} description="Recorded in the audit trail."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant={m.legal_hold ? 'primary' : 'danger'} disabled={reason.trim().length < 5} loading={mu.isPending} onClick={() => { setErr(null); mu.mutate() }}>{m.legal_hold ? 'Release hold' : 'Place hold'}</Button></>}>
      <div className="space-y-3">{err && <p role="alert" className="text-sm text-bad-700">{err.message}</p>}<Field label="Reason" required><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field></div>
    </Dialog>
  )
}
