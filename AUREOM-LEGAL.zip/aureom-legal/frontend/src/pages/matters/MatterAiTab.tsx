import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Ban, GitBranch } from 'lucide-react'
import { Badge, Button, Card, DataTable, DateTime, PermissionDenied, type Column } from '@/components/ui'
import { useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import type { Page } from '@/types/api'
import type { AgentCatalogItem, RunSummary } from '@/types/ai'
import type { MatterDetail } from '@/types/matters'
import { ACTIVE_STATES, AGENT_ICON, RunStatus, useCatalog } from '@/pages/ai/common'
import { StartRunDialog } from '@/pages/ai/StartRunDialog'

/** AI activity for one matter: scoped run buttons, recent runs, and whether AI retrieval is permitted here at all. */
export default function MatterAiTab({ matter }: { matter: MatterDetail }) {
  const { can } = useAuth()
  const [agent, setAgent] = useState<AgentCatalogItem | null>(null)
  const allowed = matter.ai_retrieval_allowed && can('ai.use')
  const cat = useCatalog()
  const runs = useApiQuery<Page<RunSummary>>(['ai', 'runs', 'matter', matter.id], `/agents/runs?matter_id=${matter.id}&limit=10`, {
    enabled: can('ai.use'),
    refetchInterval: (q) => ((q.state.data as Page<RunSummary> | undefined)?.items.some((r) => ACTIVE_STATES.has(r.status)) ? 2500 : false),
  })
  const cols: Column<RunSummary>[] = [
    { key: 'a', header: 'Agent', cell: (r) => <Link to={`/ai/runs/${r.id}`} className="font-medium text-navy-800 underline decoration-brass-500/60 underline-offset-2">{r.agent_name}</Link> },
    { key: 's', header: 'State', cell: (r) => <span className="flex flex-col items-start gap-1"><RunStatus status={r.status} />{r.pending_actions > 0 && <span className="text-2xs text-warn-700">{r.pending_actions} to review</span>}</span> },
    { key: 'u', header: 'By', cell: (r) => r.requested_by_name ?? '—', hideOnNarrow: true },
    { key: 'p', header: 'Provider', cell: (r) => r.provider === 'mock' ? <Badge tone="simulated">Mock</Badge> : r.provider, hideOnNarrow: true },
    { key: 't', header: 'When', cell: (r) => <DateTime value={r.created_at} mode="relative" /> },
  ]
  if (!can('ai.use')) return <PermissionDenied permission="ai.use" message="Your role cannot use AI agents on matters." />
  return (
    <div className="space-y-5">
      {!matter.ai_retrieval_allowed ? (
        <div role="alert" className="flex items-start gap-3 rounded-lg border border-bad-100 bg-bad-50 px-4 py-3 text-sm text-bad-700">
          <Ban className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
          <p><strong>AI retrieval is switched off for this matter.</strong> Agents cannot read its documents, correspondence or records, for anyone. A partner can change this under the Access tab (with a recorded reason).</p>
        </div>
      ) : (
        <p className="rounded-md border border-brass-200 bg-brass-50 px-4 py-2.5 text-sm text-navy-900">Agents work with <strong>your</strong> access to this matter and propose changes for you to approve. Nothing is applied, sent or shared automatically.</p>
      )}
      <Card title="Run an agent on this matter" description="Each run is recorded with its sources, cost and every human decision."
        actions={<Link to={`/matters/${matter.id}?tab=chronology`}><Button variant="secondary" size="sm"><GitBranch className="h-3.5 w-3.5" aria-hidden />Open chronology</Button></Link>}>
        <div className="flex flex-wrap gap-2">
          {(cat.data?.agents ?? []).filter((a) => a.requires_matter).map((a) => {
            const Icon = AGENT_ICON[a.key]
            return <Button key={a.key} variant="secondary" disabled={!allowed} title={!allowed ? 'AI retrieval is not permitted for this matter' : undefined} onClick={() => setAgent(a)}>{Icon && <Icon className="h-4 w-4 text-brass-600" aria-hidden />}{a.name}</Button>
          })}
        </div>
      </Card>
      <section aria-label="Recent runs">
        <div className="mb-2 flex items-center justify-between"><h3 className="font-serif text-lg text-navy-900">Recent runs on this matter</h3><Link to={`/ai/runs?matter=${matter.id}`} className="text-sm underline">All runs</Link></div>
        <DataTable caption="Recent AI runs on this matter" columns={cols} rows={runs.data?.items ?? []} rowKey={(r) => r.id} loading={runs.isPending} error={runs.error} onRetry={() => void runs.refetch()}
          emptyTitle="No runs yet" emptyDescription="Run the matter briefing for a cited summary, or the document review for parties, dates and obligations." />
      </section>
      <StartRunDialog agent={agent} open={!!agent} onClose={() => setAgent(null)} matterId={matter.id} lockMatter />
    </div>
  )
}
