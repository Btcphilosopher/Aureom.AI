import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Ban, CheckCircle2, FilePen, FileX2, Send, ShieldCheck, XCircle } from 'lucide-react'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, Checkbox, ConfirmDialog, DataTable, DateTime, Dialog, Field, Input, KeyValue, Money, PageHeader, QueryBoundary, StatusBadge, Textarea, type Column } from '@/components/ui'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle } from '@/hooks'
import { formatDate } from '@/lib/format'
import { hash8, isMoneyInput, MatterLink, Notice } from './shared'
import type { ApprovalRow, Invoice, InvoiceLine, Journal, Page } from '@/types/finance'

function CreditNoteDialog({ inv, open, onClose }: { inv: Invoice; open: boolean; onClose: () => void }) {
  const [full, setFull] = useState(true)
  const [desc, setDesc] = useState('')
  const [amt, setAmt] = useState('')
  const [narr, setNarr] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const navigate = useNavigate()
  const create = useApiMutation(() => api.post<Invoice>(`/billing/invoices/${inv.id}/credit-note`, { full, lines: full ? [] : [{ description: desc, amount: amt.trim(), vat_rate: null }], narrative: narr || null }),
    { invalidate: [['billing']], successMessage: 'Draft credit note created', errorToast: false, onSuccess: (c) => { onClose(); navigate(`/billing/invoices/${c.id}`) }, onError: setErr })
  const valid = full || (desc.trim() && isMoneyInput(amt))
  return (
    <Dialog open={open} onClose={onClose} title="Create credit note" description={`Credits invoice ${inv.number}. The credit cannot exceed the outstanding balance of ${inv.outstanding} ${inv.currency}.`}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!valid} loading={create.isPending} onClick={() => create.mutate()}>Create draft credit note</Button></>}>
      <div className="space-y-4">
        <Checkbox label="Credit the whole outstanding balance" checked={full} onChange={(e) => setFull(e.target.checked)} />
        {!full && <div className="grid grid-cols-[1fr_9rem] gap-3"><Field label="Line description" required><Input value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
          <Field label="Net amount (GBP)" required error={amt && !isMoneyInput(amt) ? 'Invalid' : undefined}><Input inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value)} /></Field></div>}
        <Field label="Narrative (optional)"><Textarea rows={2} value={narr} onChange={(e) => setNarr(e.target.value)} /></Field>
        <p className="text-xs text-stone-600">A credit note follows the same controls as an invoice: submit, approval by a different partner, then issue by finance.</p>
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
      </div>
    </Dialog>
  )
}

function AdjustmentDialog({ inv, open, onClose }: { inv: Invoice; open: boolean; onClose: () => void }) {
  const [desc, setDesc] = useState(''); const [amt, setAmt] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const add = useApiMutation(() => api.patch(`/billing/invoices/${inv.id}`, { expected_version: inv.version, add_adjustments: [{ description: desc, amount: amt.trim(), vat_rate: null }] }),
    { invalidate: [['billing']], successMessage: 'Line added', errorToast: false, onSuccess: () => { setDesc(''); setAmt(''); onClose() }, onError: setErr })
  return (
    <Dialog open={open} onClose={onClose} title="Add an adjustment line" description="Editing a draft after submission withdraws any approval — approval is bound to the exact content."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!desc.trim() || !/^-?\d+(\.\d{1,2})?$/.test(amt)} loading={add.isPending} onClick={() => add.mutate()}>Add line</Button></>}>
      <div className="grid grid-cols-[1fr_9rem] gap-3"><Field label="Description" required><Input value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
        <Field label="Net amount" hint="Negative for a discount"><Input inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value)} /></Field></div>
      {err && <p role="alert" className="mt-3 rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.isConflict ? 'The invoice changed — reload and try again.' : err.message}</p>}
    </Dialog>
  )
}

export default function InvoiceDetail() {
  const { id } = useParams()
  const { can, me } = useAuth()
  const q = useApiQuery<Invoice>(['billing', 'invoice', id], `/billing/invoices/${id}`)
  const inv = q.data
  const ap = useApiQuery<ApprovalRow>(['approvals', inv?.approval_id], `/approvals/${inv?.approval_id}`, { enabled: !!inv?.approval_id, retry: false })
  const journals = useApiQuery<Page<Journal>>(['ledger', 'journals', 'matter', inv?.matter_id], `/ledger/journals${qs({ matter_id: inv?.matter_id, limit: 50 })}`, { enabled: !!inv && can('ledger.read'), retry: false })
  usePageTitle(inv?.number ? `Invoice ${inv.number}` : 'Invoice')
  useBreadcrumbs([{ label: 'Time & Billing', to: '/billing' }, { label: 'Invoices', to: '/billing?tab=invoices' }, { label: inv?.number ?? (inv?.kind === 'credit_note' ? 'Draft credit note' : 'Draft invoice') }])
  const [credit, setCredit] = useState(false)
  const [adjust, setAdjust] = useState(false)
  const [voiding, setVoiding] = useState(false)
  const [rejecting, setRejecting] = useState(false)
  const [note, setNote] = useState('')
  const [dueEdit, setDueEdit] = useState('')
  const [actionErr, setActionErr] = useState<ApiError | null>(null)
  const inv_ = ['billing']
  const common = { invalidate: [inv_, ['approvals'], ['ledger'], ['reports']], errorToast: false as const, onError: (e: ApiError) => setActionErr(e) }
  const submit = useApiMutation(() => api.post(`/billing/invoices/${id}/submit`), { ...common, successMessage: 'Submitted for partner approval', onSuccess: () => setActionErr(null) })
  const decide = useApiMutation((v: { approve: boolean; note?: string }) => api.post(`/billing/invoices/${id}/decision`, v), { ...common, successMessage: (_d) => 'Decision recorded', onSuccess: () => { setActionErr(null); setRejecting(false); setNote('') } })
  const issue = useApiMutation(() => api.post(`/billing/invoices/${id}/issue`), { ...common, successMessage: 'Issued — a receivable has been recorded (not revenue)', onSuccess: () => setActionErr(null) })
  const voidIt = useApiMutation((reason: string) => api.post(`/billing/invoices/${id}/void`, { reason }), { ...common, successMessage: 'Draft voided', onSuccess: () => { setActionErr(null); setVoiding(false) } })
  const patch = useApiMutation((body: Record<string, unknown>) => api.patch(`/billing/invoices/${id}`, { expected_version: inv!.version, ...body }), { ...common, successMessage: 'Draft updated', onSuccess: () => setActionErr(null) })

  const lineCols: Column<InvoiceLine>[] = [
    { key: 'type', header: 'Type', cell: (l) => <Badge>{l.line_type}</Badge> },
    { key: 'desc', header: 'Description', cell: (l) => <span className="whitespace-pre-line">{l.description}</span> },
    { key: 'qty', header: 'Qty', numeric: true, hideOnNarrow: true, cell: (l) => l.quantity },
    { key: 'unit', header: 'Unit', numeric: true, hideOnNarrow: true, cell: (l) => <Money value={l.unit_amount} currency={inv?.currency} /> },
    { key: 'net', header: 'Net', numeric: true, cell: (l) => <Money value={l.amount} currency={inv?.currency} /> },
    { key: 'vat', header: 'VAT', numeric: true, cell: (l) => <span title={`${l.vat_rate}%`}><Money value={l.vat_amount} currency={inv?.currency} /> <span className="text-2xs text-stone-500">({l.vat_rate.replace(/\.00$/, '')}%)</span></span> },
    ...(inv?.status === 'draft' && can('billing.write') ? [{ key: 'rm', header: <span className="sr-only">Remove</span>, align: 'right' as const, cell: (l: InvoiceLine) => <Button size="sm" variant="ghost" onClick={() => patch.mutate({ remove_line_ids: [l.id] })}>Remove</Button> }] : []),
  ]

  return (
    <QueryBoundary query={q} what="invoice">
      {(i) => {
        const iAmRequester = ap.data?.requested_by === me?.user.id
        const isCredit = i.kind === 'credit_note'
        const issuedStates = ['issued', 'partially_paid', 'paid']
        const rel = (journals.data?.items ?? []).filter((j) => ['invoice_issue', 'allocation', 'revenue_recognition', 'client_transfer'].includes(j.source_type ?? ''))
        return (
          <>
            <PageHeader eyebrow={isCredit ? 'Credit note' : 'Invoice'} title={i.number ?? (isCredit ? 'Draft credit note' : 'Draft invoice')}
              description={<>Matter <MatterLink id={i.matter_id} reference={i.matter_reference} />{i.credit_for_invoice_id && <> · credits <Link className="text-navy-700 underline" to={`/billing/invoices/${i.credit_for_invoice_id}`}>original invoice</Link></>}</>}
              meta={<><StatusBadge status={i.status} />{i.status === 'pending_approval' && i.approval_status && <Badge tone={i.approval_status === 'approved' ? 'success' : 'warning'}>Approval: {i.approval_status}</Badge>}<Badge>{i.currency}</Badge></>}
              actions={<>
                {i.status === 'draft' && can('billing.write') && <>
                  <Button variant="secondary" icon={<FilePen className="h-4 w-4" />} onClick={() => setAdjust(true)}>Add line</Button>
                  <Button variant="secondary" icon={<Ban className="h-4 w-4" />} onClick={() => setVoiding(true)}>Void draft</Button>
                  <Button icon={<Send className="h-4 w-4" />} loading={submit.isPending} onClick={() => submit.mutate()}>Submit for approval</Button></>}
                {i.status === 'pending_approval' && i.approval_status === 'pending' && can('billing.approve') && <>
                  <Button variant="secondary" icon={<XCircle className="h-4 w-4" />} onClick={() => setRejecting(true)}>Reject</Button>
                  <Button icon={<CheckCircle2 className="h-4 w-4" />} loading={decide.isPending} onClick={() => decide.mutate({ approve: true })}>Approve this exact invoice</Button></>}
                {i.status === 'pending_approval' && i.approval_status === 'approved' && can('billing.issue') && <Button icon={<ShieldCheck className="h-4 w-4" />} loading={issue.isPending} onClick={() => issue.mutate()}>Issue {isCredit ? 'credit note' : 'invoice'}</Button>}
                {issuedStates.includes(i.status) && !isCredit && can('billing.write') && <Button variant="secondary" icon={<FileX2 className="h-4 w-4" />} onClick={() => setCredit(true)}>Create credit note</Button>}
              </>} />
            {actionErr && <p role="alert" className="mb-4 rounded-md border border-bad-100 bg-bad-50 px-4 py-3 text-sm text-bad-700"><strong>{actionErr.code === 'four_eyes_required' ? 'Four-eyes control: ' : ''}</strong>{actionErr.message}</p>}
            <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
              <div className="space-y-6">
                <Card title="Lines" padded={false}><DataTable caption="Invoice lines" columns={lineCols} rows={i.lines} rowKey={(l) => l.id} className="rounded-none border-0 shadow-none" emptyTitle="No lines yet" /></Card>
                {i.narrative && <Card title="Narrative"><p className="whitespace-pre-line text-sm">{i.narrative}</p></Card>}
                {i.status === 'draft' && can('billing.write') && (
                  <Card title="Draft details"><div className="flex flex-wrap items-end gap-3"><Field label="Due date"><Input type="date" value={dueEdit || i.due_date || ''} onChange={(e) => setDueEdit(e.target.value)} /></Field>
                    <Button variant="secondary" disabled={!dueEdit} loading={patch.isPending} onClick={() => patch.mutate({ due_date: dueEdit })}>Save due date</Button></div></Card>)}
                <Card title="Related ledger entries" description="Journals on this matter from invoice issue, allocation and revenue recognition" padded={false}>
                  {!can('ledger.read') ? <p className="px-5 py-4 text-sm text-stone-600">Ledger entries are visible to roles with ledger access.</p>
                    : journals.isPending ? <p className="px-5 py-4 text-sm text-stone-600">Loading…</p>
                    : rel.length === 0 ? <p className="px-5 py-4 text-sm text-stone-600">No related journals yet.</p>
                    : <ul className="divide-y divide-stone-100">{rel.map((j) => <li key={j.id} className="flex items-center justify-between gap-3 px-5 py-2.5 text-sm"><Link className="font-medium text-navy-700 underline-offset-2 hover:underline" to={`/ledger/journals/${j.id}`}>{j.reference}</Link><span className="text-stone-600">{j.description}</span><span className="flex items-center gap-2"><Badge>{j.ledger}</Badge><StatusBadge status={j.status} /><Money value={j.total} /></span></li>)}</ul>}
                </Card>
              </div>
              <aside className="space-y-4">
                <Card title="Totals">
                  <dl className="space-y-2 text-sm">
                    <div className="flex justify-between"><dt>Net</dt><dd><Money value={i.subtotal} currency={i.currency} /></dd></div>
                    <div className="flex justify-between"><dt>VAT</dt><dd><Money value={i.vat_amount} currency={i.currency} /></dd></div>
                    <div className="flex justify-between border-t border-stone-200 pt-2 font-semibold"><dt>Total</dt><dd><Money value={i.total} currency={i.currency} /></dd></div>
                    {issuedStates.includes(i.status) && !isCredit && <>
                      <div className="flex justify-between text-stone-700"><dt>Allocated payments</dt><dd><Money value={i.amount_paid} currency={i.currency} /></dd></div>
                      <div className="flex justify-between font-semibold"><dt>Outstanding</dt><dd><Money value={i.outstanding} currency={i.currency} /></dd></div></>}
                  </dl>
                </Card>
                <Card title="Details"><KeyValue columns={1} items={[
                  { label: 'Issued', value: <DateTime value={i.issued_at} mode="date" /> }, { label: 'Due', value: i.due_date ? formatDate(i.due_date) : '—' },
                  { label: 'Payer', value: i.payer_id ? 'Third-party payer set' : 'Client' }]} /></Card>
                {i.approval_id && (
                  <Card title="Approval record">
                    {ap.isPending ? <p className="text-sm text-stone-600">Loading…</p> : ap.data ? (
                      <KeyValue items={[
                        { label: 'Status', value: <StatusBadge status={ap.data.status} /> }, { label: 'Requested by', value: ap.data.requested_by_name },
                        { label: 'Decided by', value: ap.data.decided_by_name ?? '—' }, { label: 'Bound content hash', value: <code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-2xs">{hash8(ap.data.payload_hash)}…</code> }]} />
                    ) : <p className="text-sm text-stone-600">Approval status: {i.approval_status ?? '—'}</p>}
                    <p className="mt-3 text-xs text-stone-600">Approval is bound to the exact lines, amounts and recipient. Any later change withdraws it and a fresh approval is required.</p>
                    {i.status === 'pending_approval' && i.approval_status === 'pending' && iAmRequester && <p className="mt-2 rounded bg-warn-50 px-2.5 py-2 text-xs text-warn-700">You submitted this invoice. Four-eyes control: a different person with approval rights must approve it.</p>}
                  </Card>)}
                <Notice tone="brass" title="What “issue” means">Issuing assigns the number, locks the time and expenses as billed, and records a <strong>receivable</strong> in the office ledger. It does <strong>not</strong> recognise revenue and is <strong>not</strong> cash received. Those are separate, separately authorised steps in the <Link className="underline" to="/ledger">Client Ledger</Link>.</Notice>
                {isCredit && <Notice>A credit note reduces the amount the client owes; it does not return cash.</Notice>}
              </aside>
            </div>
            {credit && <CreditNoteDialog inv={i} open onClose={() => setCredit(false)} />}
            {adjust && <AdjustmentDialog inv={i} open onClose={() => setAdjust(false)} />}
            <ConfirmDialog open={voiding} onClose={() => setVoiding(false)} title="Void this draft" description="Time and expenses on the draft are released back to WIP." requireReason="Reason" confirmLabel="Void draft" tone="danger" onConfirm={(r) => { if (r) voidIt.mutate(r) }} />
            <Dialog open={rejecting} onClose={() => setRejecting(false)} title="Reject invoice" description="The invoice returns to draft with your note."
              footer={<><Button variant="secondary" onClick={() => setRejecting(false)}>Cancel</Button><Button variant="danger" loading={decide.isPending} disabled={note.trim().length < 3} onClick={() => decide.mutate({ approve: false, note })}>Reject</Button></>}>
              <Field label="Note to the fee earner" required><Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
            </Dialog>
          </>)
      }}
    </QueryBoundary>
  )
}
