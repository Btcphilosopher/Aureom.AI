import { useEffect, useState } from 'react'
import { ApiError, api, useApiMutation } from '@/lib/api'
import { Button, Checkbox, Dialog, Field, Input, Money, Textarea } from '@/components/ui'
import { formatHoursMinutes } from '@/lib/format'
import { isMoneyInput, MatterSelect, todayIso } from './shared'
import type { TimeEntry } from '@/types/finance'
import { useAuth } from '@/lib/auth'

/** Create or edit a time entry. Editing sends expected_version; a 409 asks the user to reload. */
export function TimeEntryDialog({ open, onClose, entry, defaultMatterId }: { open: boolean; onClose: () => void; entry?: TimeEntry | null; defaultMatterId?: string }) {
  const { can } = useAuth()
  const [matter, setMatter] = useState(defaultMatterId ?? '')
  const [date, setDate] = useState(todayIso())
  const [hours, setHours] = useState('0')
  const [mins, setMins] = useState('6')
  const [narrative, setNarrative] = useState('')
  const [billable, setBillable] = useState(true)
  const [rate, setRate] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)
  const editing = !!entry
  const locked = !!entry && !['draft', 'submitted'].includes(entry.status)

  useEffect(() => {
    if (!open) return
    setErr(null)
    if (entry) {
      setMatter(entry.matter_id); setDate(entry.work_date); setHours(String(Math.floor(entry.minutes / 60))); setMins(String(entry.minutes % 60))
      setNarrative(entry.narrative); setBillable(entry.billable); setRate('')
    } else { setMatter(defaultMatterId ?? ''); setDate(todayIso()); setHours('0'); setMins('6'); setNarrative(''); setBillable(true); setRate('') }
  }, [open, entry, defaultMatterId])

  const total = (parseInt(hours || '0', 10) || 0) * 60 + (parseInt(mins || '0', 10) || 0)
  const save = useApiMutation(
    () => {
      const body: Record<string, unknown> = { work_date: date, minutes: total, narrative, billable }
      if (rate.trim()) body.rate = rate.trim()
      return entry
        ? api.patch<TimeEntry>(`/time/entries/${entry.id}`, { ...body, expected_version: entry.version })
        : api.post<TimeEntry>('/time/entries', { ...body, matter_id: matter })
    },
    { invalidate: [['time'], ['billing']], successMessage: (e) => `Time saved — ${formatHoursMinutes(e.minutes)}`, errorToast: false, onSuccess: () => onClose(), onError: (e) => setErr(e) },
  )
  const valid = !!matter && total > 0 && total <= 1440 && narrative.trim().length > 0 && (!rate.trim() || isMoneyInput(rate))

  return (
    <Dialog open={open} onClose={onClose} title={editing ? 'Edit time entry' : 'Record time'} size="md"
      description="Describe only work that was actually done. Time is billed at the rate on the matter's rate card."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!valid || locked} loading={save.isPending} onClick={() => save.mutate()}>{editing ? 'Save changes' : 'Save time entry'}</Button></>}>
      <div className="space-y-4">
        {locked && <p role="alert" className="rounded-md bg-warn-50 px-3 py-2 text-sm text-warn-700">This entry is {entry!.status.replace('_', ' ')} and can no longer be edited.</p>}
        <Field label="Matter" required>{(p) => <MatterSelect {...p} value={matter} onChange={setMatter} disabled={editing} extra={entry ? [{ id: entry.matter_id, reference: entry.matter_reference ?? 'Matter', title: '', status: 'open' }] : undefined} />}</Field>
        <div className="grid grid-cols-3 gap-3">
          <Field label="Date" required><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} max={todayIso()} /></Field>
          <Field label="Hours"><Input inputMode="numeric" value={hours} onChange={(e) => setHours(e.target.value.replace(/\D/g, ''))} /></Field>
          <Field label="Minutes" hint="6-minute units are typical"><Input inputMode="numeric" value={mins} onChange={(e) => setMins(e.target.value.replace(/\D/g, ''))} /></Field>
        </div>
        <p className="text-xs text-stone-600" aria-live="polite">Duration: <strong className="tabular-nums text-navy-900">{formatHoursMinutes(total)}</strong> ({total} minutes)</p>
        <Field label="Narrative" required hint="What was done, for whom, and why — as it would read on a bill."><Textarea rows={3} value={narrative} onChange={(e) => setNarrative(e.target.value)} /></Field>
        <Checkbox label="Billable" checked={billable} onChange={(e) => setBillable(e.target.checked)} />
        {can('billing.write') && <Field label="Override hourly rate (GBP)" hint="Optional. Leave blank to use the rate card." error={rate && !isMoneyInput(rate) ? 'Enter an amount like 210.00' : undefined}><Input inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} /></Field>}
        {entry && <p className="text-xs text-stone-600">Current value: <Money value={entry.amount} currency={entry.currency} /> at <Money value={entry.rate} currency={entry.currency} />/h (calculated by the server).</p>}
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.isConflict ? 'This entry was changed by someone else. Close this dialog and reopen it to see the latest version.' : err.message}</p>}
      </div>
    </Dialog>
  )
}
