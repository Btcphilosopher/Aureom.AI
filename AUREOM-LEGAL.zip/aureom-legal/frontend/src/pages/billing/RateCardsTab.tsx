import { useState } from 'react'
import { Pencil, Plus } from 'lucide-react'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, Checkbox, Dialog, EmptyState, Field, Input, Money, QueryBoundary } from '@/components/ui'
import { isMoneyInput, Notice } from './shared'
import type { RateCard, RateEntry } from '@/types/finance'

function RateDialog({ card, open, onClose }: { card: RateCard | null; open: boolean; onClose: () => void }) {
  const [name, setName] = useState('')
  const [isDefault, setDefault] = useState(false)
  const [entries, setEntries] = useState<RateEntry[]>([])
  const [err, setErr] = useState<ApiError | null>(null)
  const [seed, setSeed] = useState<string | null>(null)
  const key = open ? (card?.id ?? 'new') : null
  if (key !== seed) { setSeed(key); if (open) { setName(card?.name ?? ''); setDefault(card?.is_default ?? false); setEntries(card?.entries.map((e) => ({ grade: e.grade, hourly_rate: e.hourly_rate })) ?? [{ grade: 'partner', hourly_rate: '' }, { grade: 'solicitor', hourly_rate: '' }, { grade: 'paralegal', hourly_rate: '' }]); setErr(null) } }
  const save = useApiMutation(async () => {
    const body = entries.filter((e) => e.grade.trim()).map((e) => ({ grade: e.grade.trim(), hourly_rate: e.hourly_rate.trim() }))
    if (card) return api.put(`/billing/rate-cards/${card.id}/entries`, body)
    return api.post('/billing/rate-cards', { name, currency: 'GBP', is_default: isDefault, entries: body })
  }, { invalidate: [['billing', 'rate-cards']], successMessage: 'Rate card saved', errorToast: false, onSuccess: onClose, onError: setErr })
  const valid = (card || name.trim()) && entries.length > 0 && entries.every((e) => isMoneyInput(e.hourly_rate))
  return (
    <Dialog open={open} onClose={onClose} title={card ? `Edit rates — ${card.name}` : 'New rate card'} size="md"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!valid} loading={save.isPending} onClick={() => save.mutate()}>Save</Button></>}>
      <div className="space-y-4">
        {!card && <><Field label="Name" required><Input value={name} onChange={(e) => setName(e.target.value)} /></Field><Checkbox label="Make this the default rate card" checked={isDefault} onChange={(e) => setDefault(e.target.checked)} /></>}
        <fieldset className="space-y-2"><legend className="text-xs font-semibold uppercase tracking-wide text-stone-700">Hourly rates by grade (GBP)</legend>
          {entries.map((e, i) => (
            <div key={i} className="grid grid-cols-2 gap-3">
              <Field label={i === 0 ? 'Grade' : ' '}><Input aria-label="Grade" value={e.grade} onChange={(ev) => setEntries(entries.map((x, j) => (j === i ? { ...x, grade: ev.target.value } : x)))} /></Field>
              <Field label={i === 0 ? 'Hourly rate' : ' '} error={e.hourly_rate && !isMoneyInput(e.hourly_rate) ? 'Invalid' : undefined}><Input aria-label="Hourly rate" inputMode="decimal" value={e.hourly_rate} onChange={(ev) => setEntries(entries.map((x, j) => (j === i ? { ...x, hourly_rate: ev.target.value } : x)))} /></Field>
            </div>))}
          <Button variant="ghost" size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setEntries([...entries, { grade: '', hourly_rate: '' }])}>Add grade</Button>
        </fieldset>
        <p className="text-xs text-stone-600">Rate changes apply to time recorded afterwards; billed time keeps its recorded rate.</p>
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
      </div>
    </Dialog>
  )
}

export function RateCardsTab() {
  const { can } = useAuth()
  const q = useApiQuery<RateCard[]>(['billing', 'rate-cards'], '/billing/rate-cards')
  const [editing, setEditing] = useState<RateCard | null>(null)
  const [creating, setCreating] = useState(false)
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between"><p className="text-sm text-stone-600">Rates used to value recorded time. Fixed-fee and capped matters are managed on the matter's fee arrangement.</p>
        {can('billing.write') && <Button icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(true)}>New rate card</Button>}</div>
      <QueryBoundary query={q} empty={<EmptyState title="No rate cards" description="Create a rate card to value recorded time." />}>
        {(cards) => <div className="grid gap-4 lg:grid-cols-2">{cards.map((c) => (
          <Card key={c.id} title={<span className="flex items-center gap-2">{c.name}{c.is_default && <Badge tone="brass">Default</Badge>}{!c.is_active && <Badge>Inactive</Badge>}</span>} description={`Currency ${c.currency}`}
            actions={can('billing.write') ? <Button size="sm" variant="secondary" icon={<Pencil className="h-3.5 w-3.5" />} onClick={() => setEditing(c)}>Edit rates</Button> : undefined} padded={false}>
            <table className="w-full text-sm"><caption className="sr-only">Hourly rates for {c.name}</caption>
              <thead><tr className="border-b border-stone-200 text-xs uppercase tracking-wide text-stone-600"><th scope="col" className="px-5 py-2 text-left font-semibold">Grade</th><th scope="col" className="px-5 py-2 text-right font-semibold">Hourly rate</th></tr></thead>
              <tbody>{c.entries.map((e) => <tr key={e.id ?? e.grade} className="border-b border-stone-100 last:border-0"><td className="px-5 py-2.5 capitalize">{e.grade}{e.user_id && <Badge className="ml-2">Named override</Badge>}</td><td className="px-5 py-2.5 text-right"><Money value={e.hourly_rate} currency={c.currency} /></td></tr>)}</tbody>
            </table>
          </Card>))}</div>}
      </QueryBoundary>
      <Notice>Rate cards are demonstration values. Real rates, grade definitions and approval of rate changes are for the firm to set.</Notice>
      <RateDialog card={editing} open={!!editing || creating} onClose={() => { setEditing(null); setCreating(false) }} />
    </div>
  )
}
