import { useEffect } from 'react'
import { usePageTitle, useNewParam, useQueryParams } from '@/hooks'
import { useAuth } from '@/lib/auth'
import { PageHeader, PermissionDenied, TabPanel, Tabs } from '@/components/ui'
import { ExpensesTab } from './ExpensesTab'
import { InvoicesTab } from './InvoicesTab'
import { RateCardsTab } from './RateCardsTab'
import { TimeTab } from './TimeTab'
import { TimerWidget } from './TimerWidget'
import { WipTab } from './WipTab'

const PARAMS = ['tab', 'status'] as const

export default function BillingHome() {
  usePageTitle('Time & Billing')
  const { can } = useAuth()
  const [p, setP] = useQueryParams(PARAMS)
  const newP = useNewParam()
  const canTime = can('time.write'), canInv = can('billing.read'), canWip = can('reports.read') && can('billing.read')
  const tabs = [
    { id: 'time', label: 'My time', disabled: !canTime },
    { id: 'expenses', label: 'Expenses', disabled: !canTime },
    { id: 'wip', label: 'WIP', disabled: !canWip },
    { id: 'invoices', label: 'Invoices & credit notes', disabled: !canInv },
    { id: 'rates', label: 'Rate cards', disabled: !(canInv || canTime) },
  ]
  const first = tabs.find((t) => !t.disabled)?.id
  const requested = p.tab === 'unbilled' ? 'wip' : p.tab
  const tab = tabs.find((t) => t.id === requested && !t.disabled)?.id ?? first

  // quick-create (?new=time) always lands on the time tab
  useEffect(() => { if (newP.kind === 'time' && canTime && p.tab !== 'time') setP({ tab: 'time' }) }, [newP.kind]) // eslint-disable-line react-hooks/exhaustive-deps

  if (!first) return <><PageHeader title="Time & Billing" /><PermissionDenied permission={['time.write', 'billing.read']} /></>
  return (
    <>
      <PageHeader eyebrow="Practice finance" title="Time & Billing" description="Record time and expenses, review unbilled work, prepare draft bills and credit notes. Bills are approved by a partner and issued by finance." />
      {canTime && <TimerWidget />}
      <Tabs label="Time and billing" tabs={tabs} value={tab!} onChange={(id) => setP({ tab: id })} />
      <TabPanel id="time" value={tab!}><TimeTab openNew={newP.kind === 'time'} onNewHandled={newP.clear} /></TabPanel>
      <TabPanel id="expenses" value={tab!}><ExpensesTab /></TabPanel>
      <TabPanel id="wip" value={tab!}><WipTab /></TabPanel>
      <TabPanel id="invoices" value={tab!}><InvoicesTab status={p.status ?? ''} onStatus={(s) => setP({ status: s || null })} /></TabPanel>
      <TabPanel id="rates" value={tab!}><RateCardsTab /></TabPanel>
    </>
  )
}
