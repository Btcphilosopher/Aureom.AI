import { Route, Routes } from 'react-router-dom'
import { NotFoundState } from '@/components/ui/States'
import BillingHome from './BillingHome'
import InvoiceDetail from './InvoiceDetail'

export { MatterBillingPanel } from './MatterBillingPanel'

/** Time & Billing section. Owns all nested routes under /billing. */
export default function BillingSection() {
  return (
    <Routes>
      <Route index element={<BillingHome />} />
      <Route path="invoices/:id" element={<InvoiceDetail />} />
      <Route path="*" element={<NotFoundState what="page" />} />
    </Routes>
  )
}
