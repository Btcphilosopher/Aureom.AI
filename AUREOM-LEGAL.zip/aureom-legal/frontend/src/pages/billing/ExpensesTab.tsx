import { useState } from 'react'
import { Eraser, Plus, ThumbsUp } from 'lucide-react'
import { ApiError, api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Checkbox, ConfirmDialog, DataTable, DateTime, Dialog, Field, IconButton, Input, Money, Select, StatusBadge, type Column } from '@/components/ui'
import { isMoneyInput, MatterLink, MatterSelect, Notice, todayIso, useOpenMatters } from './shared'
import type { Expense, Page } from '@/types/finance'

function ExpenseDialog({ open, onClose, defaultMatterId }: { open: boolean; onClose: () => void; defaultMatterId?: string }) {
  const [matter, setMatter] = useState(defaultMatterId ?? '')
  const [date, setDate] = useState(todayIso())
  const [desc, setDesc] = useState('')
  const [amount, setAmount] = useState('')
  const [vat, setVat] = useState('0')
  const [billable, setBillable] = useState(true)
  const [err, setErr] = useState<ApiError | null>(null)
  const save = useApiMutation(() => api.post<Expense>('/time/expenses', { matter_id: matter, expense_date: date, description: desc, amount: amount.trim(), vat_rate: vat, billable }),
    { invalidate: [['time'], ['billing']], successMessage: 'Expense recorded', errorToast: false, onSuccess: () => { setDesc(''); setAmount(''); onClose() }, onError: setErr })
  const valid = !!matter && desc.trim().length > 0 && isMoneyInput(amount)
  return (
    <Dialog open={open} onClose={onClose} title="Record an expense" description="Amounts are net of VAT; the VAT rate is applied when the expense is billed."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!valid} loading={save.isPending} onClick={() => save.mutate()}>Save expense</Button></>}>
      <div className="space-y-4">
        <Field label="Matter" required>{(p) => <MatterSelect {...p} value={matter} onChange={setMatter} />}</Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date" required><Input type="date" value={date} max={todayIso()} onChange={(e) => setDate(e.target.value)} /></Field>
          <Field label="Net amount (GBP)" required error={amount && !isMoneyInput(amount) ? 'Enter an amount like 42.50' : undefined}><Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
        </div>
        <Field label="Description" required><Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="e.g. Land Registry official copies" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="VAT rate"><Select value={vat} onChange={(e) => setVat(e.target.value)}><option value="0">0% (outside scope / exempt)</option><option value="20">20% standard</option></Select></Field>
          <div className="flex items-end pb-1"><Checkbox label="Recharge to client" checked={billable} onChange={(e) => setBillable(e.target.checked)} /></div>
        </div>
        {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
      </div>
    </Dialog>
  )
}

export function ExpensesTab() {
  const { can } = useAuth()
  const [offset, setOffset] = useState(0)
  const [status, setStatus] = useState('')
  const [open, setOpen] = useState(false)
  const [wo, setWo] = useState<Expense | null>(null)
  const matters = useOpenMatters()
  const refs = new Map((matters.data?.items ?? []).map((m) => [m.id, m.reference]))
  const q = useApiQuery<Page<Expense>>(['time', 'expenses', status, offset], `/time/expenses${qs({ status: status || undefined, limit: 25, offset })}`)
  const approve = useApiMutation((e: Expense) => api.post(`/time/expenses/${e.id}/approve`), { invalidate: [['time']], successMessage: 'Expense approved' })
  const writeOff = useApiMutation((v: { e: Expense; reason: string }) => api.post(`/time/expenses/${v.e.id}/write-off`, { reason: v.reason }), { invalidate: [['time']], successMessage: 'Expense written off' })
  const cols: Column<Expense>[] = [
    { key: 'date', header: 'Date', className: 'whitespace-nowrap', cell: (e) => <DateTime value={e.expense_date} mode="date" /> },
    { key: 'matter', header: 'Matter', cell: (e) => <MatterLink id={e.matter_id} reference={refs.get(e.matter_id)} /> },
    { key: 'desc', header: 'Description', cell: (e) => e.description },
    { key: 'net', header: 'Net', numeric: true, cell: (e) => <Money value={e.amount} currency={e.currency} /> },
    { key: 'vat', header: 'VAT rate', numeric: true, hideOnNarrow: true, cell: (e) => `${e.vat_rate.replace(/\.00$/, '')}%` },
    { key: 'status', header: 'Status', cell: (e) => <div className="flex gap-1"><StatusBadge status={e.status} />{!e.billable && <Badge>Not recharged</Badge>}</div> },
    { key: 'act', header: <span className="sr-only">Actions</span>, align: 'right', cell: (e) => (
      <div className="flex justify-end gap-1">
        {e.status === 'draft' && can('billing.write') && <IconButton aria-label="Approve expense" size="sm" onClick={() => approve.mutate(e)}><ThumbsUp className="h-4 w-4" /></IconButton>}
        {['draft', 'approved'].includes(e.status) && can('billing.write') && <IconButton aria-label="Write off expense" size="sm" onClick={() => setWo(e)}><Eraser className="h-4 w-4" /></IconButton>}
      </div>) },
  ]
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <Select aria-label="Status" value={status} onChange={(e) => { setStatus(e.target.value); setOffset(0) }} className="w-48"><option value="">All statuses</option>{['draft', 'approved', 'billed', 'written_off'].map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</Select>
        <Button icon={<Plus className="h-4 w-4" />} onClick={() => setOpen(true)}>Record expense</Button>
      </div>
      <DataTable caption="Expenses" columns={cols} rows={q.data?.items} rowKey={(e) => e.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()}
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} emptyTitle="No expenses" />
      <Notice>Expenses are recharged to the client when they appear on an issued invoice. In this demonstration, recharges are booked to “fees billed – not yet recognised”, which is a simplification for the accountants to replace.</Notice>
      <ExpenseDialog open={open} onClose={() => setOpen(false)} />
      <ConfirmDialog open={!!wo} onClose={() => setWo(null)} title="Write off expense" requireReason="Reason for write-off" confirmLabel="Write off" tone="danger"
        onConfirm={async (reason) => { if (wo && reason) { await writeOff.mutateAsync({ e: wo, reason }); setWo(null) } }} />
    </div>
  )
}
