import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { Badge, Button, Checkbox, Drawer, Field, Input, LoadingState, Money, Textarea, ErrorState } from '@/components/ui'
import { formatDate, sumDecimal } from '@/lib/format'
import { Notice } from './shared'
import type { Invoice, Unbilled } from '@/types/finance'

interface Adj { description: string; amount: string; vat_rate: string }
const SIGNED = /^-?\d+(\.\d{1,2})?$/

/** Select unbilled time + expenses and create a DRAFT invoice. Nothing is issued here. */
export function InvoiceBuilder({ matterId, matterRef, open, onClose }: { matterId: string | null; matterRef?: string; open: boolean; onClose: () => void }) {
  const nav = useNavigate()
  const q = useApiQuery<Unbilled>(['billing', 'unbilled', matterId], `/billing/matters/${matterId}/unbilled`, { enabled: open && !!matterId })
  const [timeIds, setTimeIds] = useState<Set<string>>(new Set())
  const [expIds, setExpIds] = useState<Set<string>>(new Set())
  const [fixed, setFixed] = useState(false)
  const [fixedAmt, setFixedAmt] = useState('')
  const [adjs, setAdjs] = useState<Adj[]>([])
  const [narr, setNarr] = useState('')
  const [err, setErr] = useState<ApiError | null>(null)

  useEffect(() => {
    if (!q.data) return
    setTimeIds(new Set(q.data.time_entries.map((t) => t.id))); setExpIds(new Set(q.data.expenses.map((e) => e.id)))
    setFixed(false); setFixedAmt(q.data.fixed_fee_amount ?? ''); setAdjs([]); setNarr(''); setErr(null)
  }, [q.data])

  const net = useMemo(() => {
    if (!q.data) return '0.00'
    return sumDecimal([
      ...q.data.time_entries.filter((t) => timeIds.has(t.id)).map((t) => t.amount),
      ...q.data.expenses.filter((e) => expIds.has(e.id)).map((e) => e.amount),
      ...(fixed && SIGNED.test(fixedAmt) ? [fixedAmt] : []),
      ...adjs.filter((a) => SIGNED.test(a.amount)).map((a) => a.amount),
    ])
  }, [q.data, timeIds, expIds, fixed, fixedAmt, adjs])

  const create = useApiMutation(() => api.post<Invoice>('/billing/invoices', {
    matter_id: matterId, time_entry_ids: [...timeIds], expense_ids: [...expIds], include_fixed_fee: fixed, fixed_fee_amount: fixed ? fixedAmt : null,
    adjustments: adjs.filter((a) => a.description.trim()).map((a) => ({ description: a.description, amount: a.amount, vat_rate: a.vat_rate || null })), narrative: narr || null,
  }), { invalidate: [['billing'], ['time'], ['reports']], errorToast: false, successMessage: 'Draft invoice created', onSuccess: (inv) => { onClose(); nav(`/billing/invoices/${inv.id}`) }, onError: setErr })

  const toggle = (set: Set<string>, id: string, fn: (s: Set<string>) => void) => { const n = new Set(set); n.has(id) ? n.delete(id) : n.add(id); fn(n) }
  const nothing = timeIds.size + expIds.size === 0 && !fixed && adjs.length === 0
  const badAdj = adjs.some((a) => a.description.trim() && !SIGNED.test(a.amount))

  return (
    <Drawer open={open} onClose={onClose} title={`Prepare draft invoice${matterRef ? ` — ${matterRef}` : ''}`} width="max-w-3xl"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={nothing || badAdj} loading={create.isPending} onClick={() => create.mutate()}>Create draft invoice</Button></>}>
      {q.isPending && <LoadingState label="Loading unbilled work…" />}
      {q.isError && <ErrorState error={q.error} onRetry={() => void q.refetch()} />}
      {q.data && (
        <div className="space-y-6">
          <Notice tone="brass" title="This creates a draft only">A draft invoice is not a bill. It must be submitted, approved by a partner (a different person) and issued by finance. Issuing records a receivable — it is not revenue and not cash.</Notice>
          <section aria-labelledby="ub-time">
            <h3 id="ub-time" className="mb-2 text-sm font-semibold text-navy-900">Time entries ({q.data.time_entries.length})</h3>
            {q.data.time_entries.length === 0 ? <p className="text-sm text-stone-600">No submitted or approved billable time awaiting billing.</p> : (
              <ul className="divide-y divide-stone-100 rounded-md border border-stone-200">
                {q.data.time_entries.map((t) => (
                  <li key={t.id} className="flex items-start gap-3 px-3 py-2.5">
                    <Checkbox label={<span><span className="tabular-nums text-stone-600">{formatDate(t.work_date)}</span> · {t.user_name} · {t.narrative || 'No narrative'}</span>} checked={timeIds.has(t.id)} onChange={() => toggle(timeIds, t.id, setTimeIds)} className="flex-1" />
                    <span className="shrink-0 text-right text-sm"><span className="mr-3 tabular-nums text-stone-600">{Math.floor(t.minutes / 60)}h {t.minutes % 60}m</span><Money value={t.amount} /></span>
                  </li>))}
              </ul>)}
          </section>
          <section aria-labelledby="ub-exp">
            <h3 id="ub-exp" className="mb-2 text-sm font-semibold text-navy-900">Expenses ({q.data.expenses.length})</h3>
            {q.data.expenses.length === 0 ? <p className="text-sm text-stone-600">No recharge expenses awaiting billing.</p> : (
              <ul className="divide-y divide-stone-100 rounded-md border border-stone-200">
                {q.data.expenses.map((e) => (
                  <li key={e.id} className="flex items-start gap-3 px-3 py-2.5">
                    <Checkbox label={<span><span className="tabular-nums text-stone-600">{formatDate(e.expense_date)}</span> · {e.description} <Badge className="ml-1">VAT {e.vat_rate.replace(/\.00$/, '')}%</Badge></span>} checked={expIds.has(e.id)} onChange={() => toggle(expIds, e.id, setExpIds)} className="flex-1" />
                    <Money value={e.amount} />
                  </li>))}
              </ul>)}
          </section>
          {q.data.fee_arrangement === 'fixed' && (
            <section className="rounded-md border border-stone-200 p-3" aria-labelledby="ub-fixed">
              <h3 id="ub-fixed" className="sr-only">Fixed fee</h3>
              <Checkbox label={<span>Include the fixed fee for this matter</span>} hint="Fee arrangement: fixed fee" checked={fixed} onChange={(e) => setFixed(e.target.checked)} />
              {fixed && <Field label="Fixed-fee amount (net, GBP)" className="mt-3 max-w-xs" error={!SIGNED.test(fixedAmt) ? 'Enter an amount' : undefined}><Input inputMode="decimal" value={fixedAmt} onChange={(e) => setFixedAmt(e.target.value)} /></Field>}
            </section>)}
          <section aria-labelledby="ub-adj">
            <div className="mb-2 flex items-center justify-between"><h3 id="ub-adj" className="text-sm font-semibold text-navy-900">Adjustments</h3>
              <Button size="sm" variant="secondary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setAdjs([...adjs, { description: '', amount: '', vat_rate: '' }])}>Add adjustment</Button></div>
            {adjs.length === 0 && <p className="text-sm text-stone-600">Optional: discounts (negative amounts) or other lines.</p>}
            {adjs.map((a, i) => (
              <div key={i} className="mb-2 grid grid-cols-[1fr_8rem_6rem_auto] items-end gap-2">
                <Field label="Description"><Input value={a.description} onChange={(e) => setAdjs(adjs.map((x, j) => (j === i ? { ...x, description: e.target.value } : x)))} /></Field>
                <Field label="Net amount" error={a.amount && !SIGNED.test(a.amount) ? 'Invalid' : undefined}><Input inputMode="decimal" value={a.amount} onChange={(e) => setAdjs(adjs.map((x, j) => (j === i ? { ...x, amount: e.target.value } : x)))} placeholder="-50.00" /></Field>
                <Field label="VAT %"><Input inputMode="decimal" value={a.vat_rate} onChange={(e) => setAdjs(adjs.map((x, j) => (j === i ? { ...x, vat_rate: e.target.value } : x)))} placeholder="firm" /></Field>
                <Button variant="ghost" size="sm" aria-label="Remove adjustment" onClick={() => setAdjs(adjs.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4" /></Button>
              </div>))}
          </section>
          <Field label="Narrative (optional)"><Textarea rows={2} value={narr} onChange={(e) => setNarr(e.target.value)} /></Field>
          <div className="rounded-md bg-ivory-100 px-4 py-3 text-sm" aria-live="polite">
            <div className="flex items-center justify-between"><span>Net total of selected items</span><strong className="tabular-nums"><Money value={net} /></strong></div>
            <p className="mt-1 text-xs text-stone-600">VAT is calculated per line by the server (firm default 20% unless a line says otherwise). The invoice total is shown after the draft is created.</p>
          </div>
          {err && <p role="alert" className="rounded-md bg-bad-50 px-3 py-2 text-sm text-bad-700">{err.message}</p>}
        </div>)}
    </Drawer>
  )
}
