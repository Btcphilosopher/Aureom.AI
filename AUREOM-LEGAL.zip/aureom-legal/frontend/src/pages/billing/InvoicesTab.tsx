import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { qs, useApiQuery } from '@/lib/api'
import { Badge, DataTable, DateTime, Money, Select, StatusBadge, type Column } from '@/components/ui'
import { MatterLink, Notice } from './shared'
import type { Invoice, Page } from '@/types/finance'

export function InvoicesTab({ status, onStatus }: { status: string; onStatus: (s: string) => void }) {
  const nav = useNavigate()
  const [kind, setKind] = useState('')
  const [offset, setOffset] = useState(0)
  const q = useApiQuery<Page<Invoice>>(['billing', 'invoices', status, kind, offset], `/billing/invoices${qs({ status: status || undefined, kind: kind || undefined, limit: 25, offset })}`)
  const cols: Column<Invoice>[] = [
    { key: 'no', header: 'Number', cell: (i) => <span className="font-medium">{i.number ?? <span className="text-stone-500">Unnumbered draft</span>}</span> },
    { key: 'kind', header: 'Type', cell: (i) => i.kind === 'credit_note' ? <Badge tone="brass">Credit note</Badge> : <span>Invoice</span> },
    { key: 'matter', header: 'Matter', cell: (i) => <MatterLink id={i.matter_id} reference={i.matter_reference} /> },
    { key: 'status', header: 'Status', cell: (i) => <div className="flex flex-wrap gap-1"><StatusBadge status={i.status} />{i.status === 'pending_approval' && i.approval_status === 'approved' && <Badge tone="success">Approved — ready to issue</Badge>}</div> },
    { key: 'total', header: 'Total', numeric: true, cell: (i) => <Money value={i.kind === 'credit_note' ? '-' + i.total : i.total} currency={i.currency} /> },
    { key: 'out', header: 'Outstanding', numeric: true, hideOnNarrow: true, cell: (i) => ['issued', 'partially_paid'].includes(i.status) && i.kind === 'invoice' ? <Money value={i.outstanding} currency={i.currency} /> : <span className="text-stone-400">–</span> },
    { key: 'issued', header: 'Issued', className: 'whitespace-nowrap', hideOnNarrow: true, cell: (i) => <DateTime value={i.issued_at} mode="date" /> },
    { key: 'due', header: 'Due', className: 'whitespace-nowrap', hideOnNarrow: true, cell: (i) => <DateTime value={i.due_date} mode="date" /> },
  ]
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <Select aria-label="Status" value={status} onChange={(e) => { onStatus(e.target.value); setOffset(0) }} className="w-52"><option value="">All statuses</option>{['draft', 'pending_approval', 'issued', 'partially_paid', 'paid', 'void'].map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</Select>
        <Select aria-label="Type" value={kind} onChange={(e) => { setKind(e.target.value); setOffset(0) }} className="w-44"><option value="">Invoices &amp; credit notes</option><option value="invoice">Invoices</option><option value="credit_note">Credit notes</option></Select>
        <p className="ml-auto text-xs text-stone-600">Create drafts from the <strong>WIP</strong> tab.</p>
      </div>
      <DataTable caption="Invoices and credit notes" columns={cols} rows={q.data?.items} rowKey={(i) => i.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(i) => nav(`/billing/invoices/${i.id}`)}
        pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} emptyTitle="No invoices match" emptyDescription="Try another status, or prepare a draft invoice from the WIP tab." />
      <Notice>“Issued” means a bill has been delivered and a receivable recorded. It is <strong>not recognised revenue</strong> and <strong>not cash received</strong>; those are separate, separately authorised steps in the Client Ledger.</Notice>
    </div>
  )
}
