import { useMemo, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { Lock } from 'lucide-react'
import { ApiError, qs, useApiQuery } from '@/lib/api'
import { sumDecimal } from '@/lib/format'
import { Select, Skeleton } from '@/components/ui'
import type { MatterLite, Page } from '@/types/finance'

/** Decimal-string helpers (BigInt, scale 4) — never Number() on money. */
const DEC = /^(-?)(\d+)(?:\.(\d+))?$/
export function scaled(v: string | null | undefined): bigint | null {
  if (v === null || v === undefined) return null
  const m = DEC.exec(String(v).trim())
  if (!m) return null
  const n = BigInt(m[2] + (m[3] ?? '').padEnd(4, '0').slice(0, 4))
  return m[1] ? -n : n
}
/** Whole-number percentage of part/whole (presentation only, e.g. bar widths). */
export function pctOf(part: string | null | undefined, whole: string | null | undefined): number | null {
  const a = scaled(part), b = scaled(whole)
  if (a === null || b === null || b <= 0n) return null
  return Number((a * 100n) / b)
}
/** a - b as a decimal string. */
export function subDecimal(a: string, b: string): string { return sumDecimal([a, b.startsWith('-') ? b.slice(1) : '-' + b]) }
export function isMoneyInput(v: string): boolean { return /^\d+(\.\d{1,2})?$/.test(v.trim()) }
export function isZero(v: string | null | undefined): boolean { const s = scaled(v); return s !== null && s === 0n }
export function cmp(a: string, b: string): number { const x = scaled(a), y = scaled(b); if (x === null || y === null) return 0; return x < y ? -1 : x > y ? 1 : 0 }
export function todayIso(): string { return new Date().toISOString().slice(0, 10) }
export function hash8(h: string | null | undefined): string { return h ? h.slice(0, 12) : '—' }

export const FINANCE_NOTICE =
  'Demonstration accounting only. The chart of accounts, journals, receipts, allocations, client-money transfers, reconciliation and revenue recognition shown here are illustrative and use synthetic data. ' +
  'Before real client money or live billing is introduced, a qualified legal-accounts professional (COFA / finance director / accountants) must define the real accounting procedures, and the firm must obtain the regulatory and professional review described in docs/COMPLIANCE_REVIEW.md. No compliance certification is claimed.'

/** Matter picker (open matters the user may see). Falls back to a plain UUID input if the matters endpoint is not available. */
export function useOpenMatters(enabled = true) {
  return useApiQuery<Page<MatterLite>>(['matters', 'picker'], `/matters${qs({ status: 'open', limit: 200 })}`, { enabled, staleTime: 60_000 })
}
export function MatterSelect({ value, onChange, id, required, disabled, extra, 'aria-describedby': describedBy, 'aria-invalid': invalid }: {
  value: string; onChange: (id: string) => void; id?: string; required?: boolean; disabled?: boolean; extra?: MatterLite[]
  'aria-describedby'?: string; 'aria-invalid'?: boolean
}) {
  const q = useOpenMatters()
  const items = useMemo(() => {
    const base = q.data?.items ?? []
    const have = new Set(base.map((m) => m.id))
    return [...base, ...(extra ?? []).filter((m) => !have.has(m.id))]
  }, [q.data, extra])
  if (q.isPending) return <Skeleton className="h-9 w-full" />
  return (
    <Select id={id} value={value} onChange={(e) => onChange(e.target.value)} required={required} disabled={disabled} aria-describedby={describedBy} aria-invalid={invalid}>
      <option value="">{q.isError ? 'Matters unavailable' : 'Select a matter…'}</option>
      {items.map((m) => <option key={m.id} value={m.id}>{m.reference} · {m.title}</option>)}
    </Select>
  )
}

/** Renders children, or a calm inline "not available for your role" if the query was refused with 403. */
export function GateNote({ error, what }: { error: unknown; what: string }) {
  if (error instanceof ApiError && error.status === 403) {
    return <p className="flex items-center gap-2 rounded-md bg-stone-50 px-3 py-2 text-xs text-stone-600"><Lock className="h-3.5 w-3.5" aria-hidden />{what} is not available to your role.</p>
  }
  return null
}

export function MatterLink({ id, reference }: { id: string; reference: string | null | undefined }) {
  return <Link to={`/matters/${id}`} className="font-medium text-navy-700 underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500" onClick={(e) => e.stopPropagation()}>{reference ?? 'Matter'}</Link>
}

export function Notice({ tone = 'neutral', title, children, className }: { tone?: 'neutral' | 'brass' | 'warning'; title?: ReactNode; children: ReactNode; className?: string }) {
  const c = { neutral: 'border-stone-300 bg-ivory-100 text-stone-700', brass: 'border-brass-300 bg-brass-50 text-brass-700', warning: 'border-warn-100 bg-warn-50 text-warn-700' }[tone]
  return (
    <div role="note" className={`rounded-md border px-4 py-3 text-sm leading-relaxed ${c} ${className ?? ''}`}>
      {title && <p className="mb-0.5 font-semibold">{title}</p>}
      <div>{children}</div>
    </div>
  )
}
