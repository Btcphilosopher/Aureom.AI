import { useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight, Pencil, Plus, Send, ThumbsUp, Trash2, Eraser } from 'lucide-react'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, ConfirmDialog, DataTable, DateTime, Duration, IconButton, Money, Select, StatusBadge, type Column } from '@/components/ui'
import { formatDate, sumDecimal } from '@/lib/format'
import { MatterLink, Notice } from './shared'
import { TimeEntryDialog } from './TimeEntryDialog'
import type { Page, TimeEntry } from '@/types/finance'

function mondayOf(d: Date): Date { const x = new Date(d); const day = (x.getDay() + 6) % 7; x.setDate(x.getDate() - day); x.setHours(12, 0, 0, 0); return x }
const iso = (d: Date) => d.toISOString().slice(0, 10)
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }

export function TimeTab({ openNew, onNewHandled }: { openNew: boolean; onNewHandled: () => void }) {
  const { can } = useAuth()
  const [weekStart, setWeekStart] = useState(() => mondayOf(new Date()))
  const [view, setView] = useState<'week' | 'list'>('week')
  const [status, setStatus] = useState('')
  const [offset, setOffset] = useState(0)
  const [editing, setEditing] = useState<TimeEntry | null>(null)
  const [creating, setCreating] = useState(false)
  const [writeOff, setWriteOff] = useState<TimeEntry | null>(null)
  const [scope, setScope] = useState<'mine' | 'all'>('mine')
  const weekEnd = addDays(weekStart, 6)

  const weekQ = useApiQuery<Page<TimeEntry>>(['time', 'week', iso(weekStart), scope], `/time/entries${qs({ mine: scope === 'mine', date_from: iso(weekStart), date_to: iso(weekEnd), limit: 200 })}`, { enabled: view === 'week' })
  const listQ = useApiQuery<Page<TimeEntry>>(['time', 'list', status, offset, scope], `/time/entries${qs({ mine: scope === 'mine', status: status || undefined, limit: 25, offset })}`, { enabled: view === 'list' })

  const submit = useApiMutation((e: TimeEntry) => api.post(`/time/entries/${e.id}/submit`), { invalidate: [['time']], successMessage: 'Submitted for approval' })
  const approve = useApiMutation((e: TimeEntry) => api.post(`/time/entries/${e.id}/approve`), { invalidate: [['time']], successMessage: 'Time approved' })
  const del = useApiMutation((e: TimeEntry) => api.delete(`/time/entries/${e.id}`), { invalidate: [['time']], successMessage: 'Draft entry deleted' })
  const wo = useApiMutation((v: { e: TimeEntry; reason: string }) => api.post(`/time/entries/${v.e.id}/write-off`, { reason: v.reason }), { invalidate: [['time']], successMessage: 'Time written off' })

  const showNew = creating || openNew
  const closeNew = () => { setCreating(false); onNewHandled() }

  const actions = (e: TimeEntry) => (
    <div className="flex justify-end gap-1" onClick={(ev) => ev.stopPropagation()}>
      {['draft', 'submitted'].includes(e.status) && <IconButton aria-label={`Edit time entry on ${e.matter_reference}`} size="sm" onClick={() => setEditing(e)}><Pencil className="h-4 w-4" /></IconButton>}
      {e.status === 'draft' && <IconButton aria-label="Submit for approval" size="sm" onClick={() => submit.mutate(e)}><Send className="h-4 w-4" /></IconButton>}
      {['draft', 'submitted'].includes(e.status) && can('billing.write') && <IconButton aria-label="Approve time" size="sm" onClick={() => approve.mutate(e)}><ThumbsUp className="h-4 w-4" /></IconButton>}
      {['draft', 'submitted', 'approved'].includes(e.status) && can('billing.write') && <IconButton aria-label="Write off time" size="sm" onClick={() => setWriteOff(e)}><Eraser className="h-4 w-4" /></IconButton>}
      {e.status === 'draft' && <IconButton aria-label="Delete draft entry" size="sm" onClick={() => del.mutate(e)}><Trash2 className="h-4 w-4" /></IconButton>}
    </div>
  )

  const cols: Column<TimeEntry>[] = [
    { key: 'date', header: 'Date', className: 'whitespace-nowrap', cell: (e) => <DateTime value={e.work_date} mode="date" /> },
    { key: 'matter', header: 'Matter', cell: (e) => <MatterLink id={e.matter_id} reference={e.matter_reference} /> },
    ...(scope === 'all' ? [{ key: 'user', header: 'Fee earner', cell: (e: TimeEntry) => e.user_name ?? '—' }] : []),
    { key: 'narr', header: 'Narrative', cell: (e) => <span className="line-clamp-2 max-w-md">{e.narrative || <em className="text-stone-500">No narrative</em>}</span> },
    { key: 'dur', header: 'Time', numeric: true, cell: (e) => <Duration minutes={e.minutes} /> },
    { key: 'rate', header: 'Rate', numeric: true, hideOnNarrow: true, cell: (e) => <Money value={e.rate} currency={e.currency} muted /> },
    { key: 'amount', header: 'Value', numeric: true, cell: (e) => <span className={e.billable ? '' : 'text-stone-500'}><Money value={e.amount} currency={e.currency} /></span> },
    { key: 'status', header: 'Status', cell: (e) => <div className="flex flex-wrap gap-1"><StatusBadge status={e.status} />{!e.billable && <Badge>Non-billable</Badge>}{e.source === 'agent_suggestion' && <Badge tone="simulated">AI draft</Badge>}</div> },
    { key: 'act', header: <span className="sr-only">Actions</span>, align: 'right', cell: actions },
  ]

  // Week grid
  const week = weekQ.data?.items ?? []
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))
  const rows = useMemo(() => {
    const m = new Map<string, { id: string; ref: string; mins: number[]; amt: string[] }>()
    for (const e of week) {
      const r = m.get(e.matter_id) ?? { id: e.matter_id, ref: e.matter_reference ?? 'Matter', mins: Array<number>(7).fill(0), amt: [] as string[] }
      const di = Math.round((new Date(e.work_date + 'T12:00:00').getTime() - weekStart.getTime()) / 86400000)
      if (di >= 0 && di < 7) r.mins[di] += e.minutes
      r.amt.push(e.amount); m.set(e.matter_id, r)
    }
    return [...m.values()].sort((a, b) => a.ref.localeCompare(b.ref))
  }, [week, weekStart])
  const dayTotals = days.map((_, i) => rows.reduce((s, r) => s + r.mins[i]!, 0))

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div role="group" aria-label="View" className="inline-flex overflow-hidden rounded-md ring-1 ring-stone-300">
            {(['week', 'list'] as const).map((v) => <button key={v} type="button" aria-pressed={view === v} onClick={() => setView(v)} className={`px-3 py-1.5 text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500 ${view === v ? 'bg-navy-800 text-white' : 'bg-white text-navy-800 hover:bg-ivory-100'}`}>{v === 'week' ? 'Timesheet' : 'List'}</button>)}
          </div>
          {can('time.read_all') && <Select aria-label="Whose time" value={scope} onChange={(e) => { setScope(e.target.value as 'mine' | 'all'); setOffset(0) }} className="w-40"><option value="mine">My time</option><option value="all">Everyone's time</option></Select>}
          {view === 'list' && <Select aria-label="Status" value={status} onChange={(e) => { setStatus(e.target.value); setOffset(0) }} className="w-44"><option value="">All statuses</option>{['draft', 'submitted', 'approved', 'billed', 'written_off'].map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</Select>}
        </div>
        <Button icon={<Plus className="h-4 w-4" />} onClick={() => setCreating(true)}>Record time</Button>
      </div>

      {view === 'week' ? (
        <Card title={`Week of ${formatDate(weekStart)}`} actions={<div className="flex items-center gap-1">
          <IconButton aria-label="Previous week" variant="secondary" onClick={() => setWeekStart(addDays(weekStart, -7))}><ChevronLeft className="h-4 w-4" /></IconButton>
          <Button size="sm" variant="secondary" onClick={() => setWeekStart(mondayOf(new Date()))}>This week</Button>
          <IconButton aria-label="Next week" variant="secondary" onClick={() => setWeekStart(addDays(weekStart, 7))}><ChevronRight className="h-4 w-4" /></IconButton></div>} padded={false}>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <caption className="sr-only">Timesheet for the week starting {formatDate(weekStart)}: minutes per matter per day</caption>
              <thead><tr className="border-b border-stone-300 bg-ivory-200 text-xs uppercase tracking-wide text-stone-700">
                <th scope="col" className="px-4 py-2.5 text-left font-semibold">Matter</th>
                {days.map((d) => <th scope="col" key={iso(d)} className="px-3 py-2.5 text-right font-semibold">{d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric' })}</th>)}
                <th scope="col" className="px-4 py-2.5 text-right font-semibold">Total</th><th scope="col" className="px-4 py-2.5 text-right font-semibold">Value</th></tr></thead>
              <tbody>
                {weekQ.isPending && <tr><td colSpan={10} className="px-4 py-8 text-center text-stone-600">Loading timesheet…</td></tr>}
                {weekQ.isError && <tr><td colSpan={10} className="px-4 py-8 text-center text-bad-700">{weekQ.error.message}</td></tr>}
                {!weekQ.isPending && !weekQ.isError && rows.length === 0 && <tr><td colSpan={10} className="px-4 py-10 text-center text-stone-600">No time recorded this week. Use the timer or “Record time”.</td></tr>}
                {rows.map((r) => (
                  <tr key={r.id} className="border-b border-stone-100">
                    <th scope="row" className="px-4 py-2.5 text-left font-medium"><MatterLink id={r.id} reference={r.ref} /></th>
                    {r.mins.map((m, i) => <td key={i} className="px-3 py-2.5 text-right tabular-nums">{m ? <Duration minutes={m} /> : <span className="text-stone-400">–</span>}</td>)}
                    <td className="px-4 py-2.5 text-right font-medium tabular-nums"><Duration minutes={r.mins.reduce((a, b) => a + b, 0)} /></td>
                    <td className="px-4 py-2.5 text-right"><Money value={sumDecimal(r.amt)} /></td>
                  </tr>))}
              </tbody>
              {rows.length > 0 && <tfoot><tr className="border-t border-stone-300 bg-ivory-100 font-semibold">
                <th scope="row" className="px-4 py-2.5 text-left">Day total</th>{dayTotals.map((m, i) => <td key={i} className="px-3 py-2.5 text-right tabular-nums"><Duration minutes={m} /></td>)}
                <td className="px-4 py-2.5 text-right tabular-nums"><Duration minutes={dayTotals.reduce((a, b) => a + b, 0)} /></td><td className="px-4 py-2.5 text-right"><Money value={sumDecimal(week.map((e) => e.amount))} /></td></tr></tfoot>}
            </table>
          </div>
          {week.length > 0 && <div className="border-t border-stone-200 p-4"><DataTable caption="Entries this week" columns={cols} rows={week} rowKey={(e) => e.id} dense className="shadow-none" /></div>}
        </Card>
      ) : (
        <DataTable caption="Time entries" columns={cols} rows={listQ.data?.items} rowKey={(e) => e.id} loading={listQ.isPending} error={listQ.error} onRetry={() => void listQ.refetch()}
          pagination={listQ.data ? { total: listQ.data.total, limit: listQ.data.limit, offset: listQ.data.offset, onChange: setOffset } : undefined}
          emptyTitle="No time entries" emptyDescription="Record time with the timer above or the button." />
      )}
      <Notice>Time starts as a <strong>draft</strong>, is <strong>submitted</strong>, then <strong>approved</strong> by someone with billing rights before it can be billed. Written-off time needs a recorded reason. Time that has been billed cannot be edited.</Notice>

      <TimeEntryDialog open={showNew || !!editing} onClose={() => { setEditing(null); closeNew() }} entry={editing} />
      <ConfirmDialog open={!!writeOff} onClose={() => setWriteOff(null)} title="Write off time" description="Written-off time will not be billed. This is recorded in the audit trail." requireReason="Reason for write-off" confirmLabel="Write off" tone="danger"
        onConfirm={async (reason) => { if (writeOff && reason) { await wo.mutateAsync({ e: writeOff, reason }); setWriteOff(null) } }} />
    </div>
  )
}
