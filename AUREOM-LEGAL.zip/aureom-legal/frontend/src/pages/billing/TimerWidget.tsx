import { useEffect, useState } from 'react'
import { Play, Square, Timer } from 'lucide-react'
import { ApiError, api, useApiMutation, useApiQuery } from '@/lib/api'
import { Button, Field, Input, Select } from '@/components/ui'
import { MatterSelect } from './shared'
import type { TimeEntry } from '@/types/finance'

function elapsed(from: string, now: number): string {
  const s = Math.max(0, Math.floor((now - new Date(from).getTime()) / 1000))
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
}

/** Start/stop timer. One running timer per user (enforced by the server). Stopping converts it into a draft time entry. */
export function TimerWidget() {
  const q = useApiQuery<TimeEntry | null>(['time', 'timer'], '/time/timer', { refetchInterval: 60_000 })
  const [now, setNow] = useState(Date.now())
  const [matter, setMatter] = useState('')
  const [narrative, setNarrative] = useState('')
  const [billable, setBillable] = useState(true)
  const running = q.data ?? null
  useEffect(() => { if (!running) return; const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t) }, [running])

  const start = useApiMutation(() => api.post<TimeEntry>('/time/timer/start', { matter_id: matter, narrative, billable }), { invalidate: [['time']], successMessage: 'Timer started' })
  const stop = useApiMutation(() => api.post<TimeEntry>('/time/timer/stop', { narrative: narrative || null }), {
    invalidate: [['time'], ['billing']], successMessage: (e) => `Timer stopped — ${e.minutes} min recorded as a draft entry`,
  })

  if (q.isError) return null // role without time.write: widget is simply not offered
  return (
    <section aria-label="Timer" className="mb-6 flex flex-wrap items-end gap-4 rounded-lg border border-stone-200 bg-white px-5 py-4 shadow-panel">
      <div className="flex items-center gap-3">
        <span className={`flex h-10 w-10 items-center justify-center rounded-full ${running ? 'bg-brass-100 text-brass-700' : 'bg-navy-50 text-navy-600'}`}><Timer className="h-5 w-5" aria-hidden /></span>
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-stone-600">{running ? 'Timer running' : 'Timer'}</p>
          {running
            ? <p className="font-serif text-2xl tabular-nums text-navy-900" aria-live="off">{elapsed(running.timer_started_at!, now)}</p>
            : <p className="text-sm text-stone-600">No timer running</p>}
        </div>
      </div>
      {running ? (
        <>
          <div className="min-w-[12rem] flex-1 text-sm"><p className="font-medium text-navy-900">{running.matter_reference}</p><p className="truncate text-stone-600">{running.narrative || 'No narrative yet'}</p></div>
          <Field label="Narrative on stop" className="min-w-[16rem] flex-1"><Input value={narrative} onChange={(e) => setNarrative(e.target.value)} placeholder="Describe the work done" /></Field>
          <Button variant="danger" icon={<Square className="h-4 w-4" />} loading={stop.isPending} onClick={() => stop.mutate()}>Stop &amp; save</Button>
        </>
      ) : (
        <>
          <Field label="Matter" className="min-w-[16rem] flex-1">{(p) => <MatterSelect {...p} value={matter} onChange={setMatter} />}</Field>
          <Field label="What are you working on?" className="min-w-[14rem] flex-1"><Input value={narrative} onChange={(e) => setNarrative(e.target.value)} placeholder="Optional — can be added when stopping" /></Field>
          <Field label="Billing"><Select value={billable ? 'y' : 'n'} onChange={(e) => setBillable(e.target.value === 'y')}><option value="y">Billable</option><option value="n">Non-billable</option></Select></Field>
          <Button icon={<Play className="h-4 w-4" />} disabled={!matter} loading={start.isPending} onClick={() => start.mutate()}>Start timer</Button>
        </>
      )}
      {(start.error instanceof ApiError || stop.error instanceof ApiError) && <p role="alert" className="w-full text-xs font-medium text-bad-700">{(start.error ?? stop.error)?.message}</p>}
      <p className="w-full text-2xs text-stone-600">Narratives must describe work actually done. Rates and amounts are calculated by the server from the matter's rate card when the entry is saved.</p>
    </section>
  )
}
