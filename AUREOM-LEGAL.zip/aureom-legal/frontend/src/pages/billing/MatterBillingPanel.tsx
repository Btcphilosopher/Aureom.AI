import { useState } from 'react'
import { Link } from 'react-router-dom'
import { FilePlus2, Plus } from 'lucide-react'
import { qs, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Badge, Button, Card, DataTable, DateTime, Duration, Money, StatCard, StatusBadge, type Column } from '@/components/ui'
import { formatMoney, sumDecimal } from '@/lib/format'
import { BudgetBar } from './WipTab'
import { GateNote, Notice, pctOf } from './shared'
import { InvoiceBuilder } from './InvoiceBuilder'
import { TimeEntryDialog } from './TimeEntryDialog'
import type { Expense, Invoice, MatterBudget, Page, TimeEntry } from '@/types/finance'

/** Time, expenses, unbilled WIP vs budget, invoices and client-ledger balance for ONE matter. Each section degrades gracefully by permission. */
export function MatterBillingPanel({ matterId, matterReference }: { matterId: string; matterReference?: string }) {
  const { can } = useAuth()
  const [logTime, setLogTime] = useState(false)
  const [build, setBuild] = useState(false)
  const budget = useApiQuery<MatterBudget>(['billing', 'budget', matterId], `/time/matters/${matterId}/budget`, { enabled: can('billing.read'), retry: false })
  const time = useApiQuery<Page<TimeEntry>>(['time', 'matter', matterId], `/time/entries${qs({ matter_id: matterId, limit: 15 })}`, { enabled: can('time.write'), retry: false })
  const exps = useApiQuery<Page<Expense>>(['time', 'matter-expenses', matterId], `/time/expenses${qs({ matter_id: matterId, limit: 10 })}`, { enabled: can('time.write'), retry: false })
  const invs = useApiQuery<Page<Invoice>>(['billing', 'matter-invoices', matterId], `/billing/invoices${qs({ matter_id: matterId, limit: 10 })}`, { enabled: can('billing.read'), retry: false })
  const bal = useApiQuery<{ balance: string; currency: string; basis: string }>(['ledger', 'client-balance', matterId], `/ledger/matters/${matterId}/client-balance`, { enabled: can('ledger.read'), retry: false })

  const timeCols: Column<TimeEntry>[] = [
    { key: 'd', header: 'Date', cell: (e) => <DateTime value={e.work_date} mode="date" /> },
    { key: 'u', header: 'Fee earner', hideOnNarrow: true, cell: (e) => e.user_name ?? '—' },
    { key: 'n', header: 'Narrative', cell: (e) => <span className="line-clamp-1 max-w-sm">{e.narrative || '—'}</span> },
    { key: 'm', header: 'Time', numeric: true, cell: (e) => <Duration minutes={e.minutes} /> },
    { key: 'a', header: 'Value', numeric: true, cell: (e) => <Money value={e.amount} currency={e.currency} /> },
    { key: 's', header: 'Status', cell: (e) => <StatusBadge status={e.status} /> },
  ]
  const expCols: Column<Expense>[] = [
    { key: 'd', header: 'Date', cell: (e) => <DateTime value={e.expense_date} mode="date" /> },
    { key: 'n', header: 'Description', cell: (e) => e.description },
    { key: 'a', header: 'Net', numeric: true, cell: (e) => <Money value={e.amount} currency={e.currency} /> },
    { key: 's', header: 'Status', cell: (e) => <StatusBadge status={e.status} /> },
  ]
  const invCols: Column<Invoice>[] = [
    { key: 'n', header: 'Number', cell: (i) => <Link className="font-medium text-navy-700 underline-offset-2 hover:underline" to={`/billing/invoices/${i.id}`}>{i.number ?? 'Draft'}</Link> },
    { key: 't', header: 'Type', cell: (i) => (i.kind === 'credit_note' ? <Badge tone="brass">Credit note</Badge> : 'Invoice') },
    { key: 's', header: 'Status', cell: (i) => <StatusBadge status={i.status} /> },
    { key: 'tot', header: 'Total', numeric: true, cell: (i) => <Money value={i.total} currency={i.currency} /> },
    { key: 'o', header: 'Outstanding', numeric: true, cell: (i) => (['issued', 'partially_paid'].includes(i.status) && i.kind === 'invoice' ? <Money value={i.outstanding} currency={i.currency} /> : '–') },
  ]

  const b = budget.data
  const unbilledTime = time.data ? sumDecimal(time.data.items.filter((e) => e.billable && !e.invoice_line_id && e.status !== 'written_off').map((e) => e.amount)) : null
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Unbilled WIP (net)" value={b ? <Money value={b.unbilled_wip} currency={b.currency} /> : '—'} hint={b ? 'Time + expenses not yet billed' : undefined} footnote="Work in progress is not revenue." />
        <StatCard label="Billed (net, issued)" value={b ? <Money value={b.billed_net} currency={b.currency} /> : '—'} footnote="Billed is not recognised revenue or cash." />
        <StatCard label="Budget used" tone={b?.over_budget ? 'danger' : 'neutral'} value={b?.used_pct ? `${b.used_pct}%` : '—'} hint={b?.budget ? <>of <Money value={b.budget} currency={b.currency} /></> : 'No budget set'} footnote={b ? b.basis : undefined} />
        <StatCard label="Client money held" tone="brass" value={bal.data ? <Money value={bal.data.balance} currency={bal.data.currency} /> : '—'} hint={bal.data ? 'Held for the client — not the firm\'s money' : undefined} to={can('ledger.read') ? '/ledger/client-money' : undefined} />
      </div>
      {b && b.budget && <Card title="Budget"><BudgetBar used={b.used} budget={b.budget} />{b.over_budget && <p role="alert" className="mt-2 text-sm font-medium text-bad-700">This matter has exceeded its budget ({formatMoney(b.used, b.currency)} used). Consider a client update.</p>}</Card>}
      <GateNote error={budget.error} what="Budget and billing summary" />

      {can('time.write') && (
        <Card title="Time" actions={<><Button size="sm" variant="secondary" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setLogTime(true)}>Record time</Button>
          {can('billing.write') && <Button size="sm" icon={<FilePlus2 className="h-3.5 w-3.5" />} onClick={() => setBuild(true)}>Prepare invoice</Button>}</>} padded={false}>
          <DataTable caption="Recent time entries on this matter" columns={timeCols} rows={time.data?.items} rowKey={(e) => e.id} loading={time.isPending} error={time.error} onRetry={() => void time.refetch()} dense className="rounded-none border-0 shadow-none" emptyTitle="No time recorded on this matter yet" />
          {time.data && time.data.total > time.data.items.length && <p className="border-t border-stone-200 px-5 py-2 text-xs text-stone-600">Showing latest {time.data.items.length} of {time.data.total}. <Link className="underline" to="/billing?tab=time">Open Time &amp; Billing</Link>.</p>}
          {unbilledTime && <p className="sr-only">Unbilled value in the visible entries: {unbilledTime}</p>}
        </Card>)}
      {can('time.write') && <Card title="Expenses" padded={false}><DataTable caption="Expenses on this matter" columns={expCols} rows={exps.data?.items} rowKey={(e) => e.id} loading={exps.isPending} error={exps.error} dense className="rounded-none border-0 shadow-none" emptyTitle="No expenses on this matter" /></Card>}
      {can('billing.read') && <Card title="Invoices & credit notes" padded={false}><DataTable caption="Invoices on this matter" columns={invCols} rows={invs.data?.items} rowKey={(i) => i.id} loading={invs.isPending} error={invs.error} dense className="rounded-none border-0 shadow-none" emptyTitle="Nothing billed yet" /></Card>}
      {!can('time.write') && !can('billing.read') && <Notice>Billing information is not available to your role.</Notice>}
      <TimeEntryDialog open={logTime} onClose={() => setLogTime(false)} defaultMatterId={matterId} />
      <InvoiceBuilder matterId={matterId} matterRef={matterReference} open={build} onClose={() => setBuild(false)} />
    </div>
  )
}
