import { useState } from 'react'
import { FilePlus2 } from 'lucide-react'
import { useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { Button, Card, DataTable, Money, StatCard, type Column } from '@/components/ui'
import { InvoiceBuilder } from './InvoiceBuilder'
import { MatterLink, Notice, pctOf } from './shared'
import type { ReportData } from '@/types/finance'

interface WipRow { matter_id: string; reference: string; title: string; fee_earner: string | null; time: string; hours: string; expenses: string; total: string; budget: string | null }

export function BudgetBar({ used, budget }: { used: string; budget: string | null }) {
  const pct = pctOf(used, budget)
  if (pct === null) return <span className="text-xs text-stone-500">No budget set</span>
  const w = Math.min(100, pct)
  const tone = pct >= 100 ? 'bg-bad-600' : pct >= 80 ? 'bg-warn-600' : 'bg-navy-600'
  return (
    <div className="min-w-[8rem]" title={`${pct}% of budget`}>
      <div className="h-2 overflow-hidden rounded-full bg-stone-200" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={w} aria-label={`WIP is ${pct}% of budget`}><div className={`h-full ${tone}`} style={{ width: `${w}%` }} /></div>
      <p className="mt-0.5 text-2xs tabular-nums text-stone-600">{pct}% of <Money value={budget} /></p>
    </div>
  )
}

export function WipTab() {
  const { can } = useAuth()
  const q = useApiQuery<ReportData>(['billing', 'wip'], '/reports/wip')
  const [target, setTarget] = useState<WipRow | null>(null)
  const rows = (q.data?.rows ?? []) as unknown as WipRow[]
  const cols: Column<WipRow>[] = [
    { key: 'ref', header: 'Matter', cell: (r) => <div><MatterLink id={r.matter_id} reference={r.reference} /><p className="max-w-xs truncate text-xs text-stone-600">{r.title}</p></div> },
    { key: 'fe', header: 'Fee earner', hideOnNarrow: true, cell: (r) => r.fee_earner ?? '—' },
    { key: 'hours', header: 'Hours', numeric: true, cell: (r) => r.hours },
    { key: 'time', header: 'Time', numeric: true, cell: (r) => <Money value={r.time} /> },
    { key: 'exp', header: 'Expenses', numeric: true, cell: (r) => <Money value={r.expenses} /> },
    { key: 'total', header: 'Unbilled', numeric: true, cell: (r) => <strong><Money value={r.total} /></strong> },
    { key: 'budget', header: 'Against budget', cell: (r) => <BudgetBar used={r.total} budget={r.budget} /> },
    { key: 'act', header: <span className="sr-only">Actions</span>, align: 'right', cell: (r) => can('billing.write') ? <Button size="sm" variant="secondary" icon={<FilePlus2 className="h-3.5 w-3.5" />} onClick={() => setTarget(r)}>Prepare invoice</Button> : null },
  ]
  const t = q.data?.totals as { time?: string; expenses?: string; total?: string } | undefined
  return (
    <div className="space-y-5">
      {q.data && (
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard label="Unbilled time" value={<Money value={t?.time} />} />
          <StatCard label="Unbilled expenses" value={<Money value={t?.expenses} />} />
          <StatCard label="Total WIP" tone="brass" value={<Money value={t?.total} />} footnote="Work in progress is not revenue." />
        </div>)}
      <Card title="Unbilled work by matter" description={q.data ? `As at ${q.data.period.as_of ?? 'today'} · ${q.data.currency}` : undefined} padded={false}>
        <DataTable caption="Unbilled work by matter" columns={cols} rows={rows} rowKey={(r) => r.matter_id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} className="rounded-none border-0 shadow-none"
          emptyTitle="Nothing unbilled" emptyDescription="All billable time and expenses on matters you can see have been billed or written off." />
      </Card>
      {q.data && <Notice title="Calculation basis">{q.data.basis}</Notice>}
      <InvoiceBuilder matterId={target?.matter_id ?? null} matterRef={target?.reference} open={!!target} onClose={() => setTarget(null)} />
    </div>
  )
}
