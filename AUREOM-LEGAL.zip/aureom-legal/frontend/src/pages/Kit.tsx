import { useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { useBreadcrumbs } from '@/layout/Breadcrumbs'
import { usePageTitle } from '@/hooks'
import { sumDecimal } from '@/lib/format'
import {
  Avatar, Badge, Button, Card, Checkbox, CitationChip, ConfirmDialog, DataTable, DateTime, Dialog, Drawer, DropdownMenu, EmptyState, ErrorState, Field,
  FileDropzone, IconButton, Input, IntegrationUnavailable, KeyValue, LoadingState, Money, NotFoundState, PageHeader, PermissionDenied, SearchInput,
  Select, SimulatedBanner, Skeleton, Spinner, StatCard, StatusBadge, StatusStepper, TabPanel, Tabs, Textarea, Timeline, Tooltip, useToast, type Column,
} from '@/components/ui'

interface Row { id: string; ref: string; title: string; status: string; fee: string }
const ROWS: Row[] = [
  { id: '1', ref: 'PCS-COM-0142', title: 'Supply agreement — Halifax Mills Ltd', status: 'open', fee: '12450.50' },
  { id: '2', ref: 'PCS-PRO-0097', title: 'Lease renewal — Calder Works', status: 'paused', fee: '3200.00' },
  { id: '3', ref: 'PCS-LIT-0031', title: 'Debt recovery — Brontë Foods', status: 'pending_approval', fee: '-480.25' },
]

/** Hidden design-kit page (/_kit): every shared component in context. */
export default function Kit() {
  usePageTitle('UI kit'); useBreadcrumbs([{ label: 'Home', to: '/' }, { label: 'UI kit' }])
  const toast = useToast()
  const [tab, setTab] = useState('badges'), [dlg, setDlg] = useState(false), [confirm, setConfirm] = useState(false), [drawer, setDrawer] = useState(false)
  const [q, setQ] = useState(''), [sort, setSort] = useState({ key: 'ref', dir: 'asc' as 'asc' | 'desc' })
  const cols: Column<Row>[] = [
    { key: 'ref', header: 'Reference', sortable: true, cell: (r) => <span className="font-medium">{r.ref}</span> },
    { key: 'title', header: 'Matter', cell: (r) => r.title },
    { key: 'status', header: 'Status', cell: (r) => <StatusBadge status={r.status} /> },
    { key: 'fee', header: 'Fees', numeric: true, cell: (r) => <Money value={r.fee} /> },
  ]
  return (
    <>
      <PageHeader eyebrow="Design system" title="UI kit" description="Reference page for the shared, accessible components. Not linked from navigation." />
      <div className="space-y-8">
        <Tabs value={tab} onChange={setTab} tabs={[{ id: 'badges', label: 'Badges & stats' }, { id: 'table', label: 'Data table', badge: 3 }, { id: 'forms', label: 'Forms' }, { id: 'overlays', label: 'Overlays' }, { id: 'states', label: 'States' }]} />
        <TabPanel id="badges" value={tab} className="space-y-6">
          <Card title="Status badges" description="Tones map from backend status strings via statusTone().">
            <div className="flex flex-wrap gap-2"><Badge>neutral</Badge><Badge tone="info">info</Badge><Badge tone="success">success</Badge><Badge tone="warning">warning</Badge><Badge tone="danger">danger</Badge><Badge tone="brass">restricted</Badge><Badge tone="simulated">simulated</Badge><StatusBadge status="passed_simulated" /><StatusBadge status="awaiting_review" /></div>
          </Card>
          <div className="grid gap-4 sm:grid-cols-3">
            <StatCard label="Active matters" value="38" hint="Responsible or fee-earner" to="/matters" />
            <StatCard label="Unbilled WIP" value={<Money value={sumDecimal(['1200.10', '800.05'])} />} tone="brass" footnote="Basis: approved, unbilled time × rate, 1 Oct – 12 Nov 2026." />
            <StatCard label="Overdue deadlines" value="2" tone="danger" to="/tasks" />
          </div>
          <Card title="Misc"><div className="flex flex-wrap items-center gap-4"><Avatar name="Eleanor Whitcombe" /><CitationChip documentTitle="Supply Agreement" versionNo={2} page={3} paragraph={4} quote="The Supplier shall deliver…" /><Tooltip text="Tooltip text"><Button variant="secondary" size="sm">Hover me</Button></Tooltip><Spinner /><Skeleton className="h-4 w-32" /><DateTime value="2026-11-12T14:30:00Z" /><DateTime value="2026-11-11T10:00:00Z" mode="relative" /></div></Card>
          <Card title="Stepper & timeline"><StatusStepper steps={[{ key: 'a', label: 'Instruction' }, { key: 'b', label: 'Drafting' }, { key: 'c', label: 'Negotiation' }, { key: 'd', label: 'Completion' }]} current="b" />
            <div className="mt-6"><Timeline items={[{ id: '1', title: 'Matter opened', meta: 'E. Whitcombe', time: '12 Nov 2026', tone: 'success' }, { id: '2', title: 'Agreement uploaded (v1)', time: '12 Nov 2026', tone: 'info', description: 'SHA-256 recorded; original is immutable.' }]} /></div></Card>
          <KeyValue columns={3} items={[{ label: 'Client ref', value: 'PCS-C-0012' }, { label: 'Office', value: 'Leeds' }, { label: 'Opened', value: <DateTime value="2026-11-12" mode="date" /> }]} />
        </TabPanel>
        <TabPanel id="table" value={tab} className="space-y-4">
          <SearchInput value={q} onValueChange={setQ} placeholder="Filter matters…" className="max-w-sm" />
          <DataTable caption="Example matters" columns={cols} rows={ROWS.filter((r) => r.title.toLowerCase().includes(q.toLowerCase()))} rowKey={(r) => r.id} sort={sort} onSortChange={setSort} onRowClick={(r) => toast.push({ title: `Opened ${r.ref}`, tone: 'info' })} pagination={{ total: 3, limit: 50, offset: 0, onChange: () => undefined }} />
          <DataTable caption="Loading example" columns={cols} rows={undefined} rowKey={(r) => r.id} loading skeletonRows={3} />
          <DataTable caption="Empty example" columns={cols} rows={[]} rowKey={(r) => r.id} emptyTitle="No matters match" emptyDescription="Adjust the filters or open a new matter." emptyAction={<Button icon={<Plus className="h-4 w-4" />}>New matter</Button>} />
        </TabPanel>
        <TabPanel id="forms" value={tab}>
          <Card title="Form controls"><div className="grid max-w-2xl gap-5 sm:grid-cols-2">
            <Field label="Client name" required hint="As shown on identity documents."><Input placeholder="e.g. Halifax Mills Ltd" /></Field>
            <Field label="Practice area"><Select defaultValue="commercial"><option value="commercial">Commercial</option><option value="property">Property</option></Select></Field>
            <Field label="Email" error="Enter a valid email address."><Input defaultValue="not-an-email" /></Field>
            <Field label="Notes"><Textarea rows={3} /></Field>
            <Checkbox label="Restrict this matter" hint="Only listed members can see it." /><div />
            <FileDropzone className="sm:col-span-2" accept=".pdf,.docx,.txt,.png,.jpg" maxSizeBytes={25 * 1024 * 1024} onFiles={(f) => toast.push({ title: `${f.length} file(s) selected`, tone: 'info' })} />
          </div></Card>
        </TabPanel>
        <TabPanel id="overlays" value={tab}>
          <Card title="Overlays & menus"><div className="flex flex-wrap items-center gap-3">
            <Button onClick={() => setDlg(true)}>Dialog</Button><Button variant="secondary" onClick={() => setConfirm(true)}>Confirm with reason</Button><Button variant="ghost" onClick={() => setDrawer(true)}>Drawer</Button>
            <Button variant="danger" icon={<Trash2 className="h-4 w-4" />}>Danger</Button><Button loading>Saving</Button><IconButton aria-label="Add item" variant="secondary"><Plus className="h-4 w-4" /></IconButton>
            <DropdownMenu trigger={({ props }) => <Button {...props} variant="secondary">Menu</Button>} items={[{ label: 'Edit' }, { label: 'Duplicate' }, { label: 'Delete', danger: true, separatorBefore: true }]} />
            <Button variant="secondary" onClick={() => toast.push({ title: 'Saved', description: 'Toast example', tone: 'success' })}>Toast</Button>
          </div></Card>
          <Dialog open={dlg} onClose={() => setDlg(false)} title="Example dialog" description="Focus is trapped; Esc closes." footer={<Button onClick={() => setDlg(false)}>Done</Button>}><p className="text-sm">Dialog body.</p></Dialog>
          <ConfirmDialog open={confirm} onClose={() => setConfirm(false)} title="Close matter?" description="Closure needs a recorded reason." requireReason="Reason for closing" confirmLabel="Close matter" onConfirm={() => setConfirm(false)} />
          <Drawer open={drawer} onClose={() => setDrawer(false)} title="Example drawer"><p className="text-sm">Drawer content.</p></Drawer>
        </TabPanel>
        <TabPanel id="states" value={tab} className="space-y-6">
          <SimulatedBanner>Identity provider is a demonstration adapter.</SimulatedBanner>
          <div className="grid gap-4 lg:grid-cols-2">
            <Card><LoadingState rows={2} /></Card><Card><EmptyState description="Nothing to show for these filters." /></Card>
            <Card><ErrorState error={new Error('Something failed')} onRetry={() => undefined} /></Card><Card><PermissionDenied permission="ledger.read" /></Card>
            <Card><PermissionDenied matter /></Card><Card><IntegrationUnavailable name="Electronic signature" setupHint="Configure ESIGN_PROVIDER and credentials." mockAvailable /></Card>
            <Card><NotFoundState what="matter" /></Card>
          </div>
        </TabPanel>
      </div>
    </>
  )
}
