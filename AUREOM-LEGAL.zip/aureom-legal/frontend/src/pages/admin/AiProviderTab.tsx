import { Bot, Lock, ShieldCheck } from 'lucide-react'
import { Badge, Card, EmptyState, ErrorState, IntegrationUnavailable, KeyValue, LoadingState, PermissionDenied, SimulatedBanner } from '@/components/ui'
import { ApiError, useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { AiProviderInfo } from '@/types/admin'
import { Generic } from './shared'

export function AiProviderTab() {
  const q = useApiQuery<AiProviderInfo>(['agents', 'provider'], '/agents/provider')
  if (q.isPending) return <LoadingState rows={4} />
  if (q.isError) {
    const e = q.error
    if (e instanceof ApiError) {
      if (e.status === 404) return <EmptyState icon={<Bot className="h-5 w-5" />} title="AI provider details are not available" description="The AI workspace service did not respond with a provider endpoint in this deployment. Nothing is sent to any model provider." />
      if (e.status === 403) return <PermissionDenied permission="ai.use" />
      if (e.isIntegrationUnavailable) return <IntegrationUnavailable name="AI provider" message={e.message} setupHint={(e.details.setup_hint as string | undefined) ?? 'Set AI_PROVIDER and, for a live provider, a server-side API key.'} mockAvailable />
    }
    return <ErrorState error={e} onRetry={() => void q.refetch()} />
  }
  const d = q.data
  const mock = d.integration.mode === 'mock'
  return (
    <div className="space-y-6">
      {mock && <SimulatedBanner>The AI provider is the local MOCK: deterministic heuristic extraction on this server. It is not a language model and nothing leaves the application.</SimulatedBanner>}
      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="Provider configuration" actions={<Badge tone={mock ? 'simulated' : d.integration.mode === 'live' ? 'success' : 'danger'}>{mock ? 'MOCK' : humanise(d.integration.mode)}</Badge>}>
          <KeyValue columns={2} items={[
            { label: 'Active provider', value: d.active_provider ?? 'none' }, { label: 'Model', value: <span className="font-mono text-xs">{d.model ?? '—'}</span> },
            { label: 'Data residency', value: d.data_residency.toUpperCase() }, { label: 'Provider integration', value: d.integration.name },
            { label: 'AI workspace', value: d.settings.enabled ? 'Enabled' : 'Disabled' }, { label: 'Read-only runs auto-complete', value: d.settings.auto_complete_readonly ? 'Yes' : 'No' },
            { label: 'Monthly budget', value: `£${d.settings.monthly_budget_gbp}` }, { label: 'Per-run budget', value: `£${d.settings.per_run_budget_gbp}` },
            { label: 'Runs per user per day', value: d.settings.user_daily_runs }, { label: 'Agents enabled', value: d.settings.allowed_agents.map(humanise).join(', ') || 'none' }]} />
          <p className="mt-4 text-xs text-stone-600">{d.integration.description}</p>
        </Card>
        <Card title="Privacy commitments" actions={<ShieldCheck className="h-4 w-4 text-ok-600" aria-hidden />}>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-3 rounded-md border border-stone-300 bg-stone-100 p-3"><Lock className="mt-0.5 h-4 w-4 shrink-0 text-stone-600" aria-hidden />
              <div><p className="font-semibold text-stone-900">No training on matter content</p><p className="mt-0.5 text-xs text-stone-700">{d.training_note}</p></div></div>
            <p className="text-stone-800">{d.logging}</p>
            <div><p className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-600">Never sent to a provider</p>
              <ul className="list-disc space-y-0.5 pl-5 text-sm text-stone-800">{d.never_sent.map((n) => <li key={n}>{n}</li>)}</ul></div>
          </div>
        </Card>
      </div>
      <Card title="What information would leave the application" description="If a live provider were enabled, this is the content each agent would send (only records the requesting user is permitted to read).">
        <div className="mb-4 rounded-md bg-ivory-100 p-3 text-sm text-stone-800"><span className="font-semibold">Provider statement: </span>{d.integration.data_leaves_application}</div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Object.entries(d.egress_by_agent).map(([agent, what]) => (
            <section key={agent} aria-label={humanise(agent)} className="rounded-lg border border-stone-200 p-3"><h3 className="mb-1.5 text-sm font-semibold text-navy-900">{humanise(agent)}</h3><div className="text-sm"><Generic value={what} /></div></section>))}
        </div>
      </Card>
    </div>
  )
}
