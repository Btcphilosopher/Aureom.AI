import { useEffect, useState } from 'react'
import { KeyRound, Plus } from 'lucide-react'
import { Badge, Button, Checkbox, DataTable, DateTime, Dialog, Field, Input, SearchInput, Select, StatusBadge, type Column } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useAuth } from '@/lib/auth'
import { useDebounce } from '@/hooks'
import type { AdminUser, OfficeRow, RolesResponse, TeamRow } from '@/types/admin'
import type { Page } from '@/types/api'

interface Form { email: string; name: string; role_key: string; job_title: string; office_id: string; team_id: string; grade: string; password: string; is_active: boolean }
const blank: Form = { email: '', name: '', role_key: '', job_title: '', office_id: '', team_id: '', grade: '', password: '', is_active: true }

export function UsersTab() {
  const { me } = useAuth()
  const [search, setSearch] = useState('')
  const dq = useDebounce(search)
  const [offset, setOffset] = useState(0)
  const [editing, setEditing] = useState<AdminUser | 'new' | null>(null)
  const [pw, setPw] = useState<AdminUser | null>(null)
  const q = useApiQuery<Page<AdminUser>>(['admin', 'users', dq, offset], `/admin/users${qs({ q: dq, limit: 25, offset })}`)
  const cols: Column<AdminUser>[] = [
    { key: 'n', header: 'Name', cell: (u) => <span className="block"><span className="font-medium text-navy-900">{u.name}</span>{u.id === me?.user.id && <Badge className="ml-2" tone="brass">You</Badge>}<span className="block text-xs text-stone-600">{u.email}</span></span> },
    { key: 'r', header: 'Role', cell: (u) => u.role_name },
    { key: 'o', header: 'Office / team', hideOnNarrow: true, cell: (u) => <span className="text-xs">{u.office ?? '—'}<br />{u.team ?? ''}</span> },
    { key: 'l', header: 'Last sign-in', hideOnNarrow: true, cell: (u) => <DateTime value={u.last_login_at} mode="relative" /> },
    { key: 's', header: 'Status', cell: (u) => <StatusBadge status={u.is_active ? 'active' : 'inactive'} /> },
    { key: 'a', header: <span className="sr-only">Actions</span>, align: 'right', cell: (u) => <Button size="sm" variant="ghost" icon={<KeyRound className="h-3.5 w-3.5" />} onClick={(e) => { e.stopPropagation(); setPw(u) }}>Reset password</Button> },
  ]
  return (
    <>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <SearchInput value={search} onValueChange={(v) => { setSearch(v); setOffset(0) }} placeholder="Search name or email…" className="w-72" aria-label="Search users" />
        <Button className="ml-auto" icon={<Plus className="h-4 w-4" />} onClick={() => setEditing('new')}>New user</Button>
      </div>
      <DataTable caption="Users" columns={cols} rows={q.data?.items} rowKey={(u) => u.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(u) => setEditing(u)}
        emptyTitle="No users found" pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} />
      <UserDialog target={editing} onClose={() => setEditing(null)} />
      <PasswordDialog user={pw} onClose={() => setPw(null)} />
    </>
  )
}

function UserDialog({ target, onClose }: { target: AdminUser | 'new' | null; onClose: () => void }) {
  const isNew = target === 'new'
  const user = target && target !== 'new' ? target : null
  const roles = useApiQuery<RolesResponse>(['admin', 'roles'], '/admin/roles', { enabled: !!target })
  const offices = useApiQuery<{ items: OfficeRow[] }>(['admin', 'offices'], '/admin/offices', { enabled: !!target })
  const teams = useApiQuery<{ items: TeamRow[] }>(['admin', 'teams'], '/admin/teams', { enabled: !!target })
  const [f, setF] = useState<Form>(blank)
  const [err, setErr] = useState<string | null>(null)
  const [sub, setSub] = useState(false)
  useEffect(() => {
    if (!target) return
    setErr(null); setSub(false)
    setF(user ? { email: user.email, name: user.name, role_key: user.role_key ?? '', job_title: user.job_title ?? '', office_id: user.office_id ?? '', team_id: user.team_id ?? '', grade: user.grade ?? '', password: '', is_active: user.is_active } : blank)
  }, [target]) // eslint-disable-line react-hooks/exhaustive-deps
  const set = (p: Partial<Form>) => setF((x) => ({ ...x, ...p }))
  const m = useApiMutation(() => isNew
    ? api.post('/admin/users', { email: f.email.trim(), name: f.name.trim(), role_key: f.role_key, job_title: f.job_title || null, office_id: f.office_id || null, team_id: f.team_id || null, grade: f.grade || null, password: f.password || null })
    : api.patch(`/admin/users/${user!.id}`, { expected_version: user!.version, name: f.name.trim(), role_key: f.role_key, job_title: f.job_title || null, office_id: f.office_id || null, team_id: f.team_id || null, grade: f.grade || null, is_active: f.is_active }),
    { invalidate: [['admin', 'users']], successMessage: isNew ? 'User created' : 'User updated', errorToast: false, onSuccess: () => onClose(),
      onError: (e) => setErr(e.isConflict && e.code === 'version_conflict' ? 'This user was changed by someone else. Close this dialog and reopen it to see the latest version.' : e.message) })
  const emailErr = sub && isNew && !/^\S+@\S+\.\S+$/.test(f.email) ? 'Enter a valid email address.' : undefined
  const pwErr = sub && isNew && f.password && f.password.length < 12 ? 'Passwords need at least 12 characters.' : undefined
  const submit = () => { setSub(true); if (!f.name.trim() || !f.role_key || emailErr || pwErr || (isNew && !/^\S+@\S+\.\S+$/.test(f.email))) return; m.mutate() }
  const roleChanged = !!user && f.role_key !== (user.role_key ?? '')
  return (
    <Dialog open={!!target} onClose={onClose} size="lg" title={isNew ? 'New user' : user?.name ?? 'User'} description={isNew ? 'Create a staff or client user. They can sign in with the password below (or via SSO when configured).' : user?.email}
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={m.isPending} onClick={submit}>{isNew ? 'Create user' : 'Save changes'}</Button></>}>
      <div className="space-y-4">
        {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name" required error={sub && !f.name.trim() ? 'A name is required.' : undefined}><Input value={f.name} onChange={(e) => set({ name: e.target.value })} data-autofocus /></Field>
          <Field label="Email" required={isNew} error={emailErr}><Input type="email" value={f.email} disabled={!isNew} onChange={(e) => set({ email: e.target.value })} /></Field>
          <Field label="Role" required error={sub && !f.role_key ? 'Choose a role.' : undefined}><Select value={f.role_key} onChange={(e) => set({ role_key: e.target.value })}><option value="">Select…</option>{roles.data?.items.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}</Select></Field>
          <Field label="Job title"><Input value={f.job_title} onChange={(e) => set({ job_title: e.target.value })} /></Field>
          <Field label="Office"><Select value={f.office_id} onChange={(e) => set({ office_id: e.target.value })}><option value="">None</option>{offices.data?.items.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select></Field>
          <Field label="Team" hint="Teams are used for ethical-wall rules."><Select value={f.team_id} onChange={(e) => set({ team_id: e.target.value })}><option value="">None</option>{teams.data?.items.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</Select></Field>
          <Field label="Grade" hint="Used to pick the rate-card rate (e.g. partner, solicitor, paralegal)."><Input value={f.grade} onChange={(e) => set({ grade: e.target.value })} /></Field>
          {isNew && <Field label="Initial password" hint="Minimum 12 characters. Leave blank for SSO-only accounts." error={pwErr}><Input type="password" autoComplete="new-password" value={f.password} onChange={(e) => set({ password: e.target.value })} /></Field>}
        </div>
        {!isNew && <Checkbox label="Account is active" hint="Deactivating revokes all of this user's sessions immediately." checked={f.is_active} onChange={(e) => set({ is_active: e.target.checked })} />}
        {roleChanged && <p role="note" className="rounded border border-warn-100 bg-warn-50 px-3 py-2 text-sm text-warn-700">Changing a role changes what this person can do. The change is recorded in the audit log as a permission change.</p>}
      </div>
    </Dialog>
  )
}

function PasswordDialog({ user, onClose }: { user: AdminUser | null; onClose: () => void }) {
  const [p, setP] = useState('')
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => { setP(''); setErr(null) }, [user])
  const m = useApiMutation(() => api.post(`/admin/users/${user!.id}/reset-password`, { password: p }), { successMessage: 'Password reset; sessions revoked', errorToast: false, onSuccess: () => onClose(), onError: (e) => setErr(e.message) })
  return (
    <Dialog open={!!user} onClose={onClose} size="sm" title={`Reset password — ${user?.name}`} description="All of this user's active sessions are signed out and any lockout is cleared."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={p.length < 12} loading={m.isPending} onClick={() => m.mutate()}>Reset password</Button></>}>
      {err && <p role="alert" className="mb-3 text-sm text-bad-700">{err}</p>}
      <Field label="New password" required hint="At least 12 characters. Share it with the user through a secure channel."><Input type="password" autoComplete="new-password" value={p} onChange={(e) => setP(e.target.value)} data-autofocus /></Field>
    </Dialog>
  )
}
