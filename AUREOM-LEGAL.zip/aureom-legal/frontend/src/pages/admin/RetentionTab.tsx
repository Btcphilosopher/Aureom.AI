import { useState } from 'react'
import { Plus } from 'lucide-react'
import { Badge, Button, DataTable, Dialog, Field, Input, Select, Textarea, type Column } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { RetentionRow } from '@/types/admin'

export function RetentionTab() {
  const q = useApiQuery<{ items: RetentionRow[]; note: string }>(['admin', 'retention'], '/admin/retention')
  const [edit, setEdit] = useState<RetentionRow | 'new' | null>(null)
  const cols: Column<RetentionRow>[] = [
    { key: 'n', header: 'Policy', cell: (r) => <span className="block"><span className="font-medium text-navy-900">{r.name}</span><span className="block font-mono text-2xs text-stone-500">{r.key}</span></span> },
    { key: 'y', header: 'Years from closure', numeric: true, cell: (r) => r.years },
    { key: 'a', header: 'At expiry', cell: (r) => humanise(r.action_at_expiry) }, { key: 'd', header: 'Description', hideOnNarrow: true, cell: (r) => <span className="text-xs text-stone-700">{r.description ?? '—'}</span> },
    { key: 's', header: 'Status', cell: (r) => <Badge tone={r.is_active ? 'success' : 'neutral'}>{r.is_active ? 'Active' : 'Inactive'}</Badge> }]
  return (
    <>
      <div className="mb-4 flex items-start justify-between gap-4">
        <p className="max-w-3xl rounded-lg border border-stone-200 bg-ivory-100 px-4 py-3 text-sm text-stone-700">{q.data?.note ?? 'Retention periods are configurable defaults for demonstration and must be set by the compliance function. A legal hold always overrides retention expiry. Destruction is not automated.'}</p>
        <Button icon={<Plus className="h-4 w-4" />} onClick={() => setEdit('new')}>New policy</Button>
      </div>
      <DataTable caption="Retention policies" columns={cols} rows={q.data?.items} rowKey={(r) => r.id} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(r) => setEdit(r)} emptyTitle="No retention policies" />
      <RetentionDialog target={edit} onClose={() => setEdit(null)} />
    </>
  )
}

function RetentionDialog({ target, onClose }: { target: RetentionRow | 'new' | null; onClose: () => void }) {
  const row = target && target !== 'new' ? target : null
  const [f, setF] = useState({ key: '', name: '', years: '6', description: '', action: 'review' })
  const [err, setErr] = useState<string | null>(null)
  const [key, setKey] = useState<string | null>(null)
  if (target && key !== (row?.id ?? 'new')) { setKey(row?.id ?? 'new'); setErr(null); setF(row ? { key: row.key, name: row.name, years: String(row.years), description: row.description ?? '', action: row.action_at_expiry } : { key: '', name: '', years: '6', description: '', action: 'review' }) }
  if (!target && key !== null) setKey(null)
  const m = useApiMutation(() => api.post('/admin/retention', { key: f.key.trim(), name: f.name.trim(), years: parseInt(f.years, 10), description: f.description || null, action_at_expiry: f.action }),
    { invalidate: [['admin', 'retention']], successMessage: 'Retention policy saved', errorToast: false, onSuccess: () => onClose(), onError: (e) => setErr(e.message) })
  const yearsOk = /^\d+$/.test(f.years) && +f.years >= 1 && +f.years <= 100
  return (
    <Dialog open={!!target} onClose={onClose} size="md" title={row ? `Edit ${row.key}` : 'New retention policy'} footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.key.trim() || !f.name.trim() || !yearsOk} loading={m.isPending} onClick={() => m.mutate()}>Save policy</Button></>}>
      <div className="space-y-4">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Key" required hint="Stable identifier used by matters."><Input value={f.key} disabled={!!row} onChange={(e) => setF({ ...f, key: e.target.value })} data-autofocus /></Field>
        <Field label="Name" required><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Years from closure" required error={!yearsOk ? 'Between 1 and 100.' : undefined}><Input inputMode="numeric" value={f.years} onChange={(e) => setF({ ...f, years: e.target.value })} /></Field>
          <Field label="Action at expiry"><Select value={f.action} onChange={(e) => setF({ ...f, action: e.target.value })}><option value="review">Review</option><option value="destroy_after_review">Destroy after review</option></Select></Field></div>
        <Field label="Description"><Textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field></div>
    </Dialog>)
}
