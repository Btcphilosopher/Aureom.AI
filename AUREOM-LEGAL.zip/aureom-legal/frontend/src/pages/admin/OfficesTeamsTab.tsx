import { useState } from 'react'
import { Plus } from 'lucide-react'
import { Button, Card, DataTable, Dialog, Field, Input, Select, type Column } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import { PRACTICE_AREAS } from './constants'
import type { OfficeRow, TeamRow } from '@/types/admin'

export function OfficesTeamsTab() {
  const offices = useApiQuery<{ items: OfficeRow[] }>(['admin', 'offices'], '/admin/offices')
  const teams = useApiQuery<{ items: TeamRow[] }>(['admin', 'teams'], '/admin/teams')
  const [dlg, setDlg] = useState<'office' | 'team' | null>(null)
  const oc: Column<OfficeRow>[] = [
    { key: 'n', header: 'Office', cell: (o) => <span className="font-medium text-navy-900">{o.name}</span> }, { key: 'c', header: 'City', cell: (o) => o.city },
    { key: 'a', header: 'Address', hideOnNarrow: true, cell: (o) => o.address ?? '—' }, { key: 't', header: 'Timezone', cell: (o) => o.timezone }]
  const tc: Column<TeamRow>[] = [
    { key: 'n', header: 'Team', cell: (t) => <span className="font-medium text-navy-900">{t.name}</span> }, { key: 'p', header: 'Practice area', cell: (t) => (t.practice_area ? humanise(t.practice_area) : '—') },
    { key: 'o', header: 'Office', cell: (t) => offices.data?.items.find((o) => o.id === t.office_id)?.name ?? '—' }]
  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <Card title="Offices" actions={<Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setDlg('office')}>Add office</Button>} padded={false}>
        <DataTable caption="Offices" columns={oc} rows={offices.data?.items} rowKey={(o) => o.id} loading={offices.isPending} error={offices.error} onRetry={() => void offices.refetch()} dense className="rounded-none border-0 shadow-none" /></Card>
      <Card title="Teams" description="Teams are the unit for ethical-wall denials." actions={<Button size="sm" icon={<Plus className="h-3.5 w-3.5" />} onClick={() => setDlg('team')}>Add team</Button>} padded={false}>
        <DataTable caption="Teams" columns={tc} rows={teams.data?.items} rowKey={(t) => t.id} loading={teams.isPending} error={teams.error} onRetry={() => void teams.refetch()} dense className="rounded-none border-0 shadow-none" /></Card>
      <OfficeDialog open={dlg === 'office'} onClose={() => setDlg(null)} />
      <TeamDialog open={dlg === 'team'} onClose={() => setDlg(null)} offices={offices.data?.items ?? []} />
    </div>
  )
}

function OfficeDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [f, setF] = useState({ name: '', city: '', address: '', timezone: 'Europe/London' })
  const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post('/admin/offices', { name: f.name.trim(), city: f.city.trim(), address: f.address || null, timezone: f.timezone }), { invalidate: [['admin']], successMessage: 'Office created', errorToast: false, onSuccess: () => { setF({ name: '', city: '', address: '', timezone: 'Europe/London' }); onClose() }, onError: (e) => setErr(e.message) })
  return (
    <Dialog open={open} onClose={onClose} title="New office" size="md" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.name.trim() || !f.city.trim()} loading={m.isPending} onClick={() => m.mutate()}>Create office</Button></>}>
      <div className="space-y-4">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Name" required><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} data-autofocus /></Field>
        <Field label="City" required><Input value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} /></Field>
        <Field label="Address"><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field>
        <Field label="Timezone"><Input value={f.timezone} onChange={(e) => setF({ ...f, timezone: e.target.value })} /></Field></div>
    </Dialog>)
}

function TeamDialog({ open, onClose, offices }: { open: boolean; onClose: () => void; offices: OfficeRow[] }) {
  const [f, setF] = useState({ name: '', practice_area: '', office_id: '' })
  const [err, setErr] = useState<string | null>(null)
  const m = useApiMutation(() => api.post('/admin/teams', { name: f.name.trim(), practice_area: f.practice_area || null, office_id: f.office_id || null }), { invalidate: [['admin']], successMessage: 'Team created', errorToast: false, onSuccess: () => { setF({ name: '', practice_area: '', office_id: '' }); onClose() }, onError: (e) => setErr(e.message) })
  return (
    <Dialog open={open} onClose={onClose} title="New team" size="md" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button disabled={!f.name.trim()} loading={m.isPending} onClick={() => m.mutate()}>Create team</Button></>}>
      <div className="space-y-4">{err && <p role="alert" className="text-sm text-bad-700">{err}</p>}
        <Field label="Name" required><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} data-autofocus /></Field>
        <Field label="Practice area"><Select value={f.practice_area} onChange={(e) => setF({ ...f, practice_area: e.target.value })}><option value="">None</option>{PRACTICE_AREAS.map((p) => <option key={p} value={p}>{humanise(p)}</option>)}</Select></Field>
        <Field label="Office"><Select value={f.office_id} onChange={(e) => setF({ ...f, office_id: e.target.value })}><option value="">None</option>{offices.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select></Field></div>
    </Dialog>)
}
