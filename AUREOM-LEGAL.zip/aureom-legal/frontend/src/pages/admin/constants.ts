export const PRACTICE_AREAS = ['commercial', 'property', 'litigation', 'employment', 'private_client', 'corporate'] as const
export const AGENT_TYPES = ['matter_briefing', 'document_review', 'chronology', 'drafting', 'knowledge', 'intake', 'billing_assistant'] as const
