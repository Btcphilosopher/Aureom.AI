import { Field, Textarea } from '@/components/ui'
import type { ReactNode } from 'react'

export const AUDIT_NOTE = 'This change is written to the append-only audit log with your name and the reason.'

export function ReasonField({ value, onChange, error }: { value: string; onChange: (v: string) => void; error?: ReactNode }) {
  return <Field label="Reason for change" required hint={AUDIT_NOTE} error={error}><Textarea rows={2} value={value} onChange={(e) => onChange(e.target.value)} /></Field>
}

/** Generic renderer for provider-supplied structures whose exact shape can vary. */
export function Generic({ value, depth = 0 }: { value: unknown; depth?: number }) {
  if (value === null || value === undefined) return <span className="text-stone-500">—</span>
  if (typeof value === 'boolean') return <span>{value ? 'Yes' : 'No'}</span>
  if (typeof value !== 'object') return <span>{String(value)}</span>
  if (Array.isArray(value)) return value.length === 0 ? <span className="text-stone-500">none</span> : (
    <ul className="list-disc space-y-0.5 pl-5">{value.map((v, i) => <li key={i}><Generic value={v} depth={depth + 1} /></li>)}</ul>)
  return (
    <dl className={depth ? 'space-y-1 border-l border-stone-200 pl-3' : 'space-y-2'}>
      {Object.entries(value as Record<string, unknown>).map(([k, v]) => (
        <div key={k}><dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">{k.replace(/_/g, ' ')}</dt><dd className="text-sm text-stone-900"><Generic value={v} depth={depth + 1} /></dd></div>))}
    </dl>)
}
