import { Cable, CloudOff, FlaskConical, Radio } from 'lucide-react'
import { Badge, Card, IntegrationUnavailable, QueryBoundary, SimulatedBanner } from '@/components/ui'
import { useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { IntegrationRow } from '@/types/admin'

const MODE = {
  mock: { tone: 'simulated' as const, label: 'MOCK — simulated', Icon: FlaskConical },
  live: { tone: 'success' as const, label: 'Live', Icon: Radio },
  unavailable: { tone: 'danger' as const, label: 'Unavailable', Icon: CloudOff },
}

export function IntegrationsTab() {
  const q = useApiQuery<{ items: IntegrationRow[]; note: string }>(['integrations'], '/integrations')
  return (
    <QueryBoundary query={q} empty={<p className="text-sm text-stone-600">No integrations are registered.</p>}>
      {(d) => {
        const groups = [...new Set(d.items.map((i) => i.category))]
        return (
          <div className="space-y-6">
            <SimulatedBanner>{d.note}</SimulatedBanner>
            {groups.map((g) => (
              <section key={g} aria-labelledby={`g-${g}`}>
                <h2 id={`g-${g}`} className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-brass-700"><Cable className="h-3.5 w-3.5" aria-hidden />{humanise(g)}</h2>
                <div className="grid gap-4 lg:grid-cols-2">
                  {d.items.filter((i) => i.category === g).map((i) => {
                    const m = MODE[i.mode]
                    return (
                      <Card key={i.key} as="article" title={<span className="flex items-center gap-2"><m.Icon className="h-4 w-4 text-stone-600" aria-hidden />{i.name}</span>} actions={<Badge tone={m.tone}>{m.label}</Badge>}>
                        <p className="text-sm text-stone-800">{i.description}</p>
                        <dl className="mt-3 space-y-2 text-xs">
                          <div><dt className="font-semibold uppercase tracking-wide text-stone-600">Provider</dt><dd className="font-mono text-stone-800">{i.provider}</dd></div>
                          <div><dt className="font-semibold uppercase tracking-wide text-stone-600">What would leave the application if live</dt><dd className="mt-0.5 rounded bg-ivory-100 px-2 py-1.5 text-stone-800">{i.data_leaves_application}</dd></div>
                          {i.setup_hint && <div><dt className="font-semibold uppercase tracking-wide text-stone-600">Setup</dt><dd className="text-stone-700">{i.setup_hint}</dd></div>}
                        </dl>
                        {i.mode === 'unavailable' && <div className="mt-3"><IntegrationUnavailable name={i.name} setupHint={i.setup_hint} mockAvailable={false} className="!py-4" /></div>}
                      </Card>)
                  })}
                </div>
              </section>))}
          </div>)
      }}
    </QueryBoundary>
  )
}
