import { useState } from 'react'
import { Download, ShieldCheck } from 'lucide-react'
import { Badge, Button, DataTable, DateTime, Drawer, Field, Input, KeyValue, type Column } from '@/components/ui'
import { api, qs, useApiMutation, useApiQuery } from '@/lib/api'
import { useDebounce } from '@/hooks'
import type { AuditRow } from '@/types/admin'
import type { Page } from '@/types/api'
import { Generic } from './shared'

export function AuditTab() {
  const [action, setAction] = useState(''); const [entity, setEntity] = useState(''); const [since, setSince] = useState('')
  const dAction = useDebounce(action); const dEntity = useDebounce(entity)
  const [offset, setOffset] = useState(0)
  const [open, setOpen] = useState<AuditRow | null>(null)
  const [exportErr, setExportErr] = useState<string | null>(null)
  const params = { action: dAction, entity_type: dEntity, since: since ? new Date(since).toISOString() : undefined, limit: 30, offset }
  const q = useApiQuery<Page<AuditRow>>(['admin', 'audit', params], `/admin/audit${qs(params)}`)
  const verify = useApiMutation(() => api.get<{ ok: boolean; checked: number; first_bad_id: number | null }>('/admin/audit/verify'), { invalidate: [['admin', 'audit']], errorToast: true })
  const exportCsv = async () => {
    setExportErr(null)
    try {
      const blob = await api.blob(`/admin/audit.csv${qs({ action: dAction, entity_type: dEntity, since: params.since })}`)
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'audit.csv'; a.click(); URL.revokeObjectURL(a.href)
    } catch (e) { setExportErr((e as Error).message) }
  }
  const cols: Column<AuditRow>[] = [
    { key: 't', header: 'When', cell: (e) => <span className="whitespace-nowrap text-xs"><DateTime value={e.occurred_at} /></span> },
    { key: 'a', header: 'Actor', hideOnNarrow: true, cell: (e) => <span className="text-xs">{e.actor}{e.actor_type !== 'user' && <Badge className="ml-1" tone={e.actor_type === 'agent' ? 'simulated' : 'neutral'}>{e.actor_type}</Badge>}</span> },
    { key: 'ac', header: 'Action', cell: (e) => <span className="font-mono text-xs">{e.action}</span> },
    { key: 's', header: 'Summary', cell: (e) => <span className="text-sm">{e.summary}</span> },
    { key: 'h', header: 'Hash', hideOnNarrow: true, cell: (e) => <span className="font-mono text-2xs text-stone-500">{e.hash}</span> },
  ]
  const v = verify.data
  return (
    <>
      <p className="mb-4 max-w-3xl text-sm text-stone-700">The audit log is append-only and hash-chained: records cannot be edited or deleted, and any gap or alteration is detectable. Confidential document and email text is never stored in it. Events on matters you cannot access are not shown.</p>
      <div className="mb-4 flex flex-wrap items-end gap-3 rounded-lg border border-stone-200 bg-white px-4 py-3 shadow-panel" role="search" aria-label="Audit filters">
        <Field label="Action starts with"><Input value={action} onChange={(e) => { setAction(e.target.value); setOffset(0) }} placeholder="e.g. admin." className="w-48" /></Field>
        <Field label="Entity type"><Input value={entity} onChange={(e) => { setEntity(e.target.value); setOffset(0) }} placeholder="e.g. matter" className="w-40" /></Field>
        <Field label="Since"><Input type="date" value={since} onChange={(e) => { setSince(e.target.value); setOffset(0) }} className="w-40" /></Field>
        <div className="ml-auto flex gap-2">
          <Button variant="secondary" icon={<ShieldCheck className="h-4 w-4" />} loading={verify.isPending} onClick={() => verify.mutate()}>Verify chain</Button>
          <Button variant="secondary" icon={<Download className="h-4 w-4" />} onClick={() => void exportCsv()}>Export CSV</Button>
        </div>
      </div>
      {v && <p role="status" className={`mb-4 rounded-lg border px-4 py-3 text-sm ${v.ok ? 'border-ok-100 bg-ok-50 text-ok-700' : 'border-bad-100 bg-bad-50 text-bad-700'}`}>{v.ok ? `Chain verified: ${v.checked} events checked, no alteration or gap detected.` : `INTEGRITY FAILURE at event #${v.first_bad_id} after ${v.checked} valid events. Escalate to the compliance function.`}</p>}
      {exportErr && <p role="alert" className="mb-4 text-sm text-bad-700">{exportErr}</p>}
      <p className="mb-2 text-xs text-stone-600">CSV export is itself audited as a sensitive export and excludes matter-linked events.</p>
      <DataTable caption="Audit events" columns={cols} rows={q.data?.items} rowKey={(e) => String(e.id)} loading={q.isPending} error={q.error} onRetry={() => void q.refetch()} onRowClick={(e) => setOpen(e)} dense
        emptyTitle="No audit events match" pagination={q.data ? { total: q.data.total, limit: q.data.limit, offset: q.data.offset, onChange: setOffset } : undefined} />
      <Drawer open={!!open} onClose={() => setOpen(null)} title={open?.action ?? 'Audit event'}>
        {open && <div className="space-y-5">
          <p className="text-sm text-stone-900">{open.summary}</p>
          <KeyValue columns={2} items={[{ label: 'Event #', value: open.id }, { label: 'When', value: <DateTime value={open.occurred_at} /> }, { label: 'Actor', value: open.actor }, { label: 'Actor type', value: open.actor_type },
            { label: 'Entity', value: `${open.entity_type}${open.entity_id ? ` · ${open.entity_id.slice(0, 8)}…` : ''}` }, { label: 'Matter', value: open.matter_id ? `${open.matter_id.slice(0, 8)}…` : '—' }, { label: 'Hash (prefix)', value: <span className="font-mono text-xs">{open.hash}</span> }]} />
          <section><h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-stone-700">Details</h3><div className="rounded border border-stone-200 bg-ivory-100 p-3"><Generic value={open.details} /></div></section>
        </div>}
      </Drawer>
    </>
  )
}
