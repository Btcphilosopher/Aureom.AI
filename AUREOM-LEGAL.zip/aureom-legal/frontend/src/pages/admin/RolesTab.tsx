import { Fragment, useEffect, useMemo, useState } from 'react'
import { Check, Pencil, ShieldAlert } from 'lucide-react'
import { Button, Checkbox, Dialog, QueryBoundary, Badge } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { AdminRole, RolesResponse } from '@/types/admin'
import { AUDIT_NOTE, ReasonField } from './shared'

export function RolesTab() {
  const q = useApiQuery<RolesResponse>(['admin', 'roles'], '/admin/roles')
  const [edit, setEdit] = useState<AdminRole | null>(null)
  return (
    <QueryBoundary query={q}>{(d) => <Matrix d={d} onEdit={setEdit} edit={edit} onClose={() => setEdit(null)} />}</QueryBoundary>
  )
}

function Matrix({ d, onEdit, edit, onClose }: { d: RolesResponse; onEdit: (r: AdminRole) => void; edit: AdminRole | null; onClose: () => void }) {
  const groups = useMemo(() => {
    const m = new Map<string, string[]>()
    d.catalogue.forEach((p) => { const g = p.split('.')[0]!; m.set(g, [...(m.get(g) ?? []), p]) })
    return [...m]
  }, [d.catalogue])
  return (
    <>
      <p className="mb-4 flex items-start gap-2 rounded-lg border border-warn-100 bg-warn-50 px-4 py-3 text-sm text-warn-700"><ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />Permission changes take effect immediately for every user with the role, and are audited with your reason. Matter-level access (restricted matters, ethical walls) is applied in addition to role permissions.</p>
      <div className="overflow-auto rounded-lg border border-stone-200 bg-white shadow-panel">
        <table className="w-full border-collapse text-sm">
          <caption className="sr-only">Permission matrix: permissions by role</caption>
          <thead className="sticky top-0 bg-ivory-200"><tr className="border-b border-stone-300">
            <th scope="col" className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-stone-700">Permission</th>
            {d.items.map((r) => (
              <th key={r.id} scope="col" className="px-3 py-3 text-center text-xs font-semibold text-stone-800">
                <span className="block">{r.name}</span><span className="block text-2xs font-normal text-stone-600">{r.users} user{r.users === 1 ? '' : 's'}</span>
                <Button size="sm" variant="ghost" className="mt-1" icon={<Pencil className="h-3 w-3" />} onClick={() => onEdit(r)} aria-label={`Edit permissions for ${r.name}`}>Edit</Button>
              </th>))}
          </tr></thead>
          <tbody>
            {groups.map(([g, perms]) => (
              <Fragment key={g}>
                <tr className="bg-ivory-100"><th scope="rowgroup" colSpan={d.items.length + 1} className="px-4 py-1.5 text-left text-2xs font-semibold uppercase tracking-[0.12em] text-brass-700">{humanise(g)}</th></tr>
                {perms.map((p) => (
                  <tr key={p} className="border-b border-stone-100">
                    <th scope="row" className="px-4 py-1.5 text-left font-mono text-xs font-normal text-stone-800">{p}</th>
                    {d.items.map((r) => {
                      const has = r.permissions.includes(p); const isDefault = d.defaults[r.key]?.includes(p) ?? false
                      return <td key={r.id} className="px-3 py-1.5 text-center">{has ? <><Check className="mx-auto h-4 w-4 text-ok-600" aria-hidden /><span className="sr-only">Granted{!isDefault ? ' (customised)' : ''}</span>{!isDefault && <span className="text-2xs text-brass-700" aria-hidden>custom</span>}</> : <><span className="text-stone-300" aria-hidden>·</span><span className="sr-only">Not granted</span></>}</td>
                    })}
                  </tr>))}
              </Fragment>))}
          </tbody>
        </table>
      </div>
      <EditRole d={d} role={edit} onClose={onClose} groups={groups} />
    </>
  )
}

function EditRole({ d, role, onClose, groups }: { d: RolesResponse; role: AdminRole | null; onClose: () => void; groups: [string, string[]][] }) {
  const [sel, setSel] = useState<Set<string>>(new Set())
  const [reason, setReason] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [sub, setSub] = useState(false)
  useEffect(() => { if (role) { setSel(new Set(role.permissions)); setReason(''); setErr(null); setSub(false) } }, [role])
  const m = useApiMutation(() => api.put(`/admin/roles/${role!.id}`, { permissions: [...sel], reason }), { invalidate: [['admin', 'roles']], successMessage: 'Role permissions updated', errorToast: false, onSuccess: () => onClose(), onError: (e) => setErr(e.message) })
  const added = role ? [...sel].filter((p) => !role.permissions.includes(p)) : []
  const removed = role ? role.permissions.filter((p) => !sel.has(p)) : []
  return (
    <Dialog open={!!role} onClose={onClose} size="xl" title={`Permissions — ${role?.name}`} description={AUDIT_NOTE}
      footer={<><Button variant="ghost" className="mr-auto" onClick={() => role && setSel(new Set(d.defaults[role.key] ?? []))}>Reset to defaults</Button><Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button disabled={!added.length && !removed.length} loading={m.isPending} onClick={() => { setSub(true); if (reason.trim().length >= 5) m.mutate() }}>Save permissions</Button></>}>
      {err && <p role="alert" className="mb-3 rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
      <div className="grid gap-5 sm:grid-cols-2">
        {groups.map(([g, perms]) => (
          <fieldset key={g}><legend className="mb-1 text-xs font-semibold uppercase tracking-wide text-brass-700">{humanise(g)}</legend>
            <div className="space-y-1">{perms.map((p) => <Checkbox key={p} label={<span className="font-mono text-xs">{p}</span>} checked={sel.has(p)} onChange={(e) => setSel((s) => { const n = new Set(s); if (e.target.checked) n.add(p); else n.delete(p); return n })} />)}</div></fieldset>))}
      </div>
      <div className="mt-5 space-y-3 border-t border-stone-200 pt-4">
        {(added.length > 0 || removed.length > 0) && <p className="text-sm" role="status">{added.length > 0 && <><Badge tone="success">+{added.length}</Badge> <span className="font-mono text-xs">{added.join(', ')}</span> </>}{removed.length > 0 && <><Badge tone="danger">−{removed.length}</Badge> <span className="font-mono text-xs">{removed.join(', ')}</span></>}</p>}
        <ReasonField value={reason} onChange={setReason} error={sub && reason.trim().length < 5 ? 'Enter a reason of at least 5 characters.' : undefined} />
      </div>
    </Dialog>
  )
}
