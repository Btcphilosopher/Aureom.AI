import { useEffect, useState } from 'react'
import { Lock } from 'lucide-react'
import { Button, Card, Checkbox, Field, Input, QueryBoundary, Select, Badge } from '@/components/ui'
import { api, useApiMutation, useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { CheckType, FirmSettings } from '@/types/admin'
import { AGENT_TYPES } from './constants'
import { ReasonField } from './shared'

export function SettingsTab() {
  const q = useApiQuery<FirmSettings>(['admin', 'settings'], '/admin/settings')
  return <QueryBoundary query={q}>{(d) => <SettingsForm d={d} />}</QueryBoundary>
}

function SettingsForm({ d }: { d: FirmSettings }) {
  const s = d.settings
  const [prefix, setPrefix] = useState(s.client_reference_prefix ?? '')
  const [vat, setVat] = useState(s.vat_rate ?? '20.00')
  const [types, setTypes] = useState<CheckType[]>(s.onboarding_check_types ?? [])
  const [required, setRequired] = useState<string[]>(s.onboarding_required_checks ?? [])
  const [fourEyes, setFourEyes] = useState(s.finance?.four_eyes ?? true)
  const [ai, setAi] = useState({ enabled: s.ai?.enabled ?? true, auto: s.ai?.auto_complete_readonly ?? true, monthly: String(s.ai?.monthly_budget_gbp ?? '50'), perRun: String(s.ai?.per_run_budget_gbp ?? '2'), daily: String(s.ai?.user_daily_runs ?? 40), agents: s.ai?.allowed_agents ?? [...AGENT_TYPES] })
  const [residency, setResidency] = useState(d.data_residency)
  const [reason, setReason] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [sub, setSub] = useState(false)
  useEffect(() => { setErr(null) }, [d])
  const num = (v: string) => (v.trim() !== '' && !isNaN(Number(v)) && Number(v) >= 0)
  const vatOk = /^\d{1,2}(\.\d{1,2})?$/.test(vat)
  const valid = vatOk && num(ai.monthly) && num(ai.perRun) && /^\d+$/.test(ai.daily) && prefix.trim().length > 0 && reason.trim().length >= 5
  const m = useApiMutation(() => api.put('/admin/settings', {
    reason, data_residency: residency !== d.data_residency ? residency : null,
    settings: {
      client_reference_prefix: prefix.trim(), vat_rate: vat, onboarding_check_types: types, onboarding_required_checks: required,
      finance: { ...(s.finance ?? {}), four_eyes: fourEyes },
      ai: { ...(s.ai ?? {}), enabled: ai.enabled, auto_complete_readonly: ai.auto, monthly_budget_gbp: Number(ai.monthly), per_run_budget_gbp: Number(ai.perRun), user_daily_runs: parseInt(ai.daily, 10), allowed_agents: ai.agents, train_on_matter_content: false },
    } }), { invalidate: [['admin', 'settings'], ['agents']], successMessage: 'Settings saved', errorToast: false, onSuccess: () => { setReason(''); setSub(false); setErr(null) }, onError: (e) => setErr(e.message) })
  const toggleReq = (k: string, on: boolean) => setRequired((r) => (on ? [...new Set([...r, k])] : r.filter((x) => x !== k)))
  return (
    <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setSub(true); if (valid) m.mutate() }} aria-label="Firm settings">
      {err && <p role="alert" className="rounded border border-bad-100 bg-bad-50 px-3 py-2 text-sm text-bad-700">{err}</p>}
      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="General & billing" description={`${d.name} · ${d.slug}`}>
          <div className="space-y-4">
            <Field label="Client reference prefix" required hint="Used when a contact is made a client."><Input value={prefix} onChange={(e) => setPrefix(e.target.value)} /></Field>
            <Field label="Default VAT rate (%)" required error={sub && !vatOk ? 'Enter a percentage such as 20.00.' : undefined} hint="Applied to new invoice lines. Stored and used as an exact decimal."><Input value={vat} inputMode="decimal" onChange={(e) => setVat(e.target.value)} /></Field>
            <Checkbox label="Four-eyes control on financial postings" hint="The person who prepares a posting cannot approve it. Recommended; disabling needs compliance sign-off." checked={fourEyes} onChange={(e) => setFourEyes(e.target.checked)} />
            <Field label="Data residency" hint="Informational and enforced as a gate for AI egress. Changes are audited."><Select value={residency} onChange={(e) => setResidency(e.target.value)}><option value="uk">United Kingdom</option><option value="eu">European Economic Area</option></Select></Field>
          </div>
        </Card>
        <Card title="Onboarding checks" description="Configurable check types. Identity checks use a SIMULATED adapter in this build — never a verified identity check.">
          <ul className="space-y-2">
            {types.map((t, i) => (
              <li key={t.key} className="grid grid-cols-[1fr_11rem_auto] items-end gap-2 rounded border border-stone-200 p-2">
                <Field label={<span className="font-mono normal-case">{t.key}</span>}><Input value={t.label} onChange={(e) => setTypes((x) => x.map((y, j) => (j === i ? { ...y, label: e.target.value } : y)))} /></Field>
                <Field label="Applies to"><Select value={t.applies_to} onChange={(e) => setTypes((x) => x.map((y, j) => (j === i ? { ...y, applies_to: e.target.value } : y)))}><option value="any">Any</option><option value="individual">Individuals</option><option value="organisation">Organisations</option></Select></Field>
                <div className="pb-2"><Checkbox label="Required" checked={required.includes(t.key)} onChange={(e) => toggleReq(t.key, e.target.checked)} /></div>
              </li>))}
          </ul>
          {types.length === 0 && <p className="text-sm text-stone-600">No check types configured.</p>}
        </Card>
      </div>
      <Card title="AI policy & budgets" description="Agents are read-only by default and can only propose changes. These limits are enforced before a run starts.">
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-4">
            <Checkbox label="AI workspace enabled" checked={ai.enabled} onChange={(e) => setAi({ ...ai, enabled: e.target.checked })} />
            <Checkbox label="Allow read-only runs to complete without a review step" hint="Only for runs that propose no changes." checked={ai.auto} onChange={(e) => setAi({ ...ai, auto: e.target.checked })} />
            <div className="flex items-start gap-3 rounded-md border border-stone-300 bg-stone-100 p-3" role="group" aria-label="Training on matter content (locked)">
              <Lock className="mt-0.5 h-4 w-4 shrink-0 text-stone-600" aria-hidden />
              <div><p className="text-sm font-semibold text-stone-900">Training on matter content: <Badge tone="success">Disabled</Badge></p>
                <p className="mt-0.5 text-xs text-stone-700">Locked. Matter content is never used for model training in this build and the server refuses any attempt to enable it.</p></div>
            </div>
          </div>
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Monthly budget (GBP)" error={sub && !num(ai.monthly) ? 'Enter a number.' : undefined}><Input inputMode="decimal" value={ai.monthly} onChange={(e) => setAi({ ...ai, monthly: e.target.value })} /></Field>
              <Field label="Per-run budget (GBP)" error={sub && !num(ai.perRun) ? 'Enter a number.' : undefined}><Input inputMode="decimal" value={ai.perRun} onChange={(e) => setAi({ ...ai, perRun: e.target.value })} /></Field>
              <Field label="Runs per user per day" error={sub && !/^\d+$/.test(ai.daily) ? 'Whole number.' : undefined}><Input inputMode="numeric" value={ai.daily} onChange={(e) => setAi({ ...ai, daily: e.target.value })} /></Field>
            </div>
            <fieldset><legend className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-stone-700">Agents available to users</legend>
              <div className="grid gap-1 sm:grid-cols-2">{AGENT_TYPES.map((a) => <Checkbox key={a} label={humanise(a)} checked={ai.agents.includes(a)} onChange={(e) => setAi({ ...ai, agents: e.target.checked ? [...ai.agents, a] : ai.agents.filter((x) => x !== a) })} />)}</div></fieldset>
          </div>
        </div>
      </Card>
      <Card title="Save changes">
        <div className="max-w-xl space-y-4">
          <ReasonField value={reason} onChange={setReason} error={sub && reason.trim().length < 5 ? 'Enter a reason of at least 5 characters.' : undefined} />
          <Button type="submit" loading={m.isPending}>Save settings</Button>
        </div>
      </Card>
    </form>
  )
}
