import type { ReactNode } from 'react'
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { ExternalLink } from 'lucide-react'
import { NotFoundState, PageHeader, PermissionDenied, Tabs, type TabItem } from '@/components/ui'
import { useAuth } from '@/lib/auth'
import { usePageTitle } from '@/hooks'
import { AiProviderTab } from './AiProviderTab'
import { AuditTab } from './AuditTab'
import { IntegrationsTab } from './IntegrationsTab'
import { OfficesTeamsTab } from './OfficesTeamsTab'
import { RetentionTab } from './RetentionTab'
import { RolesTab } from './RolesTab'
import { SettingsTab } from './SettingsTab'
import { SystemTab } from './SystemTab'
import { UsersTab } from './UsersTab'

interface Def { id: string; label: string; perms?: string[]; element: ReactNode }
const DEFS: Def[] = [
  { id: 'users', label: 'Users', perms: ['admin.users'], element: <UsersTab /> },
  { id: 'roles', label: 'Roles & permissions', perms: ['admin.users'], element: <RolesTab /> },
  { id: 'offices', label: 'Offices & teams', perms: ['admin.settings'], element: <OfficesTeamsTab /> },
  { id: 'settings', label: 'Firm settings', perms: ['admin.settings'], element: <SettingsTab /> },
  { id: 'retention', label: 'Retention', perms: ['admin.settings'], element: <RetentionTab /> },
  { id: 'integrations', label: 'Integrations', element: <IntegrationsTab /> },
  { id: 'ai', label: 'AI provider', element: <AiProviderTab /> },
  { id: 'audit', label: 'Audit log', perms: ['audit.read'], element: <AuditTab /> },
  { id: 'system', label: 'System & backup', perms: ['admin.settings'], element: <SystemTab /> },
]

export default function AdminSection() {
  const { can } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  usePageTitle('Administration')
  const allowed = (d: Def) => !d.perms || d.perms.every((p) => can(p))
  const current = DEFS.find((d) => loc.pathname.startsWith(`/admin/${d.id}`))?.id ?? ''
  const tabs: TabItem[] = DEFS.map((d) => ({ id: d.id, label: d.label, disabled: !allowed(d) }))
  const first = DEFS.find(allowed)
  const canTemplates = can('matters.read') || can('admin.settings')
  return (
    <>
      <PageHeader eyebrow="Administration" title="Administration" description="Users, permissions, configuration, integrations and the audit trail. Every change here is recorded." />
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <Tabs label="Administration sections" tabs={tabs} value={current} onChange={(id) => nav(`/admin/${id}`)} />
        {canTemplates && <a href="/matters/templates" onClick={(e) => { e.preventDefault(); nav('/matters/templates') }} className="inline-flex items-center gap-1 text-xs font-semibold text-navy-700 hover:text-brass-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">Matter templates <ExternalLink className="h-3 w-3" aria-hidden /></a>}
      </div>
      <Routes>
        <Route index element={first ? <Navigate to={`/admin/${first.id}`} replace /> : <PermissionDenied message="Your role has no administration functions." />} />
        {DEFS.map((d) => <Route key={d.id} path={`${d.id}/*`} element={allowed(d) ? d.element : <PermissionDenied permission={d.perms} />} />)}
        <Route path="*" element={<NotFoundState what="page" />} />
      </Routes>
    </>
  )
}
