import { AlertTriangle, DatabaseBackup } from 'lucide-react'
import { Badge, Card, KeyValue, QueryBoundary } from '@/components/ui'
import { useApiQuery } from '@/lib/api'
import { humanise } from '@/lib/format'
import type { SystemInfo } from '@/types/admin'
import { Generic } from './shared'

export function SystemTab() {
  const q = useApiQuery<SystemInfo>(['admin', 'system'], '/admin/system')
  return (
    <QueryBoundary query={q}>{(s) => (
      <div className="space-y-6">
        {s.warnings.length > 0 && (
          <div role="alert" className="rounded-lg border border-warn-100 bg-warn-50 p-4 text-sm text-warn-700">
            <p className="mb-1 flex items-center gap-2 font-semibold"><AlertTriangle className="h-4 w-4" aria-hidden />Configuration warnings</p>
            <ul className="list-disc space-y-0.5 pl-6">{s.warnings.map((w) => <li key={w}>{w}</li>)}</ul></div>)}
        <div className="grid gap-6 xl:grid-cols-2">
          <Card title="Environment">
            <KeyValue columns={2} items={[
              { label: 'Environment', value: <Badge tone={s.environment === 'production' ? 'success' : 'warning'}>{s.environment}</Badge> }, { label: 'Demo mode', value: s.demo_mode ? 'On (persona picker active)' : 'Off' },
              { label: 'Data residency (firm)', value: s.data_residency.toUpperCase() }, { label: 'Data residency (deployment)', value: s.configured_residency.toUpperCase() },
              { label: 'Session lifetime', value: `${s.session_ttl_minutes} minutes` }, { label: 'Secure cookies', value: s.cookie_secure ? 'Yes' : 'No (HTTP development)' },
              { label: 'AI provider', value: s.ai_provider }, { label: 'SSO', value: s.sso_configured ? 'Configured' : 'Not configured' }, { label: 'Max upload', value: `${s.max_upload_mb} MB` }]} />
          </Card>
          <Card title="Storage & background jobs">
            <div className="space-y-4 text-sm"><div><p className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-600">Document storage</p><Generic value={s.storage} /></div>
              <div><p className="mb-1 text-xs font-semibold uppercase tracking-wide text-stone-600">Jobs by status</p>
                {Object.keys(s.jobs).length === 0 ? <span className="text-stone-600">No jobs yet.</span> : <ul className="flex flex-wrap gap-2">{Object.entries(s.jobs).map(([k, v]) => <li key={k}><Badge tone={k === 'failed' ? 'danger' : k === 'queued' || k === 'running' ? 'info' : 'neutral'}>{humanise(k)}: {v}</Badge></li>)}</ul>}</div></div>
          </Card>
        </div>
        <Card title="Backup & restore" actions={<DatabaseBackup className="h-4 w-4 text-brass-600" aria-hidden />}>
          <p className="text-sm text-stone-800">{s.backup.summary}</p>
          <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-stone-800">
            <li><strong>Back up together:</strong> PostgreSQL (<code className="font-mono text-xs">pg_dump -Fc</code> or WAL archiving) and the document bucket, to the same point in time.</li>
            <li><strong>Restore:</strong> restore the database, restore the bucket, run migrations, then verify.</li>
            <li><strong>Verify:</strong> run <em>Verify chain</em> on the Audit log tab and spot-check document hashes against version history.</li>
            <li><strong>Protect:</strong> encrypt backups, keep them in the configured residency region, and rehearse restores.</li>
          </ol>
          <p className="mt-3 text-xs text-stone-600">Full instructions: <code className="font-mono">{s.backup.doc}</code> in the project repository. Scheduling and off-site replication are not provided by this demonstration.</p>
        </Card>
      </div>)}</QueryBoundary>
  )
}
