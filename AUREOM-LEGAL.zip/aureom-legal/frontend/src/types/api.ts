/** Shared API types. Page forks add their own domain types in src/types/<domain>.ts */
export interface Page<T> { items: T[]; total: number; limit: number; offset: number }

export interface ApiErrorBody { error: { code: string; message: string; details?: Record<string, unknown> } }

export interface MeUser {
  id: string; name: string; initials: string; email: string; job_title: string | null
  office_id: string | null; team_id: string | null; contact_id: string | null
}
export interface Me {
  user: MeUser
  role: { key: string; name: string }
  permissions: string[]
  firm: { id: string; name: string; data_residency: string }
  offices: { id: string; name: string; city: string }[]
  active_office_id: string | null
  csrf_token: string
  demo_mode: boolean
  environment: string
}
export interface Persona { email: string; name: string; role: string; job_title: string | null }

export interface SearchItem { id: string; title: string; subtitle?: string; href: string }
export interface SearchGroup { type: string; label: string; items: SearchItem[] }
export interface SearchResponse { groups: SearchGroup[] }

export interface NotificationItem { id: string; title: string; body: string | null; link: string | null; read_at: string | null; created_at: string }
export interface NotificationsResponse { items: NotificationItem[]; unread: number }

/** Decimal values from the API are strings. Never do arithmetic with Number(). */
export type DecimalString = string
