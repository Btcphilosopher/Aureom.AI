export interface Attachment { id: string; filename: string; content_type: string; size_bytes: number; scan_status: string; document_id: string | null }
export interface CorrItem {
  id: string; matter_id: string | null; matter_reference: string | null; direction: 'inbound' | 'outbound'; status: string; from_addr: string; to_addrs: string[]
  subject: string; preview: string; client_visible: boolean; is_read: boolean; has_attachments: boolean
  received_at: string | null; sent_at: string | null; created_at: string
}
export interface CorrDetail {
  id: string; matter_id: string | null; matter_reference: string | null; thread_id: string | null; direction: 'inbound' | 'outbound'; channel: string
  from_addr: string; to_addrs: string[]; cc_addrs: string[]; subject: string; body_text: string; status: string; client_visible: boolean; is_read: boolean
  received_at: string | null; sent_at: string | null; approval_id: string | null; agent_run_id: string | null; external_ref: string | null
  simulated: boolean; version: number; attachments: Attachment[]; untrusted_content: boolean; created_at: string
}
export interface Note { id: string; matter_id: string | null; correspondence_id: string | null; author_id: string; author_name: string | null; body: string; created_at: string }
export interface ClientVisibleItem { id: string; direction: string; from_addr: string; to_addrs: string[]; subject: string; body_text: string; date: string | null; attachments: string[] }
export interface ApprovalLite { id: string; status: string; payload_hash: string; decided_by_name: string | null; requested_by_name: string | null; decision_note: string | null }
