import type { DecimalString, Page } from './api'

export type { Page }

export interface MatterLite { id: string; reference: string; title: string; status: string; fee_arrangement?: string; currency?: string; client?: { id: string; name: string | null } }

export interface TimeEntry {
  id: string; matter_id: string; user_id: string; work_date: string; minutes: number; narrative: string
  rate: DecimalString; amount: DecimalString; currency: string; billable: boolean
  status: 'draft' | 'submitted' | 'approved' | 'billed' | 'written_off' | string
  source: string; timer_started_at: string | null; invoice_line_id: string | null; version: number
  matter_reference: string | null; user_name: string | null
}
export interface Expense {
  id: string; matter_id: string; user_id: string; expense_date: string; description: string; amount: DecimalString; vat_rate: DecimalString
  currency: string; billable: boolean; status: string; invoice_line_id: string | null; version: number
}
export interface RateEntry { id?: string; grade: string; hourly_rate: DecimalString; user_id?: string | null }
export interface RateCard { id: string; name: string; currency: string; is_default: boolean; is_active: boolean; entries: RateEntry[] }

export interface InvoiceLine {
  id: string; line_type: string; description: string; quantity: DecimalString; unit_amount: DecimalString; amount: DecimalString
  vat_rate: DecimalString; vat_amount: DecimalString; time_entry_id: string | null; expense_id: string | null
}
export interface Invoice {
  id: string; matter_id: string; matter_reference: string | null; client_id: string; payer_id: string | null
  kind: 'invoice' | 'credit_note'; credit_for_invoice_id: string | null; number: string | null
  status: 'draft' | 'pending_approval' | 'issued' | 'partially_paid' | 'paid' | 'void'; currency: string
  subtotal: DecimalString; vat_amount: DecimalString; total: DecimalString; amount_paid: DecimalString; outstanding: DecimalString
  issued_at: string | null; due_date: string | null; narrative: string | null; approval_id: string | null; approval_status: string | null
  version: number; lines: InvoiceLine[]; basis: string
}
export interface Unbilled {
  matter_id: string; time_entries: TimeEntry[]; expenses: Expense[]; fee_arrangement: string; fixed_fee_amount: DecimalString | null; currency: string
}
export interface MatterBudget {
  matter_id: string; currency: string; budget: DecimalString | null; unbilled_wip: DecimalString; billed_net: DecimalString; used: DecimalString
  used_pct: DecimalString | null; over_budget: boolean; basis: string
}

export type LedgerKey = 'office' | 'client'
export interface LedgerAccount {
  id: string; ledger: LedgerKey; code: string; name: string; account_type: string; currency: string; is_bank: boolean
  system_key: string | null; matter_id: string | null; balance: DecimalString | null
}
export interface TrialBalance {
  ledger: LedgerKey; as_of: string | null; total_debit: DecimalString; total_credit: DecimalString; balanced: boolean | null; note: string
  accounts: { account_id: string; code: string; name: string; type: string; system_key: string | null; matter_id: string | null; debit: DecimalString; credit: DecimalString; balance: DecimalString }[]
}
export interface JournalLine {
  id: string; account_id: string; debit: DecimalString; credit: DecimalString; matter_id: string | null; narrative: string | null
  reconciled_at: string | null; account_code: string | null; account_name: string | null
}
export interface Journal {
  id: string; ledger: LedgerKey; reference: string; description: string; effective_date: string; currency: string
  status: 'draft' | 'pending_approval' | 'posted' | 'reversed'; matter_id: string | null; source_type: string | null
  prepared_by: string; posted_by: string | null; posted_at: string | null; approval_id: string | null; approval_status: string | null
  reverses_journal_id: string | null; total: DecimalString; version: number; lines: JournalLine[]
}
export interface BankLine {
  id: string; bank_account_id: string; ledger: LedgerKey; txn_date: string; description: string; reference: string | null
  amount: DecimalString; currency: string; external_id: string; status: string; payment_id: string | null; matched_journal_line_id: string | null
}
export interface Payment {
  id: string; ledger: LedgerKey; matter_id: string | null; received_from_id: string | null; amount: DecimalString; allocated_amount: DecimalString
  unallocated_amount: DecimalString | null; currency: string; received_on: string; reference: string | null
  status: string; receipt_journal_id: string | null; bank_statement_line_id: string | null; version: number; note: string
}
export interface BankSyncResult { provider: string; mode: string; synthetic: boolean; bank_account_id: string; [k: string]: unknown }
export interface Reconciliation {
  id: string; ledger: LedgerKey; bank_account_id: string; period_end: string; statement_balance: DecimalString; ledger_balance: DecimalString
  difference: DecimalString; status: 'draft' | 'signed_off'; prepared_by: string; signed_off_by: string | null; signed_off_at: string | null; notes: string | null
  can_sign_off?: boolean
  unmatched_statement_lines?: BankLine[]
  unreconciled_journal_lines?: { journal_line_id: string; journal_id: string; reference: string; effective_date: string; debit: DecimalString; credit: DecimalString }[]
  suggestions?: { bank_line_id: string; journal_line_id: string; [k: string]: unknown }[]
}
export interface RevenueRecognitionRow { id: string; invoice_id: string; matter_id: string; amount: DecimalString; basis: string; recognised_on: string }
export interface ApprovalRow {
  id: string; kind: string; status: string; subject_type: string; subject_id: string | null; matter_id: string | null
  requested_by: string; requested_by_name: string | null; decided_by: string | null; decided_by_name: string | null
  decided_at: string | null; decision_note: string | null; payload: Record<string, unknown>; payload_hash: string
  required_permission: string | null; created_at: string; href: string | null
}

export interface ReportData {
  report: string; title: string; period: { from: string | null; to: string | null; as_of: string | null }
  filters: Record<string, unknown>; basis: string; currency: string; generated_at: string
  rows: Record<string, unknown>[]; totals: Record<string, unknown>; by_fee_earner?: Record<string, unknown>[] | null
}
export interface ReportCatalogueItem { name: string; financial: boolean; permitted: boolean }
