export interface Blocker { id: string; title: string; status: string }
export interface Task {
  id: string; matter_id: string | null; matter_reference: string | null; matter_title: string | null; title: string; description: string | null
  assignee_id: string | null; assignee_name: string | null; created_by: string | null; due_at: string | null; status: string; priority: string
  completed_at: string | null; recurrence: { freq: 'daily' | 'weekly' | 'monthly'; interval: number; until?: string | null; next_created?: boolean } | null
  reminder_offsets_minutes: number[]; escalate_to_id: string | null; escalate_after_hours: number | null; escalated_at: string | null
  deadline_id: string | null; source: string; agent_run_id: string | null; version: number; is_overdue: boolean; blocked_by: Blocker[]; created_at: string
}
export interface TaskDeps { depends_on: Task[]; required_by: Task[]; blocked_by: Blocker[] }
export interface DiaryEvent {
  id: string; matter_id: string | null; matter_reference: string | null; title: string; kind: string; start_at: string; end_at: string | null
  location: string | null; attendee_ids: string[]; owner_id: string; owner_name: string | null; description: string | null; external_calendar_ref: string | null; version: number
}
export interface FeedItem {
  kind: 'event' | 'task' | 'deadline'; id: string; title: string; start: string; end: string | null; all_day: boolean; matter_id: string | null
  matter_reference: string | null; status: string | null; authoritative: boolean | null; label: string | null; href: string
}
export interface Deadline {
  id: string; matter_id: string; matter_reference: string | null; title: string; due_date: string; due_time: string | null; timezone: string
  origin: 'manual' | 'calculated_suggestion' | 'ai_suggestion'; status: string; authoritative: boolean; label: string; jurisdiction: string | null
  rule_key: string | null; calendar_id: string | null; calendar_name: string | null; trigger_date: string | null; assumptions: string | null
  calculation: Record<string, unknown>; source_document_id: string | null; source_version_id: string | null; source_passage: string | null
  source_ref: { page?: number; paragraph?: number; version_no?: number; document_title?: string } & Record<string, unknown>
  agent_run_id: string | null; suggested_by: string | null; reviewer_id: string | null; confirmed_by: string | null; confirmed_by_name: string | null
  confirmed_at: string | null; review_note: string | null; version: number
}
export interface DeadlineRule {
  id: string; key: string; name: string; jurisdiction: string; offset_days: number; day_type: 'business' | 'calendar'; direction: 'after' | 'before'
  roll_convention: string; description: string | null; source_note: string; is_active: boolean
}
export interface BusinessCalendar { id: string; name: string; jurisdiction: string; timezone: string; weekend_days: number[]; is_default: boolean; source_note: string | null; holiday_count: number }
export interface Holiday { id: string; date: string; name: string }
export interface StaffOption { id: string; name: string }
export interface MatterOption { id: string; reference: string; title: string }
