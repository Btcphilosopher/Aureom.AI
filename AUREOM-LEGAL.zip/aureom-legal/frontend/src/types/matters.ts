import type { DecimalString } from './api'
import type { PartyRole } from './clients'

export interface MatterListItem {
  id: string; reference: string; title: string; status: string; stage: string | null; practice_area: string; matter_type: string
  client: { id: string; name: string | null }; responsible_partner: { id: string; name: string | null }; fee_earner: { id: string; name: string | null }
  office: { id: string; name: string | null }; opened_at: string | null; target_date: string | null
  access_level: 'standard' | 'restricted'; ethical_wall: boolean; legal_hold: boolean; version: number
}
export interface MatterParty { id: string; role: PartyRole; notes: string | null; contact: { id: string; name: string; kind: string; status: string } }
export interface MatterMember { id: string; access: 'allow' | 'deny'; member_role: string | null; reason: string | null; user: { id: string; name: string | null } | null; team: { id: string; name: string | null } | null }
export interface ChecklistItem { id: string; phase: 'opening' | 'closing'; label: string; required: boolean; completed: boolean; completed_at: string | null; completed_by: string | null; note: string | null }
export interface MatterFinancial {
  fee_arrangement: string; fixed_fee_amount: DecimalString | null; budget_amount: DecimalString | null; currency: string
  unbilled_time: DecimalString; unbilled_expenses: DecimalString; unbilled_entries: number; client_balance: DecimalString; basis: string
}
export interface StateEvent { from: string | null; to: string; actor: string | null; reason: string | null; at: string; requested_by: string | null; approved_by: string | null }
export interface PendingTransition { approval_id: string; to_status: string; requested_by: string; reason: string | null }
export interface TemplateStageDef { key: string; name: string }
export interface MatterDetail extends MatterListItem {
  description: string | null; jurisdiction: string; closed_at: string | null; team_id: string | null; exports_allowed: boolean; ai_retrieval_allowed: boolean
  fee_arrangement: string; currency: string; retention_policy_key: string | null; retention_until: string | null; legal_hold_reason: string | null
  conflict_search_id: string | null; custom_fields: Record<string, unknown>
  template: { id: string; name: string; stages: TemplateStageDef[]; required_fields: string[] } | null
  parties: MatterParty[]; members: MatterMember[]; checklist: ChecklistItem[]; financial: MatterFinancial | null
  pending_transition: PendingTransition | null; state_history: StateEvent[]
}
export interface MatterSummary {
  matter_id: string; reference: string; documents: number | null; open_tasks: number | null; upcoming_deadlines: number | null
  suggested_deadlines_unconfirmed: number | null; unbilled_wip: DecimalString | null; unbilled_entries?: number; client_balance: DecimalString | null
  currency?: string; basis?: string; outstanding_required_checklist_items: number
}
export interface Blocker { code?: string; message?: string; label?: string; [k: string]: unknown }
export interface AvailableTransition { to_status: string; allowed: boolean; blockers: (string | Blocker)[]; reason_required: boolean; needs_approval_from_partner: boolean; can_request: boolean }
export interface TransitionsAvailable { status: string; version: number; transitions: AvailableTransition[] }
export interface TransitionResult { executed: boolean; approval_id: string; approval_status: string; matter: MatterDetail }
export interface ChronologyEntry {
  id: string; event_date: string | null; date_text: string | null; date_basis: 'explicit' | 'inferred'; description: string
  source: { type?: string; id?: string; document_title?: string; title?: string; version_no?: number; page?: number; paragraph?: number; quote?: string; [k: string]: unknown }
  origin: 'manual' | 'agent'; status: string; created_by_name?: string | null; edited_by_name?: string | null; version: number; agent_run_id?: string | null
}
export interface ActivityItem { id: number; at: string; action: string; summary: string; actor: string; actor_type: string; entity_type: string; details: Record<string, unknown> }
export interface MatterTemplate {
  id: string; name: string; practice_area: string; matter_type: string; description: string | null; stages: TemplateStageDef[]
  opening_checklist: { label: string; required: boolean }[]; closing_checklist: { label: string; required: boolean }[]
  required_fields: string[]; default_fee_arrangement: string; default_retention_key: string | null
  default_tasks: { title: string; due_in_days: number }[]; is_active: boolean; created_at: string
}
export interface AdminUser { id: string; name: string; email: string; role_key: string | null; role_name: string | null; office_id: string | null; team_id: string | null; team: string | null; is_active: boolean }
export interface Team { id: string; name: string; practice_area: string | null; office_id: string | null }
export interface RetentionPolicy { id?: string; key: string; name: string; years?: number; description?: string | null }
