export interface AdminUser {
  id: string; email: string; name: string; initials: string; job_title: string | null; role_key: string | null; role_name: string | null
  office_id: string | null; office: string | null; team_id: string | null; team: string | null; grade: string | null; is_active: boolean
  has_password: boolean; sso_subject: string | null; last_login_at: string | null; version: number
}
export interface AdminRole { id: string; key: string; name: string; permissions: string[]; users: number }
export interface RolesResponse { catalogue: string[]; defaults: Record<string, string[]>; items: AdminRole[] }
export interface OfficeRow { id: string; name: string; city: string; address: string | null; timezone: string }
export interface TeamRow { id: string; name: string; practice_area: string | null; office_id: string | null }
export interface CheckType { key: string; label: string; applies_to: string }
export interface FirmSettings {
  name: string; slug: string; data_residency: string
  settings: {
    onboarding_check_types?: CheckType[]; onboarding_required_checks?: string[]; client_reference_prefix?: string; vat_rate?: string
    ai?: { enabled?: boolean; provider?: string; auto_complete_readonly?: boolean; monthly_budget_gbp?: number | string; per_run_budget_gbp?: number | string; user_daily_runs?: number; train_on_matter_content?: boolean; allowed_agents?: string[] }
    finance?: { four_eyes?: boolean; currency?: string }
    retention?: { default_policy?: string }
  } & Record<string, unknown>
}
export interface RetentionRow { id: string; key: string; name: string; years: number; description: string | null; action_at_expiry: string; is_active: boolean }
export interface IntegrationRow { key: string; name: string; category: string; provider: string; mode: 'mock' | 'live' | 'unavailable'; description: string; data_leaves_application: string; setup_hint: string; available: boolean }
export interface AuditRow {
  id: number; occurred_at: string; actor_user_id: string | null; actor: string; actor_type: string; action: string; entity_type: string; entity_id: string | null
  matter_id: string | null; summary: string; details: Record<string, unknown>; hash: string
}
export interface SystemInfo {
  environment: string; demo_mode: boolean; storage: Record<string, unknown>; data_residency: string; configured_residency: string; session_ttl_minutes: number
  cookie_secure: boolean; ai_provider: string; sso_configured: boolean; jobs: Record<string, number>; max_upload_mb: number
  backup: { doc: string; summary: string }; warnings: string[]
}
export interface AiProviderInfo {
  integration: IntegrationRow; active_provider: string | null; model: string | null; data_residency: string; train_on_matter_content: boolean; training_note: string
  settings: { enabled: boolean; auto_complete_readonly: boolean; allowed_agents: string[]; monthly_budget_gbp: string; per_run_budget_gbp: string; user_daily_runs: number }
  egress_by_agent: Record<string, unknown>; never_sent: string[]; logging: string
}
export interface ApprovalRow {
  id: string; kind: string; status: string; subject_type: string; subject_id: string | null; matter_id: string | null; requested_by: string; requested_by_name: string | null
  decided_by: string | null; decided_by_name: string | null; decided_at: string | null; decision_note: string | null; payload: Record<string, unknown>; payload_hash: string
  required_permission: string | null; created_at: string; href: string | null
}
