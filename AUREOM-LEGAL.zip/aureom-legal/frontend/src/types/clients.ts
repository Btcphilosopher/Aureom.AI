import type { DecimalString } from './api'

export type ContactKind = 'individual' | 'organisation'
export type Channel = 'email' | 'phone' | 'post' | 'portal'
export type PartyRole = 'client' | 'payer' | 'beneficiary' | 'counterparty' | 'counterparty_solicitor' | 'witness' | 'other'

export interface Contact {
  id: string; kind: ContactKind; display_name: string; title: string | null; first_name: string | null; last_name: string | null
  date_of_birth: string | null; org_name: string | null; company_number: string | null; email: string | null; phone: string | null
  preferred_channel: Channel; aliases: string[]; client_ref: string | null; is_client: boolean; status: string
  responsible_user_id: string | null; responsible_name: string | null; office_id: string | null; notes: string | null
  merged_into_id: string | null; version: number; created_at: string; updated_at: string
}
export interface Address { id: string; kind: string; line1: string; line2: string | null; city: string | null; county: string | null; postcode: string | null; country: string; is_primary: boolean }
export interface Relationship {
  id: string; relation_type: string; direction: 'outgoing' | 'incoming'
  other: { id: string; display_name: string; kind: ContactKind }; start_date: string | null; end_date: string | null; notes: string | null
}
export interface ContactMatterRoles { matter_id: string; reference: string; title: string; status: string; roles: PartyRole[] }
export interface ContactDetail extends Contact {
  addresses: Address[]; relationships: Relationship[]; matters: ContactMatterRoles[]; restricted_matters_hidden: number
  onboarding: { status: string; record_id: string | null; simulated_notice: string }
  merged_into?: { id: string; display_name: string } | null
}

export interface OnboardingCheck {
  id: string; check_type: string; provider: string; simulated: boolean; status: string; status_label: string; result_summary: string | null
  external_ref: string | null; performed_at: string | null; reviewed_by: string | null; review_note: string | null
}
export interface Onboarding {
  simulated_notice: string
  record: null | { id: string; status: string; status_label: string; risk_level: string | null; submitted_form: Record<string, unknown>; notes: string | null; version: number; reviewed_by: string | null; reviewed_at: string | null }
  status: string
  required_checks: string[]
  check_types: { key: string; label: string; applies_to?: string; applicable: boolean; required: boolean }[]
  checks: OnboardingCheck[]
  blockers: (string | { message?: string; label?: string })[]
  checks_missing: string[]
}

export interface DuplicatePair { score: number; reasons: string[]; a: Contact; b: Contact; merge_pending: boolean }
export interface MergeRecord {
  id: string; survivor_id: string; merged_id: string; status: 'pending' | 'completed' | 'rejected'
  requested_by: string; requested_by_name: string | null; reviewed_by: string | null; reviewed_by_name: string | null
  field_choices: Record<string, 'survivor' | 'merged'>; repointed: Record<string, number>; reason: string | null
  snapshot: Partial<Contact>; created_at: string; completed_at: string | null
}

export interface EvidenceMatter { matter_id: string | null; role: string; masked: boolean; reference?: string; title?: string; status?: string; label?: string }
export interface ConflictMatch {
  id: string; searched_term: string; match_type: string; score: number; disposition: string; note: string | null
  reviewed_by_name: string | null; reviewed_at: string | null
  evidence: { contact?: { id: string; name: string; kind: string; status: string; client_ref: string | null }; matters?: EvidenceMatter[]; [k: string]: unknown }
}
export interface ConflictHistory { id: string; event: string; actor: string | null; actor_id: string; from: string | null; to: string | null; note: string | null; match_id: string | null; at: string }
export interface ConflictSearch {
  id: string; status: string; terms: string[]; match_count: number; version: number
  subject_contact: { id: string; name: string } | null; matter_id: string | null
  requested_by: string; requested_by_name: string | null; created_at: string; reviewed_by: string | null; reviewed_by_name: string | null
  reviewed_at: string | null; review_note: string | null; unreviewed_matches: number; notice: string
  matches: ConflictMatch[]; history: ConflictHistory[]
}
export interface ConflictSearchRow {
  id: string; status: string; terms: string[]; match_count: number; subject_contact_id: string | null; matter_id: string | null
  requested_by_name: string | null; reviewed_by_name: string | null; created_at: string; version: number
}
export type { DecimalString }
