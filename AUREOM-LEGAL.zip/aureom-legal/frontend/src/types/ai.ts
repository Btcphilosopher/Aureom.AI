import type { DecimalString } from './api'

export interface AgentCatalogItem {
  key: string; name: string; description: string; retrieves: string[]; read_only: boolean
  read_tools: string[]; proposal_tools: string[]; proposes_actions: string[]; requires_matter: boolean; prompt_template_version: string
}
export interface AgentCatalog { agents: AgentCatalogItem[]; prohibited_tools: string[]; notice: string }

export interface AgentCitation {
  source_type: string | null; source_id: string; document_id?: string | null; version_id?: string | null; version_no?: number | null
  page?: number | null; paragraph?: number | null; quote?: string | null; ref?: string; title?: string | null; invalid?: boolean
  meta?: { effective_date?: string; last_reviewed?: string; source_ref?: string; retrieved_at?: string; source?: string }
}
export interface ResultItem { statement: string; citations: AgentCitation[]; kind?: string; data?: Record<string, unknown>; confidence?: string }
export interface ResultWarning { type: string; message: string; patterns?: string[]; citation?: AgentCitation; tool?: string; reason?: string }
export interface AgentResult {
  agent_type: string; title: string; summary?: string
  facts: ResultItem[]; inferences: ResultItem[]; contradictions: ResultItem[]
  recommendations: { statement: string }[]; missing_information: string[]
  warnings: ResultWarning[]; rejected_claims: { section: string; reason: string }[]
  proposed_action_count: number; sections_note?: string
  evidence_summary?: { items_retrieved: number; by_type: Record<string, number> }
}

export type ActionStatus = 'proposed' | 'approved' | 'rejected' | 'executing' | 'executed' | 'failed' | 'superseded'
export interface ProposedAction {
  id: string; action_type: string; summary: string; params: Record<string, unknown>; evidence: AgentCitation[]; risk: 'low' | 'medium' | 'high'
  status: ActionStatus; approved_by: string | null; approved_by_name: string | null; approved_at: string | null
  approved_hash: string | null; params_hash: string; decision_note: string | null; executed_at: string | null
  result: { type?: string; id?: string; ids?: string[]; status?: string; sent?: boolean; fields_changed?: string[]; updated?: string[]; [k: string]: unknown } | null
  error: string | null; edit_count: number; edit_history: { at: string; by: string; before: Record<string, unknown>; after: Record<string, unknown>; was_approved: boolean }[]
  version: number; approval_is_current: boolean
}
export interface RunEvent { id: string; kind: string; summary: string; details: Record<string, unknown>; actor_user_id: string | null; actor_name: string | null; created_at: string }

export interface RunSummary {
  id: string; agent_type: string; agent_name: string; status: string; approval_state: string
  matter_id: string | null; matter_reference: string | null; contact_id: string | null; requested_by: string; requested_by_name: string | null
  provider: string; model: string; prompt_template_version: string; cost_gbp: DecimalString; tokens_in: number; tokens_out: number
  attempts: number; created_at: string; started_at: string | null; finished_at: string | null; error: string | null
  summary: string | null; proposed_actions: number; pending_actions: number
}
export interface RunDetail extends RunSummary {
  scope: Record<string, unknown>; input: Record<string, unknown>
  source_versions: { type: string; id: string; version_id?: string | null; version_no?: number | null; title?: string | null }[]
  result: AgentResult | null; execution_result: Record<string, unknown> | null
  actions: ProposedAction[]; events: RunEvent[]; approval_history: RunEvent[]
  reviewed_by: string | null; reviewed_by_name: string | null; reviewed_at: string | null
  max_attempts: number; timeout_seconds: number; version: number; cancel_requested: boolean; provider_notice: string | null
}

export interface KnowledgeItem {
  id: string; title: string; kind: string; practice_area: string | null; source_ref: string | null; effective_date: string; last_reviewed: string | null
  approved: boolean; approved_by: string | null; updated_at: string; body?: string; snippet?: string; rank?: number
}
export interface KnowledgeSearch { query: string; results: KnowledgeItem[]; notice: string }

export interface AiUsage {
  period_start: string; basis: string; currency: string; spent_gbp: DecimalString; monthly_budget_gbp: DecimalString; per_run_budget_gbp: DecimalString
  your_runs_today: number; user_daily_runs_limit: number; by_agent: { agent_type: string; runs: number; cost_gbp: DecimalString }[]
}
export interface ProviderInfo {
  integration: { key: string; name: string; mode: string; provider: string; description: string; data_leaves_application: string; setup_hint?: string; available: boolean }
  active_provider: string | null; model: string | null; data_residency: string; train_on_matter_content: boolean; training_note: string
  settings: { enabled: boolean; auto_complete_readonly: boolean; allowed_agents: string[]; monthly_budget_gbp: DecimalString; per_run_budget_gbp: DecimalString; user_daily_runs: number }
  egress_by_agent: Record<string, string[]>; never_sent: string[]; logging: string
}
