import type { Page } from './api'

export interface DocVersion {
  id: string; version_no: number; original_filename: string; content_type: string; size_bytes: number; sha256: string
  author_id: string; author_name: string | null; change_note: string | null; created_at: string
  scan_status: string; scan_detail: string | null; ocr_status: string; index_status: string; page_count: number | null
}
export interface DocItem {
  id: string; matter_id: string | null; contact_id: string | null; folder_id: string | null; title: string; doc_type: string; tags: string[]
  status: string; current_version_no: number; current_version_id: string | null; client_visible: boolean; legal_hold: boolean
  retention_until: string | null; source: string; created_by: string; created_at: string; updated_at: string; version: number
  matter_reference: string | null; matter_title: string | null; current: DocVersion | null
}
export interface SignatureRequestOut {
  id: string; version_id: string; provider: string; simulated: boolean; status: string; external_ref: string | null
  signers: { name: string; email: string; status?: string; signed_at?: string | null }[]; created_at: string
}
export interface DocDetail extends DocItem { versions: DocVersion[]; signature_requests: SignatureRequestOut[]; meta: Record<string, unknown> }
export type DocPage = Page<DocItem>

export interface SearchHit {
  document_id: string; title: string; doc_type: string; matter_id: string | null; matter_reference: string | null
  version_id: string; version_no: number; page: number; paragraph: number; chunk_id: string; is_ocr: boolean; snippet: string; rank: number
}
export interface Folder { id: string; matter_id: string | null; parent_id: string | null; name: string }

export interface MatterOption { id: string; reference: string; title: string; status: string; access_level: string; ethical_wall?: boolean; client?: { id: string; name: string | null } }

export interface PreviewParagraph { paragraph: number; chunk_id: string; ordinal: number; text: string; is_ocr: boolean }
export interface Preview {
  document_id: string; title: string; version_id: string; version_no: number; sha256: string; content_type: string; filename: string
  scan_status: string; ocr_status: string; simulated_ocr: boolean; render: string; notice: string; text_available: boolean
  pages: { page: number; paragraphs: PreviewParagraph[] }[]
}

export interface CompareOp { op: 'equal' | 'added' | 'removed' | 'changed'; count?: number; from?: { page: number; paragraph: number; text: string }[]; to?: { page: number; paragraph: number; text: string }[] }
export interface CompareResult {
  document_id: string; from_version: number; to_version: number; from_sha256: string; to_sha256: string
  summary: { added: number; removed: number; changed: number; unchanged: number }; operations: CompareOp[]
}

export interface TemplateField { key: string; label?: string | null; source?: string | null; required?: boolean }
export interface DocTemplate {
  id: string; name: string; doc_type: string; practice_area: string | null; body: string; fields: TemplateField[]
  approved: boolean; approved_by: string | null; template_version: number; updated_at: string
}
export interface TemplatePreview {
  template_id: string; template_version: number; approved: boolean; text: string
  fields: { key: string; value: string | null; missing: boolean; required: boolean }[]; missing: string[]; missing_required: string[]
}

export interface ExportRow {
  id: string; matter_id: string; requested_by: string; document_ids: string[]; reason: string; status: string; approval_id: string | null
  sha256: string | null; expires_at: string | null; download_count: number; error: string | null; created_at: string
}
export interface IntegrationInfo { key: string; name: string; mode: string; provider: string; description: string; data_leaves_application: string; setup_hint: string; available: boolean }
