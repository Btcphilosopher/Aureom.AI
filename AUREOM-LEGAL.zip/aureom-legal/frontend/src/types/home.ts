import type { DecimalString } from './api'

export interface HomeMatter { id: string; reference: string; title: string; client: string; stage: string | null; status: string; practice_area: string; restricted: boolean; target_date: string | null; href: string }
export interface HomeTask { id: string; title: string; due_at: string | null; priority: string; status: string; matter_reference: string | null; overdue: boolean; href: string }
export interface HomeDeadline { id: string; title: string; due_date: string; status: string; origin: string; matter_reference: string | null; days_left: number; needs_confirmation: boolean; href: string }
export interface HomeDocument { id: string; title: string; status: string; matter_reference: string | null; version_no: number; href: string }
export interface HomeCorrespondence { id: string; subject: string; direction: string; status: string; from: string; at: string | null; href: string }
export interface HomeAiRun { id: string; agent_type: string; matter_reference: string | null; created_at: string; href: string }
export interface HomeMetric { key: string; label: string; value: DecimalString; currency: string; href: string; basis: string }
export interface HomeException { key: string; label: string; count: number; href: string; severity: 'warning' | 'danger'; items: { label: string; href: string }[] }

export interface HomeData {
  generated_at: string
  scope: 'mine' | 'firm'
  office_id: string | null
  as_of: string
  user: { name: string; role: string }
  role?: string
  redirect?: string
  matters?: { count: number; href: string; items: HomeMatter[] }
  tasks?: { count: number; overdue: number; href: string; items: HomeTask[] }
  deadlines?: { count: number; href: string; items: HomeDeadline[] }
  documents?: { awaiting_review: number; awaiting_signature: number; href: string; items: HomeDocument[] }
  correspondence?: { unfiled: number; href: string; items: HomeCorrespondence[] }
  ai_drafts?: { count: number; href: string; items: HomeAiRun[] }
  approvals?: { count: number; href: string }
  financial?: {
    period: { from: string; to: string; label: string; key: string }
    filters: { scope: string; office_id: string | null; currency: string }
    basis_note: string
    metrics: HomeMetric[]
    draft_invoices: { count: number; total: DecimalString; href: string; items: { id: string; status: string; total: DecimalString; href: string }[] }
  }
  exceptions: HomeException[]
}
