import { lazy } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { LoadingState } from '@/components/ui/States'
import { useAuth } from '@/lib/auth'
import { Shell } from '@/layout/Shell'
import Login from '@/pages/Login'

const sections = {
  home: lazy(() => import('@/pages/home')),
  clients: lazy(() => import('@/pages/clients')),
  matters: lazy(() => import('@/pages/matters')),
  documents: lazy(() => import('@/pages/documents')),
  correspondence: lazy(() => import('@/pages/correspondence')),
  tasks: lazy(() => import('@/pages/tasks')),
  billing: lazy(() => import('@/pages/billing')),
  ledger: lazy(() => import('@/pages/ledger')),
  reports: lazy(() => import('@/pages/reports')),
  ai: lazy(() => import('@/pages/ai')),
  admin: lazy(() => import('@/pages/admin')),
  portal: lazy(() => import('@/pages/portal')),
  demo: lazy(() => import('@/pages/demo')),
  approvals: lazy(() => import('@/pages/approvals')),
}
const Kit = lazy(() => import('@/pages/Kit'))

function Protected({ children }: { children: React.ReactNode }) {
  const { me, loading } = useAuth()
  const loc = useLocation()
  if (loading) return <LoadingState label="Signing you in…" className="min-h-screen" />
  if (!me) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />
  return <>{children}</>
}

/** Client users only ever see the portal. */
function HomeGate() {
  const { isClientUser } = useAuth()
  return isClientUser ? <Navigate to="/portal" replace /> : <sections.home />
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<Protected><Shell /></Protected>}>
        <Route index element={<HomeGate />} />
        <Route path="clients/*" element={<sections.clients />} />
        <Route path="matters/*" element={<sections.matters />} />
        <Route path="documents/*" element={<sections.documents />} />
        <Route path="correspondence/*" element={<sections.correspondence />} />
        <Route path="tasks/*" element={<sections.tasks />} />
        <Route path="billing/*" element={<sections.billing />} />
        <Route path="ledger/*" element={<sections.ledger />} />
        <Route path="reports/*" element={<sections.reports />} />
        <Route path="ai/*" element={<sections.ai />} />
        <Route path="admin/*" element={<sections.admin />} />
        <Route path="portal/*" element={<sections.portal />} />
        <Route path="demo/*" element={<sections.demo />} />
        <Route path="approvals/*" element={<sections.approvals />} />
        <Route path="_kit" element={<Kit />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
