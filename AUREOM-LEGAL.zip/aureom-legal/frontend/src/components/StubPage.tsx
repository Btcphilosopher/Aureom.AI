import { Construction } from 'lucide-react'
import { usePageTitle } from '@/hooks'
import { PageHeader } from './ui/Nav'
import { EmptyState } from './ui/States'

export function StubPage({ title, description, owner }: { title: string; description: string; owner: string }) {
  usePageTitle(title)
  return (
    <>
      <PageHeader title={title} description={description} eyebrow="AUREOM LEGAL" />
      <EmptyState icon={<Construction className="h-5 w-5" />} title="This section is being built" description={<>Placeholder page. Replace <code className="rounded bg-stone-100 px-1 font-mono text-2xs">src/pages/{owner}/index.tsx</code> — it owns its nested routes.</>} />
    </>
  )
}
