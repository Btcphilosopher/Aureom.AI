import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from 'react'
import { AlertTriangle, CheckCircle2, Info, X, XCircle } from 'lucide-react'
import { cn } from '@/lib/cn'

type ToastTone = 'success' | 'danger' | 'warning' | 'info'
export interface ToastInput { title: string; description?: string; tone?: ToastTone; durationMs?: number }
interface ToastItem extends Required<Pick<ToastInput, 'title' | 'tone'>> { id: number; description?: string }
interface ToastApi { push: (t: ToastInput) => void }

const Ctx = createContext<ToastApi>({ push: () => undefined })
export const useToast = () => useContext(Ctx)

const ICON = { success: CheckCircle2, danger: XCircle, warning: AlertTriangle, info: Info }
const TONE: Record<ToastTone, string> = {
  success: 'border-ok-600 text-ok-700', danger: 'border-bad-600 text-bad-700', warning: 'border-warn-600 text-warn-700', info: 'border-navy-500 text-navy-700',
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])
  const seq = useRef(0)
  const dismiss = useCallback((id: number) => setItems((l) => l.filter((x) => x.id !== id)), [])
  const push = useCallback((t: ToastInput) => {
    const id = ++seq.current
    setItems((l) => [...l.slice(-3), { id, title: t.title, description: t.description, tone: t.tone ?? 'info' }])
    setTimeout(() => dismiss(id), t.durationMs ?? (t.tone === 'danger' ? 8000 : 5000))
  }, [dismiss])
  const value = useMemo(() => ({ push }), [push])
  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[22rem] max-w-[calc(100vw-2rem)] flex-col gap-2" aria-live="polite" aria-atomic="false" role="region" aria-label="Notifications">
        {items.map((t) => {
          const Icon = ICON[t.tone]
          return (
            <div key={t.id} role={t.tone === 'danger' ? 'alert' : 'status'} className={cn('pointer-events-auto flex animate-slide-up gap-3 rounded-md border-l-4 bg-white p-3 shadow-pop ring-1 ring-stone-200', TONE[t.tone])}>
              <Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-navy-900">{t.title}</p>
                {t.description && <p className="mt-0.5 break-words text-xs text-stone-600">{t.description}</p>}
              </div>
              <button className="rounded p-0.5 text-stone-500 hover:text-navy-900" onClick={() => dismiss(t.id)} aria-label="Dismiss notification"><X className="h-4 w-4" /></button>
            </div>
          )
        })}
      </div>
    </Ctx.Provider>
  )
}
