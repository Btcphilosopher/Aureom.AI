import type { ReactNode } from 'react'
import { AlertTriangle, FileQuestion, FlaskConical, Inbox, Lock, PlugZap } from 'lucide-react'
import { ApiError } from '@/lib/api'
import { cn } from '@/lib/cn'
import { Button } from './Button'

export function Spinner({ className, label = 'Loading' }: { className?: string; label?: string }) {
  return <span role="status" aria-label={label} className={cn('inline-block h-4 w-4 animate-spin rounded-full border-2 border-navy-200 border-t-navy-700', className)} />
}
export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden className={cn('animate-pulse rounded bg-stone-200/70 motion-reduce:animate-none', className)} />
}

function Shell({ icon, title, children, tone = 'neutral', className, actions }: { icon: ReactNode; title: string; children?: ReactNode; tone?: 'neutral' | 'danger' | 'warning' | 'sim'; className?: string; actions?: ReactNode }) {
  const ring = { neutral: 'bg-navy-50 text-navy-600', danger: 'bg-bad-50 text-bad-600', warning: 'bg-warn-50 text-warn-600', sim: 'bg-sim-50 text-sim-600' }[tone]
  return (
    <div className={cn('flex flex-col items-center justify-center px-6 py-12 text-center', className)}>
      <div className={cn('mb-4 flex h-11 w-11 items-center justify-center rounded-full', ring)} aria-hidden>{icon}</div>
      <h3 className="font-serif text-lg text-navy-900">{title}</h3>
      {children && <div className="mt-1.5 max-w-md text-sm leading-relaxed text-stone-600">{children}</div>}
      {actions && <div className="mt-5 flex flex-wrap justify-center gap-2">{actions}</div>}
    </div>
  )
}

export function LoadingState({ label = 'Loading…', rows = 0, className }: { label?: string; rows?: number; className?: string }) {
  return (
    <div role="status" aria-live="polite" className={cn('flex flex-col items-center justify-center gap-3 py-12 text-sm text-stone-600', className)}>
      <Spinner className="h-6 w-6" label={label} />
      <span>{label}</span>
      {rows > 0 && <div className="mt-2 w-full max-w-xl space-y-2">{Array.from({ length: rows }, (_, i) => <Skeleton key={i} className="h-4" />)}</div>}
    </div>
  )
}

export function EmptyState({ title = 'Nothing here yet', description, action, icon, className }: { title?: string; description?: ReactNode; action?: ReactNode; icon?: ReactNode; className?: string }) {
  return <Shell icon={icon ?? <Inbox className="h-5 w-5" />} title={title} className={className} actions={action}>{description}</Shell>
}

export function ErrorState({ error, title = 'We could not load this', onRetry, className }: { error?: unknown; title?: string; onRetry?: () => void; className?: string }) {
  const e = error instanceof ApiError ? error : null
  return (
    <Shell icon={<AlertTriangle className="h-5 w-5" />} tone="danger" title={title} className={className} actions={onRetry && <Button variant="secondary" onClick={onRetry}>Try again</Button>}>
      <p>{e?.message ?? (error instanceof Error ? error.message : 'An unexpected error occurred.')}</p>
      {e && <p className="mt-1 font-mono text-2xs text-stone-500">{e.status || 'network'} · {e.code}</p>}
    </Shell>
  )
}

export function PermissionDenied({ permission, message, matter, className }: { permission?: string | string[]; message?: string; matter?: boolean; className?: string }) {
  const perms = permission ? (Array.isArray(permission) ? permission : [permission]) : []
  return (
    <Shell icon={<Lock className="h-5 w-5" />} tone="warning" title={matter ? 'This matter is restricted' : 'Permission required'} className={className}>
      <p>{message ?? (matter ? 'You are not on the access list for this matter. Ask the responsible partner or compliance team if you believe you should have access.' : 'Your role does not include access to this area. Ask an administrator if you need it.')}</p>
      {perms.length > 0 && <p className="mt-2 text-xs">Required permission: {perms.map((p) => <code key={p} className="mx-0.5 rounded bg-stone-100 px-1.5 py-0.5 font-mono text-2xs text-navy-800">{p}</code>)}</p>}
    </Shell>
  )
}

export function IntegrationUnavailable({ name, setupHint, mockAvailable, message, className }: { name?: string; setupHint?: string; mockAvailable?: boolean; message?: string; className?: string }) {
  return (
    <Shell icon={<PlugZap className="h-5 w-5" />} tone="warning" title={`${name ?? 'This integration'} is not available`} className={className}>
      <p>{message ?? 'This feature depends on an external service that is not configured in this environment.'}</p>
      {setupHint && <p className="mt-2 rounded bg-stone-100 px-3 py-2 text-left text-xs text-stone-700"><span className="font-semibold">To enable: </span>{setupHint}</p>}
      {mockAvailable && <p className="mt-2 text-xs text-sim-700">A clearly-labelled simulated provider is available for demonstrations.</p>}
    </Shell>
  )
}

export function NotFoundState({ what = 'page', action, className }: { what?: string; action?: ReactNode; className?: string }) {
  return <Shell icon={<FileQuestion className="h-5 w-5" />} title={`That ${what} could not be found`} className={className} actions={action}><p>It may have been moved, or you may not have access to it.</p></Shell>
}

export function SimulatedBanner({ children, className }: { children?: ReactNode; className?: string }) {
  return (
    <div role="note" className={cn('flex items-start gap-2.5 rounded-md border border-dashed border-sim-600/60 bg-sim-50 px-3.5 py-2.5 text-sm text-sim-700', className)}>
      <FlaskConical className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      <p><strong className="font-semibold">SIMULATED / DEMONSTRATION</strong> — not a verified result.{children && <span className="ml-1 text-sim-700/90">{children}</span>}</p>
    </div>
  )
}
