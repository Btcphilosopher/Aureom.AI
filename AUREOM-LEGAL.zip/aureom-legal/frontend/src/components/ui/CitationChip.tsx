import { FileText } from 'lucide-react'
import { cn } from '@/lib/cn'

export interface Citation { documentTitle: string; versionNo?: number | null; page?: number | null; paragraph?: number | null; quote?: string | null; documentId?: string }

/** Evidence reference: Document title · v2 · p.3 ¶4. Optionally clickable (open source) with the quote as tooltip. */
export function CitationChip({ documentTitle, versionNo, page, paragraph, quote, onClick, className }: Citation & { onClick?: () => void; className?: string }) {
  const parts = [versionNo != null && `v${versionNo}`, page != null && `p.${page}`, paragraph != null && `¶${paragraph}`].filter(Boolean).join(' · ')
  const inner = <><FileText className="h-3 w-3 shrink-0 text-brass-600" aria-hidden /><span className="max-w-[14rem] truncate">{documentTitle}</span>{parts && <span className="tabular-nums text-stone-600">· {parts}</span>}</>
  const cls = cn('inline-flex items-center gap-1 rounded border border-brass-200 bg-brass-50 px-1.5 py-0.5 text-xs text-navy-800', onClick && 'hover:bg-brass-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500', className)
  const label = `Source: ${documentTitle}${parts ? `, ${parts.replace(/·/g, ',')}` : ''}`
  return onClick ? <button type="button" onClick={onClick} title={quote ?? undefined} aria-label={label} className={cls}>{inner}</button> : <span title={quote ?? undefined} aria-label={label} className={cls}>{inner}</span>
}
