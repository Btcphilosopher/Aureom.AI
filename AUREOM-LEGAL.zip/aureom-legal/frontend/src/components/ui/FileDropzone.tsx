import { useId, useRef, useState } from 'react'
import { UploadCloud } from 'lucide-react'
import { cn } from '@/lib/cn'
import { formatBytes } from '@/lib/format'
import { Spinner } from './States'

export interface FileDropzoneProps {
  onFiles: (files: File[]) => void
  /** e.g. ".pdf,.docx,.txt" — client hint only; the server validates type, content and size authoritatively. */
  accept?: string
  maxSizeBytes?: number
  multiple?: boolean
  busy?: boolean
  disabled?: boolean
  hint?: string
  onReject?: (rejected: { file: File; reason: string }[]) => void
  className?: string
}
export function FileDropzone({ onFiles, accept, maxSizeBytes, multiple = true, busy, disabled, hint, onReject, className }: FileDropzoneProps) {
  const [over, setOver] = useState(false)
  const [rejects, setRejects] = useState<string[]>([])
  const input = useRef<HTMLInputElement>(null)
  const id = useId()
  const exts = accept?.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)
  const handle = (list: FileList | null) => {
    if (!list?.length) return
    const ok: File[] = [], bad: { file: File; reason: string }[] = []
    for (const f of Array.from(list)) {
      const ext = '.' + (f.name.split('.').pop() ?? '').toLowerCase()
      if (exts?.length && !exts.includes(ext)) bad.push({ file: f, reason: `${f.name}: file type ${ext} is not accepted` })
      else if (maxSizeBytes && f.size > maxSizeBytes) bad.push({ file: f, reason: `${f.name}: larger than ${formatBytes(maxSizeBytes)}` })
      else ok.push(f)
    }
    setRejects(bad.map((b) => b.reason)); if (bad.length) onReject?.(bad)
    if (ok.length) onFiles(multiple ? ok : ok.slice(0, 1))
    if (input.current) input.current.value = ''
  }
  return (
    <div className={className}>
      <div onDragOver={(e) => { e.preventDefault(); if (!disabled) setOver(true) }} onDragLeave={() => setOver(false)} onDrop={(e) => { e.preventDefault(); setOver(false); if (!disabled) handle(e.dataTransfer.files) }}
        className={cn('flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-6 py-8 text-center transition-colors', over ? 'border-brass-500 bg-brass-50' : 'border-stone-300 bg-ivory-50', disabled && 'opacity-60')}>
        {busy ? <Spinner className="h-6 w-6" label="Uploading" /> : <UploadCloud className="h-7 w-7 text-brass-600" aria-hidden />}
        <p className="text-sm text-navy-900">Drag and drop {multiple ? 'files' : 'a file'} here, or{' '}
          <label htmlFor={id} className="cursor-pointer font-medium text-navy-700 underline decoration-brass-500 underline-offset-2 focus-within:ring-2 focus-within:ring-brass-500">browse<input ref={input} id={id} type="file" className="sr-only" accept={accept} multiple={multiple} disabled={disabled || busy} onChange={(e) => handle(e.target.files)} /></label>
        </p>
        <p className="text-xs text-stone-600">{hint ?? [accept && `Accepted: ${accept}`, maxSizeBytes && `max ${formatBytes(maxSizeBytes)}`].filter(Boolean).join(' · ')}</p>
        <p className="text-2xs text-stone-500">Files are scanned and checked on the server before they can be previewed.</p>
      </div>
      {rejects.length > 0 && <ul role="alert" className="mt-2 space-y-0.5 text-xs text-bad-700">{rejects.map((r) => <li key={r}>{r}</li>)}</ul>}
    </div>
  )
}
