import type { ReactNode } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { cn } from '@/lib/cn'

export function Card({ title, description, actions, children, className, bodyClassName, padded = true, as: As = 'section' }: {
  title?: ReactNode; description?: ReactNode; actions?: ReactNode; children?: ReactNode; className?: string; bodyClassName?: string; padded?: boolean; as?: 'section' | 'div' | 'article'
}) {
  return (
    <As className={cn('rounded-lg border border-stone-200 bg-white shadow-panel', className)}>
      {(title || actions) && (
        <header className="flex items-start justify-between gap-4 border-b border-stone-200 px-5 py-3.5">
          <div className="min-w-0">
            {title && <h2 className="text-sm font-semibold tracking-wide text-navy-900">{title}</h2>}
            {description && <p className="mt-0.5 text-xs text-stone-600">{description}</p>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className={cn(padded && 'p-5', bodyClassName)}>{children}</div>
    </As>
  )
}
export const Panel = Card

export function StatCard({ label, value, hint, to, tone = 'neutral', footnote, icon }: {
  label: string; value: ReactNode; hint?: ReactNode; to?: string; tone?: 'neutral' | 'warning' | 'danger' | 'success' | 'brass'; footnote?: ReactNode; icon?: ReactNode
}) {
  const accent = { neutral: 'bg-navy-200', warning: 'bg-warn-600', danger: 'bg-bad-600', success: 'bg-ok-600', brass: 'bg-brass-500' }[tone]
  const body = (
    <div className="relative h-full overflow-hidden rounded-lg border border-stone-200 bg-white p-4 shadow-panel transition-colors group-hover:border-brass-400">
      <span className={cn('absolute inset-y-0 left-0 w-1', accent)} aria-hidden />
      <div className="flex items-start justify-between gap-2 pl-1">
        <p className="text-xs font-semibold uppercase tracking-wide text-stone-600">{label}</p>
        {icon ?? (to && <ArrowUpRight className="h-4 w-4 text-stone-400 group-hover:text-brass-600" aria-hidden />)}
      </div>
      <p className="mt-2 pl-1 font-serif text-3xl tabular-nums text-navy-900">{value}</p>
      {hint && <p className="mt-1 pl-1 text-xs text-stone-600">{hint}</p>}
      {footnote && <p className="mt-2 border-t border-stone-100 pl-1 pt-2 text-2xs leading-snug text-stone-600">{footnote}</p>}
    </div>
  )
  return to ? <Link to={to} className="group block rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500 focus-visible:ring-offset-2">{body}</Link> : <div className="group">{body}</div>
}

export function KeyValue({ items, columns = 1, className }: { items: { label: ReactNode; value: ReactNode }[]; columns?: 1 | 2 | 3; className?: string }) {
  return (
    <dl className={cn('grid gap-x-8 gap-y-3', columns === 2 && 'sm:grid-cols-2', columns === 3 && 'sm:grid-cols-2 xl:grid-cols-3', className)}>
      {items.map((it, i) => (
        <div key={i} className="min-w-0">
          <dt className="text-xs font-semibold uppercase tracking-wide text-stone-600">{it.label}</dt>
          <dd className="mt-0.5 break-words text-sm text-navy-900">{it.value ?? '—'}</dd>
        </div>
      ))}
    </dl>
  )
}
