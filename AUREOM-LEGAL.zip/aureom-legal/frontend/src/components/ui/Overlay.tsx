import { useId, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'
import { cn } from '@/lib/cn'
import { useFocusTrap } from '@/lib/a11y'
import { Button, IconButton } from './Button'
import { Field, Textarea } from './Form'

export interface DialogProps { open: boolean; onClose: () => void; title: ReactNode; description?: ReactNode; children: ReactNode; footer?: ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl'; dismissible?: boolean }

export function Dialog({ open, onClose, title, description, children, footer, size = 'md', dismissible = true }: DialogProps) {
  const ref = useRef<HTMLDivElement>(null)
  const id = useId()
  useFocusTrap(ref, open, dismissible ? onClose : undefined)
  if (!open) return null
  const w = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' }[size]
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-navy-950/55 p-4 pt-[10vh] animate-fade-in" onMouseDown={(e) => { if (dismissible && e.target === e.currentTarget) onClose() }}>
      <div ref={ref} role="dialog" aria-modal="true" aria-labelledby={`${id}-t`} aria-describedby={description ? `${id}-d` : undefined} tabIndex={-1} className={cn('w-full animate-slide-up rounded-lg bg-white shadow-pop focus:outline-none', w)}>
        <header className="flex items-start justify-between gap-4 border-b border-stone-200 px-6 py-4">
          <div><h2 id={`${id}-t`} className="font-serif text-xl text-navy-900">{title}</h2>{description && <p id={`${id}-d`} className="mt-1 text-sm text-stone-600">{description}</p>}</div>
          {dismissible && <IconButton aria-label="Close dialog" size="sm" onClick={onClose}><X className="h-4 w-4" /></IconButton>}
        </header>
        <div className="px-6 py-5">{children}</div>
        {footer && <footer className="flex justify-end gap-2 border-t border-stone-200 bg-ivory-50 px-6 py-3.5">{footer}</footer>}
      </div>
    </div>, document.body)
}

export interface ConfirmDialogProps {
  open: boolean; onClose: () => void; onConfirm: (reason?: string) => void | Promise<void>
  title: ReactNode; description?: ReactNode; confirmLabel?: string; tone?: 'primary' | 'danger'
  /** When set, a reason textarea is shown and must be filled in (min 3 chars) before confirming. */
  requireReason?: string | boolean; loading?: boolean
}
export function ConfirmDialog({ open, onClose, onConfirm, title, description, confirmLabel = 'Confirm', tone = 'primary', requireReason, loading }: ConfirmDialogProps) {
  const [reason, setReason] = useState('')
  const need = !!requireReason
  const valid = !need || reason.trim().length >= 3
  return (
    <Dialog open={open} onClose={onClose} title={title} description={description} size="sm"
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant={tone === 'danger' ? 'danger' : 'primary'} disabled={!valid} loading={loading} onClick={async () => { await onConfirm(need ? reason.trim() : undefined); setReason('') }}>{confirmLabel}</Button></>}>
      {need && <Field label={typeof requireReason === 'string' ? requireReason : 'Reason'} required hint="Recorded in the audit trail."><Textarea data-autofocus rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>}
    </Dialog>
  )
}

export function Drawer({ open, onClose, title, children, footer, width = 'max-w-xl' }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; footer?: ReactNode; width?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const id = useId()
  useFocusTrap(ref, open, onClose)
  if (!open) return null
  return createPortal(
    <div className="fixed inset-0 z-50 bg-navy-950/45 animate-fade-in" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <aside ref={ref} role="dialog" aria-modal="true" aria-labelledby={id} tabIndex={-1} className={cn('absolute right-0 top-0 flex h-full w-full animate-slide-left flex-col bg-white shadow-pop focus:outline-none', width)}>
        <header className="flex items-center justify-between gap-3 border-b border-stone-200 px-6 py-4">
          <h2 id={id} className="font-serif text-xl text-navy-900">{title}</h2>
          <IconButton aria-label="Close panel" size="sm" onClick={onClose}><X className="h-4 w-4" /></IconButton>
        </header>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
        {footer && <footer className="flex justify-end gap-2 border-t border-stone-200 bg-ivory-50 px-6 py-3.5">{footer}</footer>}
      </aside>
    </div>, document.body)
}
