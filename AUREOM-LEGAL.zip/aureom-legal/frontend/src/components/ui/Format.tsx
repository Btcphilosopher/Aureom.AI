import { cn } from '@/lib/cn'
import { formatDate, formatDateTime, formatHoursMinutes, formatMoney, relativeTime } from '@/lib/format'

/** Exact money display from a decimal string. Right-aligned, tabular numerals. Never pass Number-derived sums. */
export function Money({ value, currency = 'GBP', className, muted }: { value: string | number | null | undefined; currency?: string; className?: string; muted?: boolean }) {
  const neg = typeof value === 'string' && value.trim().startsWith('-')
  return <span className={cn('tabular-nums', neg && 'text-bad-700', muted && 'text-stone-600', className)}>{formatMoney(value, currency)}</span>
}

export function DateTime({ value, mode = 'datetime', className }: { value: string | Date | null | undefined; mode?: 'date' | 'datetime' | 'relative'; className?: string }) {
  if (!value) return <span className={className}>—</span>
  const iso = value instanceof Date ? value.toISOString() : value
  const text = mode === 'date' ? formatDate(value) : mode === 'relative' ? relativeTime(value) : formatDateTime(value)
  return <time dateTime={iso} title={mode === 'relative' ? formatDateTime(value) : undefined} className={cn('tabular-nums', className)}>{text}</time>
}

export function Duration({ minutes, className }: { minutes: number | null | undefined; className?: string }) {
  return <span className={cn('tabular-nums', className)}>{formatHoursMinutes(minutes)}</span>
}
