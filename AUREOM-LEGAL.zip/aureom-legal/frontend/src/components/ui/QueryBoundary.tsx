import type { ReactNode } from 'react'
import type { UseQueryResult } from '@tanstack/react-query'
import { Navigate } from 'react-router-dom'
import { ApiError } from '@/lib/api'
import { EmptyState, ErrorState, IntegrationUnavailable, LoadingState, NotFoundState, PermissionDenied } from './States'

export interface QueryBoundaryProps<T> {
  query: Pick<UseQueryResult<T, Error>, 'data' | 'error' | 'isPending' | 'isError' | 'refetch'>
  children: (data: T) => ReactNode
  /** treat data as empty (renders `empty`); default: empty arrays and Page objects with no items */
  isEmpty?: (data: T) => boolean
  empty?: ReactNode
  loading?: ReactNode
  /** label used in the not-found / integration states */
  what?: string
  /** name of the integration if a 503 comes back */
  integration?: string
}

function defaultEmpty(d: unknown): boolean {
  if (Array.isArray(d)) return d.length === 0
  if (d && typeof d === 'object' && Array.isArray((d as { items?: unknown }).items)) return (d as { items: unknown[] }).items.length === 0
  return false
}

/** Renders loading / permission-denied / not-found / integration-unavailable / error / empty states, then your content. */
export function QueryBoundary<T>({ query, children, isEmpty = defaultEmpty, empty, loading, what, integration }: QueryBoundaryProps<T>) {
  if (query.isPending) return <>{loading ?? <LoadingState />}</>
  if (query.isError) {
    const e = query.error
    if (e instanceof ApiError) {
      if (e.status === 401) return <Navigate to="/login" replace />
      if (e.status === 403) return <PermissionDenied matter={e.code === 'matter_access_denied'} message={e.message} permission={(e.details.required as string[] | undefined)} />
      if (e.status === 404) return <NotFoundState what={what} />
      if (e.isIntegrationUnavailable) return <IntegrationUnavailable name={integration ?? (e.details.integration as string | undefined)} message={e.message} setupHint={e.details.setup_hint as string | undefined} />
    }
    return <ErrorState error={e} onRetry={() => void query.refetch()} />
  }
  const data = query.data as T
  if (isEmpty(data)) return <>{empty ?? <EmptyState />}</>
  return <>{children(data)}</>
}
