import { cloneElement, useId, useRef, useState, type ReactElement, type ReactNode } from 'react'
import { useNavigate } from 'react-router-dom'
import { cn } from '@/lib/cn'
import { useClickOutside } from '@/lib/a11y'

export function Tooltip({ text, children, side = 'top' }: { text: ReactNode; children: ReactElement; side?: 'top' | 'bottom' | 'right' }) {
  const id = useId()
  const pos = { top: 'bottom-full left-1/2 mb-1.5 -translate-x-1/2', bottom: 'top-full left-1/2 mt-1.5 -translate-x-1/2', right: 'left-full top-1/2 ml-2 -translate-y-1/2' }[side]
  return (
    <span className="group/tt relative inline-flex">
      {cloneElement(children, { 'aria-describedby': id } as Record<string, unknown>)}
      <span role="tooltip" id={id} className={cn('pointer-events-none absolute z-50 w-max max-w-xs rounded bg-navy-950 px-2 py-1 text-xs text-white opacity-0 shadow-pop transition-opacity group-focus-within/tt:opacity-100 group-hover/tt:opacity-100', pos)}>{text}</span>
    </span>
  )
}

export interface MenuItem { key?: string; label: ReactNode; icon?: ReactNode; onSelect?: () => void; to?: string; disabled?: boolean; danger?: boolean; separatorBefore?: boolean; hint?: ReactNode }

export function DropdownMenu({ trigger, items, align = 'right', label = 'Menu' }: { trigger: (p: { open: boolean; props: Record<string, unknown> }) => ReactNode; items: MenuItem[]; align?: 'left' | 'right'; label?: string }) {
  const [open, setOpen] = useState(false)
  const [idx, setIdx] = useState(0)
  const root = useRef<HTMLDivElement>(null)
  const list = useRef<HTMLDivElement>(null)
  const id = useId()
  const nav = useNavigate()
  useClickOutside(root, () => setOpen(false), open)
  const enabled = items.map((it, i) => (it.disabled ? -1 : i)).filter((i) => i >= 0)
  const close = (refocus = true) => { setOpen(false); if (refocus) root.current?.querySelector<HTMLElement>('[aria-haspopup]')?.focus() }
  const choose = (it: MenuItem) => { if (it.disabled) return; close(false); if (it.to) nav(it.to); it.onSelect?.() }
  const focusItem = (i: number) => { setIdx(i); requestAnimationFrame(() => list.current?.querySelectorAll<HTMLElement>('[role=menuitem]')[i]?.focus()) }
  const onKey = (e: React.KeyboardEvent) => {
    if (!open) { if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen(true); focusItem(enabled[0] ?? 0) } return }
    const pos = enabled.indexOf(idx)
    if (e.key === 'ArrowDown') { e.preventDefault(); focusItem(enabled[(pos + 1) % enabled.length]!) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); focusItem(enabled[(pos - 1 + enabled.length) % enabled.length]!) }
    else if (e.key === 'Home') { e.preventDefault(); focusItem(enabled[0]!) }
    else if (e.key === 'End') { e.preventDefault(); focusItem(enabled[enabled.length - 1]!) }
    else if (e.key === 'Escape') { e.preventDefault(); close() }
    else if (e.key === 'Tab') setOpen(false)
  }
  return (
    <div ref={root} className="relative" onKeyDown={onKey}>
      {trigger({ open, props: { 'aria-haspopup': 'menu', 'aria-expanded': open, 'aria-controls': open ? id : undefined, onClick: () => { setOpen((o) => !o); if (!open) focusItem(enabled[0] ?? 0) } } })}
      {open && (
        <div ref={list} id={id} role="menu" aria-label={label} className={cn('absolute z-40 mt-1.5 min-w-[14rem] animate-fade-in rounded-md border border-stone-200 bg-white py-1 shadow-pop', align === 'right' ? 'right-0' : 'left-0')}>
          {items.map((it, i) => (
            <div key={it.key ?? i}>
              {it.separatorBefore && <div role="separator" className="my-1 border-t border-stone-200" />}
              <button role="menuitem" tabIndex={-1} disabled={it.disabled} onClick={() => choose(it)}
                className={cn('flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm focus:outline-none disabled:cursor-not-allowed disabled:text-stone-400', it.danger ? 'text-bad-700 hover:bg-bad-50 focus:bg-bad-50' : 'text-navy-900 hover:bg-ivory-100 focus:bg-ivory-100')}>
                {it.icon && <span className="text-stone-600" aria-hidden>{it.icon}</span>}
                <span className="flex-1">{it.label}</span>{it.hint && <span className="text-xs text-stone-500">{it.hint}</span>}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
