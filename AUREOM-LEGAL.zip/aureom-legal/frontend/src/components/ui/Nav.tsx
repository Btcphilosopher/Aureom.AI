import type { ReactNode } from 'react'
import { Check, ChevronRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { cn } from '@/lib/cn'
import { initialsOf } from '@/lib/format'
import type { Tone } from '@/lib/status'

export interface Crumb { label: string; to?: string }
export function Breadcrumbs({ items, className }: { items: Crumb[]; className?: string }) {
  if (!items.length) return null
  return (
    <nav aria-label="Breadcrumb" className={className}>
      <ol className="flex flex-wrap items-center gap-1 text-xs text-stone-600">
        {items.map((c, i) => (
          <li key={i} className="flex items-center gap-1">
            {i > 0 && <ChevronRight className="h-3 w-3 text-stone-400" aria-hidden />}
            {c.to && i < items.length - 1 ? <Link to={c.to} className="rounded hover:text-navy-900 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500">{c.label}</Link> : <span aria-current={i === items.length - 1 ? 'page' : undefined} className={i === items.length - 1 ? 'font-medium text-navy-900' : ''}>{c.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  )
}

export function PageHeader({ title, description, actions, eyebrow, meta }: { title: ReactNode; description?: ReactNode; actions?: ReactNode; eyebrow?: ReactNode; meta?: ReactNode }) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-4 border-b border-stone-200 pb-5">
      <div className="min-w-0">
        {eyebrow && <p className="mb-1 text-xs font-semibold uppercase tracking-[0.14em] text-brass-600">{eyebrow}</p>}
        <h1 className="font-serif text-3xl leading-tight text-navy-900">{title}</h1>
        {description && <p className="mt-1.5 max-w-3xl text-sm text-stone-600">{description}</p>}
        {meta && <div className="mt-2 flex flex-wrap items-center gap-2">{meta}</div>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </header>
  )
}

const AV = ['bg-navy-700', 'bg-navy-500', 'bg-brass-600', 'bg-ok-600', 'bg-sim-600', 'bg-stone-600']
export function Avatar({ name, size = 'md', className }: { name: string; size?: 'sm' | 'md' | 'lg'; className?: string }) {
  let h = 0; for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0
  const s = { sm: 'h-6 w-6 text-2xs', md: 'h-8 w-8 text-xs', lg: 'h-11 w-11 text-sm' }[size]
  return <span role="img" aria-label={name} title={name} className={cn('inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white', AV[h % AV.length], s, className)}>{initialsOf(name)}</span>
}

export interface TimelineItem { id: string; title: ReactNode; meta?: ReactNode; description?: ReactNode; tone?: Tone | 'brass'; icon?: ReactNode; time?: ReactNode }
export function Timeline({ items, className }: { items: TimelineItem[]; className?: string }) {
  const dot: Record<string, string> = { neutral: 'bg-stone-400', info: 'bg-navy-500', success: 'bg-ok-600', warning: 'bg-warn-600', danger: 'bg-bad-600', brass: 'bg-brass-500', simulated: 'bg-sim-600' }
  return (
    <ol className={cn('relative space-y-5 border-l border-stone-300 pl-6', className)}>
      {items.map((it) => (
        <li key={it.id} className="relative">
          <span className={cn('absolute -left-[1.9rem] top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full ring-4 ring-white', dot[it.tone ?? 'neutral'])} aria-hidden>{it.icon}</span>
          <div className="flex flex-wrap items-baseline justify-between gap-x-3">
            <p className="text-sm font-medium text-navy-900">{it.title}</p>{it.time && <time className="text-xs tabular-nums text-stone-600">{it.time}</time>}
          </div>
          {it.meta && <p className="text-xs text-stone-600">{it.meta}</p>}
          {it.description && <div className="mt-1 text-sm text-stone-700">{it.description}</div>}
        </li>
      ))}
    </ol>
  )
}

export function StatusStepper({ steps, current, className }: { steps: { key: string; label: string }[]; current: string; className?: string }) {
  const ci = steps.findIndex((s) => s.key === current)
  return (
    <ol className={cn('flex flex-wrap items-center gap-x-1 gap-y-2', className)} aria-label="Progress">
      {steps.map((s, i) => {
        const done = ci >= 0 && i < ci, cur = i === ci
        return (
          <li key={s.key} className="flex items-center gap-1" aria-current={cur ? 'step' : undefined}>
            <span className={cn('flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset', cur ? 'bg-navy-800 text-white ring-navy-800' : done ? 'bg-ok-50 text-ok-700 ring-ok-100' : 'bg-white text-stone-600 ring-stone-300')}>
              {done ? <Check className="h-3 w-3" aria-hidden /> : <span className="tabular-nums" aria-hidden>{i + 1}</span>}{s.label}
              <span className="sr-only">{done ? ' (complete)' : cur ? ' (current)' : ''}</span>
            </span>
            {i < steps.length - 1 && <ChevronRight className="h-3 w-3 text-stone-400" aria-hidden />}
          </li>
        )
      })}
    </ol>
  )
}
