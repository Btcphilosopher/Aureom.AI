import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react'
import { Loader2 } from 'lucide-react'
import { cn } from '@/lib/cn'

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'brass'
export type ButtonSize = 'sm' | 'md' | 'lg'

const VARIANT: Record<ButtonVariant, string> = {
  primary: 'bg-navy-800 text-white hover:bg-navy-700 active:bg-navy-900 disabled:bg-navy-300',
  brass: 'bg-brass-600 text-white hover:bg-brass-700 disabled:bg-brass-300',
  secondary: 'bg-white text-navy-800 ring-1 ring-inset ring-stone-300 hover:bg-ivory-100 disabled:text-stone-400',
  ghost: 'text-navy-700 hover:bg-navy-50 disabled:text-stone-400',
  danger: 'bg-bad-600 text-white hover:bg-bad-700 disabled:bg-bad-100 disabled:text-bad-600',
}
const SIZE: Record<ButtonSize, string> = { sm: 'h-8 px-3 text-xs gap-1.5', md: 'h-9 px-4 text-sm gap-2', lg: 'h-11 px-5 text-sm gap-2' }

export const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500 focus-visible:ring-offset-2 focus-visible:ring-offset-ivory-50'

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant; size?: ButtonSize; loading?: boolean; icon?: ReactNode
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', loading, icon, children, className, disabled, type = 'button', ...rest }, ref) {
  return (
    <button ref={ref} type={type} disabled={disabled || loading} aria-busy={loading || undefined}
      className={cn('inline-flex shrink-0 items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors disabled:cursor-not-allowed', focusRing, VARIANT[variant], SIZE[size], className)} {...rest}>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : icon}
      {children}
    </button>
  )
})

export interface IconButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'aria-label'> {
  'aria-label': string; variant?: 'ghost' | 'secondary' | 'dark'; size?: 'sm' | 'md'; children: ReactNode
}
export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { variant = 'ghost', size = 'md', className, children, type = 'button', ...rest }, ref) {
  const v = { ghost: 'text-stone-600 hover:bg-navy-50 hover:text-navy-900', secondary: 'bg-white ring-1 ring-inset ring-stone-300 text-navy-800 hover:bg-ivory-100', dark: 'text-navy-100 hover:bg-white/10 hover:text-white' }[variant]
  return <button ref={ref} type={type} title={rest['aria-label']} className={cn('inline-flex items-center justify-center rounded-md transition-colors disabled:opacity-50', size === 'sm' ? 'h-7 w-7' : 'h-9 w-9', focusRing, v, className)} {...rest}>{children}</button>
})
