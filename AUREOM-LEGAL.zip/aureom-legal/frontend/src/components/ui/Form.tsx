import { Children, cloneElement, forwardRef, isValidElement, useId, type InputHTMLAttributes, type ReactElement, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react'
import { Search, X } from 'lucide-react'
import { cn } from '@/lib/cn'

const base = 'block w-full rounded-md border border-stone-300 bg-white px-3 text-sm text-navy-900 placeholder:text-stone-500 transition-colors focus:border-brass-500 focus:outline-none focus:ring-2 focus:ring-brass-500/40 disabled:bg-stone-100 disabled:text-stone-500 aria-[invalid=true]:border-bad-600 aria-[invalid=true]:ring-bad-600/20'

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function Input({ className, ...p }, ref) {
  return <input ref={ref} className={cn(base, 'h-9', className)} {...p} />
})
export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea({ className, rows = 4, ...p }, ref) {
  return <textarea ref={ref} rows={rows} className={cn(base, 'py-2 leading-relaxed', className)} {...p} />
})
export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(function Select({ className, children, ...p }, ref) {
  return <select ref={ref} className={cn(base, 'h-9 pr-8', className)} {...p}>{children}</select>
})

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> { label: ReactNode; hint?: ReactNode }
export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox({ label, hint, className, id, ...p }, ref) {
  const gen = useId(); const cid = id ?? gen
  return (
    <div className={cn('flex items-start gap-2.5', className)}>
      <input ref={ref} id={cid} type="checkbox" className="mt-0.5 h-4 w-4 shrink-0 rounded border-stone-400 text-navy-800 accent-navy-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500 focus-visible:ring-offset-2" aria-describedby={hint ? `${cid}-hint` : undefined} {...p} />
      <label htmlFor={cid} className="text-sm text-navy-900">{label}{hint && <span id={`${cid}-hint`} className="block text-xs text-stone-600">{hint}</span>}</label>
    </div>
  )
})

export interface FieldControlProps { id: string; 'aria-describedby'?: string; 'aria-invalid'?: boolean; 'aria-required'?: boolean }
export interface FieldProps {
  label: ReactNode; hint?: ReactNode; error?: ReactNode; required?: boolean; className?: string
  /** Either an element (props injected via cloneElement) or a render function receiving the control props. */
  children: ReactElement | ((p: FieldControlProps) => ReactNode)
}
export function Field({ label, hint, error, required, className, children }: FieldProps) {
  const id = useId()
  const describedBy = [hint ? `${id}-hint` : '', error ? `${id}-err` : ''].filter(Boolean).join(' ') || undefined
  const props: FieldControlProps = { id, 'aria-describedby': describedBy, 'aria-invalid': error ? true : undefined, 'aria-required': required || undefined }
  const control = typeof children === 'function' ? children(props) : isValidElement(Children.only(children)) ? cloneElement(children as ReactElement<FieldControlProps>, props) : children
  return (
    <div className={cn('space-y-1.5', className)}>
      <label htmlFor={id} className="block text-xs font-semibold uppercase tracking-wide text-stone-700">
        {label}{required && <span className="ml-0.5 text-bad-600" aria-hidden>*</span>}{required && <span className="sr-only"> (required)</span>}
      </label>
      {control}
      {hint && <p id={`${id}-hint`} className="text-xs text-stone-600">{hint}</p>}
      {error && <p id={`${id}-err`} role="alert" className="text-xs font-medium text-bad-700">{error}</p>}
    </div>
  )
}

export interface SearchInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> { value: string; onValueChange: (v: string) => void }
export function SearchInput({ value, onValueChange, className, placeholder = 'Search…', ...p }: SearchInputProps) {
  return (
    <div className={cn('relative', className)}>
      <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" aria-hidden />
      <Input type="search" value={value} onChange={(e) => onValueChange(e.target.value)} placeholder={placeholder} className="pl-8 pr-8 [&::-webkit-search-cancel-button]:hidden" aria-label={p['aria-label'] ?? placeholder} {...p} />
      {value && <button type="button" onClick={() => onValueChange('')} aria-label="Clear search" className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1 text-stone-500 hover:text-navy-900"><X className="h-3.5 w-3.5" /></button>}
    </div>
  )
}
