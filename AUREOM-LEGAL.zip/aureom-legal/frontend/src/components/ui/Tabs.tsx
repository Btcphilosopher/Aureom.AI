import { useId, useRef, type KeyboardEvent, type ReactNode } from 'react'
import { cn } from '@/lib/cn'

export interface TabItem { id: string; label: ReactNode; badge?: ReactNode; disabled?: boolean }

/** Controlled tabs (WAI-ARIA tablist). Pair with <TabPanel id=… value=…>. Sync `value` with the URL if you want deep links. */
export function Tabs({ tabs, value, onChange, className, label = 'Sections' }: { tabs: TabItem[]; value: string; onChange: (id: string) => void; className?: string; label?: string }) {
  const uid = useId()
  const refs = useRef<Record<string, HTMLButtonElement | null>>({})
  const enabled = tabs.filter((t) => !t.disabled)
  const onKey = (e: KeyboardEvent) => {
    const i = enabled.findIndex((t) => t.id === value)
    let n = -1
    if (e.key === 'ArrowRight') n = (i + 1) % enabled.length
    else if (e.key === 'ArrowLeft') n = (i - 1 + enabled.length) % enabled.length
    else if (e.key === 'Home') n = 0
    else if (e.key === 'End') n = enabled.length - 1
    if (n >= 0) { e.preventDefault(); const t = enabled[n]!; onChange(t.id); refs.current[t.id]?.focus() }
  }
  return (
    <div role="tablist" aria-label={label} onKeyDown={onKey} className={cn('flex gap-1 overflow-x-auto border-b border-stone-300', className)}>
      {tabs.map((t) => {
        const sel = t.id === value
        return (
          <button key={t.id} ref={(el) => { refs.current[t.id] = el }} role="tab" id={`${uid}-tab-${t.id}`} aria-selected={sel} aria-controls={`${uid}-panel-${t.id}`} tabIndex={sel ? 0 : -1} disabled={t.disabled}
            onClick={() => onChange(t.id)} data-tabs-uid={uid}
            className={cn('-mb-px inline-flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500 disabled:cursor-not-allowed disabled:text-stone-400',
              sel ? 'border-brass-500 text-navy-900' : 'border-transparent text-stone-600 hover:border-stone-300 hover:text-navy-900')}>
            {t.label}{t.badge !== undefined && <span className="rounded-full bg-navy-100 px-1.5 text-2xs font-semibold tabular-nums text-navy-700">{t.badge}</span>}
          </button>
        )
      })}
    </div>
  )
}

export function TabPanel({ id, value, children, className }: { id: string; value: string; children: ReactNode; className?: string }) {
  if (id !== value) return null
  return <div role="tabpanel" tabIndex={0} aria-label={id} className={cn('pt-5 focus-visible:outline-none', className)}>{children}</div>
}
