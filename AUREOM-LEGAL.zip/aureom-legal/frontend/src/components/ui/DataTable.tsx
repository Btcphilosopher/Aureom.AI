import type { KeyboardEvent, ReactNode } from 'react'
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/cn'
import { Button } from './Button'
import { EmptyState, ErrorState, Skeleton } from './States'

export interface Column<T> {
  key: string
  header: ReactNode
  cell: (row: T, index: number) => ReactNode
  align?: 'left' | 'right' | 'center'
  /** right-aligned tabular numerals, e.g. money */
  numeric?: boolean
  sortable?: boolean
  width?: string
  className?: string
  /** hide below the tablet breakpoint */
  hideOnNarrow?: boolean
}
export interface SortState { key: string; dir: 'asc' | 'desc' }
export interface PaginationState { total: number; limit: number; offset: number; onChange: (offset: number) => void }

export interface DataTableProps<T> {
  columns: Column<T>[]
  rows: T[] | undefined
  rowKey: (row: T) => string
  /** accessible name for the table (visually hidden caption) */
  caption: string
  loading?: boolean
  error?: unknown
  onRetry?: () => void
  onRowClick?: (row: T) => void
  emptyTitle?: string
  emptyDescription?: ReactNode
  emptyAction?: ReactNode
  sort?: SortState
  onSortChange?: (s: SortState) => void
  pagination?: PaginationState
  zebra?: boolean
  dense?: boolean
  skeletonRows?: number
  rowClassName?: (row: T) => string | undefined
  className?: string
}

export function DataTable<T>({ columns, rows, rowKey, caption, loading, error, onRetry, onRowClick, emptyTitle = 'No records found', emptyDescription, emptyAction, sort, onSortChange, pagination, zebra, dense, skeletonRows = 6, rowClassName, className }: DataTableProps<T>) {
  const al = (c: Column<T>) => (c.numeric || c.align === 'right' ? 'text-right tabular-nums' : c.align === 'center' ? 'text-center' : 'text-left')
  const cellPad = dense ? 'px-3 py-1.5' : 'px-4 py-3'
  const toggle = (c: Column<T>) => {
    if (!c.sortable || !onSortChange) return
    onSortChange({ key: c.key, dir: sort?.key === c.key && sort.dir === 'asc' ? 'desc' : 'asc' })
  }
  const onKey = (e: KeyboardEvent, row: T) => { if (onRowClick && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); onRowClick(row) } }

  return (
    <div className={cn('overflow-hidden rounded-lg border border-stone-200 bg-white shadow-panel', className)}>
      <div className="overflow-auto">
        <table className="w-full border-collapse text-sm">
          <caption className="sr-only">{caption}</caption>
          <thead className="sticky top-0 z-10 bg-ivory-200">
            <tr className="border-b border-stone-300">
              {columns.map((c) => {
                const active = sort?.key === c.key
                return (
                  <th key={c.key} scope="col" style={c.width ? { width: c.width } : undefined}
                    aria-sort={active ? (sort!.dir === 'asc' ? 'ascending' : 'descending') : c.sortable ? 'none' : undefined}
                    className={cn(cellPad, 'whitespace-nowrap text-xs font-semibold uppercase tracking-wide text-stone-700', al(c), c.hideOnNarrow && 'hidden lg:table-cell')}>
                    {c.sortable ? (
                      <button type="button" onClick={() => toggle(c)} className={cn('inline-flex items-center gap-1 rounded uppercase hover:text-navy-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass-500', (c.numeric || c.align === 'right') && 'flex-row-reverse')}>
                        {c.header}
                        {active ? (sort!.dir === 'asc' ? <ArrowUp className="h-3 w-3" aria-hidden /> : <ArrowDown className="h-3 w-3" aria-hidden />) : <ArrowUpDown className="h-3 w-3 text-stone-400" aria-hidden />}
                      </button>
                    ) : c.header}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: skeletonRows }, (_, i) => (
              <tr key={`sk${i}`} className="border-b border-stone-100">
                {columns.map((c) => <td key={c.key} className={cn(cellPad, c.hideOnNarrow && 'hidden lg:table-cell')}><Skeleton className="h-4 w-full max-w-[12rem]" /></td>)}
              </tr>
            ))}
            {!loading && !error && rows?.map((row, i) => (
              <tr key={rowKey(row)} tabIndex={onRowClick ? 0 : undefined} onClick={onRowClick ? () => onRowClick(row) : undefined} onKeyDown={(e) => onKey(e, row)}
                className={cn('border-b border-stone-100 last:border-0', zebra && i % 2 === 1 && 'bg-ivory-50', onRowClick && 'cursor-pointer hover:bg-brass-50/60 focus-visible:bg-brass-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass-500', rowClassName?.(row))}>
                {columns.map((c) => <td key={c.key} className={cn(cellPad, 'align-middle text-navy-900', al(c), c.hideOnNarrow && 'hidden lg:table-cell', c.className)}>{c.cell(row, i)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!!error && !loading && <ErrorState error={error} onRetry={onRetry} />}
      {!loading && !error && rows && rows.length === 0 && <EmptyState title={emptyTitle} description={emptyDescription} action={emptyAction} />}
      {pagination && !error && <Pagination {...pagination} />}
    </div>
  )
}

export function Pagination({ total, limit, offset, onChange }: PaginationState) {
  if (total <= 0) return null
  const from = offset + 1, to = Math.min(offset + limit, total)
  const page = Math.floor(offset / limit) + 1, pages = Math.max(1, Math.ceil(total / limit))
  return (
    <nav aria-label="Pagination" className="flex items-center justify-between gap-3 border-t border-stone-200 bg-ivory-50 px-4 py-2.5 text-xs text-stone-700">
      <p aria-live="polite">Showing <span className="font-semibold tabular-nums">{from}–{to}</span> of <span className="font-semibold tabular-nums">{total}</span></p>
      <div className="flex items-center gap-2">
        <span className="tabular-nums">Page {page} of {pages}</span>
        <Button size="sm" variant="secondary" disabled={offset <= 0} onClick={() => onChange(Math.max(0, offset - limit))} aria-label="Previous page"><ChevronLeft className="h-3.5 w-3.5" /></Button>
        <Button size="sm" variant="secondary" disabled={offset + limit >= total} onClick={() => onChange(offset + limit)} aria-label="Next page"><ChevronRight className="h-3.5 w-3.5" /></Button>
      </div>
    </nav>
  )
}
