import type { ReactNode } from 'react'
import { FlaskConical } from 'lucide-react'
import { cn } from '@/lib/cn'
import { humanise } from '@/lib/format'
import { statusTone, type Tone } from '@/lib/status'

const TONE: Record<Tone, string> = {
  neutral: 'bg-stone-100 text-stone-700 ring-stone-300',
  info: 'bg-navy-50 text-navy-700 ring-navy-200',
  success: 'bg-ok-50 text-ok-700 ring-ok-100',
  warning: 'bg-warn-50 text-warn-700 ring-warn-100',
  danger: 'bg-bad-50 text-bad-700 ring-bad-100',
  brass: 'bg-brass-50 text-brass-700 ring-brass-200',
  // dashed ring + icon make mock / demonstration results visibly different from real ones
  simulated: 'bg-sim-50 text-sim-700 ring-sim-600/50',
}

export function Badge({ tone = 'neutral', children, className, dot }: { tone?: Tone; children: ReactNode; className?: string; dot?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-1 whitespace-nowrap rounded px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-wide ring-1 ring-inset', TONE[tone], tone === 'simulated' && 'outline-dashed outline-1 -outline-offset-1 outline-sim-600/60', className)}>
      {tone === 'simulated' && <FlaskConical className="h-3 w-3" aria-hidden />}
      {dot && <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden />}
      {children}
    </span>
  )
}

/** Badge from a backend status string: <StatusBadge status="pending_approval" /> */
export function StatusBadge({ status, tone, label }: { status: string | null | undefined; tone?: Tone; label?: string }) {
  return <Badge tone={tone ?? statusTone(status)}>{label ?? humanise(status)}</Badge>
}
