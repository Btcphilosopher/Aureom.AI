import type { Config } from 'tailwindcss'

// AUREOM LEGAL design tokens: midnight navy, warm ivory, restrained brass.
// Text on ivory uses navy-800+ / stone-700+ / brass-600+ to stay AA-compliant.
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: { 50: '#F1F4F9', 100: '#E1E7F0', 200: '#C3CEE0', 300: '#94A6C4', 400: '#62799F', 500: '#3B5380', 600: '#1B3358', 700: '#14284A', 800: '#0E1E38', 900: '#0A1730', 950: '#070F1E' },
        ivory: { 50: '#FDFCF8', 100: '#FAF7F0', 200: '#F3EEE2', 300: '#E8E1D0', 400: '#D9D0BA' },
        brass: { 50: '#FBF7EC', 100: '#F4EBD0', 200: '#E6D4A0', 300: '#C9A961', 400: '#B8933F', 500: '#A8812F', 600: '#8A6A24', 700: '#6B521C' },
        stone: { 50: '#FAF9F7', 100: '#F3F1ED', 200: '#E7E4DD', 300: '#D3CFC5', 400: '#A9A498', 500: '#7C776C', 600: '#5E5A51', 700: '#47443D', 800: '#2F2D29', 900: '#1C1B19' },
        ok: { 50: '#EAF5EF', 100: '#CFE8DB', 600: '#1F6B4A', 700: '#17533A' },
        warn: { 50: '#FBF3E2', 100: '#F5E3B8', 600: '#8A5A00', 700: '#6E4700' },
        bad: { 50: '#FAECEC', 100: '#F2CFCF', 600: '#9B2C2C', 700: '#7C2222' },
        sim: { 50: '#F1ECFA', 100: '#DED3F3', 600: '#5B3E9A', 700: '#47307A' },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
        serif: ['"Iowan Old Style"', '"Palatino Linotype"', 'Palatino', 'Georgia', 'ui-serif', 'Cambria', 'serif'],
      },
      boxShadow: {
        panel: '0 1px 0 rgba(14,30,56,0.04), 0 1px 3px rgba(14,30,56,0.06)',
        pop: '0 12px 32px -8px rgba(7,15,30,0.28), 0 2px 6px rgba(7,15,30,0.12)',
      },
      fontSize: { '2xs': ['0.6875rem', '1rem'] },
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'slide-up': { from: { opacity: '0', transform: 'translateY(6px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        'slide-left': { from: { transform: 'translateX(100%)' }, to: { transform: 'translateX(0)' } },
      },
      animation: { 'fade-in': 'fade-in .15s ease-out', 'slide-up': 'slide-up .18s ease-out', 'slide-left': 'slide-left .2s ease-out' },
    },
  },
  plugins: [],
} satisfies Config
