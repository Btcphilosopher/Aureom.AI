#!/bin/sh
# Creates the NON-superuser application role. The API connects as this role so row-level security is enforced;
# the owner role (POSTGRES_USER) is used only by migrations and the demo seed.
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'aureom_app') THEN
    CREATE ROLE aureom_app LOGIN PASSWORD '${APP_DB_PASSWORD}' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
  END IF;
END \$\$;
GRANT CONNECT ON DATABASE ${POSTGRES_DB} TO aureom_app;
SQL
