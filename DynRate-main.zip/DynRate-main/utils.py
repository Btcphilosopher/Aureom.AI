"""
dynrate/utils.py
─────────────────────────────────────────────────────────────────────────────
Utility helpers for the DynRate engine.

Responsibilities:
  • Structured audit logging (newline-delimited JSON / JSONL)
  • Numerical helpers (clamp, APR ↔ APY conversion, compound-interest math)
  • Balance-tier lookup
  • Input validation guards
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import json
import logging
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np

from dynrate.config import (
    BALANCE_TIER_ADJUSTMENTS,
    COMPOUNDING_FREQUENCIES,
    DAYS_IN_YEAR,
    LOG_DIR,
    LOG_FILE,
    LOG_LEVEL,
    AccountType,
)


# ─────────────────────────────────────────────────────────────────────────────
# Structured Audit Logger
# ─────────────────────────────────────────────────────────────────────────────

class AuditLogger:
    """
    Writes rate-change events to a newline-delimited JSON (JSONL) file.

    Each record is a self-contained JSON object containing:
      • ISO-8601 UTC timestamp
      • account_id / account_type
      • previous_rate / new_rate
      • triggering factors (scenario, risk tier, balance tier, etc.)
      • a human-readable description

    The JSONL format allows streaming ingest into analytics pipelines
    (e.g. BigQuery, Redshift, Splunk) without any schema migration.
    """

    def __init__(self, log_dir: str = LOG_DIR, log_file: str = LOG_FILE) -> None:
        self._log_path = Path(log_dir) / log_file
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        # Simultaneously emit to the console / application log
        self._logger = logging.getLogger("dynrate.audit")
        if not self._logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter("%(asctime)s  %(levelname)-8s  %(message)s")
            )
            self._logger.addHandler(handler)
        self._logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))

    # ── Public API ────────────────────────────────────────────────────────────

    def log_rate_event(
        self,
        account_id:    str,
        account_type:  str,
        previous_rate: float,
        new_rate:      float,
        factors:       Dict[str, Any],
        description:   str = "",
    ) -> None:
        """Append a single rate-change record to the audit log."""
        record = {
            "timestamp":     datetime.now(timezone.utc).isoformat(),
            "account_id":    account_id,
            "account_type":  account_type,
            "previous_rate": round(previous_rate, 6),
            "new_rate":      round(new_rate, 6),
            "delta_bps":     round((new_rate - previous_rate) * 10_000, 2),
            "factors":       factors,
            "description":   description,
        }
        with open(self._log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")

        self._logger.info(
            "Rate event | account=%s type=%s prev=%.4f%% new=%.4f%% Δ=%.1f bps",
            account_id,
            account_type,
            previous_rate * 100,
            new_rate * 100,
            record["delta_bps"],
        )

    def export_logs(self, output_path: Optional[str] = None) -> list[dict]:
        """
        Read all audit records from the JSONL file and return as a list of dicts.
        Optionally write a pretty-printed JSON export to *output_path*.
        """
        if not self._log_path.exists():
            return []

        records: list[dict] = []
        with open(self._log_path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    records.append(json.loads(line))

        if output_path:
            Path(output_path).write_text(
                json.dumps(records, indent=2), encoding="utf-8"
            )

        return records

    def clear_logs(self) -> None:
        """Truncate the audit log file (useful in tests)."""
        if self._log_path.exists():
            self._log_path.write_text("", encoding="utf-8")


# ─────────────────────────────────────────────────────────────────────────────
# Numerical Helpers
# ─────────────────────────────────────────────────────────────────────────────

def clamp(value: float, lo: float, hi: float) -> float:
    """
    Clamp *value* to the closed interval [lo, hi].

    Uses max/min rather than numpy to avoid dtype coercion on plain floats.
    """
    return max(lo, min(hi, value))


def apr_to_apy(apr: float, n: int = 12) -> float:
    """
    Convert Annual Percentage Rate (APR) to Annual Percentage Yield (APY).

    APY = (1 + APR / n)^n  – 1

    where *n* is the compounding frequency (default: monthly = 12).
    This conversion is required by Regulation Z disclosures.
    """
    if n <= 0:
        raise ValueError(f"Compounding frequency must be positive, got {n}")
    return (1.0 + apr / n) ** n - 1.0


def apy_to_apr(apy: float, n: int = 12) -> float:
    """
    Convert Annual Percentage Yield (APY) back to APR.

    APR = n * ((1 + APY)^(1/n) – 1)
    """
    if n <= 0:
        raise ValueError(f"Compounding frequency must be positive, got {n}")
    return n * ((1.0 + apy) ** (1.0 / n) - 1.0)


def compound_interest(
    principal:    float,
    annual_rate:  float,
    days:         int,
    frequency:    str = "monthly",
    days_in_year: int = DAYS_IN_YEAR,
) -> Tuple[float, float]:
    """
    Calculate compound interest for a given principal over *days* calendar days.

    Uses the standard compound-interest formula:
        A = P * (1 + r/n)^(n * t)
    where:
        P = principal
        r = annual rate (decimal)
        n = compounding periods per year
        t = time in years  (= days / days_in_year)

    Returns
    -------
    (final_amount, interest_earned) : both rounded to 2 d.p.
    """
    if principal < 0:
        raise ValueError("Principal cannot be negative")
    if annual_rate < 0:
        raise ValueError("Annual rate cannot be negative")
    if days < 0:
        raise ValueError("Days cannot be negative")

    n = COMPOUNDING_FREQUENCIES.get(frequency, 12)
    t = days / days_in_year
    final = principal * (1.0 + annual_rate / n) ** (n * t)
    return round(final, 2), round(final - principal, 2)


def simple_interest(
    principal:   float,
    annual_rate: float,
    days:        int,
    days_in_year: int = DAYS_IN_YEAR,
) -> Tuple[float, float]:
    """
    Calculate simple interest (used for short-duration loan products).

        Interest = P * r * (days / days_in_year)
    """
    interest = principal * annual_rate * (days / days_in_year)
    return round(principal + interest, 2), round(interest, 2)


def effective_monthly_rate(annual_rate: float) -> float:
    """
    Derive the effective monthly rate from an annual nominal rate.

    Used when amortising loan repayment schedules.
    monthly_rate = (1 + annual_rate)^(1/12) – 1
    """
    return (1.0 + annual_rate) ** (1.0 / 12) - 1.0


def loan_monthly_payment(
    principal:   float,
    annual_rate: float,
    months:      int,
) -> float:
    """
    Calculate the fixed monthly repayment for a fully-amortising loan.

    Uses the standard annuity formula:
        PMT = P * r / (1 – (1 + r)^(-n))

    where r = effective monthly rate, n = loan term in months.
    Falls back to simple division if rate ≈ 0 (zero-interest loan).
    """
    if months <= 0:
        raise ValueError("Loan term must be at least 1 month")
    if principal <= 0:
        raise ValueError("Principal must be positive")

    r = effective_monthly_rate(annual_rate)
    if abs(r) < 1e-10:
        # Zero-interest edge case – straight-line repayment
        return round(principal / months, 2)

    pmt = principal * r / (1.0 - (1.0 + r) ** (-months))
    return round(pmt, 2)


# ─────────────────────────────────────────────────────────────────────────────
# Balance Tier Lookup
# ─────────────────────────────────────────────────────────────────────────────

def get_balance_tier_adjustment(account_type: AccountType, balance: float) -> float:
    """
    Return the rate adjustment (decimal) for the given account type and balance.

    Iterates over the tier band definitions in config.BALANCE_TIER_ADJUSTMENTS.
    Returns 0.0 if no matching tier is found (defensive default).
    """
    tiers = BALANCE_TIER_ADJUSTMENTS.get(account_type, {})
    for (lo, hi), adjustment in tiers.items():
        if lo <= balance < hi:
            return adjustment
    return 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Input validation
# ─────────────────────────────────────────────────────────────────────────────

def validate_rate_inputs(
    balance:     float,
    account_type: AccountType,
) -> None:
    """
    Raise ValueError with a descriptive message for clearly invalid inputs.
    Called at the entry point of the rate engine to catch bad data early.
    """
    if not isinstance(account_type, AccountType):
        raise ValueError(
            f"account_type must be an AccountType enum, got {type(account_type)}"
        )
    if not math.isfinite(balance):
        raise ValueError(f"Balance must be finite, got {balance}")
    if balance < 0:
        raise ValueError(f"Balance cannot be negative, got {balance}")


def format_rate_display(rate: float) -> str:
    """Return a human-readable percentage string, e.g. 4.75%."""
    return f"{rate * 100:.4f}%"


# ─────────────────────────────────────────────────────────────────────────────
# Seed helper for reproducible simulation runs
# ─────────────────────────────────────────────────────────────────────────────

def set_global_seed(seed: int = 42) -> None:
    """Seed both the Python random module and NumPy for reproducible results."""
    import random
    random.seed(seed)
    np.random.seed(seed)
