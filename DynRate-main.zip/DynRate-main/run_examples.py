"""
examples/run_examples.py
─────────────────────────────────────────────────────────────────────────────
DynRate Complete Demonstration Script

Covers:
  1.  Savings account — dynamic interest with real-time rate breakdown
  2.  Loan account — variable rate, amortisation schedule, RL optimisation
  3.  Multi-scenario comparison across all market conditions
  4.  AI / ML model training and rate prediction
  5.  Historical rate-hiking cycle simulation (2022-style)
  6.  Interest impact analysis (£ delta per scenario)
  7.  Stress test / boundary validation
  8.  Audit log export
  9.  FastAPI integration snippet

Run from the project root:
    cd dynrate
    python examples/run_examples.py
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd

pd.set_option("display.float_format", "{:.4f}".format)
pd.set_option("display.max_columns", 20)
pd.set_option("display.width", 120)

from dynrate import (
    AccountType,
    CustomerProfile,
    DynRateEngine,
    EngineConfig,
    GradientBoostingRateModel,
    HistoricalSimulator,
    MarketScenario,
    MultiScenarioSimulator,
    RLRateOptimiser,
    RiskTier,
    StressTester,
    generate_scenario_report,
    loan_monthly_payment,
)

DIVIDER = "═" * 72


def header(title: str) -> None:
    print(f"\n{DIVIDER}")
    print(f"  {title}")
    print(DIVIDER)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Savings Account — Dynamic Interest
# ─────────────────────────────────────────────────────────────────────────────

def demo_savings_account() -> None:
    header("1. SAVINGS ACCOUNT — Dynamic Interest Calculation")

    engine = DynRateEngine(config=EngineConfig(log_dir="logs"))

    # Standard mid-tier saver
    profile = CustomerProfile(
        account_id=             "SAV-ALICE-001",
        account_type=           AccountType.SAVINGS,
        balance=                22_500.0,
        risk_tier=              RiskTier.LOW,
        monthly_transactions=   18,          # Active customer
        months_since_opened=    36,          # 3-year customer
    )

    result = engine.calculate_rate(profile, log=True)

    print(f"\n  Customer : Alice")
    print(f"  Balance  : £{profile.balance:,.2f}")
    print(f"  Risk     : {profile.risk_tier.value.upper()}")
    print()
    print(f"  ► Annual Rate (APR) : {result.annual_rate * 100:.4f}%")
    print(f"  ► Effective APY     : {result.effective_apy * 100:.4f}%")
    print()
    print("  Rate Breakdown (basis points):")
    for factor, value in result.breakdown.items():
        bps  = value * 10_000
        sign = "+" if bps >= 0 else ""
        print(f"    {factor:<30s}  {sign}{bps:.1f} bps")

    # Project 12-month savings growth
    print("\n  12-Month Savings Projection (with reinvestment):")
    snapshots = engine.simulate_future_interest(profile, horizon_months=12, reinvest=True)
    df = pd.DataFrame(snapshots)
    df["opening_balance"]  = df["opening_balance"].map("£{:,.2f}".format)
    df["interest_earned"]  = df["interest_earned"].map("£{:,.2f}".format)
    df["closing_balance"]  = df["closing_balance"].map("£{:,.2f}".format)
    print(df[["month","opening_balance","annual_rate_pct","interest_earned","closing_balance"]].to_string(index=False))


# ─────────────────────────────────────────────────────────────────────────────
# 2. Loan Account — Variable Rate & Amortisation
# ─────────────────────────────────────────────────────────────────────────────

def demo_loan_account() -> None:
    header("2. LOAN ACCOUNT — Variable Repayment Rates & Amortisation")

    engine = DynRateEngine()

    # Medium-risk personal loan, steady repayment history
    loan_profile = CustomerProfile(
        account_id=                    "LOAN-BOB-001",
        account_type=                  AccountType.LOAN,
        balance=                       18_500.0,
        risk_tier=                     RiskTier.MEDIUM,
        consecutive_on_time_payments=  14,    # Loyalty discount kicks in
        has_late_payments=             False,
    )

    result = engine.calculate_rate(loan_profile, log=True)
    pmt    = loan_monthly_payment(loan_profile.balance, result.annual_rate, 36)

    print(f"\n  Customer  : Bob")
    print(f"  Principal : £{loan_profile.balance:,.2f}")
    print(f"  Term      : 36 months")
    print(f"  On-time payments streak : {loan_profile.consecutive_on_time_payments}")
    print()
    print(f"  ► Loan Rate (APR)     : {result.annual_rate * 100:.4f}%")
    print(f"  ► Monthly Payment     : £{pmt:,.2f}")
    print()

    schedule = engine.amortise_loan(loan_profile, term_months=36)
    total_interest   = sum(e.interest_portion   for e in schedule)
    total_principal  = sum(e.principal_portion  for e in schedule)

    print(f"  Total Interest Paid   : £{total_interest:,.2f}")
    print(f"  Total Principal Paid  : £{total_principal:,.2f}")
    print(f"  Total Cost of Credit  : £{(total_interest + total_principal):,.2f}")
    print()
    print("  First 6 months of amortisation:")
    print(f"  {'Month':>5}  {'Opening':>12}  {'Payment':>10}  {'Interest':>10}  {'Principal':>11}  {'Closing':>12}")
    print("  " + "-"*65)
    for row in schedule[:6]:
        print(
            f"  {row.month:>5}  "
            f"£{row.opening_balance:>11,.2f}  "
            f"£{row.payment:>9,.2f}  "
            f"£{row.interest_portion:>9,.2f}  "
            f"£{row.principal_portion:>10,.2f}  "
            f"£{row.closing_balance:>11,.2f}"
        )

    # Compare: high-risk borrower with late payments
    print("\n  ── Comparison: High-Risk Borrower with Late Payments ──")
    risky_profile = CustomerProfile(
        account_id=       "LOAN-RISKY-001",
        account_type=     AccountType.LOAN,
        balance=          18_500.0,
        risk_tier=        RiskTier.HIGH,
        has_late_payments=True,
    )
    risky_result = engine.calculate_rate(risky_profile, log=False)
    risky_pmt    = loan_monthly_payment(risky_profile.balance, risky_result.annual_rate, 36)
    extra_pm     = risky_pmt - pmt

    print(f"  High-risk APR         : {risky_result.annual_rate * 100:.4f}%")
    print(f"  High-risk Monthly PMT : £{risky_pmt:,.2f}")
    print(f"  Extra cost / month    : £{extra_pm:,.2f}")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Multi-Scenario Comparison
# ─────────────────────────────────────────────────────────────────────────────

def demo_multi_scenario() -> None:
    header("3. MULTI-SCENARIO COMPARISON")

    portfolio = [
        CustomerProfile("P-SAVINGS",  AccountType.SAVINGS,  15_000.0, RiskTier.MEDIUM),
        CustomerProfile("P-CHECKING", AccountType.CHECKING,  3_500.0, RiskTier.MEDIUM),
        CustomerProfile("P-LOAN",     AccountType.LOAN,     25_000.0, RiskTier.MEDIUM),
    ]

    sim   = MultiScenarioSimulator()
    pivot = sim.pivot_by_scenario(portfolio)

    print("\n  Annual Rate (%) per Account × Scenario:")
    print()
    print(pivot.to_string(index=False))

    print("\n  Annual Interest Impact (£) vs NORMAL scenario (365 days):")
    impact = sim.interest_impact_analysis(portfolio, horizon_days=365)
    impact_pivot = impact.pivot_table(
        index="account_id", columns="scenario",
        values="delta_vs_normal_£", aggfunc="first"
    ).reset_index()
    print(impact_pivot.to_string(index=False))


# ─────────────────────────────────────────────────────────────────────────────
# 4. AI / ML Rate Prediction
# ─────────────────────────────────────────────────────────────────────────────

def demo_ai_model() -> None:
    header("4. AI / ML RATE PREDICTION (Gradient Boosting + RL)")

    # ── Supervised model ──────────────────────────────────────────────────────
    print("\n  Training GradientBoostingRateModel on 8,000 synthetic samples…")
    gbm_model = GradientBoostingRateModel()
    df        = GradientBoostingRateModel.generate_synthetic_training_data(
        n_samples=8_000
    )
    metrics   = gbm_model.fit_from_dataframe(df)

    print(f"  MAE  : {metrics['mae'] * 10_000:.2f} bps")
    print(f"  R²   : {metrics['r2']:.4f}")
    print(f"  Train: {metrics['n_train']:,} samples  Test: {metrics['n_test']:,} samples")

    print("\n  Top Feature Importances:")
    fi = gbm_model.feature_importances().head(5)
    for feat, imp in fi.items():
        print(f"    {feat:<40s}  {imp:.4f}")

    # Attach model to engine and compute AI-enhanced rate
    engine = DynRateEngine(ai_model=gbm_model)
    profile = CustomerProfile(
        account_id=   "AI-CAROL-001",
        account_type= AccountType.SAVINGS,
        balance=      50_000.0,
        risk_tier=    RiskTier.LOW,
        monthly_transactions=20,
    )
    result = engine.calculate_rate(profile, log=False)
    print(f"\n  AI-Enhanced Rate for Carol (£50k savings, LOW risk):")
    print(f"  APR: {result.annual_rate * 100:.4f}%  |  APY: {result.effective_apy * 100:.4f}%")
    print(f"  ML adjustment: {result.breakdown.get('ml_adjustment', 0) * 10_000:+.1f} bps")

    # ── Reinforcement learning ─────────────────────────────────────────────────
    print("\n  Training RL Rate Optimiser (Q-learning, 3,000 episodes)…")
    agent   = RLRateOptimiser()
    summary = agent.train(n_episodes=3_000)
    print(f"  Final ε: {summary['final_epsilon']:.4f}")
    print(f"  Q-table states visited: {summary['q_table_states']}")
    print(f"  Avg reward (last 100): {summary['avg_reward_last100']:.4f}")

    policy = agent.policy_summary()
    print("\n  Learned Policy Sample (Savings, Normal scenario):")
    sample = policy[
        (policy["account_type"] == "savings") &
        (policy["scenario"] == "normal")
    ].head(5)
    if not sample.empty:
        print(sample.to_string(index=False))


# ─────────────────────────────────────────────────────────────────────────────
# 5. Historical Rate-Hiking Cycle Simulation
# ─────────────────────────────────────────────────────────────────────────────

def demo_historical_simulation() -> None:
    header("5. HISTORICAL SIMULATION — 2022-Style Rate-Hiking Cycle")

    portfolio = [
        CustomerProfile("HIST-SAVER", AccountType.SAVINGS, 20_000.0, RiskTier.LOW),
        CustomerProfile("HIST-LOAN",  AccountType.LOAN,    30_000.0, RiskTier.MEDIUM),
    ]

    sim      = HistoricalSimulator()
    timeline = HistoricalSimulator.build_rate_hike_timeline(
        start_date=      "2022-01-01",
        months=          12,
        start_benchmark= 0.0050,    # Start: 0.5%
    )

    print(f"\n  Timeline: {timeline[0].date} → {timeline[-1].date}")
    print(f"  Benchmark: {timeline[0].benchmark_rate:.2%} → {timeline[-1].benchmark_rate:.2%}")
    print()

    df = sim.replay(portfolio, timeline, log=False)

    # Pivot: dates as rows, account rates as columns
    pivot = df.pivot_table(
        index=  "date",
        columns="account_id",
        values= "annual_rate_pct",
        aggfunc="first",
    ).reset_index()
    pivot.columns.name = None

    # Print every other month for brevity
    print("  Rate evolution over 2022 hiking cycle:")
    print(f"  {'Date':<12}  {'Saver APR':>12}  {'Loan APR':>10}  {'Scenario':<18}  {'Benchmark':>10}")
    print("  " + "-"*65)
    timeline_map = {e.date: (e.benchmark_rate, e.scenario.value) for e in timeline}
    for _, row in pivot.iloc[::2].iterrows():
        bench, scen = timeline_map.get(row["date"], (0, "—"))
        saver_col = "HIST-SAVER" if "HIST-SAVER" in pivot.columns else pivot.columns[1]
        loan_col  = "HIST-LOAN"  if "HIST-LOAN"  in pivot.columns else pivot.columns[2]
        print(
            f"  {row['date']:<12}  "
            f"{row.get(saver_col, '—'):>11.4f}%  "
            f"{row.get(loan_col, '—'):>9.4f}%  "
            f"{scen:<18}  "
            f"{bench:>9.2%}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# 6. Full Scenario Report
# ─────────────────────────────────────────────────────────────────────────────

def demo_full_report() -> None:
    header("6. FULL SCENARIO REPORT — Portfolio × All Scenarios")

    portfolio = [
        CustomerProfile("RPT-SAV-LOW",  AccountType.SAVINGS,  50_000.0, RiskTier.LOW),
        CustomerProfile("RPT-SAV-HIGH", AccountType.SAVINGS,   2_000.0, RiskTier.HIGH),
        CustomerProfile("RPT-LOAN-MED", AccountType.LOAN,     40_000.0, RiskTier.MEDIUM),
    ]

    report = generate_scenario_report(portfolio, output_csv="logs/scenario_report.csv")
    print("\n  Full report (15 rows):")
    cols = ["account_id","scenario","annual_rate_%","monthly_interest_£","annual_interest_£"]
    print(report[cols].to_string(index=False))
    print("\n  ✓ Full CSV saved to logs/scenario_report.csv")


# ─────────────────────────────────────────────────────────────────────────────
# 7. Stress Test
# ─────────────────────────────────────────────────────────────────────────────

def demo_stress_test() -> None:
    header("7. STRESS TEST — Regulatory Boundary Validation")

    tester = StressTester()
    result = tester.run_boundary_check(n_samples=2_000)

    status = "✅ PASSED" if result["passed"] else "❌ FAILED"
    print(f"\n  Status          : {status}")
    print(f"  Profiles tested : {result['tested']:,}")
    print(f"  Violations      : {result['violations']}")
    print(f"  Violation rate  : {result['violation_rate']:.4%}")

    print("\n  Sensitivity Matrix — SAVINGS, MEDIUM risk:")
    matrix = tester.sensitivity_matrix(AccountType.SAVINGS, RiskTier.MEDIUM)
    print(matrix.to_string())


# ─────────────────────────────────────────────────────────────────────────────
# 8. Audit Log Export
# ─────────────────────────────────────────────────────────────────────────────

def demo_audit_log() -> None:
    header("8. AUDIT LOG — Export & Review")

    import os
    os.makedirs("logs", exist_ok=True)

    engine = DynRateEngine(config=EngineConfig(log_dir="logs"))

    # Trigger several rate calculations to populate the log
    profiles = [
        CustomerProfile("AUD-001", AccountType.SAVINGS,   10_000.0, RiskTier.LOW),
        CustomerProfile("AUD-002", AccountType.LOAN,      25_000.0, RiskTier.HIGH, has_late_payments=True),
        CustomerProfile("AUD-003", AccountType.CHECKING,   3_000.0, RiskTier.MEDIUM),
    ]
    for p in profiles:
        for scenario in [MarketScenario.NORMAL, MarketScenario.INFLATIONARY]:
            engine.calculate_rate(p, scenario=scenario, log=True)

    records = engine.get_audit_log()
    engine.export_audit_log("logs/audit_export.json")

    print(f"\n  Total audit records : {len(records)}")
    print("\n  Most recent 3 entries:")
    for rec in records[-3:]:
        print(
            f"    [{rec['timestamp'][:19]}Z]  "
            f"{rec['account_id']:<12}  "
            f"prev={rec['previous_rate'] * 100:.3f}%  "
            f"new={rec['new_rate'] * 100:.3f}%  "
            f"Δ={rec['delta_bps']:+.1f} bps  "
            f"scenario={rec['factors'].get('scenario','?')}"
        )
    print("\n  ✓ Full audit export saved to logs/audit_export.json")


# ─────────────────────────────────────────────────────────────────────────────
# 9. FastAPI Integration Snippet
# ─────────────────────────────────────────────────────────────────────────────

def demo_fastapi_snippet() -> None:
    header("9. FASTAPI INTEGRATION GUIDE")
    print("""
  Add to your FastAPI app (requirements: fastapi, uvicorn, pydantic):

  ─────────────────────────────────────────────────────────────────────
  # api/routes/rates.py

  from fastapi   import APIRouter, HTTPException
  from pydantic  import BaseModel, Field
  from typing    import Optional

  from dynrate   import (
      DynRateEngine, CustomerProfile, EngineConfig,
      AccountType, RiskTier, MarketScenario
  )

  router = APIRouter(prefix="/rates", tags=["Interest Rates"])

  # Initialise once at startup (thread-safe, stateless per calculation)
  _engine = DynRateEngine(config=EngineConfig(log_dir="/var/log/dynrate"))


  class RateRequest(BaseModel):
      account_id:    str
      account_type:  AccountType
      balance:       float              = Field(gt=0)
      risk_tier:     RiskTier           = RiskTier.MEDIUM
      monthly_transactions:  int        = 0
      months_since_opened:   int        = 0
      has_late_payments:     bool       = False
      scenario:      Optional[MarketScenario] = None


  @router.post("/calculate")
  def calculate_rate(req: RateRequest):
      profile = CustomerProfile(**req.model_dump(exclude={"scenario"}))
      try:
          result = _engine.calculate_rate(profile, scenario=req.scenario)
      except ValueError as exc:
          raise HTTPException(status_code=422, detail=str(exc))
      return result.to_dict()


  @router.post("/apply")
  def apply_rate(req: RateRequest, days: int = 30):
      profile = CustomerProfile(**req.model_dump(exclude={"scenario"}))
      app     = _engine.apply_rate(profile, days=days, scenario=req.scenario)
      return app.to_dict()


  @router.get("/simulate/{account_id}")
  def simulate(account_id: str, balance: float, months: int = 12):
      profile = CustomerProfile(
          account_id=account_id, account_type=AccountType.SAVINGS,
          balance=balance,
      )
      return _engine.simulate_future_interest(profile, horizon_months=months)

  ─────────────────────────────────────────────────────────────────────

  Mount in main.py:
      app.include_router(rates_router)

  Example cURL:
      curl -X POST http://localhost:8000/rates/calculate \\
           -H 'Content-Type: application/json' \\
           -d '{"account_id":"C1","account_type":"savings","balance":15000}'
""")


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import os
    os.makedirs("logs", exist_ok=True)

    print("\n" + "█" * 72)
    print("  DynRate: Dynamic Interest Engine — Full Demonstration")
    print("█" * 72)

    demo_savings_account()
    demo_loan_account()
    demo_multi_scenario()
    demo_ai_model()
    demo_historical_simulation()
    demo_full_report()
    demo_stress_test()
    demo_audit_log()
    demo_fastapi_snippet()

    print(f"\n{DIVIDER}")
    print("  All demonstrations complete.")
    print(f"{DIVIDER}\n")
