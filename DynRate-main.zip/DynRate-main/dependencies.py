"""
api/dependencies.py
─────────────────────────────────────────────────────────────────────────────
FastAPI dependency-injection providers.

The DynRateEngine is initialised once at application startup and shared
across all requests.  This is safe because the engine is stateless per
rate-calculation call (all mutable state lives inside EngineConfig, which
is protected behind a lock for the rare admin mutation endpoints).
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import threading
from functools import lru_cache
from typing import Optional

from dynrate import DynRateEngine, GradientBoostingRateModel
from dynrate.config import EngineConfig, MarketScenario


class EngineState:
    """
    Application-level singleton wrapping the DynRateEngine.

    Mutations (benchmark rate, scenario) are guarded by a threading.Lock
    so they are safe in multi-worker ASGI deployments with shared state.
    In a distributed setup (multiple Uvicorn workers), mutations should be
    propagated via a Redis pub-sub or similar mechanism instead.
    """

    def __init__(self) -> None:
        self._lock   = threading.Lock()
        self._engine: Optional[DynRateEngine] = None
        self._ml_ready = False

    def initialise(
        self,
        log_dir:    str = "logs",
        load_ml:    bool = True,
        ml_samples: int = 5_000,
    ) -> None:
        """
        Build and configure the engine.  Called once from app lifespan.

        If *load_ml* is True, trains a GBM model on synthetic data so that
        ML-enhanced rates are available immediately on startup.  Disable for
        faster cold-start in environments where pure-rules rates are sufficient.
        """
        with self._lock:
            config = EngineConfig(log_dir=log_dir)
            ai_model = None

            if load_ml:
                try:
                    ai_model = GradientBoostingRateModel()
                    df = GradientBoostingRateModel.generate_synthetic_training_data(
                        n_samples=ml_samples
                    )
                    metrics = ai_model.fit_from_dataframe(df)
                    self._ml_ready = True
                    import logging
                    logging.getLogger("dynrate.api").info(
                        "ML model ready — MAE=%.2f bps  R²=%.4f",
                        metrics["mae"] * 10_000,
                        metrics["r2"],
                    )
                except Exception as exc:
                    import logging
                    logging.getLogger("dynrate.api").warning(
                        "ML model failed to load (%s). Running rules-only.", exc
                    )
                    ai_model = None

            self._engine = DynRateEngine(config=config, ai_model=ai_model)

    @property
    def engine(self) -> DynRateEngine:
        if self._engine is None:
            raise RuntimeError("Engine not initialised. Call initialise() first.")
        return self._engine

    @property
    def ml_ready(self) -> bool:
        return self._ml_ready

    def update_benchmark(self, rate: float) -> None:
        with self._lock:
            self.engine.update_benchmark_rate(rate)

    def update_scenario(self, scenario: MarketScenario) -> None:
        with self._lock:
            self.engine.update_scenario(scenario)


# Module-level singleton — shared across the entire application process
_engine_state = EngineState()


def get_engine_state() -> EngineState:
    """FastAPI dependency that yields the shared EngineState."""
    return _engine_state


def get_engine() -> DynRateEngine:
    """FastAPI dependency that yields the DynRateEngine directly."""
    return _engine_state.engine
