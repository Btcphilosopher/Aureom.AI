"""
dynrate/simulator.py
─────────────────────────────────────────────────────────────────────────────
DynRate Scenario Simulator

Provides tools for:

1. MultiScenarioSimulator  – run a portfolio of accounts through every
   defined market scenario and compare resulting rates / interest.

2. HistoricalSimulator     – replay a synthetic or provided time-series of
   market events (rate hikes, scenario transitions) against a customer
   portfolio to validate engine behaviour over time.

3. StressTest              – push parameter combinations to extremes and
   verify that the engine's output stays within regulatory bounds.

4. generate_scenario_report() – produce a structured DataFrame summary
   ready for management / risk reporting.
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from dynrate.config import (
    BENCHMARK_RATE,
    RATE_BOUNDS,
    SCENARIO_MULTIPLIERS,
    AccountType,
    EngineConfig,
    MarketScenario,
    RiskTier,
)
from dynrate.engine import CustomerProfile, DynRateEngine, RateResult
from dynrate.utils import format_rate_display, set_global_seed

logger = logging.getLogger("dynrate.simulator")


# ─────────────────────────────────────────────────────────────────────────────
# Data Classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ScenarioSnapshot:
    """Rate result for one account under one scenario."""
    account_id:   str
    account_type: str
    scenario:     str
    annual_rate:  float
    effective_apy: float
    risk_tier:    str
    balance:      float

    def to_dict(self) -> dict:
        return {
            "account_id":      self.account_id,
            "account_type":    self.account_type,
            "scenario":        self.scenario,
            "annual_rate_pct": round(self.annual_rate * 100, 4),
            "effective_apy_pct": round(self.effective_apy * 100, 4),
            "risk_tier":       self.risk_tier,
            "balance":         self.balance,
        }


@dataclass
class TimeSeriesEvent:
    """A single event in a historical simulation timeline."""
    date:              str                      # ISO date string
    scenario:          MarketScenario
    benchmark_rate:    float
    description:       str = ""


# ─────────────────────────────────────────────────────────────────────────────
# Multi-Scenario Simulator
# ─────────────────────────────────────────────────────────────────────────────

class MultiScenarioSimulator:
    """
    Run a portfolio of CustomerProfiles through all (or a subset of)
    MarketScenarios and collect the resulting rates.

    Useful for:
      • What-if analysis ("what rates would we offer in a recession?")
      • Sensitivity analysis for risk management
      • Backtesting model outputs vs. historical decisions
    """

    def __init__(
        self,
        engine:   Optional[DynRateEngine] = None,
        config:   Optional[EngineConfig]  = None,
    ) -> None:
        self.engine = engine or DynRateEngine(config=config or EngineConfig())

    def run(
        self,
        profiles:  List[CustomerProfile],
        scenarios: Optional[List[MarketScenario]] = None,
        log:       bool = False,
    ) -> pd.DataFrame:
        """
        Calculate rates for every (profile × scenario) combination.

        Parameters
        ----------
        profiles  : list of CustomerProfile objects to evaluate.
        scenarios : subset of MarketScenario to test (default: all).
        log       : pass through to the engine's audit logger.

        Returns
        -------
        pd.DataFrame  — one row per (profile, scenario) combination.
        """
        scenarios = scenarios or list(MarketScenario)
        rows: List[dict] = []

        for scenario in scenarios:
            for profile in profiles:
                result: RateResult = self.engine.calculate_rate(
                    profile, scenario=scenario, log=log
                )
                rows.append({
                    "account_id":       result.account_id,
                    "account_type":     result.account_type,
                    "scenario":         result.scenario,
                    "annual_rate_pct":  round(result.annual_rate * 100, 4),
                    "effective_apy_pct": round(result.effective_apy * 100, 4),
                    "risk_tier":        result.risk_tier,
                    "balance":          profile.balance,
                    # Key breakdown components
                    "base_rate_pct":      round(result.breakdown.get("base_rate", 0) * 100, 4),
                    "scenario_adj_pct":   round(result.breakdown.get("scenario_adjustment", 0) * 100, 4),
                    "risk_spread_pct":    round(result.breakdown.get("risk_spread", 0) * 100, 4),
                    "behaviour_adj_pct":  round(result.breakdown.get("behaviour_adjustment", 0) * 100, 4),
                    "ml_adj_pct":         round(result.breakdown.get("ml_adjustment", 0) * 100, 4),
                })

        df = pd.DataFrame(rows)
        return df

    def pivot_by_scenario(
        self,
        profiles:  List[CustomerProfile],
        scenarios: Optional[List[MarketScenario]] = None,
    ) -> pd.DataFrame:
        """
        Return a pivoted view: accounts as rows, scenarios as columns,
        values = annual rate %.  Useful for side-by-side scenario comparison.
        """
        df = self.run(profiles, scenarios)
        pivot = df.pivot_table(
            index=  ["account_id", "account_type", "risk_tier", "balance"],
            columns="scenario",
            values= "annual_rate_pct",
            aggfunc="first",
        ).reset_index()
        pivot.columns.name = None
        return pivot

    def interest_impact_analysis(
        self,
        profiles:        List[CustomerProfile],
        horizon_days:    int = 365,
        scenarios:       Optional[List[MarketScenario]] = None,
    ) -> pd.DataFrame:
        """
        For each (profile, scenario) pair, calculate the total interest
        earned/charged over *horizon_days* and the difference vs. the
        NORMAL scenario baseline.

        Returns a DataFrame with a 'delta_vs_normal_£' column.
        """
        from dynrate.utils import compound_interest as ci

        scenarios = scenarios or list(MarketScenario)
        rows: List[dict] = []

        for scenario in scenarios:
            for profile in profiles:
                result = self.engine.calculate_rate(
                    profile, scenario=scenario, log=False
                )
                _, interest = ci(
                    principal=   profile.balance,
                    annual_rate= result.annual_rate,
                    days=        horizon_days,
                    frequency=   "monthly",
                )
                rows.append({
                    "account_id":    profile.account_id,
                    "account_type":  profile.account_type.value,
                    "scenario":      scenario.value,
                    "balance":       profile.balance,
                    "annual_rate":   result.annual_rate,
                    "interest_£":    interest,
                })

        df = pd.DataFrame(rows)

        # Compute delta vs. NORMAL baseline
        normal_map = (
            df[df["scenario"] == MarketScenario.NORMAL.value]
            .set_index("account_id")["interest_£"]
            .to_dict()
        )
        df["baseline_interest_£"] = df["account_id"].map(normal_map)
        df["delta_vs_normal_£"]   = (
            df["interest_£"] - df["baseline_interest_£"]
        ).round(2)

        return df


# ─────────────────────────────────────────────────────────────────────────────
# Historical Simulator (Time-Series Replay)
# ─────────────────────────────────────────────────────────────────────────────

class HistoricalSimulator:
    """
    Replay a timeline of market events against a customer portfolio.

    The timeline is a sequence of TimeSeriesEvent objects that specify
    the market scenario and benchmark rate at each point in time.
    The engine's state is updated at each event, and the resulting rates
    are recorded for each profile.

    This enables:
      • Backtesting: did our engine produce sensible rates during 2022's
        rate-hiking cycle?
      • Forward scenarios: model what happens if rates rise another 100 bps.
    """

    def __init__(self, config: Optional[EngineConfig] = None) -> None:
        self.engine = DynRateEngine(config=config or EngineConfig())

    @staticmethod
    def build_rate_hike_timeline(
        start_date:       str,
        months:           int,
        start_benchmark:  float = 0.0050,
        hike_schedule:    Optional[List[Tuple[int, float]]] = None,
        base_scenario:    MarketScenario = MarketScenario.NORMAL,
    ) -> List[TimeSeriesEvent]:
        """
        Construct a synthetic timeline representing a rate-hiking cycle.

        Parameters
        ----------
        start_date      : ISO date string (e.g. '2022-01-01')
        months          : total simulation horizon in months
        start_benchmark : initial central-bank benchmark rate
        hike_schedule   : list of (month_number, rate_increase) tuples.
                          Default: 8 hikes of 25 bps starting at month 3.
        base_scenario   : macro scenario that persists unless overridden.

        Returns a list of TimeSeriesEvent, one per month.
        """
        if hike_schedule is None:
            # Simulate 2022-style hiking cycle: 8 × 25 bps
            hike_schedule = [(m, 0.0025) for m in range(3, 11)]

        hike_map = dict(hike_schedule)
        events: List[TimeSeriesEvent] = []
        current_rate = start_benchmark
        base_dt = datetime.fromisoformat(start_date)

        for month in range(months):
            current_rate += hike_map.get(month, 0.0)
            dt = base_dt + timedelta(days=30 * month)

            # Shift to inflationary scenario during aggressive hiking
            scenario = base_scenario
            if current_rate > 0.04:
                scenario = MarketScenario.INFLATIONARY
            if current_rate > 0.06:
                scenario = MarketScenario.HIGH_VOLATILITY

            events.append(TimeSeriesEvent(
                date=           dt.strftime("%Y-%m-%d"),
                scenario=       scenario,
                benchmark_rate= round(current_rate, 4),
                description=    f"Month {month}: benchmark={current_rate:.2%}",
            ))

        return events

    def replay(
        self,
        profiles:  List[CustomerProfile],
        timeline:  List[TimeSeriesEvent],
        log:       bool = False,
    ) -> pd.DataFrame:
        """
        Replay the timeline against all profiles.

        Returns a long-format DataFrame with columns:
          date, account_id, scenario, benchmark_rate, annual_rate_pct
        """
        rows: List[dict] = []

        for event in timeline:
            # Update engine state for this time point
            self.engine.update_benchmark_rate(event.benchmark_rate)
            self.engine.update_scenario(event.scenario)

            for profile in profiles:
                result = self.engine.calculate_rate(
                    profile, scenario=event.scenario, log=log
                )
                rows.append({
                    "date":             event.date,
                    "account_id":       result.account_id,
                    "account_type":     result.account_type,
                    "scenario":         event.scenario.value,
                    "benchmark_rate":   event.benchmark_rate,
                    "annual_rate_pct":  round(result.annual_rate * 100, 4),
                    "effective_apy_pct": round(result.effective_apy * 100, 4),
                })

        return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# Stress Tester
# ─────────────────────────────────────────────────────────────────────────────

class StressTester:
    """
    Verify that the engine respects regulatory bounds under all parameter
    combinations.  Designed to be run as part of the CI pipeline.
    """

    def __init__(self, config: Optional[EngineConfig] = None) -> None:
        self.engine = DynRateEngine(config=config or EngineConfig())

    def run_boundary_check(
        self,
        n_samples: int = 1_000,
        seed:      int = 42,
    ) -> Dict[str, Any]:
        """
        Generate random profiles and assert that all calculated rates fall
        within regulatory bounds.

        Returns a summary dict with violation counts and pass/fail status.
        """
        set_global_seed(seed)
        rng = np.random.default_rng(seed)

        account_types = list(AccountType)
        risk_tiers    = list(RiskTier)
        scenarios     = list(MarketScenario)
        violations: List[dict] = []
        tested = 0

        for _ in range(n_samples):
            account_type = account_types[int(rng.integers(len(account_types)))]
            risk_tier    = risk_tiers[int(rng.integers(len(risk_tiers)))]
            scenario     = scenarios[int(rng.integers(len(scenarios)))]
            balance      = float(rng.uniform(0, 2_000_000))

            profile = CustomerProfile(
                account_id=   f"STRESS-{tested:04d}",
                account_type= account_type,
                balance=      balance,
                risk_tier=    risk_tier,
                monthly_transactions=         int(rng.integers(0, 60)),
                months_since_opened=          int(rng.integers(0, 120)),
                consecutive_on_time_payments= int(rng.integers(0, 36)),
                has_late_payments=            bool(rng.integers(0, 2)),
            )

            result = self.engine.calculate_rate(
                profile, scenario=scenario, log=False
            )
            lo, hi = RATE_BOUNDS[account_type]

            if not (lo <= result.annual_rate <= hi):
                violations.append({
                    "account_id":   profile.account_id,
                    "account_type": account_type.value,
                    "scenario":     scenario.value,
                    "rate":         result.annual_rate,
                    "expected_lo":  lo,
                    "expected_hi":  hi,
                })
            tested += 1

        return {
            "tested":         tested,
            "violations":     len(violations),
            "violation_rate": len(violations) / tested,
            "passed":         len(violations) == 0,
            "violation_details": violations,
        }

    def sensitivity_matrix(
        self,
        account_type: AccountType = AccountType.SAVINGS,
        risk_tier:    RiskTier    = RiskTier.MEDIUM,
    ) -> pd.DataFrame:
        """
        Generate a sensitivity matrix of rates across all scenario ×
        balance-band combinations for a given account_type / risk_tier pair.
        """
        balance_bands = [500, 5_000, 25_000, 100_000, 500_000]
        scenarios     = list(MarketScenario)
        rows: List[dict] = []

        for scenario in scenarios:
            row: dict = {"scenario": scenario.value}
            for balance in balance_bands:
                profile = CustomerProfile(
                    account_id=   f"SENS-{account_type.value}-{balance}",
                    account_type= account_type,
                    balance=      float(balance),
                    risk_tier=    risk_tier,
                )
                result = self.engine.calculate_rate(
                    profile, scenario=scenario, log=False
                )
                row[f"£{balance:,}"] = f"{result.annual_rate * 100:.3f}%"
            rows.append(row)

        return pd.DataFrame(rows).set_index("scenario")


# ─────────────────────────────────────────────────────────────────────────────
# Report Generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_scenario_report(
    profiles:   List[CustomerProfile],
    config:     Optional[EngineConfig] = None,
    output_csv: Optional[str]          = None,
) -> pd.DataFrame:
    """
    Generate a comprehensive scenario report for a portfolio of accounts.

    For each profile × scenario combination, computes:
      • Applied rate
      • Effective APY
      • Monthly interest (30-day projection)
      • Annual interest (365-day projection)

    Optionally writes the result to a CSV file.

    Parameters
    ----------
    profiles   : list of CustomerProfile objects.
    config     : optional EngineConfig override.
    output_csv : path to write the report CSV.

    Returns pd.DataFrame with the full report.
    """
    from dynrate.utils import compound_interest as ci

    engine = DynRateEngine(config=config or EngineConfig())
    rows: List[dict] = []

    for scenario in MarketScenario:
        for profile in profiles:
            result = engine.calculate_rate(
                profile, scenario=scenario, log=False
            )
            _, monthly_interest = ci(
                profile.balance, result.annual_rate, 30, "monthly"
            )
            _, annual_interest = ci(
                profile.balance, result.annual_rate, 365, "monthly"
            )
            rows.append({
                "account_id":          profile.account_id,
                "account_type":        profile.account_type.value,
                "balance_£":           profile.balance,
                "risk_tier":           profile.risk_tier.value,
                "scenario":            scenario.value,
                "annual_rate_%":       round(result.annual_rate * 100, 4),
                "effective_apy_%":     round(result.effective_apy * 100, 4),
                "monthly_interest_£":  monthly_interest,
                "annual_interest_£":   annual_interest,
            })

    df = pd.DataFrame(rows).sort_values(
        ["account_id", "scenario"]
    ).reset_index(drop=True)

    if output_csv:
        df.to_csv(output_csv, index=False)
        logger.info("Scenario report written to %s", output_csv)

    return df
