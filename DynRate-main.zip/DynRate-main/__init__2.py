"""
DynRate: Dynamic Interest Engine
─────────────────────────────────────────────────────────────────────────────
Public API surface.  Import from here rather than from individual submodules
to maintain a stable interface regardless of internal refactoring.

Quick start
-----------
    from dynrate import DynRateEngine, CustomerProfile, AccountType, RiskTier

    engine  = DynRateEngine()
    profile = CustomerProfile(
        account_id   = "ACC-001",
        account_type = AccountType.SAVINGS,
        balance      = 15_000.0,
        risk_tier    = RiskTier.LOW,
    )
    result = engine.calculate_rate(profile)
    print(result.to_dict())
─────────────────────────────────────────────────────────────────────────────
"""

from dynrate.config import (
    AccountType,
    EngineConfig,
    MarketScenario,
    RiskTier,
)
from dynrate.engine import (
    CustomerProfile,
    DynRateEngine,
    InterestApplication,
    LoanScheduleEntry,
    RateResult,
)
from dynrate.ai_model import (
    GradientBoostingRateModel,
    RLRateOptimiser,
)
from dynrate.simulator import (
    HistoricalSimulator,
    MultiScenarioSimulator,
    StressTester,
    TimeSeriesEvent,
    generate_scenario_report,
)
from dynrate.utils import (
    AuditLogger,
    apr_to_apy,
    apy_to_apr,
    compound_interest,
    format_rate_display,
    loan_monthly_payment,
    simple_interest,
)

__version__ = "1.0.0"
__author__  = "DynRate Financial Engineering Team"

__all__ = [
    # Config / Enums
    "AccountType",
    "EngineConfig",
    "MarketScenario",
    "RiskTier",
    # Engine
    "CustomerProfile",
    "DynRateEngine",
    "InterestApplication",
    "LoanScheduleEntry",
    "RateResult",
    # AI / ML
    "GradientBoostingRateModel",
    "RLRateOptimiser",
    # Simulator
    "HistoricalSimulator",
    "MultiScenarioSimulator",
    "StressTester",
    "TimeSeriesEvent",
    "generate_scenario_report",
    # Utils
    "AuditLogger",
    "apr_to_apy",
    "apy_to_apr",
    "compound_interest",
    "format_rate_display",
    "loan_monthly_payment",
    "simple_interest",
]
