"""
api/routes/rates.py
─────────────────────────────────────────────────────────────────────────────
/rates  —  core interest-rate endpoints

  POST /rates/calculate     → calculate rate for one account
  POST /rates/apply         → apply rate and return interest earned
  POST /rates/simulate      → month-by-month projection
  POST /rates/batch         → calculate rates for up to 100 accounts
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status

from dynrate import CustomerProfile, AccountType
from dynrate.engine import DynRateEngine

from api.dependencies import get_engine
from api.schemas import (
    ApplyRateRequest,
    InterestApplicationResponse,
    RateRequest,
    RateResponse,
    SimulateFutureRequest,
    SimulationSnapshot,
)

router = APIRouter(prefix="/rates", tags=["Interest Rates"])


def _profile_from_request(req: RateRequest) -> CustomerProfile:
    """Convert a validated RateRequest to a CustomerProfile."""
    return CustomerProfile(
        account_id=                   req.account_id,
        account_type=                 req.account_type,
        balance=                      req.balance,
        risk_tier=                    req.risk_tier,
        monthly_transactions=         req.monthly_transactions,
        months_since_opened=          req.months_since_opened,
        consecutive_on_time_payments= req.consecutive_on_time_payments,
        has_late_payments=            req.has_late_payments,
        ml_predicted_rate=            req.ml_predicted_rate,
    )


@router.post(
    "/calculate",
    response_model=RateResponse,
    summary="Calculate the current interest rate for an account",
    responses={422: {"description": "Invalid input parameters"}},
)
def calculate_rate(
    req:    RateRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> RateResponse:
    """
    Run the full 8-step rate pipeline for a single account and return
    the rate, APY, and a complete factor breakdown.

    The breakdown shows the contribution of every pipeline step in basis
    points — supporting open-banking explainability mandates.
    """
    try:
        profile = _profile_from_request(req)
        result  = engine.calculate_rate(profile, scenario=req.scenario, log=True)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=str(exc))
    return RateResponse(**result.to_dict())


@router.post(
    "/apply",
    response_model=InterestApplicationResponse,
    summary="Apply an interest rate to an account for N days",
)
def apply_rate(
    req:    ApplyRateRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> InterestApplicationResponse:
    """
    Calculate and apply the interest rate for *days* days.
    Returns the final balance and total interest earned / charged.
    """
    try:
        profile = _profile_from_request(req)
        app     = engine.apply_rate(
            profile,
            days=        req.days,
            compounding= req.compounding,
            scenario=    req.scenario,
            log=         True,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return InterestApplicationResponse(**app.to_dict())


@router.post(
    "/simulate",
    response_model=List[SimulationSnapshot],
    summary="Project interest earnings month-by-month",
)
def simulate_future(
    req:    SimulateFutureRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> List[SimulationSnapshot]:
    """
    Project interest earnings over *horizon_months* months.

    When *reinvest* is True (default), compounding applies — interest
    earned each month is added back to the principal.
    """
    try:
        profile   = _profile_from_request(req)
        snapshots = engine.simulate_future_interest(
            profile,
            horizon_months= req.horizon_months,
            scenario=        req.scenario,
            reinvest=        req.reinvest,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return [SimulationSnapshot(**s) for s in snapshots]


@router.post(
    "/batch",
    response_model=List[RateResponse],
    summary="Calculate rates for up to 100 accounts in a single request",
)
def batch_calculate(
    requests: List[RateRequest],
    engine:   DynRateEngine = Depends(get_engine),
) -> List[RateResponse]:
    """
    Batch rate calculation — useful for nightly repricing jobs or
    bulk portfolio revaluations.  Returns results in input order.
    """
    if len(requests) > 100:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="Maximum 100 accounts per batch request",
        )
    results: List[RateResponse] = []
    errors:  List[str]          = []

    for req in requests:
        try:
            profile = _profile_from_request(req)
            result  = engine.calculate_rate(profile, scenario=req.scenario, log=True)
            results.append(RateResponse(**result.to_dict()))
        except (ValueError, Exception) as exc:
            errors.append(f"{req.account_id}: {exc}")

    if errors:
        raise HTTPException(
            status_code=422,
            detail=f"Some accounts failed: {'; '.join(errors[:5])}",
        )
    return results
