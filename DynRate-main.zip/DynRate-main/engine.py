"""
dynrate/engine.py
─────────────────────────────────────────────────────────────────────────────
DynRate Core Engine

This module is the heart of the interest-rate system.  It exposes a single
public class – DynRateEngine – whose methods calculate, apply, and simulate
interest rates for any account type.

Rate Composition Pipeline (executed in order):
 ┌─────────────────────────────────────────────────────────────────────┐
 │ 1. BASE RATE      — default rate for the account type               │
 │ 2. MARKET ADJUST  — scenario multiplier (recession, inflation, etc.) │
 │ 3. BENCHMARK TETHER — pull rate toward central-bank policy rate     │
 │ 4. BALANCE TIER   — volume-based discount / premium                 │
 │ 5. RISK SPREAD    — customer risk-tier spread                       │
 │ 6. BEHAVIOUR ADJ  — transaction activity bonus / late-pay penalty   │
 │ 7. ML OVERRIDE    — (optional) ML-predicted optimal rate            │
 │ 8. CLAMP          — hard floor / ceiling per regulatory bounds      │
 └─────────────────────────────────────────────────────────────────────┘
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import numpy as np

from dynrate.config import (
    ACTIVE_ACCOUNT_BONUS,
    ACTIVE_TRANSACTION_THRESHOLD,
    BASE_RATES,
    BENCHMARK_RATE,
    LATE_PAYMENT_PENALTY,
    LOYAL_REPAYMENT_MONTHS,
    LOYALTY_RATE_DISCOUNT,
    NIM_SPREAD,
    RISK_SPREADS,
    SCENARIO_MULTIPLIERS,
    AccountType,
    EngineConfig,
    MarketScenario,
    RiskTier,
)
from dynrate.utils import (
    AuditLogger,
    apr_to_apy,
    clamp,
    compound_interest,
    format_rate_display,
    get_balance_tier_adjustment,
    loan_monthly_payment,
    validate_rate_inputs,
)


# ─────────────────────────────────────────────────────────────────────────────
# Data Transfer Objects
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CustomerProfile:
    """
    Immutable snapshot of a customer's financial profile at the point of
    rate calculation.  Passed into the engine; never mutated inside it.
    """
    account_id:                   str
    account_type:                 AccountType
    balance:                      float
    risk_tier:                    RiskTier               = RiskTier.MEDIUM

    # Behavioural signals
    monthly_transactions:         int                    = 0
    months_since_opened:          int                    = 0
    consecutive_on_time_payments: int                    = 0   # Loan-specific
    has_late_payments:            bool                   = False

    # Optional override – if the caller already has an ML-predicted rate
    ml_predicted_rate:            Optional[float]        = None

    # Arbitrary metadata passed through to the audit log
    metadata:                     Dict[str, Any]         = field(default_factory=dict)


@dataclass
class RateResult:
    """
    Output of a single rate-calculation run.  Carries both the headline rate
    and a complete breakdown of every factor that contributed to it so that
    the caller can explain the rate to the customer (open-banking mandate).
    """
    account_id:        str
    account_type:      str
    annual_rate:       float         # Nominal APR (decimal)
    effective_apy:     float         # Effective APY after compounding
    scenario:          str
    risk_tier:         str
    calculation_ts:    str           # ISO-8601

    # Breakdown: each pipeline step and its contribution (decimal)
    breakdown: Dict[str, float]      = field(default_factory=dict)

    # Human-readable summary
    description: str                 = ""

    def to_dict(self) -> dict:
        """Serialise to a plain dict (suitable for JSON API responses)."""
        return {
            "account_id":    self.account_id,
            "account_type":  self.account_type,
            "annual_rate":   round(self.annual_rate * 100, 4),
            "annual_rate_pct": format_rate_display(self.annual_rate),
            "effective_apy": round(self.effective_apy * 100, 4),
            "effective_apy_pct": format_rate_display(self.effective_apy),
            "scenario":      self.scenario,
            "risk_tier":     self.risk_tier,
            "calculation_ts": self.calculation_ts,
            "breakdown_pct": {
                k: round(v * 100, 4) for k, v in self.breakdown.items()
            },
            "description":   self.description,
        }


@dataclass
class InterestApplication:
    """
    Result of applying an interest rate to an account for a given period.
    """
    account_id:       str
    principal:        float
    annual_rate:      float
    days:             int
    compounding:      str
    final_amount:     float
    interest_earned:  float
    calculation_ts:   str

    def to_dict(self) -> dict:
        return {
            "account_id":      self.account_id,
            "principal":       self.principal,
            "annual_rate_pct": format_rate_display(self.annual_rate),
            "days":            self.days,
            "compounding":     self.compounding,
            "final_amount":    self.final_amount,
            "interest_earned": self.interest_earned,
            "calculation_ts":  self.calculation_ts,
        }


@dataclass
class LoanScheduleEntry:
    """Single row in a loan amortisation schedule."""
    month:             int
    opening_balance:   float
    payment:           float
    principal_portion: float
    interest_portion:  float
    closing_balance:   float


# ─────────────────────────────────────────────────────────────────────────────
# Core Engine
# ─────────────────────────────────────────────────────────────────────────────

class DynRateEngine:
    """
    DynRateEngine: Stateless interest-rate calculation engine.

    Design principles
    -----------------
    * Stateless per calculation – each call to `calculate_rate` is independent.
    * Composable pipeline – each factor is isolated in its own private method
      so it can be unit-tested and overridden individually.
    * Audit-first – every rate decision is written to the structured JSONL log.
    * ML-ready – accepts an optional AIRateModel to blend learned predictions
      into the pipeline without coupling to any specific ML framework.

    Parameters
    ----------
    config : EngineConfig
        Runtime configuration (base rates, scenario, compounding, etc.).
    ai_model : optional
        An object exposing `.predict(profile) -> float`.  When provided,
        its prediction is blended into the final rate (see step 7 above).
    """

    def __init__(
        self,
        config:   Optional[EngineConfig] = None,
        ai_model: Any                    = None,
    ) -> None:
        self.config   = config or EngineConfig()
        self.ai_model = ai_model
        self._logger  = AuditLogger(
            log_dir=self.config.log_dir,
            log_file=self.config.log_file,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    def calculate_rate(
        self,
        profile:  CustomerProfile,
        scenario: Optional[MarketScenario] = None,
        log:      bool = True,
    ) -> RateResult:
        """
        Run the full rate-calculation pipeline for *profile* and return a
        RateResult with a complete factor breakdown.

        Parameters
        ----------
        profile  : CustomerProfile – customer and account data.
        scenario : override the engine-level scenario for this call only.
        log      : write the rate event to the audit log (default True).
        """
        validate_rate_inputs(profile.balance, profile.account_type)

        active_scenario = scenario or self.config.scenario
        breakdown: Dict[str, float] = {}

        # ── Step 1 : Base Rate ─────────────────────────────────────────────
        rate = self.config.base_rates.get(
            profile.account_type,
            BASE_RATES[profile.account_type],
        )
        breakdown["base_rate"] = rate

        # ── Step 2 : Market / Scenario Multiplier ─────────────────────────
        multiplier = SCENARIO_MULTIPLIERS.get(active_scenario, 1.0)
        scenario_adjustment = rate * (multiplier - 1.0)
        rate = rate * multiplier
        breakdown["scenario_adjustment"] = scenario_adjustment

        # ── Step 3 : Benchmark Tether ──────────────────────────────────────
        # Pull the rate toward (benchmark + NIM spread) with a 30 % weight.
        # This prevents rates from diverging wildly from market reality.
        benchmark_target = self.config.benchmark_rate + self.config.nim_spread
        tether_weight    = 0.30
        benchmark_adj    = tether_weight * (benchmark_target - rate)
        rate            += benchmark_adj
        breakdown["benchmark_tether"] = benchmark_adj

        # ── Step 4 : Balance Tier Adjustment ──────────────────────────────
        balance_adj = get_balance_tier_adjustment(
            profile.account_type, profile.balance
        )
        rate += balance_adj
        breakdown["balance_tier"] = balance_adj

        # ── Step 5 : Risk Spread ───────────────────────────────────────────
        risk_spread = self._compute_risk_spread(
            profile.account_type, profile.risk_tier
        )
        rate += risk_spread
        breakdown["risk_spread"] = risk_spread

        # ── Step 6 : Behavioural Adjustments ──────────────────────────────
        behaviour_adj = self._compute_behaviour_adjustment(profile)
        rate         += behaviour_adj
        breakdown["behaviour_adjustment"] = behaviour_adj

        # ── Step 7 : ML Override (optional blend) ─────────────────────────
        ml_adj = 0.0
        if self.ai_model is not None or profile.ml_predicted_rate is not None:
            ml_adj = self._apply_ml_blend(rate, profile, active_scenario)
            rate   = rate + ml_adj
        breakdown["ml_adjustment"] = ml_adj

        # ── Step 8 : Regulatory Clamp ──────────────────────────────────────
        lo, hi = self.config.rate_bounds.get(
            profile.account_type,
            (0.0, 1.0),
        )
        clamped_rate = clamp(rate, lo, hi)
        clamp_adj    = clamped_rate - rate
        breakdown["regulatory_clamp"] = clamp_adj
        rate = clamped_rate

        # ── Compute effective APY ──────────────────────────────────────────
        n   = 12  # monthly compounding for APY disclosure
        apy = apr_to_apy(rate, n)

        result = RateResult(
            account_id=     profile.account_id,
            account_type=   profile.account_type.value,
            annual_rate=    round(rate, 6),
            effective_apy=  round(apy, 6),
            scenario=       active_scenario.value,
            risk_tier=      profile.risk_tier.value,
            calculation_ts= datetime.now(timezone.utc).isoformat(),
            breakdown=      breakdown,
            description=    self._build_description(profile, rate, active_scenario),
        )

        if log:
            self._logger.log_rate_event(
                account_id=    profile.account_id,
                account_type=  profile.account_type.value,
                previous_rate= breakdown["base_rate"],
                new_rate=      rate,
                factors={
                    "scenario":            active_scenario.value,
                    "risk_tier":           profile.risk_tier.value,
                    "balance":             profile.balance,
                    "monthly_transactions": profile.monthly_transactions,
                    "has_late_payments":   profile.has_late_payments,
                    "ml_used":             self.ai_model is not None,
                },
                description=   result.description,
            )

        return result

    def apply_rate(
        self,
        profile:     CustomerProfile,
        days:        int,
        compounding: Optional[str] = None,
        scenario:    Optional[MarketScenario] = None,
        log:         bool = False,
    ) -> InterestApplication:
        """
        Apply the calculated interest rate to the account for *days* days.

        Returns an InterestApplication with final balance and interest earned.
        """
        rate_result  = self.calculate_rate(profile, scenario=scenario, log=log)
        comp_freq    = compounding or self.config.default_compounding
        final, earned = compound_interest(
            principal=   profile.balance,
            annual_rate= rate_result.annual_rate,
            days=        days,
            frequency=   comp_freq,
            days_in_year=self.config.days_in_year,
        )
        return InterestApplication(
            account_id=      profile.account_id,
            principal=       profile.balance,
            annual_rate=     rate_result.annual_rate,
            days=            days,
            compounding=     comp_freq,
            final_amount=    final,
            interest_earned= earned,
            calculation_ts=  datetime.now(timezone.utc).isoformat(),
        )

    def simulate_future_interest(
        self,
        profile:        CustomerProfile,
        horizon_months: int,
        scenario:       Optional[MarketScenario] = None,
        reinvest:       bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Project interest earnings month-by-month over *horizon_months*.

        When *reinvest* is True, interest earned each month is added back
        to the running balance (compound effect).  When False, the principal
        stays flat (simple projection).

        Returns a list of monthly snapshot dicts.
        """
        snapshots: List[Dict[str, Any]] = []
        running_balance = profile.balance

        for month in range(1, horizon_months + 1):
            # Re-profile with the updated balance each month
            monthly_profile = CustomerProfile(
                account_id=   profile.account_id,
                account_type= profile.account_type,
                balance=      running_balance,
                risk_tier=    profile.risk_tier,
                monthly_transactions=         profile.monthly_transactions,
                months_since_opened=          profile.months_since_opened + month - 1,
                consecutive_on_time_payments= profile.consecutive_on_time_payments,
                has_late_payments=            profile.has_late_payments,
            )
            app = self.apply_rate(
                monthly_profile, days=30, scenario=scenario
            )
            snapshots.append({
                "month":            month,
                "opening_balance":  round(running_balance, 2),
                "annual_rate_pct":  format_rate_display(app.annual_rate),
                "interest_earned":  app.interest_earned,
                "closing_balance":  app.final_amount,
            })
            running_balance = app.final_amount if reinvest else profile.balance

        return snapshots

    def amortise_loan(
        self,
        profile:        CustomerProfile,
        term_months:    int,
        scenario:       Optional[MarketScenario] = None,
    ) -> List[LoanScheduleEntry]:
        """
        Generate a full amortisation schedule for a loan account.

        Uses the reducing-balance method (standard mortgage / personal loan
        amortisation).  The monthly payment is fixed; only the split between
        interest and principal changes over time.
        """
        if profile.account_type != AccountType.LOAN:
            raise ValueError("amortise_loan only supports AccountType.LOAN")

        rate_result  = self.calculate_rate(profile, scenario=scenario, log=False)
        annual_rate  = rate_result.annual_rate
        monthly_rate = (1.0 + annual_rate) ** (1.0 / 12) - 1.0
        pmt          = loan_monthly_payment(profile.balance, annual_rate, term_months)

        schedule: List[LoanScheduleEntry] = []
        balance = profile.balance

        for month in range(1, term_months + 1):
            interest_portion  = round(balance * monthly_rate, 2)
            principal_portion = round(pmt - interest_portion, 2)
            closing_balance   = max(0.0, round(balance - principal_portion, 2))

            schedule.append(LoanScheduleEntry(
                month=             month,
                opening_balance=   round(balance, 2),
                payment=           pmt,
                principal_portion= principal_portion,
                interest_portion=  interest_portion,
                closing_balance=   closing_balance,
            ))
            balance = closing_balance
            if balance <= 0:
                break   # Loan fully repaid (may be early due to rounding)

        return schedule

    def update_scenario(self, scenario: MarketScenario) -> None:
        """Mutate the engine's active market scenario."""
        self.config.scenario = scenario
        self._logger._logger.info(
            "Market scenario updated to: %s", scenario.value
        )

    def update_benchmark_rate(self, new_rate: float) -> None:
        """
        Reflect a central-bank rate change.
        Logs the transition for audit trail.
        """
        old = self.config.benchmark_rate
        self.config.benchmark_rate = new_rate
        self._logger._logger.info(
            "Benchmark rate updated: %.4f%% → %.4f%%",
            old * 100, new_rate * 100,
        )

    def get_audit_log(self) -> List[dict]:
        """Return all audit records as a list of dicts."""
        return self._logger.export_logs()

    def export_audit_log(self, path: str) -> None:
        """Write a pretty-printed JSON export of the audit log to *path*."""
        self._logger.export_logs(output_path=path)

    # ─────────────────────────────────────────────────────────────────────────
    # Private Pipeline Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _compute_risk_spread(
        self,
        account_type: AccountType,
        risk_tier:    RiskTier,
    ) -> float:
        """
        Return the annualised risk spread.

        For deposit accounts (savings, checking): high-risk customers earn
        slightly LESS (bank retains margin).
        For loan accounts: high-risk customers pay MORE (default premium).

        The spread direction is therefore flipped for deposits vs. loans.
        """
        spread = RISK_SPREADS.get(risk_tier, 0.0)
        if account_type == AccountType.LOAN:
            # Positive spread = higher loan rate for risky borrowers
            return spread
        else:
            # For deposits, the sign is inverted:
            #   LOW risk  → spread = –0.005 (deposits earn –0.5 pp from risk alone)
            #   But we want LOW-risk depositors to earn MORE, so flip.
            return -spread

    def _compute_behaviour_adjustment(self, profile: CustomerProfile) -> float:
        """
        Aggregate behavioural signals into a rate adjustment (decimal).

        Positive adjustments reward desired behaviour (saving, on-time
        repayment, active usage).  Negative adjustments penalise risk signals
        (late payments).
        """
        adj = 0.0

        # Active usage bonus (all account types)
        if profile.monthly_transactions >= ACTIVE_TRANSACTION_THRESHOLD:
            adj += ACTIVE_ACCOUNT_BONUS

        # Loyalty discount (loan only – sustained on-time repayment)
        if (
            profile.account_type == AccountType.LOAN
            and profile.consecutive_on_time_payments >= LOYAL_REPAYMENT_MONTHS
        ):
            adj -= LOYALTY_RATE_DISCOUNT  # Reduces loan rate

        # Late payment penalty (loan only)
        if profile.account_type == AccountType.LOAN and profile.has_late_payments:
            adj += LATE_PAYMENT_PENALTY   # Increases loan rate

        # Tenure bonus for deposits – reward long-standing customers
        if profile.account_type in (AccountType.SAVINGS, AccountType.CHECKING):
            if profile.months_since_opened >= 24:
                adj += 0.001   # +0.1 pp for 2+ year customers
            if profile.months_since_opened >= 60:
                adj += 0.002   # Additional +0.2 pp for 5+ year customers

        return adj

    def _apply_ml_blend(
        self,
        rule_rate: float,
        profile:   CustomerProfile,
        scenario:  MarketScenario,
    ) -> float:
        """
        Blend a ML-predicted rate with the rule-engine rate.

        Blend weight is 40 % ML / 60 % rules by default to maintain
        interpretability and guard against model drift.  The adjustment
        returned is the *delta* from the rule-based rate.
        """
        ML_WEIGHT = 0.40

        if profile.ml_predicted_rate is not None:
            predicted = profile.ml_predicted_rate
        elif self.ai_model is not None:
            predicted = self.ai_model.predict(profile, scenario)
        else:
            return 0.0

        blended = (1.0 - ML_WEIGHT) * rule_rate + ML_WEIGHT * predicted
        return blended - rule_rate   # Return adjustment, not absolute rate

    @staticmethod
    def _build_description(
        profile:  CustomerProfile,
        rate:     float,
        scenario: MarketScenario,
    ) -> str:
        return (
            f"Account {profile.account_id} ({profile.account_type.value}) "
            f"assigned rate {format_rate_display(rate)} "
            f"under {scenario.value} scenario "
            f"[risk={profile.risk_tier.value}, balance=£{profile.balance:,.2f}]"
        )
