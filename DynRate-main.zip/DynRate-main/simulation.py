"""
api/routes/simulation.py
─────────────────────────────────────────────────────────────────────────────
/simulate  —  scenario analysis and simulation endpoints

  POST /simulate/scenarios    → multi-scenario comparison (pivot table)
  POST /simulate/historical   → rate-hiking cycle replay
  POST /simulate/impact       → £ interest impact by scenario
  GET  /simulate/sensitivity  → rate sensitivity matrix
  GET  /simulate/stress-test  → run boundary validation
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from dynrate import (
    AccountType,
    CustomerProfile,
    HistoricalSimulator,
    MarketScenario,
    MultiScenarioSimulator,
    RiskTier,
    StressTester,
)
from dynrate.config import EngineConfig
from dynrate.engine import DynRateEngine

from api.dependencies import get_engine
from api.schemas import (
    HistoricalReplayRequest,
    RateRequest,
    ScenarioCompareRequest,
    ScenarioCompareRow,
)

router = APIRouter(prefix="/simulate", tags=["Simulation"])


def _profiles_from_requests(reqs: List[RateRequest]) -> List[CustomerProfile]:
    return [
        CustomerProfile(
            account_id=                   r.account_id,
            account_type=                 r.account_type,
            balance=                      r.balance,
            risk_tier=                    r.risk_tier,
            monthly_transactions=         r.monthly_transactions,
            months_since_opened=          r.months_since_opened,
            consecutive_on_time_payments= r.consecutive_on_time_payments,
            has_late_payments=            r.has_late_payments,
        )
        for r in reqs
    ]


@router.post(
    "/scenarios",
    response_model=List[ScenarioCompareRow],
    summary="Compare rates for a portfolio across all market scenarios",
)
def compare_scenarios(
    req:    ScenarioCompareRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> List[ScenarioCompareRow]:
    """
    Run every account in *accounts* through every (or specified) market
    scenario and return all resulting rates.

    Use the response to build scenario-comparison tables or charts in
    your frontend.
    """
    profiles = _profiles_from_requests(req.accounts)
    sim      = MultiScenarioSimulator(engine=engine)
    try:
        df = sim.run(profiles, scenarios=req.scenarios, log=False)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    return [
        ScenarioCompareRow(
            account_id=        row["account_id"],
            account_type=      row["account_type"],
            scenario=          row["scenario"],
            annual_rate_pct=   row["annual_rate_pct"],
            effective_apy_pct= row["effective_apy_pct"],
            risk_tier=         row["risk_tier"],
            balance=           row["balance"],
        )
        for _, row in df.iterrows()
    ]


class ImpactRow(BaseModel):
    account_id:         str
    account_type:       str
    scenario:           str
    balance:            float
    annual_rate:        float
    interest_gbp:       float
    delta_vs_normal_gbp: float


@router.post(
    "/impact",
    response_model=List[ImpactRow],
    summary="Annual interest impact (£) per scenario vs. NORMAL baseline",
)
def interest_impact(
    req:          ScenarioCompareRequest,
    horizon_days: int = Query(365, ge=1, le=3650),
    engine:       DynRateEngine = Depends(get_engine),
) -> List[ImpactRow]:
    """
    Show the financial impact of each market scenario in absolute GBP terms,
    relative to the NORMAL scenario baseline.

    Positive delta = more interest under that scenario.
    Negative delta = less interest under that scenario.
    """
    profiles = _profiles_from_requests(req.accounts)
    sim      = MultiScenarioSimulator(engine=engine)
    df       = sim.interest_impact_analysis(
        profiles, horizon_days=horizon_days, scenarios=req.scenarios
    )
    return [
        ImpactRow(
            account_id=          row["account_id"],
            account_type=        row["account_type"],
            scenario=            row["scenario"],
            balance=             row["balance"],
            annual_rate=         row["annual_rate"],
            interest_gbp=        round(row["interest_£"], 2),
            delta_vs_normal_gbp= round(row["delta_vs_normal_£"], 2),
        )
        for _, row in df.iterrows()
    ]


class HistoricalRatePoint(BaseModel):
    date:               str
    account_id:         str
    account_type:       str
    scenario:           str
    benchmark_rate:     float
    annual_rate_pct:    float
    effective_apy_pct:  float


@router.post(
    "/historical",
    response_model=List[HistoricalRatePoint],
    summary="Replay a rate-hiking cycle timeline against a portfolio",
)
def historical_replay(
    req: HistoricalReplayRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> List[HistoricalRatePoint]:
    """
    Replay a synthetic rate-hiking cycle (defaulting to a 2022-style
    BoE/Fed hiking schedule) against a set of customer accounts.

    Returns a time-series of rates for each account at each monthly
    interval — ready for charting.
    """
    profiles = _profiles_from_requests(req.accounts)
    sim      = HistoricalSimulator(config=engine.config)
    timeline = HistoricalSimulator.build_rate_hike_timeline(
        start_date=      req.start_date,
        months=          req.months,
        start_benchmark= req.start_benchmark,
    )
    df = sim.replay(profiles, timeline, log=False)

    return [
        HistoricalRatePoint(
            date=              row["date"],
            account_id=        row["account_id"],
            account_type=      row["account_type"],
            scenario=          row["scenario"],
            benchmark_rate=    row["benchmark_rate"],
            annual_rate_pct=   row["annual_rate_pct"],
            effective_apy_pct= row["effective_apy_pct"],
        )
        for _, row in df.iterrows()
    ]


class SensitivityCell(BaseModel):
    scenario:      str
    balance:       float
    annual_rate_pct: float


@router.get(
    "/sensitivity",
    response_model=List[SensitivityCell],
    summary="Rate sensitivity matrix across scenarios × balance bands",
)
def sensitivity_matrix(
    account_type: AccountType = Query(AccountType.SAVINGS),
    risk_tier:    RiskTier    = Query(RiskTier.MEDIUM),
    engine:       DynRateEngine = Depends(get_engine),
) -> List[SensitivityCell]:
    """
    Generate a sensitivity matrix showing how rates change across all
    scenario × balance-band combinations.
    """
    from dynrate.config import SCENARIO_MULTIPLIERS
    tester = StressTester(config=engine.config)
    matrix = tester.sensitivity_matrix(account_type, risk_tier)

    rows: List[SensitivityCell] = []
    for scenario in matrix.index:
        for col in matrix.columns:
            # Column headers are formatted like "£5,000"
            balance_str = col.replace("£", "").replace(",", "")
            try:
                balance = float(balance_str)
            except ValueError:
                continue
            rate_str = matrix.loc[scenario, col].rstrip("%")
            rows.append(SensitivityCell(
                scenario=       scenario,
                balance=        balance,
                annual_rate_pct=float(rate_str),
            ))
    return rows


class StressTestResult(BaseModel):
    tested:          int
    violations:      int
    violation_rate:  float
    passed:          bool


@router.get(
    "/stress-test",
    response_model=StressTestResult,
    summary="Run a regulatory boundary stress test",
)
def run_stress_test(
    n_samples: int = Query(500, ge=100, le=10_000),
    engine:    DynRateEngine = Depends(get_engine),
) -> StressTestResult:
    """
    Validate that the engine produces rates within regulatory bounds
    across *n_samples* randomly generated customer profiles.
    """
    tester = StressTester(config=engine.config)
    result = tester.run_boundary_check(n_samples=n_samples)
    return StressTestResult(
        tested=         result["tested"],
        violations=     result["violations"],
        violation_rate= result["violation_rate"],
        passed=         result["passed"],
    )
