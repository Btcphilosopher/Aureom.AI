"""
dynrate/config.py
─────────────────────────────────────────────────────────────────────────────
Central configuration for DynRate: Dynamic Interest Engine.

All tuneable parameters live here so that ops/risk teams can adjust without
touching application logic.  Import this module rather than hard-coding any
magic numbers elsewhere in the codebase.
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Tuple


# ─────────────────────────────────────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────────────────────────────────────

class AccountType(str, Enum):
    """Supported account types in the engine."""
    SAVINGS  = "savings"
    CHECKING = "checking"
    LOAN     = "loan"


class MarketScenario(str, Enum):
    """Macro-economic market conditions that modify base rates."""
    NORMAL        = "normal"
    RECESSION     = "recession"
    INFLATIONARY  = "inflationary"
    DEFLATIONARY  = "deflationary"
    HIGH_VOLATILITY = "high_volatility"


class RiskTier(str, Enum):
    """Customer risk classification used by the rate engine."""
    LOW    = "low"      # Prime / Tier-1 customer
    MEDIUM = "medium"   # Standard customer
    HIGH   = "high"     # Sub-prime / elevated risk


# ─────────────────────────────────────────────────────────────────────────────
# Base Rate Floors & Ceilings  (annualised, decimal)
# Regulatory floors prevent predatory rates; ceilings cap extreme volatility.
# ─────────────────────────────────────────────────────────────────────────────

RATE_BOUNDS: Dict[AccountType, Tuple[float, float]] = {
    AccountType.SAVINGS:  (0.001,  0.12),   # 0.1 % – 12 %
    AccountType.CHECKING: (0.0005, 0.05),   # 0.05 % – 5 %
    AccountType.LOAN:     (0.02,   0.35),   # 2 % – 35 %
}

# ─────────────────────────────────────────────────────────────────────────────
# Default base rates (annualised, decimal) per account type
# These represent "normal market, medium risk, average balance" starting point.
# ─────────────────────────────────────────────────────────────────────────────

BASE_RATES: Dict[AccountType, float] = {
    AccountType.SAVINGS:  0.045,   # 4.5 %
    AccountType.CHECKING: 0.010,   # 1.0 %
    AccountType.LOAN:     0.075,   # 7.5 %
}

# ─────────────────────────────────────────────────────────────────────────────
# Market Scenario Multipliers
# Applied as a multiplicative factor on top of the base rate.
# ─────────────────────────────────────────────────────────────────────────────

SCENARIO_MULTIPLIERS: Dict[MarketScenario, float] = {
    MarketScenario.NORMAL:          1.00,
    MarketScenario.RECESSION:       0.70,   # Central banks cut rates
    MarketScenario.INFLATIONARY:    1.55,   # Rates rise to curb inflation
    MarketScenario.DEFLATIONARY:    0.55,   # Near-zero rate environment
    MarketScenario.HIGH_VOLATILITY: 1.20,   # Risk premium baked in
}

# ─────────────────────────────────────────────────────────────────────────────
# Risk Tier Spread  (annualised, decimal)
# Added to (savings/checking) or multiplied (loans) relative to base.
# ─────────────────────────────────────────────────────────────────────────────

RISK_SPREADS: Dict[RiskTier, float] = {
    RiskTier.LOW:    -0.005,   # Reward: –0.5 pp  (deposits get more, loans less)
    RiskTier.MEDIUM:  0.000,   #  Neutral
    RiskTier.HIGH:    0.020,   # Penalty: +2 pp   (deposits get less, loans more)
}

# ─────────────────────────────────────────────────────────────────────────────
# Balance Tier Adjustments  (annualised, decimal)
# Higher savings balances attract marginally better deposit rates.
# Larger loan principals carry marginally lower rates (volume discount).
# ─────────────────────────────────────────────────────────────────────────────

# (lower_bound_inclusive, upper_bound_exclusive) → rate_adjustment
BALANCE_TIER_ADJUSTMENTS: Dict[AccountType, Dict[Tuple[float, float], float]] = {
    AccountType.SAVINGS: {
        (0,         5_000):    -0.005,   # Small saver:  –0.5 pp
        (5_000,     25_000):    0.000,   # Standard tier
        (25_000,    100_000):   0.005,   # Mid-tier:     +0.5 pp
        (100_000,   float("inf")): 0.010,  # Wealth:     +1 pp
    },
    AccountType.CHECKING: {
        (0,         1_000):    -0.003,
        (1_000,     10_000):    0.000,
        (10_000,    float("inf")): 0.003,
    },
    AccountType.LOAN: {
        (0,         10_000):    0.010,   # Small personal loan: +1 pp
        (10_000,    50_000):    0.000,   # Standard band
        (50_000,    250_000):  -0.005,   # Mortgage-ish: –0.5 pp
        (250_000,   float("inf")): -0.010,  # Jumbo:     –1 pp
    },
}

# ─────────────────────────────────────────────────────────────────────────────
# Transaction-pattern bonuses / penalties
# ─────────────────────────────────────────────────────────────────────────────

# Minimum monthly transactions to qualify for the "active" bonus
ACTIVE_TRANSACTION_THRESHOLD: int = 10
ACTIVE_ACCOUNT_BONUS: float        = 0.002   # +0.2 pp

# Number of months of on-time loan repayments to earn a loyalty discount
LOYAL_REPAYMENT_MONTHS: int         = 12
LOYALTY_RATE_DISCOUNT: float        = 0.005   # –0.5 pp

# Late-payment penalty (loans only, annualised spread added)
LATE_PAYMENT_PENALTY: float         = 0.030   # +3 pp

# ─────────────────────────────────────────────────────────────────────────────
# Benchmark / Market Rate Feed
# In production these would be fetched from a market data provider.
# ─────────────────────────────────────────────────────────────────────────────

# Simulated central bank policy rate (annualised)
BENCHMARK_RATE: float = 0.0525   # 5.25 % (Fed Funds / BoE equivalent)

# Spread over benchmark that the bank targets for net interest margin
NIM_SPREAD: float = 0.015   # 1.5 pp

# ─────────────────────────────────────────────────────────────────────────────
# Compounding & Day-count
# ─────────────────────────────────────────────────────────────────────────────

DAYS_IN_YEAR: int = 365   # Actual/365 day-count convention

# Default compounding frequency (number of times per year)
COMPOUNDING_FREQUENCIES: Dict[str, int] = {
    "daily":     365,
    "monthly":    12,
    "quarterly":   4,
    "annually":    1,
}
DEFAULT_COMPOUNDING: str = "monthly"

# ─────────────────────────────────────────────────────────────────────────────
# ML / AI Model settings
# ─────────────────────────────────────────────────────────────────────────────

ML_FEATURE_COLUMNS = [
    "balance",
    "monthly_transactions",
    "months_since_opened",
    "consecutive_on_time_payments",
    "benchmark_rate",
    "scenario_multiplier",
    "risk_score",           # numeric encoding of RiskTier
]

ML_TARGET_COLUMN     = "optimal_rate"
ML_TEST_SIZE         = 0.20   # 20 % held out for validation
ML_RANDOM_STATE      = 42
ML_N_ESTIMATORS      = 200    # Random-forest trees
ML_MAX_DEPTH         = 6

# ─────────────────────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────────────────────

LOG_DIR             = "logs"
LOG_FILE            = "dynrate_audit.jsonl"   # newline-delimited JSON
LOG_LEVEL           = "INFO"


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic-compatible typed config container (optional strict mode)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EngineConfig:
    """
    Runtime configuration object passed into DynRateEngine.
    Override any default by passing keyword arguments.
    """
    benchmark_rate:      float        = BENCHMARK_RATE
    nim_spread:          float        = NIM_SPREAD
    default_compounding: str          = DEFAULT_COMPOUNDING
    log_dir:             str          = LOG_DIR
    log_file:            str          = LOG_FILE
    scenario:            MarketScenario = MarketScenario.NORMAL
    days_in_year:        int          = DAYS_IN_YEAR
    base_rates:          Dict         = field(default_factory=lambda: dict(BASE_RATES))
    rate_bounds:         Dict         = field(default_factory=lambda: dict(RATE_BOUNDS))
