"""
api/routes/loans.py
─────────────────────────────────────────────────────────────────────────────
/loans  —  loan-specific endpoints

  POST /loans/amortise        → full amortisation schedule
  POST /loans/compare-risk    → side-by-side risk-tier rate comparison
  GET  /loans/rate-bounds     → regulatory min/max for loan accounts
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

from typing import Dict, List

from fastapi import APIRouter, Depends, HTTPException

from dynrate import CustomerProfile, AccountType, RiskTier
from dynrate.config import RATE_BOUNDS
from dynrate.engine import DynRateEngine
from dynrate.utils import loan_monthly_payment

from api.dependencies import get_engine
from api.schemas import (
    LoanAmortiseRequest,
    LoanAmortiseResponse,
    LoanScheduleRow,
    RateRequest,
    RateResponse,
)

router = APIRouter(prefix="/loans", tags=["Loans"])


@router.post(
    "/amortise",
    response_model=LoanAmortiseResponse,
    summary="Generate a full amortisation schedule for a loan",
)
def amortise_loan(
    req:    LoanAmortiseRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> LoanAmortiseResponse:
    """
    Produce a month-by-month loan amortisation schedule.

    Uses the standard reducing-balance (annuity) method.  The monthly
    payment is fixed throughout the term; only the split between principal
    and interest changes (interest-front-loading at the start).
    """
    profile = CustomerProfile(
        account_id=                   req.account_id,
        account_type=                 AccountType.LOAN,
        balance=                      req.balance,
        risk_tier=                    req.risk_tier,
        consecutive_on_time_payments= req.consecutive_on_time_payments,
        has_late_payments=            req.has_late_payments,
    )
    try:
        result   = engine.calculate_rate(profile, scenario=req.scenario, log=False)
        schedule = engine.amortise_loan(profile, term_months=req.term_months,
                                        scenario=req.scenario)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    monthly_payment = schedule[0].payment if schedule else 0.0
    total_interest  = round(sum(r.interest_portion  for r in schedule), 2)
    total_repaid    = round(sum(r.payment            for r in schedule), 2)

    return LoanAmortiseResponse(
        account_id=      req.account_id,
        principal=       req.balance,
        term_months=     req.term_months,
        annual_rate_pct= f"{result.annual_rate * 100:.4f}%",
        monthly_payment= monthly_payment,
        total_interest=  total_interest,
        total_repaid=    total_repaid,
        schedule=[
            LoanScheduleRow(
                month=             r.month,
                opening_balance=   r.opening_balance,
                payment=           r.payment,
                principal_portion= r.principal_portion,
                interest_portion=  r.interest_portion,
                closing_balance=   r.closing_balance,
            )
            for r in schedule
        ],
    )


@router.post(
    "/compare-risk",
    response_model=List[RateResponse],
    summary="Compare loan rates across all risk tiers for identical profiles",
)
def compare_risk_tiers(
    req:    LoanAmortiseRequest,
    engine: DynRateEngine = Depends(get_engine),
) -> List[RateResponse]:
    """
    Return the rates a loan of this size / term would attract at each
    risk tier.  Useful for presenting personalised rate quotes that show
    what the customer could achieve with a better credit profile.
    """
    results: List[RateResponse] = []
    for tier in RiskTier:
        profile = CustomerProfile(
            account_id=   f"{req.account_id}-{tier.value}",
            account_type= AccountType.LOAN,
            balance=      req.balance,
            risk_tier=    tier,
            consecutive_on_time_payments= req.consecutive_on_time_payments,
            has_late_payments=            req.has_late_payments,
        )
        r = engine.calculate_rate(profile, scenario=req.scenario, log=False)
        results.append(RateResponse(**r.to_dict()))
    return results


@router.get(
    "/rate-bounds",
    response_model=Dict[str, Dict[str, float]],
    summary="Regulatory rate bounds for loan accounts",
)
def get_rate_bounds() -> Dict[str, Dict[str, float]]:
    """Return the floor and ceiling APR for all account types."""
    return {
        atype.value: {"floor_pct": lo * 100, "ceiling_pct": hi * 100}
        for atype, (lo, hi) in RATE_BOUNDS.items()
    }
