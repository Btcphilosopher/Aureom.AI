"""
dynrate/ai_model.py
─────────────────────────────────────────────────────────────────────────────
DynRate AI / ML Rate Prediction Module

Provides two complementary models:

1. GradientBoostingRateModel  – sklearn GradientBoostingRegressor trained on
   synthetic (or real) historical rate data.  Acts as a supervised learner
   that maps customer + market features → optimal rate.

2. RLRateOptimiser  – a tabular Q-learning agent that learns rate-setting
   policy through simulated reward signals (bank P&L, churn proxy, etc.).
   Uses discretised state/action spaces for interpretability.

Both models conform to the same simple interface:
    model.fit(X, y)
    model.predict(profile, scenario) → float

The engine performs a 40/60 ML/rules blend when a model is attached,
ensuring human-interpretable rates even if the model is wrong.
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import logging
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
    from sklearn.model_selection import cross_val_score, train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_absolute_error, r2_score
    from sklearn.pipeline import Pipeline

from dynrate.config import (
    ML_FEATURE_COLUMNS,
    ML_MAX_DEPTH,
    ML_N_ESTIMATORS,
    ML_RANDOM_STATE,
    ML_TARGET_COLUMN,
    ML_TEST_SIZE,
    SCENARIO_MULTIPLIERS,
    AccountType,
    MarketScenario,
    RiskTier,
)

logger = logging.getLogger("dynrate.ai_model")


# ─────────────────────────────────────────────────────────────────────────────
# Feature Engineering Helpers
# ─────────────────────────────────────────────────────────────────────────────

_RISK_TIER_ENCODING: Dict[RiskTier, float] = {
    RiskTier.LOW:    0.0,
    RiskTier.MEDIUM: 1.0,
    RiskTier.HIGH:   2.0,
}

_ACCOUNT_TYPE_ENCODING: Dict[AccountType, float] = {
    AccountType.SAVINGS:  0.0,
    AccountType.CHECKING: 1.0,
    AccountType.LOAN:     2.0,
}


def profile_to_feature_vector(profile: Any, scenario: MarketScenario) -> np.ndarray:
    """
    Convert a CustomerProfile and MarketScenario into a numeric feature vector.

    Feature ordering must remain stable between training and inference –
    adding features requires re-training the model.

    Features
    --------
    balance                        : raw account balance (£)
    monthly_transactions           : count in the last calendar month
    months_since_opened            : account tenure
    consecutive_on_time_payments   : loan-repayment streak (0 for deposits)
    benchmark_rate                 : central bank policy rate (decimal)
    scenario_multiplier            : numeric scenario factor
    risk_score                     : 0 / 1 / 2 (LOW / MED / HIGH)
    account_type_code              : 0 / 1 / 2 (SAVINGS / CHECKING / LOAN)
    log_balance                    : natural log of balance (handles skew)
    txn_per_month_per_k            : transactions per £1k balance (engagement density)
    """
    scenario_mult = SCENARIO_MULTIPLIERS.get(scenario, 1.0)

    # Compute derived features safely
    log_balance = np.log1p(profile.balance)
    bal_k = max(profile.balance / 1_000.0, 0.001)
    txn_density = profile.monthly_transactions / bal_k

    vec = np.array([
        profile.balance,
        float(profile.monthly_transactions),
        float(profile.months_since_opened),
        float(profile.consecutive_on_time_payments),
        0.0525,                                         # benchmark_rate (static here)
        scenario_mult,
        _RISK_TIER_ENCODING.get(profile.risk_tier, 1.0),
        _ACCOUNT_TYPE_ENCODING.get(profile.account_type, 0.0),
        log_balance,
        txn_density,
    ], dtype=np.float64)

    return vec.reshape(1, -1)


# ─────────────────────────────────────────────────────────────────────────────
# Supervised Learning Model
# ─────────────────────────────────────────────────────────────────────────────

class GradientBoostingRateModel:
    """
    Gradient-boosted regression model for rate prediction.

    Training data can be:
      a) Synthetic – generated via `generate_synthetic_training_data()`
      b) Historical – a DataFrame loaded from your data warehouse

    The model is wrapped in a sklearn Pipeline with a StandardScaler so
    that the scaler and model are always serialised together.

    Usage
    -----
        model = GradientBoostingRateModel()
        df    = model.generate_synthetic_training_data(n_samples=5000)
        model.fit_from_dataframe(df)
        rate  = model.predict(profile, scenario)
    """

    FEATURE_COLS = [
        "balance", "monthly_transactions", "months_since_opened",
        "consecutive_on_time_payments", "benchmark_rate",
        "scenario_multiplier", "risk_score", "account_type_code",
        "log_balance", "txn_density",
    ]

    def __init__(self) -> None:
        self._pipeline: Optional[Pipeline] = None
        self._is_fitted: bool = False
        self._train_metrics: Dict[str, float] = {}

    # ── Training ──────────────────────────────────────────────────────────────

    def fit_from_dataframe(self, df: pd.DataFrame) -> Dict[str, float]:
        """
        Train on a DataFrame that must contain all FEATURE_COLS plus
        'optimal_rate' as the target.

        Returns a dict of evaluation metrics (MAE, R²) on the held-out set.
        """
        missing = set(self.FEATURE_COLS + [ML_TARGET_COLUMN]) - set(df.columns)
        if missing:
            raise ValueError(f"DataFrame missing required columns: {missing}")

        X = df[self.FEATURE_COLS].values.astype(np.float64)
        y = df[ML_TARGET_COLUMN].values.astype(np.float64)

        X_train, X_test, y_train, y_test = train_test_split(
            X, y,
            test_size=  ML_TEST_SIZE,
            random_state=ML_RANDOM_STATE,
        )

        self._pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("model",  GradientBoostingRegressor(
                n_estimators= ML_N_ESTIMATORS,
                max_depth=    ML_MAX_DEPTH,
                learning_rate=0.05,
                subsample=    0.80,
                random_state= ML_RANDOM_STATE,
            )),
        ])

        self._pipeline.fit(X_train, y_train)
        self._is_fitted = True

        y_pred = self._pipeline.predict(X_test)
        self._train_metrics = {
            "mae":  float(mean_absolute_error(y_test, y_pred)),
            "r2":   float(r2_score(y_test, y_pred)),
            "n_train": len(X_train),
            "n_test":  len(X_test),
        }
        logger.info(
            "Model trained — MAE=%.6f  R²=%.4f  (n_train=%d)",
            self._train_metrics["mae"],
            self._train_metrics["r2"],
            self._train_metrics["n_train"],
        )
        return self._train_metrics

    def predict(self, profile: Any, scenario: MarketScenario) -> float:
        """
        Predict the optimal interest rate for a given customer profile.

        Returns the raw model output (decimal APR).  The engine will blend
        this with the rules-based rate before clamping.
        """
        if not self._is_fitted or self._pipeline is None:
            raise RuntimeError(
                "Model is not fitted.  Call fit_from_dataframe() first."
            )
        X = profile_to_feature_vector(profile, scenario)
        return float(self._pipeline.predict(X)[0])

    @property
    def is_fitted(self) -> bool:
        return self._is_fitted

    @property
    def metrics(self) -> Dict[str, float]:
        return dict(self._train_metrics)

    def feature_importances(self) -> pd.Series:
        """Return feature importances from the underlying GBM."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted")
        importances = self._pipeline.named_steps["model"].feature_importances_
        return pd.Series(importances, index=self.FEATURE_COLS).sort_values(
            ascending=False
        )

    # ── Synthetic Data Generation ─────────────────────────────────────────────

    @staticmethod
    def generate_synthetic_training_data(
        n_samples:   int = 10_000,
        random_seed: int = ML_RANDOM_STATE,
    ) -> pd.DataFrame:
        """
        Generate a realistic synthetic training dataset.

        The 'optimal_rate' target is constructed from a deterministic formula
        that mirrors the engine's rule pipeline with added Gaussian noise to
        simulate historical variability and teach the model to generalise.

        This data can be augmented with real historical rate decisions once
        the engine is in production.
        """
        rng = np.random.default_rng(random_seed)

        n = n_samples

        # ── Simulate customer features ────────────────────────────────────
        account_type_codes = rng.choice([0.0, 1.0, 2.0], size=n, p=[0.5, 0.2, 0.3])
        risk_scores        = rng.choice([0.0, 1.0, 2.0], size=n, p=[0.25, 0.55, 0.20])
        scenario_mults     = rng.choice(
            list(SCENARIO_MULTIPLIERS.values()), size=n
        )

        # Log-normal balance distribution mimics real-world wealth skew
        balances = np.expm1(rng.normal(loc=9.5, scale=1.8, size=n)).clip(100, 2_000_000)
        monthly_txns   = rng.integers(0, 60, size=n)
        months_opened  = rng.integers(0, 120, size=n)
        ontime_streak  = rng.integers(0, 36, size=n)
        benchmark_rate = np.full(n, 0.0525)

        log_balance  = np.log1p(balances)
        txn_density  = monthly_txns / np.maximum(balances / 1_000.0, 0.001)

        # ── Construct target rate from deterministic formula + noise ──────
        # Base rates per account type
        base_map = {0.0: 0.045, 1.0: 0.010, 2.0: 0.075}
        base_rates = np.vectorize(base_map.get)(account_type_codes)

        # Apply scenario, risk, balance, behaviour adjustments
        rates = base_rates * scenario_mults
        rates += (risk_scores - 1.0) * 0.010   # –0.01 LOW, 0 MED, +0.01 HIGH
        rates -= (log_balance - 9.5) * 0.002   # Larger balance → slightly lower rate
        rates += (monthly_txns > 10).astype(float) * 0.002   # Active bonus
        rates += np.where(account_type_codes == 2.0,
                          (ontime_streak >= 12).astype(float) * -0.005, 0.0)

        # Add realistic noise: 15 bps std to simulate human decision variability
        rates += rng.normal(0.0, 0.0015, size=n)

        # Clamp to plausible range
        rates = np.clip(rates, 0.001, 0.35)

        df = pd.DataFrame({
            "balance":                       np.round(balances, 2),
            "monthly_transactions":          monthly_txns,
            "months_since_opened":           months_opened,
            "consecutive_on_time_payments":  ontime_streak,
            "benchmark_rate":                benchmark_rate,
            "scenario_multiplier":           np.round(scenario_mults, 3),
            "risk_score":                    risk_scores,
            "account_type_code":             account_type_codes,
            "log_balance":                   np.round(log_balance, 4),
            "txn_density":                   np.round(txn_density, 4),
            ML_TARGET_COLUMN:                np.round(rates, 6),
        })

        return df


# ─────────────────────────────────────────────────────────────────────────────
# Reinforcement Learning Rate Optimiser  (Tabular Q-Learning)
# ─────────────────────────────────────────────────────────────────────────────

class RLRateOptimiser:
    """
    Tabular Q-Learning agent for rate policy optimisation.

    State space  : (account_type, risk_tier, balance_bucket, scenario)
    Action space : discrete rate adjustments relative to the rule-based rate
                   e.g. [–50 bps, –25 bps, 0, +25 bps, +50 bps]

    Reward function:
        Deposits : reward  = interest_earned_by_bank (net interest margin proxy)
                   penalty = customer_churn_proxy  (rate too low → churn risk)
        Loans    : reward  = interest_earned_by_bank
                   penalty = default_risk_proxy   (rate too high → default risk)

    After sufficient episodes the Q-table converges to a policy that
    maximises the expected cumulative reward.

    Note: For production use, consider upgrading to a Deep Q-Network (DQN)
    to handle continuous state spaces without discretisation.
    """

    # Discrete action set: bps adjustments to the base rate
    ACTIONS: List[float] = [-0.010, -0.005, 0.000, 0.005, 0.010]

    # Balance buckets for state discretisation
    BALANCE_BUCKETS: List[float] = [0, 5_000, 25_000, 100_000, float("inf")]

    def __init__(
        self,
        alpha:       float = 0.10,   # learning rate
        gamma:       float = 0.95,   # discount factor
        epsilon:     float = 0.20,   # exploration rate (ε-greedy)
        epsilon_min: float = 0.01,
        epsilon_decay: float = 0.995,
    ) -> None:
        self.alpha         = alpha
        self.gamma         = gamma
        self.epsilon       = epsilon
        self.epsilon_min   = epsilon_min
        self.epsilon_decay = epsilon_decay

        # Q-table: (state_key → action_index → Q-value)
        self._q_table: Dict[Tuple, np.ndarray] = {}
        self._episode_rewards: List[float] = []

    # ── Q-table helpers ───────────────────────────────────────────────────────

    def _state_key(
        self,
        account_type: AccountType,
        risk_tier:    RiskTier,
        balance:      float,
        scenario:     MarketScenario,
    ) -> Tuple:
        """Discretise continuous features into a hashable state tuple."""
        bucket = 0
        for i, threshold in enumerate(self.BALANCE_BUCKETS[1:]):
            if balance < threshold:
                bucket = i
                break
        return (account_type.value, risk_tier.value, bucket, scenario.value)

    def _get_q_values(self, state: Tuple) -> np.ndarray:
        if state not in self._q_table:
            self._q_table[state] = np.zeros(len(self.ACTIONS))
        return self._q_table[state]

    def _choose_action(self, state: Tuple) -> int:
        """ε-greedy action selection."""
        if np.random.random() < self.epsilon:
            return np.random.randint(len(self.ACTIONS))
        return int(np.argmax(self._get_q_values(state)))

    def _reward(
        self,
        rate:         float,
        account_type: AccountType,
        risk_tier:    RiskTier,
        balance:      float,
    ) -> float:
        """
        Compute the one-step reward for setting a given rate.

        Reward structure (annualised, per £1 of balance):
          Deposits : NIM = benchmark – deposit_rate  (want deposit rate low but
                     not so low customers churn; linear penalty below 2 %)
          Loans    : NIM = loan_rate – benchmark  (want rate high but
                     penalise default risk for high-risk customers above 15 %)
        """
        benchmark = 0.0525

        if account_type == AccountType.LOAN:
            nim = rate - benchmark
            # Default risk penalty: exponential penalty if rate > 15 % for
            # medium/high risk (proxy for increased probability of default)
            default_penalty = 0.0
            if risk_tier in (RiskTier.MEDIUM, RiskTier.HIGH) and rate > 0.15:
                default_penalty = 5.0 * (rate - 0.15) ** 2
            return nim * balance / 1_000.0 - default_penalty
        else:
            nim = benchmark - rate
            # Churn penalty: if we pay too little on deposits, customers leave
            churn_penalty = 0.0
            if rate < 0.02:
                churn_penalty = 3.0 * (0.02 - rate) ** 2
            return nim * balance / 1_000.0 - churn_penalty

    # ── Training ──────────────────────────────────────────────────────────────

    def train(
        self,
        n_episodes:   int = 5_000,
        base_rates:   Optional[Dict[AccountType, float]] = None,
        random_seed:  int = ML_RANDOM_STATE,
    ) -> Dict[str, Any]:
        """
        Run Q-learning training over *n_episodes* simulated interactions.

        Each episode:
          1. Sample a random customer profile
          2. ε-greedy action selection
          3. Apply action (adjust base rate)
          4. Compute reward
          5. Q-table update (Bellman equation)
          6. Decay ε

        Returns training summary statistics.
        """
        from dynrate.config import BASE_RATES as _BASE_RATES

        np.random.seed(random_seed)
        base_rates = base_rates or dict(_BASE_RATES)
        rng = np.random.default_rng(random_seed)

        account_types = list(AccountType)
        risk_tiers    = list(RiskTier)
        scenarios     = list(MarketScenario)

        self._episode_rewards = []

        for episode in range(n_episodes):
            # ── Sample random customer ─────────────────────────────────────
            # Use integer indexing to avoid numpy coercing enums to strings
            account_type = account_types[int(rng.integers(len(account_types)))]
            risk_tier    = risk_tiers[int(rng.integers(len(risk_tiers)))]
            scenario     = scenarios[int(rng.integers(len(scenarios)))]
            balance      = float(np.expm1(rng.normal(9.5, 1.8)).clip(100, 2_000_000))

            state  = self._state_key(account_type, risk_tier, balance, scenario)
            action = self._choose_action(state)

            # ── Apply action to base rate ──────────────────────────────────
            base = base_rates.get(account_type, 0.05)
            mult = SCENARIO_MULTIPLIERS.get(scenario, 1.0)
            proposed_rate = base * mult + self.ACTIONS[action]
            proposed_rate = max(0.001, min(proposed_rate, 0.35))

            # ── Compute reward ─────────────────────────────────────────────
            reward = self._reward(proposed_rate, account_type, risk_tier, balance)

            # ── Q-table update (Bellman equation) ─────────────────────────
            # Q(s, a) ← Q(s, a) + α * [r + γ * max_a' Q(s', a') – Q(s, a)]
            # (single-step episode, so next state = current state approximation)
            q_values     = self._get_q_values(state)
            next_max     = float(np.max(q_values))
            q_values[action] += self.alpha * (
                reward + self.gamma * next_max - q_values[action]
            )

            # ── ε decay ────────────────────────────────────────────────────
            self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
            self._episode_rewards.append(reward)

        avg_reward = float(np.mean(self._episode_rewards[-100:]))
        logger.info(
            "RL training complete — %d episodes, final ε=%.4f, "
            "last-100 avg reward=%.4f",
            n_episodes, self.epsilon, avg_reward,
        )
        return {
            "episodes":           n_episodes,
            "final_epsilon":      round(self.epsilon, 4),
            "avg_reward_last100": round(avg_reward, 4),
            "q_table_states":     len(self._q_table),
        }

    # ── Inference ─────────────────────────────────────────────────────────────

    def predict(self, profile: Any, scenario: MarketScenario) -> float:
        """
        Return the optimal rate adjustment from the learned Q-policy.

        Returns a concrete rate (not just an adjustment delta).
        Falls back to the base rate if the state has not been visited.
        """
        from dynrate.config import BASE_RATES as _BASE_RATES

        state    = self._state_key(
            profile.account_type, profile.risk_tier,
            profile.balance, scenario,
        )
        q_values = self._get_q_values(state)
        action   = int(np.argmax(q_values))

        base  = _BASE_RATES.get(profile.account_type, 0.05)
        mult  = SCENARIO_MULTIPLIERS.get(scenario, 1.0)
        rate  = base * mult + self.ACTIONS[action]
        return float(max(0.001, min(rate, 0.35)))

    def policy_summary(self) -> pd.DataFrame:
        """
        Render the learned greedy policy as a human-readable DataFrame.
        Useful for model audits and regulatory review.
        """
        rows = []
        for state, q_values in self._q_table.items():
            best_action_idx = int(np.argmax(q_values))
            best_action_bps = self.ACTIONS[best_action_idx] * 10_000
            rows.append({
                "account_type":  state[0],
                "risk_tier":     state[1],
                "balance_bucket": state[2],
                "scenario":      state[3],
                "optimal_action_bps": best_action_bps,
                "max_q_value":   round(float(np.max(q_values)), 4),
            })
        if not rows:
            return pd.DataFrame()
        return pd.DataFrame(rows).sort_values(
            ["account_type", "risk_tier", "balance_bucket"]
        ).reset_index(drop=True)
