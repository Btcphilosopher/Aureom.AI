"""
tests/test_dynrate.py
─────────────────────────────────────────────────────────────────────────────
DynRate unit + integration test suite.

Run with:
    cd dynrate
    python -m pytest tests/ -v

Test coverage:
  • Configuration constants and bounds
  • Utility functions (numerical accuracy, edge cases)
  • Engine pipeline (all 8 steps)
  • Rate clamping / regulatory bounds
  • AI model (training, inference, synthetic data generation)
  • Simulator (multi-scenario, stress test, historical replay)
  • Audit logging
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import math
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

# Make the package importable from the project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from dynrate import (
    AccountType,
    AuditLogger,
    CustomerProfile,
    DynRateEngine,
    EngineConfig,
    GradientBoostingRateModel,
    HistoricalSimulator,
    MarketScenario,
    MultiScenarioSimulator,
    RLRateOptimiser,
    RateResult,
    RiskTier,
    StressTester,
    apr_to_apy,
    apy_to_apr,
    compound_interest,
    generate_scenario_report,
    loan_monthly_payment,
    simple_interest,
)
from dynrate.config import RATE_BOUNDS
from dynrate.utils import (
    clamp,
    effective_monthly_rate,
    get_balance_tier_adjustment,
    validate_rate_inputs,
)


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def engine() -> DynRateEngine:
    return DynRateEngine()


@pytest.fixture
def savings_profile() -> CustomerProfile:
    return CustomerProfile(
        account_id=   "TEST-SAVINGS-001",
        account_type= AccountType.SAVINGS,
        balance=      20_000.0,
        risk_tier=    RiskTier.MEDIUM,
        monthly_transactions=15,
        months_since_opened= 24,
    )


@pytest.fixture
def loan_profile() -> CustomerProfile:
    return CustomerProfile(
        account_id=   "TEST-LOAN-001",
        account_type= AccountType.LOAN,
        balance=      30_000.0,
        risk_tier=    RiskTier.MEDIUM,
        consecutive_on_time_payments=12,
        has_late_payments=False,
    )


@pytest.fixture
def high_risk_loan_profile() -> CustomerProfile:
    return CustomerProfile(
        account_id=   "TEST-LOAN-HIGH-001",
        account_type= AccountType.LOAN,
        balance=      8_000.0,
        risk_tier=    RiskTier.HIGH,
        has_late_payments=True,
        consecutive_on_time_payments=0,
    )


# ─────────────────────────────────────────────────────────────────────────────
# 1. Utility Functions
# ─────────────────────────────────────────────────────────────────────────────

class TestUtils:

    def test_clamp_within_bounds(self):
        assert clamp(5.0, 0.0, 10.0) == 5.0

    def test_clamp_below_floor(self):
        assert clamp(-1.0, 0.0, 10.0) == 0.0

    def test_clamp_above_ceiling(self):
        assert clamp(15.0, 0.0, 10.0) == 10.0

    def test_apr_to_apy_roundtrip(self):
        """APR → APY → APR should return the original value."""
        for apr in [0.01, 0.05, 0.10, 0.25]:
            apy = apr_to_apy(apr, n=12)
            back = apy_to_apr(apy, n=12)
            assert abs(back - apr) < 1e-9, f"Roundtrip failed for APR={apr}"

    def test_apy_greater_than_apr(self):
        """APY always exceeds APR for positive rates (compounding effect)."""
        apr = 0.06
        apy = apr_to_apy(apr, n=12)
        assert apy > apr

    def test_compound_interest_zero_rate(self):
        """Zero interest rate should return original principal."""
        final, earned = compound_interest(10_000.0, 0.0, 365)
        assert final  == 10_000.0
        assert earned == 0.0

    def test_compound_interest_positive_growth(self):
        """Positive rate must increase the balance."""
        final, earned = compound_interest(10_000.0, 0.05, 365)
        assert final > 10_000.0
        assert earned > 0

    def test_compound_interest_known_value(self):
        """
        £10,000 at 5% monthly compounding for 1 year should give ~£5,116
        annual interest (APY ≈ 5.116%).
        """
        final, earned = compound_interest(10_000.0, 0.05, 365, frequency="monthly")
        assert abs(earned - 511.62) < 1.0, f"Unexpected interest: {earned}"

    def test_simple_interest_calculation(self):
        _, interest = simple_interest(1_000.0, 0.10, 365)
        assert abs(interest - 100.0) < 0.01

    def test_loan_monthly_payment_positive(self):
        pmt = loan_monthly_payment(100_000.0, 0.06, 360)
        assert pmt > 0
        # Sanity: 30-year mortgage at 6% should be ~£599 per month
        assert 580 < pmt < 620, f"Unexpected PMT: {pmt}"

    def test_loan_monthly_payment_zero_rate(self):
        """Zero-rate loan: payment = principal / term."""
        pmt = loan_monthly_payment(12_000.0, 0.0, 12)
        assert abs(pmt - 1_000.0) < 0.01

    def test_balance_tier_adjustment_savings(self):
        """Small savings balance should attract a negative adjustment."""
        adj = get_balance_tier_adjustment(AccountType.SAVINGS, 2_000.0)
        assert adj < 0

    def test_balance_tier_adjustment_high_balance(self):
        """Large savings balance should attract a positive adjustment."""
        adj = get_balance_tier_adjustment(AccountType.SAVINGS, 200_000.0)
        assert adj > 0

    def test_validate_rate_inputs_negative_balance(self):
        with pytest.raises(ValueError, match="negative"):
            validate_rate_inputs(-100.0, AccountType.SAVINGS)

    def test_validate_rate_inputs_inf_balance(self):
        with pytest.raises(ValueError, match="finite"):
            validate_rate_inputs(float("inf"), AccountType.SAVINGS)

    def test_validate_rate_inputs_wrong_type(self):
        with pytest.raises(ValueError):
            validate_rate_inputs(1000.0, "savings")   # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
# 2. Engine — Core Rate Calculation
# ─────────────────────────────────────────────────────────────────────────────

class TestEngine:

    def test_calculate_rate_returns_rate_result(self, engine, savings_profile):
        result = engine.calculate_rate(savings_profile, log=False)
        assert isinstance(result, RateResult)

    def test_rate_within_bounds_savings(self, engine, savings_profile):
        result = engine.calculate_rate(savings_profile, log=False)
        lo, hi = RATE_BOUNDS[AccountType.SAVINGS]
        assert lo <= result.annual_rate <= hi, (
            f"Rate {result.annual_rate} out of bounds [{lo}, {hi}]"
        )

    def test_rate_within_bounds_loan(self, engine, loan_profile):
        result = engine.calculate_rate(loan_profile, log=False)
        lo, hi = RATE_BOUNDS[AccountType.LOAN]
        assert lo <= result.annual_rate <= hi

    def test_high_risk_loan_higher_than_low_risk(self, engine, loan_profile):
        """High-risk borrower should face a higher rate than medium-risk."""
        low_risk_profile = CustomerProfile(
            account_id=   "TEST-LOW",
            account_type= AccountType.LOAN,
            balance=      30_000.0,
            risk_tier=    RiskTier.LOW,
        )
        high_risk_profile = CustomerProfile(
            account_id=   "TEST-HIGH",
            account_type= AccountType.LOAN,
            balance=      30_000.0,
            risk_tier=    RiskTier.HIGH,
        )
        low_result  = engine.calculate_rate(low_risk_profile,  log=False)
        high_result = engine.calculate_rate(high_risk_profile, log=False)
        assert high_result.annual_rate > low_result.annual_rate

    def test_late_payment_penalty_applied(self, engine, high_risk_loan_profile):
        """Profile with late payments should have a higher rate."""
        clean_profile = CustomerProfile(
            account_id=   "CLEAN",
            account_type= AccountType.LOAN,
            balance=      8_000.0,
            risk_tier=    RiskTier.HIGH,
            has_late_payments=False,
        )
        late_profile = CustomerProfile(
            account_id=   "LATE",
            account_type= AccountType.LOAN,
            balance=      8_000.0,
            risk_tier=    RiskTier.HIGH,
            has_late_payments=True,
        )
        clean_result = engine.calculate_rate(clean_profile, log=False)
        late_result  = engine.calculate_rate(late_profile,  log=False)
        assert late_result.annual_rate > clean_result.annual_rate

    def test_active_account_bonus(self, engine):
        """Account with >10 monthly transactions earns an active bonus."""
        inactive = CustomerProfile(
            account_id="INACT", account_type=AccountType.SAVINGS,
            balance=10_000.0, risk_tier=RiskTier.MEDIUM,
            monthly_transactions=2,
        )
        active = CustomerProfile(
            account_id="ACT", account_type=AccountType.SAVINGS,
            balance=10_000.0, risk_tier=RiskTier.MEDIUM,
            monthly_transactions=15,
        )
        r_inactive = engine.calculate_rate(inactive, log=False)
        r_active   = engine.calculate_rate(active,   log=False)
        assert r_active.annual_rate > r_inactive.annual_rate

    def test_inflationary_higher_than_normal(self, engine, savings_profile):
        """Inflationary scenario should produce a higher rate than normal."""
        r_normal = engine.calculate_rate(
            savings_profile, scenario=MarketScenario.NORMAL, log=False
        )
        r_inflation = engine.calculate_rate(
            savings_profile, scenario=MarketScenario.INFLATIONARY, log=False
        )
        assert r_inflation.annual_rate > r_normal.annual_rate

    def test_recession_lower_than_normal(self, engine, savings_profile):
        """Recession scenario should produce a lower rate than normal."""
        r_normal   = engine.calculate_rate(
            savings_profile, scenario=MarketScenario.NORMAL, log=False
        )
        r_recession = engine.calculate_rate(
            savings_profile, scenario=MarketScenario.RECESSION, log=False
        )
        assert r_recession.annual_rate < r_normal.annual_rate

    def test_breakdown_sums_to_final_rate(self, engine, savings_profile):
        """
        Sum of all breakdown components should equal the final rate
        (before clamping).  Tolerance for floating point.
        """
        result = engine.calculate_rate(savings_profile, log=False)
        total = sum(result.breakdown.values())
        # After clamping the final rate may differ slightly from the sum
        # We check that the breakdown components are individually finite
        for key, val in result.breakdown.items():
            assert math.isfinite(val), f"Breakdown component {key} is not finite"

    def test_to_dict_serialisable(self, engine, savings_profile):
        """to_dict() should produce a JSON-serialisable dict."""
        import json
        result = engine.calculate_rate(savings_profile, log=False)
        d = result.to_dict()
        json_str = json.dumps(d)
        assert len(json_str) > 0

    def test_apply_rate(self, engine, savings_profile):
        app = engine.apply_rate(savings_profile, days=30, log=False)
        assert app.final_amount > savings_profile.balance
        assert app.interest_earned > 0

    def test_simulate_future_interest_length(self, engine, savings_profile):
        snapshots = engine.simulate_future_interest(
            savings_profile, horizon_months=12
        )
        assert len(snapshots) == 12

    def test_simulate_future_reinvest_grows(self, engine, savings_profile):
        """With reinvestment, balance should monotonically increase."""
        snapshots = engine.simulate_future_interest(
            savings_profile, horizon_months=6, reinvest=True
        )
        balances = [s["closing_balance"] for s in snapshots]
        assert all(balances[i] < balances[i+1] for i in range(len(balances)-1))

    def test_amortise_loan_schedule(self, engine, loan_profile):
        schedule = engine.amortise_loan(loan_profile, term_months=24)
        # Must have at most 24 entries (may be fewer if paid early due to rounding)
        assert 1 <= len(schedule) <= 24
        # Final closing balance should be near zero
        assert schedule[-1].closing_balance < 1.0

    def test_amortise_loan_wrong_account_type(self, engine, savings_profile):
        with pytest.raises(ValueError):
            engine.amortise_loan(savings_profile, term_months=12)

    def test_update_scenario_changes_rate(self, engine, savings_profile):
        r1 = engine.calculate_rate(savings_profile, log=False)
        engine.update_scenario(MarketScenario.RECESSION)
        r2 = engine.calculate_rate(savings_profile, log=False)
        # Rate should differ after scenario change
        assert r1.annual_rate != r2.annual_rate
        # Reset
        engine.update_scenario(MarketScenario.NORMAL)

    def test_zero_balance_does_not_crash(self, engine):
        """Zero-balance account should still compute without error."""
        profile = CustomerProfile(
            account_id="ZERO", account_type=AccountType.SAVINGS, balance=0.0
        )
        result = engine.calculate_rate(profile, log=False)
        assert result.annual_rate >= 0


# ─────────────────────────────────────────────────────────────────────────────
# 3. AI / ML Model
# ─────────────────────────────────────────────────────────────────────────────

class TestAIModel:

    def test_synthetic_data_shape(self):
        df = GradientBoostingRateModel.generate_synthetic_training_data(n_samples=500)
        assert len(df) == 500
        assert "optimal_rate" in df.columns

    def test_synthetic_data_rate_bounds(self):
        df = GradientBoostingRateModel.generate_synthetic_training_data(n_samples=1000)
        assert df["optimal_rate"].between(0.001, 0.35).all()

    def test_model_fit_and_predict(self, savings_profile):
        model = GradientBoostingRateModel()
        df    = model.generate_synthetic_training_data(n_samples=2_000)
        metrics = model.fit_from_dataframe(df)

        assert metrics["r2"] > 0.5, f"R² too low: {metrics['r2']}"
        assert metrics["mae"] < 0.02, f"MAE too high: {metrics['mae']}"

        rate = model.predict(savings_profile, MarketScenario.NORMAL)
        assert isinstance(rate, float)
        assert 0.0 < rate < 1.0

    def test_model_predict_before_fit_raises(self, savings_profile):
        model = GradientBoostingRateModel()
        with pytest.raises(RuntimeError, match="not fitted"):
            model.predict(savings_profile, MarketScenario.NORMAL)

    def test_ml_model_integrated_with_engine(self, savings_profile):
        """Engine with AI model should return a valid, clamped rate."""
        model = GradientBoostingRateModel()
        df    = model.generate_synthetic_training_data(n_samples=2_000)
        model.fit_from_dataframe(df)

        engine = DynRateEngine(ai_model=model)
        result = engine.calculate_rate(savings_profile, log=False)

        lo, hi = RATE_BOUNDS[AccountType.SAVINGS]
        assert lo <= result.annual_rate <= hi
        # ML adjustment should be non-zero
        assert result.breakdown.get("ml_adjustment", 0) != 0.0

    def test_rl_training_convergence(self, savings_profile):
        agent   = RLRateOptimiser()
        summary = agent.train(n_episodes=500)

        assert summary["episodes"] == 500
        assert summary["final_epsilon"] < 0.20   # Should have decayed
        assert summary["q_table_states"] > 0

    def test_rl_predict_after_training(self, savings_profile):
        agent = RLRateOptimiser()
        agent.train(n_episodes=300)
        rate = agent.predict(savings_profile, MarketScenario.NORMAL)
        assert 0.001 <= rate <= 0.35


# ─────────────────────────────────────────────────────────────────────────────
# 4. Simulator
# ─────────────────────────────────────────────────────────────────────────────

class TestSimulator:

    def _make_portfolio(self) -> list:
        return [
            CustomerProfile(
                account_id="P1", account_type=AccountType.SAVINGS,
                balance=10_000.0, risk_tier=RiskTier.LOW,
            ),
            CustomerProfile(
                account_id="P2", account_type=AccountType.LOAN,
                balance=25_000.0, risk_tier=RiskTier.MEDIUM,
            ),
            CustomerProfile(
                account_id="P3", account_type=AccountType.CHECKING,
                balance=5_000.0, risk_tier=RiskTier.HIGH,
            ),
        ]

    def test_multi_scenario_run_shape(self):
        sim = MultiScenarioSimulator()
        df  = sim.run(self._make_portfolio(), log=False)
        # 3 profiles × 5 scenarios = 15 rows
        assert len(df) == 15
        assert "annual_rate_pct" in df.columns

    def test_multi_scenario_pivot(self):
        sim   = MultiScenarioSimulator()
        pivot = sim.pivot_by_scenario(self._make_portfolio())
        # Should have a column per scenario
        for s in MarketScenario:
            assert s.value in pivot.columns

    def test_interest_impact_analysis(self):
        sim = MultiScenarioSimulator()
        df  = sim.interest_impact_analysis(
            self._make_portfolio(), horizon_days=365
        )
        assert "delta_vs_normal_£" in df.columns
        # NORMAL scenario delta should be 0
        normal_rows = df[df["scenario"] == MarketScenario.NORMAL.value]
        assert (normal_rows["delta_vs_normal_£"] == 0).all()

    def test_historical_replay(self):
        sim      = HistoricalSimulator()
        timeline = HistoricalSimulator.build_rate_hike_timeline(
            start_date="2022-01-01", months=12
        )
        df = sim.replay(self._make_portfolio(), timeline, log=False)
        assert len(df) == 12 * 3   # 12 months × 3 accounts

    def test_stress_test_no_violations(self):
        tester = StressTester()
        result = tester.run_boundary_check(n_samples=500)
        assert result["passed"], (
            f"Stress test found {result['violations']} violation(s): "
            f"{result['violation_details'][:3]}"
        )

    def test_sensitivity_matrix_shape(self):
        tester = StressTester()
        matrix = tester.sensitivity_matrix(
            account_type=AccountType.SAVINGS,
            risk_tier=   RiskTier.MEDIUM,
        )
        # Should have len(MarketScenario) rows and several balance columns
        assert len(matrix) == len(list(MarketScenario))

    def test_scenario_report_columns(self):
        portfolio = self._make_portfolio()
        df = generate_scenario_report(portfolio)
        required = {
            "account_id", "account_type", "scenario",
            "annual_rate_%", "effective_apy_%",
            "monthly_interest_£", "annual_interest_£",
        }
        assert required.issubset(df.columns)


# ─────────────────────────────────────────────────────────────────────────────
# 5. Audit Logging
# ─────────────────────────────────────────────────────────────────────────────

class TestAuditLogging:

    def test_log_event_written(self, tmp_path):
        audit = AuditLogger(log_dir=str(tmp_path), log_file="test_audit.jsonl")
        audit.log_rate_event(
            account_id="A1", account_type="savings",
            previous_rate=0.04, new_rate=0.045,
            factors={"scenario": "normal"},
            description="Test event",
        )
        records = audit.export_logs()
        assert len(records) == 1
        assert records[0]["account_id"] == "A1"
        assert records[0]["new_rate"] == 0.045

    def test_delta_bps_calculated(self, tmp_path):
        audit = AuditLogger(log_dir=str(tmp_path), log_file="test_audit2.jsonl")
        audit.log_rate_event(
            account_id="A2", account_type="loan",
            previous_rate=0.07, new_rate=0.075,
            factors={},
        )
        records = audit.export_logs()
        assert abs(records[0]["delta_bps"] - 50.0) < 0.01

    def test_export_logs_returns_list(self, tmp_path):
        audit = AuditLogger(log_dir=str(tmp_path), log_file="test_audit3.jsonl")
        for i in range(5):
            audit.log_rate_event(
                account_id=f"ACC-{i}", account_type="savings",
                previous_rate=0.04, new_rate=0.042 + i * 0.001,
                factors={},
            )
        records = audit.export_logs()
        assert len(records) == 5

    def test_engine_logging_integration(self, tmp_path, savings_profile):
        config = EngineConfig(
            log_dir=str(tmp_path),
            log_file="engine_audit.jsonl",
        )
        engine = DynRateEngine(config=config)
        engine.calculate_rate(savings_profile, log=True)
        records = engine.get_audit_log()
        assert len(records) == 1
        assert records[0]["account_id"] == savings_profile.account_id


# ─────────────────────────────────────────────────────────────────────────────
# 6. Edge Cases & Numerical Stability
# ─────────────────────────────────────────────────────────────────────────────

class TestEdgeCases:

    def test_very_large_balance(self):
        engine  = DynRateEngine()
        profile = CustomerProfile(
            account_id="BIG", account_type=AccountType.SAVINGS,
            balance=10_000_000.0, risk_tier=RiskTier.LOW,
        )
        result = engine.calculate_rate(profile, log=False)
        lo, hi = RATE_BOUNDS[AccountType.SAVINGS]
        assert lo <= result.annual_rate <= hi

    def test_all_account_types_compute(self):
        engine = DynRateEngine()
        for atype in AccountType:
            profile = CustomerProfile(
                account_id=f"T-{atype.value}",
                account_type=atype,
                balance=10_000.0,
            )
            result = engine.calculate_rate(profile, log=False)
            assert result.annual_rate > 0

    def test_all_scenarios_compute(self):
        engine  = DynRateEngine()
        profile = CustomerProfile(
            account_id="SCEN", account_type=AccountType.SAVINGS, balance=5000.0
        )
        for scenario in MarketScenario:
            result = engine.calculate_rate(profile, scenario=scenario, log=False)
            assert math.isfinite(result.annual_rate)

    def test_all_risk_tiers_compute(self):
        engine = DynRateEngine()
        for tier in RiskTier:
            profile = CustomerProfile(
                account_id=f"RT-{tier.value}",
                account_type=AccountType.LOAN,
                balance=20_000.0,
                risk_tier=tier,
            )
            result = engine.calculate_rate(profile, log=False)
            assert math.isfinite(result.annual_rate)

    def test_compound_interest_precision(self):
        """
        Verify compound interest to 6 significant figures.
        £1,000 at 10% monthly compounded for 1 year → £1,104.71
        """
        final, _ = compound_interest(1_000.0, 0.10, 365, "monthly")
        assert abs(final - 1104.71) < 0.50

    def test_loan_amortisation_total_interest(self):
        """
        Total interest paid on a loan should be greater than zero and
        less than the original principal (for sub-100% rates).
        """
        engine  = DynRateEngine()
        profile = CustomerProfile(
            account_id="AMORT", account_type=AccountType.LOAN,
            balance=10_000.0, risk_tier=RiskTier.MEDIUM,
        )
        schedule = engine.amortise_loan(profile, term_months=36)
        total_interest = sum(e.interest_portion for e in schedule)
        assert 0 < total_interest < profile.balance


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
