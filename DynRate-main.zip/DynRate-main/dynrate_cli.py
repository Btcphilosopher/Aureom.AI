"""
cli/dynrate_cli.py
─────────────────────────────────────────────────────────────────────────────
DynRate CLI — quick rate queries from the terminal

Usage examples:
    python cli/dynrate_cli.py rate  --type savings --balance 20000 --risk low
    python cli/dynrate_cli.py loan  --balance 25000 --term 36 --risk medium
    python cli/dynrate_cli.py sim   --type savings --balance 15000 --months 12
    python cli/dynrate_cli.py bench --balance 10000 --scenario inflationary
    python cli/dynrate_cli.py audit
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rich import box
from rich.console import Console
from rich.table import Table
from rich.text import Text

from dynrate import (
    AccountType, CustomerProfile, DynRateEngine, EngineConfig,
    MarketScenario, RiskTier,
)

console = Console(color_system="truecolor")
C_GOLD, C_CYAN, C_GREEN, C_RED, C_DIM = "#FFB800", "#00D4FF", "#00FF9F", "#FF4D4D", "#6B7280"


def _engine() -> DynRateEngine:
    return DynRateEngine(config=EngineConfig(log_dir="logs"))


def cmd_rate(args: argparse.Namespace) -> None:
    """Calculate and display the current rate for an account."""
    engine  = _engine()
    profile = CustomerProfile(
        account_id=   args.id,
        account_type= AccountType(args.type),
        balance=      args.balance,
        risk_tier=    RiskTier(args.risk),
        monthly_transactions= args.txns,
    )
    scenario = MarketScenario(args.scenario) if args.scenario else None
    result   = engine.calculate_rate(profile, scenario=scenario, log=True)

    t = Table(box=box.SIMPLE_HEAVY, border_style=C_DIM,
              header_style=f"bold {C_CYAN}", show_header=False, padding=(0, 2))
    t.add_column("Key",   style=C_DIM,   min_width=26)
    t.add_column("Value", style=f"bold {C_WHITE}", min_width=16, justify="right")

    C_WHITE = "#F0F0F0"
    t.add_row("Account ID",    f"[{C_WHITE}]{result.account_id}[/]")
    t.add_row("Account Type",  f"[{C_CYAN}]{result.account_type.upper()}[/]")
    t.add_row("Annual Rate",   f"[{C_GOLD}]{result.annual_rate * 100:.4f}%[/]")
    t.add_row("Effective APY", f"[{C_GOLD}]{result.effective_apy * 100:.4f}%[/]")
    t.add_row("Scenario",      f"[#00D4FF]{result.scenario.upper()}[/]")
    t.add_row("Risk Tier",     result.risk_tier.upper())
    t.add_row("Timestamp",     result.calculation_ts[:19])
    t.add_row("──────────────────────────────", "")
    for factor, val in result.breakdown.items():
        bps  = val * 10_000
        sign = "+" if bps >= 0 else ""
        col  = C_GREEN if bps >= 0 else C_RED
        t.add_row(f"  {factor}", f"[{col}]{sign}{bps:.1f} bps[/]")

    console.print(f"\n[bold {C_GOLD}]  ⬡  DYNRATE RATE QUERY[/]\n")
    console.print(t)


def cmd_loan(args: argparse.Namespace) -> None:
    """Generate and display a loan amortisation schedule."""
    engine  = _engine()
    profile = CustomerProfile(
        account_id=                    args.id,
        account_type=                  AccountType.LOAN,
        balance=                       args.balance,
        risk_tier=                     RiskTier(args.risk),
        consecutive_on_time_payments=  args.ontime,
        has_late_payments=             args.late,
    )
    result   = engine.calculate_rate(profile, log=False)
    schedule = engine.amortise_loan(profile, term_months=args.term)
    total_i  = sum(r.interest_portion for r in schedule)
    pmt      = schedule[0].payment

    console.print(f"\n[bold {C_GOLD}]  ⬡  LOAN AMORTISATION — {args.id}[/]")
    console.print(f"  APR [{C_CYAN}]{result.annual_rate * 100:.4f}%[/{C_CYAN}]  "
                  f"Monthly [{C_GOLD}]£{pmt:,.2f}[/{C_GOLD}]  "
                  f"Total Interest [{C_RED}]£{total_i:,.2f}[/{C_RED}]\n")

    t = Table(box=box.SIMPLE, border_style=C_DIM,
              header_style=f"bold {C_CYAN}", padding=(0, 1))
    t.add_column("Month",   justify="right",  style=C_DIM)
    t.add_column("Opening", justify="right",  style="#F0F0F0")
    t.add_column("Payment", justify="right",  style=f"bold {C_GOLD}")
    t.add_column("Interest", justify="right", style=C_RED)
    t.add_column("Principal", justify="right", style=C_GREEN)
    t.add_column("Closing",  justify="right",  style=C_CYAN)

    show_rows = schedule if len(schedule) <= 24 else (
        schedule[:6] + [None] + schedule[-3:]   # type: ignore
    )
    for row in show_rows:
        if row is None:
            t.add_row(*["  ···"] * 6)
            continue
        t.add_row(
            str(row.month),
            f"£{row.opening_balance:>10,.2f}",
            f"£{row.payment:>8,.2f}",
            f"£{row.interest_portion:>8,.2f}",
            f"£{row.principal_portion:>9,.2f}",
            f"£{row.closing_balance:>10,.2f}",
        )
    console.print(t)


def cmd_simulate(args: argparse.Namespace) -> None:
    """Project future interest earnings month by month."""
    engine  = _engine()
    profile = CustomerProfile(
        account_id=   args.id,
        account_type= AccountType(args.type),
        balance=      args.balance,
        risk_tier=    RiskTier(args.risk),
    )
    scenario  = MarketScenario(args.scenario) if args.scenario else None
    snapshots = engine.simulate_future_interest(
        profile, horizon_months=args.months,
        scenario=scenario, reinvest=not args.no_reinvest,
    )

    total_earned = sum(s["interest_earned"] for s in snapshots)
    console.print(f"\n[bold {C_GOLD}]  ⬡  FUTURE SIMULATION — {args.months} months[/]")
    console.print(f"  Starting balance [{C_CYAN}]£{args.balance:,.2f}[/{C_CYAN}]  "
                  f"Total interest [{C_GREEN}]£{total_earned:,.2f}[/{C_GREEN}]\n")

    t = Table(box=box.SIMPLE, border_style=C_DIM,
              header_style=f"bold {C_CYAN}", padding=(0, 1))
    t.add_column("Mo", justify="right",  style=C_DIM)
    t.add_column("Opening",  justify="right", style="#F0F0F0")
    t.add_column("Rate",     justify="right", style=C_CYAN)
    t.add_column("Earned",   justify="right", style=C_GREEN)
    t.add_column("Closing",  justify="right", style=f"bold {C_GOLD}")

    for s in snapshots:
        t.add_row(
            str(s["month"]),
            f"£{s['opening_balance']:>12,.2f}",
            s["annual_rate_pct"],
            f"£{s['interest_earned']:>8,.2f}",
            f"£{s['closing_balance']:>12,.2f}",
        )
    console.print(t)


def cmd_bench(args: argparse.Namespace) -> None:
    """Quick cross-scenario benchmark for one account."""
    engine  = _engine()
    profile = CustomerProfile(
        account_id=   args.id,
        account_type= AccountType(args.type),
        balance=      args.balance,
        risk_tier=    RiskTier(args.risk),
    )

    console.print(f"\n[bold {C_GOLD}]  ⬡  SCENARIO BENCHMARK — {args.id}[/]\n")
    t = Table(box=box.SIMPLE_HEAVY, border_style=C_DIM,
              header_style=f"bold {C_CYAN}", padding=(0, 2))
    t.add_column("SCENARIO",    style="bold", min_width=16)
    t.add_column("APR",         justify="right", min_width=10)
    t.add_column("APY",         justify="right", min_width=10)
    t.add_column("Δ vs NORMAL", justify="right", min_width=12)

    normal_rate = None
    for scenario in MarketScenario:
        r = engine.calculate_rate(profile, scenario=scenario, log=False)
        if scenario == MarketScenario.NORMAL:
            normal_rate = r.annual_rate

        delta = (r.annual_rate - normal_rate) * 10_000 if normal_rate else 0
        scol  = {
            "normal": C_CYAN, "recession": "#FF8C42",
            "inflationary": C_RED, "deflationary": "#A78BFA",
            "high_volatility": C_GOLD,
        }.get(scenario.value, "#F0F0F0")

        dsign = "+" if delta >= 0 else ""
        dcol  = C_GREEN if delta >= 0 else C_RED
        t.add_row(
            f"[{scol}]{scenario.value.upper().replace('_',' ')}[/]",
            f"[{scol}]{r.annual_rate * 100:.4f}%[/]",
            f"[{scol}]{r.effective_apy * 100:.4f}%[/]",
            f"[{dcol}]{dsign}{delta:.1f} bps[/]" if normal_rate else "—",
        )
        if scenario == MarketScenario.NORMAL:
            normal_rate = r.annual_rate

    console.print(t)


def cmd_audit(args: argparse.Namespace) -> None:
    """Show the last N audit log entries."""
    engine  = _engine()
    records = list(reversed(engine.get_audit_log()))[:args.n]

    console.print(f"\n[bold {C_GOLD}]  ⬡  AUDIT LOG  (last {args.n} entries)[/]\n")
    t = Table(box=box.SIMPLE, border_style=C_DIM,
              header_style=f"bold {C_CYAN}", padding=(0, 1))
    t.add_column("TIME",      style=C_DIM,  min_width=8)
    t.add_column("ACCOUNT",   min_width=14)
    t.add_column("TYPE",      style=C_DIM)
    t.add_column("PREV",      justify="right")
    t.add_column("NEW",       justify="right", style=C_CYAN)
    t.add_column("Δ BPS",     justify="right")
    t.add_column("SCENARIO",  style=C_DIM)

    for rec in records:
        ts    = rec.get("timestamp", "")[:19].split("T")[-1]
        delta = rec.get("delta_bps", 0)
        dcol  = C_GREEN if delta >= 0 else C_RED
        t.add_row(
            ts,
            rec.get("account_id","—"),
            rec.get("account_type","—"),
            f"{rec.get('previous_rate',0)*100:.3f}%",
            f"{rec.get('new_rate',0)*100:.3f}%",
            f"[{dcol}]{'+' if delta>=0 else ''}{delta:.1f}[/]",
            rec.get("factors",{}).get("scenario","—"),
        )

    console.print(t)


# ─────────────────────────────────────────────────────────────────────────────
# Argument parser
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="dynrate",
        description="DynRate CLI — Dynamic Interest Engine"
    )
    sub = p.add_subparsers(dest="command")

    # rate
    r = sub.add_parser("rate", help="Calculate current rate for an account")
    r.add_argument("--id",       default="CLI-001")
    r.add_argument("--type",     default="savings",
                   choices=["savings","checking","loan"])
    r.add_argument("--balance",  type=float, default=10_000.0)
    r.add_argument("--risk",     default="medium",
                   choices=["low","medium","high"])
    r.add_argument("--txns",     type=int, default=0)
    r.add_argument("--scenario", default=None)

    # loan
    l = sub.add_parser("loan", help="Generate loan amortisation schedule")
    l.add_argument("--id",      default="LOAN-CLI-001")
    l.add_argument("--balance", type=float, default=25_000.0)
    l.add_argument("--term",    type=int,   default=36)
    l.add_argument("--risk",    default="medium", choices=["low","medium","high"])
    l.add_argument("--ontime",  type=int,   default=0)
    l.add_argument("--late",    action="store_true")

    # sim
    s = sub.add_parser("sim", help="Simulate future interest projection")
    s.add_argument("--id",           default="SIM-001")
    s.add_argument("--type",         default="savings",
                   choices=["savings","checking","loan"])
    s.add_argument("--balance",      type=float, default=10_000.0)
    s.add_argument("--risk",         default="medium", choices=["low","medium","high"])
    s.add_argument("--months",       type=int,   default=12)
    s.add_argument("--scenario",     default=None)
    s.add_argument("--no-reinvest",  action="store_true")

    # bench
    b = sub.add_parser("bench", help="Cross-scenario benchmark for one account")
    b.add_argument("--id",      default="BENCH-001")
    b.add_argument("--type",    default="savings",
                   choices=["savings","checking","loan"])
    b.add_argument("--balance", type=float, default=15_000.0)
    b.add_argument("--risk",    default="medium", choices=["low","medium","high"])

    # audit
    a = sub.add_parser("audit", help="Show recent audit log entries")
    a.add_argument("--n", type=int, default=20)

    return p


def main() -> None:
    os.makedirs("logs", exist_ok=True)
    parser = build_parser()
    args   = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    dispatch = {
        "rate":  cmd_rate,
        "loan":  cmd_loan,
        "sim":   cmd_simulate,
        "bench": cmd_bench,
        "audit": cmd_audit,
    }
    dispatch[args.command](args)
    console.print()


if __name__ == "__main__":
    main()
