"""
api/middleware.py
─────────────────────────────────────────────────────────────────────────────
ASGI middleware stack for the DynRate API.

Included:
  • RequestTimingMiddleware  – adds X-Process-Time-Ms response header
  • RequestLoggingMiddleware – structured per-request access log (JSON)
  • CORSMiddleware           – configured for typical banking SPA origins
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from typing import Callable

from fastapi import Request, Response
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

logger = logging.getLogger("dynrate.api.access")


class RequestTimingMiddleware(BaseHTTPMiddleware):
    """
    Measures wall-clock time for every request and injects the result
    into the response as X-Process-Time-Ms.

    Also stamps each request with a unique X-Request-ID header for
    distributed tracing (uses a short UUID4 prefix for readability).
    """

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = str(uuid.uuid4())[:8]
        request.state.request_id = request_id

        t0       = time.perf_counter()
        response = await call_next(request)
        elapsed  = (time.perf_counter() - t0) * 1_000   # → milliseconds

        response.headers["X-Request-ID"]       = request_id
        response.headers["X-Process-Time-Ms"]  = f"{elapsed:.2f}"
        return response


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Emits a structured JSON access-log line after every request.

    Format mirrors a subset of the Common Log Format extended with
    DynRate-specific fields for audit / SIEM ingestion.
    """

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        t0       = time.perf_counter()
        response = await call_next(request)
        elapsed  = (time.perf_counter() - t0) * 1_000

        log_record = {
            "type":        "access",
            "method":      request.method,
            "path":        request.url.path,
            "status":      response.status_code,
            "duration_ms": round(elapsed, 2),
            "request_id":  getattr(request.state, "request_id", "-"),
            "client_ip":   (request.client.host if request.client else "-"),
        }
        logger.info(json.dumps(log_record))
        return response


def configure_cors(app: ASGIApp, allowed_origins: list[str] | None = None) -> None:
    """
    Attach CORSMiddleware with banking-appropriate defaults.

    In production, replace the wildcard with your SPA's origin(s).
    """
    origins = allowed_origins or ["*"]
    app.add_middleware(                          # type: ignore[attr-defined]
        CORSMiddleware,
        allow_origins=     origins,
        allow_credentials= True,
        allow_methods=     ["GET", "POST", "PATCH", "OPTIONS"],
        allow_headers=     ["*"],
        expose_headers=    ["X-Request-ID", "X-Process-Time-Ms"],
    )
