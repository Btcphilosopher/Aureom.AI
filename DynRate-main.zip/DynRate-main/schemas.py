"""
api/schemas.py
─────────────────────────────────────────────────────────────────────────────
Pydantic v2 request / response models for the DynRate API.

All monetary values are in GBP (£).  Rates are returned as both decimal
and percentage strings for client convenience.
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator, model_validator

from dynrate.config import AccountType, MarketScenario, RiskTier


# ─────────────────────────────────────────────────────────────────────────────
# Request Models
# ─────────────────────────────────────────────────────────────────────────────

class RateRequest(BaseModel):
    """POST /rates/calculate — calculate the current rate for an account."""
    account_id:                   str           = Field(..., min_length=1, max_length=64)
    account_type:                 AccountType
    balance:                      float         = Field(..., gt=0, le=50_000_000)
    risk_tier:                    RiskTier      = RiskTier.MEDIUM
    monthly_transactions:         int           = Field(0, ge=0, le=10_000)
    months_since_opened:          int           = Field(0, ge=0, le=600)
    consecutive_on_time_payments: int           = Field(0, ge=0, le=600)
    has_late_payments:            bool          = False
    scenario:                     Optional[MarketScenario] = None
    ml_predicted_rate:            Optional[float] = Field(None, ge=0.0, le=1.0)

    model_config = {"json_schema_extra": {"example": {
        "account_id":    "ACC-001",
        "account_type":  "savings",
        "balance":       22500.0,
        "risk_tier":     "low",
        "monthly_transactions": 18,
        "months_since_opened":  36,
    }}}


class ApplyRateRequest(RateRequest):
    """POST /rates/apply — apply the rate for a given number of days."""
    days:        int = Field(30, ge=1, le=3650)
    compounding: str = Field("monthly", pattern="^(daily|monthly|quarterly|annually)$")


class SimulateFutureRequest(RateRequest):
    """POST /rates/simulate — project interest earnings month-by-month."""
    horizon_months: int  = Field(12, ge=1, le=360)
    reinvest:       bool = True


class LoanAmortiseRequest(BaseModel):
    """POST /loans/amortise — generate full amortisation schedule."""
    account_id:                   str   = Field(..., min_length=1)
    balance:                      float = Field(..., gt=0, le=10_000_000)
    risk_tier:                    RiskTier = RiskTier.MEDIUM
    term_months:                  int   = Field(36, ge=1, le=360)
    consecutive_on_time_payments: int   = Field(0, ge=0)
    has_late_payments:            bool  = False
    scenario:                     Optional[MarketScenario] = None

    @field_validator("term_months")
    @classmethod
    def validate_term(cls, v: int) -> int:
        if v < 1:
            raise ValueError("Loan term must be at least 1 month")
        return v


class ScenarioCompareRequest(BaseModel):
    """POST /simulate/scenarios — compare rates across all market scenarios."""
    accounts: List[RateRequest] = Field(..., min_length=1, max_length=50)
    scenarios: Optional[List[MarketScenario]] = None


class HistoricalReplayRequest(BaseModel):
    """POST /simulate/historical — replay a rate-hiking timeline."""
    accounts:         List[RateRequest]
    start_date:       str   = Field(..., pattern=r"^\d{4}-\d{2}-\d{2}$")
    months:           int   = Field(12, ge=1, le=60)
    start_benchmark:  float = Field(0.005, ge=0.0, le=0.25)


class BenchmarkUpdateRequest(BaseModel):
    """PATCH /admin/benchmark — update the engine's benchmark rate."""
    rate: float = Field(..., ge=0.0, le=0.25,
                        description="New benchmark rate (decimal, e.g. 0.0525 = 5.25%)")


class ScenarioUpdateRequest(BaseModel):
    """PATCH /admin/scenario — change the active market scenario."""
    scenario: MarketScenario


# ─────────────────────────────────────────────────────────────────────────────
# Response Models
# ─────────────────────────────────────────────────────────────────────────────

class RateBreakdown(BaseModel):
    base_rate_pct:          float
    scenario_adjustment_pct: float
    benchmark_tether_pct:   float
    balance_tier_pct:       float
    risk_spread_pct:        float
    behaviour_adjustment_pct: float
    ml_adjustment_pct:      float
    regulatory_clamp_pct:   float


class RateResponse(BaseModel):
    account_id:        str
    account_type:      str
    annual_rate:       float   = Field(..., description="Decimal APR")
    annual_rate_pct:   str     = Field(..., description="Human-readable APR, e.g. '5.1234%'")
    effective_apy:     float
    effective_apy_pct: str
    scenario:          str
    risk_tier:         str
    calculation_ts:    str
    breakdown_pct:     Dict[str, float]
    description:       str


class InterestApplicationResponse(BaseModel):
    account_id:      str
    principal:       float
    annual_rate_pct: str
    days:            int
    compounding:     str
    final_amount:    float
    interest_earned: float
    calculation_ts:  str


class SimulationSnapshot(BaseModel):
    month:           int
    opening_balance: float
    annual_rate_pct: str
    interest_earned: float
    closing_balance: float


class LoanScheduleRow(BaseModel):
    month:             int
    opening_balance:   float
    payment:           float
    principal_portion: float
    interest_portion:  float
    closing_balance:   float


class LoanAmortiseResponse(BaseModel):
    account_id:     str
    principal:      float
    term_months:    int
    annual_rate_pct: str
    monthly_payment: float
    total_interest:  float
    total_repaid:    float
    schedule:        List[LoanScheduleRow]


class ScenarioCompareRow(BaseModel):
    account_id:         str
    account_type:       str
    scenario:           str
    annual_rate_pct:    float
    effective_apy_pct:  float
    risk_tier:          str
    balance:            float


class HealthResponse(BaseModel):
    status:          str
    version:         str
    scenario:        str
    benchmark_rate:  float
    engine_ready:    bool


class AuditRecord(BaseModel):
    timestamp:     str
    account_id:    str
    account_type:  str
    previous_rate: float
    new_rate:      float
    delta_bps:     float
    factors:       Dict[str, Any]
    description:   str


class ErrorResponse(BaseModel):
    error:   str
    detail:  Optional[str] = None
    code:    int
