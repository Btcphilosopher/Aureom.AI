"""
cli/dashboard.py
─────────────────────────────────────────────────────────────────────────────
DynRate Terminal Dashboard

A live-updating Rich terminal dashboard that visualises:
  • Current rates across all account types and scenarios
  • Rate sensitivity matrix (heatmap-style table)
  • Loan amortisation sparkline
  • ML model metrics
  • Audit log tail

Run:
    cd dynrate
    python cli/dashboard.py
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import os
import sys
import time
from datetime import datetime
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn
from rich.rule import Rule
from rich.style import Style
from rich.table import Table
from rich.text import Text

from dynrate import (
    AccountType,
    CustomerProfile,
    DynRateEngine,
    EngineConfig,
    GradientBoostingRateModel,
    MarketScenario,
    RiskTier,
    StressTester,
)
from dynrate.config import BASE_RATES, SCENARIO_MULTIPLIERS, RATE_BOUNDS

# ─────────────────────────────────────────────────────────────────────────────
# Colour palette (Charcoal + Gold + Cyan — matches Tom's aesthetic)
# ─────────────────────────────────────────────────────────────────────────────

C_GOLD   = "#FFB800"
C_CYAN   = "#00D4FF"
C_GREEN  = "#00FF9F"
C_RED    = "#FF4D4D"
C_DIM    = "#6B7280"
C_WHITE  = "#F0F0F0"
C_BG     = "grey7"

SCENARIO_COLOURS = {
    "normal":          C_CYAN,
    "recession":       "#FF8C42",
    "inflationary":    C_RED,
    "deflationary":    "#A78BFA",
    "high_volatility": C_GOLD,
}

RISK_ICONS = {RiskTier.LOW: "🟢", RiskTier.MEDIUM: "🟡", RiskTier.HIGH: "🔴"}


# ─────────────────────────────────────────────────────────────────────────────
# Widget builders
# ─────────────────────────────────────────────────────────────────────────────

def make_header(engine: DynRateEngine, ml_ready: bool) -> Panel:
    scenario  = engine.config.scenario.value.upper()
    bench     = engine.config.benchmark_rate * 100
    scen_col  = SCENARIO_COLOURS.get(engine.config.scenario.value, C_WHITE)
    ml_badge  = f"[{C_GREEN}]● ML ON[/]" if ml_ready else f"[{C_DIM}]○ ML OFF[/]"

    title = Text()
    title.append("  ⬡  DYNRATE  ", style=f"bold {C_GOLD}")
    title.append("Dynamic Interest Engine  ", style=f"bold {C_WHITE}")
    title.append(f"v1.0.0  ", style=C_DIM)
    title.append(f"[{scen_col}]{scenario}[/]  ")
    title.append(f"[{C_DIM}]BENCHMARK [{C_CYAN}]{bench:.2f}%[/]  ")
    title.append(ml_badge)
    title.append(f"  [{C_DIM}]{datetime.now().strftime('%H:%M:%S')}[/]")
    return Panel(Align.center(title), style=f"bold {C_GOLD}", padding=(0, 1))


def make_rates_table(engine: DynRateEngine) -> Table:
    """Live rate grid: account types × market scenarios."""
    table = Table(
        title="[ CURRENT RATES ]",
        title_style=f"bold {C_GOLD}",
        box=box.SIMPLE_HEAVY,
        border_style=C_DIM,
        show_header=True,
        header_style=f"bold {C_CYAN}",
        padding=(0, 1),
    )
    table.add_column("ACCOUNT TYPE", style=f"bold {C_WHITE}", min_width=14)
    for s in MarketScenario:
        colour = SCENARIO_COLOURS.get(s.value, C_WHITE)
        table.add_column(s.value.upper().replace("_", " "),
                         style=colour, justify="right", min_width=12)

    for atype in AccountType:
        row_vals = [f"[bold]{atype.value.upper()}[/]"]
        for scenario in MarketScenario:
            profile = CustomerProfile(
                account_id=   f"DASH-{atype.value}",
                account_type= atype,
                balance=      25_000.0,
                risk_tier=    RiskTier.MEDIUM,
            )
            result = engine.calculate_rate(profile, scenario=scenario, log=False)
            rate   = result.annual_rate * 100
            lo, hi = RATE_BOUNDS[atype]
            # Colour by distance from bounds
            pct_range = (hi - lo) * 100
            pct_pos   = (result.annual_rate - lo) / (hi - lo)
            colour    = SCENARIO_COLOURS.get(scenario.value, C_WHITE)
            row_vals.append(f"[{colour}]{rate:.3f}%[/]")
        table.add_row(*row_vals)
    return table


def make_sensitivity_panel(engine: DynRateEngine) -> Panel:
    """Heatmap-style sensitivity matrix for savings, medium risk."""
    tester = StressTester(config=engine.config)
    matrix = tester.sensitivity_matrix(AccountType.SAVINGS, RiskTier.MEDIUM)

    table = Table(
        box=box.SIMPLE,
        border_style=C_DIM,
        header_style=f"bold {C_CYAN}",
        padding=(0, 1),
    )
    table.add_column("SCENARIO", style=f"bold {C_WHITE}", min_width=16)
    for col in matrix.columns:
        table.add_column(col, justify="right", min_width=9)

    for scenario in matrix.index:
        colour = SCENARIO_COLOURS.get(scenario, C_WHITE)
        vals   = [f"[{colour}]{scenario.upper()}[/]"]
        for col in matrix.columns:
            raw = float(matrix.loc[scenario, col].rstrip("%"))
            # Colour cells: hotter = higher rate
            if raw >= 7.0:
                cell_col = C_RED
            elif raw >= 5.5:
                cell_col = C_GOLD
            elif raw >= 4.0:
                cell_col = C_CYAN
            else:
                cell_col = C_DIM
            vals.append(f"[{cell_col}]{raw:.3f}%[/]")
        table.add_row(*vals)

    return Panel(
        table,
        title=f"[bold {C_GOLD}][ SENSITIVITY MATRIX — SAVINGS / MEDIUM RISK ][/]",
        border_style=C_DIM,
    )


def make_risk_comparison_panel(engine: DynRateEngine) -> Panel:
    """Side-by-side rate comparison for all risk tiers."""
    balances = [5_000, 25_000, 100_000]

    table = Table(
        box=box.SIMPLE,
        border_style=C_DIM,
        header_style=f"bold {C_CYAN}",
        padding=(0, 1),
    )
    table.add_column("BALANCE", style=f"bold {C_WHITE}", min_width=12)
    for tier in RiskTier:
        icon = RISK_ICONS[tier]
        table.add_column(f"{icon} {tier.value.upper()}", justify="right", min_width=10)

    for balance in balances:
        row = [f"[{C_WHITE}]£{balance:>9,.0f}[/]"]
        for tier in RiskTier:
            profile = CustomerProfile(
                account_id=   f"CMP-{tier.value}",
                account_type= AccountType.SAVINGS,
                balance=      float(balance),
                risk_tier=    tier,
            )
            result = engine.calculate_rate(profile, log=False)
            col    = C_GREEN if tier == RiskTier.LOW else (
                     C_GOLD  if tier == RiskTier.MEDIUM else C_RED)
            row.append(f"[{col}]{result.annual_rate * 100:.3f}%[/]")
        table.add_row(*row)

    return Panel(
        table,
        title=f"[bold {C_GOLD}][ RISK TIER COMPARISON — SAVINGS ][/]",
        border_style=C_DIM,
    )


def make_loan_panel(engine: DynRateEngine) -> Panel:
    """Loan rate breakdown + amortisation summary for a sample loan."""
    profile = CustomerProfile(
        account_id=                    "DASH-LOAN",
        account_type=                  AccountType.LOAN,
        balance=                       25_000.0,
        risk_tier=                     RiskTier.MEDIUM,
        consecutive_on_time_payments=  14,
    )
    result   = engine.calculate_rate(profile, log=False)
    schedule = engine.amortise_loan(profile, term_months=36)
    pmt      = schedule[0].payment
    total_int = sum(r.interest_portion for r in schedule)

    table = Table(box=box.SIMPLE, border_style=C_DIM, header_style=f"bold {C_CYAN}",
                  show_header=False, padding=(0, 2))
    table.add_column("Key",   style=f"{C_DIM}", min_width=22)
    table.add_column("Value", style=f"bold {C_WHITE}", justify="right")

    table.add_row("Principal",         f"[{C_WHITE}]£25,000.00[/]")
    table.add_row("APR",               f"[{C_CYAN}]{result.annual_rate * 100:.4f}%[/]")
    table.add_row("APY",               f"[{C_CYAN}]{result.effective_apy * 100:.4f}%[/]")
    table.add_row("Monthly Payment",   f"[{C_GOLD}]£{pmt:,.2f}[/]")
    table.add_row("Term",              f"[{C_WHITE}]36 months[/]")
    table.add_row("Total Interest",    f"[{C_RED}]£{total_int:,.2f}[/]")
    table.add_row("Total Repaid",      f"[{C_WHITE}]£{pmt * len(schedule):,.2f}[/]")

    # Tiny ASCII sparkline of the closing balance over term
    balances = [r.closing_balance for r in schedule]
    spark    = _sparkline(balances, width=28)
    table.add_row("Balance curve", f"[{C_DIM}]{spark}[/]")

    return Panel(
        table,
        title=f"[bold {C_GOLD}][ SAMPLE LOAN — £25k / 36 MONTHS ][/]",
        border_style=C_DIM,
    )


def make_ml_metrics_panel(metrics: dict, ml_ready: bool) -> Panel:
    """ML model status and performance metrics."""
    table = Table(box=box.SIMPLE, border_style=C_DIM, show_header=False,
                  padding=(0, 2))
    table.add_column("Metric", style=C_DIM, min_width=22)
    table.add_column("Value",  style=f"bold {C_WHITE}", justify="right")

    if ml_ready and metrics:
        mae_bps = metrics.get("mae", 0) * 10_000
        r2      = metrics.get("r2", 0)
        n_train = metrics.get("n_train", 0)

        table.add_row("Model",         f"[{C_CYAN}]GradientBoostingRegressor[/]")
        table.add_row("Status",        f"[{C_GREEN}]● TRAINED & ACTIVE[/]")
        table.add_row("MAE",           f"[{C_GOLD}]{mae_bps:.2f} bps[/]")
        table.add_row("R²",            f"[{C_GREEN}]{r2:.4f}[/]")
        table.add_row("Train samples", f"[{C_WHITE}]{n_train:,}[/]")
        table.add_row("ML blend",      f"[{C_WHITE}]40% ML / 60% rules[/]")
    else:
        table.add_row("Model",  f"[{C_DIM}]Not loaded[/]")
        table.add_row("Status", f"[{C_DIM}]○ RULES-ONLY MODE[/]")

    return Panel(
        table,
        title=f"[bold {C_GOLD}][ ML MODEL STATUS ][/]",
        border_style=C_DIM,
    )


def make_audit_tail_panel(engine: DynRateEngine, n: int = 6) -> Panel:
    """Most recent N audit log entries."""
    records = list(reversed(engine.get_audit_log()))[:n]

    table = Table(box=box.SIMPLE, border_style=C_DIM,
                  header_style=f"bold {C_CYAN}", padding=(0, 1))
    table.add_column("TIME",      style=C_DIM,     min_width=8)
    table.add_column("ACCOUNT",   style=C_WHITE,   min_width=14)
    table.add_column("TYPE",      style=C_DIM,     min_width=8)
    table.add_column("PREV",      justify="right", min_width=8)
    table.add_column("NEW",       justify="right", min_width=8)
    table.add_column("Δ bps",     justify="right", min_width=8)
    table.add_column("SCENARIO",  style=C_DIM,     min_width=12)

    for rec in records:
        ts      = rec.get("timestamp", "")[:19].split("T")[-1]
        delta   = rec.get("delta_bps", 0)
        dcol    = C_GREEN if delta >= 0 else C_RED
        dsign   = "+" if delta >= 0 else ""
        scen    = rec.get("factors", {}).get("scenario", "—")
        scol    = SCENARIO_COLOURS.get(scen, C_DIM)
        table.add_row(
            ts,
            rec.get("account_id", "—"),
            rec.get("account_type", "—"),
            f"{rec.get('previous_rate', 0) * 100:.3f}%",
            f"[{C_CYAN}]{rec.get('new_rate', 0) * 100:.3f}%[/]",
            f"[{dcol}]{dsign}{delta:.1f}[/]",
            f"[{scol}]{scen}[/]",
        )

    if not records:
        table.add_row(*["[dim]—[/]"] * 7)

    return Panel(
        table,
        title=f"[bold {C_GOLD}][ AUDIT LOG — LIVE TAIL ][/]",
        border_style=C_DIM,
    )


def make_footer() -> Panel:
    keys = Text()
    keys.append(" q ", style=f"bold black on {C_GOLD}")
    keys.append(" quit  ", style=C_DIM)
    keys.append(" r ", style=f"bold black on {C_CYAN}")
    keys.append(" refresh  ", style=C_DIM)
    keys.append(" [ / ] ", style=f"bold black on #5A5A5A")
    keys.append(" prev/next scenario  ", style=C_DIM)
    keys.append(f"  [{C_DIM}]DynRate Financial Engine · Refreshes every 3s[/]")
    return Panel(Align.center(keys), style=C_DIM, padding=(0, 0))


# ─────────────────────────────────────────────────────────────────────────────
# ASCII sparkline helper
# ─────────────────────────────────────────────────────────────────────────────

def _sparkline(values: List[float], width: int = 20) -> str:
    """Render a list of floats as an ASCII bar sparkline."""
    blocks = " ▁▂▃▄▅▆▇█"
    if not values:
        return " " * width
    lo, hi = min(values), max(values)
    span   = hi - lo or 1.0
    # Downsample to width
    step   = max(1, len(values) // width)
    sampled = [values[i] for i in range(0, len(values), step)][:width]
    return "".join(blocks[int((v - lo) / span * (len(blocks) - 1))] for v in sampled)


# ─────────────────────────────────────────────────────────────────────────────
# Main dashboard loop
# ─────────────────────────────────────────────────────────────────────────────

def run_dashboard(refresh_seconds: float = 3.0) -> None:
    console = Console(color_system="truecolor")

    # ── Initialise engine + optional ML ──────────────────────────────────────
    console.print(f"\n[bold {C_GOLD}]  ⬡  DYNRATE  [/][{C_WHITE}]Initialising engine…[/]")
    ml_model = GradientBoostingRateModel()
    with console.status(f"[{C_CYAN}]Training ML model on 6,000 samples…[/]"):
        df      = GradientBoostingRateModel.generate_synthetic_training_data(6_000)
        metrics = ml_model.fit_from_dataframe(df)

    engine   = DynRateEngine(config=EngineConfig(log_dir="logs"), ai_model=ml_model)
    ml_ready = True

    # Pre-populate audit log with some sample events
    sample_profiles = [
        CustomerProfile("SAV-001", AccountType.SAVINGS,  22_500.0, RiskTier.LOW,
                        monthly_transactions=15, months_since_opened=36),
        CustomerProfile("LOAN-001", AccountType.LOAN,   30_000.0, RiskTier.MEDIUM,
                        consecutive_on_time_payments=14),
        CustomerProfile("CHK-001",  AccountType.CHECKING, 4_500.0, RiskTier.HIGH,
                        has_late_payments=True),
    ]
    for p in sample_profiles:
        for scen in [MarketScenario.NORMAL, MarketScenario.INFLATIONARY]:
            engine.calculate_rate(p, scenario=scen, log=True)

    scenarios = list(MarketScenario)
    scen_idx  = [0]   # mutable reference for closure

    def build_layout() -> Layout:
        layout = Layout()

        layout.split_column(
            Layout(name="header",    size=3),
            Layout(name="main",      ratio=1),
            Layout(name="bottom",    size=10),
            Layout(name="audit",     size=12),
            Layout(name="footer",    size=3),
        )
        layout["main"].split_row(
            Layout(name="left",   ratio=5),
            Layout(name="right",  ratio=4),
        )
        layout["right"].split_column(
            Layout(name="top_right",    ratio=1),
            Layout(name="bottom_right", ratio=1),
        )

        layout["header"].update(make_header(engine, ml_ready))
        layout["left"].update(Panel(make_rates_table(engine),
                                    border_style=C_DIM, padding=(0, 0)))
        layout["top_right"].update(make_loan_panel(engine))
        layout["bottom_right"].update(make_ml_metrics_panel(metrics, ml_ready))
        layout["bottom"].update(make_sensitivity_panel(engine))
        layout["audit"].update(make_audit_tail_panel(engine, n=5))
        layout["footer"].update(make_footer())
        return layout

    console.print(f"[{C_GREEN}]  ✓ Ready  —  launching dashboard[/]\n")
    time.sleep(0.5)

    try:
        with Live(build_layout(), console=console, refresh_per_second=0.5,
                  screen=True) as live:
            while True:
                time.sleep(refresh_seconds)
                # Cycle scenario to show live rate changes
                scen_idx[0] = (scen_idx[0] + 1) % len(scenarios)
                engine.update_scenario(scenarios[scen_idx[0]])
                live.update(build_layout())

    except KeyboardInterrupt:
        console.print(f"\n[{C_GOLD}]  DynRate dashboard closed.[/]\n")


if __name__ == "__main__":
    run_dashboard()
