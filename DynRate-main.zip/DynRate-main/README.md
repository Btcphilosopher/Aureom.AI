# DynRate: Dynamic Interest Engine

> Production-ready Python module for dynamic interest rate calculation, AI-enhanced prediction, and multi-scenario simulation for modern banking backends.

---

## Architecture

```
dynrate/
├── dynrate/
│   ├── __init__.py       ← Public API surface
│   ├── config.py         ← All parameters, thresholds, enumerations
│   ├── engine.py         ← Core 8-step rate calculation pipeline
│   ├── ai_model.py       ← GradientBoosting + Q-Learning models
│   ├── simulator.py      ← Multi-scenario, historical replay, stress test
│   └── utils.py          ← Logging, compound interest math, validation
├── tests/
│   └── test_dynrate.py   ← 40+ unit and integration tests
├── examples/
│   └── run_examples.py   ← Full end-to-end demonstration
└── logs/                 ← JSONL audit logs (auto-created)
```

---

## Rate Calculation Pipeline

Every rate is computed through a deterministic 8-step pipeline:

| Step | Factor | Description |
|------|--------|-------------|
| 1 | **Base Rate** | Default rate for account type |
| 2 | **Scenario Multiplier** | Market condition (recession, inflation, etc.) |
| 3 | **Benchmark Tether** | Pull toward central-bank policy rate (30% weight) |
| 4 | **Balance Tier** | Volume discount / premium by balance band |
| 5 | **Risk Spread** | Customer risk classification spread |
| 6 | **Behaviour Adjustment** | Transaction activity, loyalty, late payments |
| 7 | **ML Override** | Optional 40% AI blend |
| 8 | **Regulatory Clamp** | Hard floor/ceiling per regulatory bounds |

---

## Installation

```bash
pip install pandas numpy scikit-learn
```

No additional dependencies required. All ML components use scikit-learn.

---

## Quick Start

```python
from dynrate import DynRateEngine, CustomerProfile, AccountType, RiskTier, MarketScenario

engine = DynRateEngine()

profile = CustomerProfile(
    account_id            = "ACC-001",
    account_type          = AccountType.SAVINGS,
    balance               = 22_500.0,
    risk_tier             = RiskTier.LOW,
    monthly_transactions  = 18,
    months_since_opened   = 36,
)

result = engine.calculate_rate(profile)
print(result.to_dict())
# {
#   "annual_rate_pct": 5.1234,
#   "effective_apy_pct": 5.2401,
#   "scenario": "normal",
#   "breakdown_pct": { "base_rate": 4.5, "scenario_adjustment": ... }
# }
```

---

## Key Features

### Dynamic Rate Factors
- **Account Types**: `SAVINGS`, `CHECKING`, `LOAN`
- **Market Scenarios**: `NORMAL`, `RECESSION`, `INFLATIONARY`, `DEFLATIONARY`, `HIGH_VOLATILITY`
- **Risk Tiers**: `LOW`, `MEDIUM`, `HIGH`
- **Balance Tiers**: 4 bands per account type (adjustments up to ±1pp)
- **Behavioural Signals**: Active account bonus, loyalty discount, late-payment penalty

### AI/ML Models
```python
# Gradient Boosting (supervised)
model = GradientBoostingRateModel()
df    = model.generate_synthetic_training_data(n_samples=10_000)
model.fit_from_dataframe(df)
engine = DynRateEngine(ai_model=model)

# Reinforcement Learning (Q-learning policy)
agent = RLRateOptimiser()
agent.train(n_episodes=5_000)
rate  = agent.predict(profile, MarketScenario.NORMAL)
```

### Simulation
```python
# Multi-scenario comparison
sim   = MultiScenarioSimulator()
pivot = sim.pivot_by_scenario(portfolio)   # Rate % per scenario

# Historical replay (rate-hiking cycle)
sim      = HistoricalSimulator()
timeline = HistoricalSimulator.build_rate_hike_timeline("2022-01-01", months=12)
df       = sim.replay(portfolio, timeline)

# Stress test
tester = StressTester()
result = tester.run_boundary_check(n_samples=2_000)
assert result["passed"]

# Sensitivity matrix
matrix = tester.sensitivity_matrix(AccountType.SAVINGS, RiskTier.MEDIUM)
```

### Loan Amortisation
```python
schedule = engine.amortise_loan(loan_profile, term_months=36)
for row in schedule:
    print(row.month, row.payment, row.interest_portion, row.closing_balance)
```

### Audit Logging
All rate decisions are written to `logs/dynrate_audit.jsonl`:
```json
{
  "timestamp": "2026-04-05T10:30:00Z",
  "account_id": "ACC-001",
  "account_type": "savings",
  "previous_rate": 0.045,
  "new_rate": 0.0512,
  "delta_bps": 62.0,
  "factors": { "scenario": "normal", "risk_tier": "low", ... }
}
```

Export:
```python
engine.export_audit_log("audit_export.json")
records = engine.get_audit_log()
```

---

## FastAPI Integration

```python
from fastapi  import APIRouter
from pydantic import BaseModel
from dynrate  import DynRateEngine, CustomerProfile, AccountType, RiskTier

router  = APIRouter(prefix="/rates")
_engine = DynRateEngine()

class RateRequest(BaseModel):
    account_id:   str
    account_type: AccountType
    balance:      float
    risk_tier:    RiskTier = RiskTier.MEDIUM

@router.post("/calculate")
def calculate_rate(req: RateRequest):
    profile = CustomerProfile(**req.model_dump())
    return _engine.calculate_rate(profile).to_dict()
```

---

## Running Tests

```bash
cd dynrate
python -m pytest tests/ -v --tb=short
```

Expected: **40+ tests, all passing**.

---

## Running the Full Demo

```bash
cd dynrate
python examples/run_examples.py
```

---

## Configuration

All parameters are in `dynrate/config.py`:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `BENCHMARK_RATE` | 5.25% | Central bank policy rate |
| `BASE_RATES` | 4.5% / 1.0% / 7.5% | Per account type |
| `RATE_BOUNDS` | See config | Regulatory floor/ceiling |
| `NIM_SPREAD` | 1.5pp | Target net interest margin |
| `LATE_PAYMENT_PENALTY` | +3pp | Applied to loan rate |
| `LOYALTY_RATE_DISCOUNT` | –0.5pp | After 12 on-time payments |

Override at runtime:
```python
from dynrate import EngineConfig, MarketScenario

config = EngineConfig(
    benchmark_rate = 0.04,
    scenario       = MarketScenario.RECESSION,
)
engine = DynRateEngine(config=config)
```

---

## Design Principles

- **Stateless**: Each `calculate_rate()` call is independent — safe to use in async/multi-threaded backends
- **Audit-first**: Every rate decision is logged with full factor breakdown
- **Explainable**: `RateResult.breakdown` exposes every pipeline contribution in basis points
- **Regulatory-safe**: Hard clamps enforced last, after all adjustments
- **ML-augmented, not ML-dependent**: Rules run even if model is absent or fails
