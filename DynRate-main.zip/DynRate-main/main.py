"""
api/main.py
─────────────────────────────────────────────────────────────────────────────
DynRate FastAPI Application

Creates and configures the ASGI application.  Designed as a factory
(`create_app`) so it can be instantiated in tests with different configs
without side effects.

Usage
-----
    # Development (with auto-reload)
    uvicorn api.main:app --reload --host 0.0.0.0 --port 8000

    # Production (Gunicorn + Uvicorn workers)
    gunicorn api.main:app -k uvicorn.workers.UvicornWorker -w 4

    # Direct Python
    python api/main.py
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

import logging
import os
import sys
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

# ── path setup so this runs from project root ─────────────────────────────
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dynrate import __version__
from api.dependencies import _engine_state
from api.middleware import (
    RequestLoggingMiddleware,
    RequestTimingMiddleware,
    configure_cors,
)
from api.routes import admin, loans, rates, simulation

# ── logging ───────────────────────────────────────────────────────────────
logging.basicConfig(
    level=  logging.INFO,
    format= "%(asctime)s  %(name)-28s  %(levelname)-8s  %(message)s",
)
logger = logging.getLogger("dynrate.api")


# ─────────────────────────────────────────────────────────────────────────────
# Lifespan (replaces deprecated @app.on_event)
# ─────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Startup: initialise the DynRateEngine (and optionally train ML model).
    Shutdown: flush any pending log buffers.
    """
    load_ml  = os.getenv("DYNRATE_LOAD_ML", "true").lower() == "true"
    ml_samp  = int(os.getenv("DYNRATE_ML_SAMPLES", "5000"))
    log_dir  = os.getenv("DYNRATE_LOG_DIR", "logs")

    logger.info("DynRate API v%s  —  starting up", __version__)
    logger.info("ML enabled=%s  ml_samples=%d  log_dir=%s", load_ml, ml_samp, log_dir)

    _engine_state.initialise(log_dir=log_dir, load_ml=load_ml, ml_samples=ml_samp)

    logger.info(
        "Engine ready  scenario=%s  benchmark=%.2f%%  ml=%s",
        _engine_state.engine.config.scenario.value,
        _engine_state.engine.config.benchmark_rate * 100,
        "on" if _engine_state.ml_ready else "off",
    )

    yield   # ← application runs here

    logger.info("DynRate API  —  shutting down")


# ─────────────────────────────────────────────────────────────────────────────
# Application Factory
# ─────────────────────────────────────────────────────────────────────────────

def create_app(allowed_origins: list[str] | None = None) -> FastAPI:
    app = FastAPI(
        title=       "DynRate — Dynamic Interest Engine",
        description= (
            "Production-grade API for real-time interest rate calculation, "
            "loan amortisation, scenario simulation, and AI-enhanced rate "
            "prediction for modern banking platforms."
        ),
        version=     __version__,
        lifespan=    lifespan,
        docs_url=    "/docs",
        redoc_url=   "/redoc",
        openapi_url= "/openapi.json",
    )

    # ── Middleware ────────────────────────────────────────────────────────
    configure_cors(app, allowed_origins)
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(RequestTimingMiddleware)

    # ── Routers ───────────────────────────────────────────────────────────
    app.include_router(rates.router)
    app.include_router(loans.router)
    app.include_router(simulation.router)
    app.include_router(admin.router)

    # ── Global exception handler ──────────────────────────────────────────
    @app.exception_handler(Exception)
    async def unhandled_exception(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": "Internal server error", "detail": str(exc), "code": 500},
        )

    return app


# Module-level app instance (used by uvicorn / gunicorn)
app = create_app()


# ─────────────────────────────────────────────────────────────────────────────
# Dev runner
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api.main:app",
        host=    "0.0.0.0",
        port=    int(os.getenv("PORT", "8000")),
        reload=  True,
        log_level="info",
    )
