"""
api/routes/admin.py
─────────────────────────────────────────────────────────────────────────────
/admin  —  operational control and audit endpoints

  PATCH /admin/benchmark    → update central-bank rate
  PATCH /admin/scenario     → switch market scenario
  GET   /admin/audit        → paginated audit log
  GET   /admin/audit/export → download full audit log as JSON
  GET   /health             → liveness / readiness probe
─────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse

from api.dependencies import EngineState, get_engine_state
from api.schemas import (
    AuditRecord,
    BenchmarkUpdateRequest,
    HealthResponse,
    ScenarioUpdateRequest,
)
from dynrate import __version__

router = APIRouter(tags=["Admin & Audit"])


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Liveness / readiness probe",
)
def health(state: EngineState = Depends(get_engine_state)) -> HealthResponse:
    """
    Kubernetes liveness / readiness probe endpoint.
    Returns 200 when the engine is initialised and ready to serve.
    """
    try:
        engine = state.engine
        return HealthResponse(
            status=         "ok",
            version=        __version__,
            scenario=       engine.config.scenario.value,
            benchmark_rate= engine.config.benchmark_rate,
            engine_ready=   True,
        )
    except RuntimeError:
        return HealthResponse(
            status="starting",
            version=__version__,
            scenario="unknown",
            benchmark_rate=0.0,
            engine_ready=False,
        )


@router.patch(
    "/admin/benchmark",
    summary="Update the central-bank benchmark rate",
    response_model=dict,
)
def update_benchmark(
    req:   BenchmarkUpdateRequest,
    state: EngineState = Depends(get_engine_state),
) -> dict:
    """
    Reflect a central-bank rate decision in the engine.

    In production this would be called by a scheduled job that polls a
    market-data feed (e.g. BoE / Fed Funds target rate API).
    """
    old_rate = state.engine.config.benchmark_rate
    state.update_benchmark(req.rate)
    return {
        "status":       "updated",
        "previous_rate": round(old_rate * 100, 4),
        "new_rate":      round(req.rate * 100, 4),
        "delta_bps":     round((req.rate - old_rate) * 10_000, 2),
    }


@router.patch(
    "/admin/scenario",
    summary="Switch the active market scenario",
    response_model=dict,
)
def update_scenario(
    req:   ScenarioUpdateRequest,
    state: EngineState = Depends(get_engine_state),
) -> dict:
    """
    Change the engine's active market scenario.

    All subsequent rate calculations will use this scenario unless the
    caller passes an explicit `scenario` field in the request body.
    """
    old = state.engine.config.scenario.value
    state.update_scenario(req.scenario)
    return {
        "status":       "updated",
        "previous":     old,
        "new":          req.scenario.value,
    }


@router.get(
    "/admin/audit",
    response_model=List[AuditRecord],
    summary="Retrieve paginated audit log",
)
def get_audit_log(
    limit:      int = Query(50,  ge=1,  le=500),
    offset:     int = Query(0,   ge=0),
    account_id: Optional[str]    = Query(None),
    state:      EngineState      = Depends(get_engine_state),
) -> List[AuditRecord]:
    """
    Return audit records, most-recent first.

    Filter by *account_id* for account-specific rate history.
    Paginate using *limit* and *offset*.
    """
    records = state.engine.get_audit_log()
    records = list(reversed(records))   # Most recent first

    if account_id:
        records = [r for r in records if r.get("account_id") == account_id]

    page = records[offset: offset + limit]
    return [AuditRecord(**r) for r in page]


@router.get(
    "/admin/audit/export",
    summary="Download the full audit log as JSON",
)
def export_audit_log(
    state: EngineState = Depends(get_engine_state),
) -> JSONResponse:
    """
    Return the complete audit log as a downloadable JSON file.

    Sets Content-Disposition: attachment so browsers trigger a download.
    """
    records = state.engine.get_audit_log()
    return JSONResponse(
        content=records,
        headers={
            "Content-Disposition": 'attachment; filename="dynrate_audit.json"'
        },
    )
