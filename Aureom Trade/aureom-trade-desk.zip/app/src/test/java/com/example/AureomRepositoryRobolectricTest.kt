package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.SyntheticMarketData
import com.example.data.TerminalRepository
import com.example.data.local.AureomDatabase
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.OrderSide
import com.example.domain.model.OrgRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AureomRepositoryRobolectricTest {

    private lateinit var db: AureomDatabase
    private lateinit var repo: TerminalRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = TerminalRepository(db.terminalDao())
        runBlocking { repo.initializeOrReplay() }
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `stock reservation prevents overselling and releases on cancel`() = runBlocking {
        val beforeBatch = repo.inventories.first().first { it.instrumentId == "LAUNDRY-LIQ-UK-DEC26" }
        val initialAvail = beforeBatch.availableQty
        val initialRes = beforeBatch.reservedQty

        // Place SELL order for 100 cases -> atomically reserves 100 cases
        val res = repo.placeSpotLimitOrder(
            instrumentId = "LAUNDRY-LIQ-UK-DEC26",
            orgId = SyntheticMarketData.ORG_NORTHSHORE_SUPPLY,
            role = OrgRole.SALES_MANAGER,
            side = OrderSide.SELL,
            limitPrice = bd("36.50"),
            quantity = 100L,
        )
        assertTrue(res.isSuccess)
        val afterOrderBatch = repo.inventories.first().first { it.instrumentId == "LAUNDRY-LIQ-UK-DEC26" }
        assertEquals(initialAvail - 100L, afterOrderBatch.availableQty)
        assertEquals(initialRes + 100L, afterOrderBatch.reservedQty)

        // Cancel that resting sell order -> releases 100 cases back to available
        val restingSell = repo.engineSnapshot.value.orders.first {
            it.instrumentId == "LAUNDRY-LIQ-UK-DEC26" && it.side == OrderSide.SELL && it.limitPrice == bd("36.50") && it.orgId == SyntheticMarketData.ORG_NORTHSHORE_SUPPLY
        }
        val cancelRes = repo.cancelSpotOrder(restingSell, SyntheticMarketData.ORG_NORTHSHORE_SUPPLY, OrgRole.SALES_MANAGER)
        assertTrue(cancelRes.isSuccess)
        val afterCancelBatch = repo.inventories.first().first { it.instrumentId == "LAUNDRY-LIQ-UK-DEC26" }
        assertEquals(initialAvail, afterCancelBatch.availableQty)
        assertEquals(initialRes, afterCancelBatch.reservedQty)
    }

    @Test
    fun `credit checks block over-limit buy orders and segregation of duties blocks self-approval`() = runBlocking {
        // Attempt huge buy order exceeding credit limit -> blocked
        val overCredit = repo.placeSpotLimitOrder(
            instrumentId = "LAUNDRY-LIQ-UK-DEC26",
            orgId = SyntheticMarketData.ORG_AUREOM_DESK,
            role = OrgRole.TRADER,
            side = OrderSide.BUY,
            limitPrice = bd("36.00"),
            quantity = 8000L, // $288,000 exceeds available credit ($265,480) & order limit ($120,000)
        )
        assertTrue(overCredit.isFailure)

        // Segregation of duties: Procurement Manager created FWD-2088, so Procurement Manager cannot approve it
        val fwd = repo.contracts.first().first { it.contractId == "FWD-2088" }
        val selfApprove = repo.approveAndAcceptForward(fwd, OrgRole.PROCUREMENT_MANAGER)
        assertTrue(selfApprove.isFailure)

        // Independent Approver succeeds
        val independentApprove = repo.approveAndAcceptForward(fwd, OrgRole.APPROVER)
        assertTrue(independentApprove.isSuccess)
    }

    @Test
    fun `forward amendments preserve signed version history and delivery discrepancies adjust invoice`() = runBlocking {
        val fwd = repo.contracts.first().first { it.contractId == "AT-1047" }
        val amended = repo.proposeAndSignAmendment(fwd, "Add 100 cases", bd("19.50"), 500L, OrgRole.APPROVER).getOrThrow()
        assertEquals(2, amended.signedVersion)
        assertEquals(1, amended.amendments.size)
        assertEquals(500L, amended.contractedQty)

        val shp = repo.shipments.first().first { it.shipmentId == "SHP-7701" }
        val updatedShp = repo.recordPartialDelivery(shp, 40L, 30L, OrgRole.WAREHOUSE_OPERATOR).getOrThrow()
        assertEquals(360L, updatedShp.deliveredQty)
        assertEquals(350L, updatedShp.acceptedQty)
        assertEquals(10L, updatedShp.rejectedQty)
    }

    @Test
    fun `complete 12 step E2E demonstration and Room event-log restart replay succeed`() = runBlocking {
        val steps = repo.runComplete12StepDemonstration()
        assertEquals(12, steps.size)
        assertTrue(steps.all { it.completed })

        val beforeCount = repo.engineSnapshot.value.eventCount
        val beforeOrders = repo.engineSnapshot.value.orders.size
        assertTrue(beforeCount > 0)

        // Simulate restart reconstruction using a fresh repository instance on the same Room DAO
        val restartedRepo = TerminalRepository(db.terminalDao())
        restartedRepo.initializeOrReplay()
        val replayed = restartedRepo.engineSnapshot.value
        assertEquals(beforeCount, replayed.eventCount)
        assertEquals(beforeOrders, replayed.orders.size)
        assertFalse(replayed.orders.isEmpty())
    }
}
