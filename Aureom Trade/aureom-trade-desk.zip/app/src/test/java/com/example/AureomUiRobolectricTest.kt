package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AureomUiRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `terminal launches with market watch, order ticket, and navigation tabs`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithText("AUREOM TRADE").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_tab_trade").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_tab_contracts").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("FWD-2088", substring = true).assertIsDisplayed()

        composeRule.onNodeWithTag("nav_tab_reports").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("run_12_step_demo_btn").assertIsDisplayed()
    }
}
