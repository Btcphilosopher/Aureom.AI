package com.example

import com.example.ai.AiAssistantGuardrail
import com.example.data.SyntheticMarketData
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DecimalMath
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.InstrumentCompatibility
import com.example.domain.model.LandedCostCalculator
import com.example.domain.model.MarginHealthStatus
import com.example.domain.model.OrderSide
import com.example.domain.model.OrderStatus
import com.example.domain.model.OrgRole
import com.example.domain.model.TradeTerm
import com.example.engine.EngineCommand
import com.example.engine.FuturesSimulationEngine
import com.example.engine.MatchingPartition
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class AureomEngineAndDomainTest {

    private val nowMs = 1_794_734_000_000L
    private val instruments = SyntheticMarketData.instruments(nowMs)
    private val laundry = instruments.first { it.id == "LAUNDRY-LIQ-UK-DEC26" }
    private val oil = instruments.first { it.id == "COOKING-OIL-NL-DEC26" }

    @Test
    fun `instrument compatibility rejects unlike SKU, location, and terms`() {
        val same = InstrumentCompatibility.checkFungibility(laundry, laundry.copy())
        assertTrue(same.isFungible)
        assertTrue(same.mismatchReasons.isEmpty())

        val diffLocation = InstrumentCompatibility.checkFungibility(
            laundry,
            laundry.copy(deliveryLocation = "Manchester, UK", namedPlace = "Manchester"),
        )
        assertFalse(diffLocation.isFungible)
        assertTrue(diffLocation.mismatchReasons.any { it.contains("Location") })

        val diffProduct = InstrumentCompatibility.checkFungibility(laundry, oil)
        assertFalse(diffProduct.isFungible)
        assertTrue(diffProduct.mismatchReasons.size >= 4)
    }

    @Test
    fun `packaging conversion and equivalent unit price are exact`() {
        // 12 x 1 L = 12 L per case; 60 cases per pallet; $36.00/case = $3.0000/L
        assertEquals(1440L, laundry.packaging.casesToUnits(120L))
        assertEquals(bd("2.00"), laundry.packaging.casesToPallets(120L))
        assertEquals(bd("3.0000"), laundry.packaging.equivalentUnitPrice(bd("36.00")))
    }

    @Test
    fun `currency precision and display conversion never mutate contract settlement`() {
        val rates = SyntheticMarketData.fxRates(nowMs)
        val gbp = DecimalMath.convertDisplayOnly(bd("100.00"), CurrencyCode.USD, CurrencyCode.GBP, rates)
        assertEquals(bd("78.50"), gbp)
        val jpy = DecimalMath.convertDisplayOnly(bd("10.00"), CurrencyCode.USD, CurrencyCode.JPY, rates)
        assertEquals(0, jpy.scale())
        assertEquals(bd("1524"), jpy)
    }

    @Test
    fun `landed cost avoids double counting freight and insurance when DAP`() {
        val adapter = SyntheticMarketData.freightAdapters().first()
        val fob = LandedCostCalculator.compute(bd("25.00"), CurrencyCode.USD, TradeTerm.FOB, adapter)
        val dap = LandedCostCalculator.compute(bd("25.00"), CurrencyCode.USD, TradeTerm.DAP, adapter)
        assertEquals(adapter.freightPerCaseUsd, fob.additionalFreight)
        assertEquals(BigDecimal.ZERO.setScale(2), dap.additionalFreight)
        assertTrue(fob.estimatedLandedPerCase > dap.estimatedLandedPerCase)
    }

    @Test
    fun `matching engine enforces price-time priority, partial fills, and idempotency`() {
        val part = MatchingPartition(laundry)
        val exp = nowMs + 100_000L

        // Two sell orders at different prices & times
        part.submit(EngineCommand.PlaceLimitOrder("C1", laundry.id, nowMs, "S1", "ORG-A", "Seller A", "Trader", OrderSide.SELL, bd("36.30"), 100L, exp))
        part.submit(EngineCommand.PlaceLimitOrder("C2", laundry.id, nowMs + 1, "S2", "ORG-B", "Seller B", "Trader", OrderSide.SELL, bd("36.20"), 60L, exp))
        part.submit(EngineCommand.PlaceLimitOrder("C3", laundry.id, nowMs + 2, "S3", "ORG-C", "Seller C", "Trader", OrderSide.SELL, bd("36.20"), 80L, exp))

        // Buy 100 @ 36.20 -> fills S2 (60, earlier time) and part-fills S3 (40/80)
        val buyCmd = EngineCommand.PlaceLimitOrder("C4", laundry.id, nowMs + 3, "B1", "ORG-BUY", "Buyer", "Trader", OrderSide.BUY, bd("36.20"), 100L, exp)
        val outcome = part.submit(buyCmd)
        assertTrue(outcome.accepted)
        assertEquals(2, outcome.executedTrades.size)
        assertEquals("S2", outcome.executedTrades[0].sellOrderId)
        assertEquals(60L, outcome.executedTrades[0].quantity)
        assertEquals("S3", outcome.executedTrades[1].sellOrderId)
        assertEquals(40L, outcome.executedTrades[1].quantity)
        assertEquals(OrderStatus.FILLED, outcome.resultingOrder?.status)

        // Duplicate command ID returns cached idempotent replay without creating extra trades
        val dup = part.submit(buyCmd)
        assertTrue(dup.idempotentReplay)
        assertEquals(2, part.allTrades().size)
    }

    @Test
    fun `matching engine enforces self-trade prevention and cancel-vs-fill sequencing`() {
        val part = MatchingPartition(laundry)
        val exp = nowMs + 100_000L

        part.submit(EngineCommand.PlaceLimitOrder("S-1", laundry.id, nowMs, "ORD-S", "ORG-1", "Org One", "Trader", OrderSide.SELL, bd("36.20"), 100L, exp))

        // Same org attempts crossing buy -> STP blocks it
        val stp = part.submit(EngineCommand.PlaceLimitOrder("B-STP", laundry.id, nowMs + 1, "ORD-B1", "ORG-1", "Org One", "Trader", OrderSide.BUY, bd("36.20"), 60L, exp))
        assertFalse(stp.accepted)
        assertTrue(stp.selfTradePrevented)

        // Different org buys 60 -> S becomes PART_FILLED (40 remaining)
        part.submit(EngineCommand.PlaceLimitOrder("B-2", laundry.id, nowMs + 2, "ORD-B2", "ORG-2", "Org Two", "Trader", OrderSide.BUY, bd("36.20"), 60L, exp))

        // Cancel remaining 40 -> preserves filled 60 and releases 40
        val cancelOutcome = part.submit(EngineCommand.CancelOrder("CXL-1", laundry.id, nowMs + 3, "ORD-S", "ORG-1"))
        assertTrue(cancelOutcome.accepted)
        assertEquals(OrderStatus.CANCELLED, cancelOutcome.resultingOrder?.status)
        assertEquals(60L, cancelOutcome.resultingOrder?.filledQty)

        // Second cancel rejected (already cancelled)
        val cancelAgain = part.submit(EngineCommand.CancelOrder("CXL-2", laundry.id, nowMs + 4, "ORD-S", "ORG-1"))
        assertFalse(cancelAgain.accepted)
    }

    @Test
    fun `matching partition replay produces identical book and trades`() {
        val part1 = MatchingPartition(laundry)
        val exp = nowMs + 100_000L
        part1.submit(EngineCommand.PlaceLimitOrder("R1", laundry.id, nowMs, "O1", "ORG-A", "A", "Trader", OrderSide.SELL, bd("36.20"), 120L, exp))
        part1.submit(EngineCommand.PlaceLimitOrder("R2", laundry.id, nowMs + 1, "O2", "ORG-B", "B", "Trader", OrderSide.BUY, bd("36.20"), 60L, exp))
        part1.submit(EngineCommand.CancelOrder("R3", laundry.id, nowMs + 2, "O1", "ORG-A"))

        val part2 = MatchingPartition(laundry)
        part1.allEvents().forEach { part2.replayEvent(it) }

        assertEquals(part1.allOrders().size, part2.allOrders().size)
        assertEquals(part1.allTrades().size, part2.allTrades().size)
        assertEquals(part1.bidLadder(), part2.bidLadder())
        assertEquals(part1.askLadder(), part2.askLadder())
        assertEquals(part1.currentLastPrice(), part2.currentLastPrice())
    }

    @Test
    fun `futures multiplier, daily settlement without double counting, and insufficient liquidity shortfall`() {
        val spec = SyntheticMarketData.seedFuturesSpecs().first { it.contractCode == "HOMECARE-MAR27" }
        val acc0 = SyntheticMarketData.seedCollateralAccount().copy(cashCollateralPosted = bd("10000.00"))

        val (pos1, fee1) = FuturesSimulationEngine.openOrAdjustPosition(null, acc0.accountId, spec, OrderSide.BUY, 10, bd("36.20"), nowMs = nowMs)
        val acc1 = acc0.copy(feesCharged = fee1)

        // Day 1 settle at 37.20 -> +1.00 * 10 * 100 = +1000.00; settlementBasisPrice resets to 37.20
        val (pos2, acc2, res1) = FuturesSimulationEngine.runDailyVariationSettlement(pos1, spec, acc1, bd("37.20"), "2026-11-15", nowMs + 1000)
        assertEquals(bd("1000.00"), res1.variationMarginDelta)
        assertEquals(bd("37.20"), pos2.settlementBasisPrice)
        // Unrealised after reset at same price must be 0.00 (no double counting!)
        assertEquals(bd("0.00"), pos2.unrealisedVariationPnL(bd("37.20"), spec.contractMultiplier))

        // Day 2 adverse shock to 29.00 -> -8.20 * 10 * 100 = -8200.00 -> margin call (equity < 7500 maint)
        val (pos3, acc3, res2) = FuturesSimulationEngine.runDailyVariationSettlement(pos2, spec, acc2, bd("29.00"), "2026-11-16", nowMs + 2000)
        assertEquals(MarginHealthStatus.MARGIN_CALL, res2.status)

        // Forced reduction for 15 contracts when simulated book only has 12 bid contracts -> insufficient liquidity!
        val (bigPos, fee2) = FuturesSimulationEngine.openOrAdjustPosition(pos3, acc3.accountId, spec, OrderSide.BUY, 6, bd("29.00"), nowMs = nowMs + 3000)
        val reduction = FuturesSimulationEngine.simulateForcedReduction(bigPos, spec.copy(currentMarkPrice = bd("29.00")), acc3.copy(feesCharged = acc3.feesCharged.add(fee2)), 15)
        assertTrue(reduction.liquidityInsufficient)
        assertEquals(12, reduction.executedContractsClosed)
        assertEquals(3, reduction.unliquidatedContractsRemaining)
        assertTrue(reduction.residualMarginShortfall > BigDecimal.ZERO)
    }

    @Test
    fun `role permissions and AI action restrictions are strictly enforced`() {
        assertFalse(OrgRole.WAREHOUSE_OPERATOR.canPlaceSpotOrders)
        assertFalse(OrgRole.TRADER.canApproveContracts)
        assertTrue(OrgRole.APPROVER.canApproveContracts)
        assertTrue(OrgRole.FINANCE_ANALYST.canReconcileFinance)
        assertTrue(OrgRole.RISK_MANAGER.canManageRiskAndHalts)

        assertNotNull(AiAssistantGuardrail.checkRestrictedMutation("Please place a buy order for 120 cases of laundry liquid"))
        assertNotNull(AiAssistantGuardrail.checkRestrictedMutation("Approve contract FWD-2088 immediately"))
        assertNotNull(AiAssistantGuardrail.checkRestrictedMutation("Increase credit limit by $50,000"))
        assertNotNull(AiAssistantGuardrail.checkRestrictedMutation("Transfer collateral $2,000"))
        assertNotNull(AiAssistantGuardrail.checkRestrictedMutation("Change bank settlement instruction to GB99"))
        assertNull(AiAssistantGuardrail.checkRestrictedMutation("Compare equivalent unit prices across laundry and shampoo SKUs"))
    }
}
