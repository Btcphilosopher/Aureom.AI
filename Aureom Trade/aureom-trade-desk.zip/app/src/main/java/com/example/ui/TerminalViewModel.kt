package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiAssistantGuardrail
import com.example.ai.AiTradeAssistantService
import com.example.ai.AiUiState
import com.example.data.EngineSnapshot
import com.example.data.SyntheticMarketData
import com.example.data.TerminalRepository
import com.example.data.local.AuditLogEntity
import com.example.data.local.AureomDatabase
import com.example.domain.model.CommercialInvoice
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DailySettlementResult
import com.example.domain.model.DemoStepStatus
import com.example.domain.model.EngineOrder
import com.example.domain.model.FirmOfferRecord
import com.example.domain.model.ForcedReductionResult
import com.example.domain.model.ForwardContract
import com.example.domain.model.ForwardCurvePoint
import com.example.domain.model.FreightDutyTaxAdapter
import com.example.domain.model.FuturesCollateralAccount
import com.example.domain.model.FuturesContractSpec
import com.example.domain.model.FuturesPosition
import com.example.domain.model.FxRateSnapshot
import com.example.domain.model.InventoryBatch
import com.example.domain.model.MarketMode
import com.example.domain.model.OrderSide
import com.example.domain.model.OrgRole
import com.example.domain.model.OrganizationAccount
import com.example.domain.model.PhysicalInstrument
import com.example.domain.model.PricePoint
import com.example.domain.model.ProcurementPlanRow
import com.example.domain.model.RfqQuote
import com.example.domain.model.RfqRecord
import com.example.domain.model.ShipmentRecord
import com.example.domain.model.SurveillanceAlert
import com.example.domain.model.TerminalTab
import com.example.domain.model.WorkspacePreset
import com.example.ui.theme.TerminalDensity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class TerminalUiState(
    val activeTab: TerminalTab = TerminalTab.TRADE,
    val marketMode: MarketMode = MarketMode.PHYSICAL_SPOT,
    val selectedInstrumentId: String = "LAUNDRY-LIQ-UK-DEC26",
    val selectedFuturesCode: String = "HOMECARE-MAR27",
    val selectedDeliveryPeriod: String = "All Periods",
    val searchQuery: String = "",
    val activeOrgId: String = SyntheticMarketData.ORG_AUREOM_DESK,
    val activeRole: OrgRole = OrgRole.TRADER,
    val displayCurrency: CurrencyCode = CurrencyCode.USD,
    val isDarkTheme: Boolean = true,
    val density: TerminalDensity = TerminalDensity.COMPACT,
    val isFeedHealthy: Boolean = true,
    val isFeedStale: Boolean = false,
    val utcClockText: String = "14:32:08 UTC",
    val chartRange: String = "3M",
    val blotterTabIndex: Int = 0,
    val instruments: List<PhysicalInstrument> = emptyList(),
    val organizations: List<OrganizationAccount> = emptyList(),
    val futuresSpecs: List<FuturesContractSpec> = emptyList(),
    val engineSnapshot: EngineSnapshot = EngineSnapshot(),
    val inventories: List<InventoryBatch> = emptyList(),
    val offers: List<FirmOfferRecord> = emptyList(),
    val rfqs: List<RfqRecord> = emptyList(),
    val contracts: List<ForwardContract> = emptyList(),
    val shipments: List<ShipmentRecord> = emptyList(),
    val invoices: List<CommercialInvoice> = emptyList(),
    val futuresPositions: List<FuturesPosition> = emptyList(),
    val collateral: FuturesCollateralAccount = SyntheticMarketData.seedCollateralAccount(),
    val alerts: List<SurveillanceAlert> = emptyList(),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val fxRates: List<FxRateSnapshot> = emptyList(),
    val freightAdapters: List<FreightDutyTaxAdapter> = SyntheticMarketData.freightAdapters(),
    val lastSettlement: DailySettlementResult? = null,
    val lastForcedReduction: ForcedReductionResult? = null,
    val demoSteps: List<DemoStepStatus> = emptyList(),
    val workspacePresets: List<WorkspacePreset> = defaultPresets(),
    val aiState: AiUiState = AiUiState.Idle,
    val isAiSheetOpen: Boolean = false,
    val feedbackMessage: String? = null,
    val feedbackIsError: Boolean = false,
) {
    val selectedInstrument: PhysicalInstrument?
        get() = instruments.firstOrNull { it.id == selectedInstrumentId } ?: instruments.firstOrNull()

    val selectedFuturesSpec: FuturesContractSpec?
        get() = futuresSpecs.firstOrNull { it.contractCode == selectedFuturesCode } ?: futuresSpecs.firstOrNull()

    val activeOrg: OrganizationAccount?
        get() = organizations.firstOrNull { it.orgId == activeOrgId } ?: organizations.firstOrNull()

    val procurementRows: List<ProcurementPlanRow>
        get() = SyntheticMarketData.procurementPlanRows(inventories, contracts, futuresPositions)

    fun priceHistory(): List<PricePoint> {
        val base = SyntheticMarketData.priceHistoryFor(selectedInstrumentId)
        return when (chartRange) {
            "1D" -> base.takeLast(3)
            "1W" -> base.takeLast(5)
            "1M" -> base.takeLast(8)
            else -> base
        }
    }

    fun forwardCurve(): List<ForwardCurvePoint> =
        selectedInstrument?.let { SyntheticMarketData.forwardCurveFor(it) } ?: emptyList()

    companion object {
        fun defaultPresets(): List<WorkspacePreset> = listOf(
            WorkspacePreset("PRESET-SPOT", "UK Spot Desk", TerminalTab.TRADE, MarketMode.PHYSICAL_SPOT, CurrencyCode.USD, true, true),
            WorkspacePreset("PRESET-PROC", "Procurement & Hedging", TerminalTab.POSITIONS, MarketMode.PHYSICAL_FORWARD, CurrencyCode.GBP, true, false),
            WorkspacePreset("PRESET-RISK", "Risk & Margin Monitor", TerminalTab.RISK, MarketMode.FUTURES_SIMULATION, CurrencyCode.USD, true, true),
            WorkspacePreset("PRESET-LIGHT", "Daylight Operations", TerminalTab.CONTRACTS, MarketMode.PHYSICAL_FORWARD, CurrencyCode.EUR, false, false),
        )
    }
}

private data class UiControlPrefs(
    val activeTab: TerminalTab = TerminalTab.TRADE,
    val marketMode: MarketMode = MarketMode.PHYSICAL_SPOT,
    val selectedInstrumentId: String = "LAUNDRY-LIQ-UK-DEC26",
    val selectedFuturesCode: String = "HOMECARE-MAR27",
    val selectedDeliveryPeriod: String = "All Periods",
    val searchQuery: String = "",
    val activeOrgId: String = SyntheticMarketData.ORG_AUREOM_DESK,
    val activeRole: OrgRole = OrgRole.TRADER,
    val displayCurrency: CurrencyCode = CurrencyCode.USD,
    val isDarkTheme: Boolean = true,
    val density: TerminalDensity = TerminalDensity.COMPACT,
    val isFeedHealthy: Boolean = true,
    val isFeedStale: Boolean = false,
    val chartRange: String = "3M",
    val blotterTabIndex: Int = 0,
    val isAiSheetOpen: Boolean = false,
    val feedbackMessage: String? = null,
    val feedbackIsError: Boolean = false,
)

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AureomDatabase.getInstance(application)
    private val repo = TerminalRepository(db.terminalDao())
    private val aiService = AiTradeAssistantService()

    private val _prefs = MutableStateFlow(UiControlPrefs())
    private val _utcClock = MutableStateFlow(currentUtcString())
    private val _aiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    private val _demoSteps = MutableStateFlow<List<DemoStepStatus>>(emptyList())

    val uiState: StateFlow<TerminalUiState> = combine(
        _prefs,
        _utcClock,
        repo.instruments,
        repo.organizations,
        repo.futuresSpecs,
    ) { prefs, clock, instruments, orgs, futuresSpecs ->
        TerminalUiState(
            activeTab = prefs.activeTab,
            marketMode = prefs.marketMode,
            selectedInstrumentId = prefs.selectedInstrumentId,
            selectedFuturesCode = prefs.selectedFuturesCode,
            selectedDeliveryPeriod = prefs.selectedDeliveryPeriod,
            searchQuery = prefs.searchQuery,
            activeOrgId = prefs.activeOrgId,
            activeRole = prefs.activeRole,
            displayCurrency = prefs.displayCurrency,
            isDarkTheme = prefs.isDarkTheme,
            density = prefs.density,
            isFeedHealthy = prefs.isFeedHealthy,
            isFeedStale = prefs.isFeedStale,
            utcClockText = clock,
            chartRange = prefs.chartRange,
            blotterTabIndex = prefs.blotterTabIndex,
            instruments = instruments,
            organizations = orgs,
            futuresSpecs = futuresSpecs,
            fxRates = SyntheticMarketData.fxRates(System.currentTimeMillis()),
            isAiSheetOpen = prefs.isAiSheetOpen,
            feedbackMessage = prefs.feedbackMessage,
            feedbackIsError = prefs.feedbackIsError,
        )
    }.combine(repo.engineSnapshot) { state, snap ->
        state.copy(engineSnapshot = snap)
    }.combine(repo.inventories) { state, inv ->
        state.copy(inventories = inv)
    }.combine(repo.offers) { state, offers ->
        state.copy(offers = offers)
    }.combine(repo.rfqs) { state, rfqs ->
        state.copy(rfqs = rfqs)
    }.combine(repo.contracts) { state, contracts ->
        state.copy(contracts = contracts)
    }.combine(repo.shipments) { state, shipments ->
        state.copy(shipments = shipments)
    }.combine(repo.invoices) { state, invoices ->
        state.copy(invoices = invoices)
    }.combine(repo.futuresPositions) { state, futPos ->
        state.copy(futuresPositions = futPos)
    }.combine(repo.collateral) { state, col ->
        state.copy(collateral = col)
    }.combine(repo.alerts) { state, alerts ->
        state.copy(alerts = alerts)
    }.combine(repo.auditLogs) { state, logs ->
        state.copy(auditLogs = logs)
    }.combine(repo.lastSettlement) { state, settle ->
        state.copy(lastSettlement = settle)
    }.combine(repo.lastForcedReduction) { state, red ->
        state.copy(lastForcedReduction = red)
    }.combine(_aiState) { state, ai ->
        state.copy(aiState = ai)
    }.combine(_demoSteps) { state, steps ->
        state.copy(demoSteps = steps)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = TerminalUiState(),
    )

    init {
        viewModelScope.launch {
            repo.initializeOrReplay()
            val saved = repo.loadPrefs()
            _prefs.value = _prefs.value.copy(
                isDarkTheme = saved["dark_theme"]?.toBooleanStrictOrNull() ?: true,
                density = if (saved["density"] == "STANDARD") TerminalDensity.STANDARD else TerminalDensity.COMPACT,
                displayCurrency = saved["currency"]?.let { runCatching { CurrencyCode.valueOf(it) }.getOrNull() } ?: CurrencyCode.USD,
            )
        }
        viewModelScope.launch {
            while (true) {
                _utcClock.value = currentUtcString()
                delay(1000L)
            }
        }
    }

    private fun currentUtcString(): String {
        val sdf = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return sdf.format(Date())
    }

    fun selectTab(tab: TerminalTab) {
        _prefs.value = _prefs.value.copy(activeTab = tab)
    }

    fun selectMarketMode(mode: MarketMode) {
        _prefs.value = _prefs.value.copy(marketMode = mode)
    }

    fun selectInstrument(instrumentId: String) {
        _prefs.value = _prefs.value.copy(selectedInstrumentId = instrumentId)
    }

    fun selectFuturesSpec(contractCode: String) {
        _prefs.value = _prefs.value.copy(selectedFuturesCode = contractCode)
    }

    fun setDeliveryPeriodFilter(period: String) {
        _prefs.value = _prefs.value.copy(selectedDeliveryPeriod = period)
    }

    fun setSearchQuery(query: String) {
        _prefs.value = _prefs.value.copy(searchQuery = query)
    }

    fun setChartRange(range: String) {
        _prefs.value = _prefs.value.copy(chartRange = range)
    }

    fun setBlotterTab(index: Int) {
        _prefs.value = _prefs.value.copy(blotterTabIndex = index)
    }

    fun setActiveRole(role: OrgRole) {
        _prefs.value = _prefs.value.copy(activeRole = role, feedbackMessage = "Switched role to ${role.label}", feedbackIsError = false)
    }

    fun setActiveOrg(orgId: String) {
        _prefs.value = _prefs.value.copy(activeOrgId = orgId)
    }

    fun setDisplayCurrency(currency: CurrencyCode) {
        _prefs.value = _prefs.value.copy(displayCurrency = currency)
        viewModelScope.launch { repo.savePref("currency", currency.name) }
    }

    fun toggleTheme() {
        val next = !_prefs.value.isDarkTheme
        _prefs.value = _prefs.value.copy(isDarkTheme = next)
        viewModelScope.launch { repo.savePref("dark_theme", next.toString()) }
    }

    fun toggleDensity() {
        val next = if (_prefs.value.density == TerminalDensity.COMPACT) TerminalDensity.STANDARD else TerminalDensity.COMPACT
        _prefs.value = _prefs.value.copy(density = next)
        viewModelScope.launch { repo.savePref("density", next.name) }
    }

    fun toggleStaleFeedSimulation() {
        val nextStale = !_prefs.value.isFeedStale
        _prefs.value = _prefs.value.copy(
            isFeedStale = nextStale,
            isFeedHealthy = !nextStale,
            feedbackMessage = if (nextStale) "Feed paused — stale price warning active" else "Stream healthy — live demo feed restored",
            feedbackIsError = nextStale,
        )
    }

    fun applyWorkspacePreset(preset: WorkspacePreset) {
        _prefs.value = _prefs.value.copy(
            activeTab = preset.activeTab,
            marketMode = preset.marketMode,
            displayCurrency = preset.displayCurrency,
            isDarkTheme = preset.isDarkTheme,
            density = if (preset.isCompactDensity) TerminalDensity.COMPACT else TerminalDensity.STANDARD,
            feedbackMessage = "Loaded workspace: ${preset.name}",
            feedbackIsError = false,
        )
    }

    fun clearFeedback() {
        _prefs.value = _prefs.value.copy(feedbackMessage = null)
    }

    private fun postFeedback(msg: String, isError: Boolean = false) {
        _prefs.value = _prefs.value.copy(feedbackMessage = msg, feedbackIsError = isError)
    }

    // --- Trading & Workflow Actions ---
    fun placeSpotOrder(side: OrderSide, priceStr: String, qtyStr: String) {
        val prefs = _prefs.value
        if (prefs.isFeedStale) {
            postFeedback("Blocked: Market feed is stale. Reconnect stream before submitting orders.", true)
            return
        }
        val price = priceStr.toBigDecimalOrNull()
        val qty = qtyStr.toLongOrNull()
        if (price == null || qty == null) {
            postFeedback("Enter valid numeric price and quantity.", true)
            return
        }
        viewModelScope.launch {
            val res = repo.placeSpotLimitOrder(
                instrumentId = prefs.selectedInstrumentId,
                orgId = prefs.activeOrgId,
                role = prefs.activeRole,
                side = side,
                limitPrice = price,
                quantity = qty,
            )
            res.onSuccess { postFeedback(it, false) }
                .onFailure { postFeedback(it.message ?: "Order rejected", true) }
        }
    }

    fun cancelOrder(order: EngineOrder) {
        viewModelScope.launch {
            val res = repo.cancelSpotOrder(order, order.orgId, _prefs.value.activeRole)
            res.onSuccess { postFeedback(it, false) }
                .onFailure { postFeedback(it.message ?: "Cancel failed", true) }
        }
    }

    fun publishOffer(instrumentId: String, isFirm: Boolean, price: BigDecimal, qty: Long) {
        viewModelScope.launch {
            val res = repo.publishOffer(instrumentId, _prefs.value.activeOrgId, isFirm, price, qty, _prefs.value.activeRole)
            res.onSuccess { postFeedback("Published ${if (isFirm) "FIRM" else "INDICATIVE"} offer ${it.offerId} (${it.totalQty} cases)", false) }
                .onFailure { postFeedback(it.message ?: "Publish failed", true) }
        }
    }

    fun liftFirmOffer(offerId: String, qty: Long) {
        viewModelScope.launch {
            val res = repo.acceptFirmOfferPartial(offerId, _prefs.value.activeOrgId, qty, _prefs.value.activeRole)
            res.onSuccess { postFeedback(it, false) }
                .onFailure { postFeedback(it.message ?: "Purchase failed", true) }
        }
    }

    fun createRfq(instrumentId: String, qty: Long, targetPrice: BigDecimal?, period: String, dest: String) {
        viewModelScope.launch {
            val rfq = repo.createRfq(instrumentId, _prefs.value.activeOrgId, qty, targetPrice, period, dest)
            postFeedback("Submitted ${rfq.rfqId} with ${rfq.quotes.size} synthetic supplier quote(s).", false)
        }
    }

    fun convertRfqToForward(rfq: RfqRecord, quote: RfqQuote) {
        viewModelScope.launch {
            val fc = repo.createForwardFromRfq(rfq, quote, _prefs.value.activeRole)
            postFeedback("Created forward contract ${fc.contractId} (Awaiting dual-control approval).", false)
            selectTab(TerminalTab.CONTRACTS)
        }
    }

    fun approveForwardContract(contract: ForwardContract) {
        viewModelScope.launch {
            val res = repo.approveAndAcceptForward(contract, _prefs.value.activeRole)
            res.onSuccess { postFeedback("Contract ${it.contractId} approved & accepted (v${it.signedVersion}).", false) }
                .onFailure { postFeedback(it.message ?: "Approval blocked", true) }
        }
    }

    fun amendForwardContract(contract: ForwardContract, summary: String, newPrice: BigDecimal?, newQty: Long?) {
        viewModelScope.launch {
            val res = repo.proposeAndSignAmendment(contract, summary, newPrice, newQty, _prefs.value.activeRole)
            res.onSuccess { postFeedback("Amendment v${it.signedVersion} recorded on ${it.contractId} (${it.status.label}).", false) }
                .onFailure { postFeedback(it.message ?: "Amendment failed", true) }
        }
    }

    fun recordPartialDelivery(shipment: ShipmentRecord, deliverQty: Long, acceptQty: Long) {
        viewModelScope.launch {
            val res = repo.recordPartialDelivery(shipment, deliverQty, acceptQty, _prefs.value.activeRole)
            res.onSuccess { postFeedback("Updated ${it.shipmentId}: ${it.acceptedQty}/${it.orderedQty} accepted (${it.status.label}).", false) }
                .onFailure { postFeedback(it.message ?: "Delivery update failed", true) }
        }
    }

    fun reconcileInvoice(invoice: CommercialInvoice, payAmount: BigDecimal) {
        viewModelScope.launch {
            val res = repo.reconcileAndPayInvoice(invoice, payAmount, _prefs.value.activeRole)
            res.onSuccess { postFeedback("Invoice ${it.invoiceId} ${it.status.label} ($${it.paidAmount}/$${it.grossAmount}).", false) }
                .onFailure { postFeedback(it.message ?: "Reconciliation blocked", true) }
        }
    }

    fun openSimulatedFutures(contractCode: String, side: OrderSide, contracts: Int) {
        viewModelScope.launch {
            val res = repo.placeSimulatedFuturesOrder(contractCode, side, contracts)
            res.onSuccess { postFeedback(it, false) }
                .onFailure { postFeedback(it.message ?: "Futures sim order failed", true) }
        }
    }

    fun runDailySettlement(contractCode: String, newMarkPrice: BigDecimal) {
        viewModelScope.launch {
            val res = repo.runFuturesDailySettlement(contractCode, newMarkPrice, "2026-11-15")
            res.onSuccess {
                postFeedback("Settled $contractCode @ $${it.newSettlementPrice}; Variation Δ $${it.variationMarginDelta} (${it.status.label}).", false)
            }.onFailure { postFeedback(it.message ?: "Settlement failed", true) }
        }
    }

    fun triggerMarginStressScenario() {
        viewModelScope.launch {
            val (settle, red) = repo.runMarginStressAndInsufficientLiquidityDemo(_prefs.value.selectedFuturesCode)
            postFeedback(
                "Stress test: ${settle.status.label} | ${red.executedContractsClosed}/${red.requestedContractsToClose} closed | Shortfall $${red.residualMarginShortfall}",
                true,
            )
        }
    }

    fun toggleMarketSuspension(instrumentId: String, suspend: Boolean) {
        viewModelScope.launch {
            val res = repo.toggleMarketSuspension(instrumentId, suspend, _prefs.value.activeRole)
            res.onSuccess { postFeedback(it, suspend) }
                .onFailure { postFeedback(it.message ?: "Action denied", true) }
        }
    }

    fun toggleOrgHalt(orgId: String, halt: Boolean) {
        viewModelScope.launch {
            val res = repo.toggleOrgHalt(orgId, halt, _prefs.value.activeRole)
            res.onSuccess { postFeedback(it, halt) }
                .onFailure { postFeedback(it.message ?: "Action denied", true) }
        }
    }

    fun requestBankChange(orgId: String, newMask: String) {
        viewModelScope.launch {
            val res = repo.requestBankDetailChange(orgId, newMask, _prefs.value.activeRole)
            res.onSuccess { postFeedback(it, false) }
                .onFailure { postFeedback(it.message ?: "Bank change denied", true) }
        }
    }

    fun approveBankChange(orgId: String) {
        viewModelScope.launch {
            val res = repo.approveBankDetailChange(orgId, _prefs.value.activeRole)
            res.onSuccess { postFeedback(it, false) }
                .onFailure { postFeedback(it.message ?: "Approval denied", true) }
        }
    }

    fun acknowledgeAlert(alert: SurveillanceAlert) {
        viewModelScope.launch { repo.acknowledgeAlert(alert) }
    }

    fun replayEngineEvents() {
        viewModelScope.launch {
            val snap = repo.reconstructFromPersistedEvents()
            postFeedback("Restart/Recovery verified: Replayed ${snap.eventCount} committed events into ${snap.orders.size} orders & ${snap.trades.size} trades.", false)
        }
    }

    fun runComplete12StepDemo() {
        viewModelScope.launch {
            val steps = repo.runComplete12StepDemonstration()
            _demoSteps.value = steps
            postFeedback("Executed all 12 E2E demonstration steps & persisted transactions.", false)
        }
    }

    fun resetDemo() {
        viewModelScope.launch {
            repo.resetAllDemoData()
            _demoSteps.value = emptyList()
            postFeedback("Reset synthetic market data & re-seeded matching engine.", false)
        }
    }

    // --- Section 16: Firebase AI Logic Trade Assistant ---
    fun setAiSheetOpen(open: Boolean) {
        _prefs.value = _prefs.value.copy(isAiSheetOpen = open)
    }

    fun askAiAssistant(prompt: String) {
        val blocked = AiAssistantGuardrail.checkRestrictedMutation(prompt)
        if (blocked != null) {
            _aiState.value = AiUiState.BlockedByGuardrail(blocked)
            return
        }
        val state = uiState.value
        val selectedInst = state.selectedInstrument ?: return
        val (snapshot, citedIds) = AiAssistantGuardrail.buildDeterministicContextSnapshot(
            selectedInstrument = selectedInst,
            allInstruments = state.instruments,
            offers = state.offers,
            contracts = state.contracts,
            curve = state.forwardCurve(),
            futuresSpec = state.selectedFuturesSpec,
            futuresPos = state.futuresPositions.firstOrNull { it.contractCode == state.selectedFuturesCode },
            collateral = state.collateral,
            procurementRows = state.procurementRows,
        )

        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            var lastText = ""
            try {
                aiService.streamAnalysis(prompt, snapshot).collect { partial ->
                    lastText = partial
                    _aiState.value = AiUiState.Streaming(partial, citedIds)
                }
                _aiState.value = AiUiState.Success(lastText, citedIds)
            } catch (e: TimeoutCancellationException) {
                _aiState.value = AiUiState.Error("AI request timed out after 60s. Please retry.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "Firebase AI Logic request failed.")
            }
        }
    }
}
