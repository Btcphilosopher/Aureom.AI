package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TerminalDao {
    // Engine Events (Replayable Event Sourcing)
    @Query("SELECT * FROM engine_events ORDER BY id ASC")
    suspend fun getAllEngineEvents(): List<EngineEventEntity>

    @Query("SELECT * FROM engine_events ORDER BY id DESC LIMIT 100")
    fun observeRecentEngineEvents(): Flow<List<EngineEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEngineEvents(events: List<EngineEventEntity>)

    // Inventory
    @Query("SELECT * FROM inventory_batches ORDER BY warehouseName ASC, productName ASC")
    fun observeInventory(): Flow<List<InventoryBatchEntity>>

    @Query("SELECT * FROM inventory_batches")
    suspend fun getAllInventory(): List<InventoryBatchEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInventory(batch: InventoryBatchEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInventories(batches: List<InventoryBatchEntity>)

    // Firm & Indicative Offers
    @Query("SELECT * FROM firm_offers ORDER BY createdAtMs DESC")
    fun observeOffers(): Flow<List<FirmOfferEntity>>

    @Query("SELECT * FROM firm_offers WHERE offerId = :offerId")
    suspend fun getOfferById(offerId: String): FirmOfferEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOffer(offer: FirmOfferEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOffers(offers: List<FirmOfferEntity>)

    // RFQs
    @Query("SELECT * FROM rfqs ORDER BY createdAtMs DESC")
    fun observeRfqs(): Flow<List<RfqEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRfq(rfq: RfqEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRfqs(rfqs: List<RfqEntity>)

    // Forward Contracts
    @Query("SELECT * FROM forward_contracts ORDER BY createdAtMs DESC")
    fun observeContracts(): Flow<List<ForwardContractEntity>>

    @Query("SELECT * FROM forward_contracts")
    suspend fun getAllContracts(): List<ForwardContractEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContract(contract: ForwardContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContracts(contracts: List<ForwardContractEntity>)

    // Shipments
    @Query("SELECT * FROM shipments ORDER BY lastEventMs DESC")
    fun observeShipments(): Flow<List<ShipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertShipment(shipment: ShipmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertShipments(shipments: List<ShipmentEntity>)

    // Invoices
    @Query("SELECT * FROM invoices ORDER BY issuedAtMs DESC")
    fun observeInvoices(): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvoice(invoice: InvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInvoices(invoices: List<InvoiceEntity>)

    // Futures Positions & Collateral
    @Query("SELECT * FROM futures_positions")
    fun observeFuturesPositions(): Flow<List<FuturesPositionEntity>>

    @Query("SELECT * FROM futures_positions")
    suspend fun getAllFuturesPositions(): List<FuturesPositionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFuturesPosition(position: FuturesPositionEntity)

    @Query("SELECT * FROM collateral_ledger LIMIT 1")
    fun observeCollateral(): Flow<CollateralAccountEntity?>

    @Query("SELECT * FROM collateral_ledger LIMIT 1")
    suspend fun getCollateral(): CollateralAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCollateral(account: CollateralAccountEntity)

    // Surveillance Alerts & Audit Logs
    @Query("SELECT * FROM surveillance_alerts ORDER BY timestampMs DESC")
    fun observeAlerts(): Flow<List<SurveillanceAlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlert(alert: SurveillanceAlertEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlerts(alerts: List<SurveillanceAlertEntity>)

    @Query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 120")
    fun observeAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    // Workspace Prefs
    @Query("SELECT * FROM workspace_prefs")
    suspend fun getPrefs(): List<WorkspacePrefEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPref(pref: WorkspacePrefEntity)

    @Query("DELETE FROM engine_events")
    suspend fun clearEngineEvents()

    @Query("DELETE FROM inventory_batches")
    suspend fun clearInventory()

    @Query("DELETE FROM firm_offers")
    suspend fun clearOffers()

    @Query("DELETE FROM rfqs")
    suspend fun clearRfqs()

    @Query("DELETE FROM forward_contracts")
    suspend fun clearContracts()

    @Query("DELETE FROM shipments")
    suspend fun clearShipments()

    @Query("DELETE FROM invoices")
    suspend fun clearInvoices()

    @Query("DELETE FROM futures_positions")
    suspend fun clearFuturesPositions()

    @Query("DELETE FROM collateral_ledger")
    suspend fun clearCollateral()

    @Query("DELETE FROM surveillance_alerts")
    suspend fun clearAlerts()
}
