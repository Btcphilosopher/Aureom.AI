package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BookLevel
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DecimalMath
import com.example.domain.model.EngineOrder
import com.example.domain.model.ForwardContractStatus
import com.example.domain.model.MarketMode
import com.example.domain.model.OrderSide
import com.example.domain.model.OrderStatus
import com.example.domain.model.PhysicalInstrument
import com.example.ui.TerminalUiState
import com.example.ui.TerminalViewModel
import com.example.ui.components.DeliveryCurveChart
import com.example.ui.components.PriceVolumeChart
import com.example.ui.components.ProductVisualBadge
import com.example.ui.components.TerminalPanel
import com.example.ui.theme.LocalAureomPalette
import com.example.ui.theme.MonoTabularStyle
import java.math.BigDecimal

@Composable
fun TradeWorkspaceScreen(
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val selected = state.selectedInstrument ?: return
    val bids = state.engineSnapshot.bidsByInstrument[selected.id].orEmpty()
    val asks = state.engineSnapshot.asksByInstrument[selected.id].orEmpty()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp)
    ) {
        val isWide = maxWidth >= 900.dp

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (isWide) {
                // 3-Column Desktop Trading Workstation matching Aureom Trade mockup
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    // Left column: Market Watch + Product Specification
                    Column(
                        modifier = Modifier.weight(0.27f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        MarketWatchPanel(state, vm)
                        ProductSpecPanel(selected, state.displayCurrency, state)
                    }

                    // Center column: Main Chart + (Bids/Offers & Delivery Curve)
                    Column(
                        modifier = Modifier.weight(0.46f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        MainPriceChartPanel(selected, state, vm)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            BidsOffersLadderPanel(
                                bids = bids,
                                asks = asks,
                                currency = selected.currency,
                                modifier = Modifier.weight(1f),
                            )
                            DeliveryCurvePanel(
                                state = state,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }

                    // Right column: Order Ticket + Account & Risk + Simulated Futures
                    Column(
                        modifier = Modifier.weight(0.27f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        OrderTicketPanel(selected, state, vm)
                        AccountAndRiskPanel(state, vm)
                        SimulatedFuturesCard(state, vm)
                    }
                }
            } else {
                // Compact Mobile/Handheld Workstation with quick section jump pills
                var mobileSection by remember { mutableStateOf(0) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    listOf("All Panels", "Watchlist", "Chart & Book", "Order Ticket", "Risk & Futures").forEachIndexed { idx, lbl ->
                        val active = mobileSection == idx
                        Surface(
                            color = if (active) LocalAureomPalette.current.accentContainer else LocalAureomPalette.current.panelBg,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (active) LocalAureomPalette.current.accent else LocalAureomPalette.current.border),
                            modifier = Modifier.clickable { mobileSection = idx },
                        ) {
                            Text(
                                text = lbl,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (active) LocalAureomPalette.current.accent else LocalAureomPalette.current.textSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            )
                        }
                    }
                }

                if (mobileSection == 0 || mobileSection == 2) {
                    MainPriceChartPanel(selected, state, vm)
                    BidsOffersLadderPanel(bids, asks, selected.currency)
                    DeliveryCurvePanel(state)
                }
                if (mobileSection == 0 || mobileSection == 3) {
                    OrderTicketPanel(selected, state, vm)
                }
                if (mobileSection == 0 || mobileSection == 1) {
                    MarketWatchPanel(state, vm)
                    ProductSpecPanel(selected, state.displayCurrency, state)
                }
                if (mobileSection == 0 || mobileSection == 4) {
                    AccountAndRiskPanel(state, vm)
                    SimulatedFuturesCard(state, vm)
                }
            }

            // Bottom Blotter spanning full width
            BottomBlotterPanel(state, vm)
        }
    }
}

@Composable
private fun MarketWatchPanel(
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val palette = LocalAureomPalette.current
    val filtered = state.instruments.filter { inst ->
        state.searchQuery.isBlank() ||
            inst.productName.contains(state.searchQuery, ignoreCase = true) ||
            inst.brand.contains(state.searchQuery, ignoreCase = true) ||
            inst.skuOrSpec.contains(state.searchQuery, ignoreCase = true) ||
            inst.deliveryLocation.contains(state.searchQuery, ignoreCase = true)
    }

    TerminalPanel(title = "Market Watch") {
        // Table Header
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
            Text("Product", style = MaterialTheme.typography.labelMedium, color = palette.textMuted, modifier = Modifier.weight(1.3f))
            Text("Bid (${state.displayCurrency.displayLabel})", style = MaterialTheme.typography.labelMedium, color = palette.textMuted, modifier = Modifier.weight(0.8f))
            Text("Ask (${state.displayCurrency.displayLabel})", style = MaterialTheme.typography.labelMedium, color = palette.textMuted, modifier = Modifier.weight(0.8f))
            Text("Change", style = MaterialTheme.typography.labelMedium, color = palette.textMuted, modifier = Modifier.weight(0.75f))
        }
        HorizontalDivider(color = palette.border)

        filtered.forEach { inst ->
            val selected = inst.id == state.selectedInstrumentId
            val bestBid = state.engineSnapshot.bidsByInstrument[inst.id]?.firstOrNull()?.price
                ?: inst.referenceSpotPrice.subtract(BigDecimal("0.20"))
            val bestAsk = state.engineSnapshot.asksByInstrument[inst.id]?.firstOrNull()?.price
                ?: inst.referenceSpotPrice

            val dispBid = DecimalMath.convertDisplayOnly(bestBid, inst.currency, state.displayCurrency, state.fxRates)
            val dispAsk = DecimalMath.convertDisplayOnly(bestAsk, inst.currency, state.displayCurrency, state.fxRates)
            val pct = inst.dailyChangePct
            val isPos = pct >= BigDecimal.ZERO

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (selected) palette.accentContainer else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable { vm.selectInstrument(inst.id) }
                    .padding(vertical = 7.dp, horizontal = 4.dp)
                    .testTag("watchlist_row_${inst.id}"),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = inst.productName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal),
                        color = palette.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (inst.isSuspended) {
                        Text("HALTED", style = MaterialTheme.typography.labelSmall, color = palette.warning)
                    }
                }
                Text(
                    text = dispBid.toPlainString(),
                    style = MonoTabularStyle.copy(fontSize = 12.sp),
                    color = palette.positive,
                    modifier = Modifier.weight(0.8f),
                )
                Text(
                    text = dispAsk.toPlainString(),
                    style = MonoTabularStyle.copy(fontSize = 12.sp),
                    color = palette.negative,
                    modifier = Modifier.weight(0.8f),
                )
                Text(
                    text = DecimalMath.formatPercent(pct),
                    style = MonoTabularStyle.copy(fontSize = 12.sp, fontWeight = FontWeight.Medium),
                    color = if (isPos) palette.positive else palette.negative,
                    modifier = Modifier.weight(0.75f),
                )
            }
            HorizontalDivider(color = palette.border.copy(alpha = 0.5f))
        }
    }
}

@Composable
private fun ProductSpecPanel(
    inst: PhysicalInstrument,
    displayCurrency: CurrencyCode,
    state: TerminalUiState,
) {
    val palette = LocalAureomPalette.current
    val eqUnit = inst.packaging.equivalentUnitPrice(inst.referenceSpotPrice)
    TerminalPanel(title = "Product Specification") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProductVisualBadge(
                category = inst.category,
                modifier = Modifier.size(72.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "${inst.productName} • ${inst.packaging.description}",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                )
                Text(
                    text = "${inst.brand} (${inst.skuOrSpec})",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.accent,
                )
                Text(
                    text = "${inst.dispatchLocation} • ${inst.termAndPlace}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
                Text(
                    text = "Minimum ${inst.minOrderQty} ${inst.quantityBasis} • Lot ${inst.lotSize}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
                Text(
                    text = "Dispatch: ${inst.dispatchLeadDays} • Shelf life: ${inst.minRemainingShelfLifeMonths}+ months",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = palette.border)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Grade: ${inst.grade} | Origin: ${inst.originCountry} | HS ${inst.hsCode}",
            style = MaterialTheme.typography.bodySmall,
            color = palette.textSecondary,
        )
        Text(
            text = "Unit eq: ${DecimalMath.formatCurrency(eqUnit, inst.currency)} / ${inst.packaging.unitMeasureLabel} | Tax: ${inst.taxTreatment}",
            style = MonoTabularStyle.copy(fontSize = 11.sp),
            color = palette.textMuted,
        )
        if (displayCurrency != inst.currency) {
            val converted = DecimalMath.convertDisplayOnly(inst.referenceSpotPrice, inst.currency, displayCurrency, state.fxRates)
            Text(
                text = "Display est: ${DecimalMath.formatCurrency(converted, displayCurrency)}/case (Contract settles in ${inst.currency.displayLabel})",
                style = MaterialTheme.typography.bodySmall,
                color = palette.warning,
            )
        }
    }
}

@Composable
private fun MainPriceChartPanel(
    inst: PhysicalInstrument,
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val palette = LocalAureomPalette.current
    val chg = inst.dailyChange
    val pct = inst.dailyChangePct
    val isPos = chg >= BigDecimal.ZERO

    TerminalPanel(
        title = "${inst.productName} / ${inst.deliveryLocation.substringAfterLast(", ").uppercase()} ${state.marketMode.badge}",
        trailing = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("1D", "1W", "1M", "3M").forEach { r ->
                    val active = state.chartRange == r
                    Surface(
                        color = if (active) palette.accent else palette.panelElevated,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.clickable { vm.setChartRange(r) },
                    ) {
                        Text(
                            text = r,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (active) palette.onAccent else palette.textSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
            }
        }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "${DecimalMath.formatCurrency(inst.referenceSpotPrice, inst.currency)} / case",
                style = MaterialTheme.typography.displaySmall,
                color = palette.textPrimary,
            )
            Surface(
                color = if (isPos) palette.positiveBg else palette.negativeBg,
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, if (isPos) palette.positive else palette.negative),
            ) {
                Text(
                    text = "${DecimalMath.formatCurrency(chg, inst.currency, showSign = true)} (${DecimalMath.formatPercent(pct)})",
                    style = MonoTabularStyle.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
                    color = if (isPos) palette.positive else palette.negative,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        PriceVolumeChart(points = state.priceHistory())
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = "Source: ${inst.quoteSource.label} • ${inst.termAndPlace} • ${inst.grade}",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textMuted,
            )
            if (inst.isSuspended) {
                Text(
                    text = "MARKET SUSPENDED",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.warning,
                )
            }
        }
    }
}

@Composable
private fun BidsOffersLadderPanel(
    bids: List<BookLevel>,
    asks: List<BookLevel>,
    currency: CurrencyCode,
    modifier: Modifier = Modifier,
) {
    val palette = LocalAureomPalette.current
    TerminalPanel(title = "Bids / Offers", modifier = modifier) {
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
            Text("Bid size", style = MaterialTheme.typography.labelSmall, color = palette.textMuted, modifier = Modifier.weight(1f))
            Text("Bid (${currency.displayLabel})", style = MaterialTheme.typography.labelSmall, color = palette.textMuted, modifier = Modifier.weight(1f))
            Text("Ask (${currency.displayLabel})", style = MaterialTheme.typography.labelSmall, color = palette.textMuted, modifier = Modifier.weight(1f))
            Text("Ask size", style = MaterialTheme.typography.labelSmall, color = palette.textMuted, modifier = Modifier.weight(1f))
        }
        HorizontalDivider(color = palette.border)
        val rows = maxOf(bids.size, asks.size, 5)
        for (i in 0 until rows) {
            val bid = bids.getOrNull(i)
            val ask = asks.getOrNull(i)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = bid?.let { DecimalMath.formatQty(it.quantity) } ?: "—",
                    style = MonoTabularStyle.copy(fontSize = 11.sp),
                    color = palette.textPrimary,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = bid?.price?.toPlainString() ?: "—",
                    style = MonoTabularStyle.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                    color = palette.positive,
                    modifier = Modifier.weight(1f).background(palette.positiveBg).padding(horizontal = 4.dp, vertical = 2.dp),
                )
                Text(
                    text = ask?.price?.toPlainString() ?: "—",
                    style = MonoTabularStyle.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                    color = palette.negative,
                    modifier = Modifier.weight(1f).background(palette.negativeBg).padding(horizontal = 4.dp, vertical = 2.dp),
                )
                Text(
                    text = ask?.let { DecimalMath.formatQty(it.quantity) } ?: "—",
                    style = MonoTabularStyle.copy(fontSize = 11.sp),
                    color = palette.textPrimary,
                    modifier = Modifier.weight(1f).padding(start = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun DeliveryCurvePanel(
    state: TerminalUiState,
    modifier: Modifier = Modifier,
) {
    val palette = LocalAureomPalette.current
    val curve = state.forwardCurve()
    TerminalPanel(title = "Delivery Curve", modifier = modifier) {
        Text(
            text = "Indicative forward offers • ${state.selectedInstrument?.currency?.displayLabel ?: "USD"}/case",
            style = MaterialTheme.typography.bodySmall,
            color = palette.textSecondary,
        )
        Spacer(modifier = Modifier.height(4.dp))
        DeliveryCurveChart(curve = curve)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Assumptions: financing + storage/insurance + shelf-life decay (cost-of-carry ≠ all branded CPG SKUs).",
            style = MaterialTheme.typography.bodySmall,
            color = palette.textMuted,
        )
    }
}

@Composable
private fun OrderTicketPanel(
    inst: PhysicalInstrument,
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val palette = LocalAureomPalette.current
    var side by remember { mutableStateOf(OrderSide.BUY) }
    var qtyInput by remember(inst.id) { mutableStateOf(inst.minOrderQty.toString()) }
    var priceInput by remember(inst.id) { mutableStateOf(inst.referenceSpotPrice.toPlainString()) }
    var showReviewDialog by remember { mutableStateOf(false) }

    val qtyLong = qtyInput.toLongOrNull() ?: 0L
    val priceBd = priceInput.toBigDecimalOrNull() ?: BigDecimal.ZERO
    val totalNotional = priceBd.multiply(BigDecimal.valueOf(qtyLong))
    val pallets = inst.packaging.casesToPallets(qtyLong)

    TerminalPanel(
        title = "Order Ticket",
        trailing = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OrderSide.entries.forEach { s ->
                    val active = side == s
                    Surface(
                        color = when {
                            active && s == OrderSide.BUY -> palette.accent
                            active && s == OrderSide.SELL -> palette.negative
                            else -> palette.panelElevated
                        },
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .clickable { side = s }
                            .testTag("order_side_${s.name.lowercase()}"),
                    ) {
                        Text(
                            text = s.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (active) palette.onAccent else palette.textSecondary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        )
                    }
                }
            }
        }
    ) {
        if (state.marketMode == MarketMode.FUTURES_SIMULATION) {
            Surface(
                color = palette.warningBg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, palette.warning),
            ) {
                Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = palette.warning, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Live futures disabled. Switch to Risk tab for isolated Futures Simulation orders.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.warning,
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        TicketFieldRow("Product", "${inst.productName} (${inst.skuOrSpec})")
        TicketFieldRow("Market", state.marketMode.label)
        TicketFieldRow("Account", "${state.activeOrg?.name ?: "Desk"} (${state.activeRole.label})")
        TicketFieldRow("Destination", inst.deliveryLocation)
        TicketFieldRow("Trade terms", inst.termAndPlace)

        Spacer(modifier = Modifier.height(6.dp))
        TicketEditableField(
            label = "Quantity (${inst.quantityBasis})",
            value = qtyInput,
            onValueChange = { qtyInput = it.filter { ch -> ch.isDigit() } },
            suffix = "${pallets} plts",
            testTag = "order_qty_input",
        )
        Spacer(modifier = Modifier.height(6.dp))
        TicketEditableField(
            label = "Limit price (${inst.currency.displayLabel}/case)",
            value = priceInput,
            onValueChange = { priceInput = it },
            suffix = "Tick ${inst.tickSize}",
            testTag = "order_price_input",
        )

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = palette.border)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("Total goods value", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                Text("Taxes shown at confirmation", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
            }
            Text(
                text = DecimalMath.formatCurrency(totalNotional, inst.currency),
                style = MonoTabularStyle.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold),
                color = palette.textPrimary,
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { showReviewDialog = true },
            enabled = !inst.isSuspended && !state.isFeedStale && state.marketMode != MarketMode.FUTURES_SIMULATION,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (side == OrderSide.BUY) palette.accent else palette.negative,
                contentColor = palette.onAccent,
            ),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("review_order_button"),
        ) {
            Text(
                text = "Review ${side.label.lowercase()} order ->",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            )
        }
    }

    if (showReviewDialog) {
        val taxEst = totalNotional.multiply(BigDecimal("0.20"))
        AlertDialog(
            onDismissRequest = { showReviewDialog = false },
            containerColor = palette.panelElevated,
            title = {
                Text("Confirm ${side.label} Limit Order", color = palette.textPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${inst.productName} (${inst.skuOrSpec})", color = palette.accent, style = MaterialTheme.typography.bodyMedium)
                    Text("Quantity: $qtyLong cases ($pallets pallets)", color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                    Text("Limit Price: ${DecimalMath.formatCurrency(priceBd, inst.currency)} / case", color = palette.textPrimary, style = MaterialTheme.typography.bodySmall)
                    Text("Commercial Terms: ${inst.termAndPlace} • ${inst.deliveryPeriod}", color = palette.textSecondary, style = MaterialTheme.typography.bodySmall)
                    Text("Goods Value: ${DecimalMath.formatCurrency(totalNotional, inst.currency)}", color = palette.textPrimary, style = MonoTabularStyle.copy(fontSize = 12.sp))
                    Text("Est. Tax (${inst.taxTreatment}): ${DecimalMath.formatCurrency(taxEst, inst.currency)}", color = palette.textSecondary, style = MonoTabularStyle.copy(fontSize = 11.sp))
                    Text("Note: Matching commits a commercial trade record; physical shipment & payment settle separately.", color = palette.textMuted, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showReviewDialog = false
                        vm.placeSpotOrder(side, priceInput, qtyInput)
                    },
                    modifier = Modifier.testTag("confirm_submit_order_button"),
                ) {
                    Text("Submit to Matching Engine")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showReviewDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun TicketFieldRow(label: String, value: String) {
    val palette = LocalAureomPalette.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
        Text(value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium), color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TicketEditableField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    suffix: String,
    testTag: String,
) {
    val palette = LocalAureomPalette.current
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
        Spacer(modifier = Modifier.height(3.dp))
        Surface(
            color = palette.panelElevated,
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, palette.border),
            modifier = Modifier.fillMaxWidth().height(40.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    textStyle = MonoTabularStyle.copy(fontSize = 13.sp, color = palette.textPrimary, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(palette.accent),
                    modifier = Modifier.weight(1f).testTag(testTag),
                )
                Text(suffix, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
            }
        }
    }
}

@Composable
private fun AccountAndRiskPanel(
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val palette = LocalAureomPalette.current
    val org = state.activeOrg
    val physicalCommitments = state.contracts
        .filter { it.status != ForwardContractStatus.CANCELLED }
        .fold(BigDecimal.ZERO) { acc, c -> acc.add(c.totalValue) }
    val pendingApprovals = state.contracts.count { it.status == ForwardContractStatus.PENDING_APPROVAL }

    TerminalPanel(title = "Account & Risk") {
        TicketFieldRow("Available credit", org?.let { DecimalMath.formatCurrency(it.availableCreditUsd, CurrencyCode.USD) } ?: "$0.00")
        TicketFieldRow("Physical commitments", DecimalMath.formatCurrency(physicalCommitments, CurrencyCode.USD))
        TicketFieldRow("Simulation collateral", DecimalMath.formatCurrency(state.collateral.cashCollateralPosted, CurrencyCode.USD))

        if (pendingApprovals > 0) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = palette.warningBg,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, palette.warning),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.selectTab(com.example.domain.model.TerminalTab.CONTRACTS) },
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = palette.warning, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$pendingApprovals forward contract awaiting approval",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        color = palette.warning,
                    )
                }
            }
        }
    }
}

@Composable
private fun SimulatedFuturesCard(
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val palette = LocalAureomPalette.current
    val spec = state.selectedFuturesSpec ?: return
    val pos = state.futuresPositions.firstOrNull { it.contractCode == spec.contractCode }
    val unrealised = pos?.unrealisedVariationPnL(spec.currentMarkPrice, spec.contractMultiplier) ?: BigDecimal.ZERO
    val marginUsed = if (pos != null) {
        spec.initialMarginPerContract.multiply(BigDecimal.valueOf(kotlin.math.abs(pos.netContracts).toLong()))
    } else BigDecimal.ZERO

    TerminalPanel(
        title = "Simulated Futures",
        trailing = {
            Surface(
                color = palette.accentContainer,
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, palette.accent),
            ) {
                Text(
                    text = "SIM",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.accent,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
    ) {
        Text(
            text = spec.displayTitle,
            style = MaterialTheme.typography.titleMedium,
            color = palette.accent,
        )
        Spacer(modifier = Modifier.height(6.dp))
        TicketFieldRow(
            "Position",
            when {
                pos == null || pos.netContracts == 0 -> "Flat (0 contracts)"
                pos.netContracts > 0 -> "Long ${pos.netContracts} contracts"
                else -> "Short ${kotlin.math.abs(pos.netContracts)} contracts"
            }
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("P&L (Variation)", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
            Text(
                text = DecimalMath.formatCurrency(unrealised, CurrencyCode.USD, showSign = true),
                style = MonoTabularStyle.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
                color = if (unrealised >= BigDecimal.ZERO) palette.positive else palette.negative,
            )
        }
        TicketFieldRow("Margin (Illustrative)", DecimalMath.formatCurrency(marginUsed, CurrencyCode.USD))
        Spacer(modifier = Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = palette.textMuted, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Financial exposure ≠ physical delivery",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
        }
    }
}

@Composable
private fun BottomBlotterPanel(
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    val palette = LocalAureomPalette.current
    val openOrders = state.engineSnapshot.orders.filter {
        it.status == OrderStatus.WORKING || it.status == OrderStatus.PART_FILLED
    }
    val tabs = listOf(
        "Open orders (${openOrders.size})",
        "Trades (${state.engineSnapshot.trades.size})",
        "Physical commitments (${state.contracts.size})",
        "Futures simulation (${state.futuresPositions.size})",
    )

    TerminalPanel(title = "Execution & Position Blotter") {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            tabs.forEachIndexed { idx, label ->
                val active = state.blotterTabIndex == idx
                Surface(
                    color = if (active) palette.accentContainer else palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (active) palette.accent else palette.border),
                    modifier = Modifier
                        .clickable { vm.setBlotterTab(idx) }
                        .testTag("blotter_tab_$idx"),
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (active) palette.accent else palette.textSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        when (state.blotterTabIndex) {
            0 -> {
                if (openOrders.isEmpty()) {
                    Text("No active working orders.", style = MaterialTheme.typography.bodySmall, color = palette.textMuted)
                } else {
                    openOrders.take(10).forEach { ord ->
                        BlotterOrderRow(ord, onCancel = { vm.cancelOrder(ord) })
                        HorizontalDivider(color = palette.border.copy(alpha = 0.5f))
                    }
                }
            }
            1 -> {
                if (state.engineSnapshot.trades.isEmpty()) {
                    Text("No committed spot trades yet.", style = MaterialTheme.typography.bodySmall, color = palette.textMuted)
                } else {
                    state.engineSnapshot.trades.take(10).forEach { trd ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${trd.tradeId} • ${trd.productName}", style = MaterialTheme.typography.bodySmall, color = palette.textPrimary, modifier = Modifier.weight(1.4f))
                            Text("${trd.buyerOrgName.take(14)} <- ${trd.sellerOrgName.take(14)}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary, modifier = Modifier.weight(1.6f))
                            Text("${trd.quantity} @ ${DecimalMath.formatCurrency(trd.price, trd.currency)}", style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.positive, modifier = Modifier.weight(1f))
                        }
                        HorizontalDivider(color = palette.border.copy(alpha = 0.5f))
                    }
                }
            }
            2 -> {
                state.contracts.forEach { c ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.selectTab(com.example.domain.model.TerminalTab.CONTRACTS) }
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("${c.contractId} • ${c.productSpec}", style = MaterialTheme.typography.bodySmall, color = palette.textPrimary, modifier = Modifier.weight(1.6f))
                        Text("${c.acceptedQty}/${c.contractedQty} accepted", style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.textSecondary, modifier = Modifier.weight(1f))
                        Text(c.status.label, style = MaterialTheme.typography.labelSmall, color = palette.accent, modifier = Modifier.weight(0.8f))
                    }
                    HorizontalDivider(color = palette.border.copy(alpha = 0.5f))
                }
            }
            3 -> {
                state.futuresPositions.forEach { pos ->
                    val spec = state.futuresSpecs.firstOrNull { it.contractCode == pos.contractCode }
                    val pnl = if (spec != null) pos.unrealisedVariationPnL(spec.currentMarkPrice, spec.contractMultiplier) else BigDecimal.ZERO
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(pos.displayTitle, style = MaterialTheme.typography.bodySmall, color = palette.accent, modifier = Modifier.weight(1.3f))
                        Text("Net ${pos.netContracts} @ ${pos.avgEntryPrice}", style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.textPrimary, modifier = Modifier.weight(1f))
                        Text(DecimalMath.formatCurrency(pnl, CurrencyCode.USD, true), style = MonoTabularStyle.copy(fontSize = 11.sp), color = if (pnl >= BigDecimal.ZERO) palette.positive else palette.negative, modifier = Modifier.weight(0.8f))
                    }
                }
            }
        }
    }
}

@Composable
private fun BlotterOrderRow(
    order: EngineOrder,
    onCancel: () -> Unit,
) {
    val palette = LocalAureomPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(order.orderId, style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.textPrimary, modifier = Modifier.weight(0.8f))
        Text(order.instrumentId.substringBefore("-"), style = MaterialTheme.typography.bodySmall, color = palette.textPrimary, modifier = Modifier.weight(1f))
        Surface(
            color = if (order.side == OrderSide.BUY) palette.positiveBg else palette.negativeBg,
            shape = RoundedCornerShape(4.dp),
        ) {
            Text(
                text = order.side.label,
                style = MaterialTheme.typography.labelSmall,
                color = if (order.side == OrderSide.BUY) palette.positive else palette.negative,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        Text("${order.remainingQty}/${order.originalQty}", style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.textPrimary, modifier = Modifier.weight(0.8f))
        Text(DecimalMath.formatCurrency(order.limitPrice, order.currency), style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.textPrimary, modifier = Modifier.weight(0.7f))
        Text(order.status.label, style = MaterialTheme.typography.labelSmall, color = if (order.status == OrderStatus.PART_FILLED) palette.warning else palette.accent, modifier = Modifier.weight(0.8f))
        Surface(
            color = palette.panelElevated,
            shape = RoundedCornerShape(4.dp),
            border = BorderStroke(1.dp, palette.border),
            modifier = Modifier
                .clickable(onClick = onCancel)
                .testTag("cancel_order_${order.orderId}"),
        ) {
            Text("Cancel", style = MaterialTheme.typography.labelSmall, color = palette.negative, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
    }
}
