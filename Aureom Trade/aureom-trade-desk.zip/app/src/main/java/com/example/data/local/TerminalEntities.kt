package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "engine_events")
data class EngineEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val seq: Long,
    val clientCommandId: String,
    val instrumentId: String,
    val eventType: String,
    val payloadJson: String,
    val timestampMs: Long,
)

@Entity(tableName = "inventory_batches")
data class InventoryBatchEntity(
    @PrimaryKey val batchId: String,
    val warehouseId: String,
    val warehouseName: String,
    val ownerOrgId: String,
    val instrumentId: String,
    val skuOrSpec: String,
    val productName: String,
    val batchCode: String,
    val expiryDate: String,
    val remainingShelfLifeMonths: Int,
    val availableQty: Long,
    val reservedQty: Long,
    val quarantinedQty: Long,
    val expiredQty: Long,
    val inTransitQty: Long,
    val stockSource: String,
    val freshnessTimestampMs: Long,
    val certificateRef: String,
)

@Entity(tableName = "firm_offers")
data class FirmOfferEntity(
    @PrimaryKey val offerId: String,
    val instrumentId: String,
    val sellerOrgId: String,
    val sellerOrgName: String,
    val isFirm: Boolean,
    val unitPrice: String,
    val totalQty: Long,
    val remainingQty: Long,
    val reservedBatchId: String?,
    val currency: String,
    val location: String,
    val deliveryTerms: String,
    val expiresAtMs: Long,
    val status: String,
    val createdAtMs: Long,
)

@Entity(tableName = "rfqs")
data class RfqEntity(
    @PrimaryKey val rfqId: String,
    val requesterOrgId: String,
    val requesterOrgName: String,
    val instrumentId: String,
    val productName: String,
    val side: String,
    val targetQty: Long,
    val targetPrice: String?,
    val currency: String,
    val deliveryPeriod: String,
    val destination: String,
    val tradeTerm: String,
    val minShelfLifeMonths: Int,
    val status: String,
    val quotesJson: String,
    val createdAtMs: Long,
)

@Entity(tableName = "forward_contracts")
data class ForwardContractEntity(
    @PrimaryKey val contractId: String,
    val instrumentId: String,
    val productSpec: String,
    val buyerOrgId: String,
    val buyerOrgName: String,
    val sellerOrgId: String,
    val sellerOrgName: String,
    val contractedQty: Long,
    val tolerancePct: String,
    val pricingBasis: String,
    val fixedOrFormulaPrice: String,
    val currency: String,
    val deliveryWindowStart: String,
    val deliveryWindowEnd: String,
    val deliveryLocation: String,
    val tradeTerms: String,
    val paymentSchedule: String,
    val creditSupportTerms: String,
    val inspectionAndAcceptanceTerms: String,
    val shortDeliveryAndRejectionTerms: String,
    val cancellationAndDefaultTerms: String,
    val disputeResolutionTerms: String,
    val signedVersion: Int,
    val createdByRole: String,
    val approvedByRole: String?,
    val status: String,
    val allocatedQty: Long,
    val dispatchedQty: Long,
    val deliveredQty: Long,
    val acceptedQty: Long,
    val amendmentsJson: String,
    val createdAtMs: Long,
)

@Entity(tableName = "shipments")
data class ShipmentEntity(
    @PrimaryKey val shipmentId: String,
    val referenceId: String,
    val instrumentId: String,
    val productName: String,
    val warehouseName: String,
    val destination: String,
    val carrierName: String,
    val trackingNumber: String,
    val orderedQty: Long,
    val dispatchedQty: Long,
    val deliveredQty: Long,
    val acceptedQty: Long,
    val rejectedQty: Long,
    val status: String,
    val discrepancyReason: String?,
    val documentsJson: String,
    val lastEventMs: Long,
)

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val invoiceId: String,
    val referenceId: String,
    val shipmentId: String?,
    val counterpartyName: String,
    val invoicedQty: Long,
    val acceptedQty: Long,
    val unitPrice: String,
    val taxAmount: String,
    val grossAmount: String,
    val paidAmount: String,
    val settlementCurrency: String,
    val bankAccountMask: String,
    val status: String,
    val issuedAtMs: Long,
)

@Entity(tableName = "futures_positions")
data class FuturesPositionEntity(
    @PrimaryKey val positionId: String,
    val accountId: String,
    val contractCode: String,
    val displayTitle: String,
    val netContracts: Int,
    val closedContracts: Int,
    val avgEntryPrice: String,
    val settlementBasisPrice: String,
    val realisedPnL: String,
    val cumulativeVariationSettled: String,
    val tradingFeesPaid: String,
    val updatedAtMs: Long,
)

@Entity(tableName = "collateral_ledger")
data class CollateralAccountEntity(
    @PrimaryKey val accountId: String,
    val cashCollateralPosted: String,
    val realisedTradingPnL: String,
    val feesCharged: String,
    val currency: String,
    val lastSettlementDate: String,
)

@Entity(tableName = "surveillance_alerts")
data class SurveillanceAlertEntity(
    @PrimaryKey val alertId: String,
    val category: String,
    val severity: String,
    val title: String,
    val detail: String,
    val relatedRecordId: String,
    val acknowledged: Boolean,
    val timestampMs: Long,
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actorOrg: String,
    val actorRole: String,
    val action: String,
    val targetId: String,
    val detail: String,
    val timestampMs: Long,
)

@Entity(tableName = "workspace_prefs")
data class WorkspacePrefEntity(
    @PrimaryKey val prefKey: String,
    val prefValue: String,
)
