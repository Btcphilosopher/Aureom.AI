package com.example.domain.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class MarketMode(val label: String, val badge: String) {
    PHYSICAL_SPOT("Physical spot", "SPOT"),
    PHYSICAL_FORWARD("Forwards", "FWD"),
    FUTURES_SIMULATION("Futures simulation", "SIM"),
}

enum class ProductCategory(val tickerLabel: String, val displayName: String) {
    LAUNDRY("HOME CARE", "Laundry products"),
    PERSONAL_CARE("PERSONAL CARE", "Personal care"),
    PAPER("PAPER", "Paper products"),
    PACKAGED_FOOD("FOOD", "Packaged food"),
    COOKING_OILS("OILS", "Cooking oils"),
    HOUSEHOLD_CLEANING("CLEANING", "Household cleaning"),
}

enum class TradingApproach(val label: String) {
    BRANDED_SKU("Branded SKU"),
    GENERIC_SPEC("Generic Specification"),
}

enum class TradeTerm(
    val code: String,
    val includesMainFreight: Boolean,
    val includesInsurance: Boolean,
    val includesImportDuty: Boolean,
) {
    EXW("EXW", false, false, false),
    FCA("FCA", false, false, false),
    FOB("FOB", false, false, false),
    CIF("CIF", true, true, false),
    DAP("DAP", true, true, false),
    DDP("DDP", true, true, true),
}

enum class OrderSide(val label: String) {
    BUY("Buy"),
    SELL("Sell"),
}

enum class OrderStatus(val label: String) {
    WORKING("Working"),
    PART_FILLED("Part-filled"),
    FILLED("Filled"),
    CANCELLED("Cancelled"),
    EXPIRED("Expired"),
    REJECTED("Rejected"),
}

enum class PriceSourceType(val label: String) {
    COMMITTED_TRADE("Committed engine trade"),
    FIRM_OFFER("Firm executable offer"),
    INDICATIVE_QUOTE("Indicative quote (non-executable)"),
    MODEL_DERIVED("Model-derived estimate"),
}

data class PackagingSpec(
    val description: String, // e.g. "12 x 1 L"
    val unitsPerCase: Int,
    val unitMeasureValue: BigDecimal, // e.g. 1.0
    val unitMeasureLabel: String, // e.g. "L", "ml", "kg", "sheets"
    val casesPerPallet: Int,
) {
    val totalMeasurePerCase: BigDecimal
        get() = unitMeasureValue.multiply(BigDecimal.valueOf(unitsPerCase.toLong()))

    fun casesToUnits(cases: Long): Long = cases * unitsPerCase
    fun casesToPallets(cases: Long): BigDecimal =
        BigDecimal.valueOf(cases).divide(BigDecimal.valueOf(casesPerPallet.toLong()), 2, RoundingMode.HALF_EVEN)

    fun equivalentUnitPrice(casePrice: BigDecimal): BigDecimal =
        if (totalMeasurePerCase > BigDecimal.ZERO) {
            casePrice.divide(totalMeasurePerCase, 4, RoundingMode.HALF_EVEN)
        } else casePrice
}

data class PhysicalInstrument(
    val id: String,
    val productName: String,
    val brand: String,
    val skuOrSpec: String,
    val category: ProductCategory,
    val tradingApproach: TradingApproach,
    val grade: String,
    val permittedSubstitutions: String,
    val packaging: PackagingSpec,
    val quantityBasis: String, // e.g. "cases"
    val originCountry: String,
    val hsCode: String,
    val dispatchLocation: String,
    val deliveryLocation: String,
    val deliveryPeriod: String, // e.g. "Dec 2026"
    val currency: CurrencyCode,
    val tradeTerm: TradeTerm,
    val namedPlace: String,
    val minRemainingShelfLifeMonths: Int,
    val qualityDocsRequired: List<String>,
    val taxTreatment: String,
    val eligibleCounterparties: List<String>,
    val tickSize: BigDecimal,
    val lotSize: Long,
    val minOrderQty: Long,
    val priceCollarPct: BigDecimal,
    val referenceSpotPrice: BigDecimal,
    val previousClosePrice: BigDecimal,
    val isStandardisedOrderBook: Boolean,
    val isSuspended: Boolean = false,
    val dispatchLeadDays: String = "3-5 days",
    val quoteSource: PriceSourceType = PriceSourceType.COMMITTED_TRADE,
    val lastUpdatedMs: Long,
) {
    val dailyChange: BigDecimal
        get() = referenceSpotPrice.subtract(previousClosePrice)

    val dailyChangePct: BigDecimal
        get() = if (previousClosePrice > BigDecimal.ZERO) {
            dailyChange.multiply(BigDecimal.valueOf(100))
                .divide(previousClosePrice, 2, RoundingMode.HALF_EVEN)
        } else BigDecimal.ZERO

    val termAndPlace: String get() = "${tradeTerm.code} $namedPlace"
}

data class CompatibilityResult(
    val isFungible: Boolean,
    val mismatchReasons: List<String>,
)

object InstrumentCompatibility {
    /**
     * Never combines unlike products, locations, grades, shelf-life, or commercial terms into one executable quote.
     */
    fun checkFungibility(a: PhysicalInstrument, b: PhysicalInstrument): CompatibilityResult {
        val reasons = mutableListOf<String>()
        if (a.skuOrSpec != b.skuOrSpec) reasons += "SKU/Spec differs (${a.skuOrSpec} vs ${b.skuOrSpec})"
        if (a.grade != b.grade) reasons += "Grade differs (${a.grade} vs ${b.grade})"
        if (a.packaging.description != b.packaging.description) {
            reasons += "Packaging differs (${a.packaging.description} vs ${b.packaging.description})"
        }
        if (a.deliveryLocation != b.deliveryLocation) {
            reasons += "Location differs (${a.deliveryLocation} vs ${b.deliveryLocation})"
        }
        if (a.deliveryPeriod != b.deliveryPeriod) {
            reasons += "Delivery period differs (${a.deliveryPeriod} vs ${b.deliveryPeriod})"
        }
        if (a.tradeTerm != b.tradeTerm || a.namedPlace != b.namedPlace) {
            reasons += "Commercial term differs (${a.termAndPlace} vs ${b.termAndPlace})"
        }
        if (a.currency != b.currency) {
            reasons += "Settlement currency differs (${a.currency} vs ${b.currency})"
        }
        if (a.minRemainingShelfLifeMonths != b.minRemainingShelfLifeMonths) {
            reasons += "Min shelf life differs (${a.minRemainingShelfLifeMonths}m vs ${b.minRemainingShelfLifeMonths}m)"
        }
        return CompatibilityResult(isFungible = reasons.isEmpty(), mismatchReasons = reasons)
    }
}

data class BookLevel(
    val price: BigDecimal,
    val quantity: Long,
    val orderCount: Int,
)

data class EngineOrder(
    val orderId: String,
    val clientCommandId: String,
    val instrumentId: String,
    val orgId: String,
    val orgName: String,
    val traderRole: String,
    val side: OrderSide,
    val limitPrice: BigDecimal,
    val originalQty: Long,
    val filledQty: Long,
    val status: OrderStatus,
    val deliveryPeriod: String,
    val tradeTerm: String,
    val currency: CurrencyCode,
    val sequenceNumber: Long,
    val expiresAtMs: Long,
    val createdAtMs: Long,
    val updatedAtMs: Long,
) {
    val remainingQty: Long get() = (originalQty - filledQty).coerceAtLeast(0L)
}

data class SpotTradeRecord(
    val tradeId: String,
    val instrumentId: String,
    val productName: String,
    val buyOrderId: String,
    val sellOrderId: String,
    val buyerOrgId: String,
    val buyerOrgName: String,
    val sellerOrgId: String,
    val sellerOrgName: String,
    val price: BigDecimal,
    val quantity: Long,
    val currency: CurrencyCode,
    val tradeTerm: String,
    val deliveryLocation: String,
    val executionTimestampMs: Long,
    val sequenceNumber: Long,
    val fulfilmentNote: String = "Commercial trade committed; shipment & settlement pending",
) {
    val notionalValue: BigDecimal get() = price.multiply(BigDecimal.valueOf(quantity))
}

data class FirmOfferRecord(
    val offerId: String,
    val instrumentId: String,
    val sellerOrgId: String,
    val sellerOrgName: String,
    val isFirm: Boolean, // Firm reserves stock atomically; Indicative is non-binding
    val unitPrice: BigDecimal,
    val totalQty: Long,
    val remainingQty: Long,
    val reservedBatchId: String?,
    val currency: CurrencyCode,
    val location: String,
    val deliveryTerms: String,
    val expiresAtMs: Long,
    val status: String, // ACTIVE, PARTIALLY_TAKEN, FILLED, CANCELLED, EXPIRED
    val createdAtMs: Long,
)

enum class RfqStatus(val label: String) {
    OPEN("Open"),
    QUOTED("Quoted"),
    NEGOTIATING("Negotiating"),
    ACCEPTED("Accepted"),
    CONVERTED("Converted to Contract"),
    DECLINED("Declined"),
}

data class RfqQuote(
    val quoteId: String,
    val supplierOrgId: String,
    val supplierOrgName: String,
    val quotedPrice: BigDecimal,
    val availableQty: Long,
    val tradeTerm: String,
    val validUntilMs: Long,
    val notes: String,
)

data class RfqRecord(
    val rfqId: String,
    val requesterOrgId: String,
    val requesterOrgName: String,
    val instrumentId: String,
    val productName: String,
    val side: OrderSide,
    val targetQty: Long,
    val targetPrice: BigDecimal?,
    val currency: CurrencyCode,
    val deliveryPeriod: String,
    val destination: String,
    val tradeTerm: TradeTerm,
    val minShelfLifeMonths: Int,
    val status: RfqStatus,
    val quotes: List<RfqQuote>,
    val createdAtMs: Long,
)

enum class ForwardContractStatus(val label: String) {
    DRAFT("Draft"),
    PENDING_APPROVAL("Awaiting Approval"),
    APPROVED("Approved"),
    ACCEPTED("Accepted"),
    PARTIALLY_DELIVERED("Part-delivered"),
    COMPLETED("Completed"),
    AMENDMENT_PENDING("Amendment Pending"),
    DISPUTED("Disputed"),
    CANCELLED("Cancelled"),
}

data class ForwardAmendment(
    val amendmentId: String,
    val versionNumber: Int,
    val proposedByOrg: String,
    val summary: String,
    val newPrice: BigDecimal?,
    val newQty: Long?,
    val newDeliveryWindow: String?,
    val buyerApproved: Boolean,
    val sellerApproved: Boolean,
    val timestampMs: Long,
)

data class ForwardContract(
    val contractId: String,
    val instrumentId: String,
    val productSpec: String,
    val buyerOrgId: String,
    val buyerOrgName: String,
    val sellerOrgId: String,
    val sellerOrgName: String,
    val contractedQty: Long,
    val tolerancePct: BigDecimal,
    val pricingBasis: String, // "FIXED" or "INDEX_FORMULA"
    val fixedOrFormulaPrice: BigDecimal,
    val currency: CurrencyCode,
    val deliveryWindowStart: String,
    val deliveryWindowEnd: String,
    val deliveryLocation: String,
    val tradeTerms: String,
    val paymentSchedule: String,
    val creditSupportTerms: String,
    val inspectionAndAcceptanceTerms: String,
    val shortDeliveryAndRejectionTerms: String,
    val cancellationAndDefaultTerms: String,
    val disputeResolutionTerms: String,
    val signedVersion: Int,
    val createdByRole: String,
    val approvedByRole: String?,
    val status: ForwardContractStatus,
    val allocatedQty: Long,
    val dispatchedQty: Long,
    val deliveredQty: Long,
    val acceptedQty: Long,
    val amendments: List<ForwardAmendment>,
    val createdAtMs: Long,
) {
    val outstandingQty: Long get() = (contractedQty - acceptedQty).coerceAtLeast(0L)
    val totalValue: BigDecimal get() = fixedOrFormulaPrice.multiply(BigDecimal.valueOf(contractedQty))
}

data class InventoryBatch(
    val batchId: String,
    val warehouseId: String,
    val warehouseName: String,
    val ownerOrgId: String,
    val instrumentId: String,
    val skuOrSpec: String,
    val productName: String,
    val batchCode: String,
    val expiryDate: String,
    val remainingShelfLifeMonths: Int,
    val availableQty: Long,
    val reservedQty: Long,
    val quarantinedQty: Long,
    val expiredQty: Long,
    val inTransitQty: Long,
    val stockSource: String,
    val freshnessTimestampMs: Long,
    val certificateRef: String,
)

enum class ShipmentStatus(val label: String) {
    ALLOCATED("Allocated"),
    PICKED("Picked"),
    DISPATCHED("Dispatched"),
    IN_TRANSIT("In Transit"),
    PART_DELIVERED("Part-delivered"),
    DELIVERED("Delivered"),
    INSPECTED("Inspected"),
    ACCEPTED("Accepted"),
    DISCREPANCY("Discrepancy / Claim"),
    RETURNED("Returned"),
}

data class ProvenanceDocument(
    val docId: String,
    val docType: String, // "Commercial Invoice", "Packing List", "COA", "POD"
    val filename: String,
    val sha256Short: String,
    val uploadedByOrg: String,
    val uploadedAtMs: Long,
)

data class ShipmentRecord(
    val shipmentId: String,
    val referenceId: String, // Trade ID or Contract ID
    val instrumentId: String,
    val productName: String,
    val warehouseName: String,
    val destination: String,
    val carrierName: String,
    val trackingNumber: String,
    val orderedQty: Long,
    val dispatchedQty: Long,
    val deliveredQty: Long,
    val acceptedQty: Long,
    val rejectedQty: Long,
    val status: ShipmentStatus,
    val discrepancyReason: String?,
    val documents: List<ProvenanceDocument>,
    val lastEventMs: Long,
)

enum class InvoiceStatus(val label: String) {
    ISSUED("Issued"),
    PART_PAID("Part-paid"),
    RECONCILED("Reconciled"),
    DISCREPANCY_HOLD("Discrepancy Hold"),
}

data class CommercialInvoice(
    val invoiceId: String,
    val referenceId: String, // Trade or Contract ID
    val shipmentId: String?,
    val counterpartyName: String,
    val invoicedQty: Long,
    val acceptedQty: Long,
    val unitPrice: BigDecimal,
    val taxAmount: BigDecimal,
    val grossAmount: BigDecimal,
    val paidAmount: BigDecimal,
    val settlementCurrency: CurrencyCode,
    val bankAccountMask: String,
    val status: InvoiceStatus,
    val issuedAtMs: Long,
) {
    val balanceDue: BigDecimal get() = (grossAmount.subtract(paidAmount)).coerceAtLeast(BigDecimal.ZERO)
}

data class PricePoint(
    val label: String,
    val price: BigDecimal,
    val volume: Long,
    val source: PriceSourceType,
)

data class ForwardCurvePoint(
    val deliveryMonth: String,
    val price: BigDecimal,
    val basisVsSpot: BigDecimal,
    val financingCarryCost: BigDecimal,
    val storageInsuranceCost: BigDecimal,
    val shelfLifeRiskAdjustment: BigDecimal,
    val openQuoteCount: Int,
    val sourceLabel: String,
)
