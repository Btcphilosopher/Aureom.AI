package com.example.engine

import com.example.domain.model.BookLevel
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DecimalMath
import com.example.domain.model.EngineOrder
import com.example.domain.model.OrderSide
import com.example.domain.model.OrderStatus
import com.example.domain.model.PhysicalInstrument
import com.example.domain.model.SpotTradeRecord
import java.math.BigDecimal
import java.math.RoundingMode

sealed interface EngineCommand {
    val clientCommandId: String
    val instrumentId: String
    val timestampMs: Long

    data class PlaceLimitOrder(
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val orderId: String,
        val orgId: String,
        val orgName: String,
        val traderRole: String,
        val side: OrderSide,
        val limitPrice: BigDecimal,
        val quantity: Long,
        val expiresAtMs: Long,
    ) : EngineCommand

    data class CancelOrder(
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val orderId: String,
        val requestingOrgId: String,
    ) : EngineCommand

    data class SuspendMarket(
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val reason: String,
    ) : EngineCommand

    data class ResumeMarket(
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
    ) : EngineCommand

    data class ExpireOrders(
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
    ) : EngineCommand
}

sealed interface EngineEvent {
    val seq: Long
    val clientCommandId: String
    val instrumentId: String
    val timestampMs: Long

    data class OrderAccepted(
        override val seq: Long,
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val order: EngineOrder,
    ) : EngineEvent

    data class TradeExecuted(
        override val seq: Long,
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val trade: SpotTradeRecord,
    ) : EngineEvent

    data class OrderCancelled(
        override val seq: Long,
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val orderId: String,
        val releasedQty: Long,
    ) : EngineEvent

    data class OrderExpired(
        override val seq: Long,
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val orderId: String,
        val releasedQty: Long,
    ) : EngineEvent

    data class MarketStatusChanged(
        override val seq: Long,
        override val clientCommandId: String,
        override val instrumentId: String,
        override val timestampMs: Long,
        val suspended: Boolean,
        val reason: String,
    ) : EngineEvent
}

data class EngineCommandOutcome(
    val accepted: Boolean,
    val idempotentReplay: Boolean,
    val message: String,
    val events: List<EngineEvent>,
    val resultingOrder: EngineOrder? = null,
    val executedTrades: List<SpotTradeRecord> = emptyList(),
    val selfTradePrevented: Boolean = false,
)

/**
 * Deterministic single-partition matching engine.
 * - Price-time priority
 * - Idempotent command handling via clientCommandId cache
 * - Self-trade prevention (cancels/rejects incoming crossing order from same orgId)
 * - Price collars, tick size, lot size, minimum order quantity, market suspension
 * - Event-sourced so full order books and trades can be replayed identically on restart
 */
class MatchingPartition(
    private val instrument: PhysicalInstrument,
) {
    private var nextSequence: Long = 1L
    private var nextTradeCounter: Long = 2001L
    private var isSuspended: Boolean = instrument.isSuspended
    private var lastTradePrice: BigDecimal = instrument.referenceSpotPrice

    private val ordersById = linkedMapOf<String, EngineOrder>()
    private val trades = mutableListOf<SpotTradeRecord>()
    private val eventLog = mutableListOf<EngineEvent>()
    private val commandCache = hashMapOf<String, EngineCommandOutcome>()

    @Synchronized
    fun submit(command: EngineCommand): EngineCommandOutcome {
        commandCache[command.clientCommandId]?.let { cached ->
            return cached.copy(idempotentReplay = true)
        }

        val outcome = when (command) {
            is EngineCommand.PlaceLimitOrder -> handlePlaceOrder(command)
            is EngineCommand.CancelOrder -> handleCancelOrder(command)
            is EngineCommand.SuspendMarket -> handleSuspend(command)
            is EngineCommand.ResumeMarket -> handleResume(command)
            is EngineCommand.ExpireOrders -> handleExpireOrders(command)
        }

        commandCache[command.clientCommandId] = outcome
        return outcome
    }

    /**
     * Replays a persisted event directly without re-running validation, reconstructing identical state.
     */
    @Synchronized
    fun replayEvent(event: EngineEvent) {
        when (event) {
            is EngineEvent.OrderAccepted -> {
                ordersById[event.order.orderId] = event.order
                nextSequence = maxOf(nextSequence, event.seq + 1)
            }
            is EngineEvent.TradeExecuted -> {
                trades.add(event.trade)
                lastTradePrice = event.trade.price
                nextTradeCounter = maxOf(nextTradeCounter, event.seq + 1)
                ordersById[event.trade.buyOrderId]?.let { buy ->
                    val newFilled = buy.filledQty + event.trade.quantity
                    val newStatus = if (newFilled >= buy.originalQty) OrderStatus.FILLED else OrderStatus.PART_FILLED
                    ordersById[buy.orderId] = buy.copy(
                        filledQty = newFilled,
                        status = newStatus,
                        updatedAtMs = event.timestampMs,
                    )
                }
                ordersById[event.trade.sellOrderId]?.let { sell ->
                    val newFilled = sell.filledQty + event.trade.quantity
                    val newStatus = if (newFilled >= sell.originalQty) OrderStatus.FILLED else OrderStatus.PART_FILLED
                    ordersById[sell.orderId] = sell.copy(
                        filledQty = newFilled,
                        status = newStatus,
                        updatedAtMs = event.timestampMs,
                    )
                }
                nextSequence = maxOf(nextSequence, event.seq + 1)
            }
            is EngineEvent.OrderCancelled -> {
                ordersById[event.orderId]?.let { existing ->
                    if (existing.remainingQty > 0L) {
                        ordersById[existing.orderId] = existing.copy(
                            status = OrderStatus.CANCELLED,
                            updatedAtMs = event.timestampMs,
                        )
                    }
                }
                nextSequence = maxOf(nextSequence, event.seq + 1)
            }
            is EngineEvent.OrderExpired -> {
                ordersById[event.orderId]?.let { existing ->
                    if (existing.remainingQty > 0L) {
                        ordersById[existing.orderId] = existing.copy(
                            status = OrderStatus.EXPIRED,
                            updatedAtMs = event.timestampMs,
                        )
                    }
                }
                nextSequence = maxOf(nextSequence, event.seq + 1)
            }
            is EngineEvent.MarketStatusChanged -> {
                isSuspended = event.suspended
                nextSequence = maxOf(nextSequence, event.seq + 1)
            }
        }
        eventLog.add(event)
        // Also remember commandId so re-submitting after restart stays idempotent
        if (!commandCache.containsKey(event.clientCommandId)) {
            commandCache[event.clientCommandId] = EngineCommandOutcome(
                accepted = true,
                idempotentReplay = true,
                message = "Replayed from persisted event log",
                events = listOf(event),
            )
        }
    }

    private fun handlePlaceOrder(cmd: EngineCommand.PlaceLimitOrder): EngineCommandOutcome {
        if (isSuspended) {
            return reject("Market ${instrument.id} is currently suspended.")
        }
        if (cmd.quantity < instrument.minOrderQty) {
            return reject("Quantity ${cmd.quantity} is below minimum order quantity (${instrument.minOrderQty} ${instrument.quantityBasis}).")
        }
        if (!DecimalMath.isLotAligned(cmd.quantity, instrument.lotSize)) {
            return reject("Quantity ${cmd.quantity} must be a multiple of lot size (${instrument.lotSize}).")
        }
        if (cmd.limitPrice <= BigDecimal.ZERO || !DecimalMath.isTickAligned(cmd.limitPrice, instrument.tickSize)) {
            return reject("Limit price ${cmd.limitPrice} is not aligned to tick size ${instrument.tickSize}.")
        }
        val collarDelta = instrument.referenceSpotPrice
            .multiply(instrument.priceCollarPct)
            .divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_EVEN)
        val minAllowed = instrument.referenceSpotPrice.subtract(collarDelta)
        val maxAllowed = instrument.referenceSpotPrice.add(collarDelta)
        if (cmd.limitPrice < minAllowed || cmd.limitPrice > maxAllowed) {
            return reject(
                "Price ${cmd.limitPrice} breaches ±${instrument.priceCollarPct}% price collar " +
                    "[${minAllowed.setScale(2, RoundingMode.HALF_EVEN)} .. ${maxAllowed.setScale(2, RoundingMode.HALF_EVEN)}]."
            )
        }

        // Expire any timed-out resting orders deterministically before matching
        expireTimedOutResting(cmd.timestampMs, cmd.clientCommandId)

        // Check self-trade prevention before executing
        val restingCandidates = matchingRestingOrders(cmd.side, cmd.limitPrice)
        val selfCross = restingCandidates.firstOrNull { it.orgId == cmd.orgId }
        if (selfCross != null) {
            return EngineCommandOutcome(
                accepted = false,
                idempotentReplay = false,
                message = "Self-trade prevented: ${cmd.orgName} already rests opposite order ${selfCross.orderId} at ${selfCross.limitPrice}.",
                events = emptyList(),
                selfTradePrevented = true,
            )
        }

        val seq = nextSequence++
        var incoming = EngineOrder(
            orderId = cmd.orderId,
            clientCommandId = cmd.clientCommandId,
            instrumentId = instrument.id,
            orgId = cmd.orgId,
            orgName = cmd.orgName,
            traderRole = cmd.traderRole,
            side = cmd.side,
            limitPrice = cmd.limitPrice.setScale(instrument.currency.scale, RoundingMode.HALF_EVEN),
            originalQty = cmd.quantity,
            filledQty = 0L,
            status = OrderStatus.WORKING,
            deliveryPeriod = instrument.deliveryPeriod,
            tradeTerm = instrument.termAndPlace,
            currency = instrument.currency,
            sequenceNumber = seq,
            expiresAtMs = cmd.expiresAtMs,
            createdAtMs = cmd.timestampMs,
            updatedAtMs = cmd.timestampMs,
        )

        val emittedEvents = mutableListOf<EngineEvent>()
        val acceptedEvt = EngineEvent.OrderAccepted(
            seq = seq,
            clientCommandId = cmd.clientCommandId,
            instrumentId = instrument.id,
            timestampMs = cmd.timestampMs,
            order = incoming,
        )
        emittedEvents.add(acceptedEvt)
        eventLog.add(acceptedEvt)
        ordersById[incoming.orderId] = incoming

        val executedTrades = mutableListOf<SpotTradeRecord>()
        for (resting in restingCandidates) {
            if (incoming.remainingQty <= 0L) break
            val fillQty = minOf(incoming.remainingQty, resting.remainingQty)
            if (fillQty <= 0L) continue

            val tradeSeq = nextSequence++
            val tradePrice = resting.limitPrice // Resting maker price determines execution price
            val buyOrder = if (incoming.side == OrderSide.BUY) incoming else resting
            val sellOrder = if (incoming.side == OrderSide.SELL) incoming else resting

            val trade = SpotTradeRecord(
                tradeId = "TRD-${nextTradeCounter++}",
                instrumentId = instrument.id,
                productName = instrument.productName,
                buyOrderId = buyOrder.orderId,
                sellOrderId = sellOrder.orderId,
                buyerOrgId = buyOrder.orgId,
                buyerOrgName = buyOrder.orgName,
                sellerOrgId = sellOrder.orgId,
                sellerOrgName = sellOrder.orgName,
                price = tradePrice,
                quantity = fillQty,
                currency = instrument.currency,
                tradeTerm = instrument.termAndPlace,
                deliveryLocation = instrument.deliveryLocation,
                executionTimestampMs = cmd.timestampMs,
                sequenceNumber = tradeSeq,
            )

            // Update resting order
            val restingNewFilled = resting.filledQty + fillQty
            val restingNewStatus = if (restingNewFilled >= resting.originalQty) OrderStatus.FILLED else OrderStatus.PART_FILLED
            ordersById[resting.orderId] = resting.copy(
                filledQty = restingNewFilled,
                status = restingNewStatus,
                updatedAtMs = cmd.timestampMs,
            )

            // Update incoming order
            val incomingNewFilled = incoming.filledQty + fillQty
            val incomingNewStatus = if (incomingNewFilled >= incoming.originalQty) OrderStatus.FILLED else OrderStatus.PART_FILLED
            incoming = incoming.copy(
                filledQty = incomingNewFilled,
                status = incomingNewStatus,
                updatedAtMs = cmd.timestampMs,
            )
            ordersById[incoming.orderId] = incoming

            trades.add(trade)
            executedTrades.add(trade)
            lastTradePrice = tradePrice

            val tradeEvt = EngineEvent.TradeExecuted(
                seq = tradeSeq,
                clientCommandId = cmd.clientCommandId,
                instrumentId = instrument.id,
                timestampMs = cmd.timestampMs,
                trade = trade,
            )
            emittedEvents.add(tradeEvt)
            eventLog.add(tradeEvt)
        }

        val summary = when {
            executedTrades.isEmpty() -> "Order ${incoming.orderId} resting on book (${incoming.remainingQty} ${instrument.quantityBasis} @ ${incoming.limitPrice})."
            incoming.remainingQty == 0L -> "Order ${incoming.orderId} filled completely across ${executedTrades.size} trade(s)."
            else -> "Order ${incoming.orderId} part-filled (${incoming.filledQty}/${incoming.originalQty}); ${incoming.remainingQty} resting."
        }

        return EngineCommandOutcome(
            accepted = true,
            idempotentReplay = false,
            message = summary,
            events = emittedEvents,
            resultingOrder = incoming,
            executedTrades = executedTrades,
        )
    }

    private fun handleCancelOrder(cmd: EngineCommand.CancelOrder): EngineCommandOutcome {
        val existing = ordersById[cmd.orderId]
            ?: return reject("Order ${cmd.orderId} not found in partition ${instrument.id}.")
        if (existing.orgId != cmd.requestingOrgId) {
            return reject("Order ${cmd.orderId} belongs to ${existing.orgName}; cannot cancel.")
        }
        if (existing.status == OrderStatus.FILLED || existing.remainingQty == 0L) {
            return reject("Cancel-vs-fill: Order ${cmd.orderId} already completely filled (${existing.filledQty}/${existing.originalQty}).")
        }
        if (existing.status == OrderStatus.CANCELLED || existing.status == OrderStatus.EXPIRED) {
            return reject("Order ${cmd.orderId} is already ${existing.status.label}.")
        }

        val released = existing.remainingQty
        val updated = existing.copy(
            status = OrderStatus.CANCELLED,
            updatedAtMs = cmd.timestampMs,
        )
        ordersById[existing.orderId] = updated

        val seq = nextSequence++
        val evt = EngineEvent.OrderCancelled(
            seq = seq,
            clientCommandId = cmd.clientCommandId,
            instrumentId = instrument.id,
            timestampMs = cmd.timestampMs,
            orderId = existing.orderId,
            releasedQty = released,
        )
        eventLog.add(evt)

        return EngineCommandOutcome(
            accepted = true,
            idempotentReplay = false,
            message = "Cancelled ${existing.orderId}; released $released ${instrument.quantityBasis} (filled qty preserved: ${existing.filledQty}).",
            events = listOf(evt),
            resultingOrder = updated,
        )
    }

    private fun handleSuspend(cmd: EngineCommand.SuspendMarket): EngineCommandOutcome {
        isSuspended = true
        val evt = EngineEvent.MarketStatusChanged(
            seq = nextSequence++,
            clientCommandId = cmd.clientCommandId,
            instrumentId = instrument.id,
            timestampMs = cmd.timestampMs,
            suspended = true,
            reason = cmd.reason,
        )
        eventLog.add(evt)
        return EngineCommandOutcome(true, false, "Market ${instrument.id} suspended: ${cmd.reason}", listOf(evt))
    }

    private fun handleResume(cmd: EngineCommand.ResumeMarket): EngineCommandOutcome {
        isSuspended = false
        val evt = EngineEvent.MarketStatusChanged(
            seq = nextSequence++,
            clientCommandId = cmd.clientCommandId,
            instrumentId = instrument.id,
            timestampMs = cmd.timestampMs,
            suspended = false,
            reason = "Resumed by Risk/Admin",
        )
        eventLog.add(evt)
        return EngineCommandOutcome(true, false, "Market ${instrument.id} resumed.", listOf(evt))
    }

    private fun handleExpireOrders(cmd: EngineCommand.ExpireOrders): EngineCommandOutcome {
        val expiredEvents = expireTimedOutResting(cmd.timestampMs, cmd.clientCommandId)
        return EngineCommandOutcome(
            accepted = true,
            idempotentReplay = false,
            message = "Expired ${expiredEvents.size} timed-out order(s).",
            events = expiredEvents,
        )
    }

    private fun expireTimedOutResting(nowMs: Long, clientCmdId: String): List<EngineEvent> {
        val expiredEvents = mutableListOf<EngineEvent>()
        ordersById.values
            .filter { (it.status == OrderStatus.WORKING || it.status == OrderStatus.PART_FILLED) && it.expiresAtMs in 1..nowMs }
            .forEach { order ->
                val released = order.remainingQty
                ordersById[order.orderId] = order.copy(status = OrderStatus.EXPIRED, updatedAtMs = nowMs)
                val evt = EngineEvent.OrderExpired(
                    seq = nextSequence++,
                    clientCommandId = "$clientCmdId-exp-${order.orderId}",
                    instrumentId = instrument.id,
                    timestampMs = nowMs,
                    orderId = order.orderId,
                    releasedQty = released,
                )
                eventLog.add(evt)
                expiredEvents.add(evt)
            }
        return expiredEvents
    }

    private fun matchingRestingOrders(incomingSide: OrderSide, limitPrice: BigDecimal): List<EngineOrder> {
        return ordersById.values
            .filter { it.status == OrderStatus.WORKING || it.status == OrderStatus.PART_FILLED }
            .filter { it.remainingQty > 0L }
            .filter { resting ->
                when (incomingSide) {
                    OrderSide.BUY -> resting.side == OrderSide.SELL && resting.limitPrice <= limitPrice
                    OrderSide.SELL -> resting.side == OrderSide.BUY && resting.limitPrice >= limitPrice
                }
            }
            .sortedWith(
                when (incomingSide) {
                    // Incoming BUY wants lowest SELL price first, then earliest sequence
                    OrderSide.BUY -> compareBy<EngineOrder> { it.limitPrice }.thenBy { it.sequenceNumber }
                    // Incoming SELL wants highest BUY price first, then earliest sequence
                    OrderSide.SELL -> compareByDescending<EngineOrder> { it.limitPrice }.thenBy { it.sequenceNumber }
                }
            )
    }

    private fun reject(reason: String) = EngineCommandOutcome(
        accepted = false,
        idempotentReplay = false,
        message = reason,
        events = emptyList(),
    )

    @Synchronized
    fun bidLadder(levels: Int = 5): List<BookLevel> {
        return ordersById.values
            .filter { it.side == OrderSide.BUY && (it.status == OrderStatus.WORKING || it.status == OrderStatus.PART_FILLED) && it.remainingQty > 0L }
            .groupBy { it.limitPrice }
            .entries
            .sortedByDescending { it.key }
            .take(levels)
            .map { (price, list) ->
                BookLevel(price = price, quantity = list.sumOf { it.remainingQty }, orderCount = list.size)
            }
    }

    @Synchronized
    fun askLadder(levels: Int = 5): List<BookLevel> {
        return ordersById.values
            .filter { it.side == OrderSide.SELL && (it.status == OrderStatus.WORKING || it.status == OrderStatus.PART_FILLED) && it.remainingQty > 0L }
            .groupBy { it.limitPrice }
            .entries
            .sortedBy { it.key }
            .take(levels)
            .map { (price, list) ->
                BookLevel(price = price, quantity = list.sumOf { it.remainingQty }, orderCount = list.size)
            }
    }

    @Synchronized
    fun allOrders(): List<EngineOrder> = ordersById.values.sortedByDescending { it.sequenceNumber }

    @Synchronized
    fun allTrades(): List<SpotTradeRecord> = trades.sortedByDescending { it.sequenceNumber }

    @Synchronized
    fun allEvents(): List<EngineEvent> = eventLog.toList()

    @Synchronized
    fun currentLastPrice(): BigDecimal = lastTradePrice

    @Synchronized
    fun isMarketSuspended(): Boolean = isSuspended
}
