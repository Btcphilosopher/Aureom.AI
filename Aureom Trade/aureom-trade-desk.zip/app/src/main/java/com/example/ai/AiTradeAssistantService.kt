package com.example.ai

import android.util.Log
import com.example.domain.model.DecimalMath
import com.example.domain.model.FirmOfferRecord
import com.example.domain.model.ForwardContract
import com.example.domain.model.ForwardCurvePoint
import com.example.domain.model.FuturesCollateralAccount
import com.example.domain.model.FuturesContractSpec
import com.example.domain.model.FuturesPosition
import com.example.domain.model.PhysicalInstrument
import com.example.domain.model.ProcurementPlanRow
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import java.math.BigDecimal

private const val TAG = "AiTradeAssistant"

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Streaming(val text: String, val citedIds: List<String>) : AiUiState
    data class Success(val text: String, val citedIds: List<String>) : AiUiState
    data class BlockedByGuardrail(val reason: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

/**
 * Deterministic application-level guardrails & calculations for Section 16 AI Trade Assistant.
 * - AI must NEVER autonomously place trades, increase limits, transfer collateral, approve contracts, or change settlement instructions.
 * - Numeric unit conversions, spreads, and margin math are calculated deterministically in Kotlin first, then passed to Gemini for explanation.
 */
object AiAssistantGuardrail {
    private val restrictedActionPatterns = listOf(
        Regex("""\b(place|execute|submit|send)\b.*\b(order|trade|buy|sell|short|long)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(increase|raise|override|bump)\b.*\b(credit|limit|threshold)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(transfer|withdraw|deposit|wire|move)\b.*\b(collateral|funds|margin|cash)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(approve|sign|accept)\b.*\b(contract|forward|amendment)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(change|update|modify|edit)\b.*\b(bank|iban|settlement\s+instruction)\b""", RegexOption.IGNORE_CASE),
    )

    fun checkRestrictedMutation(prompt: String): String? {
        val matched = restrictedActionPatterns.any { it.containsMatchIn(prompt) }
        return if (matched) {
            "Action Blocked by Business Controls (Section 16): The AI Trade Assistant is strictly read-only/advisory. " +
                "It cannot autonomously place trades, increase limits, transfer collateral, approve contracts, or modify settlement instructions. " +
                "Use the signed role workflow in the Order Ticket, Contracts, Finance, or Risk tabs."
        } else null
    }

    fun buildDeterministicContextSnapshot(
        selectedInstrument: PhysicalInstrument,
        allInstruments: List<PhysicalInstrument>,
        offers: List<FirmOfferRecord>,
        contracts: List<ForwardContract>,
        curve: List<ForwardCurvePoint>,
        futuresSpec: FuturesContractSpec?,
        futuresPos: FuturesPosition?,
        collateral: FuturesCollateralAccount?,
        procurementRows: List<ProcurementPlanRow>,
    ): Pair<String, List<String>> {
        val citedIds = mutableListOf<String>()
        citedIds += selectedInstrument.id

        val eqUnitPrices = allInstruments.joinToString("\n") { inst ->
            val eq = inst.packaging.equivalentUnitPrice(inst.referenceSpotPrice)
            "- [${inst.id}] ${inst.productName} (${inst.brand}, ${inst.packaging.description}, ${inst.termAndPlace}): " +
                "${DecimalMath.formatCurrency(inst.referenceSpotPrice, inst.currency)}/case = " +
                "${DecimalMath.formatCurrency(eq, inst.currency)}/${inst.packaging.unitMeasureLabel} (${inst.quoteSource.label})"
        }

        val matchingOffers = offers.filter { it.status == "ACTIVE" || it.status == "PARTIALLY_TAKEN" }
        matchingOffers.forEach { citedIds += it.offerId }
        val offersBlock = if (matchingOffers.isEmpty()) "None active" else matchingOffers.joinToString("\n") { o ->
            "- [${o.offerId}] ${o.instrumentId} | Seller=${o.sellerOrgName} | ${if (o.isFirm) "FIRM" else "INDICATIVE"} | " +
                "Price=${DecimalMath.formatCurrency(o.unitPrice, o.currency)} | Remaining=${o.remainingQty}/${o.totalQty} | Terms=${o.deliveryTerms}"
        }

        contracts.forEach { citedIds += it.contractId }
        val contractsBlock = contracts.joinToString("\n") { c ->
            "- [${c.contractId}] ${c.productSpec} | ${c.buyerOrgName} <-> ${c.sellerOrgName} | " +
                "Qty=${c.contractedQty} (Accepted=${c.acceptedQty}, Outstanding=${c.outstandingQty}) | " +
                "Price=${DecimalMath.formatCurrency(c.fixedOrFormulaPrice, c.currency)} | Status=${c.status.label} | " +
                "Window=${c.deliveryWindowStart}..${c.deliveryWindowEnd} | Terms=${c.tradeTerms} | Payment=${c.paymentSchedule}"
        }

        val curveBlock = curve.joinToString("\n") { pt ->
            "- ${pt.deliveryMonth}: $${pt.price}/case (Basis vs spot=${pt.basisVsSpot}, Fin=${pt.financingCarryCost}, Store=${pt.storageInsuranceCost}, ShelfLife=${pt.shelfLifeRiskAdjustment})"
        }

        val marginBlock = if (futuresSpec != null && futuresPos != null && collateral != null) {
            citedIds += futuresSpec.contractCode
            val unrealised = futuresPos.unrealisedVariationPnL(futuresSpec.currentMarkPrice, futuresSpec.contractMultiplier)
            val equity = collateral.netCollateralBalance(unrealised)
            val initReq = futuresSpec.initialMarginPerContract.multiply(BigDecimal.valueOf(kotlin.math.abs(futuresPos.netContracts).toLong()))
            val maintReq = futuresSpec.maintenanceMarginPerContract.multiply(BigDecimal.valueOf(kotlin.math.abs(futuresPos.netContracts).toLong()))
            "Contract=${futuresSpec.contractCode}, NetContracts=${futuresPos.netContracts}, AvgEntry=${futuresPos.avgEntryPrice}, " +
                "SettlementBasis=${futuresPos.settlementBasisPrice}, Mark=${futuresSpec.currentMarkPrice}, " +
                "UnrealisedVariation=$unrealised, RealisedPnL=${futuresPos.realisedPnL}, CashCollateral=${collateral.cashCollateralPosted}, " +
                "NetEquity=$equity, InitialReq=$initReq, MaintReq=$maintReq"
        } else "No open futures simulation position."

        val procBlock = procurementRows.joinToString("\n") { row ->
            "- ${row.label}: Req=${row.expectedRequirementCases} cases, PhysicalCoverage=${row.totalPhysicalCoverageCases} (${row.physicalCoveragePct}%), " +
                "Gap=${row.remainingPhysicalGapCases}, FuturesHedgeEq=${row.futuresHedgeEquivalentCases}, BasisRisk=${row.basisRiskNote}"
        }

        val snapshot = """
SELECTED INSTRUMENT: [${selectedInstrument.id}] ${selectedInstrument.productName} (${selectedInstrument.brand})
SKU: ${selectedInstrument.skuOrSpec} | Grade: ${selectedInstrument.grade} | Packaging: ${selectedInstrument.packaging.description}
Location: ${selectedInstrument.deliveryLocation} | Term: ${selectedInstrument.termAndPlace} | Min Shelf Life: ${selectedInstrument.minRemainingShelfLifeMonths} months

DETERMINISTIC EQUIVALENT UNIT PRICES:
$eqUnitPrices

ACTIVE WHOLESALE OFFERS:
$offersBlock

FORWARD CONTRACTS:
$contractsBlock

DELIVERY CURVE (${selectedInstrument.productName}):
$curveBlock

FUTURES SIMULATION MARGIN SNAPSHOT (ILLUSTRATIVE ONLY):
$marginBlock

PROCUREMENT COVERAGE SUMMARY:
$procBlock
        """.trimIndent()

        return snapshot to citedIds.distinct()
    }
}

class AiTradeAssistantService {

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "You are the Aureom Trade Terminal AI Assistant for enterprise wholesale B2B consumer goods trading. " +
                        "Follow these strict governance rules:\n" +
                        "1. Always distinguish facts, estimates, and inferences using explicit labels: [FACT], [ESTIMATE], [INFERENCE].\n" +
                        "2. Always cite exact record IDs from the provided context (e.g., AT-1047, OFR-901, LAUNDRY-LIQ-UK-DEC26, HOMECARE-MAR27).\n" +
                        "3. Never invent prices, quantities, or math — use only the deterministic calculations provided in the snapshot.\n" +
                        "4. Never claim a simulated futures contract guarantees physical delivery of a branded SKU.\n" +
                        "5. You are strictly read-only: never claim you placed a trade, approved a contract, raised a credit limit, or transferred collateral."
                )
            }
        )
    }

    fun streamAnalysis(userQuery: String, contextSnapshot: String): Flow<String> = flow {
        val fullPrompt = """
$contextSnapshot

USER REQUEST:
$userQuery

Respond concisely with structured bullet points. Cite source IDs and prefix statements with [FACT], [ESTIMATE], or [INFERENCE].
        """.trimIndent()

        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                model.generateContentStream(fullPrompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("Model returned an empty response.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI assistant request timed out", e)
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI generation failed", e)
            throw e
        }
    }
}
