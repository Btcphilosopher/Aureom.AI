package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DecimalMath
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.ForwardContractStatus
import com.example.domain.model.InstrumentCompatibility
import com.example.domain.model.LandedCostCalculator
import com.example.domain.model.ProductCategory
import com.example.domain.model.TerminalTab
import com.example.domain.model.TradingApproach
import com.example.ui.TerminalUiState
import com.example.ui.TerminalViewModel
import com.example.ui.components.TerminalPanel
import com.example.ui.theme.LocalAureomPalette
import com.example.ui.theme.MonoTabularStyle
import java.math.BigDecimal

@Composable
fun MarketsScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    var filterApproach by remember { mutableStateOf<TradingApproach?>(null) }
    var filterCat by remember { mutableStateOf<ProductCategory?>(null) }
    var compareTargetId by remember { mutableStateOf(state.instruments.lastOrNull()?.id ?: "") }

    val selected = state.selectedInstrument
    val compareTarget = state.instruments.firstOrNull { it.id == compareTargetId }
    val compatibility = if (selected != null && compareTarget != null) {
        InstrumentCompatibility.checkFungibility(selected, compareTarget)
    } else null

    val filtered = state.instruments.filter { inst ->
        (filterApproach == null || inst.tradingApproach == filterApproach) &&
            (filterCat == null || inst.category == filterCat) &&
            (state.searchQuery.isBlank() || inst.productName.contains(state.searchQuery, true) || inst.skuOrSpec.contains(state.searchQuery, true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Filter strip
        TerminalPanel(title = "Wholesale Consumer Goods Universe (Branded SKU vs Generic Spec)") {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChipPill("All Approaches", filterApproach == null) { filterApproach = null }
                TradingApproach.entries.forEach { app ->
                    FilterChipPill(app.label, filterApproach == app) { filterApproach = app }
                }
                FilterChipPill("All Categories", filterCat == null) { filterCat = null }
                ProductCategory.entries.forEach { cat ->
                    FilterChipPill(cat.displayName, filterCat == cat) { filterCat = cat }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            filtered.forEach { inst ->
                val eqPrice = inst.packaging.equivalentUnitPrice(inst.referenceSpotPrice)
                val adapter = if (inst.originCountry == "Netherlands") state.freightAdapters[1] else state.freightAdapters[0]
                val landed = LandedCostCalculator.compute(inst.referenceSpotPrice, inst.currency, inst.tradeTerm, adapter)

                Surface(
                    color = if (inst.id == state.selectedInstrumentId) palette.accentContainer else palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (inst.id == state.selectedInstrumentId) palette.accent else palette.border),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable {
                            vm.selectInstrument(inst.id)
                            vm.selectTab(TerminalTab.TRADE)
                        },
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${inst.productName} • ${inst.brand}", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(
                                "${DecimalMath.formatCurrency(inst.referenceSpotPrice, inst.currency)}/case",
                                style = MonoTabularStyle.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold),
                                color = palette.accent,
                            )
                        }
                        Text(
                            "SKU/Spec: ${inst.skuOrSpec} • ${inst.tradingApproach.label} • ${inst.packaging.description} (${inst.packaging.casesPerPallet}/plt)",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                        )
                        Text(
                            "Grade: ${inst.grade} | Origin: ${inst.originCountry} | HS ${inst.hsCode} | ${inst.termAndPlace} -> ${inst.deliveryLocation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textMuted,
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "Unit Eq: ${DecimalMath.formatCurrency(eqPrice, inst.currency)}/${inst.packaging.unitMeasureLabel} | Min shelf: ${inst.minRemainingShelfLifeMonths}m",
                                style = MonoTabularStyle.copy(fontSize = 11.sp),
                                color = palette.textPrimary,
                            )
                            Text(
                                "Est. Landed: ${DecimalMath.formatCurrency(landed.estimatedLandedPerCase, inst.currency)}/case",
                                style = MonoTabularStyle.copy(fontSize = 11.sp),
                                color = palette.positive,
                            )
                        }
                        Text(
                            "Source: ${inst.quoteSource.label} • Substitutions: ${inst.permittedSubstitutions}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textMuted,
                        )
                    }
                }
            }
        }

        // Fungibility & Compatibility Matrix + Cross-Border Landed Cost Assumptions
        if (selected != null && compareTarget != null && compatibility != null) {
            TerminalPanel(title = "Instrument Compatibility & Fungibility Guardrail") {
                Text(
                    "Comparing [${selected.id}] vs [${compareTarget.id}] (Tap another instrument below to compare):",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    state.instruments.forEach { candidate ->
                        FilterChipPill(candidate.productName, candidate.id == compareTarget.id) { compareTargetId = candidate.id }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = if (compatibility.isFungible) palette.positiveBg else palette.warningBg,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (compatibility.isFungible) palette.positive else palette.warning),
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (compatibility.isFungible) "FUNGIBLE: Identical specification, location, grade & commercial terms." else "NON-FUNGIBLE: Cannot merge into a single executable price.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (compatibility.isFungible) palette.positive else palette.warning,
                        )
                        compatibility.mismatchReasons.forEach { reason ->
                            Text("• $reason", style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RfqsScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    val selected = state.selectedInstrument

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Firm vs Indicative Wholesale Offer Board
        TerminalPanel(
            title = "Wholesale Offers (Firm Stock-Reserved vs Indicative)",
            trailing = {
                if (selected != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { vm.publishOffer(selected.id, true, selected.referenceSpotPrice, 120L) }) {
                            Text("+ Publish Firm Offer (120)")
                        }
                    }
                }
            }
        ) {
            state.offers.forEach { offer ->
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (offer.isFirm) palette.accent else palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${offer.offerId} • ${offer.sellerOrgName}", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Surface(
                                color = if (offer.isFirm) palette.positiveBg else palette.warningBg,
                                shape = RoundedCornerShape(4.dp),
                            ) {
                                Text(
                                    text = if (offer.isFirm) "FIRM • STOCK RESERVED" else "INDICATIVE ONLY",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (offer.isFirm) palette.positive else palette.warning,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            }
                        }
                        Text(
                            "Instrument: ${offer.instrumentId} | Price: ${DecimalMath.formatCurrency(offer.unitPrice, offer.currency)}/case | Remaining: ${offer.remainingQty}/${offer.totalQty}",
                            style = MonoTabularStyle.copy(fontSize = 12.sp),
                            color = palette.textPrimary,
                        )
                        Text("${offer.location} • ${offer.deliveryTerms} • Status: ${offer.status}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        if (offer.isFirm && offer.remainingQty >= 60L) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = { vm.liftFirmOffer(offer.offerId, 60L) },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = palette.onAccent),
                                modifier = Modifier.testTag("buy_offer_${offer.offerId}"),
                            ) {
                                Text("Purchase 60 Cases (Atomic Reservation)")
                            }
                        }
                    }
                }
            }
        }

        // Negotiated RFQs outside central order book
        TerminalPanel(
            title = "Requests for Quotations (Bilateral — Outside Central Order Book)",
            trailing = {
                if (selected != null) {
                    Button(
                        onClick = { vm.createRfq(selected.id, 300L, selected.referenceSpotPrice, "Feb 2027", selected.deliveryLocation) },
                        modifier = Modifier.testTag("create_rfq_button"),
                    ) {
                        Text("+ Submit RFQ (300)")
                    }
                }
            }
        ) {
            state.rfqs.forEach { rfq ->
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${rfq.rfqId} • ${rfq.productName}", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(rfq.status.label, style = MaterialTheme.typography.labelSmall, color = palette.accent)
                        }
                        Text(
                            "Requester: ${rfq.requesterOrgName} | Qty: ${rfq.targetQty} | Target: ${rfq.targetPrice?.let { DecimalMath.formatCurrency(it, rfq.currency) } ?: "Open"} | ${rfq.tradeTerm.code} ${rfq.destination}",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                        )
                        rfq.quotes.forEach { q ->
                            HorizontalDivider(color = palette.border.copy(alpha = 0.5f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${q.supplierOrgName} • ${DecimalMath.formatCurrency(q.quotedPrice, rfq.currency)}/case", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = palette.textPrimary)
                                    Text(q.notes, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                                }
                                if (rfq.status != com.example.domain.model.RfqStatus.CONVERTED) {
                                    OutlinedButton(onClick = { vm.convertRfqToForward(rfq, q) }) {
                                        Text("Accept -> Forward")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContractsScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(title = "Bilateral Physical Forward Contracts (Dual-Control & Versioned Amendments)") {
            Text(
                "Note: Bilateral physical forwards carry explicit physical delivery obligations and credit terms; they are NOT exchange-traded futures.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
            Spacer(modifier = Modifier.height(8.dp))
            state.contracts.forEach { c ->
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (c.status == ForwardContractStatus.PENDING_APPROVAL) palette.warning else palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${c.contractId} (v${c.signedVersion}) • ${c.productSpec}", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Surface(
                                color = if (c.status == ForwardContractStatus.PENDING_APPROVAL) palette.warningBg else palette.accentContainer,
                                shape = RoundedCornerShape(4.dp),
                            ) {
                                Text(c.status.label, style = MaterialTheme.typography.labelSmall, color = if (c.status == ForwardContractStatus.PENDING_APPROVAL) palette.warning else palette.accent, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Text("Buyer: ${c.buyerOrgName} | Seller: ${c.sellerOrgName}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        Text(
                            "Price: ${DecimalMath.formatCurrency(c.fixedOrFormulaPrice, c.currency)} (${c.pricingBasis}) | Tolerance: ±${c.tolerancePct}% | Window: ${c.deliveryWindowStart}..${c.deliveryWindowEnd}",
                            style = MonoTabularStyle.copy(fontSize = 11.sp),
                            color = palette.textPrimary,
                        )
                        Text("Terms: ${c.tradeTerms} • Payment: ${c.paymentSchedule}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        Text("Credit Support: ${c.creditSupportTerms}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        Text("Inspection: ${c.inspectionAndAcceptanceTerms} | Short Delivery: ${c.shortDeliveryAndRejectionTerms}", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        Text("Default/Dispute: ${c.cancellationAndDefaultTerms} • ${c.disputeResolutionTerms}", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        HorizontalDivider(color = palette.border)
                        Text(
                            "Quantities -> Contracted: ${c.contractedQty} | Allocated: ${c.allocatedQty} | Dispatched: ${c.dispatchedQty} | Delivered: ${c.deliveredQty} | Accepted: ${c.acceptedQty} | Outstanding: ${c.outstandingQty}",
                            style = MonoTabularStyle.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                            color = palette.accent,
                        )
                        if (c.amendments.isNotEmpty()) {
                            c.amendments.forEach { a ->
                                Text("Amendment v${a.versionNumber}: ${a.summary} (Buyer=${a.buyerApproved}, Seller=${a.sellerApproved})", style = MaterialTheme.typography.labelSmall, color = palette.positive)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (c.status == ForwardContractStatus.PENDING_APPROVAL) {
                                Button(
                                    onClick = { vm.approveForwardContract(c) },
                                    modifier = Modifier.testTag("approve_contract_${c.contractId}"),
                                ) {
                                    Text("Approve & Accept")
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    vm.amendForwardContract(
                                        c,
                                        "Volume +50 cases at revised freight bracket",
                                        c.fixedOrFormulaPrice,
                                        c.contractedQty + 50L,
                                    )
                                },
                                modifier = Modifier.testTag("amend_contract_${c.contractId}"),
                            ) {
                                Text("Propose Amendment (+50)")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InventoryScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(title = "Warehouse, Batch & Expiry Inventory Ledger") {
            state.inventories.forEach { b ->
                val ageMin = ((System.currentTimeMillis() - b.freshnessTimestampMs) / 60_000L).coerceAtLeast(0L)
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${b.warehouseName} • ${b.productName}", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text("Batch ${b.batchCode}", style = MonoTabularStyle.copy(fontSize = 11.sp), color = palette.accent)
                        }
                        Text("Expiry: ${b.expiryDate} (${b.remainingShelfLifeMonths}m remaining) | Cert: ${b.certificateRef}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avail: ${b.availableQty}", style = MonoTabularStyle.copy(fontSize = 12.sp, fontWeight = FontWeight.Bold), color = palette.positive)
                            Text("Reserved: ${b.reservedQty}", style = MonoTabularStyle.copy(fontSize = 12.sp), color = palette.accent)
                            Text("Quarantine: ${b.quarantinedQty}", style = MonoTabularStyle.copy(fontSize = 12.sp), color = if (b.quarantinedQty > 0) palette.warning else palette.textMuted)
                            Text("In-Transit: ${b.inTransitQty}", style = MonoTabularStyle.copy(fontSize = 12.sp), color = palette.textSecondary)
                            Text("Expired: ${b.expiredQty}", style = MonoTabularStyle.copy(fontSize = 12.sp), color = if (b.expiredQty > 0) palette.negative else palette.textMuted)
                        }
                        Text("Source: ${b.stockSource} • Synced ${ageMin}m ago", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                    }
                }
            }
        }
    }
}

@Composable
fun DeliveriesScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(title = "Logistics, Partial Deliveries, Inspection & Document Provenance") {
            state.shipments.forEach { s ->
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (s.discrepancyReason != null) palette.warning else palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${s.shipmentId} (Ref: ${s.referenceId}) • ${s.productName}", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(s.status.label, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = palette.warning)
                        }
                        Text("${s.warehouseName} -> ${s.destination} | Carrier: ${s.carrierName} (${s.trackingNumber})", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        Text(
                            "Ordered: ${s.orderedQty} | Dispatched: ${s.dispatchedQty} | Delivered: ${s.deliveredQty} | Accepted: ${s.acceptedQty} | Rejected: ${s.rejectedQty}",
                            style = MonoTabularStyle.copy(fontSize = 11.sp),
                            color = palette.accent,
                        )
                        s.discrepancyReason?.let {
                            Text("Exception: $it", style = MaterialTheme.typography.bodySmall, color = palette.warning)
                        }
                        if (s.documents.isNotEmpty()) {
                            Text(
                                "Documents: " + s.documents.joinToString(" | ") { "${it.docType} (${it.filename}, sha:${it.sha256Short})" },
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textMuted,
                            )
                        }
                        if (s.acceptedQty < s.orderedQty) {
                            val rem = (s.orderedQty - s.deliveredQty).coerceAtLeast(20L).coerceAtMost(s.orderedQty - s.acceptedQty)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { vm.recordPartialDelivery(s, rem, rem) },
                                    modifier = Modifier.testTag("accept_delivery_${s.shipmentId}"),
                                ) {
                                    Text("Inspect & Accept +$rem Cases")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChipPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val palette = LocalAureomPalette.current
    Surface(
        color = if (selected) palette.accentContainer else palette.panelElevated,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, if (selected) palette.accent else palette.border),
        modifier = Modifier.clickable(onClick = onClick),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) palette.accent else palette.textSecondary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )
    }
}
