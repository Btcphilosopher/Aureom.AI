package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class TerminalDensity(
    val label: String,
    val panelPadding: Dp,
    val rowVerticalPadding: Dp,
    val sectionSpacing: Dp,
) {
    COMPACT("Compact", 8.dp, 4.dp, 6.dp),
    STANDARD("Standard", 12.dp, 7.dp, 10.dp),
}

val LocalAureomPalette = staticCompositionLocalOf { DarkAureomPalette }
val LocalTerminalDensity = staticCompositionLocalOf { TerminalDensity.COMPACT }

private val AureomDarkScheme = darkColorScheme(
    primary = AureomCyan,
    onPrimary = ColorTokens.OnCyanDark,
    primaryContainer = AureomCyanContainer,
    onPrimaryContainer = TextPrimaryDark,
    secondary = BidGreen,
    onSecondary = ColorTokens.OnCyanDark,
    tertiary = AmberAlert,
    background = MidnightShell,
    onBackground = TextPrimaryDark,
    surface = CharcoalPanel,
    onSurface = TextPrimaryDark,
    surfaceVariant = CharcoalElevated,
    onSurfaceVariant = TextSecondaryDark,
    outline = TerminalBorder,
    error = AskRed,
)

private val AureomLightScheme = lightColorScheme(
    primary = LightCyan,
    onPrimary = LightPanel,
    primaryContainer = LightCyanContainer,
    onPrimaryContainer = TextPrimaryLight,
    secondary = BidGreenLight,
    onSecondary = LightPanel,
    tertiary = AmberAlertLight,
    background = LightShell,
    onBackground = TextPrimaryLight,
    surface = LightPanel,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightElevated,
    onSurfaceVariant = TextSecondaryLight,
    outline = LightBorder,
    error = AskRedLight,
)

private object ColorTokens {
    val OnCyanDark = androidx.compose.ui.graphics.Color(0xFF04131D)
}

private val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(10.dp),
    extraLarge = RoundedCornerShape(12.dp),
)

@Composable
fun AureomTheme(
    darkTheme: Boolean = true,
    density: TerminalDensity = TerminalDensity.COMPACT,
    content: @Composable () -> Unit,
) {
    val palette = if (darkTheme) DarkAureomPalette else LightAureomPalette
    val colorScheme = if (darkTheme) AureomDarkScheme else AureomLightScheme

    CompositionLocalProvider(
        LocalAureomPalette provides palette,
        LocalTerminalDensity provides density,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AureomTypography,
            shapes = AureomShapes,
            content = content,
        )
    }
}
