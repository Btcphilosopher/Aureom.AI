package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        EngineEventEntity::class,
        InventoryBatchEntity::class,
        FirmOfferEntity::class,
        RfqEntity::class,
        ForwardContractEntity::class,
        ShipmentEntity::class,
        InvoiceEntity::class,
        FuturesPositionEntity::class,
        CollateralAccountEntity::class,
        SurveillanceAlertEntity::class,
        AuditLogEntity::class,
        WorkspacePrefEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun terminalDao(): TerminalDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getInstance(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_trade_terminal.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
