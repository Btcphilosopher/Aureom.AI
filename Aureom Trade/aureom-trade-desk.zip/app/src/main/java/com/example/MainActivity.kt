package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.configureAppCheck
import com.example.domain.model.CurrencyCode
import com.example.domain.model.OrgRole
import com.example.domain.model.TerminalTab
import com.example.ui.TerminalViewModel
import com.example.ui.components.AiAssistantSheet
import com.example.ui.components.AureomTopHeader
import com.example.ui.components.CategoryAndModeStrip
import com.example.ui.components.TerminalFooterBar
import com.example.ui.screens.AdministrationScreen
import com.example.ui.screens.ContractsScreen
import com.example.ui.screens.DeliveriesScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.MarketsScreen
import com.example.ui.screens.PositionsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.RfqsScreen
import com.example.ui.screens.RiskScreen
import com.example.ui.screens.TradeWorkspaceScreen
import com.example.ui.theme.AureomTheme
import com.example.ui.theme.LocalAureomPalette

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory: configure App Check with launch intent before Compose UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            val vm: TerminalViewModel = viewModel()
            AureomTerminalApp(vm)
        }
    }
}

@Composable
fun AureomTerminalApp(vm: TerminalViewModel) {
    val state by vm.uiState.collectAsStateWithLifecycle()

    if (state.activeTab != TerminalTab.TRADE) {
        BackHandler {
            vm.selectTab(TerminalTab.TRADE)
        }
    }

    AureomTheme(
        darkTheme = state.isDarkTheme,
        density = state.density,
    ) {
        val palette = LocalAureomPalette.current

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.shellBg)
                .onPreviewKeyEvent { keyEvent ->
                    if (keyEvent.type == KeyEventType.KeyDown && keyEvent.isCtrlPressed) {
                        when (keyEvent.key) {
                            Key.One -> { vm.selectTab(TerminalTab.MARKETS); true }
                            Key.Two -> { vm.selectTab(TerminalTab.TRADE); true }
                            Key.Three -> { vm.selectTab(TerminalTab.RFQS); true }
                            Key.Four -> { vm.selectTab(TerminalTab.CONTRACTS); true }
                            Key.Five -> { vm.selectTab(TerminalTab.INVENTORY); true }
                            Key.R -> { vm.replayEngineEvents(); true }
                            else -> false
                        }
                    } else false
                }
        ) {
            val isCompactScreen = maxWidth < 760.dp

            Column(modifier = Modifier.fillMaxSize()) {
                AureomTopHeader(
                    activeTab = state.activeTab,
                    onSelectTab = vm::selectTab,
                    searchQuery = state.searchQuery,
                    onSearchChange = vm::setSearchQuery,
                    displayCurrency = state.displayCurrency,
                    onCycleCurrency = {
                        val all = listOf(CurrencyCode.USD, CurrencyCode.GBP, CurrencyCode.EUR)
                        val next = all[(all.indexOf(state.displayCurrency) + 1) % all.size]
                        vm.setDisplayCurrency(next)
                    },
                    utcClockText = state.utcClockText,
                    isFeedHealthy = state.isFeedHealthy,
                    isFeedStale = state.isFeedStale,
                    onToggleStaleFeed = vm::toggleStaleFeedSimulation,
                    activeRole = state.activeRole,
                    onCycleRole = {
                        val all = OrgRole.entries
                        val next = all[(all.indexOf(state.activeRole) + 1) % all.size]
                        vm.setActiveRole(next)
                    },
                    onToggleTheme = vm::toggleTheme,
                    onToggleDensity = vm::toggleDensity,
                    onOpenAiAssistant = { vm.setAiSheetOpen(true) },
                    isCompactScreen = isCompactScreen,
                )

                CategoryAndModeStrip(
                    marketMode = state.marketMode,
                    onSelectMode = vm::selectMarketMode,
                    isFeedStale = state.isFeedStale,
                    isCompactScreen = isCompactScreen,
                )

                // Feedback banner for command confirmations / errors
                AnimatedVisibility(visible = state.feedbackMessage != null) {
                    state.feedbackMessage?.let { msg ->
                        Surface(
                            color = if (state.feedbackIsError) palette.negativeBg else palette.accentContainer,
                            border = BorderStroke(1.dp, if (state.feedbackIsError) palette.negative else palette.accent),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                .clickable { vm.clearFeedback() },
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (state.feedbackIsError) palette.negative else palette.textPrimary,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    text = "Dismiss",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.accent,
                                )
                            }
                        }
                    }
                }

                // Active Workspace Module
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (state.activeTab) {
                        TerminalTab.MARKETS -> MarketsScreen(state, vm)
                        TerminalTab.TRADE -> TradeWorkspaceScreen(state, vm)
                        TerminalTab.RFQS -> RfqsScreen(state, vm)
                        TerminalTab.CONTRACTS -> ContractsScreen(state, vm)
                        TerminalTab.INVENTORY -> InventoryScreen(state, vm)
                        TerminalTab.DELIVERIES -> DeliveriesScreen(state, vm)
                        TerminalTab.POSITIONS -> PositionsScreen(state, vm)
                        TerminalTab.RISK -> RiskScreen(state, vm)
                        TerminalTab.FINANCE -> FinanceScreen(state, vm)
                        TerminalTab.REPORTS -> ReportsScreen(state, vm)
                        TerminalTab.ADMINISTRATION -> AdministrationScreen(state, vm)
                    }
                }

                TerminalFooterBar(
                    isFeedStale = state.isFeedStale,
                    utcClockText = state.utcClockText,
                    eventCount = state.engineSnapshot.eventCount,
                )
            }

            AiAssistantSheet(state = state, vm = vm)
        }
    }
}
