package com.example.data.local

import com.example.domain.model.AlertSeverity
import com.example.domain.model.CommercialInvoice
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.EngineOrder
import com.example.domain.model.FirmOfferRecord
import com.example.domain.model.ForwardAmendment
import com.example.domain.model.ForwardContract
import com.example.domain.model.ForwardContractStatus
import com.example.domain.model.FuturesCollateralAccount
import com.example.domain.model.FuturesPosition
import com.example.domain.model.InventoryBatch
import com.example.domain.model.InvoiceStatus
import com.example.domain.model.OrderSide
import com.example.domain.model.OrderStatus
import com.example.domain.model.ProvenanceDocument
import com.example.domain.model.RfqQuote
import com.example.domain.model.RfqRecord
import com.example.domain.model.RfqStatus
import com.example.domain.model.ShipmentRecord
import com.example.domain.model.ShipmentStatus
import com.example.domain.model.SpotTradeRecord
import com.example.domain.model.SurveillanceAlert
import com.example.domain.model.TradeTerm
import com.example.engine.EngineEvent
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal

object TerminalMappers {

    fun EngineEvent.toEntity(): EngineEventEntity {
        val (type, json) = when (this) {
            is EngineEvent.OrderAccepted -> "OrderAccepted" to JSONObject().apply {
                put("orderId", order.orderId)
                put("clientCommandId", order.clientCommandId)
                put("instrumentId", order.instrumentId)
                put("orgId", order.orgId)
                put("orgName", order.orgName)
                put("traderRole", order.traderRole)
                put("side", order.side.name)
                put("limitPrice", order.limitPrice.toPlainString())
                put("originalQty", order.originalQty)
                put("filledQty", order.filledQty)
                put("status", order.status.name)
                put("deliveryPeriod", order.deliveryPeriod)
                put("tradeTerm", order.tradeTerm)
                put("currency", order.currency.name)
                put("sequenceNumber", order.sequenceNumber)
                put("expiresAtMs", order.expiresAtMs)
                put("createdAtMs", order.createdAtMs)
                put("updatedAtMs", order.updatedAtMs)
            }.toString()
            is EngineEvent.TradeExecuted -> "TradeExecuted" to JSONObject().apply {
                put("tradeId", trade.tradeId)
                put("instrumentId", trade.instrumentId)
                put("productName", trade.productName)
                put("buyOrderId", trade.buyOrderId)
                put("sellOrderId", trade.sellOrderId)
                put("buyerOrgId", trade.buyerOrgId)
                put("buyerOrgName", trade.buyerOrgName)
                put("sellerOrgId", trade.sellerOrgId)
                put("sellerOrgName", trade.sellerOrgName)
                put("price", trade.price.toPlainString())
                put("quantity", trade.quantity)
                put("currency", trade.currency.name)
                put("tradeTerm", trade.tradeTerm)
                put("deliveryLocation", trade.deliveryLocation)
                put("executionTimestampMs", trade.executionTimestampMs)
                put("sequenceNumber", trade.sequenceNumber)
            }.toString()
            is EngineEvent.OrderCancelled -> "OrderCancelled" to JSONObject().apply {
                put("orderId", orderId)
                put("releasedQty", releasedQty)
            }.toString()
            is EngineEvent.OrderExpired -> "OrderExpired" to JSONObject().apply {
                put("orderId", orderId)
                put("releasedQty", releasedQty)
            }.toString()
            is EngineEvent.MarketStatusChanged -> "MarketStatusChanged" to JSONObject().apply {
                put("suspended", suspended)
                put("reason", reason)
            }.toString()
        }
        return EngineEventEntity(
            seq = seq,
            clientCommandId = clientCommandId,
            instrumentId = instrumentId,
            eventType = type,
            payloadJson = json,
            timestampMs = timestampMs,
        )
    }

    fun EngineEventEntity.toDomain(): EngineEvent {
        val obj = JSONObject(payloadJson)
        return when (eventType) {
            "OrderAccepted" -> EngineEvent.OrderAccepted(
                seq = seq,
                clientCommandId = clientCommandId,
                instrumentId = instrumentId,
                timestampMs = timestampMs,
                order = EngineOrder(
                    orderId = obj.getString("orderId"),
                    clientCommandId = obj.getString("clientCommandId"),
                    instrumentId = obj.getString("instrumentId"),
                    orgId = obj.getString("orgId"),
                    orgName = obj.getString("orgName"),
                    traderRole = obj.getString("traderRole"),
                    side = OrderSide.valueOf(obj.getString("side")),
                    limitPrice = BigDecimal(obj.getString("limitPrice")),
                    originalQty = obj.getLong("originalQty"),
                    filledQty = obj.getLong("filledQty"),
                    status = OrderStatus.valueOf(obj.getString("status")),
                    deliveryPeriod = obj.getString("deliveryPeriod"),
                    tradeTerm = obj.getString("tradeTerm"),
                    currency = CurrencyCode.valueOf(obj.getString("currency")),
                    sequenceNumber = obj.getLong("sequenceNumber"),
                    expiresAtMs = obj.getLong("expiresAtMs"),
                    createdAtMs = obj.getLong("createdAtMs"),
                    updatedAtMs = obj.getLong("updatedAtMs"),
                ),
            )
            "TradeExecuted" -> EngineEvent.TradeExecuted(
                seq = seq,
                clientCommandId = clientCommandId,
                instrumentId = instrumentId,
                timestampMs = timestampMs,
                trade = SpotTradeRecord(
                    tradeId = obj.getString("tradeId"),
                    instrumentId = obj.getString("instrumentId"),
                    productName = obj.getString("productName"),
                    buyOrderId = obj.getString("buyOrderId"),
                    sellOrderId = obj.getString("sellOrderId"),
                    buyerOrgId = obj.getString("buyerOrgId"),
                    buyerOrgName = obj.getString("buyerOrgName"),
                    sellerOrgId = obj.getString("sellerOrgId"),
                    sellerOrgName = obj.getString("sellerOrgName"),
                    price = BigDecimal(obj.getString("price")),
                    quantity = obj.getLong("quantity"),
                    currency = CurrencyCode.valueOf(obj.getString("currency")),
                    tradeTerm = obj.getString("tradeTerm"),
                    deliveryLocation = obj.getString("deliveryLocation"),
                    executionTimestampMs = obj.getLong("executionTimestampMs"),
                    sequenceNumber = obj.getLong("sequenceNumber"),
                ),
            )
            "OrderCancelled" -> EngineEvent.OrderCancelled(
                seq = seq,
                clientCommandId = clientCommandId,
                instrumentId = instrumentId,
                timestampMs = timestampMs,
                orderId = obj.getString("orderId"),
                releasedQty = obj.getLong("releasedQty"),
            )
            "OrderExpired" -> EngineEvent.OrderExpired(
                seq = seq,
                clientCommandId = clientCommandId,
                instrumentId = instrumentId,
                timestampMs = timestampMs,
                orderId = obj.getString("orderId"),
                releasedQty = obj.getLong("releasedQty"),
            )
            else -> EngineEvent.MarketStatusChanged(
                seq = seq,
                clientCommandId = clientCommandId,
                instrumentId = instrumentId,
                timestampMs = timestampMs,
                suspended = obj.optBoolean("suspended", false),
                reason = obj.optString("reason", ""),
            )
        }
    }

    fun InventoryBatch.toEntity() = InventoryBatchEntity(
        batchId, warehouseId, warehouseName, ownerOrgId, instrumentId, skuOrSpec, productName,
        batchCode, expiryDate, remainingShelfLifeMonths, availableQty, reservedQty, quarantinedQty,
        expiredQty, inTransitQty, stockSource, freshnessTimestampMs, certificateRef,
    )

    fun InventoryBatchEntity.toDomain() = InventoryBatch(
        batchId, warehouseId, warehouseName, ownerOrgId, instrumentId, skuOrSpec, productName,
        batchCode, expiryDate, remainingShelfLifeMonths, availableQty, reservedQty, quarantinedQty,
        expiredQty, inTransitQty, stockSource, freshnessTimestampMs, certificateRef,
    )

    fun FirmOfferRecord.toEntity() = FirmOfferEntity(
        offerId, instrumentId, sellerOrgId, sellerOrgName, isFirm, unitPrice.toPlainString(),
        totalQty, remainingQty, reservedBatchId, currency.name, location, deliveryTerms,
        expiresAtMs, status, createdAtMs,
    )

    fun FirmOfferEntity.toDomain() = FirmOfferRecord(
        offerId, instrumentId, sellerOrgId, sellerOrgName, isFirm, bd(unitPrice),
        totalQty, remainingQty, reservedBatchId, CurrencyCode.valueOf(currency), location,
        deliveryTerms, expiresAtMs, status, createdAtMs,
    )

    fun RfqRecord.toEntity(): RfqEntity {
        val arr = JSONArray()
        quotes.forEach { q ->
            arr.put(JSONObject().apply {
                put("quoteId", q.quoteId)
                put("supplierOrgId", q.supplierOrgId)
                put("supplierOrgName", q.supplierOrgName)
                put("quotedPrice", q.quotedPrice.toPlainString())
                put("availableQty", q.availableQty)
                put("tradeTerm", q.tradeTerm)
                put("validUntilMs", q.validUntilMs)
                put("notes", q.notes)
            })
        }
        return RfqEntity(
            rfqId, requesterOrgId, requesterOrgName, instrumentId, productName, side.name,
            targetQty, targetPrice?.toPlainString(), currency.name, deliveryPeriod, destination,
            tradeTerm.name, minShelfLifeMonths, status.name, arr.toString(), createdAtMs,
        )
    }

    fun RfqEntity.toDomain(): RfqRecord {
        val arr = JSONArray(quotesJson)
        val quotes = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            RfqQuote(
                quoteId = o.getString("quoteId"),
                supplierOrgId = o.getString("supplierOrgId"),
                supplierOrgName = o.getString("supplierOrgName"),
                quotedPrice = bd(o.getString("quotedPrice")),
                availableQty = o.getLong("availableQty"),
                tradeTerm = o.getString("tradeTerm"),
                validUntilMs = o.getLong("validUntilMs"),
                notes = o.getString("notes"),
            )
        }
        return RfqRecord(
            rfqId, requesterOrgId, requesterOrgName, instrumentId, productName, OrderSide.valueOf(side),
            targetQty, targetPrice?.let { bd(it) }, CurrencyCode.valueOf(currency), deliveryPeriod,
            destination, TradeTerm.valueOf(tradeTerm), minShelfLifeMonths, RfqStatus.valueOf(status),
            quotes, createdAtMs,
        )
    }

    fun ForwardContract.toEntity(): ForwardContractEntity {
        val arr = JSONArray()
        amendments.forEach { a ->
            arr.put(JSONObject().apply {
                put("amendmentId", a.amendmentId)
                put("versionNumber", a.versionNumber)
                put("proposedByOrg", a.proposedByOrg)
                put("summary", a.summary)
                put("newPrice", a.newPrice?.toPlainString() ?: "")
                put("newQty", a.newQty ?: -1L)
                put("newDeliveryWindow", a.newDeliveryWindow ?: "")
                put("buyerApproved", a.buyerApproved)
                put("sellerApproved", a.sellerApproved)
                put("timestampMs", a.timestampMs)
            })
        }
        return ForwardContractEntity(
            contractId, instrumentId, productSpec, buyerOrgId, buyerOrgName, sellerOrgId, sellerOrgName,
            contractedQty, tolerancePct.toPlainString(), pricingBasis, fixedOrFormulaPrice.toPlainString(),
            currency.name, deliveryWindowStart, deliveryWindowEnd, deliveryLocation, tradeTerms,
            paymentSchedule, creditSupportTerms, inspectionAndAcceptanceTerms,
            shortDeliveryAndRejectionTerms, cancellationAndDefaultTerms, disputeResolutionTerms,
            signedVersion, createdByRole, approvedByRole, status.name, allocatedQty, dispatchedQty,
            deliveredQty, acceptedQty, arr.toString(), createdAtMs,
        )
    }

    fun ForwardContractEntity.toDomain(): ForwardContract {
        val arr = JSONArray(amendmentsJson)
        val amends = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val np = o.optString("newPrice", "")
            val nq = o.optLong("newQty", -1L)
            val nw = o.optString("newDeliveryWindow", "")
            ForwardAmendment(
                amendmentId = o.getString("amendmentId"),
                versionNumber = o.getInt("versionNumber"),
                proposedByOrg = o.getString("proposedByOrg"),
                summary = o.getString("summary"),
                newPrice = if (np.isBlank()) null else bd(np),
                newQty = if (nq <= 0L) null else nq,
                newDeliveryWindow = if (nw.isBlank()) null else nw,
                buyerApproved = o.getBoolean("buyerApproved"),
                sellerApproved = o.getBoolean("sellerApproved"),
                timestampMs = o.getLong("timestampMs"),
            )
        }
        return ForwardContract(
            contractId, instrumentId, productSpec, buyerOrgId, buyerOrgName, sellerOrgId, sellerOrgName,
            contractedQty, bd(tolerancePct), pricingBasis, bd(fixedOrFormulaPrice),
            CurrencyCode.valueOf(currency), deliveryWindowStart, deliveryWindowEnd, deliveryLocation,
            tradeTerms, paymentSchedule, creditSupportTerms, inspectionAndAcceptanceTerms,
            shortDeliveryAndRejectionTerms, cancellationAndDefaultTerms, disputeResolutionTerms,
            signedVersion, createdByRole, approvedByRole, ForwardContractStatus.valueOf(status),
            allocatedQty, dispatchedQty, deliveredQty, acceptedQty, amends, createdAtMs,
        )
    }

    fun ShipmentRecord.toEntity(): ShipmentEntity {
        val arr = JSONArray()
        documents.forEach { d ->
            arr.put(JSONObject().apply {
                put("docId", d.docId)
                put("docType", d.docType)
                put("filename", d.filename)
                put("sha256Short", d.sha256Short)
                put("uploadedByOrg", d.uploadedByOrg)
                put("uploadedAtMs", d.uploadedAtMs)
            })
        }
        return ShipmentEntity(
            shipmentId, referenceId, instrumentId, productName, warehouseName, destination,
            carrierName, trackingNumber, orderedQty, dispatchedQty, deliveredQty, acceptedQty,
            rejectedQty, status.name, discrepancyReason, arr.toString(), lastEventMs,
        )
    }

    fun ShipmentEntity.toDomain(): ShipmentRecord {
        val arr = JSONArray(documentsJson)
        val docs = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ProvenanceDocument(
                docId = o.getString("docId"),
                docType = o.getString("docType"),
                filename = o.getString("filename"),
                sha256Short = o.getString("sha256Short"),
                uploadedByOrg = o.getString("uploadedByOrg"),
                uploadedAtMs = o.getLong("uploadedAtMs"),
            )
        }
        return ShipmentRecord(
            shipmentId, referenceId, instrumentId, productName, warehouseName, destination,
            carrierName, trackingNumber, orderedQty, dispatchedQty, deliveredQty, acceptedQty,
            rejectedQty, ShipmentStatus.valueOf(status), discrepancyReason, docs, lastEventMs,
        )
    }

    fun CommercialInvoice.toEntity() = InvoiceEntity(
        invoiceId, referenceId, shipmentId, counterpartyName, invoicedQty, acceptedQty,
        unitPrice.toPlainString(), taxAmount.toPlainString(), grossAmount.toPlainString(),
        paidAmount.toPlainString(), settlementCurrency.name, bankAccountMask, status.name, issuedAtMs,
    )

    fun InvoiceEntity.toDomain() = CommercialInvoice(
        invoiceId, referenceId, shipmentId, counterpartyName, invoicedQty, acceptedQty,
        bd(unitPrice), bd(taxAmount), bd(grossAmount), bd(paidAmount),
        CurrencyCode.valueOf(settlementCurrency), bankAccountMask, InvoiceStatus.valueOf(status), issuedAtMs,
    )

    fun FuturesPosition.toEntity() = FuturesPositionEntity(
        positionId, accountId, contractCode, displayTitle, netContracts, closedContracts,
        avgEntryPrice.toPlainString(), settlementBasisPrice.toPlainString(), realisedPnL.toPlainString(),
        cumulativeVariationSettled.toPlainString(), tradingFeesPaid.toPlainString(), updatedAtMs,
    )

    fun FuturesPositionEntity.toDomain() = FuturesPosition(
        positionId, accountId, contractCode, displayTitle, netContracts, closedContracts,
        bd(avgEntryPrice), bd(settlementBasisPrice), bd(realisedPnL),
        bd(cumulativeVariationSettled), bd(tradingFeesPaid), updatedAtMs,
    )

    fun FuturesCollateralAccount.toEntity() = CollateralAccountEntity(
        accountId, cashCollateralPosted.toPlainString(), realisedTradingPnL.toPlainString(),
        feesCharged.toPlainString(), currency.name, lastSettlementDate,
    )

    fun CollateralAccountEntity.toDomain() = FuturesCollateralAccount(
        accountId, bd(cashCollateralPosted), bd(realisedTradingPnL), bd(feesCharged),
        CurrencyCode.valueOf(currency), lastSettlementDate,
    )

    fun SurveillanceAlert.toEntity() = SurveillanceAlertEntity(
        alertId, category, severity.name, title, detail, relatedRecordId, acknowledged, timestampMs,
    )

    fun SurveillanceAlertEntity.toDomain() = SurveillanceAlert(
        alertId, category, AlertSeverity.valueOf(severity), title, detail, relatedRecordId,
        isReviewSignalOnly = true, acknowledged = acknowledged, timestampMs = timestampMs,
    )
}
