package com.example.data

import com.example.data.local.AuditLogEntity
import com.example.data.local.TerminalDao
import com.example.data.local.TerminalMappers.toDomain
import com.example.data.local.TerminalMappers.toEntity
import com.example.data.local.WorkspacePrefEntity
import com.example.domain.model.AlertSeverity
import com.example.domain.model.BookLevel
import com.example.domain.model.CommercialInvoice
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DailySettlementResult
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.DemoStepStatus
import com.example.domain.model.EngineOrder
import com.example.domain.model.FirmOfferRecord
import com.example.domain.model.ForcedReductionResult
import com.example.domain.model.ForwardAmendment
import com.example.domain.model.ForwardContract
import com.example.domain.model.ForwardContractStatus
import com.example.domain.model.FuturesCollateralAccount
import com.example.domain.model.FuturesContractSpec
import com.example.domain.model.FuturesPosition
import com.example.domain.model.InventoryBatch
import com.example.domain.model.InvoiceStatus
import com.example.domain.model.MarketMode
import com.example.domain.model.OrderSide
import com.example.domain.model.OrderStatus
import com.example.domain.model.OrgRole
import com.example.domain.model.OrganizationAccount
import com.example.domain.model.PhysicalInstrument
import com.example.domain.model.ProvenanceDocument
import com.example.domain.model.RfqQuote
import com.example.domain.model.RfqRecord
import com.example.domain.model.RfqStatus
import com.example.domain.model.ShipmentRecord
import com.example.domain.model.ShipmentStatus
import com.example.domain.model.SpotTradeRecord
import com.example.domain.model.SurveillanceAlert
import com.example.domain.model.TerminalTab
import com.example.domain.model.TradeTerm
import com.example.engine.EngineCommand
import com.example.engine.EngineEvent
import com.example.engine.FuturesSimulationEngine
import com.example.engine.MatchingPartition
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

data class EngineSnapshot(
    val orders: List<EngineOrder> = emptyList(),
    val trades: List<SpotTradeRecord> = emptyList(),
    val bidsByInstrument: Map<String, List<BookLevel>> = emptyMap(),
    val asksByInstrument: Map<String, List<BookLevel>> = emptyMap(),
    val suspendedInstruments: Set<String> = emptySet(),
    val eventCount: Int = 0,
    val lastReconstructedAtMs: Long = 0L,
)

class TerminalRepository(
    private val dao: TerminalDao,
) {
    private val nowInit = System.currentTimeMillis()
    private val _instruments = MutableStateFlow(SyntheticMarketData.instruments(nowInit))
    val instruments: StateFlow<List<PhysicalInstrument>> = _instruments.asStateFlow()

    private val _organizations = MutableStateFlow(SyntheticMarketData.organizations())
    val organizations: StateFlow<List<OrganizationAccount>> = _organizations.asStateFlow()

    private val _futuresSpecs = MutableStateFlow(SyntheticMarketData.seedFuturesSpecs())
    val futuresSpecs: StateFlow<List<FuturesContractSpec>> = _futuresSpecs.asStateFlow()

    private val _engineSnapshot = MutableStateFlow(EngineSnapshot())
    val engineSnapshot: StateFlow<EngineSnapshot> = _engineSnapshot.asStateFlow()

    private val _lastSettlement = MutableStateFlow<DailySettlementResult?>(null)
    val lastSettlement: StateFlow<DailySettlementResult?> = _lastSettlement.asStateFlow()

    private val _lastForcedReduction = MutableStateFlow<ForcedReductionResult?>(null)
    val lastForcedReduction: StateFlow<ForcedReductionResult?> = _lastForcedReduction.asStateFlow()

    private val partitions = linkedMapOf<String, MatchingPartition>()

    val inventories: Flow<List<InventoryBatch>> = dao.observeInventory().map { list -> list.map { it.toDomain() } }
    val offers: Flow<List<FirmOfferRecord>> = dao.observeOffers().map { list -> list.map { it.toDomain() } }
    val rfqs: Flow<List<RfqRecord>> = dao.observeRfqs().map { list -> list.map { it.toDomain() } }
    val contracts: Flow<List<ForwardContract>> = dao.observeContracts().map { list -> list.map { it.toDomain() } }
    val shipments: Flow<List<ShipmentRecord>> = dao.observeShipments().map { list -> list.map { it.toDomain() } }
    val invoices: Flow<List<CommercialInvoice>> = dao.observeInvoices().map { list -> list.map { it.toDomain() } }
    val futuresPositions: Flow<List<FuturesPosition>> = dao.observeFuturesPositions().map { list -> list.map { it.toDomain() } }
    val collateral: Flow<FuturesCollateralAccount> = dao.observeCollateral().map {
        it?.toDomain() ?: SyntheticMarketData.seedCollateralAccount()
    }
    val alerts: Flow<List<SurveillanceAlert>> = dao.observeAlerts().map { list -> list.map { it.toDomain() } }
    val auditLogs: Flow<List<AuditLogEntity>> = dao.observeAuditLogs()

    suspend fun initializeOrReplay() {
        val existingEvents = dao.getAllEngineEvents()
        val nowMs = System.currentTimeMillis()
        if (existingEvents.isEmpty()) {
            seedFreshDatabase(nowMs)
        } else {
            reconstructPartitionsFromEventLog(existingEvents.map { it.toDomain() }, nowMs)
        }
    }

    private suspend fun seedFreshDatabase(nowMs: Long) {
        val instrList = SyntheticMarketData.instruments(nowMs)
        _instruments.value = instrList
        partitions.clear()
        instrList.forEach { partitions[it.id] = MatchingPartition(it) }

        val emitted = mutableListOf<EngineEvent>()
        SyntheticMarketData.seedMatchingCommands(nowMs).forEach { cmd ->
            val part = partitions[cmd.instrumentId] ?: return@forEach
            val outcome = part.submit(cmd)
            emitted.addAll(outcome.events)
        }
        dao.insertEngineEvents(emitted.map { it.toEntity() })
        dao.upsertInventories(SyntheticMarketData.seedInventories(nowMs).map { it.toEntity() })
        dao.upsertOffers(SyntheticMarketData.seedOffers(nowMs).map { it.toEntity() })
        dao.upsertRfqs(SyntheticMarketData.seedRfqs(nowMs).map { it.toEntity() })
        dao.upsertContracts(SyntheticMarketData.seedForwardContracts(nowMs).map { it.toEntity() })
        dao.upsertShipments(SyntheticMarketData.seedShipments(nowMs).map { it.toEntity() })
        dao.upsertInvoices(SyntheticMarketData.seedInvoices(nowMs).map { it.toEntity() })
        SyntheticMarketData.seedFuturesPositions(nowMs).forEach { dao.upsertFuturesPosition(it.toEntity()) }
        dao.upsertCollateral(SyntheticMarketData.seedCollateralAccount().toEntity())
        dao.upsertAlerts(SyntheticMarketData.seedAlerts(nowMs).map { it.toEntity() })
        dao.insertAuditLog(
            AuditLogEntity(
                actorOrg = SyntheticMarketData.ORG_AUREOM_DESK,
                actorRole = OrgRole.ADMIN.label,
                action = "SYSTEM_SEED",
                targetId = "AUREOM-TERMINAL",
                detail = "Initialized synthetic wholesale consumer goods markets (${emitted.size} engine events).",
                timestampMs = nowMs,
            )
        )
        publishEngineSnapshot(emitted.size, nowMs)
    }

    /**
     * Reconstructs exact matching engine state from the persisted Room engine_events log (restart recovery).
     */
    suspend fun reconstructFromPersistedEvents(): EngineSnapshot {
        val nowMs = System.currentTimeMillis()
        val events = dao.getAllEngineEvents().map { it.toDomain() }
        reconstructPartitionsFromEventLog(events, nowMs)
        dao.insertAuditLog(
            AuditLogEntity(
                actorOrg = SyntheticMarketData.ORG_AUREOM_DESK,
                actorRole = OrgRole.ADMIN.label,
                action = "ENGINE_REPLAY",
                targetId = "EVENT-LOG",
                detail = "Replayed ${events.size} committed engine events and reconstructed order books.",
                timestampMs = nowMs,
            )
        )
        return _engineSnapshot.value
    }

    private fun reconstructPartitionsFromEventLog(events: List<EngineEvent>, nowMs: Long) {
        val instrList = _instruments.value
        partitions.clear()
        instrList.forEach { partitions[it.id] = MatchingPartition(it) }
        events.forEach { evt ->
            partitions[evt.instrumentId]?.replayEvent(evt)
        }
        publishEngineSnapshot(events.size, nowMs)
    }

    private fun publishEngineSnapshot(eventCount: Int, nowMs: Long) {
        val orders = partitions.values.flatMap { it.allOrders() }.sortedByDescending { it.sequenceNumber }
        val trades = partitions.values.flatMap { it.allTrades() }.sortedByDescending { it.sequenceNumber }
        val bids = partitions.mapValues { (_, p) -> p.bidLadder(6) }
        val asks = partitions.mapValues { (_, p) -> p.askLadder(6) }
        val suspended = partitions.filterValues { it.isMarketSuspended() }.keys
        _engineSnapshot.value = EngineSnapshot(
            orders = orders,
            trades = trades,
            bidsByInstrument = bids,
            asksByInstrument = asks,
            suspendedInstruments = suspended,
            eventCount = eventCount,
            lastReconstructedAtMs = nowMs,
        )
        // Update instrument reference spot price from last trade if available
        _instruments.value = _instruments.value.map { inst ->
            val part = partitions[inst.id]
            if (part != null) {
                inst.copy(
                    referenceSpotPrice = part.currentLastPrice(),
                    isSuspended = part.isMarketSuspended(),
                    lastUpdatedMs = nowMs,
                )
            } else inst
        }
    }

    suspend fun placeSpotLimitOrder(
        instrumentId: String,
        orgId: String,
        role: OrgRole,
        side: OrderSide,
        limitPrice: BigDecimal,
        quantity: Long,
        clientCommandId: String = "CMD-${UUID.randomUUID().toString().take(8)}",
    ): Result<String> {
        if (!role.canPlaceSpotOrders) {
            return Result.failure(IllegalStateException("Role ${role.label} does not have spot order placement permission."))
        }
        val org = _organizations.value.firstOrNull { it.orgId == orgId }
            ?: return Result.failure(IllegalStateException("Unknown organization $orgId"))
        if (org.activityHalted) {
            return Result.failure(IllegalStateException("Organization ${org.name} is currently under an activity halt."))
        }
        val instrument = _instruments.value.firstOrNull { it.id == instrumentId }
            ?: return Result.failure(IllegalStateException("Unknown instrument $instrumentId"))
        if (!instrument.eligibleCounterparties.contains(orgId)) {
            return Result.failure(IllegalStateException("${org.name} is not an eligible counterparty for $instrumentId."))
        }

        val orderNotional = limitPrice.multiply(BigDecimal.valueOf(quantity))
        if (orderNotional > org.orderValueLimitUsd) {
            return Result.failure(IllegalStateException("Order value $$orderNotional exceeds ${org.name} single-order limit ($${org.orderValueLimitUsd})."))
        }
        if (side == OrderSide.BUY && orderNotional > org.availableCreditUsd) {
            recordAlert(
                category = "Credit Check",
                severity = AlertSeverity.CRITICAL,
                title = "Credit limit exceeded on $instrumentId buy order",
                detail = "${org.name} attempted $$orderNotional order with $${org.availableCreditUsd} available credit.",
                relatedRecordId = instrumentId,
            )
            return Result.failure(IllegalStateException("Insufficient credit: available $${org.availableCreditUsd}, required $$orderNotional."))
        }

        // For SELL orders, atomically reserve eligible available inventory first
        var reservedBatch: InventoryBatch? = null
        if (side == OrderSide.SELL) {
            val batches = dao.getAllInventory().map { it.toDomain() }
            val eligible = batches.firstOrNull {
                it.instrumentId == instrumentId &&
                    it.remainingShelfLifeMonths >= instrument.minRemainingShelfLifeMonths &&
                    it.availableQty >= quantity
            }
            if (eligible == null) {
                return Result.failure(
                    IllegalStateException("Insufficient eligible stock (min ${instrument.minRemainingShelfLifeMonths}m shelf life) to reserve $quantity cases.")
                )
            }
            val updatedBatch = eligible.copy(
                availableQty = eligible.availableQty - quantity,
                reservedQty = eligible.reservedQty + quantity,
            )
            dao.upsertInventory(updatedBatch.toEntity())
            reservedBatch = updatedBatch
        }

        val nowMs = System.currentTimeMillis()
        val orderId = "AT-${1050 + (_engineSnapshot.value.orders.size + 1)}"
        val partition = partitions[instrumentId]
            ?: return Result.failure(IllegalStateException("Matching partition unavailable for $instrumentId"))

        val outcome = partition.submit(
            EngineCommand.PlaceLimitOrder(
                clientCommandId = clientCommandId,
                instrumentId = instrumentId,
                timestampMs = nowMs,
                orderId = orderId,
                orgId = org.orgId,
                orgName = org.name,
                traderRole = role.label,
                side = side,
                limitPrice = limitPrice,
                quantity = quantity,
                expiresAtMs = nowMs + 86_400_000L * 3,
            )
        )

        if (!outcome.accepted) {
            // Rollback inventory reservation if engine rejected!
            if (reservedBatch != null) {
                val restored = reservedBatch.copy(
                    availableQty = reservedBatch.availableQty + quantity,
                    reservedQty = (reservedBatch.reservedQty - quantity).coerceAtLeast(0L),
                )
                dao.upsertInventory(restored.toEntity())
            }
            if (outcome.selfTradePrevented) {
                recordAlert(
                    category = "Surveillance (STP)",
                    severity = AlertSeverity.AMBER,
                    title = "Self-trade prevented on ${instrument.productName}",
                    detail = outcome.message,
                    relatedRecordId = instrumentId,
                )
            }
            return Result.failure(IllegalStateException(outcome.message))
        }

        if (outcome.events.isNotEmpty()) {
            dao.insertEngineEvents(outcome.events.map { it.toEntity() })
        }

        // Update credit if buy order resting or filled
        if (side == OrderSide.BUY) {
            _organizations.value = _organizations.value.map {
                if (it.orgId == orgId) it.copy(usedCreditUsd = it.usedCreditUsd.add(orderNotional)) else it
            }
        }

        // Record audit + update snapshot
        val totalEvents = dao.getAllEngineEvents().size
        publishEngineSnapshot(totalEvents, nowMs)
        dao.insertAuditLog(
            AuditLogEntity(
                actorOrg = org.name,
                actorRole = role.label,
                action = "SPOT_${side.name}_ORDER",
                targetId = orderId,
                detail = outcome.message,
                timestampMs = nowMs,
            )
        )

        // Generate shipment & invoice automatically if any trade executed
        outcome.executedTrades.forEach { trade ->
            createPendingFulfilmentForTrade(trade)
        }

        return Result.success(outcome.message)
    }

    private suspend fun createPendingFulfilmentForTrade(trade: SpotTradeRecord) {
        val nowMs = trade.executionTimestampMs
        val shpId = "SHP-${7700 + (Math.abs(trade.tradeId.hashCode()) % 900)}"
        val shipment = ShipmentRecord(
            shipmentId = shpId,
            referenceId = trade.tradeId,
            instrumentId = trade.instrumentId,
            productName = trade.productName,
            warehouseName = "UK Fulfillment Hub",
            destination = trade.deliveryLocation,
            carrierName = "Pending Carrier Booking",
            trackingNumber = "ALLOC-${trade.tradeId}",
            orderedQty = trade.quantity,
            dispatchedQty = 0L,
            deliveredQty = 0L,
            acceptedQty = 0L,
            rejectedQty = 0L,
            status = ShipmentStatus.ALLOCATED,
            discrepancyReason = "Trade matched; physical dispatch & settlement pending.",
            documents = listOf(
                ProvenanceDocument("DOC-${trade.tradeId}", "Trade Confirmation", "${trade.tradeId}_conf.pdf", "e104ab77", "Aureom Engine", nowMs)
            ),
            lastEventMs = nowMs,
        )
        dao.upsertShipment(shipment.toEntity())
    }

    suspend fun cancelSpotOrder(order: EngineOrder, requestingOrgId: String, role: OrgRole): Result<String> {
        if (!role.canPlaceSpotOrders && !role.canManageRiskAndHalts) {
            return Result.failure(IllegalStateException("Role ${role.label} cannot cancel orders."))
        }
        val partition = partitions[order.instrumentId]
            ?: return Result.failure(IllegalStateException("Missing partition ${order.instrumentId}"))
        val nowMs = System.currentTimeMillis()
        val outcome = partition.submit(
            EngineCommand.CancelOrder(
                clientCommandId = "CXL-${order.orderId}-$nowMs",
                instrumentId = order.instrumentId,
                timestampMs = nowMs,
                orderId = order.orderId,
                requestingOrgId = requestingOrgId,
            )
        )
        if (!outcome.accepted) return Result.failure(IllegalStateException(outcome.message))

        dao.insertEngineEvents(outcome.events.map { it.toEntity() })

        // Release reserved stock if SELL order was cancelled
        val releasedQty = (outcome.events.firstOrNull() as? EngineEvent.OrderCancelled)?.releasedQty ?: 0L
        if (order.side == OrderSide.SELL && releasedQty > 0L) {
            val batch = dao.getAllInventory().map { it.toDomain() }
                .firstOrNull { it.instrumentId == order.instrumentId && it.reservedQty >= releasedQty }
            if (batch != null) {
                dao.upsertInventory(
                    batch.copy(
                        availableQty = batch.availableQty + releasedQty,
                        reservedQty = batch.reservedQty - releasedQty,
                    ).toEntity()
                )
            }
        } else if (order.side == OrderSide.BUY && releasedQty > 0L) {
            val releaseCredit = order.limitPrice.multiply(BigDecimal.valueOf(releasedQty))
            _organizations.value = _organizations.value.map {
                if (it.orgId == order.orgId) it.copy(usedCreditUsd = (it.usedCreditUsd.subtract(releaseCredit)).coerceAtLeast(BigDecimal.ZERO))
                else it
            }
        }

        publishEngineSnapshot(dao.getAllEngineEvents().size, nowMs)
        return Result.success(outcome.message)
    }

    suspend fun toggleMarketSuspension(instrumentId: String, suspend: Boolean, role: OrgRole): Result<String> {
        if (!role.canManageRiskAndHalts) {
            return Result.failure(IllegalStateException("Only Risk Manager or Administrator can suspend/resume markets."))
        }
        val part = partitions[instrumentId] ?: return Result.failure(IllegalStateException("Unknown instrument"))
        val nowMs = System.currentTimeMillis()
        val cmd = if (suspend) {
            EngineCommand.SuspendMarket("SUSP-$instrumentId-$nowMs", instrumentId, nowMs, "Risk Manager manual market halt")
        } else {
            EngineCommand.ResumeMarket("RES-$instrumentId-$nowMs", instrumentId, nowMs)
        }
        val outcome = part.submit(cmd)
        dao.insertEngineEvents(outcome.events.map { it.toEntity() })
        publishEngineSnapshot(dao.getAllEngineEvents().size, nowMs)
        return Result.success(outcome.message)
    }

    // --- Firm Offers (Wholesale Offer Board with Atomic Inventory Reservation) ---
    suspend fun publishOffer(
        instrumentId: String,
        sellerOrgId: String,
        isFirm: Boolean,
        unitPrice: BigDecimal,
        quantity: Long,
        role: OrgRole,
    ): Result<FirmOfferRecord> {
        if (!role.canPlaceSpotOrders) return Result.failure(IllegalStateException("Role ${role.label} cannot publish offers."))
        val inst = _instruments.value.firstOrNull { it.id == instrumentId }
            ?: return Result.failure(IllegalStateException("Unknown instrument"))
        val seller = _organizations.value.firstOrNull { it.orgId == sellerOrgId }
            ?: return Result.failure(IllegalStateException("Unknown seller"))

        var reservedBatchId: String? = null
        if (isFirm) {
            val batch = dao.getAllInventory().map { it.toDomain() }
                .firstOrNull { it.instrumentId == instrumentId && it.availableQty >= quantity }
                ?: return Result.failure(IllegalStateException("Insufficient available stock to back firm offer ($quantity cases)."))
            dao.upsertInventory(
                batch.copy(availableQty = batch.availableQty - quantity, reservedQty = batch.reservedQty + quantity).toEntity()
            )
            reservedBatchId = batch.batchId
        }

        val nowMs = System.currentTimeMillis()
        val offer = FirmOfferRecord(
            offerId = "OFR-${903 + (nowMs % 900)}",
            instrumentId = instrumentId,
            sellerOrgId = sellerOrgId,
            sellerOrgName = seller.name,
            isFirm = isFirm,
            unitPrice = unitPrice.setScale(inst.currency.scale, RoundingMode.HALF_EVEN),
            totalQty = quantity,
            remainingQty = quantity,
            reservedBatchId = reservedBatchId,
            currency = inst.currency,
            location = inst.deliveryLocation,
            deliveryTerms = "${inst.termAndPlace} • ${inst.dispatchLeadDays}",
            expiresAtMs = nowMs + 86_400_000L * 2,
            status = "ACTIVE",
            createdAtMs = nowMs,
        )
        dao.upsertOffer(offer.toEntity())
        dao.insertAuditLog(AuditLogEntity(0, seller.name, role.label, if (isFirm) "PUBLISH_FIRM_OFFER" else "PUBLISH_INDICATIVE_OFFER", offer.offerId, "${offer.totalQty} cases @ ${offer.unitPrice}", nowMs))
        return Result.success(offer)
    }

    suspend fun acceptFirmOfferPartial(offerId: String, buyerOrgId: String, qtyToBuy: Long, role: OrgRole): Result<String> {
        if (!role.canPlaceSpotOrders) return Result.failure(IllegalStateException("Role ${role.label} cannot lift offers."))
        val existing = dao.getOfferById(offerId)?.toDomain()
            ?: return Result.failure(IllegalStateException("Offer $offerId not found"))
        if (!existing.isFirm) {
            return Result.failure(IllegalStateException("Indicative offer $offerId is non-executable; submit an RFQ instead."))
        }
        if (qtyToBuy <= 0L || qtyToBuy > existing.remainingQty) {
            return Result.failure(IllegalStateException("Requested $qtyToBuy exceeds remaining firm offer qty (${existing.remainingQty})."))
        }
        val buyer = _organizations.value.firstOrNull { it.orgId == buyerOrgId }
            ?: return Result.failure(IllegalStateException("Unknown buyer"))
        val notional = existing.unitPrice.multiply(BigDecimal.valueOf(qtyToBuy))
        if (notional > buyer.availableCreditUsd) {
            return Result.failure(IllegalStateException("Buyer credit insufficient ($${buyer.availableCreditUsd} available vs $$notional)."))
        }

        val nowMs = System.currentTimeMillis()
        val newRem = existing.remainingQty - qtyToBuy
        val updatedOffer = existing.copy(
            remainingQty = newRem,
            status = if (newRem == 0L) "FILLED" else "PARTIALLY_TAKEN",
        )
        dao.upsertOffer(updatedOffer.toEntity())

        // Convert reserved stock into allocated shipment without overselling
        existing.reservedBatchId?.let { bId ->
            dao.getAllInventory().map { it.toDomain() }.firstOrNull { it.batchId == bId }?.let { batch ->
                dao.upsertInventory(batch.copy(reservedQty = (batch.reservedQty - qtyToBuy).coerceAtLeast(0L)).toEntity())
            }
        }
        _organizations.value = _organizations.value.map {
            if (it.orgId == buyerOrgId) it.copy(usedCreditUsd = it.usedCreditUsd.add(notional)) else it
        }

        val trdId = "TRD-OFR-${(nowMs % 10000)}"
        val shp = ShipmentRecord(
            shipmentId = "SHP-${(nowMs % 9000) + 1000}",
            referenceId = trdId,
            instrumentId = existing.instrumentId,
            productName = _instruments.value.firstOrNull { it.id == existing.instrumentId }?.productName ?: existing.instrumentId,
            warehouseName = "Leeds Central DC",
            destination = existing.location,
            carrierName = "Northshore Fleet",
            trackingNumber = "NS-${(nowMs % 99999)}",
            orderedQty = qtyToBuy,
            dispatchedQty = 0L,
            deliveredQty = 0L,
            acceptedQty = 0L,
            rejectedQty = 0L,
            status = ShipmentStatus.ALLOCATED,
            discrepancyReason = "Firm offer $offerId lifted ($qtyToBuy cases). Shipment & invoice pending.",
            documents = listOf(ProvenanceDocument("DOC-$trdId", "Firm Offer Trade Note", "${trdId}.pdf", "c4a912f0", buyer.name, nowMs)),
            lastEventMs = nowMs,
        )
        dao.upsertShipment(shp.toEntity())
        dao.insertAuditLog(AuditLogEntity(0, buyer.name, role.label, "LIFT_FIRM_OFFER", offerId, "Purchased $qtyToBuy/${existing.totalQty} cases @ ${existing.unitPrice}", nowMs))
        return Result.success("Purchased $qtyToBuy cases from $offerId ($trdId); $newRem cases remain reserved.")
    }

    // --- RFQs & Forward Contracts ---
    suspend fun createRfq(
        instrumentId: String,
        requesterOrgId: String,
        qty: Long,
        targetPrice: BigDecimal?,
        deliveryPeriod: String,
        destination: String,
    ): RfqRecord {
        val nowMs = System.currentTimeMillis()
        val inst = _instruments.value.first { it.id == instrumentId }
        val org = _organizations.value.first { it.orgId == requesterOrgId }
        val rfq = RfqRecord(
            rfqId = "RFQ-${4410 + (nowMs % 500)}",
            requesterOrgId = requesterOrgId,
            requesterOrgName = org.name,
            instrumentId = instrumentId,
            productName = "${inst.productName} (${inst.packaging.description})",
            side = OrderSide.BUY,
            targetQty = qty,
            targetPrice = targetPrice,
            currency = inst.currency,
            deliveryPeriod = deliveryPeriod,
            destination = destination,
            tradeTerm = inst.tradeTerm,
            minShelfLifeMonths = inst.minRemainingShelfLifeMonths,
            status = RfqStatus.QUOTED,
            quotes = listOf(
                RfqQuote("QT-${(nowMs % 900) + 10}", SyntheticMarketData.ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", (targetPrice ?: inst.referenceSpotPrice).add(bd("0.20")), qty, inst.termAndPlace, nowMs + 86_400_000L, "Includes batch COA & pallet wrap")
            ),
            createdAtMs = nowMs,
        )
        dao.upsertRfq(rfq.toEntity())
        return rfq
    }

    suspend fun createForwardFromRfq(rfq: RfqRecord, quote: RfqQuote, creatorRole: OrgRole): ForwardContract {
        val nowMs = System.currentTimeMillis()
        val inst = _instruments.value.firstOrNull { it.id == rfq.instrumentId }
        val contract = ForwardContract(
            contractId = "FWD-${2090 + (nowMs % 800)}",
            instrumentId = rfq.instrumentId,
            productSpec = "${rfq.productName} • ${inst?.skuOrSpec ?: "SPEC"}",
            buyerOrgId = rfq.requesterOrgId,
            buyerOrgName = rfq.requesterOrgName,
            sellerOrgId = quote.supplierOrgId,
            sellerOrgName = quote.supplierOrgName,
            contractedQty = rfq.targetQty,
            tolerancePct = bd("5.0"),
            pricingBasis = "FIXED",
            fixedOrFormulaPrice = quote.quotedPrice,
            currency = rfq.currency,
            deliveryWindowStart = "2027-02-10",
            deliveryWindowEnd = "2027-02-20",
            deliveryLocation = rfq.destination,
            tradeTerms = quote.tradeTerm,
            paymentSchedule = "Net 30 days from POD acceptance",
            creditSupportTerms = "10% Buyer credit reserve held against facility",
            inspectionAndAcceptanceTerms = "48h dock inspection + COA verification",
            shortDeliveryAndRejectionTerms = "Pro-rata credit note or 5-day replacement",
            cancellationAndDefaultTerms = "Replacement spread + documented haulage",
            disputeResolutionTerms = "LCIA Expedited Commercial Arbitration",
            signedVersion = 1,
            createdByRole = creatorRole.label,
            approvedByRole = null,
            status = ForwardContractStatus.PENDING_APPROVAL,
            allocatedQty = 0L,
            dispatchedQty = 0L,
            deliveredQty = 0L,
            acceptedQty = 0L,
            amendments = emptyList(),
            createdAtMs = nowMs,
        )
        dao.upsertRfq(rfq.copy(status = RfqStatus.CONVERTED).toEntity())
        dao.upsertContract(contract.toEntity())
        return contract
    }

    suspend fun approveAndAcceptForward(contract: ForwardContract, actorRole: OrgRole): Result<ForwardContract> {
        if (!actorRole.canApproveContracts) {
            return Result.failure(IllegalStateException("Role ${actorRole.label} does not have contract approval permission."))
        }
        // Segregation of Duties check
        if (actorRole.label == contract.createdByRole && actorRole != OrgRole.ADMIN) {
            return Result.failure(
                IllegalStateException("Segregation of Duties: ${actorRole.label} created this contract; an Approver or Procurement/Sales Manager must counter-approve.")
            )
        }
        val nowMs = System.currentTimeMillis()
        val updated = contract.copy(
            approvedByRole = actorRole.label,
            status = ForwardContractStatus.ACCEPTED,
            allocatedQty = contract.contractedQty,
        )
        dao.upsertContract(updated.toEntity())
        dao.insertAuditLog(AuditLogEntity(0, contract.buyerOrgName, actorRole.label, "APPROVE_ACCEPT_FORWARD", contract.contractId, "Signed v${contract.signedVersion} accepted by ${actorRole.label}", nowMs))
        return Result.success(updated)
    }

    suspend fun proposeAndSignAmendment(
        contract: ForwardContract,
        summary: String,
        newPrice: BigDecimal?,
        newQty: Long?,
        actorRole: OrgRole,
    ): Result<ForwardContract> {
        if (!actorRole.canApproveContracts && actorRole != OrgRole.TRADER) {
            return Result.failure(IllegalStateException("Role ${actorRole.label} cannot amend contracts."))
        }
        val nowMs = System.currentTimeMillis()
        val nextVer = contract.signedVersion + 1
        val amend = ForwardAmendment(
            amendmentId = "AMD-${nextVer}-${(nowMs % 1000)}",
            versionNumber = nextVer,
            proposedByOrg = contract.buyerOrgName,
            summary = summary,
            newPrice = newPrice,
            newQty = newQty,
            newDeliveryWindow = null,
            buyerApproved = true,
            sellerApproved = actorRole.canApproveContracts,
            timestampMs = nowMs,
        )
        val bothSigned = amend.buyerApproved && amend.sellerApproved
        val updated = contract.copy(
            fixedOrFormulaPrice = if (bothSigned && newPrice != null) newPrice else contract.fixedOrFormulaPrice,
            contractedQty = if (bothSigned && newQty != null) newQty else contract.contractedQty,
            signedVersion = if (bothSigned) nextVer else contract.signedVersion,
            status = if (bothSigned) ForwardContractStatus.ACCEPTED else ForwardContractStatus.AMENDMENT_PENDING,
            amendments = contract.amendments + amend,
        )
        dao.upsertContract(updated.toEntity())
        return Result.success(updated)
    }

    // --- Deliveries & Finance Reconciliation ---
    suspend fun recordPartialDelivery(shipment: ShipmentRecord, deliverNowQty: Long, acceptNowQty: Long, role: OrgRole): Result<ShipmentRecord> {
        if (!role.canManageInventory && role != OrgRole.ADMIN) {
            return Result.failure(IllegalStateException("Only Warehouse Operator or Admin can record deliveries."))
        }
        val nowMs = System.currentTimeMillis()
        val newDelivered = (shipment.deliveredQty + deliverNowQty).coerceAtMost(shipment.orderedQty)
        val newAccepted = (shipment.acceptedQty + acceptNowQty).coerceAtMost(newDelivered)
        val rejected = (newDelivered - newAccepted).coerceAtLeast(0L)
        val newStatus = when {
            rejected > 0 -> ShipmentStatus.DISCREPANCY
            newAccepted >= shipment.orderedQty -> ShipmentStatus.ACCEPTED
            else -> ShipmentStatus.PART_DELIVERED
        }
        val reason = if (newAccepted < shipment.orderedQty) {
            "Accepted $newAccepted of ${shipment.orderedQty} ordered (${shipment.orderedQty - newAccepted} short / pending)."
        } else null

        val updated = shipment.copy(
            dispatchedQty = maxOf(shipment.dispatchedQty, newDelivered),
            deliveredQty = newDelivered,
            acceptedQty = newAccepted,
            rejectedQty = rejected,
            status = newStatus,
            discrepancyReason = reason,
            documents = shipment.documents + ProvenanceDocument("POD-${nowMs % 9999}", "Proof of Delivery", "POD_${shipment.shipmentId}.pdf", "7b22f09a", "Warehouse Operator", nowMs),
            lastEventMs = nowMs,
        )
        dao.upsertShipment(updated.toEntity())

        // Sync linked forward contract quantities if applicable
        dao.getAllContracts().map { it.toDomain() }.firstOrNull { it.contractId == shipment.referenceId }?.let { fc ->
            dao.upsertContract(
                fc.copy(
                    dispatchedQty = updated.dispatchedQty,
                    deliveredQty = updated.deliveredQty,
                    acceptedQty = updated.acceptedQty,
                    status = if (updated.acceptedQty >= fc.contractedQty) ForwardContractStatus.COMPLETED else ForwardContractStatus.PARTIALLY_DELIVERED,
                ).toEntity()
            )
        }

        // Issue or update commercial invoice based on accepted quantity
        val inst = _instruments.value.firstOrNull { it.id == shipment.instrumentId }
        val unitPrice = inst?.referenceSpotPrice ?: bd("30.00")
        val net = unitPrice.multiply(BigDecimal.valueOf(newAccepted))
        val tax = net.multiply(bd("0.20")).setScale(2, RoundingMode.HALF_EVEN)
        val gross = net.add(tax).setScale(2, RoundingMode.HALF_EVEN)
        val inv = CommercialInvoice(
            invoiceId = "INV-${shipment.shipmentId.takeLast(4)}",
            referenceId = shipment.referenceId,
            shipmentId = shipment.shipmentId,
            counterpartyName = "Northshore Consumer Supply",
            invoicedQty = updated.deliveredQty,
            acceptedQty = updated.acceptedQty,
            unitPrice = unitPrice,
            taxAmount = tax,
            grossAmount = gross,
            paidAmount = BigDecimal.ZERO,
            settlementCurrency = inst?.currency ?: CurrencyCode.USD,
            bankAccountMask = "GB88 •••• 9102",
            status = if (updated.deliveredQty != updated.acceptedQty || updated.acceptedQty < updated.orderedQty) {
                InvoiceStatus.DISCREPANCY_HOLD
            } else InvoiceStatus.ISSUED,
            issuedAtMs = nowMs,
        )
        dao.upsertInvoice(inv.toEntity())
        return Result.success(updated)
    }

    suspend fun reconcileAndPayInvoice(invoice: CommercialInvoice, payAmount: BigDecimal, role: OrgRole): Result<CommercialInvoice> {
        if (!role.canReconcileFinance) {
            return Result.failure(IllegalStateException("Only Finance Analyst or Admin can reconcile & settle invoices."))
        }
        val net = invoice.unitPrice.multiply(BigDecimal.valueOf(invoice.acceptedQty))
        val recalculatedGross = net.add(net.multiply(bd("0.20"))).setScale(invoice.settlementCurrency.scale, RoundingMode.HALF_EVEN)
        val newPaid = (invoice.paidAmount.add(payAmount)).coerceAtMost(recalculatedGross)
        val newStatus = if (newPaid >= recalculatedGross) InvoiceStatus.RECONCILED else InvoiceStatus.PART_PAID
        val updated = invoice.copy(
            invoicedQty = invoice.acceptedQty,
            grossAmount = recalculatedGross,
            paidAmount = newPaid,
            status = newStatus,
        )
        dao.upsertInvoice(updated.toEntity())
        dao.insertAuditLog(AuditLogEntity(0, "Finance Desk", role.label, "RECONCILE_INVOICE", updated.invoiceId, "Paid ${updated.paidAmount} / ${updated.grossAmount} (${updated.status.label})", System.currentTimeMillis()))
        return Result.success(updated)
    }

    // --- Futures Simulation Operations ---
    suspend fun placeSimulatedFuturesOrder(contractCode: String, side: OrderSide, contracts: Int): Result<String> {
        val spec = _futuresSpecs.value.firstOrNull { it.contractCode == contractCode }
            ?: return Result.failure(IllegalStateException("Unknown futures spec $contractCode"))
        val existing = dao.getAllFuturesPositions().map { it.toDomain() }.firstOrNull { it.contractCode == contractCode }
        val account = dao.getCollateral()?.toDomain() ?: SyntheticMarketData.seedCollateralAccount()
        val nowMs = System.currentTimeMillis()
        val (updatedPos, fee) = FuturesSimulationEngine.openOrAdjustPosition(
            existing = existing,
            accountId = account.accountId,
            spec = spec,
            side = side,
            contracts = contracts,
            executionPrice = spec.currentMarkPrice,
            nowMs = nowMs,
        )
        val absPos = kotlin.math.abs(updatedPos.netContracts)
        if (absPos > spec.positionLimitContracts) {
            return Result.failure(IllegalStateException("Exceeds position limit (${spec.positionLimitContracts} contracts)."))
        }
        dao.upsertFuturesPosition(updatedPos.toEntity())
        dao.upsertCollateral(account.copy(feesCharged = account.feesCharged.add(fee)).toEntity())
        return Result.success("Simulated ${side.label} $contracts $contractCode @ ${spec.currentMarkPrice} (Illustrative demo only).")
    }

    suspend fun runFuturesDailySettlement(contractCode: String, newMarkPrice: BigDecimal, settlementDate: String): Result<DailySettlementResult> {
        val spec = _futuresSpecs.value.firstOrNull { it.contractCode == contractCode }
            ?: return Result.failure(IllegalStateException("Unknown spec"))
        val pos = dao.getAllFuturesPositions().map { it.toDomain() }.firstOrNull { it.contractCode == contractCode }
            ?: return Result.failure(IllegalStateException("No open position for $contractCode"))
        val account = dao.getCollateral()?.toDomain() ?: SyntheticMarketData.seedCollateralAccount()
        val nowMs = System.currentTimeMillis()

        val (updatedPos, updatedAcc, result) = FuturesSimulationEngine.runDailyVariationSettlement(
            position = pos,
            spec = spec,
            account = account,
            newSettlementPrice = newMarkPrice,
            settlementDate = settlementDate,
            nowMs = nowMs,
        )
        dao.upsertFuturesPosition(updatedPos.toEntity())
        dao.upsertCollateral(updatedAcc.toEntity())
        _futuresSpecs.value = _futuresSpecs.value.map {
            if (it.contractCode == contractCode) it.copy(currentMarkPrice = newMarkPrice, priorSettlementPrice = newMarkPrice) else it
        }
        _lastSettlement.value = result

        if (result.status.name == "MARGIN_CALL" || result.status.name == "LIQUIDATION_SHORTFALL") {
            recordAlert(
                category = "Simulated Margin Call",
                severity = AlertSeverity.CRITICAL,
                title = "Margin shortfall on $contractCode",
                detail = "Equity $${result.newEquity} fell below maintenance $${result.maintenanceMarginRequired}.",
                relatedRecordId = contractCode,
            )
        }
        return Result.success(result)
    }

    suspend fun runMarginStressAndInsufficientLiquidityDemo(contractCode: String = "HOMECARE-MAR27"): Pair<DailySettlementResult, ForcedReductionResult> {
        val spec = _futuresSpecs.value.first { it.contractCode == contractCode }
        var pos = dao.getAllFuturesPositions().map { it.toDomain() }.firstOrNull { it.contractCode == contractCode }
        if (pos == null || pos.netContracts == 0) {
            placeSimulatedFuturesOrder(contractCode, OrderSide.BUY, 16)
            pos = dao.getAllFuturesPositions().map { it.toDomain() }.first { it.contractCode == contractCode }
        } else if (kotlin.math.abs(pos.netContracts) < 16) {
            placeSimulatedFuturesOrder(contractCode, OrderSide.BUY, 16 - kotlin.math.abs(pos.netContracts))
            pos = dao.getAllFuturesPositions().map { it.toDomain() }.first { it.contractCode == contractCode }
        }
        // Adverse shock price causing variation margin loss exceeding maintenance margin
        val shockPrice = spec.currentMarkPrice.subtract(bd("5.80")).max(bd("20.00"))
        val settleRes = runFuturesDailySettlement(contractCode, shockPrice, "2026-11-15").getOrThrow()
        val updatedPos = dao.getAllFuturesPositions().map { it.toDomain() }.first { it.contractCode == contractCode }
        val updatedAcc = dao.getCollateral()?.toDomain() ?: SyntheticMarketData.seedCollateralAccount()
        val reduction = FuturesSimulationEngine.simulateForcedReduction(
            position = updatedPos,
            spec = _futuresSpecs.value.first { it.contractCode == contractCode },
            account = updatedAcc,
            contractsToReduce = 15, // Exceeds simulated bid book depth (12 contracts) -> demonstrates insufficient liquidity!
        )
        _lastForcedReduction.value = reduction
        return settleRes to reduction
    }

    suspend fun recordAlert(
        category: String,
        severity: AlertSeverity,
        title: String,
        detail: String,
        relatedRecordId: String,
    ) {
        val nowMs = System.currentTimeMillis()
        dao.upsertAlert(
            SurveillanceAlert(
                alertId = "ALT-${nowMs % 100000}",
                category = category,
                severity = severity,
                title = title,
                detail = detail,
                relatedRecordId = relatedRecordId,
                timestampMs = nowMs,
            ).toEntity()
        )
    }

    suspend fun acknowledgeAlert(alert: SurveillanceAlert) {
        dao.upsertAlert(alert.copy(acknowledged = true).toEntity())
    }

    suspend fun requestBankDetailChange(orgId: String, newMask: String, role: OrgRole): Result<String> {
        if (!role.canReconcileFinance && !role.canAdministerOrgs) {
            return Result.failure(IllegalStateException("Only Finance Analyst or Administrator can initiate bank changes."))
        }
        _organizations.value = _organizations.value.map {
            if (it.orgId == orgId) it.copy(pendingBankChangeRequest = newMask) else it
        }
        return Result.success("Dual-control bank change staged for $newMask (awaiting second approver).")
    }

    suspend fun approveBankDetailChange(orgId: String, role: OrgRole): Result<String> {
        if (!role.canAdministerOrgs && !role.canApproveContracts) {
            return Result.failure(IllegalStateException("Approver or Admin required for dual-control bank confirmation."))
        }
        _organizations.value = _organizations.value.map {
            if (it.orgId == orgId && it.pendingBankChangeRequest != null) {
                it.copy(bankDetailsMask = it.pendingBankChangeRequest, pendingBankChangeRequest = null)
            } else it
        }
        return Result.success("Bank settlement instructions updated with dual-control audit.")
    }

    suspend fun toggleOrgHalt(orgId: String, halt: Boolean, role: OrgRole): Result<String> {
        if (!role.canManageRiskAndHalts) {
            return Result.failure(IllegalStateException("Risk Manager or Admin required for activity halt."))
        }
        _organizations.value = _organizations.value.map {
            if (it.orgId == orgId) it.copy(activityHalted = halt) else it
        }
        return Result.success(if (halt) "Activity halt enabled on $orgId (new orders blocked; existing obligations manageable)." else "Activity halt lifted on $orgId.")
    }

    suspend fun savePref(key: String, value: String) {
        dao.upsertPref(WorkspacePrefEntity(key, value))
    }

    suspend fun loadPrefs(): Map<String, String> = dao.getPrefs().associate { it.prefKey to it.prefValue }

    /**
     * Executes the complete 12-step Section 18 demonstration workflow end-to-end against persisted Room storage.
     */
    suspend fun runComplete12StepDemonstration(): List<DemoStepStatus> {
        // 1. Distributor publishes firm wholesale offer
        val offer = publishOffer("LAUNDRY-LIQ-UK-DEC26", SyntheticMarketData.ORG_NORTHSHORE_SUPPLY, true, bd("36.20"), 200L, OrgRole.SALES_MANAGER).getOrNull()
        // 2 & 3. Retailer purchases part of available quantity without overselling
        if (offer != null) {
            acceptFirmOfferPartial(offer.offerId, SyntheticMarketData.ORG_PENNINE_RETAIL, 80L, OrgRole.TRADER)
        }
        // 4 & 5. Second buyer negotiates forward & approves/accepts
        val rfq = createRfq("BODY-WASH-UK-DEC26", SyntheticMarketData.ORG_VANGUARD_GROCERS, 300L, bd("28.75"), "Feb 2027", "Leeds, United Kingdom")
        val fwd = createForwardFromRfq(rfq, rfq.quotes.first(), OrgRole.TRADER)
        val acceptedFwd = approveAndAcceptForward(fwd, OrgRole.APPROVER).getOrNull()
        // 6. User opens simulated futures position
        placeSimulatedFuturesOrder("HOMECARE-MAR27", OrderSide.BUY, 4)
        // 7 & 8. Daily settlement + margin shortfall scenario
        val (settle, reduction) = runMarginStressAndInsufficientLiquidityDemo("HOMECARE-MAR27")
        // 9. Partial physical delivery
        val shp = ShipmentRecord(
            shipmentId = "SHP-DEMO-901",
            referenceId = acceptedFwd?.contractId ?: "FWD-DEMO",
            instrumentId = "BODY-WASH-UK-DEC26",
            productName = "Body wash (24 × 250 ml)",
            warehouseName = "Manchester North Hub",
            destination = "Leeds, United Kingdom",
            carrierName = "Pennine Freight Logistics",
            trackingNumber = "PFL-DEMO-901",
            orderedQty = 300L,
            dispatchedQty = 200L,
            deliveredQty = 0L,
            acceptedQty = 0L,
            rejectedQty = 0L,
            status = ShipmentStatus.DISPATCHED,
            discrepancyReason = null,
            documents = emptyList(),
            lastEventMs = System.currentTimeMillis(),
        )
        dao.upsertShipment(shp.toEntity())
        recordPartialDelivery(shp, 200L, 180L, OrgRole.WAREHOUSE_OPERATOR)
        // 10. Finance reconciles quantities, invoices and payments
        val invId = "INV-DEMO".take(3) + "-0901"
        val demoInv = CommercialInvoice(invId, shp.referenceId, shp.shipmentId, "Northshore Consumer Supply", 200L, 180L, bd("28.75"), bd("1035.00"), bd("6210.00"), BigDecimal.ZERO, CurrencyCode.USD, "GB88 •••• 9102", InvoiceStatus.DISCREPANCY_HOLD, System.currentTimeMillis())
        dao.upsertInvoice(demoInv.toEntity())
        reconcileAndPayInvoice(demoInv, demoInv.grossAmount, OrgRole.FINANCE_ANALYST)
        // 12. Reconstruct consistent engine state from event log
        val replaySnap = reconstructFromPersistedEvents()

        return listOf(
            DemoStepStatus(1, "Distributor publishes firm offer", "Atomic stock reserved on Leeds DC", offer != null, offer?.offerId),
            DemoStepStatus(2, "Retailer purchases partial qty", "80 of 200 cases purchased", offer != null, offer?.offerId),
            DemoStepStatus(3, "Inventory reserved without overselling", "120 cases remain reserved on offer", true, "BATCH-LL-2026-A"),
            DemoStepStatus(4, "Second buyer negotiates forward", "RFQ converted to ${fwd.contractId}", true, fwd.contractId),
            DemoStepStatus(5, "Contract approved & accepted", "Dual-control sign-off by Approver", acceptedFwd != null, acceptedFwd?.contractId),
            DemoStepStatus(6, "Simulated futures position opened", "Long HOMECARE-MAR27 (demo)", true, "HOMECARE-MAR27"),
            DemoStepStatus(7, "Daily variation settlement", "Settled @ $${settle.newSettlementPrice}; basis reset", true, settle.settlementDate),
            DemoStepStatus(8, "Margin shortfall & thin liquidity", "${reduction.executedContractsClosed}/${reduction.requestedContractsToClose} liquidated; $${reduction.residualMarginShortfall} shortfall", reduction.liquidityInsufficient, "MARGIN-SHOCK"),
            DemoStepStatus(9, "Physical shipment part-delivered", "180 accepted / 200 delivered / 300 ordered", true, shp.shipmentId),
            DemoStepStatus(10, "Finance reconciles invoice & pay", "Adjusted to 180 accepted cases & settled", true, invId),
            DemoStepStatus(11, "Procurement coverage & basis risk", "Physical vs financial hedge gap updated", true, "COVERAGE"),
            DemoStepStatus(12, "Restart & event replay consistency", "Replayed ${replaySnap.eventCount} engine events", replaySnap.eventCount > 0, "${replaySnap.eventCount} EVTS"),
        )
    }

    suspend fun resetAllDemoData() {
        dao.clearEngineEvents()
        dao.clearInventory()
        dao.clearOffers()
        dao.clearRfqs()
        dao.clearContracts()
        dao.clearShipments()
        dao.clearInvoices()
        dao.clearFuturesPositions()
        dao.clearCollateral()
        dao.clearAlerts()
        seedFreshDatabase(System.currentTimeMillis())
    }
}
