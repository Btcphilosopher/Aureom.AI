package com.example.engine

import com.example.domain.model.DailySettlementResult
import com.example.domain.model.ForcedReductionResult
import com.example.domain.model.FuturesCollateralAccount
import com.example.domain.model.FuturesContractSpec
import com.example.domain.model.FuturesPosition
import com.example.domain.model.MarginHealthStatus
import com.example.domain.model.OrderSide
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs

/**
 * Isolated Futures Simulation Engine (Demo only — live trading disabled without authorised venue/broker/clearing).
 * Uses exact BigDecimal arithmetic and explicit contract multipliers.
 * Resets settlementBasisPrice during daily variation settlement so P&L is never double-counted.
 */
object FuturesSimulationEngine {

    fun openOrAdjustPosition(
        existing: FuturesPosition?,
        accountId: String,
        spec: FuturesContractSpec,
        side: OrderSide,
        contracts: Int,
        executionPrice: BigDecimal,
        feePerContract: BigDecimal = BigDecimal("4.50"),
        nowMs: Long,
    ): Pair<FuturesPosition, BigDecimal> {
        require(contracts > 0) { "Contracts must be positive" }
        val signedDelta = if (side == OrderSide.BUY) contracts else -contracts
        val fee = feePerContract.multiply(BigDecimal.valueOf(contracts.toLong())).setScale(2, RoundingMode.HALF_EVEN)

        if (existing == null || existing.netContracts == 0) {
            val pos = FuturesPosition(
                positionId = existing?.positionId ?: "FUT-POS-${spec.contractCode}",
                accountId = accountId,
                contractCode = spec.contractCode,
                displayTitle = spec.displayTitle,
                netContracts = signedDelta,
                closedContracts = existing?.closedContracts ?: 0,
                avgEntryPrice = executionPrice.setScale(2, RoundingMode.HALF_EVEN),
                settlementBasisPrice = executionPrice.setScale(2, RoundingMode.HALF_EVEN),
                realisedPnL = existing?.realisedPnL ?: BigDecimal.ZERO,
                cumulativeVariationSettled = existing?.cumulativeVariationSettled ?: BigDecimal.ZERO,
                tradingFeesPaid = (existing?.tradingFeesPaid ?: BigDecimal.ZERO).add(fee),
                updatedAtMs = nowMs,
            )
            return pos to fee
        }

        val currentQty = existing.netContracts
        val sameDirection = (currentQty > 0 && signedDelta > 0) || (currentQty < 0 && signedDelta < 0)

        return if (sameDirection) {
            val totalAbs = abs(currentQty) + contracts
            val newAvg = existing.avgEntryPrice.multiply(BigDecimal.valueOf(abs(currentQty).toLong()))
                .add(executionPrice.multiply(BigDecimal.valueOf(contracts.toLong())))
                .divide(BigDecimal.valueOf(totalAbs.toLong()), 4, RoundingMode.HALF_EVEN)
                .setScale(2, RoundingMode.HALF_EVEN)
            val newBasis = existing.settlementBasisPrice.multiply(BigDecimal.valueOf(abs(currentQty).toLong()))
                .add(executionPrice.multiply(BigDecimal.valueOf(contracts.toLong())))
                .divide(BigDecimal.valueOf(totalAbs.toLong()), 4, RoundingMode.HALF_EVEN)
                .setScale(2, RoundingMode.HALF_EVEN)
            existing.copy(
                netContracts = currentQty + signedDelta,
                avgEntryPrice = newAvg,
                settlementBasisPrice = newBasis,
                tradingFeesPaid = existing.tradingFeesPaid.add(fee),
                updatedAtMs = nowMs,
            ) to fee
        } else {
            // Closing or flipping position
            val closeCount = minOf(abs(currentQty), contracts)
            val directionSign = if (currentQty > 0) 1L else -1L
            val realisedDelta = executionPrice.subtract(existing.settlementBasisPrice)
                .multiply(BigDecimal.valueOf(closeCount.toLong() * directionSign))
                .multiply(spec.contractMultiplier)
                .setScale(2, RoundingMode.HALF_EVEN)

            val newNet = currentQty + signedDelta
            val flipped = (currentQty > 0 && newNet < 0) || (currentQty < 0 && newNet > 0)

            existing.copy(
                netContracts = newNet,
                closedContracts = existing.closedContracts + closeCount,
                avgEntryPrice = if (flipped) executionPrice.setScale(2, RoundingMode.HALF_EVEN) else existing.avgEntryPrice,
                settlementBasisPrice = if (flipped) executionPrice.setScale(2, RoundingMode.HALF_EVEN) else existing.settlementBasisPrice,
                realisedPnL = existing.realisedPnL.add(realisedDelta),
                tradingFeesPaid = existing.tradingFeesPaid.add(fee),
                updatedAtMs = nowMs,
            ) to fee
        }
    }

    /**
     * Runs daily variation margin settlement.
     * Moves unrealised variation into collateral/realised variation and RESETS settlementBasisPrice
     * to newSettlementPrice so subsequent ticks do NOT double-count settled P&L.
     */
    fun runDailyVariationSettlement(
        position: FuturesPosition,
        spec: FuturesContractSpec,
        account: FuturesCollateralAccount,
        newSettlementPrice: BigDecimal,
        settlementDate: String,
        nowMs: Long,
    ): Triple<FuturesPosition, FuturesCollateralAccount, DailySettlementResult> {
        val oldBasis = position.settlementBasisPrice
        val variationDelta = if (position.netContracts == 0) {
            BigDecimal.ZERO
        } else {
            newSettlementPrice.subtract(oldBasis)
                .multiply(BigDecimal.valueOf(position.netContracts.toLong()))
                .multiply(spec.contractMultiplier)
                .setScale(2, RoundingMode.HALF_EVEN)
        }

        val updatedPos = position.copy(
            settlementBasisPrice = newSettlementPrice.setScale(2, RoundingMode.HALF_EVEN),
            cumulativeVariationSettled = position.cumulativeVariationSettled.add(variationDelta),
            realisedPnL = position.realisedPnL.add(variationDelta),
            updatedAtMs = nowMs,
        )

        val updatedAccount = account.copy(
            realisedTradingPnL = account.realisedTradingPnL.add(variationDelta),
            lastSettlementDate = settlementDate,
        )

        val absContracts = abs(updatedPos.netContracts)
        val initialReq = spec.initialMarginPerContract.multiply(BigDecimal.valueOf(absContracts.toLong()))
        val maintReq = spec.maintenanceMarginPerContract.multiply(BigDecimal.valueOf(absContracts.toLong()))
        val equity = updatedAccount.netCollateralBalance(BigDecimal.ZERO)

        val health = evaluateMarginHealth(equity, initialReq, maintReq, absContracts)

        val result = DailySettlementResult(
            settlementDate = settlementDate,
            contractCode = spec.contractCode,
            oldSettlementPrice = oldBasis,
            newSettlementPrice = newSettlementPrice.setScale(2, RoundingMode.HALF_EVEN),
            variationMarginDelta = variationDelta,
            newEquity = equity,
            initialMarginRequired = initialReq,
            maintenanceMarginRequired = maintReq,
            status = health,
        )
        return Triple(updatedPos, updatedAccount, result)
    }

    fun evaluateMarginHealth(
        equity: BigDecimal,
        initialMarginReq: BigDecimal,
        maintenanceMarginReq: BigDecimal,
        absContracts: Int,
    ): MarginHealthStatus {
        if (absContracts == 0) return MarginHealthStatus.HEALTHY
        return when {
            equity < BigDecimal.ZERO -> MarginHealthStatus.LIQUIDATION_SHORTFALL
            equity < maintenanceMarginReq -> MarginHealthStatus.MARGIN_CALL
            equity < initialMarginReq -> MarginHealthStatus.WARNING
            else -> MarginHealthStatus.HEALTHY
        }
    }

    /**
     * Models forced position reduction when a margin call requires liquidation against finite simulated book depth.
     * Does NOT assume unlimited liquidity — unliquidated contracts remain open with a residual shortfall.
     */
    fun simulateForcedReduction(
        position: FuturesPosition,
        spec: FuturesContractSpec,
        account: FuturesCollateralAccount,
        contractsToReduce: Int,
    ): ForcedReductionResult {
        if (position.netContracts == 0 || contractsToReduce <= 0) {
            return ForcedReductionResult(
                requestedContractsToClose = 0,
                executedContractsClosed = 0,
                unliquidatedContractsRemaining = 0,
                executionAvgPrice = spec.currentMarkPrice,
                realisedLossOrGain = BigDecimal.ZERO,
                residualMarginShortfall = BigDecimal.ZERO,
                liquidityInsufficient = false,
                explanation = "No open contracts require forced reduction.",
            )
        }

        val isLong = position.netContracts > 0
        val depthLevels = if (isLong) {
            spec.simulatedBookBids.sortedByDescending { it.price }.mapIndexed { idx, lvl ->
                val distressedPrice = spec.currentMarkPrice.subtract(BigDecimal("0.10").multiply(BigDecimal.valueOf((idx + 1).toLong())))
                lvl.copy(price = minOf(lvl.price, distressedPrice).max(BigDecimal("0.10")))
            }
        } else {
            spec.simulatedBookAsks.sortedBy { it.price }.mapIndexed { idx, lvl ->
                val distressedPrice = spec.currentMarkPrice.add(BigDecimal("0.10").multiply(BigDecimal.valueOf((idx + 1).toLong())))
                lvl.copy(price = maxOf(lvl.price, distressedPrice))
            }
        }

        var remainingToClose = minOf(contractsToReduce, abs(position.netContracts))
        var filled = 0
        var weightedNotional = BigDecimal.ZERO

        for (level in depthLevels) {
            if (remainingToClose <= 0) break
            val availableAtLevel = level.quantity.toInt()
            val take = minOf(remainingToClose, availableAtLevel)
            if (take > 0) {
                filled += take
                remainingToClose -= take
                weightedNotional = weightedNotional.add(level.price.multiply(BigDecimal.valueOf(take.toLong())))
            }
        }

        val avgExecPrice = if (filled > 0) {
            weightedNotional.divide(BigDecimal.valueOf(filled.toLong()), 2, RoundingMode.HALF_EVEN)
        } else {
            spec.currentMarkPrice
        }

        val directionSign = if (isLong) 1L else -1L
        val realisedDelta = avgExecPrice.subtract(position.settlementBasisPrice)
            .multiply(BigDecimal.valueOf(filled.toLong() * directionSign))
            .multiply(spec.contractMultiplier)
            .setScale(2, RoundingMode.HALF_EVEN)

        val remainingContracts = abs(position.netContracts) - filled
        val maintReqAfter = spec.maintenanceMarginPerContract.multiply(BigDecimal.valueOf(remainingContracts.toLong()))
        val unrealisedOnRemaining = if (remainingContracts > 0) {
            spec.currentMarkPrice.subtract(position.settlementBasisPrice)
                .multiply(BigDecimal.valueOf(remainingContracts.toLong() * directionSign))
                .multiply(spec.contractMultiplier)
        } else BigDecimal.ZERO

        val equityAfter = account.netCollateralBalance(unrealisedOnRemaining).add(realisedDelta)
        val shortfall = (maintReqAfter.subtract(equityAfter)).coerceAtLeast(BigDecimal.ZERO)

        val insufficient = remainingToClose > 0
        val explanation = if (insufficient) {
            "Insufficient simulated book depth: closed $filled of $contractsToReduce contracts at avg $$avgExecPrice; " +
                "$remainingToClose contract(s) could not be liquidated. Residual margin deficit: $$shortfall."
        } else {
            "Reduced $filled contract(s) across ${depthLevels.size} book level(s) at avg $$avgExecPrice."
        }

        return ForcedReductionResult(
            requestedContractsToClose = contractsToReduce,
            executedContractsClosed = filled,
            unliquidatedContractsRemaining = remainingToClose,
            executionAvgPrice = avgExecPrice,
            realisedLossOrGain = realisedDelta,
            residualMarginShortfall = shortfall,
            liquidityInsufficient = insufficient,
            explanation = explanation,
        )
    }
}
