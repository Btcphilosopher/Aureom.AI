package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ai.AiUiState
import com.example.ui.TerminalUiState
import com.example.ui.TerminalViewModel
import com.example.ui.theme.LocalAureomPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantSheet(
    state: TerminalUiState,
    vm: TerminalViewModel,
) {
    if (!state.isAiSheetOpen) return
    val palette = LocalAureomPalette.current
    var promptInput by remember { mutableStateOf("") }

    val quickPrompts = listOf(
        "Find matching physical offers for Laundry liquid",
        "Compare equivalent unit prices across SKUs",
        "Explain the Dec-Apr delivery curve spread",
        "Audit forward contracts for missing terms",
        "Explain my current simulated futures margin",
        "Prepare procurement coverage & basis risk summary",
    )

    ModalBottomSheet(
        onDismissRequest = { vm.setAiSheetOpen(false) },
        containerColor = palette.panelBg,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = palette.accent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Aureom AI Trade Assistant", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                        Text("Read-only advisory • Grounded in deterministic records", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                    }
                }
                IconButton(onClick = { vm.setAiSheetOpen(false) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Close assistant", tint = palette.textSecondary)
                }
            }

            // Governance banner
            Surface(
                color = palette.accentContainer,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, palette.accent),
            ) {
                Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Gavel, contentDescription = null, tint = palette.accent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Controls enforced: AI cannot place trades, raise limits, transfer collateral, approve contracts, or alter bank instructions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textPrimary,
                    )
                }
            }

            // Quick prompts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                quickPrompts.forEach { qp ->
                    Surface(
                        color = palette.panelElevated,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, palette.border),
                        modifier = Modifier.clickable {
                            promptInput = qp
                            vm.askAiAssistant(qp)
                        },
                    ) {
                        Text(
                            text = qp,
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.accent,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
            }

            // Output card
            Surface(
                color = palette.panelElevated,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, palette.border),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp, max = 300.dp),
            ) {
                Column(
                    modifier = Modifier
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    when (val ai = state.aiState) {
                        AiUiState.Idle -> {
                            Text(
                                text = "Select a quick prompt or ask about offers, unit-price comparisons, spreads, contract terms, or margin math.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary,
                            )
                        }
                        AiUiState.Loading -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = palette.accent)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Streaming analysis via Firebase AI Logic (gemini-3.8-flash)...", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                            }
                        }
                        is AiUiState.Streaming -> {
                            Text(ai.text, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
                            CitedRecordsRow(ai.citedIds)
                        }
                        is AiUiState.Success -> {
                            Text(ai.text, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
                            HorizontalDivider(color = palette.border)
                            CitedRecordsRow(ai.citedIds)
                        }
                        is AiUiState.BlockedByGuardrail -> {
                            Text(ai.reason, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = palette.warning)
                        }
                        is AiUiState.Error -> {
                            Text("AI Request Error: ${ai.message}", style = MaterialTheme.typography.bodyMedium, color = palette.negative)
                        }
                    }
                }
            }

            // Input bar
            Surface(
                color = palette.panelElevated,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, palette.border),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BasicTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = palette.textPrimary),
                        cursorBrush = SolidColor(palette.accent),
                        modifier = Modifier.weight(1f).testTag("ai_prompt_input"),
                        decorationBox = { inner ->
                            if (promptInput.isEmpty()) {
                                Text("Ask AI assistant (e.g., Draft RFQ for 300 cases Laundry Liquid)...", style = MaterialTheme.typography.bodySmall, color = palette.textMuted)
                            }
                            inner()
                        }
                    )
                    IconButton(
                        onClick = {
                            if (promptInput.isNotBlank()) {
                                vm.askAiAssistant(promptInput)
                            }
                        },
                        modifier = Modifier.testTag("ai_send_button"),
                    ) {
                        Icon(Icons.Filled.Send, contentDescription = "Send prompt", tint = palette.accent)
                    }
                }
            }
        }
    }
}

@Composable
private fun CitedRecordsRow(ids: List<String>) {
    val palette = LocalAureomPalette.current
    if (ids.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Source Records in Context:", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            ids.forEach { id ->
                Surface(
                    color = palette.accentContainer,
                    shape = RoundedCornerShape(4.dp),
                ) {
                    Text(id, style = MaterialTheme.typography.labelSmall, color = palette.accent, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
        }
    }
}
