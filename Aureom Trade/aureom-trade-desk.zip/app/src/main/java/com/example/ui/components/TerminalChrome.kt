package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DensitySmall
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Fastfood
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.LocalDrink
import androidx.compose.material.icons.outlined.Spa
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CurrencyCode
import com.example.domain.model.MarketMode
import com.example.domain.model.OrgRole
import com.example.domain.model.ProductCategory
import com.example.domain.model.TerminalTab
import com.example.ui.theme.LocalAureomPalette
import com.example.ui.theme.LocalTerminalDensity
import com.example.ui.theme.MonoTabularStyle

@Composable
fun TerminalPanel(
    title: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val palette = LocalAureomPalette.current
    val density = LocalTerminalDensity.current
    Surface(
        modifier = modifier,
        color = palette.panelBg,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, palette.border),
    ) {
        Column(modifier = Modifier.padding(density.panelPadding)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.textPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(end = 8.dp),
                )
                if (trailing != null) {
                    trailing()
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = palette.border, thickness = 1.dp)
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun AureomTopHeader(
    activeTab: TerminalTab,
    onSelectTab: (TerminalTab) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    displayCurrency: CurrencyCode,
    onCycleCurrency: () -> Unit,
    utcClockText: String,
    isFeedHealthy: Boolean,
    isFeedStale: Boolean,
    onToggleStaleFeed: () -> Unit,
    activeRole: OrgRole,
    onCycleRole: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleDensity: () -> Unit,
    onOpenAiAssistant: () -> Unit,
    isCompactScreen: Boolean,
) {
    val palette = LocalAureomPalette.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.shellBg)
            .statusBarsPadding()
    ) {
        // Row 1: Brand + Search + Environment Status + Utility Icons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onSelectTab(TerminalTab.TRADE) },
            ) {
                AureomBrandMark(modifier = Modifier.size(26.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AUREOM TRADE",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                    ),
                    color = palette.textPrimary,
                )
                if (!isCompactScreen) {
                    Text(
                        text = " | TERMINAL",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textSecondary,
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            if (!isCompactScreen) {
                SearchPillField(
                    query = searchQuery,
                    onQueryChange = onSearchChange,
                    modifier = Modifier.weight(1f).widthIn(max = 300.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                // Currency selector chip
                CompactActionChip(
                    label = "GLOBAL / ${displayCurrency.displayLabel}",
                    onClick = onCycleCurrency,
                    testTag = "currency_cycle_chip",
                )
                if (!isCompactScreen) {
                    Text(
                        text = utcClockText,
                        style = MonoTabularStyle.copy(fontSize = 11.sp),
                        color = palette.textSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp),
                    )
                }
                // Role badge
                CompactActionChip(
                    label = activeRole.label.uppercase(),
                    accent = true,
                    onClick = onCycleRole,
                    testTag = "role_cycle_chip",
                )
                // Feed status pill
                Surface(
                    color = if (isFeedStale) palette.warningBg else palette.accentContainer,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (isFeedStale) palette.warning else palette.accent),
                    modifier = Modifier
                        .clickable(onClick = onToggleStaleFeed)
                        .testTag("feed_status_chip"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (isFeedStale) palette.warning else palette.accent)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (isFeedStale) "STALE FEED" else "DEMO FEED",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isFeedStale) palette.warning else palette.accent,
                        )
                    }
                }
                IconButton(
                    onClick = onOpenAiAssistant,
                    modifier = Modifier.size(40.dp).testTag("ai_assistant_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "Open AI Trade Assistant",
                        tint = palette.accent,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier.size(38.dp).testTag("theme_toggle_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Brightness4,
                        contentDescription = "Toggle dark or light theme",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                if (!isCompactScreen) {
                    IconButton(
                        onClick = onToggleDensity,
                        modifier = Modifier.size(38.dp).testTag("density_toggle_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DensitySmall,
                            contentDescription = "Toggle compact or standard density",
                            tint = palette.textSecondary,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }
        }

        // Mobile search bar when compact
        if (isCompactScreen) {
            SearchPillField(
                query = searchQuery,
                onQueryChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }

        // Row 2: Scrollable 11-module Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            TerminalTab.entries.forEach { tab ->
                val selected = tab == activeTab
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onSelectTab(tab) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("nav_tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        ),
                        color = if (selected) palette.accent else palette.textSecondary,
                        maxLines = 1,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(28.dp)
                            .height(2.dp)
                            .background(if (selected) palette.accent else Color.Transparent)
                    )
                }
            }
        }
        HorizontalDivider(color = palette.border, thickness = 1.dp)
    }
}

@Composable
fun CategoryAndModeStrip(
    marketMode: MarketMode,
    onSelectMode: (MarketMode) -> Unit,
    isFeedStale: Boolean,
    isCompactScreen: Boolean,
) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.panelBg)
    ) {
        // Category index ticker
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CategoryTickerChip(ProductCategory.LAUNDRY, "+0.8%", true)
            CategoryTickerChip(ProductCategory.PERSONAL_CARE, "+0.4%", true)
            CategoryTickerChip(ProductCategory.PAPER, "-0.3%", false)
            CategoryTickerChip(ProductCategory.PACKAGED_FOOD, "+0.6%", true)
            CategoryTickerChip(ProductCategory.COOKING_OILS, "+0.7%", true)
            CategoryTickerChip(ProductCategory.HOUSEHOLD_CLEANING, "+0.5%", true)
        }
        HorizontalDivider(color = palette.border, thickness = 1.dp)

        // Market mode switcher + explicit Synthetic Market label
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                MarketMode.entries.forEach { mode ->
                    val active = mode == marketMode
                    Surface(
                        color = if (active) palette.accent else palette.panelElevated,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, if (active) palette.accent else palette.border),
                        modifier = Modifier
                            .clickable { onSelectMode(mode) }
                            .testTag("mode_pill_${mode.name.lowercase()}"),
                    ) {
                        Text(
                            text = mode.label,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                            ),
                            color = if (active) palette.onAccent else palette.textPrimary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
            }
            if (!isCompactScreen) {
                Text(
                    text = if (marketMode == MarketMode.FUTURES_SIMULATION) {
                        "Demonstration simulation only • Live futures trading disabled"
                    } else {
                        "Synthetic market • Not live trading"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (marketMode == MarketMode.FUTURES_SIMULATION) palette.warning else palette.textSecondary,
                )
            }
        }

        if (isFeedStale) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.warningBg)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Filled.WarningAmber,
                    contentDescription = "Stale feed warning",
                    tint = palette.warning,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "STALE PRICE WARNING: Market data stream paused. Displayed quotes are historical timestamps and cannot be assumed live. Order entry is paused.",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = palette.warning,
                )
            }
        }
        HorizontalDivider(color = palette.border, thickness = 1.dp)
    }
}

@Composable
private fun CategoryTickerChip(category: ProductCategory, change: String, positive: Boolean) {
    val palette = LocalAureomPalette.current
    val icon = when (category) {
        ProductCategory.LAUNDRY -> Icons.Outlined.LocalDrink
        ProductCategory.PERSONAL_CARE -> Icons.Outlined.Spa
        ProductCategory.PAPER -> Icons.Outlined.Layers
        ProductCategory.PACKAGED_FOOD -> Icons.Outlined.Fastfood
        ProductCategory.COOKING_OILS -> Icons.Outlined.WaterDrop
        ProductCategory.HOUSEHOLD_CLEANING -> Icons.Outlined.CleaningServices
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = palette.textSecondary, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = category.tickerLabel,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = palette.textPrimary,
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = change,
            style = MonoTabularStyle.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
            color = if (positive) palette.positive else palette.negative,
        )
    }
}

@Composable
private fun SearchPillField(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalAureomPalette.current
    Surface(
        modifier = modifier.height(36.dp),
        color = palette.panelElevated,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, palette.border),
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = palette.textMuted,
                modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                if (query.isEmpty()) {
                    Text(
                        text = "Search products, suppliers, RFQs, contracts...",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = palette.textPrimary),
                    cursorBrush = SolidColor(palette.accent),
                    modifier = Modifier.fillMaxWidth().testTag("global_search_input"),
                )
            }
            if (query.isNotEmpty()) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Clear search",
                    tint = palette.textMuted,
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { onQueryChange("") },
                )
            }
        }
    }
}

@Composable
fun CompactActionChip(
    label: String,
    onClick: () -> Unit,
    accent: Boolean = false,
    testTag: String = "",
) {
    val palette = LocalAureomPalette.current
    Surface(
        color = if (accent) palette.accentContainer else palette.panelElevated,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, if (accent) palette.accent else palette.border),
        modifier = Modifier
            .clickable(onClick = onClick)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = if (accent) palette.accent else palette.textPrimary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            maxLines = 1,
        )
    }
}

@Composable
fun TerminalFooterBar(
    isFeedStale: Boolean,
    utcClockText: String,
    eventCount: Int,
) {
    val palette = LocalAureomPalette.current
    Surface(
        color = palette.shellBg,
        border = BorderStroke(1.dp, palette.border),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Synthetic market data • Illustrative prices • Event log: $eventCount evts",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(if (isFeedStale) palette.warning else palette.positive)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = if (isFeedStale) "Stream stale • $utcClockText" else "Stream healthy • $utcClockText",
                    style = MonoTabularStyle.copy(fontSize = 11.sp),
                    color = if (isFeedStale) palette.warning else palette.textPrimary,
                )
            }
        }
    }
}

@Composable
fun AureomBrandMark(modifier: Modifier = Modifier) {
    val palette = LocalAureomPalette.current
    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(color = palette.accentContainer, radius = r, center = c)
        drawCircle(color = palette.accent, radius = r * 0.88f, center = c, style = Stroke(width = 2.2f))
        drawLine(color = palette.accent, start = Offset(c.x - r * 0.8f, c.y), end = Offset(c.x + r * 0.8f, c.y), strokeWidth = 1.6f)
        drawLine(color = palette.accent, start = Offset(c.x, c.y - r * 0.8f), end = Offset(c.x, c.y + r * 0.8f), strokeWidth = 1.6f)
        drawOval(
            color = palette.positive,
            topLeft = Offset(c.x - r * 0.45f, c.y - r * 0.78f),
            size = Size(r * 0.9f, r * 1.56f),
            style = Stroke(width = 1.6f),
        )
    }
}

@Composable
fun ProductVisualBadge(category: ProductCategory, modifier: Modifier = Modifier) {
    val palette = LocalAureomPalette.current
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF0A2A4A), Color(0xFF0F4C75))
                )
            )
            .border(1.dp, palette.border, RoundedCornerShape(8.dp))
    ) {
        val w = size.width
        val h = size.height
        // Stylized wholesale container silhouette matching the reference terminal aesthetic
        when (category) {
            ProductCategory.LAUNDRY, ProductCategory.HOUSEHOLD_CLEANING -> {
                drawRoundRect(
                    color = Color(0xFF1995D6),
                    topLeft = Offset(w * 0.28f, h * 0.22f),
                    size = Size(w * 0.44f, h * 0.64f),
                    cornerRadius = CornerRadius(12f, 12f),
                )
                drawRoundRect(
                    color = Color(0xFFE6F4FA),
                    topLeft = Offset(w * 0.34f, h * 0.40f),
                    size = Size(w * 0.32f, h * 0.30f),
                    cornerRadius = CornerRadius(6f, 6f),
                )
                drawRect(
                    color = Color(0xFF00D1FF),
                    topLeft = Offset(w * 0.41f, h * 0.12f),
                    size = Size(w * 0.18f, h * 0.10f),
                )
            }
            ProductCategory.PAPER -> {
                drawRoundRect(
                    color = Color(0xFFEAF2F8),
                    topLeft = Offset(w * 0.20f, h * 0.34f),
                    size = Size(w * 0.60f, h * 0.42f),
                    cornerRadius = CornerRadius(10f, 10f),
                )
                drawLine(color = palette.accent, start = Offset(w * 0.30f, h * 0.46f), end = Offset(w * 0.70f, h * 0.46f), strokeWidth = 4f)
            }
            else -> {
                drawRoundRect(
                    color = palette.accent,
                    topLeft = Offset(w * 0.26f, h * 0.24f),
                    size = Size(w * 0.48f, h * 0.58f),
                    cornerRadius = CornerRadius(14f, 14f),
                    style = Stroke(width = 3f),
                )
                drawCircle(color = Color(0x3300D1FF), radius = w * 0.18f, center = Offset(w * 0.5f, h * 0.53f))
            }
        }
    }
}
