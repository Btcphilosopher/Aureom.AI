package com.example.domain.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class FuturesSettlementMethod(val label: String) {
    CASH_SETTLEMENT("Cash-settled against reference index"),
    PHYSICAL_DELIVERY_DEMO("Illustrative deliverable specification (demo)"),
}

data class FuturesContractSpec(
    val contractCode: String, // e.g. "HOMECARE-MAR27"
    val displayTitle: String, // e.g. "HOMECARE INDEX • MAR27"
    val underlyingIndexOrProduct: String,
    val contractSize: Long, // e.g. 500 cases equivalent
    val quotationUnit: String, // e.g. "USD / case"
    val tickSize: BigDecimal, // e.g. 0.05
    val tickValue: BigDecimal, // e.g. 25.00
    val contractMonths: List<String>,
    val lastTradingDate: String,
    val expiryDate: String,
    val initialMarginPerContract: BigDecimal, // Illustrative only
    val maintenanceMarginPerContract: BigDecimal, // Illustrative only
    val positionLimitContracts: Int,
    val settlementMethod: FuturesSettlementMethod,
    val referencePriceMethodology: String,
    val deliverableSpecsIfPhysical: String,
    val disruptionFallbackRule: String,
    val currentMarkPrice: BigDecimal,
    val priorSettlementPrice: BigDecimal,
    val dailyVolumeContracts: Long,
    val openInterestContracts: Long,
    val simulatedBookBids: List<BookLevel>,
    val simulatedBookAsks: List<BookLevel>,
    val isLiveTradingEnabled: Boolean = false, // Disabled until authorised exchange, broker & clearing integrated
) {
    val contractMultiplier: BigDecimal get() = BigDecimal.valueOf(contractSize)
}

data class FuturesPosition(
    val positionId: String,
    val accountId: String,
    val contractCode: String,
    val displayTitle: String,
    val netContracts: Int, // >0 Long, <0 Short, 0 Flat
    val closedContracts: Int,
    val avgEntryPrice: BigDecimal,
    val settlementBasisPrice: BigDecimal, // Reset on daily variation settlement to prevent P&L double counting
    val realisedPnL: BigDecimal,
    val cumulativeVariationSettled: BigDecimal,
    val tradingFeesPaid: BigDecimal,
    val updatedAtMs: Long,
) {
    fun unrealisedVariationPnL(markPrice: BigDecimal, multiplier: BigDecimal): BigDecimal {
        if (netContracts == 0) return BigDecimal.ZERO
        return markPrice.subtract(settlementBasisPrice)
            .multiply(BigDecimal.valueOf(netContracts.toLong()))
            .multiply(multiplier)
            .setScale(2, RoundingMode.HALF_EVEN)
    }

    fun totalOpenPnLSinceEntry(markPrice: BigDecimal, multiplier: BigDecimal): BigDecimal {
        if (netContracts == 0) return BigDecimal.ZERO
        return markPrice.subtract(avgEntryPrice)
            .multiply(BigDecimal.valueOf(netContracts.toLong()))
            .multiply(multiplier)
            .setScale(2, RoundingMode.HALF_EVEN)
    }
}

enum class MarginHealthStatus(val label: String) {
    HEALTHY("Healthy"),
    WARNING("Near Maintenance"),
    MARGIN_CALL("Margin Call"),
    LIQUIDATION_SHORTFALL("Liquidation Shortfall"),
}

data class FuturesCollateralAccount(
    val accountId: String,
    val cashCollateralPosted: BigDecimal,
    val realisedTradingPnL: BigDecimal,
    val feesCharged: BigDecimal,
    val currency: CurrencyCode = CurrencyCode.USD,
    val lastSettlementDate: String,
    val notes: String = "Illustrative simulation margin — not an actual clearinghouse methodology",
) {
    fun netCollateralBalance(unrealisedVariation: BigDecimal): BigDecimal =
        cashCollateralPosted
            .add(realisedTradingPnL)
            .subtract(feesCharged)
            .add(unrealisedVariation)
            .setScale(2, RoundingMode.HALF_EVEN)
}

data class DailySettlementResult(
    val settlementDate: String,
    val contractCode: String,
    val oldSettlementPrice: BigDecimal,
    val newSettlementPrice: BigDecimal,
    val variationMarginDelta: BigDecimal,
    val newEquity: BigDecimal,
    val initialMarginRequired: BigDecimal,
    val maintenanceMarginRequired: BigDecimal,
    val status: MarginHealthStatus,
)

data class ForcedReductionResult(
    val requestedContractsToClose: Int,
    val executedContractsClosed: Int,
    val unliquidatedContractsRemaining: Int,
    val executionAvgPrice: BigDecimal,
    val realisedLossOrGain: BigDecimal,
    val residualMarginShortfall: BigDecimal,
    val liquidityInsufficient: Boolean,
    val explanation: String,
)
