package com.example.domain.model

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale

enum class CurrencyCode(
    val symbol: String,
    val scale: Int,
    val displayLabel: String,
) {
    USD("$", 2, "USD"),
    GBP("£", 2, "GBP"),
    EUR("€", 2, "EUR"),
    JPY("¥", 0, "JPY"),
}

data class FxRateSnapshot(
    val version: String,
    val from: CurrencyCode,
    val to: CurrencyCode,
    val rate: BigDecimal,
    val timestampMs: Long,
    val source: String,
)

object DecimalMath {
    fun bd(value: String): BigDecimal = BigDecimal(value)
    fun bd(value: Double): BigDecimal = BigDecimal.valueOf(value)
    fun bd(value: Long): BigDecimal = BigDecimal.valueOf(value)

    fun roundCurrency(amount: BigDecimal, currency: CurrencyCode): BigDecimal =
        amount.setScale(currency.scale, RoundingMode.HALF_EVEN)

    fun isTickAligned(price: BigDecimal, tickSize: BigDecimal): Boolean {
        if (tickSize <= BigDecimal.ZERO) return false
        val remainder = price.remainder(tickSize)
        return remainder.compareTo(BigDecimal.ZERO) == 0
    }

    fun isLotAligned(qty: Long, lotSize: Long): Boolean {
        if (lotSize <= 0L) return false
        return qty > 0L && qty % lotSize == 0L
    }

    fun formatCurrency(amount: BigDecimal, currency: CurrencyCode, showSign: Boolean = false): String {
        val scaled = roundCurrency(amount, currency)
        val absVal = scaled.abs()
        val nf = NumberFormat.getNumberInstance(Locale.US).apply {
            minimumFractionDigits = currency.scale
            maximumFractionDigits = currency.scale
            isGroupingUsed = true
        }
        val sign = when {
            scaled < BigDecimal.ZERO -> "-"
            showSign && scaled > BigDecimal.ZERO -> "+"
            else -> ""
        }
        return "$sign${currency.symbol}${nf.format(absVal)}"
    }

    fun formatQty(qty: Long): String = NumberFormat.getIntegerInstance(Locale.US).format(qty)

    fun formatPercent(pct: BigDecimal, showSign: Boolean = true): String {
        val scaled = pct.setScale(2, RoundingMode.HALF_EVEN)
        val sign = if (showSign && scaled > BigDecimal.ZERO) "+" else ""
        return "$sign${scaled.toPlainString()}%"
    }

    /**
     * Converts a price for display only; never mutates the underlying contract settlement currency.
     */
    fun convertDisplayOnly(
        amount: BigDecimal,
        from: CurrencyCode,
        to: CurrencyCode,
        rates: List<FxRateSnapshot>,
    ): BigDecimal {
        if (from == to) return roundCurrency(amount, to)
        val direct = rates.firstOrNull { it.from == from && it.to == to }
        if (direct != null) {
            return roundCurrency(amount.multiply(direct.rate), to)
        }
        val inverse = rates.firstOrNull { it.from == to && it.to == from }
        if (inverse != null && inverse.rate > BigDecimal.ZERO) {
            return roundCurrency(amount.divide(inverse.rate, 8, RoundingMode.HALF_EVEN), to)
        }
        // Fallback via USD pivot
        val toUsd = if (from == CurrencyCode.USD) BigDecimal.ONE
        else rates.firstOrNull { it.from == from && it.to == CurrencyCode.USD }?.rate
            ?: rates.firstOrNull { it.from == CurrencyCode.USD && it.to == from }?.let {
                BigDecimal.ONE.divide(it.rate, 8, RoundingMode.HALF_EVEN)
            } ?: BigDecimal.ONE

        val fromUsd = if (to == CurrencyCode.USD) BigDecimal.ONE
        else rates.firstOrNull { it.from == CurrencyCode.USD && it.to == to }?.rate
            ?: rates.firstOrNull { it.from == to && it.to == CurrencyCode.USD }?.let {
                BigDecimal.ONE.divide(it.rate, 8, RoundingMode.HALF_EVEN)
            } ?: BigDecimal.ONE

        return roundCurrency(amount.multiply(toUsd).multiply(fromUsd), to)
    }
}
