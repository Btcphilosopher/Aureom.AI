package com.example.data

import com.example.domain.model.AlertSeverity
import com.example.domain.model.BookLevel
import com.example.domain.model.CommercialInvoice
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.FirmOfferRecord
import com.example.domain.model.ForwardContract
import com.example.domain.model.ForwardContractStatus
import com.example.domain.model.ForwardCurvePoint
import com.example.domain.model.FreightDutyTaxAdapter
import com.example.domain.model.FuturesCollateralAccount
import com.example.domain.model.FuturesContractSpec
import com.example.domain.model.FuturesPosition
import com.example.domain.model.FuturesSettlementMethod
import com.example.domain.model.FxRateSnapshot
import com.example.domain.model.InventoryBatch
import com.example.domain.model.InvoiceStatus
import com.example.domain.model.OrderSide
import com.example.domain.model.OrganizationAccount
import com.example.domain.model.PackagingSpec
import com.example.domain.model.PhysicalInstrument
import com.example.domain.model.PricePoint
import com.example.domain.model.PriceSourceType
import com.example.domain.model.ProcurementPlanRow
import com.example.domain.model.ProductCategory
import com.example.domain.model.ProvenanceDocument
import com.example.domain.model.RfqQuote
import com.example.domain.model.RfqRecord
import com.example.domain.model.RfqStatus
import com.example.domain.model.ShipmentRecord
import com.example.domain.model.ShipmentStatus
import com.example.domain.model.SurveillanceAlert
import com.example.domain.model.TradeTerm
import com.example.domain.model.TradingApproach
import com.example.engine.EngineCommand
import java.math.BigDecimal

/**
 * Provides realistic synthetic wholesale consumer goods market data, fictional businesses,
 * deterministic seed matching engine commands, and versioned FX/freight adapters.
 */
object SyntheticMarketData {

    const val ORG_PENNINE_RETAIL = "ORG-PENNINE"
    const val ORG_NORTHSHORE_SUPPLY = "ORG-NORTHSHORE"
    const val ORG_VANGUARD_GROCERS = "ORG-VANGUARD"
    const val ORG_MERIDIAN_MFG = "ORG-MERIDIAN"
    const val ORG_BALTIC_OILS = "ORG-BALTIC"
    const val ORG_AUREOM_DESK = "ORG-AUREOM-DEMO"

    fun organizations(): List<OrganizationAccount> = listOf(
        OrganizationAccount(
            orgId = ORG_AUREOM_DESK,
            name = "Aureom Demo Trading Desk",
            country = "United Kingdom",
            creditLimitUsd = bd("350000.00"),
            usedCreditUsd = bd("84520.00"),
            orderValueLimitUsd = bd("120000.00"),
            approvalThresholdUsd = bd("25000.00"),
            positionLimitContracts = 50,
            bankDetailsMask = "GB29 •••• 4491 (ClearBank UK)",
        ),
        OrganizationAccount(
            orgId = ORG_NORTHSHORE_SUPPLY,
            name = "Northshore Consumer Supply",
            country = "United Kingdom",
            creditLimitUsd = bd("500000.00"),
            usedCreditUsd = bd("62000.00"),
            orderValueLimitUsd = bd("200000.00"),
            approvalThresholdUsd = bd("50000.00"),
            positionLimitContracts = 80,
            bankDetailsMask = "GB88 •••• 9102 (Northshore Treasury)",
        ),
        OrganizationAccount(
            orgId = ORG_PENNINE_RETAIL,
            name = "Pennine Retail Group PLC",
            country = "United Kingdom",
            creditLimitUsd = bd("420000.00"),
            usedCreditUsd = bd("114200.00"),
            orderValueLimitUsd = bd("150000.00"),
            approvalThresholdUsd = bd("40000.00"),
            positionLimitContracts = 40,
            bankDetailsMask = "GB14 •••• 3319 (Pennine Commercial)",
        ),
        OrganizationAccount(
            orgId = ORG_VANGUARD_GROCERS,
            name = "Vanguard Grocers UK",
            country = "United Kingdom",
            creditLimitUsd = bd("300000.00"),
            usedCreditUsd = bd("48500.00"),
            orderValueLimitUsd = bd("100000.00"),
            approvalThresholdUsd = bd("30000.00"),
            positionLimitContracts = 30,
            bankDetailsMask = "GB55 •••• 7740 (Vanguard AP)",
        ),
        OrganizationAccount(
            orgId = ORG_MERIDIAN_MFG,
            name = "Meridian Household Manufacturing",
            country = "United Kingdom",
            creditLimitUsd = bd("600000.00"),
            usedCreditUsd = bd("95000.00"),
            orderValueLimitUsd = bd("250000.00"),
            approvalThresholdUsd = bd("75000.00"),
            positionLimitContracts = 100,
            bankDetailsMask = "GB71 •••• 2208 (Meridian Settlement)",
        ),
        OrganizationAccount(
            orgId = ORG_BALTIC_OILS,
            name = "Baltic Oils & Foods BV",
            country = "Netherlands",
            creditLimitUsd = bd("450000.00"),
            usedCreditUsd = bd("78000.00"),
            orderValueLimitUsd = bd("180000.00"),
            approvalThresholdUsd = bd("50000.00"),
            positionLimitContracts = 60,
            bankDetailsMask = "NL91 •••• 6184 (Rotterdam Trade Bank)",
        ),
    )

    fun fxRates(nowMs: Long): List<FxRateSnapshot> = listOf(
        FxRateSnapshot("FX-2026.11.15-v4", CurrencyCode.USD, CurrencyCode.GBP, bd("0.7850"), nowMs, "Aureom Synthetic Reference FX"),
        FxRateSnapshot("FX-2026.11.15-v4", CurrencyCode.USD, CurrencyCode.EUR, bd("0.9240"), nowMs, "Aureom Synthetic Reference FX"),
        FxRateSnapshot("FX-2026.11.15-v4", CurrencyCode.USD, CurrencyCode.JPY, bd("152.40"), nowMs, "Aureom Synthetic Reference FX"),
    )

    fun freightAdapters(): List<FreightDutyTaxAdapter> = listOf(
        FreightDutyTaxAdapter("FRT-UK-v2.1", "UK Domestic (Leeds/Manchester)", bd("1.15"), bd("0.20"), bd("0.00"), bd("20.00"), bd("0.35")),
        FreightDutyTaxAdapter("FRT-NL-UK-v2.1", "Rotterdam -> Leeds Cross-Border", bd("3.40"), bd("0.35"), bd("4.50"), bd("20.00"), bd("0.95")),
    )

    fun instruments(nowMs: Long): List<PhysicalInstrument> = listOf(
        PhysicalInstrument(
            id = "LAUNDRY-LIQ-UK-DEC26",
            productName = "Laundry liquid",
            brand = "AureoClean Bio",
            skuOrSpec = "ACL-LIQ-12X1L-BIO",
            category = ProductCategory.LAUNDRY,
            tradingApproach = TradingApproach.BRANDED_SKU,
            grade = "Grade A Retail Concentrated",
            permittedSubstitutions = "None (strict SKU match)",
            packaging = PackagingSpec("12 × 1 L", 12, bd("1.0"), "L", 60),
            quantityBasis = "cases",
            originCountry = "United Kingdom",
            hsCode = "3402.50.00",
            dispatchLocation = "UK warehouse",
            deliveryLocation = "Leeds, United Kingdom",
            deliveryPeriod = "Dec 2026",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.DAP,
            namedPlace = "Leeds",
            minRemainingShelfLifeMonths = 12,
            qualityDocsRequired = listOf("Certificate of Analysis (COA)", "SDS Safety Sheet", "GS1 Barcode Manifest"),
            taxTreatment = "UK Standard VAT 20% (shown at confirmation)",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_NORTHSHORE_SUPPLY, ORG_PENNINE_RETAIL, ORG_VANGUARD_GROCERS, ORG_MERIDIAN_MFG),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 60L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("36.20"),
            previousClosePrice = bd("35.90"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "3–5 days",
            quoteSource = PriceSourceType.COMMITTED_TRADE,
            lastUpdatedMs = nowMs,
        ),
        PhysicalInstrument(
            id = "BODY-WASH-UK-DEC26",
            productName = "Body wash",
            brand = "PureDew Botanicals",
            skuOrSpec = "PDB-BW-24X250ML",
            category = ProductCategory.PERSONAL_CARE,
            tradingApproach = TradingApproach.BRANDED_SKU,
            grade = "Retail Dermatological Tier-1",
            permittedSubstitutions = "None (strict SKU match)",
            packaging = PackagingSpec("24 × 250 ml", 24, bd("0.25"), "L", 72),
            quantityBasis = "cases",
            originCountry = "United Kingdom",
            hsCode = "3401.30.00",
            dispatchLocation = "Manchester Hub",
            deliveryLocation = "Leeds, United Kingdom",
            deliveryPeriod = "Dec 2026",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.DAP,
            namedPlace = "Leeds",
            minRemainingShelfLifeMonths = 14,
            qualityDocsRequired = listOf("Cosmetic PIF Summary", "COA", "Batch Traceability"),
            taxTreatment = "UK Standard VAT 20%",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_NORTHSHORE_SUPPLY, ORG_PENNINE_RETAIL, ORG_VANGUARD_GROCERS),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 40L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("28.80"),
            previousClosePrice = bd("28.66"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "2–4 days",
            quoteSource = PriceSourceType.COMMITTED_TRADE,
            lastUpdatedMs = nowMs,
        ),
        PhysicalInstrument(
            id = "TISSUE-PACK-UK-JAN27",
            productName = "Tissue packs",
            brand = "SoftWeave 3-Ply",
            skuOrSpec = "SW-TP-40X100",
            category = ProductCategory.PAPER,
            tradingApproach = TradingApproach.BRANDED_SKU,
            grade = "FSC Virgin Pulp 3-Ply",
            permittedSubstitutions = "Permitted: Equivalent FSC Mix 3-Ply",
            packaging = PackagingSpec("40 × 100 sheets", 40, bd("1.0"), "pack", 48),
            quantityBasis = "cases",
            originCountry = "United Kingdom",
            hsCode = "4818.20.10",
            dispatchLocation = "Birmingham DC",
            deliveryLocation = "Leeds, United Kingdom",
            deliveryPeriod = "Jan 2027",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.DAP,
            namedPlace = "Leeds",
            minRemainingShelfLifeMonths = 24,
            qualityDocsRequired = listOf("FSC Chain-of-Custody", "Packing List"),
            taxTreatment = "UK Standard VAT 20%",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_NORTHSHORE_SUPPLY, ORG_PENNINE_RETAIL, ORG_VANGUARD_GROCERS),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 100L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("19.40"),
            previousClosePrice = bd("19.46"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "4–6 days",
            quoteSource = PriceSourceType.FIRM_OFFER,
            lastUpdatedMs = nowMs,
        ),
        PhysicalInstrument(
            id = "SHAMPOO-UK-DEC26",
            productName = "Shampoo",
            brand = "PureDew Botanicals",
            skuOrSpec = "PDB-SH-12X500ML",
            category = ProductCategory.PERSONAL_CARE,
            tradingApproach = TradingApproach.BRANDED_SKU,
            grade = "Sulfate-Free Salon Spec",
            permittedSubstitutions = "None",
            packaging = PackagingSpec("12 × 500 ml", 12, bd("0.5"), "L", 64),
            quantityBasis = "cases",
            originCountry = "United Kingdom",
            hsCode = "3305.10.00",
            dispatchLocation = "Manchester Hub",
            deliveryLocation = "Bristol, United Kingdom",
            deliveryPeriod = "Dec 2026",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.FCA,
            namedPlace = "Manchester",
            minRemainingShelfLifeMonths = 18,
            qualityDocsRequired = listOf("COA", "Cosmetic Compliance"),
            taxTreatment = "UK Standard VAT 20%",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_NORTHSHORE_SUPPLY, ORG_PENNINE_RETAIL),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 40L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("33.00"),
            previousClosePrice = bd("32.80"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "3–5 days",
            quoteSource = PriceSourceType.FIRM_OFFER,
            lastUpdatedMs = nowMs,
        ),
        PhysicalInstrument(
            id = "COOKING-OIL-NL-DEC26",
            productName = "Cooking oil",
            brand = "Generic Spec Refined Rapeseed",
            skuOrSpec = "GEN-RSO-2X10L-FOOD",
            category = ProductCategory.COOKING_OILS,
            tradingApproach = TradingApproach.GENERIC_SPEC,
            grade = "Food Grade Cold-Filtered <0.1% FFA",
            permittedSubstitutions = "Permitted: EU-Origin Non-GMO Rapeseed spec",
            packaging = PackagingSpec("2 × 10 L", 2, bd("10.0"), "L", 40),
            quantityBasis = "cases",
            originCountry = "Netherlands",
            hsCode = "1514.19.90",
            dispatchLocation = "Rotterdam Terminal",
            deliveryLocation = "Leeds, United Kingdom",
            deliveryPeriod = "Dec 2026",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.FOB,
            namedPlace = "Rotterdam",
            minRemainingShelfLifeMonths = 9,
            qualityDocsRequired = listOf("BRCGS Food Certificate", "Phytosanitary / Health Cert", "COA Peroxide Value"),
            taxTreatment = "Zero-rated UK food import (4.5% tariff under FOB NL->UK)",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_BALTIC_OILS, ORG_PENNINE_RETAIL, ORG_VANGUARD_GROCERS),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 60L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("25.20"),
            previousClosePrice = bd("25.02"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "5–8 days",
            quoteSource = PriceSourceType.COMMITTED_TRADE,
            lastUpdatedMs = nowMs,
        ),
        PhysicalInstrument(
            id = "OAT-CEREAL-UK-DEC26",
            productName = "Oat cereal",
            brand = "HarvestMill Wholegrain",
            skuOrSpec = "HM-OAT-20X500G",
            category = ProductCategory.PACKAGED_FOOD,
            tradingApproach = TradingApproach.BRANDED_SKU,
            grade = "Retail Jumbo Rolled Oats",
            permittedSubstitutions = "None",
            packaging = PackagingSpec("20 × 500 g", 20, bd("0.5"), "kg", 50),
            quantityBasis = "cases",
            originCountry = "United Kingdom",
            hsCode = "1904.10.90",
            dispatchLocation = "Yorkshire Mill DC",
            deliveryLocation = "Leeds, United Kingdom",
            deliveryPeriod = "Dec 2026",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.DAP,
            namedPlace = "Leeds",
            minRemainingShelfLifeMonths = 10,
            qualityDocsRequired = listOf("Allergen Declaration", "SALSA / BRC Food Cert"),
            taxTreatment = "UK Zero-Rated Food",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_NORTHSHORE_SUPPLY, ORG_PENNINE_RETAIL, ORG_VANGUARD_GROCERS),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 40L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("27.10"),
            previousClosePrice = bd("27.00"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "2–3 days",
            quoteSource = PriceSourceType.FIRM_OFFER,
            lastUpdatedMs = nowMs,
        ),
        PhysicalInstrument(
            id = "SURF-CLEANER-SPEC-DEC26",
            productName = "Surface disinfectant",
            brand = "Generic EN1276 Quaternary Spec",
            skuOrSpec = "GEN-DISINF-12X750ML",
            category = ProductCategory.HOUSEHOLD_CLEANING,
            tradingApproach = TradingApproach.GENERIC_SPEC,
            grade = "BS EN 1276 Bactericidal Spec",
            permittedSubstitutions = "Permitted: Approved private-label bottle color",
            packaging = PackagingSpec("12 × 750 ml", 12, bd("0.75"), "L", 60),
            quantityBasis = "cases",
            originCountry = "United Kingdom",
            hsCode = "3808.94.90",
            dispatchLocation = "Midlands Chemical Park",
            deliveryLocation = "Leeds, United Kingdom",
            deliveryPeriod = "Dec 2026",
            currency = CurrencyCode.USD,
            tradeTerm = TradeTerm.DAP,
            namedPlace = "Leeds",
            minRemainingShelfLifeMonths = 18,
            qualityDocsRequired = listOf("EN1276 Efficacy Test", "SDS", "Biocide Reg"),
            taxTreatment = "UK Standard VAT 20%",
            eligibleCounterparties = listOf(ORG_AUREOM_DESK, ORG_MERIDIAN_MFG, ORG_PENNINE_RETAIL),
            tickSize = bd("0.10"),
            lotSize = 20L,
            minOrderQty = 60L,
            priceCollarPct = bd("10.0"),
            referenceSpotPrice = bd("22.40"),
            previousClosePrice = bd("22.30"),
            isStandardisedOrderBook = true,
            dispatchLeadDays = "3–5 days",
            quoteSource = PriceSourceType.INDICATIVE_QUOTE,
            lastUpdatedMs = nowMs,
        ),
    )

    fun seedMatchingCommands(nowMs: Long): List<EngineCommand> {
        val exp = nowMs + 86_400_000L * 7
        return listOf(
            // Laundry liquid book depth (matches screenshot ladder!)
            EngineCommand.PlaceLimitOrder("SEED-L-B1", "LAUNDRY-LIQ-UK-DEC26", nowMs - 600_000, "AT-1031", ORG_PENNINE_RETAIL, "Pennine Retail Group PLC", "Trader", OrderSide.BUY, bd("36.00"), 840L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-B2", "LAUNDRY-LIQ-UK-DEC26", nowMs - 590_000, "AT-1032", ORG_VANGUARD_GROCERS, "Vanguard Grocers UK", "Trader", OrderSide.BUY, bd("35.90"), 1200L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-B3", "LAUNDRY-LIQ-UK-DEC26", nowMs - 580_000, "AT-1033", ORG_PENNINE_RETAIL, "Pennine Retail Group PLC", "Trader", OrderSide.BUY, bd("35.80"), 1500L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-B4", "LAUNDRY-LIQ-UK-DEC26", nowMs - 570_000, "AT-1034", ORG_VANGUARD_GROCERS, "Vanguard Grocers UK", "Trader", OrderSide.BUY, bd("35.70"), 1800L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-B5", "LAUNDRY-LIQ-UK-DEC26", nowMs - 560_000, "AT-1035", ORG_PENNINE_RETAIL, "Pennine Retail Group PLC", "Trader", OrderSide.BUY, bd("35.60"), 2400L, exp),

            EngineCommand.PlaceLimitOrder("SEED-L-S1", "LAUNDRY-LIQ-UK-DEC26", nowMs - 550_000, "AT-1036", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("36.20"), 720L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-S2", "LAUNDRY-LIQ-UK-DEC26", nowMs - 540_000, "AT-1037", ORG_MERIDIAN_MFG, "Meridian Household Manufacturing", "Sales Manager", OrderSide.SELL, bd("36.30"), 960L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-S3", "LAUNDRY-LIQ-UK-DEC26", nowMs - 530_000, "AT-1038", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("36.40"), 1200L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-S4", "LAUNDRY-LIQ-UK-DEC26", nowMs - 520_000, "AT-1039", ORG_MERIDIAN_MFG, "Meridian Household Manufacturing", "Sales Manager", OrderSide.SELL, bd("36.50"), 1440L, exp),
            EngineCommand.PlaceLimitOrder("SEED-L-S5", "LAUNDRY-LIQ-UK-DEC26", nowMs - 510_000, "AT-1040", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("36.60"), 1800L, exp),

            // Active working & part-filled orders for blotter parity
            EngineCommand.PlaceLimitOrder("SEED-L-W1", "LAUNDRY-LIQ-UK-DEC26", nowMs - 300_000, "AT-1048", ORG_AUREOM_DESK, "Aureom Demo Trading Desk", "Trader", OrderSide.BUY, bd("36.00"), 120L, exp),

            // Body wash resting + partial fill
            EngineCommand.PlaceLimitOrder("SEED-BW-B1", "BODY-WASH-UK-DEC26", nowMs - 400_000, "AT-1041", ORG_PENNINE_RETAIL, "Pennine Retail Group PLC", "Trader", OrderSide.BUY, bd("28.60"), 460L, exp),
            EngineCommand.PlaceLimitOrder("SEED-BW-S1", "BODY-WASH-UK-DEC26", nowMs - 380_000, "AT-1046", ORG_AUREOM_DESK, "Aureom Demo Trading Desk", "Trader", OrderSide.SELL, bd("28.80"), 120L, exp),
            EngineCommand.PlaceLimitOrder("SEED-BW-B2", "BODY-WASH-UK-DEC26", nowMs - 350_000, "AT-1049", ORG_VANGUARD_GROCERS, "Vanguard Grocers UK", "Trader", OrderSide.BUY, bd("28.80"), 40L, exp),
            EngineCommand.PlaceLimitOrder("SEED-BW-S2", "BODY-WASH-UK-DEC26", nowMs - 320_000, "AT-1042", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("28.90"), 600L, exp),

            // Tissue packs
            EngineCommand.PlaceLimitOrder("SEED-TP-B1", "TISSUE-PACK-UK-JAN27", nowMs - 290_000, "AT-1043", ORG_PENNINE_RETAIL, "Pennine Retail Group PLC", "Trader", OrderSide.BUY, bd("19.20"), 800L, exp),
            EngineCommand.PlaceLimitOrder("SEED-TP-S1", "TISSUE-PACK-UK-JAN27", nowMs - 280_000, "AT-1044", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("19.40"), 900L, exp),

            // Shampoo
            EngineCommand.PlaceLimitOrder("SEED-SH-B1", "SHAMPOO-UK-DEC26", nowMs - 270_000, "AT-1050", ORG_VANGUARD_GROCERS, "Vanguard Grocers UK", "Trader", OrderSide.BUY, bd("32.70"), 400L, exp),
            EngineCommand.PlaceLimitOrder("SEED-SH-S1", "SHAMPOO-UK-DEC26", nowMs - 260_000, "AT-1051", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("33.00"), 520L, exp),

            // Cooking Oil
            EngineCommand.PlaceLimitOrder("SEED-CO-B1", "COOKING-OIL-NL-DEC26", nowMs - 250_000, "AT-1052", ORG_PENNINE_RETAIL, "Pennine Retail Group PLC", "Trader", OrderSide.BUY, bd("24.90"), 500L, exp),
            EngineCommand.PlaceLimitOrder("SEED-CO-S1", "COOKING-OIL-NL-DEC26", nowMs - 240_000, "AT-1053", ORG_BALTIC_OILS, "Baltic Oils & Foods BV", "Sales Manager", OrderSide.SELL, bd("25.20"), 640L, exp),

            // Oat Cereal
            EngineCommand.PlaceLimitOrder("SEED-OC-B1", "OAT-CEREAL-UK-DEC26", nowMs - 230_000, "AT-1054", ORG_VANGUARD_GROCERS, "Vanguard Grocers UK", "Trader", OrderSide.BUY, bd("26.80"), 380L, exp),
            EngineCommand.PlaceLimitOrder("SEED-OC-S1", "OAT-CEREAL-UK-DEC26", nowMs - 220_000, "AT-1055", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", "Sales Manager", OrderSide.SELL, bd("27.10"), 480L, exp),
        )
    }

    fun seedInventories(nowMs: Long): List<InventoryBatch> = listOf(
        InventoryBatch(
            batchId = "BATCH-LL-2026-A",
            warehouseId = "WH-LEEDS-01",
            warehouseName = "Leeds Central DC",
            ownerOrgId = ORG_NORTHSHORE_SUPPLY,
            instrumentId = "LAUNDRY-LIQ-UK-DEC26",
            skuOrSpec = "ACL-LIQ-12X1L-BIO",
            productName = "Laundry liquid (12 × 1 L)",
            batchCode = "LL-2611-A1",
            expiryDate = "2028-04-30",
            remainingShelfLifeMonths = 17,
            availableQty = 2200L,
            reservedQty = 720L,
            quarantinedQty = 40L,
            expiredQty = 0L,
            inTransitQty = 300L,
            stockSource = "WMS Sync (Leeds DC)",
            freshnessTimestampMs = nowMs - 90_000L,
            certificateRef = "COA-LL-2611-A1",
        ),
        InventoryBatch(
            batchId = "BATCH-BW-2026-B",
            warehouseId = "WH-MCR-02",
            warehouseName = "Manchester North Hub",
            ownerOrgId = ORG_NORTHSHORE_SUPPLY,
            instrumentId = "BODY-WASH-UK-DEC26",
            skuOrSpec = "PDB-BW-24X250ML",
            productName = "Body wash (24 × 250 ml)",
            batchCode = "BW-2611-M2",
            expiryDate = "2028-06-15",
            remainingShelfLifeMonths = 19,
            availableQty = 1480L,
            reservedQty = 80L,
            quarantinedQty = 0L,
            expiredQty = 15L,
            inTransitQty = 180L,
            stockSource = "WMS Sync (Manchester Hub)",
            freshnessTimestampMs = nowMs - 140_000L,
            certificateRef = "COA-BW-2611-M2",
        ),
        InventoryBatch(
            batchId = "BATCH-TP-2026-C",
            warehouseId = "WH-BHM-03",
            warehouseName = "Birmingham Paper Annex",
            ownerOrgId = ORG_NORTHSHORE_SUPPLY,
            instrumentId = "TISSUE-PACK-UK-JAN27",
            skuOrSpec = "SW-TP-40X100",
            productName = "Tissue packs (40 × 100)",
            batchCode = "TP-2610-B3",
            expiryDate = "2030-01-31",
            remainingShelfLifeMonths = 38,
            availableQty = 3100L,
            reservedQty = 400L,
            quarantinedQty = 0L,
            expiredQty = 0L,
            inTransitQty = 0L,
            stockSource = "Manual Upload + Scanner",
            freshnessTimestampMs = nowMs - 420_000L,
            certificateRef = "FSC-COC-99210",
        ),
        InventoryBatch(
            batchId = "BATCH-CO-2026-D",
            warehouseId = "WH-RTM-01",
            warehouseName = "Rotterdam Port Bonded",
            ownerOrgId = ORG_BALTIC_OILS,
            instrumentId = "COOKING-OIL-NL-DEC26",
            skuOrSpec = "GEN-RSO-2X10L-FOOD",
            productName = "Cooking oil (2 × 10 L)",
            batchCode = "RSO-2611-NL",
            expiryDate = "2027-10-31",
            remainingShelfLifeMonths = 11,
            availableQty = 1600L,
            reservedQty = 0L,
            quarantinedQty = 60L,
            expiredQty = 0L,
            inTransitQty = 400L,
            stockSource = "External 3PL EDI Feed",
            freshnessTimestampMs = nowMs - 1_800_000L,
            certificateRef = "BRCGS-RSO-441",
        ),
    )

    fun seedOffers(nowMs: Long): List<FirmOfferRecord> = listOf(
        FirmOfferRecord(
            offerId = "OFR-901",
            instrumentId = "LAUNDRY-LIQ-UK-DEC26",
            sellerOrgId = ORG_NORTHSHORE_SUPPLY,
            sellerOrgName = "Northshore Consumer Supply",
            isFirm = true,
            unitPrice = bd("36.20"),
            totalQty = 600L,
            remainingQty = 600L,
            reservedBatchId = "BATCH-LL-2026-A",
            currency = CurrencyCode.USD,
            location = "Leeds, United Kingdom",
            deliveryTerms = "DAP Leeds • 3-5 days • Min 60 cases",
            expiresAtMs = nowMs + 86_400_000L * 2,
            status = "ACTIVE",
            createdAtMs = nowMs - 720_000L,
        ),
        FirmOfferRecord(
            offerId = "OFR-902",
            instrumentId = "COOKING-OIL-NL-DEC26",
            sellerOrgId = ORG_BALTIC_OILS,
            sellerOrgName = "Baltic Oils & Foods BV",
            isFirm = false, // Indicative only — does not reserve inventory
            unitPrice = bd("25.10"),
            totalQty = 1000L,
            remainingQty = 1000L,
            reservedBatchId = null,
            currency = CurrencyCode.USD,
            location = "Rotterdam Terminal",
            deliveryTerms = "FOB Rotterdam • Indicative subject to vessel slot",
            expiresAtMs = nowMs + 86_400_000L * 4,
            status = "ACTIVE",
            createdAtMs = nowMs - 500_000L,
        ),
    )

    fun seedRfqs(nowMs: Long): List<RfqRecord> = listOf(
        RfqRecord(
            rfqId = "RFQ-4402",
            requesterOrgId = ORG_PENNINE_RETAIL,
            requesterOrgName = "Pennine Retail Group PLC",
            instrumentId = "LAUNDRY-LIQ-UK-DEC26",
            productName = "Laundry liquid (12 × 1 L)",
            side = OrderSide.BUY,
            targetQty = 480L,
            targetPrice = bd("36.10"),
            currency = CurrencyCode.USD,
            deliveryPeriod = "Jan 2027",
            destination = "Leeds, United Kingdom",
            tradeTerm = TradeTerm.DAP,
            minShelfLifeMonths = 12,
            status = RfqStatus.QUOTED,
            quotes = listOf(
                RfqQuote("QT-11", ORG_NORTHSHORE_SUPPLY, "Northshore Consumer Supply", bd("36.35"), 480L, "DAP Leeds", nowMs + 86_400_000L, "Includes COA & palletized shrink-wrap"),
                RfqQuote("QT-12", ORG_MERIDIAN_MFG, "Meridian Household Manufacturing", bd("36.50"), 480L, "DAP Leeds", nowMs + 86_400_000L, "Guaranteed 16m shelf life"),
            ),
            createdAtMs = nowMs - 1_200_000L,
        ),
    )

    fun seedForwardContracts(nowMs: Long): List<ForwardContract> = listOf(
        ForwardContract(
            contractId = "AT-1047",
            instrumentId = "TISSUE-PACK-UK-JAN27",
            productSpec = "Tissue packs • SoftWeave 3-Ply (40 × 100 sheets)",
            buyerOrgId = ORG_AUREOM_DESK,
            buyerOrgName = "Aureom Demo Trading Desk",
            sellerOrgId = ORG_NORTHSHORE_SUPPLY,
            sellerOrgName = "Northshore Consumer Supply",
            contractedQty = 400L,
            tolerancePct = bd("5.0"),
            pricingBasis = "FIXED",
            fixedOrFormulaPrice = bd("19.40"),
            currency = CurrencyCode.USD,
            deliveryWindowStart = "2027-01-10",
            deliveryWindowEnd = "2027-01-20",
            deliveryLocation = "Leeds, United Kingdom",
            tradeTerms = "DAP Leeds",
            paymentSchedule = "Net 30 days from POD acceptance",
            creditSupportTerms = "15% Buyer credit reserve ($1,164.00) held against facility",
            inspectionAndAcceptanceTerms = "48h count & moisture inspection upon dock arrival",
            shortDeliveryAndRejectionTerms = "Shortage >2% triggers pro-rata credit note or 5-day replacement",
            cancellationAndDefaultTerms = "Termination damages equal to replacement spread + documented freight",
            disputeResolutionTerms = "London Commercial Arbitration (LCIA Expedited)",
            signedVersion = 1,
            createdByRole = "Trader",
            approvedByRole = "Approver",
            status = ForwardContractStatus.ACCEPTED,
            allocatedQty = 400L,
            dispatchedQty = 0L,
            deliveredQty = 0L,
            acceptedQty = 0L,
            amendments = emptyList(),
            createdAtMs = nowMs - 3_600_000L,
        ),
        ForwardContract(
            contractId = "FWD-2088",
            instrumentId = "LAUNDRY-LIQ-UK-DEC26",
            productSpec = "Laundry liquid • AureoClean Bio (12 × 1 L)",
            buyerOrgId = ORG_PENNINE_RETAIL,
            buyerOrgName = "Pennine Retail Group PLC",
            sellerOrgId = ORG_MERIDIAN_MFG,
            sellerOrgName = "Meridian Household Manufacturing",
            contractedQty = 600L,
            tolerancePct = bd("2.5"),
            pricingBasis = "FIXED",
            fixedOrFormulaPrice = bd("36.45"),
            currency = CurrencyCode.USD,
            deliveryWindowStart = "2027-02-01",
            deliveryWindowEnd = "2027-02-14",
            deliveryLocation = "Leeds, United Kingdom",
            tradeTerms = "DAP Leeds",
            paymentSchedule = "20% deposit + 80% Net 14 days post-acceptance",
            creditSupportTerms = "Parent guarantee & $4,374.00 escrow deposit",
            inspectionAndAcceptanceTerms = "Batch COA verified + 24h seal integrity check",
            shortDeliveryAndRejectionTerms = "Leaking cartons rejected at carrier gate; supplier bears return haulage",
            cancellationAndDefaultTerms = "Force majeure notice 72h; default penalty 10% + market replacement diff",
            disputeResolutionTerms = "English Law, Manchester Commercial Court",
            signedVersion = 1,
            createdByRole = "Procurement Manager",
            approvedByRole = null,
            status = ForwardContractStatus.PENDING_APPROVAL,
            allocatedQty = 0L,
            dispatchedQty = 0L,
            deliveredQty = 0L,
            acceptedQty = 0L,
            amendments = emptyList(),
            createdAtMs = nowMs - 900_000L,
        ),
    )

    fun seedShipments(nowMs: Long): List<ShipmentRecord> = listOf(
        ShipmentRecord(
            shipmentId = "SHP-7701",
            referenceId = "AT-1047",
            instrumentId = "TISSUE-PACK-UK-JAN27",
            productName = "Tissue packs (40 × 100)",
            warehouseName = "Birmingham Paper Annex",
            destination = "Leeds, United Kingdom",
            carrierName = "Pennine Freight Logistics",
            trackingNumber = "PFL-9920481-UK",
            orderedQty = 400L,
            dispatchedQty = 400L,
            deliveredQty = 320L,
            acceptedQty = 320L,
            rejectedQty = 0L,
            status = ShipmentStatus.PART_DELIVERED,
            discrepancyReason = "80 cases held on backhaul trailer #2 (ETA +24h)",
            documents = listOf(
                ProvenanceDocument("DOC-1", "Packing List", "PL_AT1047_v1.pdf", "a9f3c1e2", "Northshore Consumer Supply", nowMs - 700_000L),
                ProvenanceDocument("DOC-2", "FSC Chain-of-Custody", "FSC_99210.pdf", "4d11b80a", "Northshore Consumer Supply", nowMs - 700_000L),
            ),
            lastEventMs = nowMs - 200_000L,
        ),
    )

    fun seedInvoices(nowMs: Long): List<CommercialInvoice> = listOf(
        CommercialInvoice(
            invoiceId = "INV-8812",
            referenceId = "AT-1047",
            shipmentId = "SHP-7701",
            counterpartyName = "Northshore Consumer Supply",
            invoicedQty = 320L,
            acceptedQty = 320L,
            unitPrice = bd("19.40"),
            taxAmount = bd("1241.60"),
            grossAmount = bd("7449.60"),
            paidAmount = bd("4000.00"),
            settlementCurrency = CurrencyCode.USD,
            bankAccountMask = "GB88 •••• 9102",
            status = InvoiceStatus.PART_PAID,
            issuedAtMs = nowMs - 150_000L,
        ),
    )

    fun seedFuturesSpecs(): List<FuturesContractSpec> = listOf(
        FuturesContractSpec(
            contractCode = "HOMECARE-MAR27",
            displayTitle = "HOMECARE INDEX • MAR27",
            underlyingIndexOrProduct = "Illustrative Synthetic UK Wholesale Homecare Basket (non-exchange)",
            contractSize = 100L,
            quotationUnit = "USD / case-eq",
            tickSize = bd("0.10"),
            tickValue = bd("10.00"),
            contractMonths = listOf("DEC26", "MAR27", "JUN27", "SEP27"),
            lastTradingDate = "2027-03-19",
            expiryDate = "2027-03-22",
            initialMarginPerContract = bd("1000.00"),
            maintenanceMarginPerContract = bd("750.00"),
            positionLimitContracts = 50,
            settlementMethod = FuturesSettlementMethod.CASH_SETTLEMENT,
            referencePriceMethodology = "Volume-weighted synthetic index of 5 UK Homecare SKUs; fallback to 3-day VWAP if <10 prints.",
            deliverableSpecsIfPhysical = "Cash-settled simulation only. Physical delivery not enabled on index.",
            disruptionFallbackRule = "If reference feed pauses >24h, settlement freezes at last valid TWAP pending Risk committee review.",
            currentMarkPrice = bd("37.40"),
            priorSettlementPrice = bd("36.20"),
            dailyVolumeContracts = 412L,
            openInterestContracts = 1890L,
            simulatedBookBids = listOf(
                BookLevel(bd("37.30"), 3, 2),
                BookLevel(bd("37.10"), 4, 2),
                BookLevel(bd("36.80"), 5, 1),
            ),
            simulatedBookAsks = listOf(
                BookLevel(bd("37.50"), 4, 2),
                BookLevel(bd("37.70"), 6, 3),
            ),
            isLiveTradingEnabled = false,
        ),
        FuturesContractSpec(
            contractCode = "DETERGENT-JUN27",
            displayTitle = "UK DETERGENT 1L • JUN27",
            underlyingIndexOrProduct = "Standardised 12×1L Bio Laundry Detergent Demo Spec",
            contractSize = 100L,
            quotationUnit = "USD / case",
            tickSize = bd("0.10"),
            tickValue = bd("10.00"),
            contractMonths = listOf("MAR27", "JUN27", "SEP27"),
            lastTradingDate = "2027-06-18",
            expiryDate = "2027-06-21",
            initialMarginPerContract = bd("1100.00"),
            maintenanceMarginPerContract = bd("800.00"),
            positionLimitContracts = 40,
            settlementMethod = FuturesSettlementMethod.PHYSICAL_DELIVERY_DEMO,
            referencePriceMethodology = "Demonstrative closing auction mid-price; not an exchange benchmark.",
            deliverableSpecsIfPhysical = "12×1L Bio Grade A, ≥12m shelf life, DAP Leeds bonded bay, COA + SDS required.",
            disruptionFallbackRule = "Cash fallback at last 5-day average if warehouse bay allocation halted.",
            currentMarkPrice = bd("37.90"),
            priorSettlementPrice = bd("37.60"),
            dailyVolumeContracts = 165L,
            openInterestContracts = 640L,
            simulatedBookBids = listOf(
                BookLevel(bd("37.80"), 2, 1),
                BookLevel(bd("37.40"), 3, 2),
            ),
            simulatedBookAsks = listOf(
                BookLevel(bd("38.00"), 3, 1),
                BookLevel(bd("38.30"), 5, 2),
            ),
            isLiveTradingEnabled = false,
        ),
        FuturesContractSpec(
            contractCode = "RAPESEED-CPG-SEP27",
            displayTitle = "RAPESEED OIL CPG • SEP27",
            underlyingIndexOrProduct = "Refined Non-GMO Food-Grade Rapeseed 2×10L Basket",
            contractSize = 100L,
            quotationUnit = "USD / case",
            tickSize = bd("0.10"),
            tickValue = bd("10.00"),
            contractMonths = listOf("JUN27", "SEP27", "DEC27"),
            lastTradingDate = "2027-09-17",
            expiryDate = "2027-09-20",
            initialMarginPerContract = bd("950.00"),
            maintenanceMarginPerContract = bd("700.00"),
            positionLimitContracts = 60,
            settlementMethod = FuturesSettlementMethod.CASH_SETTLEMENT,
            referencePriceMethodology = "Rotterdam FOB synthetic basket index; requires min 5 independent contributors.",
            deliverableSpecsIfPhysical = "Cash-settled simulation only. Does NOT guarantee branded retail bottle delivery.",
            disruptionFallbackRule = "Fallback to prior published settlement + verified freight spread.",
            currentMarkPrice = bd("26.10"),
            priorSettlementPrice = bd("25.80"),
            dailyVolumeContracts = 228L,
            openInterestContracts = 910L,
            simulatedBookBids = listOf(
                BookLevel(bd("26.00"), 4, 2),
                BookLevel(bd("25.70"), 4, 1),
            ),
            simulatedBookAsks = listOf(
                BookLevel(bd("26.20"), 5, 2),
                BookLevel(bd("26.50"), 6, 2),
            ),
            isLiveTradingEnabled = false,
        ),
    )

    fun seedFuturesPositions(nowMs: Long): List<FuturesPosition> = listOf(
        FuturesPosition(
            positionId = "FUT-POS-HOMECARE-MAR27",
            accountId = ORG_AUREOM_DESK,
            contractCode = "HOMECARE-MAR27",
            displayTitle = "HOMECARE INDEX • MAR27",
            netContracts = 2, // Long 2 contracts
            closedContracts = 0,
            avgEntryPrice = bd("36.20"),
            settlementBasisPrice = bd("36.20"),
            realisedPnL = BigDecimal.ZERO,
            cumulativeVariationSettled = BigDecimal.ZERO,
            tradingFeesPaid = bd("9.00"),
            updatedAtMs = nowMs - 1_500_000L,
        ),
    )

    fun seedCollateralAccount(): FuturesCollateralAccount = FuturesCollateralAccount(
        accountId = ORG_AUREOM_DESK,
        cashCollateralPosted = bd("18400.00"),
        realisedTradingPnL = BigDecimal.ZERO,
        feesCharged = bd("9.00"),
        currency = CurrencyCode.USD,
        lastSettlementDate = "2026-11-14",
    )

    fun seedAlerts(nowMs: Long): List<SurveillanceAlert> = listOf(
        SurveillanceAlert(
            alertId = "ALT-101",
            category = "Contract Approval",
            severity = AlertSeverity.AMBER,
            title = "1 forward contract awaiting approval",
            detail = "FWD-2088 (600 cases Laundry Liquid @ $36.45) requires Approver sign-off under dual-control threshold.",
            relatedRecordId = "FWD-2088",
            timestampMs = nowMs - 900_000L,
        ),
        SurveillanceAlert(
            alertId = "ALT-102",
            category = "Delivery Exception",
            severity = AlertSeverity.AMBER,
            title = "Partial delivery discrepancy on SHP-7701",
            detail = "320 of 400 cases accepted for AT-1047; 80 cases delayed on trailer #2.",
            relatedRecordId = "SHP-7701",
            timestampMs = nowMs - 200_000L,
        ),
        SurveillanceAlert(
            alertId = "ALT-103",
            category = "Inventory Freshness",
            severity = AlertSeverity.INFO,
            title = "External 3PL stock sync 30m old (Rotterdam)",
            detail = "BATCH-CO-2026-D reported via External 3PL EDI Feed; 60 cases quarantined.",
            relatedRecordId = "BATCH-CO-2026-D",
            timestampMs = nowMs - 1_800_000L,
        ),
    )

    fun priceHistoryFor(instrumentId: String): List<PricePoint> {
        val base = when (instrumentId) {
            "LAUNDRY-LIQ-UK-DEC26" -> listOf(
                "Sep 1" to "34.15", "Sep 8" to "34.45", "Sep 15" to "34.60", "Sep 22" to "34.90",
                "Oct 1" to "34.80", "Oct 8" to "35.15", "Oct 15" to "35.60", "Oct 22" to "35.40",
                "Nov 1" to "36.10", "Nov 8" to "36.40", "Nov 15" to "36.85", "Nov 22" to "36.25",
                "Nov 28" to "35.95", "Dec 1" to "36.20"
            )
            "BODY-WASH-UK-DEC26" -> listOf(
                "Sep 1" to "27.80", "Sep 15" to "28.05", "Oct 1" to "28.20", "Oct 15" to "28.45",
                "Nov 1" to "28.60", "Nov 15" to "28.95", "Dec 1" to "28.80"
            )
            "TISSUE-PACK-UK-JAN27" -> listOf(
                "Sep 1" to "19.85", "Sep 15" to "19.70", "Oct 1" to "19.65", "Oct 15" to "19.50",
                "Nov 1" to "19.55", "Nov 15" to "19.45", "Dec 1" to "19.40"
            )
            "COOKING-OIL-NL-DEC26" -> listOf(
                "Sep 1" to "23.90", "Sep 15" to "24.20", "Oct 1" to "24.60", "Oct 15" to "24.85",
                "Nov 1" to "25.05", "Nov 15" to "25.40", "Dec 1" to "25.20"
            )
            else -> listOf(
                "Sep 1" to "26.10", "Sep 15" to "26.35", "Oct 1" to "26.50", "Oct 15" to "26.80",
                "Nov 1" to "26.95", "Nov 15" to "27.20", "Dec 1" to "27.10"
            )
        }
        return base.mapIndexed { idx, (label, p) ->
            PricePoint(
                label = label,
                price = bd(p),
                volume = 4200L + (idx * 680L % 7500L),
                source = if (idx == base.lastIndex) PriceSourceType.COMMITTED_TRADE else PriceSourceType.FIRM_OFFER,
            )
        }
    }

    fun forwardCurveFor(instrument: PhysicalInstrument): List<ForwardCurvePoint> {
        val spot = instrument.referenceSpotPrice
        val months = listOf("Dec" to "0.10", "Jan" to "0.40", "Feb" to "0.70", "Mar" to "1.20", "Apr" to "1.60")
        return months.mapIndexed { idx, (m, carry) ->
            val carryBd = bd(carry)
            val fin = carryBd.multiply(bd("0.45")).setScale(2, java.math.RoundingMode.HALF_EVEN)
            val store = carryBd.multiply(bd("0.35")).setScale(2, java.math.RoundingMode.HALF_EVEN)
            val shelf = carryBd.subtract(fin).subtract(store)
            val p = spot.subtract(bd("0.20")).add(carryBd)
            ForwardCurvePoint(
                deliveryMonth = m,
                price = p,
                basisVsSpot = p.subtract(spot),
                financingCarryCost = fin,
                storageInsuranceCost = store,
                shelfLifeRiskAdjustment = shelf,
                openQuoteCount = 3 + (idx % 3),
                sourceLabel = "Indicative forward offers (cost-of-carry + shelf-life decay)",
            )
        }
    }

    fun procurementPlanRows(
        inventories: List<InventoryBatch>,
        contracts: List<ForwardContract>,
        positions: List<FuturesPosition>,
    ): List<ProcurementPlanRow> {
        val laundryInv = inventories.filter { it.instrumentId == "LAUNDRY-LIQ-UK-DEC26" }.sumOf { it.availableQty }
        val tissueInv = inventories.filter { it.instrumentId == "TISSUE-PACK-UK-JAN27" }.sumOf { it.availableQty }
        val oilInv = inventories.filter { it.instrumentId == "COOKING-OIL-NL-DEC26" }.sumOf { it.availableQty }

        val laundryFwd = contracts.filter { it.instrumentId == "LAUNDRY-LIQ-UK-DEC26" && it.status != ForwardContractStatus.CANCELLED }.sumOf { it.contractedQty }
        val tissueFwd = contracts.filter { it.instrumentId == "TISSUE-PACK-UK-JAN27" && it.status != ForwardContractStatus.CANCELLED }.sumOf { it.contractedQty }

        val homecareHedgeCases = positions.filter { it.contractCode == "HOMECARE-MAR27" }.sumOf { it.netContracts * 100L }

        return listOf(
            ProcurementPlanRow(
                category = ProductCategory.LAUNDRY,
                label = "Laundry Liquid 12×1L (Q4–Q1)",
                deliveryPeriod = "Dec 2026 – Mar 2027",
                expectedRequirementCases = 3500L,
                availableInventoryCases = laundryInv,
                spotOrdersCases = 120L,
                forwardCommittedCases = laundryFwd,
                futuresHedgeEquivalentCases = homecareHedgeCases,
                currencyExposure = CurrencyCode.USD,
                basisRiskNote = "HOMECARE INDEX tracks multi-SKU basket; ≠ guaranteed AureoClean 12×1L delivery.",
                timingMismatchNote = "Futures expire Mar 2027 vs Dec/Feb physical shelf replenishment.",
            ),
            ProcurementPlanRow(
                category = ProductCategory.PAPER,
                label = "SoftWeave 3-Ply Tissue (Jan 2027)",
                deliveryPeriod = "Jan 2027",
                expectedRequirementCases = 3800L,
                availableInventoryCases = tissueInv,
                spotOrdersCases = 0L,
                forwardCommittedCases = tissueFwd,
                futuresHedgeEquivalentCases = 0L,
                currencyExposure = CurrencyCode.USD,
                basisRiskNote = "No liquid CPG tissue futures contract; 100% physical procurement exposure.",
                timingMismatchNote = "80 cases backhaul pending on SHP-7701.",
            ),
            ProcurementPlanRow(
                category = ProductCategory.COOKING_OILS,
                label = "Generic Rapeseed Oil 2×10L",
                deliveryPeriod = "Dec 2026 – Q1 2027",
                expectedRequirementCases = 2400L,
                availableInventoryCases = oilInv,
                spotOrdersCases = 0L,
                forwardCommittedCases = 0L,
                futuresHedgeEquivalentCases = 0L,
                currencyExposure = CurrencyCode.EUR,
                basisRiskNote = "Cross-border Rotterdam FOB (EUR freight/duty) vs UK GBP retail sales.",
                timingMismatchNote = "5–8 day sea/ferry transit + customs clearance lead.",
            ),
        )
    }
}
