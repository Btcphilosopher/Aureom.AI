package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ForwardCurvePoint
import com.example.domain.model.PricePoint
import com.example.ui.theme.LocalAureomPalette
import com.example.ui.theme.MonoTabularStyle

@Composable
fun PriceVolumeChart(
    points: List<PricePoint>,
    modifier: Modifier = Modifier,
) {
    val palette = LocalAureomPalette.current
    if (points.isEmpty()) return

    val prices = points.map { it.price.toFloat() }
    val minP = (prices.minOrNull() ?: 0f) - 0.4f
    val maxP = (prices.maxOrNull() ?: 1f) + 0.4f
    val span = (maxP - minP).coerceAtLeast(0.5f)
    val maxVol = (points.maxOfOrNull { it.volume } ?: 1L).toFloat().coerceAtLeast(1f)

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Canvas(
                modifier = Modifier
                    .weight(1f)
                    .height(175.dp)
            ) {
                val w = size.width
                val h = size.height
                val chartH = h * 0.72f
                val volTop = h * 0.76f
                val volH = h * 0.22f
                val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))

                // Horizontal grid lines
                for (i in 0..4) {
                    val y = chartH * (i / 4f)
                    drawLine(
                        color = palette.border,
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f,
                        pathEffect = dash,
                    )
                }

                // Volume histogram bars
                val barSlot = w / points.size.coerceAtLeast(1)
                val barWidth = (barSlot * 0.56f).coerceAtLeast(4f)
                points.forEachIndexed { idx, pt ->
                    val ratio = pt.volume / maxVol
                    val bh = volH * ratio
                    val x = idx * barSlot + (barSlot - barWidth) / 2f
                    drawRect(
                        color = palette.accent.copy(alpha = 0.45f),
                        topLeft = Offset(x, volTop + (volH - bh)),
                        size = Size(barWidth, bh),
                    )
                }

                // Price area & line
                val stepX = if (points.size > 1) w / (points.size - 1) else w
                val linePath = Path()
                val fillPath = Path()

                points.forEachIndexed { idx, pt ->
                    val x = idx * stepX
                    val y = chartH - ((pt.price.toFloat() - minP) / span) * chartH
                    if (idx == 0) {
                        linePath.moveTo(x, y)
                        fillPath.moveTo(x, chartH)
                        fillPath.lineTo(x, y)
                    } else {
                        linePath.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                    if (idx == points.lastIndex) {
                        fillPath.lineTo(x, chartH)
                        fillPath.close()
                    }
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(palette.accent.copy(alpha = 0.26f), palette.accent.copy(alpha = 0.01f)),
                        startY = 0f,
                        endY = chartH,
                    ),
                )
                drawPath(
                    path = linePath,
                    color = palette.accent,
                    style = Stroke(width = 3f, cap = StrokeCap.Round),
                )

                // Current price terminal marker
                val lastY = chartH - ((points.last().price.toFloat() - minP) / span) * chartH
                drawCircle(color = palette.panelBg, radius = 6f, center = Offset(w, lastY))
                drawCircle(color = palette.accent, radius = 4f, center = Offset(w, lastY))
            }

            // Right price axis labels
            Column(
                modifier = Modifier
                    .padding(start = 6.dp)
                    .height(132.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.End,
            ) {
                for (i in 0..4) {
                    val value = maxP - (span * (i / 4f))
                    Text(
                        text = String.format("%.2f", value),
                        style = MonoTabularStyle.copy(fontSize = 10.sp),
                        color = palette.textSecondary,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(end = 36.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            val labels = listOfNotNull(
                points.firstOrNull()?.label,
                points.getOrNull(points.size / 3)?.label,
                points.getOrNull((points.size * 2) / 3)?.label,
                points.lastOrNull()?.label,
            ).distinct()
            labels.forEach { lbl ->
                Text(
                    text = lbl,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textMuted,
                )
            }
        }
    }
}

@Composable
fun DeliveryCurveChart(
    curve: List<ForwardCurvePoint>,
    modifier: Modifier = Modifier,
) {
    val palette = LocalAureomPalette.current
    if (curve.isEmpty()) return

    val prices = curve.map { it.price.toFloat() }
    val minP = (prices.minOrNull() ?: 0f) - 0.35f
    val maxP = (prices.maxOrNull() ?: 1f) + 0.35f
    val span = (maxP - minP).coerceAtLeast(0.5f)

    Column(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(108.dp)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            val w = size.width
            val h = size.height
            val stepX = if (curve.size > 1) w / (curve.size - 1) else w
            val dash = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))

            for (i in 0..3) {
                val y = h * (i / 3f)
                drawLine(color = palette.border, start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f, pathEffect = dash)
            }

            val path = Path()
            val pts = curve.mapIndexed { idx, point ->
                val x = idx * stepX
                val y = h - ((point.price.toFloat() - minP) / span) * h
                Offset(x, y)
            }
            pts.forEachIndexed { idx, p ->
                if (idx == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            drawPath(path = path, color = palette.accent, style = Stroke(width = 3f, cap = StrokeCap.Round))
            pts.forEach { p ->
                drawCircle(color = palette.panelBg, radius = 6.5f, center = p)
                drawCircle(color = palette.accent, radius = 4.5f, center = p)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            curve.forEach { pt ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = pt.price.toPlainString(),
                        style = MonoTabularStyle.copy(fontSize = 10.sp),
                        color = palette.textPrimary,
                    )
                    Text(
                        text = pt.deliveryMonth,
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textMuted,
                    )
                }
            }
        }
    }
}
