package com.example.domain.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class TerminalTab(val label: String) {
    MARKETS("Markets"),
    TRADE("Trade"),
    RFQS("RFQs"),
    CONTRACTS("Contracts"),
    INVENTORY("Inventory"),
    DELIVERIES("Deliveries"),
    POSITIONS("Positions"),
    RISK("Risk"),
    FINANCE("Finance"),
    REPORTS("Reports"),
    ADMINISTRATION("Administration"),
}

enum class OrgRole(
    val label: String,
    val canPlaceSpotOrders: Boolean,
    val canApproveContracts: Boolean,
    val canManageInventory: Boolean,
    val canReconcileFinance: Boolean,
    val canManageRiskAndHalts: Boolean,
    val canAdministerOrgs: Boolean,
) {
    TRADER("Trader", true, false, false, false, false, false),
    PROCUREMENT_MANAGER("Procurement Manager", true, true, false, false, false, false),
    SALES_MANAGER("Sales Manager", true, true, false, false, false, false),
    APPROVER("Approver", false, true, false, false, false, false),
    WAREHOUSE_OPERATOR("Warehouse Operator", false, false, true, false, false, false),
    FINANCE_ANALYST("Finance Analyst", false, false, false, true, false, false),
    RISK_MANAGER("Risk Manager", false, false, false, false, true, false),
    ADMIN("Administrator", true, true, true, true, true, true),
}

data class OrganizationAccount(
    val orgId: String,
    val name: String,
    val country: String,
    val creditLimitUsd: BigDecimal,
    val usedCreditUsd: BigDecimal,
    val orderValueLimitUsd: BigDecimal,
    val approvalThresholdUsd: BigDecimal,
    val positionLimitContracts: Int,
    val bankDetailsMask: String,
    val pendingBankChangeRequest: String? = null,
    val kycVerified: Boolean = true,
    val activityHalted: Boolean = false,
) {
    val availableCreditUsd: BigDecimal
        get() = (creditLimitUsd.subtract(usedCreditUsd)).coerceAtLeast(BigDecimal.ZERO)
}

enum class AlertSeverity(val label: String) {
    INFO("Info"),
    AMBER("Review Signal"),
    CRITICAL("Critical Exception"),
}

data class SurveillanceAlert(
    val alertId: String,
    val category: String,
    val severity: AlertSeverity,
    val title: String,
    val detail: String,
    val relatedRecordId: String,
    val isReviewSignalOnly: Boolean = true,
    val acknowledged: Boolean = false,
    val timestampMs: Long,
)

data class FreightDutyTaxAdapter(
    val version: String,
    val routeKey: String,
    val freightPerCaseUsd: BigDecimal,
    val insurancePct: BigDecimal,
    val customsDutyPct: BigDecimal,
    val importTaxPct: BigDecimal,
    val portHandlingPerCaseUsd: BigDecimal,
)

data class LandedCostBreakdown(
    val baseUnitPrice: BigDecimal,
    val currency: CurrencyCode,
    val tradeTerm: TradeTerm,
    val freightIncludedInPrice: BigDecimal,
    val additionalFreight: BigDecimal,
    val insuranceCost: BigDecimal,
    val customsDuty: BigDecimal,
    val importTax: BigDecimal,
    val handlingFee: BigDecimal,
    val adapterVersion: String,
    val assumptionsNote: String,
) {
    val estimatedLandedPerCase: BigDecimal
        get() = baseUnitPrice
            .add(additionalFreight)
            .add(insuranceCost)
            .add(customsDuty)
            .add(importTax)
            .add(handlingFee)
            .setScale(currency.scale, RoundingMode.HALF_EVEN)
}

object LandedCostCalculator {
    fun compute(
        basePrice: BigDecimal,
        currency: CurrencyCode,
        tradeTerm: TradeTerm,
        adapter: FreightDutyTaxAdapter,
    ): LandedCostBreakdown {
        // Avoid double-counting freight/insurance/duty already included in trade term
        val additionalFreight = if (tradeTerm.includesMainFreight) BigDecimal.ZERO else adapter.freightPerCaseUsd
        val insurance = if (tradeTerm.includesInsurance) BigDecimal.ZERO
        else basePrice.multiply(adapter.insurancePct).divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_EVEN)
        val duty = if (tradeTerm.includesImportDuty) BigDecimal.ZERO
        else basePrice.add(additionalFreight).multiply(adapter.customsDutyPct).divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_EVEN)
        val tax = basePrice.add(additionalFreight).add(duty)
            .multiply(adapter.importTaxPct).divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_EVEN)

        return LandedCostBreakdown(
            baseUnitPrice = basePrice,
            currency = currency,
            tradeTerm = tradeTerm,
            freightIncludedInPrice = if (tradeTerm.includesMainFreight) adapter.freightPerCaseUsd else BigDecimal.ZERO,
            additionalFreight = additionalFreight.setScale(currency.scale, RoundingMode.HALF_EVEN),
            insuranceCost = insurance.setScale(currency.scale, RoundingMode.HALF_EVEN),
            customsDuty = duty.setScale(currency.scale, RoundingMode.HALF_EVEN),
            importTax = tax.setScale(currency.scale, RoundingMode.HALF_EVEN),
            handlingFee = adapter.portHandlingPerCaseUsd.setScale(currency.scale, RoundingMode.HALF_EVEN),
            adapterVersion = adapter.version,
            assumptionsNote = "Adapter ${adapter.version}; ${tradeTerm.code} avoids double-counting pre-included freight/insurance/duty.",
        )
    }
}

data class ProcurementPlanRow(
    val category: ProductCategory,
    val label: String,
    val deliveryPeriod: String,
    val expectedRequirementCases: Long,
    val availableInventoryCases: Long,
    val spotOrdersCases: Long,
    val forwardCommittedCases: Long,
    val futuresHedgeEquivalentCases: Long,
    val currencyExposure: CurrencyCode,
    val basisRiskNote: String,
    val timingMismatchNote: String,
) {
    val totalPhysicalCoverageCases: Long
        get() = availableInventoryCases + spotOrdersCases + forwardCommittedCases
    val physicalCoveragePct: BigDecimal
        get() = if (expectedRequirementCases > 0) {
            BigDecimal.valueOf(totalPhysicalCoverageCases * 100)
                .divide(BigDecimal.valueOf(expectedRequirementCases), 1, RoundingMode.HALF_EVEN)
        } else BigDecimal.ZERO
    val remainingPhysicalGapCases: Long
        get() = (expectedRequirementCases - totalPhysicalCoverageCases).coerceAtLeast(0L)
}

data class WorkspacePreset(
    val presetId: String,
    val name: String,
    val activeTab: TerminalTab,
    val marketMode: MarketMode,
    val displayCurrency: CurrencyCode,
    val isDarkTheme: Boolean,
    val isCompactDensity: Boolean,
)

data class DemoStepStatus(
    val stepNumber: Int,
    val title: String,
    val description: String,
    val completed: Boolean,
    val evidenceId: String? = null,
)
