package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AlertSeverity
import com.example.domain.model.CurrencyCode
import com.example.domain.model.DecimalMath
import com.example.domain.model.DecimalMath.bd
import com.example.domain.model.OrderSide
import com.example.domain.model.OrgRole
import com.example.ui.TerminalUiState
import com.example.ui.TerminalViewModel
import com.example.ui.components.TerminalPanel
import com.example.ui.theme.LocalAureomPalette
import com.example.ui.theme.MonoTabularStyle
import java.math.BigDecimal

@Composable
fun PositionsScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(title = "Procurement Coverage, Hedging & Basis Risk Workspace") {
            Text(
                "Maps anticipated wholesale requirements against Inventory, Spot Orders, Forward Commitments, and Simulated Futures. " +
                    "Buying index futures does NOT guarantee physical receipt of branded finished goods.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.warning,
            )
            Spacer(modifier = Modifier.height(8.dp))

            state.procurementRows.forEach { row ->
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(row.label, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(
                                "Coverage: ${row.physicalCoveragePct}%",
                                style = MonoTabularStyle.copy(fontSize = 13.sp, fontWeight = FontWeight.Bold),
                                color = if (row.physicalCoveragePct >= bd("80")) palette.positive else palette.warning,
                            )
                        }
                        Text(
                            "Expected Req: ${row.expectedRequirementCases} | Inventory: ${row.availableInventoryCases} | Spot: ${row.spotOrdersCases} | Forwards: ${row.forwardCommittedCases} | Physical Gap: ${row.remainingPhysicalGapCases}",
                            style = MonoTabularStyle.copy(fontSize = 11.sp),
                            color = palette.textPrimary,
                        )
                        Text(
                            "Financial Hedge Eq: ${row.futuresHedgeEquivalentCases} cases | Exposure CCY: ${row.currencyExposure.displayLabel}",
                            style = MonoTabularStyle.copy(fontSize = 11.sp),
                            color = palette.accent,
                        )
                        Text("Basis Risk: ${row.basisRiskNote}", style = MaterialTheme.typography.bodySmall, color = palette.warning)
                        Text("Timing Mismatch: ${row.timingMismatchNote}", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                    }
                }
            }
        }

        TerminalPanel(title = "Scenario Comparison (Not Investment Advice)") {
            Text(
                "• Scenario A (Spot + Forwards Only): Zero futures margin call risk; 100% supplier-specific SKU coverage; exposed to uncommitted spot gap (${state.procurementRows.sumOf { it.remainingPhysicalGapCases }} cases).",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textPrimary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "• Scenario B (Physical + Illustrative Index Futures Overlay): Offsets broad category cost variance via daily variation settlement, but introduces basis risk and cash collateral requirements.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
        }
    }
}

@Composable
fun RiskScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    val spec = state.selectedFuturesSpec
    val pos = state.futuresPositions.firstOrNull { it.contractCode == state.selectedFuturesCode }
    val unrealised = if (spec != null && pos != null) {
        pos.unrealisedVariationPnL(spec.currentMarkPrice, spec.contractMultiplier)
    } else BigDecimal.ZERO
    val totalEquity = state.collateral.netCollateralBalance(unrealised)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Explicit Futures Simulation Regulatory Lock Banner
        Surface(
            color = palette.warningBg,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, palette.warning),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = palette.warning, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "LIVE FUTURES TRADING DISABLED: Demonstration simulation only. Live futures require an authorised exchange/venue, registered broker, and licensed clearinghouse arrangement. Illustrative margin parameters below.",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = palette.warning,
                )
            }
        }

        TerminalPanel(title = "Futures Simulation Console & Margin Engine") {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                state.futuresSpecs.forEach { s ->
                    val active = s.contractCode == state.selectedFuturesCode
                    Surface(
                        color = if (active) palette.accentContainer else palette.panelElevated,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, if (active) palette.accent else palette.border),
                        modifier = Modifier.clickable { vm.selectFuturesSpec(s.contractCode) },
                    ) {
                        Text(s.displayTitle, style = MaterialTheme.typography.labelMedium, color = if (active) palette.accent else palette.textSecondary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (spec != null) {
                Text(
                    "${spec.underlyingIndexOrProduct} | Size: ${spec.contractSize} cases | Tick: ${spec.tickSize} ($${spec.tickValue}) | Expiry: ${spec.expiryDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
                Text(
                    "Settlement: ${spec.settlementMethod.label} | Init Margin: $${spec.initialMarginPerContract}/ct | Maint Margin: $${spec.maintenanceMarginPerContract}/ct",
                    style = MonoTabularStyle.copy(fontSize = 11.sp),
                    color = palette.textPrimary,
                )
                Text("Fallback Rule: ${spec.disruptionFallbackRule}", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.openSimulatedFutures(spec.contractCode, OrderSide.BUY, 2) },
                        modifier = Modifier.weight(1f).testTag("sim_buy_futures"),
                    ) {
                        Text("Sim Buy +2")
                    }
                    OutlinedButton(
                        onClick = { vm.openSimulatedFutures(spec.contractCode, OrderSide.SELL, 2) },
                        modifier = Modifier.weight(1f).testTag("sim_sell_futures"),
                    ) {
                        Text("Sim Sell -2")
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.runDailySettlement(spec.contractCode, spec.currentMarkPrice.add(bd("0.60"))) },
                        modifier = Modifier.weight(1f).testTag("daily_settlement_btn"),
                    ) {
                        Text("Run Daily Settle (+$0.60)")
                    }
                    Button(
                        onClick = { vm.triggerMarginStressScenario() },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.negative, contentColor = palette.onAccent),
                        modifier = Modifier.weight(1f).testTag("stress_margin_btn"),
                    ) {
                        Text("Simulate Margin Shortfall")
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = palette.border)
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                "Collateral Account (${state.collateral.accountId}): Cash Posted ${DecimalMath.formatCurrency(state.collateral.cashCollateralPosted, CurrencyCode.USD)} | " +
                    "Realised Variation ${DecimalMath.formatCurrency(state.collateral.realisedTradingPnL, CurrencyCode.USD, true)} | " +
                    "Fees ${DecimalMath.formatCurrency(state.collateral.feesCharged, CurrencyCode.USD)} | " +
                    "Net Equity ${DecimalMath.formatCurrency(totalEquity, CurrencyCode.USD)}",
                style = MonoTabularStyle.copy(fontSize = 11.sp),
                color = palette.textPrimary,
            )

            state.lastSettlement?.let { s ->
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Last Settlement (${s.settlementDate}): ${s.oldSettlementPrice} -> ${s.newSettlementPrice} | Variation Δ: ${DecimalMath.formatCurrency(s.variationMarginDelta, CurrencyCode.USD, true)} | Status: ${s.status.label}",
                    style = MonoTabularStyle.copy(fontSize = 11.sp),
                    color = palette.accent,
                )
            }
            state.lastForcedReduction?.let { r ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = r.explanation,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = if (r.liquidityInsufficient) palette.negative else palette.positive,
                )
            }
        }

        // Surveillance Alerts (Review Signals)
        TerminalPanel(title = "Surveillance & Exception Alerts (Review Signals — Not Automatic Findings)") {
            state.alerts.forEach { a ->
                Surface(
                    color = if (a.severity == AlertSeverity.CRITICAL) palette.negativeBg else palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (a.severity == AlertSeverity.CRITICAL) palette.negative else palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("[${a.category}] ${a.title}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = palette.textPrimary)
                            Text(a.detail, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                        if (!a.acknowledged) {
                            OutlinedButton(onClick = { vm.acknowledgeAlert(a) }) {
                                Text("Ack")
                            }
                        } else {
                            Text("Reviewed", style = MaterialTheme.typography.labelSmall, color = palette.positive)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FinanceScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(title = "Commercial Invoices, Payment Reconciliation & Dual-Control Settlement") {
            Text(
                "Display currency (${state.displayCurrency.displayLabel}) never alters a contract's settlement currency. Invoices reconcile strictly against accepted delivery quantities.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
            Spacer(modifier = Modifier.height(8.dp))
            state.invoices.forEach { inv ->
                Surface(
                    color = palette.panelElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${inv.invoiceId} • Ref ${inv.referenceId} (${inv.counterpartyName})", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(inv.status.label, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = palette.accent)
                        }
                        Text(
                            "Invoiced: ${inv.invoicedQty} | Accepted: ${inv.acceptedQty} | Unit: ${DecimalMath.formatCurrency(inv.unitPrice, inv.settlementCurrency)} | Tax: ${DecimalMath.formatCurrency(inv.taxAmount, inv.settlementCurrency)}",
                            style = MonoTabularStyle.copy(fontSize = 11.sp),
                            color = palette.textSecondary,
                        )
                        Text(
                            "Gross: ${DecimalMath.formatCurrency(inv.grossAmount, inv.settlementCurrency)} | Paid: ${DecimalMath.formatCurrency(inv.paidAmount, inv.settlementCurrency)} | Due: ${DecimalMath.formatCurrency(inv.balanceDue, inv.settlementCurrency)} | Bank: ${inv.bankAccountMask}",
                            style = MonoTabularStyle.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
                            color = palette.textPrimary,
                        )
                        if (inv.balanceDue > BigDecimal.ZERO) {
                            Button(
                                onClick = { vm.reconcileInvoice(inv, inv.balanceDue) },
                                modifier = Modifier.testTag("reconcile_invoice_${inv.invoiceId}"),
                            ) {
                                Text("Reconcile Accepted Qty & Settle Balance")
                            }
                        }
                    }
                }
            }
        }

        TerminalPanel(title = "Controlled Bank-Detail Change Workflow") {
            val desk = state.activeOrg
            if (desk != null) {
                Text("Active Org: ${desk.name} | Current Bank: ${desk.bankDetailsMask}", style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                desk.pendingBankChangeRequest?.let { pending ->
                    Text("Pending Dual-Control Change: $pending", style = MaterialTheme.typography.bodySmall, color = palette.warning)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.requestBankChange(desk.orgId, "GB92 •••• 8810 (ClearBank Escrow)") }) {
                        Text("Stage Bank Change (Finance)")
                    }
                    if (desk.pendingBankChangeRequest != null) {
                        Button(onClick = { vm.approveBankChange(desk.orgId) }) {
                            Text("Confirm Change (Admin/Approver)")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(
            title = "12-Step Complete Demonstration & Event-Log Recovery",
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { vm.runComplete12StepDemo() },
                    modifier = Modifier.weight(1f).testTag("run_12_step_demo_btn"),
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Run 12-Step Demo")
                }
                OutlinedButton(
                    onClick = { vm.replayEngineEvents() },
                    modifier = Modifier.weight(1f).testTag("replay_events_btn"),
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Replay Log (${state.engineSnapshot.eventCount})")
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            if (state.demoSteps.isEmpty()) {
                Text(
                    "Click 'Run 12-Step Demo' to execute all Section 18 workflows: firm wholesale offer, partial purchase, stock reservation, forward negotiation & approval, futures simulation, daily settlement, margin shortfall with thin liquidity, partial shipment, finance reconciliation, procurement basis risk, and deterministic event-log restart replay.",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                )
            } else {
                state.demoSteps.forEach { step ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = if (step.completed) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber,
                            contentDescription = null,
                            tint = if (step.completed) palette.positive else palette.warning,
                            modifier = Modifier.size(16.dp),
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${step.stepNumber}. ${step.title}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = palette.textPrimary)
                            Text(step.description, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                        step.evidenceId?.let { ev ->
                            Text(ev, style = MonoTabularStyle.copy(fontSize = 10.sp), color = palette.accent)
                        }
                    }
                    HorizontalDivider(color = palette.border.copy(alpha = 0.4f))
                }
            }
        }

        TerminalPanel(title = "Immutable Audit Log (Last ${state.auditLogs.size} Events)") {
            state.auditLogs.take(15).forEach { log ->
                Text(
                    "[${log.actorRole}] ${log.action} -> ${log.targetId}: ${log.detail}",
                    style = MonoTabularStyle.copy(fontSize = 11.sp),
                    color = palette.textSecondary,
                    modifier = Modifier.padding(vertical = 2.dp),
                )
            }
        }
    }
}

@Composable
fun AdministrationScreen(state: TerminalUiState, vm: TerminalViewModel) {
    val palette = LocalAureomPalette.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TerminalPanel(title = "Role-Based Access Control (Switch Active Persona)") {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                OrgRole.entries.forEach { role ->
                    val active = role == state.activeRole
                    Surface(
                        color = if (active) palette.accent else palette.panelElevated,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, if (active) palette.accent else palette.border),
                        modifier = Modifier
                            .clickable { vm.setActiveRole(role) }
                            .testTag("select_role_${role.name.lowercase()}"),
                    ) {
                        Text(
                            text = role.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (active) palette.onAccent else palette.textPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Permissions -> Spot Orders: ${state.activeRole.canPlaceSpotOrders} | Approve Contracts: ${state.activeRole.canApproveContracts} | Inventory: ${state.activeRole.canManageInventory} | Finance: ${state.activeRole.canReconcileFinance} | Risk/Halts: ${state.activeRole.canManageRiskAndHalts}",
                style = MonoTabularStyle.copy(fontSize = 11.sp),
                color = palette.accent,
            )
        }

        TerminalPanel(title = "Saved Workspaces & Terminal Preferences") {
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                state.workspacePresets.forEach { preset ->
                    OutlinedButton(onClick = { vm.applyWorkspacePreset(preset) }) {
                        Text(preset.name)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.toggleTheme() }) {
                    Text(if (state.isDarkTheme) "Switch to Light Theme" else "Switch to Dark Midnight Theme")
                }
                OutlinedButton(onClick = { vm.toggleDensity() }) {
                    Text("Density: ${state.density.label}")
                }
                OutlinedButton(onClick = { vm.resetDemo() }) {
                    Text("Reset Synthetic Data")
                }
            }
        }

        TerminalPanel(title = "Market Suspension & Counterparty Kill-Switch Controls") {
            state.instruments.take(4).forEach { inst ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${inst.productName} (${inst.id})", style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                    OutlinedButton(onClick = { vm.toggleMarketSuspension(inst.id, !inst.isSuspended) }) {
                        Text(if (inst.isSuspended) "Resume Market" else "Suspend Market")
                    }
                }
            }
            HorizontalDivider(color = palette.border)
            Spacer(modifier = Modifier.height(6.dp))
            state.organizations.take(3).forEach { org ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(org.name, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = palette.textPrimary)
                        Text("Credit: $${org.availableCreditUsd} avail / $${org.creditLimitUsd} limit", style = MonoTabularStyle.copy(fontSize = 10.sp), color = palette.textSecondary)
                    }
                    OutlinedButton(onClick = { vm.toggleOrgHalt(org.orgId, !org.activityHalted) }) {
                        Text(if (org.activityHalted) "Lift Halt" else "Halt New Orders")
                    }
                }
            }
        }

        TerminalPanel(title = "External Arrangements Required for Live Futures Trading") {
            Text(
                "1. Authorised Designated Contract Market / Multilateral Trading Facility venue listing the contracts.\n" +
                    "2. Regulated clearinghouse membership & segregated client collateral omnibus/ISA accounts.\n" +
                    "3. Authorised executing/clearing broker connectivity (FIX / clearing API) and regulatory trade reporting.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
            )
        }
    }
}
