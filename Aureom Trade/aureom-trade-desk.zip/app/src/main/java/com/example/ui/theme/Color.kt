package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

// Aureom Midnight-Blue & Cyan Identity (Dark Terminal - Default)
val MidnightShell = Color(0xFF06101E)
val DeepNavyCanvas = Color(0xFF081426)
val CharcoalPanel = Color(0xFF0C1B30)
val CharcoalElevated = Color(0xFF10243E)
val CharcoalHeader = Color(0xFF132A47)
val TerminalBorder = Color(0xFF1D3A5C)
val TerminalBorderActive = Color(0xFF00D1FF)

val AureomCyan = Color(0xFF00D1FF)
val AureomCyanDim = Color(0xFF0B4F6C)
val AureomCyanContainer = Color(0xFF09324A)

val TextPrimaryDark = Color(0xFFF0F6FC)
val TextSecondaryDark = Color(0xFF94A8C3)
val TextMutedDark = Color(0xFF637B99)

val BidGreen = Color(0xFF27C281)
val BidGreenBg = Color(0x2227C281)
val AskRed = Color(0xFFF25F6E)
val AskRedBg = Color(0x22F25F6E)
val AmberAlert = Color(0xFFF5A623)
val AmberAlertBg = Color(0x24F5A623)

// Optional Light Terminal Theme
val LightShell = Color(0xFFEEF3F8)
val LightPanel = Color(0xFFFFFFFF)
val LightElevated = Color(0xFFF6F9FC)
val LightHeader = Color(0xFFE3ECF5)
val LightBorder = Color(0xFFC5D5E6)
val LightCyan = Color(0xFF007799)
val LightCyanContainer = Color(0xFFD5F1FA)
val TextPrimaryLight = Color(0xFF0D1D33)
val TextSecondaryLight = Color(0xFF425A77)
val TextMutedLight = Color(0xFF6E849F)
val BidGreenLight = Color(0xFF128052)
val AskRedLight = Color(0xFFC6283B)
val AmberAlertLight = Color(0xFFB36B00)

@Immutable
data class AureomPalette(
    val isDark: Boolean,
    val shellBg: Color,
    val panelBg: Color,
    val panelElevated: Color,
    val panelHeader: Color,
    val border: Color,
    val accent: Color,
    val accentContainer: Color,
    val onAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val positive: Color,
    val positiveBg: Color,
    val negative: Color,
    val negativeBg: Color,
    val warning: Color,
    val warningBg: Color,
)

val DarkAureomPalette = AureomPalette(
    isDark = true,
    shellBg = MidnightShell,
    panelBg = CharcoalPanel,
    panelElevated = CharcoalElevated,
    panelHeader = CharcoalHeader,
    border = TerminalBorder,
    accent = AureomCyan,
    accentContainer = AureomCyanContainer,
    onAccent = Color(0xFF04131D),
    textPrimary = TextPrimaryDark,
    textSecondary = TextSecondaryDark,
    textMuted = TextMutedDark,
    positive = BidGreen,
    positiveBg = BidGreenBg,
    negative = AskRed,
    negativeBg = AskRedBg,
    warning = AmberAlert,
    warningBg = AmberAlertBg,
)

val LightAureomPalette = AureomPalette(
    isDark = false,
    shellBg = LightShell,
    panelBg = LightPanel,
    panelElevated = LightElevated,
    panelHeader = LightHeader,
    border = LightBorder,
    accent = LightCyan,
    accentContainer = LightCyanContainer,
    onAccent = Color.White,
    textPrimary = TextPrimaryLight,
    textSecondary = TextSecondaryLight,
    textMuted = TextMutedLight,
    positive = BidGreenLight,
    positiveBg = Color(0x1A128052),
    negative = AskRedLight,
    negativeBg = Color(0x1AC6283B),
    warning = AmberAlertLight,
    warningBg = Color(0x1FB36B00),
)
