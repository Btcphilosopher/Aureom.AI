import {initializeApp, getApps} from 'firebase/app';
import {getAuth, GoogleAuthProvider, signInWithPopup, signOut, User} from 'firebase/auth';
import {doc, getDocFromServer, getFirestore} from 'firebase/firestore';
import firebaseConfig from '../../../firebase-applet-config.json';

let initialized = false;

export function getFirebaseClient() {
  if (typeof window === 'undefined') {
    return null;
  }
  const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
  const auth = getAuth(app);
  const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
  const googleProvider = new GoogleAuthProvider();

  if (!initialized) {
    initialized = true;
    // Validate connection to provisioned Firestore database
    getDocFromServer(doc(db, 'test', 'connection')).catch((error: unknown) => {
      if (error instanceof Error && error.message.includes('the client is offline')) {
        console.warn('Firestore client offline check:', error.message);
      }
    });
  }

  return {app, auth, db, googleProvider};
}

export async function signInWithGooglePopup(): Promise<User | null> {
  const client = getFirebaseClient();
  if (!client) return null;
  const cred = await signInWithPopup(client.auth, client.googleProvider);
  return cred.user;
}

export async function signOutFirebase(): Promise<void> {
  const client = getFirebaseClient();
  if (!client) return;
  await signOut(client.auth);
}
