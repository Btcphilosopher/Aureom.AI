import {Injectable, computed, inject, signal} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {firstValueFrom} from 'rxjs';
import {
  CartItem,
  CurrencyCode,
  DocumentRecord,
  InventoryRecord,
  Invoice,
  LandedCostBreakdown,
  MessageThread,
  Offer,
  Order,
  OrgUser,
  Organisation,
  PlatformConfig,
  Product,
  Rfq,
  Shipment,
  StockLedgerEntry,
  UserRole,
} from './models';
import {signInWithGooglePopup, signOutFirebase} from './firebase';

interface BootstrapResponse {
  actor: {orgId: string; role: UserRole; userId: string};
  activeOrg: Organisation;
  organisations: Organisation[];
  users: OrgUser[];
  products: Product[];
  offers: Offer[];
  rfqs: Rfq[];
  orders: Order[];
  shipments: Shipment[];
  invoices: Invoice[];
  inventory: InventoryRecord[];
  stockLedger: StockLedgerEntry[];
  documents: DocumentRecord[];
  threads: MessageThread[];
  shortlistOfferIds: string[];
  platformConfig: PlatformConfig;
}

export interface PersonaPreset {
  userId: string;
  name: string;
  orgId: string;
  orgName: string;
  role: UserRole;
  roleLabel: string;
}

export const PERSONA_PRESETS: PersonaPreset[] = [
  {
    userId: 'usr_claire_buyer',
    name: 'Claire Bennett',
    orgId: 'org_albion_uk',
    orgName: 'Albion Retail Group (UK Buyer)',
    role: 'buyer',
    roleLabel: 'Buyer',
  },
  {
    userId: 'usr_marcus_approver',
    name: 'Marcus Vance',
    orgId: 'org_albion_uk',
    orgName: 'Albion Retail Group (UK Buyer)',
    role: 'procurement_approver',
    roleLabel: 'Procurement Approver',
  },
  {
    userId: 'usr_helen_finance',
    name: 'Helen Patel',
    orgId: 'org_albion_uk',
    orgName: 'Albion Retail Group (UK Buyer)',
    role: 'finance_user',
    roleLabel: 'Finance User',
  },
  {
    userId: 'usr_owen_seller',
    name: 'Owen Davies',
    orgId: 'org_aureom_direct',
    orgName: 'Aureom Direct Supply (1P Seller)',
    role: 'seller_manager',
    roleLabel: 'Seller Manager',
  },
  {
    userId: 'usr_sam_warehouse',
    name: 'Samira Khan',
    orgId: 'org_aureom_direct',
    orgName: 'Aureom Direct Supply (Warehouse)',
    role: 'warehouse_user',
    roleLabel: 'Warehouse User',
  },
  {
    userId: 'usr_katrin_seller',
    name: 'Katrin Weber',
    orgId: 'org_nordic_rhine',
    orgName: 'Nordic & Rhine Consumer (3P Seller)',
    role: 'seller_manager',
    roleLabel: 'Seller Manager',
  },
  {
    userId: 'usr_platform_admin',
    name: 'Tom Gallagher',
    orgId: 'org_aureom_direct',
    orgName: 'Aureom Platform Governance',
    role: 'platform_admin',
    roleLabel: 'Platform Admin',
  },
];

@Injectable({providedIn: 'root'})
export class MarketplaceStore {
  private readonly http = inject(HttpClient);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly toast = signal<{message: string; kind: 'success' | 'error' | 'info'} | null>(null);

  readonly activePersona = signal<PersonaPreset>(PERSONA_PRESETS[0]);
  readonly firebaseUserEmail = signal<string | null>(null);

  readonly displayCurrency = signal<CurrencyCode>('USD');
  readonly selectedDestination = signal<string>('United Kingdom');
  readonly searchQuery = signal<string>('');
  readonly aiDrawerOpen = signal<boolean>(false);

  readonly organisations = signal<Organisation[]>([]);
  readonly users = signal<OrgUser[]>([]);
  readonly products = signal<Product[]>([]);
  readonly offers = signal<Offer[]>([]);
  readonly rfqs = signal<Rfq[]>([]);
  readonly orders = signal<Order[]>([]);
  readonly shipments = signal<Shipment[]>([]);
  readonly invoices = signal<Invoice[]>([]);
  readonly inventory = signal<InventoryRecord[]>([]);
  readonly stockLedger = signal<StockLedgerEntry[]>([]);
  readonly documents = signal<DocumentRecord[]>([]);
  readonly threads = signal<MessageThread[]>([]);
  readonly shortlistOfferIds = signal<string[]>([]);
  readonly platformConfig = signal<PlatformConfig | null>(null);

  readonly cart = signal<CartItem[]>([]);

  readonly activeOrg = computed(
    () =>
      this.organisations().find((o) => o.id === this.activePersona().orgId) ??
      this.organisations()[0] ??
      null,
  );

  // Header badge counts: cart items or shortlisted count when cart empty? Keep exact cart count + shortlist count
  readonly cartCount = computed(() => this.cart().length);
  readonly headerBadgeCount = computed(() =>
    this.cart().length > 0 ? this.cart().length : this.shortlistOfferIds().length,
  );

  readonly enrichedOffers = computed(() => {
    const prods = this.products();
    const orgs = this.organisations();
    return this.offers().map((offer) => {
      const product = prods.find((p) => p.id === offer.productId);
      const seller = orgs.find((o) => o.id === offer.sellerOrgId);
      const pkg =
        product?.packagingVersions.find((v) => v.version === offer.packagingVersion) ??
        product?.packagingVersions[0];
      return {offer, product, seller, pkg};
    });
  });

  private headers(): HttpHeaders {
    const p = this.activePersona();
    return new HttpHeaders({
      'x-aureom-org-id': p.orgId,
      'x-aureom-role': p.role,
      'x-aureom-user-id': p.userId,
    });
  }

  notify(message: string, kind: 'success' | 'error' | 'info' = 'info'): void {
    this.toast.set({message, kind});
    setTimeout(() => {
      if (this.toast()?.message === message) {
        this.toast.set(null);
      }
    }, 4500);
  }

  async refresh(): Promise<void> {
    try {
      this.loading.set(true);
      this.error.set(null);
      const data = await firstValueFrom(
        this.http.get<BootstrapResponse>('/api/bootstrap', {headers: this.headers()}),
      );
      this.organisations.set(data.organisations);
      this.users.set(data.users);
      this.products.set(data.products);
      this.offers.set(data.offers);
      this.rfqs.set(data.rfqs);
      this.orders.set(data.orders);
      this.shipments.set(data.shipments);
      this.invoices.set(data.invoices);
      this.inventory.set(data.inventory);
      this.stockLedger.set(data.stockLedger);
      this.documents.set(data.documents);
      this.threads.set(data.threads);
      this.shortlistOfferIds.set(data.shortlistOfferIds);
      this.platformConfig.set(data.platformConfig);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load marketplace data';
      this.error.set(msg);
    } finally {
      this.loading.set(false);
    }
  }

  async switchPersona(preset: PersonaPreset): Promise<void> {
    this.activePersona.set(preset);
    await this.refresh();
    this.notify(`Switched workspace view to ${preset.name} (${preset.roleLabel})`, 'info');
  }

  async signInGoogle(): Promise<void> {
    try {
      const user = await signInWithGooglePopup();
      if (user?.email) {
        this.firebaseUserEmail.set(user.email);
        this.notify(`Signed in via Firebase Auth as ${user.email}`, 'success');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google sign-in cancelled';
      this.notify(msg, 'error');
    }
  }

  async signOutGoogle(): Promise<void> {
    await signOutFirebase();
    this.firebaseUserEmail.set(null);
    this.notify('Signed out of Firebase session', 'info');
  }

  formatPriceMinor(minorUnits: number, fromCurrency: CurrencyCode): string {
    const target = this.displayCurrency();
    const cfg = this.platformConfig();
    let converted = minorUnits;
    if (fromCurrency !== target && cfg) {
      const usd = minorUnits * cfg.fxRatesToUsd[fromCurrency];
      converted = Math.round(usd / cfg.fxRatesToUsd[target]);
    }
    const sym = target === 'USD' ? '$' : target === 'GBP' ? '£' : '€';
    return `${sym}${(converted / 100).toFixed(2)}`;
  }

  formatExactCurrency(minorUnits: number, currency: CurrencyCode): string {
    const sym = currency === 'USD' ? '$' : currency === 'GBP' ? '£' : '€';
    return `${sym}${(minorUnits / 100).toFixed(2)}`;
  }

  flagForCountry(code: string): string {
    const flags: Record<string, string> = {
      GB: '🇬🇧',
      DE: '🇩🇪',
      TR: '🇹🇷',
      SG: '🇸🇬',
      NL: '🇳🇱',
      PL: '🇵🇱',
      US: '🇺🇸',
      FR: '🇫🇷',
    };
    return flags[code] ?? '🌐';
  }

  addToCart(item: CartItem): void {
    const current = this.cart();
    const existing = current.find((c) => c.offerId === item.offerId);
    if (existing) {
      this.cart.set(
        current.map((c) =>
          c.offerId === item.offerId ? {...c, cases: c.cases + item.cases} : c,
        ),
      );
    } else {
      this.cart.set([...current, item]);
    }
    this.notify(`Added ${item.cases} cases to wholesale basket`, 'success');
  }

  updateCartCases(offerId: string, cases: number): void {
    this.cart.set(
      this.cart().map((c) => (c.offerId === offerId ? {...c, cases} : c)),
    );
  }

  removeFromCart(offerId: string): void {
    this.cart.set(this.cart().filter((c) => c.offerId !== offerId));
  }

  async toggleShortlist(offerId: string): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.post<{shortlistOfferIds: string[]}>(
          '/api/shortlist/toggle',
          {offerId},
          {headers: this.headers()},
        ),
      );
      this.shortlistOfferIds.set(res.shortlistOfferIds);
    } catch (err) {
      this.notify(this.extractError(err), 'error');
    }
  }

  async compareOffers(
    offerIds: string[],
    cases: number,
    transportMode: string,
  ): Promise<LandedCostBreakdown[]> {
    const res = await firstValueFrom(
      this.http.post<{ranked: LandedCostBreakdown[]}>(
        '/api/compare',
        {
          offerIds,
          cases,
          transportMode,
          displayCurrency: this.displayCurrency(),
        },
        {headers: this.headers()},
      ),
    );
    return res.ranked;
  }

  async createRfq(payload: Record<string, unknown>): Promise<Rfq> {
    const res = await firstValueFrom(
      this.http.post<{rfq: Rfq}>('/api/rfqs', payload, {headers: this.headers()}),
    );
    await this.refresh();
    this.notify(`Created ${res.rfq.id} (${res.rfq.status})`, 'success');
    return res.rfq;
  }

  async submitQuote(rfqId: string, payload: Record<string, unknown>): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/rfqs/${rfqId}/quotes`, payload, {headers: this.headers()}),
    );
    await this.refresh();
    this.notify(`Submitted quotation version on ${rfqId}`, 'success');
  }

  async askRfqQuestion(rfqId: string, payload: Record<string, unknown>): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/rfqs/${rfqId}/questions`, payload, {headers: this.headers()}),
    );
    await this.refresh();
  }

  async awardRfq(rfqId: string, quoteId: string, businessUnit: string): Promise<Order> {
    const res = await firstValueFrom(
      this.http.post<{order: Order}>(
        `/api/rfqs/${rfqId}/award`,
        {quoteId, businessUnit},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(`Awarded ${rfqId} — created ${res.order.id} (${res.order.status})`, 'success');
    return res.order;
  }

  async checkoutCart(payload: {
    businessUnit: string;
    destinationCountry: string;
    deliveryLocation: string;
    orderCurrency: CurrencyCode;
  }): Promise<Order[]> {
    const res = await firstValueFrom(
      this.http.post<{orders: Order[]}>(
        '/api/orders/checkout',
        {
          ...payload,
          items: this.cart(),
        },
        {headers: this.headers()},
      ),
    );
    this.cart.set([]);
    await this.refresh();
    this.notify(
      `Created ${res.orders.length} seller order(s) under group ${res.orders[0]?.buyerOrderGroupId}`,
      'success',
    );
    return res.orders;
  }

  async approveOrder(orderId: string, approved: boolean, comment?: string): Promise<void> {
    await firstValueFrom(
      this.http.post(
        `/api/orders/${orderId}/approve`,
        {approved, comment},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(
      approved ? `Order ${orderId} approved & inventory allocated` : `Order ${orderId} rejected`,
      approved ? 'success' : 'info',
    );
  }

  async cancelOrder(orderId: string, reason: string): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/orders/${orderId}/cancel`, {reason}, {headers: this.headers()}),
    );
    await this.refresh();
    this.notify(`Order ${orderId} cancelled & reservations released`, 'info');
  }

  async dispatchShipment(
    orderId: string,
    carrier: string,
    lineDispatches: {orderLineId: string; cases: number}[],
  ): Promise<void> {
    await firstValueFrom(
      this.http.post(
        '/api/shipments/dispatch',
        {orderId, carrier, lineDispatches},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(`Shipment dispatched for ${orderId}`, 'success');
  }

  async recordDelivery(
    shipmentId: string,
    payload: {
      orderLineId: string;
      deliveredCases: number;
      damagedCases: number;
      reason: string;
      autoIssueCreditNote: boolean;
    },
  ): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/shipments/${shipmentId}/deliver`, payload, {
        headers: this.headers(),
      }),
    );
    await this.refresh();
    this.notify(`Recorded delivery on ${shipmentId}`, 'success');
  }

  async recordPayment(
    invoiceId: string,
    payload: {
      idempotencyKey: string;
      method: 'simulated_bank_transfer' | 'hosted_card_adapter';
      amountMinor: number;
      currency: CurrencyCode;
      reference: string;
    },
  ): Promise<{deduplicated: boolean}> {
    const res = await firstValueFrom(
      this.http.post<{deduplicated: boolean}>(
        `/api/invoices/${invoiceId}/payments`,
        payload,
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(
      res.deduplicated
        ? `Duplicate event ignored via idempotency key ${payload.idempotencyKey}`
        : `Payment settled on ${invoiceId}`,
      res.deduplicated ? 'info' : 'success',
    );
    return res;
  }

  async issueCreditNote(invoiceId: string, amountMinor: number, reason: string): Promise<void> {
    await firstValueFrom(
      this.http.post(
        `/api/invoices/${invoiceId}/credit-notes`,
        {amountMinor, reason},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(`Issued credit note on ${invoiceId}`, 'success');
  }

  async addInventoryReceipt(inventoryRecordId: string, casesAdded: number, note: string): Promise<void> {
    await firstValueFrom(
      this.http.post(
        '/api/inventory/receipt',
        {inventoryRecordId, casesAdded, note},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(`Received +${casesAdded} cases into warehouse ledger`, 'success');
  }

  async withdrawBatch(batchNumber: string, reason: string): Promise<void> {
    await firstValueFrom(
      this.http.post(
        '/api/inventory/withdraw-batch',
        {batchNumber, reason},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
    this.notify(`Batch ${batchNumber} withdrawn from available stock`, 'info');
  }

  async sendMessage(threadId: string, body: string, attachmentDocId?: string): Promise<void> {
    await firstValueFrom(
      this.http.post(
        `/api/messages/${threadId}`,
        {body, attachmentDocId},
        {headers: this.headers()},
      ),
    );
    await this.refresh();
  }

  async uploadDocument(payload: Record<string, unknown>): Promise<void> {
    await firstValueFrom(
      this.http.post('/api/documents', payload, {headers: this.headers()}),
    );
    await this.refresh();
    this.notify('Document version uploaded to vault', 'success');
  }

  async updateOrgSettings(orgId: string, payload: Record<string, unknown>): Promise<void> {
    await firstValueFrom(
      this.http.patch(`/api/orgs/${orgId}`, payload, {headers: this.headers()}),
    );
    await this.refresh();
    this.notify('Organisation settings saved', 'success');
  }

  async updatePlatformConfig(payload: Record<string, unknown>): Promise<void> {
    await firstValueFrom(
      this.http.patch('/api/admin/config', payload, {headers: this.headers()}),
    );
    await this.refresh();
    this.notify('Platform governance configuration updated', 'success');
  }

  async updateOrgVerification(
    orgId: string,
    payload: {status: string; notes: string; checkedItem?: string},
  ): Promise<void> {
    await firstValueFrom(
      this.http.post(`/api/admin/orgs/${orgId}/verify`, payload, {
        headers: this.headers(),
      }),
    );
    await this.refresh();
    this.notify('Organisation verification record updated', 'success');
  }

  async askProcurementAssistant(prompt: string) {
    return firstValueFrom(
      this.http.post<{
        reply: string;
        citations: {
          type: string;
          id: string;
          label: string;
          evidenceKind: string;
        }[];
        draftRfq: {
          title: string;
          productId: string;
          productName: string;
          quantity: number;
          packUnit: string;
          destinationCountry: string;
          requiredDeliveryDays: number;
          preferredCurrency: CurrencyCode;
          incoterm: string;
          requiredDocuments: string[];
        } | null;
        blockedActionReason: string | null;
        toolsExecuted: string[];
        modelUsed: string;
      }>(
        '/api/ai/procurement',
        {prompt, displayCurrency: this.displayCurrency()},
        {headers: this.headers()},
      ),
    );
  }

  async resetDemo(): Promise<void> {
    await firstValueFrom(this.http.post('/api/demo/reset', {}, {headers: this.headers()}));
    this.cart.set([]);
    await this.refresh();
    this.notify('Marketplace demonstration data reset to initial state', 'info');
  }

  extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string}}).error;
      if (inner?.error) return inner.error;
    }
    return err instanceof Error ? err.message : 'Request failed';
  }
}
