import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MarketplaceStore} from '../core/marketplace.store';

@Component({
  selector: 'app-footer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink],
  template: `
    <footer class="mt-12 border-t border-slate-200 bg-white text-xs text-slate-500">
      <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="space-y-1">
          <div class="font-semibold text-slate-700">
            Aureom Trade — Commercial B2B Consumer Goods Marketplace
          </div>
          <p>
            Commercial wholesale marketplace only — not a regulated financial exchange or escrow service.
            Business verification confirms synthetic registry checks and does not guarantee solvency, quality, or performance.
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-4 shrink-0">
          <a routerLink="/buyer" class="hover:text-[#00449E]">UK Buyer Demo</a>
          <a routerLink="/settings" class="hover:text-[#00449E]">Business Settings</a>
          <a routerLink="/admin" class="hover:text-[#00449E]">Platform Admin</a>
          <a href="/api/docs" target="_blank" class="hover:text-[#00449E]">API Spec (JSON)</a>
          <button
            type="button"
            (click)="store.resetDemo()"
            class="text-slate-600 hover:text-[#00449E] underline underline-offset-2"
          >
            Reset demo data
          </button>
        </div>
      </div>
    </footer>
  `,
})
export class Footer {
  readonly store = inject(MarketplaceStore);
}
