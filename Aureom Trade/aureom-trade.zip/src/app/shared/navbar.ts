import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {Router, RouterLink, RouterLinkActive} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {
  MarketplaceStore,
  PERSONA_PRESETS,
  PersonaPreset,
} from '../core/marketplace.store';
import {CurrencyCode} from '../core/models';

@Component({
  selector: 'app-navbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
      <!-- Top utility bar matching mockup -->
      <div class="max-w-[1360px] mx-auto px-4 lg:px-6 h-16 flex items-center justify-between gap-4">
        <!-- Brand lockup with original Aureom Trade globe emblem -->
        <a routerLink="/" class="flex items-center gap-2.5 shrink-0 group focus:outline-none">
          <svg
            viewBox="0 0 40 40"
            class="w-9 h-9 shrink-0"
            aria-hidden="true"
          >
            <defs>
              <linearGradient id="aureomGlobeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#003B95" />
                <stop offset="55%" stop-color="#0073E6" />
                <stop offset="100%" stop-color="#00C2EE" />
              </linearGradient>
            </defs>
            <circle cx="20" cy="20" r="17" fill="url(#aureomGlobeGrad)" />
            <ellipse
              cx="20"
              cy="20"
              rx="8.5"
              ry="16.5"
              fill="none"
              stroke="#FFFFFF"
              stroke-width="1.6"
              opacity="0.88"
            />
            <path
              d="M4.5 14.5 C12 18, 28 18, 35.5 14.5 M4.5 25.5 C12 22, 28 22, 35.5 25.5"
              fill="none"
              stroke="#FFFFFF"
              stroke-width="1.5"
              opacity="0.88"
            />
            <path
              d="M7 29 C16 25, 25 17, 33.5 9.5"
              fill="none"
              stroke="#7DF0FF"
              stroke-width="2.2"
              stroke-linecap="round"
            />
          </svg>
          <div class="leading-tight">
            <div class="font-display font-extrabold text-[17px] tracking-tight text-[#003E9C] whitespace-nowrap">
              AUREOM TRADE
            </div>
            <div class="hidden sm:block text-[11px] font-medium text-[#0066CC] whitespace-nowrap">
              Consumer goods. Connected worldwide.
            </div>
          </div>
        </a>

        <!-- Central search bar -->
        <form
          (submit)="submitSearch($event)"
          class="hidden md:flex flex-1 max-w-md items-center bg-[#F8FAFD] border border-slate-300 rounded-lg px-3 py-1.5 focus-within:border-[#0066CC] focus-within:ring-2 focus-within:ring-blue-100 transition-all"
        >
          <mat-icon class="text-[#0066CC] text-[20px] mr-2">search</mat-icon>
          <input
            type="search"
            [value]="store.searchQuery()"
            (input)="onSearchInput($event)"
            placeholder="Search products, brands or suppliers"
            aria-label="Search products, brands or suppliers"
            class="w-full bg-transparent text-sm text-slate-800 placeholder:text-slate-500 focus:outline-none"
          />
          @if (store.searchQuery()) {
            <button
              type="button"
              (click)="clearSearch()"
              class="text-xs text-slate-500 hover:text-slate-800 px-1 whitespace-nowrap"
            >
              Clear
            </button>
          }
        </form>

        <!-- Right utilities -->
        <div class="flex items-center gap-3 lg:gap-5 shrink-0">
          <!-- Currency selector -->
          <div class="relative">
            <button
              type="button"
              (click)="toggleCurrencyMenu()"
              class="flex items-center gap-1 text-sm font-medium text-slate-700 hover:text-[#00449E] py-1.5 px-2 rounded-md hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <span>English / {{ store.displayCurrency() }}</span>
              <mat-icon class="text-[18px]">expand_more</mat-icon>
            </button>
            @if (currencyMenuOpen()) {
              <div class="absolute right-0 mt-1 w-40 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-50">
                @for (curr of currencies; track curr) {
                  <button
                    type="button"
                    (click)="selectCurrency(curr)"
                    class="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 flex items-center justify-between"
                    [class.font-semibold]="store.displayCurrency() === curr"
                    [class.text-[#00449E]]="store.displayCurrency() === curr"
                  >
                    <span>English / {{ curr }}</span>
                    @if (store.displayCurrency() === curr) {
                      <mat-icon class="text-[16px] text-[#00449E]">check</mat-icon>
                    }
                  </button>
                }
              </div>
            }
          </div>

          <a
            routerLink="/messages"
            aria-label="Messages and documents"
            class="p-2 text-slate-600 hover:text-[#00449E] hover:bg-slate-50 rounded-lg relative shrink-0"
          >
            <mat-icon class="text-[21px]">chat_bubble_outline</mat-icon>
          </a>

          <a
            routerLink="/buyer"
            class="hidden sm:flex items-center gap-1.5 text-sm font-medium text-slate-700 hover:text-[#00449E] whitespace-nowrap shrink-0"
          >
            <mat-icon class="text-[20px]">person_outline</mat-icon>
            <span>Buyer workspace</span>
          </a>

          <a
            routerLink="/checkout"
            aria-label="Wholesale basket and checkout"
            class="relative p-2 text-slate-700 hover:text-[#00449E] hover:bg-slate-50 rounded-lg shrink-0"
          >
            <mat-icon class="text-[22px]">shopping_cart</mat-icon>
            <span
              class="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#0066CC] text-white text-[11px] font-semibold flex items-center justify-center tabular-nums"
            >
              {{ store.headerBadgeCount() }}
            </span>
          </a>

          <button
            type="button"
            (click)="mobileMenuOpen.set(!mobileMenuOpen())"
            aria-label="Toggle navigation menu"
            class="lg:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg"
          >
            <mat-icon>{{ mobileMenuOpen() ? 'close' : 'menu' }}</mat-icon>
          </button>
        </div>
      </div>

      <!-- Royal blue primary navigation bar matching mockup -->
      <nav class="bg-[#00449E] text-white">
        <div class="max-w-[1360px] mx-auto px-4 lg:px-6 h-11 flex items-center justify-between gap-4">
          <div class="hidden lg:flex items-center gap-7 text-sm font-medium">
            <a
              routerLink="/"
              routerLinkActive="border-b-2 border-cyan-300 text-white"
              [routerLinkActiveOptions]="{exact: true}"
              class="h-11 flex items-center border-b-2 border-transparent hover:text-cyan-200 transition-colors whitespace-nowrap shrink-0"
            >
              Marketplace
            </a>
            <a
              routerLink="/suppliers"
              routerLinkActive="border-b-2 border-cyan-300 text-white"
              class="h-11 flex items-center border-b-2 border-transparent hover:text-cyan-200 transition-colors whitespace-nowrap shrink-0"
            >
              Suppliers
            </a>
            <a
              routerLink="/rfqs"
              routerLinkActive="border-b-2 border-cyan-300 text-white"
              class="h-11 flex items-center border-b-2 border-transparent hover:text-cyan-200 transition-colors whitespace-nowrap shrink-0"
            >
              Request a quote
            </a>
            <a
              routerLink="/seller"
              routerLinkActive="border-b-2 border-cyan-300 text-white"
              class="h-11 flex items-center border-b-2 border-transparent hover:text-cyan-200 transition-colors whitespace-nowrap shrink-0"
            >
              Sell on Aureom
            </a>
            <a
              routerLink="/orders"
              routerLinkActive="border-b-2 border-cyan-300 text-white"
              class="h-11 flex items-center border-b-2 border-transparent hover:text-cyan-200 transition-colors whitespace-nowrap shrink-0"
            >
              Orders & logistics
            </a>
            <a
              routerLink="/invoices"
              routerLinkActive="border-b-2 border-cyan-300 text-white"
              class="h-11 flex items-center border-b-2 border-transparent hover:text-cyan-200 transition-colors whitespace-nowrap shrink-0"
            >
              Invoices & payments
            </a>
          </div>

          <!-- Mobile active route label -->
          <div class="lg:hidden text-xs font-medium text-blue-100 truncate">
            {{ store.activePersona().orgName }} · {{ store.activePersona().roleLabel }}
          </div>

          <div class="flex items-center gap-3 shrink-0 ml-auto">
            <button
              type="button"
              (click)="store.aiDrawerOpen.set(true)"
              class="flex items-center gap-1.5 text-xs font-medium bg-[#005BC5] hover:bg-[#0069E0] text-white px-3 py-1.5 rounded-md border border-blue-400/40 transition-colors whitespace-nowrap shrink-0"
            >
              <mat-icon class="text-[16px]">auto_awesome</mat-icon>
              <span class="hidden sm:inline">Procurement assistant</span>
              <span class="sm:hidden">Assistant</span>
            </button>

            <!-- Business account & persona switcher -->
            <div class="relative">
              <button
                type="button"
                (click)="accountMenuOpen.set(!accountMenuOpen())"
                class="flex items-center gap-1.5 text-sm font-medium text-white hover:text-cyan-200 py-1.5 px-2 rounded-md whitespace-nowrap shrink-0"
              >
                <mat-icon class="text-[18px]">business</mat-icon>
                <span>Business account</span>
                <mat-icon class="text-[18px]">expand_more</mat-icon>
              </button>

              @if (accountMenuOpen()) {
                <div class="absolute right-0 mt-1.5 w-80 bg-white text-slate-900 border border-slate-200 rounded-xl shadow-xl py-2 z-50">
                  <div class="px-4 py-2 border-b border-slate-100">
                    <div class="text-xs font-medium text-slate-500">Active organisation & role</div>
                    <div class="text-sm font-semibold text-slate-900 mt-0.5">
                      {{ store.activePersona().name }} · {{ store.activePersona().roleLabel }}
                    </div>
                    <div class="text-xs text-[#0055B8]">
                      {{ store.activePersona().orgName }}
                    </div>
                  </div>

                  <div class="px-3 py-1.5 text-[11px] font-semibold text-slate-500">
                    Switch organisation / role (Demo RBAC)
                  </div>
                  <div class="max-h-60 overflow-y-auto">
                    @for (preset of presets; track preset.userId) {
                      <button
                        type="button"
                        (click)="choosePersona(preset)"
                        class="w-full text-left px-4 py-2 text-xs hover:bg-blue-50 flex items-center justify-between gap-2"
                        [class.bg-blue-50]="store.activePersona().userId === preset.userId"
                      >
                        <div>
                          <div class="font-semibold text-slate-800">
                            {{ preset.name }} ({{ preset.roleLabel }})
                          </div>
                          <div class="text-slate-500">{{ preset.orgName }}</div>
                        </div>
                        @if (store.activePersona().userId === preset.userId) {
                          <mat-icon class="text-[16px] text-[#00449E]">check_circle</mat-icon>
                        }
                      </button>
                    }
                  </div>

                  <div class="border-t border-slate-100 mt-1 pt-1 px-2 flex flex-col gap-0.5">
                    <a
                      routerLink="/settings"
                      (click)="accountMenuOpen.set(false)"
                      class="flex items-center gap-2 px-2 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-md"
                    >
                      <mat-icon class="text-[16px]">tune</mat-icon>
                      <span>Business settings & approvals</span>
                    </a>
                    <a
                      routerLink="/admin"
                      (click)="accountMenuOpen.set(false)"
                      class="flex items-center gap-2 px-2 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-md"
                    >
                      <mat-icon class="text-[16px]">admin_panel_settings</mat-icon>
                      <span>Platform administration</span>
                    </a>
                    <a
                      routerLink="/messages"
                      (click)="accountMenuOpen.set(false)"
                      class="flex items-center gap-2 px-2 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-md"
                    >
                      <mat-icon class="text-[16px]">folder_shared</mat-icon>
                      <span>Messages & document vault</span>
                    </a>
                    @if (store.firebaseUserEmail()) {
                      <button
                        type="button"
                        (click)="signOut()"
                        class="flex items-center gap-2 px-2 py-2 text-xs font-medium text-emerald-700 hover:bg-emerald-50 rounded-md text-left"
                      >
                        <mat-icon class="text-[16px]">verified_user</mat-icon>
                        <span>Firebase: {{ store.firebaseUserEmail() }} (Sign out)</span>
                      </button>
                    } @else {
                      <button
                        type="button"
                        (click)="signIn()"
                        class="flex items-center gap-2 px-2 py-2 text-xs font-medium text-[#00449E] hover:bg-blue-50 rounded-md text-left"
                      >
                        <mat-icon class="text-[16px]">login</mat-icon>
                        <span>Sign in with Google (Firebase Auth)</span>
                      </button>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Mobile navigation drawer -->
        @if (mobileMenuOpen()) {
          <div class="lg:hidden bg-[#003882] border-t border-blue-700 px-4 py-3 space-y-2">
            <form (submit)="submitSearch($event)" class="flex items-center bg-white rounded-lg px-3 py-1.5 mb-2">
              <mat-icon class="text-[#0066CC] text-[18px] mr-2">search</mat-icon>
              <input
                type="search"
                [value]="store.searchQuery()"
                (input)="onSearchInput($event)"
                placeholder="Search products, brands or suppliers"
                class="w-full text-sm text-slate-800 focus:outline-none"
              />
            </form>
            <div class="grid grid-cols-2 gap-2 text-sm">
              <a routerLink="/" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Marketplace</a>
              <a routerLink="/suppliers" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Suppliers</a>
              <a routerLink="/rfqs" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Request a quote</a>
              <a routerLink="/compare" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Compare landed cost</a>
              <a routerLink="/buyer" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Buyer workspace</a>
              <a routerLink="/seller" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Sell on Aureom</a>
              <a routerLink="/orders" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Orders & logistics</a>
              <a routerLink="/invoices" (click)="mobileMenuOpen.set(false)" class="px-3 py-2 rounded-md hover:bg-blue-800">Invoices & payments</a>
            </div>
          </div>
        }
      </nav>
    </header>
  `,
})
export class Navbar {
  readonly store = inject(MarketplaceStore);
  private readonly router = inject(Router);

  readonly presets = PERSONA_PRESETS;
  readonly currencies: CurrencyCode[] = ['USD', 'GBP', 'EUR'];

  readonly currencyMenuOpen = signal(false);
  readonly accountMenuOpen = signal(false);
  readonly mobileMenuOpen = signal(false);

  onSearchInput(event: Event): void {
    const val = (event.target as HTMLInputElement).value;
    this.store.searchQuery.set(val);
  }

  clearSearch(): void {
    this.store.searchQuery.set('');
  }

  submitSearch(event: Event): void {
    event.preventDefault();
    this.mobileMenuOpen.set(false);
    this.router.navigate(['/']);
  }

  toggleCurrencyMenu(): void {
    this.currencyMenuOpen.set(!this.currencyMenuOpen());
  }

  selectCurrency(curr: CurrencyCode): void {
    this.store.displayCurrency.set(curr);
    this.currencyMenuOpen.set(false);
  }

  async choosePersona(preset: PersonaPreset): Promise<void> {
    this.accountMenuOpen.set(false);
    await this.store.switchPersona(preset);
  }

  async signIn(): Promise<void> {
    this.accountMenuOpen.set(false);
    await this.store.signInGoogle();
  }

  async signOut(): Promise<void> {
    this.accountMenuOpen.set(false);
    await this.store.signOutGoogle();
  }
}
