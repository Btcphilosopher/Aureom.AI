import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {Router} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';

interface AssistantMessage {
  role: 'user' | 'assistant';
  text: string;
  citations?: {type: string; id: string; label: string; evidenceKind: string}[];
  toolsExecuted?: string[];
  blockedActionReason?: string | null;
  draftRfq?: {
    title: string;
    productId: string;
    productName: string;
    quantity: number;
    packUnit: string;
    destinationCountry: string;
    requiredDeliveryDays: number;
    preferredCurrency: string;
    incoterm: string;
    requiredDocuments: string[];
  } | null;
}

@Component({
  selector: 'app-ai-assistant-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (store.aiDrawerOpen()) {
      <div class="fixed inset-0 z-50 flex justify-end">
        <button
          type="button"
          aria-label="Close assistant backdrop"
          (click)="store.aiDrawerOpen.set(false)"
          class="fixed inset-0 bg-slate-900/40 backdrop-blur-[1px]"
        ></button>

        <aside class="relative w-full max-w-lg bg-white h-full shadow-2xl border-l border-slate-200 flex flex-col z-10">
          <div class="px-5 py-4 bg-[#0A224E] text-white flex items-center justify-between">
            <div>
              <div class="flex items-center gap-2 font-display font-bold text-base">
                <mat-icon class="text-cyan-300 text-[20px]">auto_awesome</mat-icon>
                <span>Aureom Procurement Assistant</span>
              </div>
              <p class="text-xs text-blue-200 mt-0.5">
                Grounded in live platform tools · Cannot award contracts, approve suppliers, or commit payments
              </p>
            </div>
            <button
              type="button"
              (click)="store.aiDrawerOpen.set(false)"
              class="p-1.5 rounded-lg hover:bg-white/10 text-white"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <!-- Quick prompt starters -->
          <div class="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-1.5">
            @for (preset of samplePrompts; track preset) {
              <button
                type="button"
                (click)="sendPrompt(preset)"
                class="text-xs px-2.5 py-1 rounded-md bg-white border border-slate-200 hover:border-[#0066CC] hover:text-[#00449E] text-slate-700 transition-colors"
              >
                {{ preset }}
              </button>
            }
          </div>

          <!-- Conversation history -->
          <div class="flex-1 overflow-y-auto p-4 space-y-4">
            @if (messages().length === 0) {
              <div class="rounded-xl border border-slate-200 bg-slate-50/70 p-4 text-sm text-slate-700 space-y-2">
                <div class="font-semibold text-slate-900">How I can assist your sourcing team</div>
                <ul class="list-disc pl-5 space-y-1 text-xs text-slate-600">
                  <li>Draft an RFQ specification from natural language (saved only when you confirm).</li>
                  <li>Compare authorised wholesale offers and explain landed-cost & packaging differences.</li>
                  <li>Verify batch inventory availability and summarise authorised SDS/COA documents.</li>
                  <li>Enforce human-in-the-loop governance: autonomous contract awards, bank edits, and purchases are blocked.</li>
                </ul>
              </div>
            }

            @for (msg of messages(); track $index) {
              <div [class]="msg.role === 'user' ? 'flex justify-end' : 'flex justify-start'">
                <div
                  class="max-w-[92%] rounded-xl px-4 py-3 text-sm"
                  [class.bg-[#00449E]]="msg.role === 'user'"
                  [class.text-white]="msg.role === 'user'"
                  [class.bg-slate-50]="msg.role === 'assistant'"
                  [class.border]="msg.role === 'assistant'"
                  [class.border-slate-200]="msg.role === 'assistant'"
                  [class.text-slate-800]="msg.role === 'assistant'"
                >
                  @if (msg.blockedActionReason) {
                    <div class="flex items-start gap-2 text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-2.5 mb-2 text-xs">
                      <mat-icon class="text-[18px] text-amber-600 shrink-0">gpp_maybe</mat-icon>
                      <span>{{ msg.blockedActionReason }}</span>
                    </div>
                  }

                  <div class="whitespace-pre-wrap leading-relaxed">{{ msg.text }}</div>

                  @if (msg.toolsExecuted && msg.toolsExecuted.length > 0) {
                    <div class="mt-2 pt-2 border-t border-slate-200 text-[11px] text-slate-500">
                      Tools used: {{ msg.toolsExecuted.join(', ') }}
                    </div>
                  }

                  @if (msg.citations && msg.citations.length > 0) {
                    <div class="mt-2 space-y-1">
                      <div class="text-[11px] font-semibold text-slate-600">Sources & Evidence Provenance</div>
                      @for (cit of msg.citations; track cit.id) {
                        <div class="text-[11px] flex items-center justify-between gap-2 bg-white border border-slate-200 rounded px-2 py-1">
                          <span class="truncate text-slate-700">{{ cit.label }} ({{ cit.id }})</span>
                          <span
                            class="shrink-0 font-medium"
                            [class.text-emerald-700]="cit.evidenceKind === 'verified_platform_data'"
                            [class.text-amber-700]="cit.evidenceKind !== 'verified_platform_data'"
                          >
                            {{ cit.evidenceKind === 'verified_platform_data' ? 'Platform data' : 'Supplier claim' }}
                          </span>
                        </div>
                      }
                    </div>
                  }

                  @if (msg.draftRfq) {
                    <div class="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg space-y-2">
                      <div class="text-xs font-semibold text-[#003E9C]">Draft RFQ Ready for Review</div>
                      <div class="text-xs text-slate-700">
                        {{ msg.draftRfq.title }} · {{ msg.draftRfq.quantity }} {{ msg.draftRfq.packUnit }} ·
                        {{ msg.draftRfq.incoterm }} to {{ msg.draftRfq.destinationCountry }}
                      </div>
                      <button
                        type="button"
                        (click)="createDraftRfqFromAssistant(msg.draftRfq)"
                        class="inline-flex items-center gap-1.5 text-xs font-semibold bg-[#00449E] hover:bg-[#00357E] text-white px-3 py-1.5 rounded-md"
                      >
                        <mat-icon class="text-[15px]">post_add</mat-icon>
                        <span>Save as Draft RFQ</span>
                      </button>
                    </div>
                  }
                </div>
              </div>
            }

            @if (busy()) {
              <div class="text-xs text-slate-500 flex items-center gap-2">
                <mat-icon class="text-[16px] animate-spin text-[#0066CC]">sync</mat-icon>
                <span>Querying procurement tools and Gemini 4.0...</span>
              </div>
            }
          </div>

          <!-- Input bar -->
          <form (submit)="onSubmit($event)" class="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
            <input
              type="text"
              [value]="inputText()"
              (input)="onInput($event)"
              placeholder="Ask to compare offers, check stock, or draft an RFQ..."
              class="flex-1 text-sm border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:border-[#0066CC]"
            />
            <button
              type="submit"
              [disabled]="busy()"
              class="px-4 py-2 bg-[#00449E] hover:bg-[#00357E] disabled:opacity-50 text-white text-sm font-medium rounded-lg flex items-center gap-1 whitespace-nowrap"
            >
              <mat-icon class="text-[18px]">send</mat-icon>
              <span>Ask</span>
            </button>
          </form>
        </aside>
      </div>
    }
  `,
})
export class AiAssistantDrawer {
  readonly store = inject(MarketplaceStore);
  private readonly router = inject(Router);

  readonly messages = signal<AssistantMessage[]>([]);
  readonly inputText = signal('');
  readonly busy = signal(false);

  readonly samplePrompts = [
    'Compare landed cost for 1200 cases of Moisturising body wash',
    'Draft an RFQ for 600 cases of Everyday shampoo to United Kingdom',
    'Check batch inventory for Moisturising body wash',
    'Award contract to Aureom Direct right now',
  ];

  onInput(event: Event): void {
    this.inputText.set((event.target as HTMLInputElement).value);
  }

  onSubmit(event: Event): void {
    event.preventDefault();
    const text = this.inputText().trim();
    if (!text || this.busy()) return;
    this.inputText.set('');
    this.sendPrompt(text);
  }

  async sendPrompt(prompt: string): Promise<void> {
    this.messages.update((m) => [...m, {role: 'user', text: prompt}]);
    this.busy.set(true);
    try {
      const res = await this.store.askProcurementAssistant(prompt);
      this.messages.update((m) => [
        ...m,
        {
          role: 'assistant',
          text: res.reply,
          citations: res.citations,
          toolsExecuted: res.toolsExecuted,
          blockedActionReason: res.blockedActionReason,
          draftRfq: res.draftRfq,
        },
      ]);
    } catch (err) {
      this.messages.update((m) => [
        ...m,
        {
          role: 'assistant',
          text: `Assistant unavailable: ${this.store.extractError(err)}`,
        },
      ]);
    } finally {
      this.busy.set(false);
    }
  }

  async createDraftRfqFromAssistant(draft: NonNullable<AssistantMessage['draftRfq']>): Promise<void> {
    await this.store.createRfq({
      title: draft.title,
      productId: draft.productId,
      specification: 'Prepared from AI Procurement Assistant draft for buyer review',
      quantity: draft.quantity,
      packUnit: draft.packUnit,
      destinationCountry: draft.destinationCountry,
      requiredDeliveryDays: draft.requiredDeliveryDays,
      preferredCurrency: draft.preferredCurrency,
      incoterm: draft.incoterm,
      requiredDocuments: draft.requiredDocuments,
      publishImmediately: false,
    });
    this.store.aiDrawerOpen.set(false);
    this.router.navigate(['/rfqs']);
  }
}
