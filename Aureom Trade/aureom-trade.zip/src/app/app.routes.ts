import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./pages/marketplace-home').then((m) => m.MarketplaceHome),
  },
  {
    path: 'search',
    loadComponent: () =>
      import('./pages/marketplace-home').then((m) => m.MarketplaceHome),
  },
  {
    path: 'category/:slug',
    loadComponent: () =>
      import('./pages/marketplace-home').then((m) => m.MarketplaceHome),
  },
  {
    path: 'products/:id',
    loadComponent: () =>
      import('./pages/product-detail').then((m) => m.ProductDetail),
  },
  {
    path: 'suppliers',
    loadComponent: () =>
      import('./pages/suppliers').then((m) => m.SuppliersPage),
  },
  {
    path: 'suppliers/:id',
    loadComponent: () =>
      import('./pages/suppliers').then((m) => m.SuppliersPage),
  },
  {
    path: 'compare',
    loadComponent: () =>
      import('./pages/compare').then((m) => m.ComparePage),
  },
  {
    path: 'rfqs',
    loadComponent: () => import('./pages/rfqs').then((m) => m.RfqsPage),
  },
  {
    path: 'buyer',
    loadComponent: () =>
      import('./pages/buyer-workspace').then((m) => m.BuyerWorkspacePage),
  },
  {
    path: 'seller',
    loadComponent: () =>
      import('./pages/seller-workspace').then((m) => m.SellerWorkspacePage),
  },
  {
    path: 'checkout',
    loadComponent: () =>
      import('./pages/cart-checkout').then((m) => m.CartCheckoutPage),
  },
  {
    path: 'orders',
    loadComponent: () =>
      import('./pages/orders-shipments').then((m) => m.OrdersShipmentsPage),
  },
  {
    path: 'invoices',
    loadComponent: () =>
      import('./pages/invoices-payments').then((m) => m.InvoicesPaymentsPage),
  },
  {
    path: 'messages',
    loadComponent: () =>
      import('./pages/messages-documents').then((m) => m.MessagesDocumentsPage),
  },
  {
    path: 'settings',
    loadComponent: () =>
      import('./pages/business-settings').then((m) => m.BusinessSettingsPage),
  },
  {
    path: 'admin',
    loadComponent: () =>
      import('./pages/platform-admin').then((m) => m.PlatformAdminPage),
  },
  {
    path: '**',
    redirectTo: '',
  },
];
