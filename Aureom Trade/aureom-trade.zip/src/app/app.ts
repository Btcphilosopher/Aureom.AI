import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
} from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from './core/marketplace.store';
import {Navbar} from './shared/navbar';
import {Footer} from './shared/footer';
import {AiAssistantDrawer} from './shared/ai-assistant-drawer';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet, MatIconModule, Navbar, Footer, AiAssistantDrawer],
  template: `
    <div class="min-h-screen flex flex-col bg-[#F5F7FB] text-slate-900">
      <app-navbar />

      @if (store.toast(); as t) {
        <div
          role="status"
          class="fixed bottom-5 right-5 z-50 max-w-md px-4 py-3 rounded-xl shadow-lg border text-sm font-medium flex items-center gap-2.5 bg-white"
          [class.border-emerald-300]="t.kind === 'success'"
          [class.text-emerald-900]="t.kind === 'success'"
          [class.border-red-300]="t.kind === 'error'"
          [class.text-red-900]="t.kind === 'error'"
          [class.border-blue-300]="t.kind === 'info'"
          [class.text-slate-900]="t.kind === 'info'"
        >
          <mat-icon
            class="text-[19px]"
            [class.text-emerald-600]="t.kind === 'success'"
            [class.text-red-600]="t.kind === 'error'"
            [class.text-[#00449E]]="t.kind === 'info'"
          >
            {{ t.kind === 'success' ? 'check_circle' : t.kind === 'error' ? 'error' : 'info' }}
          </mat-icon>
          <span>{{ t.message }}</span>
        </div>
      }

      <div class="flex-1">
        @if (store.error(); as err) {
          <div class="max-w-[1360px] mx-auto px-4 lg:px-6 pt-6">
            <div class="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800 flex items-center justify-between gap-4">
              <span>{{ err }}</span>
              <button
                type="button"
                (click)="store.refresh()"
                class="px-3 py-1.5 rounded-lg bg-red-700 text-white text-xs font-semibold"
              >
                Retry
              </button>
            </div>
          </div>
        }
        <router-outlet />
      </div>

      <app-footer />
      <app-ai-assistant-drawer />
    </div>
  `,
})
export class App implements OnInit {
  readonly store = inject(MarketplaceStore);

  ngOnInit(): void {
    this.store.refresh();
  }
}
