import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';

@Component({
  selector: 'app-business-settings',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div>
        <h1 class="font-display font-bold text-2xl text-slate-900">
          Business Account Settings & Governance
        </h1>
        <p class="text-sm text-slate-600 mt-0.5">
          Organisation legal identity, delivery locations, role permissions, approval rules, and return policies.
        </p>
      </div>

      @if (store.activeOrg(); as org) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <!-- Legal Profile & Locations -->
          <section class="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <h2 class="font-display font-bold text-lg text-slate-900">
              {{ org.legalName }} ({{ org.kind }})
            </h2>
            <dl class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div class="bg-slate-50 rounded-lg p-3">
                <dt class="text-slate-500">Trading Name</dt>
                <dd class="font-semibold text-slate-900 mt-0.5">{{ org.tradingName }}</dd>
              </div>
              <div class="bg-slate-50 rounded-lg p-3">
                <dt class="text-slate-500">Business & Tax IDs</dt>
                <dd class="font-mono font-semibold text-slate-900 mt-0.5">
                  {{ org.businessIdentifier }} · {{ org.taxIdentifier }}
                </dd>
              </div>
              <div class="sm:col-span-2 bg-slate-50 rounded-lg p-3">
                <dt class="text-slate-500">Registered Address & Billing Hub</dt>
                <dd class="text-slate-800 mt-0.5">{{ org.registeredAddress }} · Billing: {{ org.billingLocation }}</dd>
              </div>
              <div class="sm:col-span-2 bg-slate-50 rounded-lg p-3">
                <dt class="text-slate-500">Delivery Locations</dt>
                <dd class="text-slate-800 mt-0.5">{{ org.deliveryLocations.join(' | ') }}</dd>
              </div>
            </dl>

            <div class="pt-3 border-t border-slate-100">
              <h3 class="font-display font-bold text-sm text-slate-900 mb-2">
                Organisation Users & Role Matrix
              </h3>
              <div class="space-y-2 text-xs">
                @for (u of orgUsers(); track u.id) {
                  <div class="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
                    <div>
                      <div class="font-semibold text-slate-900">{{ u.name }}</div>
                      <div class="text-slate-500">{{ u.email }}</div>
                    </div>
                    <span class="font-mono text-[#00449E] font-semibold">{{ u.role }}</span>
                  </div>
                }
              </div>
            </div>
          </section>

          <!-- Editable Organisation Policy -->
          <form
            [formGroup]="settingsForm"
            (ngSubmit)="saveSettings()"
            class="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 space-y-4"
          >
            <h2 class="font-display font-bold text-lg text-slate-900">
              Purchasing & Currency Configuration
            </h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div>
                <label for="bs-currency" class="block text-xs font-semibold text-slate-700 mb-1">Preferred Settlement Currency</label>
                <select id="bs-currency" formControlName="preferredCurrency" class="w-full h-10 px-3 border border-slate-300 rounded-lg bg-white">
                  <option value="GBP">GBP</option>
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                </select>
              </div>
              <div>
                <label for="bs-lang" class="block text-xs font-semibold text-slate-700 mb-1">Preferred Language</label>
                <input id="bs-lang" type="text" formControlName="preferredLanguage" class="w-full h-10 px-3 border border-slate-300 rounded-lg" />
              </div>
              <div>
                <label for="bs-thresh" class="block text-xs font-semibold text-slate-700 mb-1">Approval Threshold (USD cents)</label>
                <input id="bs-thresh" type="number" formControlName="approvalThresholdMinor" class="w-full h-10 px-3 border border-slate-300 rounded-lg tabular-nums" />
              </div>
              <div>
                <label for="bs-ret" class="block text-xs font-semibold text-slate-700 mb-1">Return Policy Window (days)</label>
                <input id="bs-ret" type="number" formControlName="returnPolicyDays" class="w-full h-10 px-3 border border-slate-300 rounded-lg tabular-nums" />
              </div>
              <div class="sm:col-span-2">
                <label for="bs-terms" class="block text-xs font-semibold text-slate-700 mb-1">Default Payment Terms</label>
                <input id="bs-terms" type="text" formControlName="paymentTerms" class="w-full h-10 px-3 border border-slate-300 rounded-lg" />
              </div>
            </div>

            <div class="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="submit"
                class="h-10 px-5 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-sm font-semibold flex items-center gap-1.5"
              >
                <mat-icon class="text-[17px]">save</mat-icon>
                <span>Save organisation settings</span>
              </button>
            </div>
          </form>
        </div>
      }
    </div>
  `,
})
export class BusinessSettingsPage {
  readonly store = inject(MarketplaceStore);

  readonly orgUsers = computed(() => {
    const orgId = this.store.activeOrg()?.id;
    return this.store.users().filter((u) => u.organisationId === orgId);
  });

  readonly settingsForm = new FormGroup({
    preferredCurrency: new FormControl('GBP', {nonNullable: true}),
    preferredLanguage: new FormControl('English', {nonNullable: true}),
    approvalThresholdMinor: new FormControl(500000, {nonNullable: true}),
    returnPolicyDays: new FormControl(14, {nonNullable: true}),
    paymentTerms: new FormControl('Net 30 days', {nonNullable: true}),
  });

  constructor() {
    effect(() => {
      const org = this.store.activeOrg();
      if (org) {
        this.settingsForm.patchValue({
          preferredCurrency: org.preferredCurrency,
          preferredLanguage: org.preferredLanguage,
          approvalThresholdMinor: org.approvalThresholdMinor,
          returnPolicyDays: org.returnPolicyDays,
          paymentTerms: org.paymentTerms,
        });
      }
    });
  }

  async saveSettings(): Promise<void> {
    const org = this.store.activeOrg();
    if (!org) return;
    try {
      await this.store.updateOrgSettings(org.id, this.settingsForm.getRawValue());
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }
}
