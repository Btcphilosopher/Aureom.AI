import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {CurrencyCode, Invoice} from '../core/models';

@Component({
  selector: 'app-invoices-payments',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div>
        <h1 class="font-display font-bold text-2xl text-slate-900">
          Invoices, Multi-Currency Settlements & Credit Notes
        </h1>
        <p class="text-sm text-slate-600 mt-0.5">
          Commercial invoice tracking with USD/GBP/EUR FX conversion timestamps, idempotent payment allocation, and credit notes.
          Aureom Trade does not hold customer funds or provide regulated escrow.
        </p>
      </div>

      @if (store.invoices().length === 0) {
        <div class="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-600">
          No invoices issued yet. Confirm and approve an order to generate a seller invoice.
        </div>
      } @else {
        <div class="space-y-4">
          @for (inv of store.invoices(); track inv.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <div class="flex items-center gap-2 text-xs">
                    <span class="font-mono font-bold text-[#00449E]">{{ inv.id }}</span>
                    <span>·</span>
                    <span>Order {{ inv.orderId }}</span>
                    <span>·</span>
                    <span
                      class="font-semibold"
                      [class.text-emerald-700]="inv.status === 'Paid'"
                      [class.text-amber-700]="inv.status !== 'Paid'"
                    >
                      {{ inv.status }}
                    </span>
                  </div>
                  <div class="text-xs text-slate-500 mt-0.5">
                    Invoice currency: {{ inv.currency }} · Settlement currency: {{ inv.settlementCurrency }} · Due {{ inv.dueDate.slice(0, 10) }}
                  </div>
                </div>

                <div class="grid grid-cols-4 gap-4 text-xs text-right tabular-nums">
                  <div>
                    <div class="text-slate-500">Total</div>
                    <div class="font-bold text-slate-900">{{ store.formatExactCurrency(inv.totalMinor, inv.currency) }}</div>
                  </div>
                  <div>
                    <div class="text-slate-500">Paid</div>
                    <div class="font-semibold text-emerald-700">{{ store.formatExactCurrency(inv.paidMinor, inv.currency) }}</div>
                  </div>
                  <div>
                    <div class="text-slate-500">Credited</div>
                    <div class="font-semibold text-[#00449E]">{{ store.formatExactCurrency(inv.creditedMinor, inv.currency) }}</div>
                  </div>
                  <div>
                    <div class="text-slate-500">Balance Due</div>
                    <div class="font-bold text-slate-900">{{ store.formatExactCurrency(inv.balanceDueMinor, inv.currency) }}</div>
                  </div>
                </div>
              </div>

              @if (inv.balanceDueMinor > 0) {
                <div class="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col lg:flex-row lg:items-end justify-between gap-3 text-xs">
                  <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 flex-1">
                    <label class="block">
                      <span class="block font-semibold text-slate-700 mb-1">Amount ({{ inv.currency }} minor units)</span>
                      <input
                        type="number"
                        [value]="payAmount()[inv.id] ?? inv.balanceDueMinor"
                        (input)="setPayAmount(inv.id, $event)"
                        class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg tabular-nums"
                      />
                    </label>
                    <label class="block">
                      <span class="block font-semibold text-slate-700 mb-1">Payment Currency</span>
                      <select
                        [value]="payCurrency()[inv.id] ?? inv.currency"
                        (change)="setPayCurrency(inv.id, $event)"
                        class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg"
                      >
                        <option value="USD">USD</option>
                        <option value="GBP">GBP</option>
                        <option value="EUR">EUR</option>
                      </select>
                    </label>
                    <label class="block">
                      <span class="block font-semibold text-slate-700 mb-1">Idempotency Key</span>
                      <input
                        type="text"
                        [value]="idempKey()[inv.id] ?? 'BACS-' + inv.id"
                        (input)="setIdempKey(inv.id, $event)"
                        class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg font-mono"
                      />
                    </label>
                  </div>
                  <div class="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      (click)="submitPayment(inv)"
                      class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white font-semibold whitespace-nowrap"
                    >
                      Record Simulated Bank Transfer
                    </button>
                  </div>
                </div>
              }

              @if (inv.payments.length > 0) {
                <div class="space-y-1.5 text-xs">
                  <div class="font-semibold text-slate-700">Payment Allocations</div>
                  @for (pay of inv.payments; track pay.id) {
                    <div class="flex flex-wrap items-center justify-between gap-2 bg-emerald-50/50 border border-emerald-200 rounded-lg px-3 py-2 tabular-nums">
                      <span>
                        <strong>{{ pay.id }}</strong> · {{ pay.method }} · Key: <span class="font-mono">{{ pay.idempotencyKey }}</span>
                      </span>
                      <span>
                        Allocated: <strong>{{ store.formatExactCurrency(pay.amountMinor, pay.currency) }}</strong>
                        (Settled: {{ store.formatExactCurrency(pay.settlementAmountMinor, pay.settlementCurrency) }} @ {{ pay.fxRate }})
                      </span>
                    </div>
                  }
                </div>
              }

              @if (inv.creditNotes.length > 0) {
                <div class="space-y-1.5 text-xs">
                  <div class="font-semibold text-slate-700">Issued Credit Notes</div>
                  @for (cn of inv.creditNotes; track cn.id) {
                    <div class="flex flex-wrap items-center justify-between gap-2 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2 tabular-nums">
                      <span><strong>{{ cn.id }}</strong> · {{ cn.reason }}</span>
                      <span class="font-bold text-[#00449E]">
                        -{{ store.formatExactCurrency(cn.amountMinor, cn.currency) }}
                      </span>
                    </div>
                  }
                </div>
              }
            </article>
          }
        </div>
      }
    </div>
  `,
})
export class InvoicesPaymentsPage {
  readonly store = inject(MarketplaceStore);

  readonly payAmount = signal<Partial<Record<string, number>>>({});
  readonly payCurrency = signal<Partial<Record<string, CurrencyCode>>>({});
  readonly idempKey = signal<Partial<Record<string, string>>>({});

  setPayAmount(id: string, e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    if (Number.isFinite(val)) {
      this.payAmount.update((m) => ({...m, [id]: Math.floor(val)}));
    }
  }

  setPayCurrency(id: string, e: Event): void {
    this.payCurrency.update((m) => ({
      ...m,
      [id]: (e.target as HTMLSelectElement).value as CurrencyCode,
    }));
  }

  setIdempKey(id: string, e: Event): void {
    this.idempKey.update((m) => ({
      ...m,
      [id]: (e.target as HTMLInputElement).value,
    }));
  }

  async submitPayment(inv: Invoice): Promise<void> {
    const amountMinor = this.payAmount()[inv.id] ?? inv.balanceDueMinor;
    const currency = this.payCurrency()[inv.id] ?? inv.currency;
    const idempotencyKey = this.idempKey()[inv.id] ?? `BACS-${inv.id}`;
    try {
      await this.store.recordPayment(inv.id, {
        idempotencyKey,
        method: 'simulated_bank_transfer',
        amountMinor,
        currency,
        reference: `FPS-${Date.now().toString().slice(-5)}`,
      });
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }
}
