import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore, PERSONA_PRESETS} from '../core/marketplace.store';

@Component({
  selector: 'app-platform-admin',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            Platform Administration & Governance
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Manage platform fee rules, reservation TTL, integration adapter boundaries, and simulated business verification reviews.
          </p>
        </div>

        @if (!isAdmin()) {
          <button
            type="button"
            (click)="switchToAdmin()"
            class="h-10 px-4 rounded-lg bg-[#00449E] text-white text-xs font-semibold flex items-center gap-1.5 self-start"
          >
            <mat-icon class="text-[17px]">admin_panel_settings</mat-icon>
            <span>Switch to Platform Admin (Tom)</span>
          </button>
        }
      </div>

      @if (store.platformConfig(); as cfg) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <!-- Platform Policies -->
          <form
            [formGroup]="configForm"
            (ngSubmit)="saveConfig()"
            class="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4"
          >
            <h2 class="font-display font-bold text-lg text-slate-900">
              Platform Fee & Inventory Policy
            </h2>
            <p class="text-xs text-slate-500">
              Changes preserve fee snapshots on previously confirmed orders and log an audit entry.
            </p>

            <div class="space-y-3 text-sm">
              <div>
                <label for="adm-fee" class="block text-xs font-semibold text-slate-700 mb-1">
                  Marketplace Commercial Fee (basis points, 100 bps = 1%)
                </label>
                <input
                  id="adm-fee"
                  type="number"
                  formControlName="marketplaceFeeBps"
                  class="w-full h-10 px-3 border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label for="adm-ttl" class="block text-xs font-semibold text-slate-700 mb-1">
                  Stock Reservation Expiry TTL (minutes)
                </label>
                <input
                  id="adm-ttl"
                  type="number"
                  formControlName="defaultReservationTtlMinutes"
                  class="w-full h-10 px-3 border border-slate-300 rounded-lg tabular-nums"
                />
              </div>
              <div>
                <label for="adm-summary" class="block text-xs font-semibold text-slate-700 mb-1">
                  Change Audit Summary
                </label>
                <input
                  id="adm-summary"
                  type="text"
                  formControlName="summary"
                  class="w-full h-10 px-3 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <button
              type="submit"
              [disabled]="!isAdmin()"
              class="w-full h-10 rounded-lg bg-[#00449E] hover:bg-[#00357E] disabled:opacity-45 text-white text-sm font-semibold"
            >
              Update Platform Policy
            </button>

            <!-- Integration Adapter Boundaries -->
            <div class="pt-4 border-t border-slate-100 space-y-2 text-xs">
              <div class="font-bold text-slate-800">External Integration Boundaries</div>
              <div class="flex justify-between py-1 border-b border-slate-100">
                <span>Freight & Carrier Tracking</span>
                <span class="font-mono text-amber-700">{{ cfg.adapters.freight }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-100">
                <span>Customs & Import Duty Engine</span>
                <span class="font-mono text-amber-700">{{ cfg.adapters.customs }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-slate-100">
                <span>Payment Settlement Adapter</span>
                <span class="font-mono text-amber-700">{{ cfg.adapters.payment }}</span>
              </div>
              <div class="flex justify-between py-1">
                <span>Document & Object Storage</span>
                <span class="font-mono text-amber-700">{{ cfg.adapters.storage }}</span>
              </div>
            </div>
          </form>

          <!-- Organisation Verification Console -->
          <section class="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <h2 class="font-display font-bold text-lg text-slate-900">
              Organisation Verification & Onboarding Registry
            </h2>

            <div class="space-y-3">
              @for (org of store.organisations(); track org.id) {
                <div class="border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div class="space-y-1">
                    <div class="flex items-center gap-2">
                      <span>{{ store.flagForCountry(org.countryCode) }}</span>
                      <strong class="text-sm text-slate-900">{{ org.tradingName }}</strong>
                      <span class="text-slate-500">({{ org.kind }})</span>
                    </div>
                    <div class="text-slate-600">{{ org.verification.checkedItem }}</div>
                    <div class="text-slate-500">
                      Status:
                      <strong
                        [class.text-emerald-700]="org.verification.status === 'verified'"
                        [class.text-amber-700]="org.verification.status !== 'verified'"
                      >
                        {{ org.verification.status }}
                      </strong>
                      · {{ org.verification.verifiedBy }} ({{ org.verification.verifiedAt.slice(0, 10) }})
                    </div>
                  </div>

                  @if (isAdmin()) {
                    <div class="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        (click)="setVerification(org.id, 'verified', 'Synthetic registry and GMP doc check passed')"
                        class="px-3 py-1.5 rounded-lg border border-emerald-300 text-emerald-800 hover:bg-emerald-50 font-semibold"
                      >
                        Mark Verified
                      </button>
                      <button
                        type="button"
                        (click)="setVerification(org.id, 'amber_exception', 'Amber exception: annual compliance renewal requested')"
                        class="px-3 py-1.5 rounded-lg border border-amber-300 text-amber-800 hover:bg-amber-50 font-semibold"
                      >
                        Flag Amber
                      </button>
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Configuration History -->
            <div class="pt-4 border-t border-slate-100 space-y-2">
              <div class="text-xs font-bold text-slate-800">Configuration Change Audit Log</div>
              @for (item of cfg.configHistory; track item.id) {
                <div class="text-xs text-slate-600 flex justify-between gap-2 py-1 border-b border-slate-50">
                  <span>{{ item.summary }}</span>
                  <span class="text-slate-400 shrink-0">{{ item.changedAt.slice(0, 16) }}</span>
                </div>
              }
            </div>
          </section>
        </div>
      }
    </div>
  `,
})
export class PlatformAdminPage {
  readonly store = inject(MarketplaceStore);

  readonly isAdmin = computed(() => this.store.activePersona().role === 'platform_admin');

  readonly configForm = new FormGroup({
    marketplaceFeeBps: new FormControl(150, {nonNullable: true}),
    defaultReservationTtlMinutes: new FormControl(120, {nonNullable: true}),
    summary: new FormControl('Updated platform fee and reservation policy', {nonNullable: true}),
  });

  constructor() {
    effect(() => {
      const cfg = this.store.platformConfig();
      if (cfg) {
        this.configForm.patchValue({
          marketplaceFeeBps: cfg.marketplaceFeeBps,
          defaultReservationTtlMinutes: cfg.defaultReservationTtlMinutes,
        });
      }
    });
  }

  async switchToAdmin(): Promise<void> {
    const admin = PERSONA_PRESETS.find((p) => p.role === 'platform_admin')!;
    await this.store.switchPersona(admin);
  }

  async saveConfig(): Promise<void> {
    try {
      await this.store.updatePlatformConfig(this.configForm.getRawValue());
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }

  async setVerification(orgId: string, status: string, notes: string): Promise<void> {
    try {
      await this.store.updateOrgVerification(orgId, {status, notes});
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }
}
