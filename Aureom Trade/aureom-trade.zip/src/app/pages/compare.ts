import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  signal,
} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {LandedCostBreakdown, TransportMode} from '../core/models';

@Component({
  selector: 'app-compare',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            Offer Comparison & Estimated Landed Cost
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Compare equivalent unit price, freight assumptions, Incoterms 2020, and missing quotation terms.
            Incomplete quotes are never ranked cheapest.
          </p>
        </div>

        <!-- Scenario controls -->
        <div class="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap items-center gap-3">
          <div class="flex items-center gap-2">
            <label for="cmp-cases" class="text-xs font-semibold text-slate-700">Quantity (cases):</label>
            <input
              id="cmp-cases"
              type="number"
              min="40"
              step="10"
              [value]="cases()"
              (input)="onCasesChange($event)"
              class="w-24 h-9 px-2.5 text-sm border border-slate-300 rounded-lg tabular-nums font-semibold"
            />
          </div>
          <div class="flex items-center gap-2">
            <label for="cmp-mode" class="text-xs font-semibold text-slate-700">Transport:</label>
            <select
              id="cmp-mode"
              [value]="transportMode()"
              (change)="onModeChange($event)"
              class="h-9 px-2.5 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="road">Road / Ro-Ro</option>
              <option value="sea">Sea Freight</option>
              <option value="air">Air Freight</option>
              <option value="multimodal">Multimodal</option>
            </select>
          </div>
          <button
            type="button"
            (click)="runComparison()"
            class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-xs font-semibold flex items-center gap-1.5"
          >
            <mat-icon class="text-[16px]">calculate</mat-icon>
            <span>Recalculate</span>
          </button>
        </div>
      </div>

      <!-- Disclaimer banner -->
      <div class="bg-[#EAF2FD] border border-blue-200 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-700">
        <mat-icon class="text-[20px] text-[#00449E] shrink-0">info</mat-icon>
        <div>
          <strong class="text-slate-900">Estimated landed cost notice:</strong>
          Formula applied: Goods + applicable freight + insurance + duties + import VAT/GST + marketplace fee ({{ (store.platformConfig()?.marketplaceFeeBps ?? 150) / 100 }}%) = Estimated Landed Cost.
          Synthetic freight and customs adapters are active because no live carrier/customs API is configured. This estimate is <strong>not</strong> a guaranteed delivered price.
        </div>
      </div>

      <!-- Quick Toggle Offers to Compare -->
      <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
        <div class="text-xs font-semibold text-slate-700">
          Offers included in comparison (click to toggle):
        </div>
        <div class="flex flex-wrap gap-2">
          @for (item of store.enrichedOffers(); track item.offer.id) {
            <button
              type="button"
              (click)="toggleOffer(item.offer.id)"
              class="px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors"
              [class.bg-[#00449E]]="selectedIds().includes(item.offer.id)"
              [class.text-white]="selectedIds().includes(item.offer.id)"
              [class.border-[#00449E]]="selectedIds().includes(item.offer.id)"
              [class.bg-slate-50]="!selectedIds().includes(item.offer.id)"
              [class.text-slate-700]="!selectedIds().includes(item.offer.id)"
              [class.border-slate-200]="!selectedIds().includes(item.offer.id)"
            >
              {{ item.product?.name }} · {{ item.seller?.tradingName }} ({{ item.offer.incoterm }})
            </button>
          }
        </div>
      </div>

      @if (breakdowns().length > 0) {
        <div class="bg-white border border-slate-200 rounded-xl overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="bg-slate-50 border-b border-slate-200 text-slate-600">
                <th class="py-3 px-4 font-semibold">Rank & Supplier</th>
                <th class="py-3 px-3 font-semibold">Product & Pack</th>
                <th class="py-3 px-3 font-semibold">Incoterm</th>
                <th class="py-3 px-3 font-semibold text-right">Goods</th>
                <th class="py-3 px-3 font-semibold text-right">Freight</th>
                <th class="py-3 px-3 font-semibold text-right">Insurance</th>
                <th class="py-3 px-3 font-semibold text-right">Duties & Tax</th>
                <th class="py-3 px-3 font-semibold text-right">Est. Landed</th>
                <th class="py-3 px-3 font-semibold text-right">Unit Equiv.</th>
                <th class="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (row of breakdowns(); track row.offerId; let idx = $index) {
                @let meta = offerMeta(row.offerId);
                <tr class="hover:bg-slate-50/70">
                  <td class="py-3.5 px-4">
                    <div class="font-semibold text-slate-900">
                      #{{ idx + 1 }} · {{ meta?.seller?.tradingName }}
                    </div>
                    <div class="text-[11px] text-slate-500">
                      MOQ {{ meta?.offer?.moqCases }} cases · {{ meta?.offer?.leadTimeDays }}d lead · {{ meta?.offer?.paymentTerms }}
                    </div>
                    @if (!row.isComplete) {
                      <div class="mt-1 text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded px-2 py-0.5 inline-block">
                        Incomplete: {{ row.missingTerms.join(', ') }}
                      </div>
                    }
                    @if (!row.transportValid && row.transportWarning) {
                      <div class="mt-1 text-[11px] text-red-700 bg-red-50 border border-red-200 rounded px-2 py-0.5">
                        {{ row.transportWarning }}
                      </div>
                    }
                  </td>
                  <td class="py-3.5 px-3">
                    <div class="font-medium text-slate-800">{{ meta?.product?.name }}</div>
                    <div class="text-slate-500">{{ meta?.pkg?.casePackSummary }}</div>
                  </td>
                  <td class="py-3.5 px-3">
                    <div class="font-semibold text-slate-800">{{ meta?.offer?.incoterm }}</div>
                    <div class="text-[11px] text-slate-500">{{ meta?.offer?.namedPlace }}</div>
                  </td>
                  <td class="py-3.5 px-3 text-right tabular-nums font-medium">
                    {{ store.formatExactCurrency(row.goodsMinor, row.currency) }}
                  </td>
                  <td class="py-3.5 px-3 text-right tabular-nums">
                    @if (row.freightMinor === null) {
                      <span class="text-amber-700 font-semibold">Missing</span>
                    } @else if (row.includedInIncoterm.includes('Main freight')) {
                      <span class="text-emerald-700">Included</span>
                    } @else {
                      <span>{{ store.formatExactCurrency(row.freightMinor, row.currency) }}</span>
                    }
                  </td>
                  <td class="py-3.5 px-3 text-right tabular-nums">
                    @if (row.insuranceMinor === null) {
                      <span class="text-amber-700 font-semibold">Missing</span>
                    } @else if (row.includedInIncoterm.includes('Cargo insurance')) {
                      <span class="text-emerald-700">Included</span>
                    } @else {
                      <span>{{ store.formatExactCurrency(row.insuranceMinor, row.currency) }}</span>
                    }
                  </td>
                  <td class="py-3.5 px-3 text-right tabular-nums">
                    @if (row.dutiesMinor === null || row.taxesMinor === null) {
                      <span class="text-amber-700 font-semibold">Missing</span>
                    } @else {
                      <span>{{ store.formatExactCurrency(row.dutiesMinor + row.taxesMinor, row.currency) }}</span>
                    }
                  </td>
                  <td class="py-3.5 px-3 text-right tabular-nums font-bold text-slate-900">
                    @if (row.estimatedLandedTotalMinor !== null) {
                      <span>{{ store.formatExactCurrency(row.estimatedLandedTotalMinor, row.currency) }}</span>
                    } @else {
                      <span class="text-amber-700">Incomplete quote</span>
                    }
                  </td>
                  <td class="py-3.5 px-3 text-right tabular-nums font-semibold text-[#00449E]">
                    @if (row.equivalentPerUnitMinor !== null) {
                      <span>{{ store.formatExactCurrency(row.equivalentPerUnitMinor, row.currency) }} / unit</span>
                    } @else {
                      <span>—</span>
                    }
                  </td>
                  <td class="py-3.5 px-4 text-right">
                    <a
                      [routerLink]="['/products', meta?.product?.id]"
                      [queryParams]="{offer: row.offerId}"
                      class="inline-flex items-center px-3 py-1.5 rounded-lg border border-[#0066CC] text-[#00449E] hover:bg-[#00449E] hover:text-white font-semibold whitespace-nowrap"
                    >
                      Select
                    </a>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </div>
  `,
})
export class ComparePage {
  readonly store = inject(MarketplaceStore);

  readonly cases = signal<number>(200);
  readonly transportMode = signal<TransportMode>('road');
  readonly selectedIds = signal<string[]>([]);
  readonly breakdowns = signal<LandedCostBreakdown[]>([]);

  constructor() {
    effect(() => {
      const shortlist = this.store.shortlistOfferIds();
      const allOffers = this.store.offers();
      if (this.selectedIds().length === 0 && allOffers.length > 0) {
        const initial =
          shortlist.length > 0
            ? [...shortlist, 'off_bw_pacific_us'].filter(
                (v, i, a) => a.indexOf(v) === i && allOffers.some((o) => o.id === v),
              )
            : allOffers.slice(0, 3).map((o) => o.id);
        this.selectedIds.set(initial);
        this.runComparison();
      }
    });
    effect(() => {
      // Re-run comparison automatically when displayCurrency changes
      this.store.displayCurrency();
      if (this.selectedIds().length > 0) {
        this.runComparison();
      }
    });
  }

  offerMeta(offerId: string) {
    return this.store.enrichedOffers().find((e) => e.offer.id === offerId);
  }

  onCasesChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val > 0) {
      this.cases.set(Math.floor(val));
    }
  }

  onModeChange(event: Event): void {
    this.transportMode.set((event.target as HTMLSelectElement).value as TransportMode);
    this.runComparison();
  }

  toggleOffer(offerId: string): void {
    const curr = this.selectedIds();
    if (curr.includes(offerId)) {
      if (curr.length === 1) return;
      this.selectedIds.set(curr.filter((id) => id !== offerId));
    } else {
      this.selectedIds.set([...curr, offerId]);
    }
    this.runComparison();
  }

  async runComparison(): Promise<void> {
    if (this.selectedIds().length === 0) return;
    try {
      const ranked = await this.store.compareOffers(
        this.selectedIds(),
        this.cases(),
        this.transportMode(),
      );
      this.breakdowns.set(ranked);
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }
}
