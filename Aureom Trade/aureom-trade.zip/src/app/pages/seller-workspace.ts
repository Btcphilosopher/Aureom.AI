import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore, PERSONA_PRESETS} from '../core/marketplace.store';
import {Order} from '../core/models';

@Component({
  selector: 'app-seller-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            Seller & Warehouse Workspace
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Manage batch inventory ledger, warehouse receipts, controlled batch withdrawals, and partial or full order dispatches.
          </p>
        </div>

        <div class="flex flex-wrap gap-2">
          <button
            type="button"
            (click)="switchToSeller('usr_owen_seller')"
            class="h-9 px-3.5 rounded-lg border border-slate-300 bg-white hover:border-[#0066CC] text-xs font-semibold text-slate-800"
          >
            Act as Aureom Direct Seller (Owen)
          </button>
          <button
            type="button"
            (click)="switchToSeller('usr_sam_warehouse')"
            class="h-9 px-3.5 rounded-lg border border-slate-300 bg-white hover:border-[#0066CC] text-xs font-semibold text-slate-800"
          >
            Act as Warehouse (Samira)
          </button>
        </div>
      </div>

      <!-- Orders Ready to Dispatch -->
      <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between">
          <h2 class="font-display font-bold text-lg text-slate-900">
            Seller Orders & Dispatch Queue ({{ dispatchableOrders().length }})
          </h2>
          <a routerLink="/orders" class="text-xs font-semibold text-[#00449E] hover:underline">
            View all shipments
          </a>
        </div>

        @if (dispatchableOrders().length === 0) {
          <div class="p-4 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
            @if (isSellerContext()) {
              No allocated orders awaiting dispatch for {{ store.activePersona().orgName }}.
            } @else {
              Switch to a Seller Manager or Warehouse User (e.g. Owen Davies or Samira Khan) to dispatch allocated seller orders.
            }
          </div>
        } @else {
          <div class="space-y-3">
            @for (ord of dispatchableOrders(); track ord.id) {
              @let line = ord.lines[0];
              @let remaining = line.casesOrdered - line.casesDispatched;
              <div class="border border-slate-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div class="space-y-1">
                  <div class="flex items-center gap-2 text-xs">
                    <span class="font-mono font-bold text-[#00449E]">{{ ord.id }}</span>
                    <span>·</span>
                    <span class="font-semibold text-slate-800">{{ ord.buyerName }}</span>
                    <span>·</span>
                    <span class="text-emerald-700 font-semibold">{{ ord.status }}</span>
                  </div>
                  <div class="text-sm font-semibold text-slate-900">
                    {{ line.productName }} ({{ line.sku }})
                  </div>
                  <div class="text-xs text-slate-600 tabular-nums">
                    Ordered: {{ line.casesOrdered }} · Allocated: {{ line.casesAllocated }} · Dispatched: {{ line.casesDispatched }} · Remaining: {{ remaining }} cases
                  </div>
                </div>

                <div class="flex flex-wrap items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    [max]="remaining"
                    [value]="dispatchQtyMap()[ord.id] ?? Math.min(remaining, 600)"
                    (input)="setDispatchQty(ord.id, $event)"
                    class="w-24 h-9 px-2.5 text-sm border border-slate-300 rounded-lg tabular-nums font-semibold"
                  />
                  <button
                    type="button"
                    (click)="dispatchOrder(ord)"
                    class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <mat-icon class="text-[16px]">local_shipping</mat-icon>
                    <span>Dispatch shipment</span>
                  </button>
                </div>
              </div>
            }
          </div>
        }
      </section>

      <!-- Inventory & Batch Traceability -->
      <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 class="font-display font-bold text-lg text-slate-900">
              Warehouse Inventory & Batch Traceability
            </h2>
            <p class="text-xs text-slate-500">
              Tracks on-hand, reserved, available, quarantined, damaged, and in-transit cases by batch and expiry.
            </p>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="bg-slate-50 border-b border-slate-200 text-slate-600">
                <th class="py-2.5 px-3 font-semibold">SKU & Warehouse</th>
                <th class="py-2.5 px-3 font-semibold">Batch & Expiry</th>
                <th class="py-2.5 px-3 font-semibold text-right">On-Hand</th>
                <th class="py-2.5 px-3 font-semibold text-right">Reserved</th>
                <th class="py-2.5 px-3 font-semibold text-right">Available</th>
                <th class="py-2.5 px-3 font-semibold text-right">Quar/Dmg</th>
                <th class="py-2.5 px-3 font-semibold text-right">In Transit</th>
                <th class="py-2.5 px-3 font-semibold">Provenance</th>
                <th class="py-2.5 px-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (rec of visibleInventory(); track rec.id) {
                <tr [class.bg-red-50/40]="rec.withdrawn">
                  <td class="py-3 px-3">
                    <div class="font-mono font-semibold text-slate-900">{{ rec.sku }}</div>
                    <div class="text-slate-500">{{ rec.warehouseName }}</div>
                  </td>
                  <td class="py-3 px-3">
                    <div class="font-mono font-medium text-slate-800">{{ rec.batchNumber }}</div>
                    <div class="text-slate-500 tabular-nums">Exp: {{ rec.expiryDate }}</div>
                  </td>
                  <td class="py-3 px-3 text-right tabular-nums">{{ rec.onHandCases }}</td>
                  <td class="py-3 px-3 text-right tabular-nums text-[#00449E] font-medium">{{ rec.reservedCases }}</td>
                  <td class="py-3 px-3 text-right tabular-nums font-bold text-emerald-700">{{ rec.availableCases }}</td>
                  <td class="py-3 px-3 text-right tabular-nums text-amber-700">
                    {{ rec.quarantinedCases }} / {{ rec.damagedCases }}
                  </td>
                  <td class="py-3 px-3 text-right tabular-nums">{{ rec.inTransitCases }}</td>
                  <td class="py-3 px-3">
                    <div class="text-slate-700">
                      {{ rec.source === 'platform_managed' ? 'Platform-managed' : 'Supplier-reported' }}
                    </div>
                    <div class="text-[11px] text-slate-500 tabular-nums">{{ rec.updatedAt.slice(0, 16) }}</div>
                  </td>
                  <td class="py-3 px-3 text-right">
                    @if (!rec.withdrawn && (rec.sellerOrgId === store.activePersona().orgId || store.activePersona().role === 'platform_admin')) {
                      <div class="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          (click)="store.addInventoryReceipt(rec.id, 100, 'Routine warehouse restock')"
                          class="px-2.5 py-1 rounded border border-slate-300 hover:border-[#0066CC] text-slate-700 font-medium"
                        >
                          +100 Receipt
                        </button>
                        <button
                          type="button"
                          (click)="store.withdrawBatch(rec.batchNumber, 'Quality control recall test')"
                          class="px-2.5 py-1 rounded border border-red-200 text-red-700 hover:bg-red-50 font-medium"
                        >
                          Withdraw
                        </button>
                      </div>
                    } @else if (rec.withdrawn) {
                      <span class="text-red-700 font-semibold">Withdrawn: {{ rec.withdrawalReason }}</span>
                    } @else {
                      <span class="text-slate-400">Read-only</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Stock Movement Ledger -->
      <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
        <h2 class="font-display font-bold text-base text-slate-900">
          Stock Movement Ledger (Latest Entries)
        </h2>
        <div class="space-y-2 text-xs">
          @for (entry of store.stockLedger().slice(0, 10); track entry.id) {
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 py-2 border-b border-slate-100">
              <div class="flex items-center gap-2">
                <span class="font-mono text-slate-500">{{ entry.timestamp.slice(0, 19) }}</span>
                <span class="font-semibold text-slate-800 uppercase">{{ entry.movementType }}</span>
                <span class="font-mono text-[#00449E]">{{ entry.sku }}</span>
                <span class="text-slate-500">Batch {{ entry.batchNumber }}</span>
              </div>
              <div class="flex items-center gap-3">
                <span class="text-slate-600">{{ entry.note }}</span>
                <span
                  class="font-mono font-bold tabular-nums"
                  [class.text-emerald-700]="entry.deltaCases > 0"
                  [class.text-amber-700]="entry.deltaCases < 0"
                >
                  {{ entry.deltaCases > 0 ? '+' + entry.deltaCases : entry.deltaCases }} cases
                </span>
              </div>
            </div>
          }
        </div>
      </section>
    </div>
  `,
})
export class SellerWorkspacePage {
  readonly store = inject(MarketplaceStore);
  readonly Math = Math;

  readonly dispatchQtyMap = signal<Partial<Record<string, number>>>({});

  readonly isSellerContext = computed(() => {
    const role = this.store.activePersona().role;
    return role === 'seller_manager' || role === 'warehouse_user' || role === 'platform_admin';
  });

  readonly dispatchableOrders = computed(() =>
    this.store
      .orders()
      .filter(
        (o) =>
          (o.status === 'Allocated' || o.status === 'Partially Dispatched' || o.status === 'Confirmed') &&
          (o.sellerOrgId === this.store.activePersona().orgId ||
            this.store.activePersona().role === 'platform_admin'),
      ),
  );

  readonly visibleInventory = computed(() => {
    const p = this.store.activePersona();
    if (p.role === 'platform_admin') return this.store.inventory();
    const own = this.store.inventory().filter((i) => i.sellerOrgId === p.orgId);
    return own.length > 0 ? own : this.store.inventory();
  });

  setDispatchQty(orderId: string, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val > 0) {
      this.dispatchQtyMap.update((m) => ({...m, [orderId]: Math.floor(val)}));
    }
  }

  async dispatchOrder(ord: Order): Promise<void> {
    const line = ord.lines[0];
    const remaining = line.casesOrdered - line.casesDispatched;
    const qty = this.dispatchQtyMap()[ord.id] ?? Math.min(remaining, 600);
    try {
      await this.store.dispatchShipment(ord.id, 'Aureom UK Express Haulage (Simulated)', [
        {orderLineId: line.id, cases: Math.min(qty, remaining)},
      ]);
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }

  async switchToSeller(userId: string): Promise<void> {
    const preset = PERSONA_PRESETS.find((p) => p.userId === userId);
    if (preset) {
      await this.store.switchPersona(preset);
    }
  }
}
