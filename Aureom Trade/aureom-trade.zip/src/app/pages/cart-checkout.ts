import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {Router, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {CurrencyCode, Offer, PackagingConfig, Product} from '../core/models';

@Component({
  selector: 'app-cart-checkout',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex items-center justify-between">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            Wholesale Basket & Multi-Seller Checkout
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Baskets spanning multiple suppliers automatically split into seller-specific orders, shipments, and invoices under one buyer group.
          </p>
        </div>
        <a routerLink="/" class="text-sm font-semibold text-[#00449E] hover:underline">
          Continue sourcing
        </a>
      </div>

      @if (store.cart().length === 0) {
        <div class="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <mat-icon class="text-[40px] text-slate-400">shopping_cart</mat-icon>
          <div class="font-display font-bold text-lg text-slate-900">Your wholesale basket is empty</div>
          <p class="text-sm text-slate-500 max-w-md mx-auto">
            Browse wholesale product offers or award a negotiated RFQ to place a confirmed order.
          </p>
          <div class="flex justify-center gap-3 pt-2">
            <a
              routerLink="/"
              class="px-5 py-2.5 rounded-lg bg-[#00449E] text-white text-sm font-semibold"
            >
              Explore marketplace
            </a>
            <a
              routerLink="/rfqs"
              class="px-5 py-2.5 rounded-lg border border-slate-300 text-slate-700 text-sm font-semibold"
            >
              View open RFQs
            </a>
          </div>
        </div>
      } @else {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <!-- Grouped by Seller -->
          <div class="lg:col-span-8 space-y-4">
            @for (group of sellerGroups(); track group.sellerId) {
              <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div class="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div>
                    <div class="text-xs text-slate-500">Seller Order Split</div>
                    <h2 class="font-display font-bold text-base text-slate-900">
                      {{ group.sellerName }}
                    </h2>
                  </div>
                  <span class="text-xs font-semibold text-[#00449E] tabular-nums">
                    {{ group.items.length }} line(s)
                  </span>
                </div>

                @for (line of group.items; track line.offer.id) {
                  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-2">
                    <div class="flex items-center gap-3">
                      <img
                        [src]="line.product.imageUrl"
                        [alt]="line.product.name"
                        referrerpolicy="no-referrer"
                        class="w-14 h-14 object-contain rounded-lg bg-slate-50 border border-slate-100 p-1"
                      />
                      <div>
                        <div class="font-semibold text-sm text-slate-900">{{ line.product.name }}</div>
                        <div class="text-xs text-slate-500">
                          {{ line.pkg.casePackSummary }} · {{ line.offer.incoterm }} {{ line.offer.namedPlace }}
                        </div>
                        <div class="text-xs text-slate-600 tabular-nums">
                          Unit tier: {{ store.formatPriceMinor(line.unitMinor, line.offer.currency) }} / case
                        </div>
                      </div>
                    </div>

                    <div class="flex items-center gap-3">
                      <input
                        type="number"
                        [value]="line.cases"
                        [min]="line.offer.moqCases"
                        [step]="line.offer.orderIncrementCases"
                        (change)="onCasesEdit(line.offer.id, $event)"
                        class="w-24 h-9 px-2.5 text-sm border border-slate-300 rounded-lg tabular-nums font-semibold"
                      />
                      <span class="text-xs text-slate-500">cases</span>
                      <div class="w-24 text-right font-bold text-sm text-slate-900 tabular-nums">
                        {{ store.formatPriceMinor(line.unitMinor * line.cases, line.offer.currency) }}
                      </div>
                      <button
                        type="button"
                        (click)="store.removeFromCart(line.offer.id)"
                        aria-label="Remove item"
                        class="p-1.5 text-slate-400 hover:text-red-600"
                      >
                        <mat-icon class="text-[18px]">delete_outline</mat-icon>
                      </button>
                    </div>
                  </div>
                }
              </section>
            }
          </div>

          <!-- Checkout Summary -->
          <aside class="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <h2 class="font-display font-bold text-lg text-slate-900">Buyer Checkout Summary</h2>

            <div class="space-y-3 text-xs">
              <div>
                <label for="co-bu" class="block font-semibold text-slate-700 mb-1">Business Unit</label>
                <select
                  id="co-bu"
                  [value]="businessUnit()"
                  (change)="onBusinessUnitChange($event)"
                  class="w-full h-9 px-2.5 border border-slate-300 rounded-lg bg-white"
                >
                  @for (bu of store.activeOrg().businessUnits; track bu) {
                    <option [value]="bu">{{ bu }}</option>
                  }
                </select>
              </div>
              <div>
                <label for="co-dest" class="block font-semibold text-slate-700 mb-1">Delivery Destination</label>
                <select
                  id="co-dest"
                  [value]="destinationCountry()"
                  (change)="onDestChange($event)"
                  class="w-full h-9 px-2.5 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="Germany">Germany</option>
                  <option value="Netherlands">Netherlands</option>
                </select>
              </div>
              <div>
                <label for="co-addr" class="block font-semibold text-slate-700 mb-1">Delivery Address</label>
                <select
                  id="co-addr"
                  [value]="deliveryLocation()"
                  (change)="onLocationChange($event)"
                  class="w-full h-9 px-2.5 border border-slate-300 rounded-lg bg-white"
                >
                  @for (loc of store.activeOrg().deliveryLocations; track loc) {
                    <option [value]="loc">{{ loc }}</option>
                  }
                </select>
              </div>
            </div>

            <div class="pt-3 border-t border-slate-100 space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-slate-600">Seller orders created</span>
                <span class="font-semibold tabular-nums">{{ sellerGroups().length }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-600">Estimated goods subtotal</span>
                <span class="font-bold text-slate-900 tabular-nums">
                  {{ store.formatPriceMinor(estimatedGoodsMinor(), 'USD') }}
                </span>
              </div>
              <div class="text-xs text-slate-500">
                Freight, insurance, duties, and {{ (store.platformConfig()?.marketplaceFeeBps ?? 150) / 100 }}% platform fee are calculated per seller order upon submission.
              </div>
            </div>

            <button
              type="button"
              [disabled]="busy()"
              (click)="placeOrders()"
              class="w-full h-11 rounded-lg bg-[#00449E] hover:bg-[#00357E] disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-2"
            >
              <mat-icon class="text-[18px]">check_circle</mat-icon>
              <span>{{ busy() ? 'Submitting orders...' : 'Place wholesale order(s)' }}</span>
            </button>
          </aside>
        </div>
      }
    </div>
  `,
})
export class CartCheckoutPage {
  readonly store = inject(MarketplaceStore);
  private readonly router = inject(Router);

  readonly businessUnit = signal<string>('UK Personal Care');
  readonly destinationCountry = signal<string>('United Kingdom');
  readonly deliveryLocation = signal<string>('Felixstowe Distribution Centre, Suffolk IP11 3SY');
  readonly busy = signal<boolean>(false);

  readonly sellerGroups = computed(() => {
    const groups = new Map<
      string,
      {
        sellerId: string;
        sellerName: string;
        items: {
          offer: Offer;
          product: Product;
          pkg: PackagingConfig;
          cases: number;
          unitMinor: number;
        }[];
      }
    >();

    for (const item of this.store.cart()) {
      const resolved = this.resolveOffer(item.offerId);
      if (!resolved) continue;
      const sorted = [...resolved.offer.tiers].sort((a, b) => a.minCases - b.minCases);
      let unitMinor = sorted[0].unitPriceMinorPerCase;
      for (const t of sorted) {
        if (item.cases >= t.minCases && (t.maxCases === null || item.cases <= t.maxCases)) {
          unitMinor = t.unitPriceMinorPerCase;
        }
      }
      const existing = groups.get(resolved.seller.id) ?? {
        sellerId: resolved.seller.id,
        sellerName: resolved.seller.tradingName,
        items: [],
      };
      existing.items.push({
        offer: resolved.offer,
        product: resolved.product,
        pkg: resolved.pkg,
        cases: item.cases,
        unitMinor,
      });
      groups.set(resolved.seller.id, existing);
    }
    return Array.from(groups.values());
  });

  readonly estimatedGoodsMinor = computed(() =>
    this.sellerGroups().reduce(
      (sum, g) => sum + g.items.reduce((s, i) => s + i.unitMinor * i.cases, 0),
      0,
    ),
  );

  private resolveOffer(offerId: string) {
    const found = this.store.enrichedOffers().find((e) => e.offer.id === offerId);
    if (!found?.product || !found?.seller || !found?.pkg) return null;
    return {offer: found.offer, product: found.product, seller: found.seller, pkg: found.pkg};
  }

  onCasesEdit(offerId: string, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val > 0) {
      this.store.updateCartCases(offerId, Math.floor(val));
    }
  }

  onBusinessUnitChange(event: Event): void {
    this.businessUnit.set((event.target as HTMLSelectElement).value);
  }

  onDestChange(event: Event): void {
    this.destinationCountry.set((event.target as HTMLSelectElement).value);
  }

  onLocationChange(event: Event): void {
    this.deliveryLocation.set((event.target as HTMLSelectElement).value);
  }

  async placeOrders(): Promise<void> {
    this.busy.set(true);
    try {
      await this.store.checkoutCart({
        businessUnit: this.businessUnit(),
        destinationCountry: this.destinationCountry(),
        deliveryLocation: this.deliveryLocation(),
        orderCurrency: this.store.displayCurrency() as CurrencyCode,
      });
      this.router.navigate(['/orders']);
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    } finally {
      this.busy.set(false);
    }
  }
}
