import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {ActivatedRoute, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';

@Component({
  selector: 'app-suppliers',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            @if (selectedSupplier(); as sup) {
              {{ sup.tradingName }} — Supplier Storefront
            } @else {
              Verified Suppliers & First-Party Wholesale
            }
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Simulated business verification shows what was checked, by whom, and when — never a guarantee of product quality or solvency.
          </p>
        </div>
        @if (selectedSupplier()) {
          <a
            routerLink="/suppliers"
            class="text-sm font-semibold text-[#00449E] hover:underline flex items-center gap-1"
          >
            <mat-icon class="text-[18px]">arrow_back</mat-icon>
            <span>All suppliers</span>
          </a>
        }
      </div>

      @if (selectedSupplier(); as sup) {
        <!-- Single Supplier Storefront -->
        <div class="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div class="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div class="space-y-1.5">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="text-xl">{{ store.flagForCountry(sup.countryCode) }}</span>
                <h2 class="font-display font-bold text-xl text-slate-900">{{ sup.legalName }}</h2>
                @if (sup.kind === 'first_party') {
                  <span class="text-xs font-semibold text-[#00449E] bg-blue-50 px-2.5 py-0.5 rounded">
                    First-party platform organisation
                  </span>
                }
              </div>
              <p class="text-sm text-slate-600">{{ sup.registeredAddress }}</p>
              <div class="text-xs text-slate-500 flex flex-wrap gap-3">
                <span class="font-mono">Reg ID: {{ sup.businessIdentifier }}</span>
                <span>·</span>
                <span class="font-mono">Tax ID: {{ sup.taxIdentifier }}</span>
                <span>·</span>
                <span>Terms: {{ sup.paymentTerms }}</span>
                <span>·</span>
                <span>Return window: {{ sup.returnPolicyDays }} days</span>
              </div>
            </div>

            <div class="rounded-xl border p-4 max-w-sm space-y-1.5 text-xs"
              [class.bg-emerald-50]="sup.verification.status === 'verified'"
              [class.border-emerald-200]="sup.verification.status === 'verified'"
              [class.bg-amber-50]="sup.verification.status !== 'verified'"
              [class.border-amber-200]="sup.verification.status !== 'verified'"
            >
              <div class="flex items-center gap-1.5 font-semibold"
                [class.text-emerald-800]="sup.verification.status === 'verified'"
                [class.text-amber-800]="sup.verification.status !== 'verified'"
              >
                <mat-icon class="text-[17px]">
                  {{ sup.verification.status === 'verified' ? 'verified_user' : 'warning_amber' }}
                </mat-icon>
                <span>
                  {{ sup.verification.status === 'verified' ? 'Verified Business (Simulated)' : 'Amber Verification Exception' }}
                </span>
              </div>
              <div class="text-slate-700"><strong>Checked:</strong> {{ sup.verification.checkedItem }}</div>
              <div class="text-slate-700"><strong>By:</strong> {{ sup.verification.verifiedBy }} · {{ sup.verification.verifiedAt.slice(0, 10) }}</div>
              <div class="text-slate-600 italic">{{ sup.verification.disclaimer }}</div>
            </div>
          </div>

          <div class="pt-4 border-t border-slate-100">
            <h3 class="font-display font-bold text-base text-slate-900 mb-3">
              Active Wholesale Offers ({{ supplierOffers(sup.id).length }})
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              @for (item of supplierOffers(sup.id); track item.offer.id) {
                <div class="border border-slate-200 rounded-xl p-4 flex flex-col justify-between gap-3">
                  <div class="flex items-start gap-3">
                    <img
                      [src]="item.product!.imageUrl"
                      [alt]="item.product!.name"
                      referrerpolicy="no-referrer"
                      class="w-16 h-16 object-contain rounded-lg bg-slate-50 p-1"
                    />
                    <div class="space-y-0.5">
                      <div class="font-semibold text-sm text-slate-900">{{ item.product!.name }}</div>
                      <div class="text-xs text-slate-500">{{ item.pkg?.casePackSummary }} · MOQ {{ item.offer.moqCases }} cases</div>
                      <div class="font-bold text-base text-slate-900 tabular-nums">
                        {{ store.formatPriceMinor(item.offer.tiers[0].unitPriceMinorPerCase, item.offer.currency) }} / case
                      </div>
                    </div>
                  </div>
                  <a
                    [routerLink]="['/products', item.product!.id]"
                    [queryParams]="{offer: item.offer.id}"
                    class="h-9 rounded-lg border border-[#0066CC] text-[#00449E] hover:bg-[#00449E] hover:text-white text-xs font-semibold flex items-center justify-center transition-colors"
                  >
                    View offer
                  </a>
                </div>
              }
            </div>
          </div>
        </div>
      } @else {
        <!-- Directory Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (org of sellerOrganisations(); track org.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-4">
              <div class="space-y-2">
                <div class="flex items-start justify-between gap-2">
                  <div>
                    <div class="flex items-center gap-1.5">
                      <span>{{ store.flagForCountry(org.countryCode) }}</span>
                      <h2 class="font-display font-bold text-base text-slate-900">{{ org.tradingName }}</h2>
                    </div>
                    <div class="text-xs text-slate-500">{{ org.countryName }} · {{ org.region }}</div>
                  </div>

                  @if (org.verification.status === 'verified') {
                    <span class="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 shrink-0">
                      <mat-icon class="text-[16px]">check_circle</mat-icon>
                      <span>Verified</span>
                    </span>
                  } @else {
                    <span class="inline-flex items-center gap-1 text-xs font-medium text-amber-700 shrink-0">
                      <mat-icon class="text-[16px]">warning_amber</mat-icon>
                      <span>Exception</span>
                    </span>
                  }
                </div>

                <p class="text-xs text-slate-600 leading-relaxed">
                  {{ org.verification.checkedItem }}
                </p>
                <div class="text-[11px] text-slate-500">
                  Verified by {{ org.verification.verifiedBy }} on {{ org.verification.verifiedAt.slice(0, 10) }}
                </div>
                <div class="text-xs text-slate-700 pt-1">
                  Ships to: {{ org.operatingCountries.join(', ') }}
                </div>
              </div>

              <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span class="text-xs text-slate-500 tabular-nums">
                  {{ supplierOffers(org.id).length }} active offers
                </span>
                <a
                  [routerLink]="['/suppliers', org.id]"
                  class="px-3.5 py-1.5 rounded-lg border border-[#0066CC] text-[#00449E] hover:bg-[#00449E] hover:text-white text-xs font-semibold transition-colors"
                >
                  Open storefront
                </a>
              </div>
            </article>
          }
        </div>
      }
    </div>
  `,
})
export class SuppliersPage {
  readonly store = inject(MarketplaceStore);
  private readonly route = inject(ActivatedRoute);

  readonly supplierId = signal<string | null>(null);

  constructor() {
    this.route.paramMap.subscribe((p) => {
      this.supplierId.set(p.get('id'));
    });
  }

  readonly sellerOrganisations = computed(() =>
    this.store.organisations().filter((o) => o.kind !== 'buyer'),
  );

  readonly selectedSupplier = computed(() => {
    const id = this.supplierId();
    if (!id) return null;
    return this.store.organisations().find((o) => o.id === id) ?? null;
  });

  supplierOffers(orgId: string) {
    return this.store
      .enrichedOffers()
      .filter((e) => e.offer.sellerOrgId === orgId && e.product);
  }
}
