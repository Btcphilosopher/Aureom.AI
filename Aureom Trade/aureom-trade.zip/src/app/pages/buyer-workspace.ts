import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore, PERSONA_PRESETS} from '../core/marketplace.store';

@Component({
  selector: 'app-buyer-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            Buyer Procurement Workspace — {{ store.activeOrg().tradingName }}
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Active role: <strong>{{ store.activePersona().name }} ({{ store.activePersona().roleLabel }})</strong> ·
            Approval threshold: {{ store.formatExactCurrency(store.activeOrg().approvalThresholdMinor, 'USD') }}
          </p>
        </div>

        <div class="flex flex-wrap gap-2">
          <button
            type="button"
            (click)="switchToApprover()"
            class="h-9 px-3.5 rounded-lg border border-slate-300 bg-white hover:border-[#0066CC] text-xs font-semibold text-slate-800 flex items-center gap-1.5"
          >
            <mat-icon class="text-[16px] text-[#00449E]">verified</mat-icon>
            <span>Act as Approver (Marcus)</span>
          </button>
          <a
            routerLink="/rfqs"
            [queryParams]="{new: 1}"
            class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-xs font-semibold flex items-center gap-1.5"
          >
            <mat-icon class="text-[16px]">add</mat-icon>
            <span>New RFQ</span>
          </a>
        </div>
      </div>

      <!-- KPI Strip -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl p-4">
          <div class="text-xs text-slate-500">Shortlisted Offers</div>
          <div class="font-display font-bold text-2xl text-slate-900 tabular-nums mt-1">
            {{ store.shortlistOfferIds().length }}
          </div>
          <a routerLink="/compare" class="text-xs font-semibold text-[#00449E] hover:underline mt-1 inline-block">
            Compare landed cost
          </a>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl p-4">
          <div class="text-xs text-slate-500">Open RFQs</div>
          <div class="font-display font-bold text-2xl text-slate-900 tabular-nums mt-1">
            {{ store.rfqs().length }}
          </div>
          <a routerLink="/rfqs" class="text-xs font-semibold text-[#00449E] hover:underline mt-1 inline-block">
            Review quotations
          </a>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl p-4">
          <div class="text-xs text-slate-500">Awaiting Approval</div>
          <div class="font-display font-bold text-2xl text-amber-700 tabular-nums mt-1">
            {{ pendingApprovalOrders().length }}
          </div>
          <span class="text-xs text-slate-500 mt-1 inline-block">Procurement gate</span>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl p-4">
          <div class="text-xs text-slate-500">Active Orders & Invoices</div>
          <div class="font-display font-bold text-2xl text-slate-900 tabular-nums mt-1">
            {{ store.orders().length }} / {{ store.invoices().length }}
          </div>
          <a routerLink="/orders" class="text-xs font-semibold text-[#00449E] hover:underline mt-1 inline-block">
            Track orders & logistics
          </a>
        </div>
      </div>

      <!-- Pending Approvals Queue -->
      <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <h2 class="font-display font-bold text-lg text-slate-900">
              Internal Procurement Approval Queue
            </h2>
            <p class="text-xs text-slate-500">
              Orders exceeding {{ store.formatExactCurrency(store.activeOrg().approvalThresholdMinor, 'USD') }} require sign-off by a Procurement Approver before stock allocation.
            </p>
          </div>
        </div>

        @if (pendingApprovalOrders().length === 0) {
          <div class="p-4 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
            No orders currently awaiting procurement approval. Award RFQ-2026-041 or submit a large basket order to trigger the approval rule.
          </div>
        } @else {
          <div class="space-y-3">
            @for (ord of pendingApprovalOrders(); track ord.id) {
              <div class="border border-amber-200 bg-amber-50/40 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="space-y-1">
                  <div class="flex items-center gap-2 text-xs">
                    <span class="font-mono font-bold text-slate-900">{{ ord.id }}</span>
                    <span class="text-amber-800 font-semibold">Awaiting Approval</span>
                    <span>·</span>
                    <span>{{ ord.businessUnit }}</span>
                  </div>
                  <div class="text-sm font-semibold text-slate-900">
                    {{ ord.sellerName }} — {{ ord.lines[0].productName }} ({{ ord.lines[0].casesOrdered }} cases)
                  </div>
                  <div class="text-xs text-slate-600">
                    {{ ord.approval.reason }} · Total:
                    <strong class="tabular-nums">{{ store.formatExactCurrency(ord.totalMinor, ord.orderCurrency) }}</strong>
                  </div>
                </div>

                <div class="flex items-center gap-2 shrink-0">
                  @if (canApprove()) {
                    <button
                      type="button"
                      (click)="store.approveOrder(ord.id, false, 'Declined in buyer workspace')"
                      class="h-9 px-3 rounded-lg border border-red-300 text-red-700 hover:bg-red-50 text-xs font-semibold"
                    >
                      Reject
                    </button>
                    <button
                      type="button"
                      (click)="store.approveOrder(ord.id, true, 'Approved by UK Procurement Approver')"
                      class="h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1"
                    >
                      <mat-icon class="text-[16px]">check</mat-icon>
                      <span>Approve & Reserve Stock</span>
                    </button>
                  } @else {
                    <button
                      type="button"
                      (click)="switchToApprover()"
                      class="h-9 px-3.5 rounded-lg bg-[#00449E] text-white text-xs font-semibold"
                    >
                      Switch to Procurement Approver to sign off
                    </button>
                  }
                </div>
              </div>
            }
          </div>
        }
      </section>

      <!-- UK Buyer End-to-End Demonstration Walkthrough Tracker -->
      <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div>
          <h2 class="font-display font-bold text-lg text-slate-900">
            UK Buyer End-to-End Demonstration Checklist (Albion Retail Group)
          </h2>
          <p class="text-xs text-slate-600">
            Live workflow verification connected directly to the underlying database records.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          @for (step of demoSteps(); track step.label; let i = $index) {
            <a
              [routerLink]="step.link"
              class="p-3 rounded-lg border transition-colors flex items-start gap-2.5"
              [class.bg-emerald-50/50]="step.done"
              [class.border-emerald-200]="step.done"
              [class.bg-slate-50]="!step.done"
              [class.border-slate-200]="!step.done"
            >
              <mat-icon
                class="text-[18px] shrink-0 mt-0.5"
                [class.text-emerald-600]="step.done"
                [class.text-slate-400]="!step.done"
              >
                {{ step.done ? 'check_circle' : 'radio_button_unchecked' }}
              </mat-icon>
              <div>
                <div class="font-semibold text-slate-900">{{ i + 1 }}. {{ step.label }}</div>
                <div class="text-slate-500 mt-0.5">{{ step.detail }}</div>
              </div>
            </a>
          }
        </div>
      </section>
    </div>
  `,
})
export class BuyerWorkspacePage {
  readonly store = inject(MarketplaceStore);

  readonly pendingApprovalOrders = computed(() =>
    this.store.orders().filter((o) => o.status === 'Awaiting Approval'),
  );

  readonly canApprove = computed(() => {
    const role = this.store.activePersona().role;
    return role === 'procurement_approver' || role === 'org_admin' || role === 'platform_admin';
  });

  readonly demoSteps = computed(() => {
    const rfq041 = this.store.rfqs().find((r) => r.id === 'RFQ-2026-041');
    const orders = this.store.orders();
    const shipments = this.store.shipments();
    const invoices = this.store.invoices();

    const hasAwarded = rfq041?.status === 'Awarded' || orders.length > 0;
    const hasApproved = orders.some(
      (o) =>
        o.status === 'Allocated' ||
        o.status === 'Partially Dispatched' ||
        o.status === 'Dispatched' ||
        o.status === 'Delivered' ||
        o.status === 'Disputed',
    );
    const hasPayment = invoices.some((i) => i.payments.length > 0);
    const hasPartialShipment = shipments.length > 0;
    const hasDiscrepancy = shipments.some((s) => s.discrepancies.length > 0);
    const hasCreditNote = invoices.some((i) => i.creditNotes.length > 0);

    return [
      {
        label: 'Filter suppliers for United Kingdom',
        detail: '6 consumer goods offers matched to UK destination',
        done: true,
        link: '/',
      },
      {
        label: 'Compare case & unit landed prices',
        detail: `${this.store.shortlistOfferIds().length} offers shortlisted`,
        done: this.store.shortlistOfferIds().length > 0,
        link: '/compare',
      },
      {
        label: 'RFQ-2026-041 with 2 supplier quotes',
        detail: `${rfq041?.quotes.length ?? 0} quotes received`,
        done: (rfq041?.quotes.length ?? 0) >= 2,
        link: '/rfqs',
      },
      {
        label: 'Award RFQ & generate order',
        detail: hasAwarded ? 'Order created from quote snapshot' : 'Click Award on RFQ-2026-041',
        done: hasAwarded,
        link: '/rfqs',
      },
      {
        label: 'Obtain internal procurement approval',
        detail: hasApproved ? 'Approved & stock atomically reserved' : 'Approve held order as Marcus Vance',
        done: hasApproved,
        link: '/buyer',
      },
      {
        label: 'Record simulated bank transfer',
        detail: hasPayment ? 'Idempotent payment allocated' : 'Pay invoice in Invoices & Payments',
        done: hasPayment,
        link: '/invoices',
      },
      {
        label: 'Dispatch partial shipment (Seller)',
        detail: hasPartialShipment ? 'Shipment in transit / delivered' : 'Switch to Owen Davies & dispatch',
        done: hasPartialShipment,
        link: '/seller',
      },
      {
        label: 'Record discrepancy & credit note',
        detail: hasDiscrepancy && hasCreditNote ? 'Shortage/damage logged & credit issued' : 'Record delivery on Shipment',
        done: hasDiscrepancy && hasCreditNote,
        link: '/orders',
      },
    ];
  });

  async switchToApprover(): Promise<void> {
    const approver = PERSONA_PRESETS.find((p) => p.role === 'procurement_approver')!;
    await this.store.switchPersona(approver);
  }
}
