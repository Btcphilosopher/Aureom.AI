import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {ActivatedRoute, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {Offer, PackagingConfig, TransportMode} from '../core/models';

@Component({
  selector: 'app-product-detail',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <!-- Breadcrumb -->
      <nav class="flex items-center gap-2 text-xs text-slate-500">
        <a routerLink="/" class="hover:text-[#00449E]">Marketplace</a>
        <span>/</span>
        @if (product(); as prod) {
          <span>{{ prod.category }}</span>
          <span>/</span>
          <span class="text-slate-800 font-medium">{{ prod.name }}</span>
        }
      </nav>

      @if (product(); as prod) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <!-- Left: Product Visual & Spec Card -->
          <div class="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-5">
            <div class="aspect-square rounded-xl bg-slate-50 border border-slate-100 p-6 flex items-center justify-center">
              <img
                [src]="prod.imageUrl"
                [alt]="prod.name"
                referrerpolicy="no-referrer"
                class="max-h-80 w-auto object-contain"
              />
            </div>

            <div class="space-y-3 pt-2 border-t border-slate-100">
              <div class="flex items-center justify-between text-xs text-slate-500">
                <span>Brand: <strong class="text-slate-800">{{ prod.brand }}</strong></span>
                <span class="font-mono">SKU: {{ prod.sku }}</span>
              </div>
              <h1 class="font-display font-bold text-2xl text-slate-900">{{ prod.name }}</h1>
              <p class="text-sm text-slate-600 leading-relaxed">{{ prod.description }}</p>

              <dl class="grid grid-cols-2 gap-3 pt-2 text-xs">
                <div class="bg-slate-50 rounded-lg p-2.5">
                  <dt class="text-slate-500">GTIN / Barcode</dt>
                  <dd class="font-mono font-semibold text-slate-800 mt-0.5">{{ prod.gtin }}</dd>
                </div>
                <div class="bg-slate-50 rounded-lg p-2.5">
                  <dt class="text-slate-500">Commodity HS Code</dt>
                  <dd class="font-mono font-semibold text-slate-800 mt-0.5">{{ prod.commodityCode }}</dd>
                </div>
                <div class="bg-slate-50 rounded-lg p-2.5">
                  <dt class="text-slate-500">Shelf Life</dt>
                  <dd class="font-semibold text-slate-800 mt-0.5 tabular-nums">{{ prod.shelfLifeDays }} days</dd>
                </div>
                <div class="bg-slate-50 rounded-lg p-2.5">
                  <dt class="text-slate-500">Current Pack Version</dt>
                  <dd class="font-semibold text-slate-800 mt-0.5 tabular-nums">v{{ prod.currentPackagingVersion }}</dd>
                </div>
              </dl>

              <div class="pt-2 border-t border-slate-100 text-xs space-y-1">
                <div class="font-semibold text-slate-700">Ingredients / Materials</div>
                <p class="text-slate-600 leading-relaxed">{{ prod.ingredientsOrMaterials }}</p>
              </div>
            </div>

            <!-- Handling Documents -->
            <div class="pt-3 border-t border-slate-100 space-y-2">
              <div class="text-xs font-semibold text-slate-800">Handling & Compliance Documents</div>
              @if (productDocs().length === 0) {
                <p class="text-xs text-slate-500">No public handling sheets uploaded; request via RFQ.</p>
              } @else {
                @for (doc of productDocs(); track doc.id) {
                  <div class="p-2.5 rounded-lg border border-slate-200 bg-slate-50/70 text-xs space-y-1">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-semibold text-slate-800">{{ doc.title }}</span>
                      <span class="text-slate-500 tabular-nums">v{{ doc.version }}</span>
                    </div>
                    <div class="text-slate-500">Issuer: {{ doc.issuer }}</div>
                    <p class="text-slate-600">{{ doc.summary }}</p>
                  </div>
                }
              }
            </div>
          </div>

          <!-- Right: Packaging Converter + Seller Offers -->
          <div class="lg:col-span-7 space-y-5">
            <!-- Packaging & Logistics Converter -->
            @if (activePkg(); as pkg) {
              <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h2 class="font-display font-bold text-base text-slate-900">
                      Packaging & Quantity Breakdown (v{{ pkg.version }})
                    </h2>
                    <p class="text-xs text-slate-500">
                      Explicit unit, inner-pack, case, and pallet conversions · Effective {{ pkg.effectiveFrom.slice(0, 10) }}
                    </p>
                  </div>
                  <div class="flex items-center gap-2">
                    <label for="case-calc-input" class="text-xs font-medium text-slate-600">Cases:</label>
                    <input
                      id="case-calc-input"
                      type="number"
                      min="1"
                      [value]="caseQuantity()"
                      (input)="onCaseQtyInput($event)"
                      class="w-24 h-9 px-2.5 text-sm border border-slate-300 rounded-lg tabular-nums font-semibold"
                    />
                  </div>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div class="bg-[#F5F8FD] border border-blue-100 rounded-lg p-3">
                    <div class="text-slate-500">Individual Units</div>
                    <div class="text-base font-bold text-slate-900 tabular-nums mt-0.5">
                      {{ (caseQuantity() * pkg.unitsPerInnerPack * pkg.innerPacksPerCase).toLocaleString() }}
                    </div>
                    <div class="text-slate-500">{{ pkg.unitVolumeLabel }} each</div>
                  </div>
                  <div class="bg-[#F5F8FD] border border-blue-100 rounded-lg p-3">
                    <div class="text-slate-500">Inner Packs</div>
                    <div class="text-base font-bold text-slate-900 tabular-nums mt-0.5">
                      {{ (caseQuantity() * pkg.innerPacksPerCase).toLocaleString() }}
                    </div>
                    <div class="text-slate-500">{{ pkg.unitsPerInnerPack }} units / pack</div>
                  </div>
                  <div class="bg-[#F5F8FD] border border-blue-100 rounded-lg p-3">
                    <div class="text-slate-500">Pallets</div>
                    <div class="text-base font-bold text-slate-900 tabular-nums mt-0.5">
                      {{ (caseQuantity() / pkg.casesPerPallet).toFixed(2) }}
                    </div>
                    <div class="text-slate-500">{{ pkg.casesPerPallet }} cases / pallet</div>
                  </div>
                  <div class="bg-[#F5F8FD] border border-blue-100 rounded-lg p-3">
                    <div class="text-slate-500">Shipping Weight</div>
                    <div class="text-base font-bold text-slate-900 tabular-nums mt-0.5">
                      {{ (caseQuantity() * pkg.grossShippingWeightKgPerCase).toFixed(1) }} kg
                    </div>
                    <div class="text-slate-500">
                      Net {{ (caseQuantity() * pkg.netWeightKgPerCase).toFixed(1) }} kg ·
                      {{ pkg.caseDimensionsCm.l }}×{{ pkg.caseDimensionsCm.w }}×{{ pkg.caseDimensionsCm.h }} cm
                    </div>
                  </div>
                </div>
              </section>
            }

            <!-- Seller Offers for this Product -->
            <section class="space-y-4">
              <div class="flex items-center justify-between">
                <h2 class="font-display font-bold text-lg text-slate-900">
                  Wholesale Seller Offers ({{ productOffers().length }})
                </h2>
                <a
                  routerLink="/compare"
                  class="text-xs font-semibold text-[#00449E] hover:underline flex items-center gap-1"
                >
                  <mat-icon class="text-[16px]">compare_arrows</mat-icon>
                  <span>Compare landed cost</span>
                </a>
              </div>

              @for (entry of productOffers(); track entry.offer.id) {
                <div
                  class="bg-white border rounded-xl p-5 space-y-4 transition-all"
                  [class.border-[#0066CC]]="highlightedOfferId() === entry.offer.id"
                  [class.ring-2]="highlightedOfferId() === entry.offer.id"
                  [class.ring-blue-100]="highlightedOfferId() === entry.offer.id"
                  [class.border-slate-200]="highlightedOfferId() !== entry.offer.id"
                >
                  <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div class="space-y-1">
                      <div class="flex items-center flex-wrap gap-2">
                        <a
                          [routerLink]="['/suppliers', entry.seller!.id]"
                          class="font-display font-bold text-base text-slate-900 hover:text-[#00449E]"
                        >
                          {{ entry.seller!.tradingName }}
                        </a>
                        @if (entry.seller!.kind === 'first_party') {
                          <span class="text-[11px] font-semibold text-[#00449E] bg-blue-50 px-2 py-0.5 rounded">
                            First-party supply
                          </span>
                        }
                        @if (entry.seller!.verification.status === 'verified') {
                          <span class="inline-flex items-center gap-1 text-xs font-medium text-emerald-700">
                            <mat-icon class="text-[15px]">check_circle</mat-icon>
                            <span>Verified business</span>
                          </span>
                        } @else {
                          <span class="inline-flex items-center gap-1 text-xs font-medium text-amber-700">
                            <mat-icon class="text-[15px]">warning_amber</mat-icon>
                            <span>{{ entry.seller!.verification.notes }}</span>
                          </span>
                        }
                      </div>

                      <div class="text-xs text-slate-600 flex flex-wrap items-center gap-2">
                        <span>{{ store.flagForCountry(entry.offer.dispatchCountryCode) }} Dispatch: {{ entry.offer.dispatchCity }}, {{ entry.offer.dispatchCountry }}</span>
                        <span>·</span>
                        <span>{{ entry.offer.incoterm }} ({{ entry.offer.incotermEdition }}) — {{ entry.offer.namedPlace }}</span>
                        <span>·</span>
                        <span>Lead time: {{ entry.offer.leadTimeDays }} days</span>
                      </div>

                      <div class="text-[11px] text-slate-500">
                        Availability: <strong class="text-slate-700 tabular-nums">{{ entry.offer.availableCases.toLocaleString() }} cases</strong>
                        ({{ entry.offer.availabilitySource === 'platform_managed' ? 'Platform-managed stock' : 'Supplier-reported stock' }}, updated {{ entry.offer.availabilityUpdatedAt.slice(0, 10) }})
                      </div>
                    </div>

                    <div class="text-left sm:text-right shrink-0">
                      <div class="font-display font-bold text-xl text-slate-900 tabular-nums">
                        {{ store.formatPriceMinor(activeTierPrice(entry.offer), entry.offer.currency) }}
                        <span class="text-xs font-normal text-slate-500">/ case</span>
                      </div>
                      <div class="text-xs text-slate-500 tabular-nums">
                        {{ entry.pkg.casePackSummary }} · MOQ {{ entry.offer.moqCases }} · +{{ entry.offer.orderIncrementCases }} step
                      </div>
                      <div class="text-[11px] text-slate-500">
                        Payment: {{ entry.offer.paymentTerms }} · Expires {{ entry.offer.offerExpiresAt.slice(0, 10) }}
                      </div>
                    </div>
                  </div>

                  <!-- Tiered Pricing Table -->
                  <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100">
                    @for (tier of entry.offer.tiers; track tier.minCases) {
                      <div class="rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2 text-xs flex items-center justify-between">
                        <span class="text-slate-600 tabular-nums">
                          {{ tier.minCases }}{{ tier.maxCases ? '–' + tier.maxCases : '+' }} cases
                        </span>
                        <span class="font-semibold text-slate-900 tabular-nums">
                          {{ store.formatPriceMinor(tier.unitPriceMinorPerCase, entry.offer.currency) }}
                        </span>
                      </div>
                    }
                  </div>

                  @if (validationMessage(entry.offer); as errMsg) {
                    <div class="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 flex items-center gap-2">
                      <mat-icon class="text-[16px] text-amber-600">info</mat-icon>
                      <span>{{ errMsg }}</span>
                    </div>
                  }

                  <div class="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
                    <div class="text-xs text-slate-600">
                      Permitted destinations: {{ entry.offer.permittedDestinations.join(', ') }}
                    </div>
                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        (click)="store.toggleShortlist(entry.offer.id)"
                        class="h-9 px-3 rounded-lg border border-slate-300 hover:border-[#0066CC] text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                      >
                        <mat-icon class="text-[16px]">
                          {{ store.shortlistOfferIds().includes(entry.offer.id) ? 'bookmark' : 'bookmark_border' }}
                        </mat-icon>
                        <span>{{ store.shortlistOfferIds().includes(entry.offer.id) ? 'Shortlisted' : 'Shortlist' }}</span>
                      </button>

                      <button
                        type="button"
                        [disabled]="validationMessage(entry.offer) !== null"
                        (click)="addOfferToBasket(entry.offer)"
                        class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] disabled:opacity-45 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <mat-icon class="text-[16px]">add_shopping_cart</mat-icon>
                        <span>Add {{ caseQuantity() }} cases to basket</span>
                      </button>
                    </div>
                  </div>
                </div>
              }
            </section>
          </div>
        </div>
      } @else {
        <div class="bg-white border border-slate-200 rounded-xl p-8 text-center">
          <p class="text-sm text-slate-600">Loading product specification...</p>
        </div>
      }
    </div>
  `,
})
export class ProductDetail {
  readonly store = inject(MarketplaceStore);
  private readonly route = inject(ActivatedRoute);

  readonly productId = signal<string>('');
  readonly highlightedOfferId = signal<string | null>(null);
  readonly caseQuantity = signal<number>(100);

  constructor() {
    this.route.paramMap.subscribe((p) => {
      this.productId.set(p.get('id') ?? '');
    });
    this.route.queryParamMap.subscribe((q) => {
      this.highlightedOfferId.set(q.get('offer'));
    });
  }

  readonly product = computed(() =>
    this.store.products().find((p) => p.id === this.productId()),
  );

  readonly productOffers = computed(() =>
    this.store
      .enrichedOffers()
      .filter((e) => e.offer.productId === this.productId() && e.seller && e.pkg)
      .map((e) => ({
        offer: e.offer,
        seller: e.seller!,
        pkg: e.pkg!,
      })),
  );

  readonly activePkg = computed<PackagingConfig | null>(() => {
    const prod = this.product();
    if (!prod) return null;
    return (
      prod.packagingVersions.find((v) => v.version === prod.currentPackagingVersion) ??
      prod.packagingVersions[0]
    );
  });

  readonly productDocs = computed(() =>
    this.store
      .documents()
      .filter(
        (d) =>
          d.linkedEntityType === 'product' && d.linkedEntityId === this.productId(),
      ),
  );

  onCaseQtyInput(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    if (Number.isFinite(val) && val > 0) {
      this.caseQuantity.set(Math.floor(val));
    }
  }

  activeTierPrice(offer: Offer): number {
    const cases = this.caseQuantity();
    const sorted = [...offer.tiers].sort((a, b) => a.minCases - b.minCases);
    let price = sorted[0].unitPriceMinorPerCase;
    for (const t of sorted) {
      if (cases >= t.minCases && (t.maxCases === null || cases <= t.maxCases)) {
        price = t.unitPriceMinorPerCase;
      }
    }
    return price;
  }

  validationMessage(offer: Offer): string | null {
    const qty = this.caseQuantity();
    if (qty < offer.moqCases) {
      return `Minimum order for this offer is ${offer.moqCases} cases (currently ${qty}).`;
    }
    if ((qty - offer.moqCases) % offer.orderIncrementCases !== 0) {
      return `Must be ordered in increments of ${offer.orderIncrementCases} cases above MOQ ${offer.moqCases}.`;
    }
    if (qty > offer.availableCases) {
      return `Requested ${qty} cases exceeds available stock (${offer.availableCases} cases).`;
    }
    return null;
  }

  addOfferToBasket(offer: Offer): void {
    const mode: TransportMode = offer.transportModes[0] ?? 'road';
    this.store.addToCart({
      offerId: offer.id,
      cases: this.caseQuantity(),
      transportMode: mode,
    });
  }
}
