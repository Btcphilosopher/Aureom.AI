import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {ActivatedRoute, Router, RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {
  Incoterm,
  ProductCategory,
  SupplierRegion,
} from '../core/models';

@Component({
  selector: 'app-marketplace-home',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-5 space-y-5">
      <!-- Hero Banner matching mockup -->
      <section
        class="relative rounded-2xl overflow-hidden text-white shadow-sm"
        style="background: linear-gradient(122deg, #003A9B 0%, #006CE0 54%, #00C2EC 100%);"
      >
        <!-- Subtle geometric globe lines on left -->
        <svg
          class="absolute inset-y-0 left-0 w-[56%] h-full opacity-20 pointer-events-none"
          viewBox="0 0 600 320"
          preserveAspectRatio="xMidYMid slice"
          aria-hidden="true"
        >
          <circle cx="330" cy="160" r="145" fill="none" stroke="#FFFFFF" stroke-width="1.4" />
          <ellipse cx="330" cy="160" rx="85" ry="145" fill="none" stroke="#FFFFFF" stroke-width="1.2" />
          <ellipse cx="330" cy="160" rx="35" ry="145" fill="none" stroke="#FFFFFF" stroke-width="1" />
          <path d="M185 115 Q330 145 475 115 M185 205 Q330 175 475 205 M185 160 L475 160" fill="none" stroke="#FFFFFF" stroke-width="1.2" />
        </svg>

        <div class="relative grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div class="lg:col-span-7 px-6 sm:px-10 py-8 sm:py-11 flex flex-col justify-center z-10">
            <h1 class="font-display font-bold text-3xl sm:text-[38px] leading-[1.14] tracking-tight max-w-xl" style="text-wrap: balance;">
              The world’s everyday essentials.<br />
              One connected marketplace.
            </h1>
            <p class="mt-3 text-base sm:text-[17px] text-blue-50/95 font-normal">
              Source wholesale. Compare suppliers. Trade with confidence.
            </p>
            <div class="mt-6 flex flex-wrap items-center gap-3">
              <button
                type="button"
                (click)="scrollToCatalog()"
                class="px-6 py-2.5 rounded-lg bg-white text-[#003E9C] font-semibold text-sm hover:bg-blue-50 transition-colors shadow-sm whitespace-nowrap shrink-0 flex items-center gap-1.5"
              >
                <mat-icon class="text-[18px]">storefront</mat-icon>
                <span>Explore products</span>
              </button>
              <a
                routerLink="/rfqs"
                [queryParams]="{new: 1}"
                class="px-6 py-2.5 rounded-lg border border-white/80 text-white font-semibold text-sm hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
              >
                <mat-icon class="text-[18px]">request_quote</mat-icon>
                <span>Request a quote</span>
              </a>
            </div>
          </div>

          <div class="hidden lg:block lg:col-span-5 relative min-h-[260px]">
            <img
              src="/src/assets/images/hero_wholesale_lineup_1794733139725.jpg"
              alt="Wholesale consumer essentials lineup including body wash, laundry detergent, cooking oil, facial tissues, and oat cereal"
              referrerpolicy="no-referrer"
              class="w-full h-full object-cover object-right"
            />
            <div
              class="absolute inset-y-0 left-0 w-24 pointer-events-none"
              style="background: linear-gradient(90deg, #0077E6 0%, transparent 100%);"
            ></div>
          </div>
        </div>
      </section>

      <!-- Rounded Category Controls matching mockup -->
      <section aria-label="Product categories" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        @for (cat of categories; track cat.name) {
          <button
            type="button"
            (click)="toggleCategory(cat.name)"
            class="h-12 px-4 rounded-full border text-sm font-medium flex items-center justify-center gap-2 transition-all whitespace-nowrap"
            [class.bg-[#EAF4FF]]="selectedCategory() === cat.name"
            [class.border-[#0066CC]]="selectedCategory() === cat.name"
            [class.text-[#003E9C]]="selectedCategory() === cat.name"
            [class.bg-white]="selectedCategory() !== cat.name"
            [class.border-slate-200]="selectedCategory() !== cat.name"
            [class.text-slate-700]="selectedCategory() !== cat.name"
            [class.hover:border-[#0066CC]]="selectedCategory() !== cat.name"
          >
            <mat-icon class="text-[20px] text-[#0066CC]">{{ cat.icon }}</mat-icon>
            <span class="truncate">{{ cat.name }}</span>
          </button>
        }
      </section>

      <!-- Mobile Filter & Sourcing Workspace bar -->
      <div class="flex lg:hidden items-center justify-between gap-3">
        <button
          type="button"
          (click)="mobileFiltersOpen.set(true)"
          class="flex-1 h-11 px-4 rounded-xl bg-white border border-slate-200 text-sm font-semibold text-slate-800 flex items-center justify-center gap-2"
        >
          <mat-icon class="text-[19px] text-[#0055B8]">tune</mat-icon>
          <span>Filters</span>
        </button>
        <button
          type="button"
          (click)="mobileWorkspaceOpen.set(true)"
          class="flex-1 h-11 px-4 rounded-xl bg-[#0A224E] text-white text-sm font-semibold flex items-center justify-center gap-2"
        >
          <mat-icon class="text-[19px] text-cyan-300">work_outline</mat-icon>
          <span>Sourcing workspace ({{ store.shortlistOfferIds().length }})</span>
        </button>
      </div>

      <!-- 3-Column Marketplace Main Grid -->
      <div id="wholesale-catalogue" class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        <!-- Left Sidebar: Refine your sourcing -->
        <aside class="hidden lg:block lg:col-span-3 xl:col-span-2 bg-white border border-slate-200 rounded-xl p-4 space-y-5">
          <div class="flex items-center justify-between">
            <h2 class="font-display font-bold text-base text-slate-900">Refine your sourcing</h2>
            @if (hasActiveFilters()) {
              <button
                type="button"
                (click)="resetFilters()"
                class="text-xs font-medium text-[#0055B8] hover:underline"
              >
                Reset
              </button>
            }
          </div>

          <!-- Ship to -->
          <div class="space-y-1.5">
            <label for="ship-to-select" class="block text-xs font-semibold text-slate-700">
              Ship to:
            </label>
            <select
              id="ship-to-select"
              [value]="store.selectedDestination()"
              (change)="onDestinationChange($event)"
              class="w-full h-10 px-3 text-sm bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-[#0066CC]"
            >
              @for (dest of destinations; track dest) {
                <option [value]="dest">{{ dest }}</option>
              }
            </select>
          </div>

          <!-- Supplier region -->
          <div class="space-y-2 pt-3 border-t border-slate-100">
            <div class="text-xs font-semibold text-slate-700">Supplier region</div>
            @for (reg of regions; track reg) {
              <label class="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  [checked]="selectedRegions().includes(reg)"
                  (change)="toggleRegion(reg)"
                  class="w-4 h-4 rounded border-slate-300 text-[#00449E] focus:ring-[#0066CC]"
                />
                <span>{{ reg }}</span>
              </label>
            }
          </div>

          <!-- Trade terms -->
          <div class="space-y-2 pt-3 border-t border-slate-100">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-slate-700">Trade terms</span>
              <span
                title="Incoterms 2020 define responsibility for main freight, cargo insurance, and import customs clearance."
                class="text-slate-400 cursor-help flex items-center"
              >
                <mat-icon class="text-[15px]">info_outline</mat-icon>
              </span>
            </div>
            @for (term of tradeTerms; track term) {
              <label class="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  [checked]="selectedTerms().includes(term)"
                  (change)="toggleTerm(term)"
                  class="w-4 h-4 rounded border-slate-300 text-[#00449E] focus:ring-[#0066CC]"
                />
                <span>{{ term }}</span>
              </label>
            }
          </div>

          <!-- Minimum order -->
          <div class="space-y-1.5 pt-3 border-t border-slate-100">
            <label for="moq-max-input" class="block text-xs font-semibold text-slate-700">
              Minimum order (max)
            </label>
            <div class="flex items-center gap-1.5">
              <input
                id="moq-max-input"
                type="number"
                min="1"
                [value]="maxMoqInput()"
                (input)="onMaxMoqInput($event)"
                placeholder="e.g. 40"
                class="w-24 h-9 px-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0066CC] tabular-nums"
              />
              <select
                [value]="moqUnit()"
                (change)="onMoqUnitChange($event)"
                aria-label="Minimum order unit"
                class="flex-1 h-9 px-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                <option value="cases">cases</option>
                <option value="pallets">pallets</option>
              </select>
            </div>
          </div>

          <!-- Verified business -->
          <div class="pt-3 border-t border-slate-100">
            <label class="flex items-center gap-2 text-sm font-medium text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                [checked]="verifiedOnly()"
                (change)="verifiedOnly.set(!verifiedOnly())"
                class="w-4 h-4 rounded border-slate-300 text-[#00449E] focus:ring-[#0066CC]"
              />
              <mat-icon class="text-[18px] text-emerald-600">check_circle</mat-icon>
              <span>Verified business</span>
            </label>
            <p class="mt-1.5 text-[11px] text-slate-500 leading-snug">
              Simulated registry check only; not a guarantee of product quality or solvency.
            </p>
          </div>
        </aside>

        <!-- Center Catalogue Grid: Wholesale essentials -->
        <main class="lg:col-span-6 xl:col-span-7 space-y-4">
          <div class="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
            <h2 class="font-display font-bold text-xl text-slate-900">
              Wholesale essentials
              @if (selectedCategory()) {
                <span class="text-sm font-normal text-[#0055B8]"> · {{ selectedCategory() }}</span>
              }
            </h2>
            <p class="text-xs text-slate-500">
              Indicative prices · Freight and duties quoted separately
            </p>
          </div>

          <!-- Tabs matching mockup -->
          <div class="flex items-center gap-6 border-b border-slate-200 text-sm">
            <button
              type="button"
              (click)="activeTab.set('recommended')"
              class="pb-2.5 font-semibold border-b-2 transition-colors whitespace-nowrap"
              [class.border-[#00449E]]="activeTab() === 'recommended'"
              [class.text-[#00449E]]="activeTab() === 'recommended'"
              [class.border-transparent]="activeTab() !== 'recommended'"
              [class.text-slate-600]="activeTab() !== 'recommended'"
            >
              Recommended
            </button>
            <button
              type="button"
              (click)="activeTab.set('recent')"
              class="pb-2.5 font-semibold border-b-2 transition-colors whitespace-nowrap"
              [class.border-[#00449E]]="activeTab() === 'recent'"
              [class.text-[#00449E]]="activeTab() === 'recent'"
              [class.border-transparent]="activeTab() !== 'recent'"
              [class.text-slate-600]="activeTab() !== 'recent'"
            >
              Recently listed
            </button>
            <button
              type="button"
              (click)="activeTab.set('rfqs')"
              class="pb-2.5 font-semibold border-b-2 transition-colors whitespace-nowrap"
              [class.border-[#00449E]]="activeTab() === 'rfqs'"
              [class.text-[#00449E]]="activeTab() === 'rfqs'"
              [class.border-transparent]="activeTab() !== 'rfqs'"
              [class.text-slate-600]="activeTab() !== 'rfqs'"
            >
              RFQ opportunities ({{ store.rfqs().length }})
            </button>
          </div>

          @if (activeTab() !== 'rfqs') {
            @if (filteredOffers().length === 0) {
              <div class="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3">
                <mat-icon class="text-[36px] text-slate-400">inventory_2</mat-icon>
                <div class="text-base font-semibold text-slate-800">
                  No wholesale offers match your current filters
                </div>
                <p class="text-sm text-slate-500">
                  Try clearing destination or minimum order filters, or request a custom quotation from verified suppliers.
                </p>
                <div class="flex justify-center gap-3 pt-1">
                  <button
                    type="button"
                    (click)="resetFilters()"
                    class="px-4 py-2 text-sm font-medium border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    Reset filters
                  </button>
                  <a
                    routerLink="/rfqs"
                    [queryParams]="{new: 1}"
                    class="px-4 py-2 text-sm font-semibold bg-[#00449E] text-white rounded-lg hover:bg-[#00357E]"
                  >
                    Create an RFQ
                  </a>
                </div>
              </div>
            } @else {
              <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3.5">
                @for (item of filteredOffers(); track item.offer.id) {
                  <article class="bg-white border border-slate-200 rounded-xl p-3.5 hover:shadow-md hover:-translate-y-0.5 transition-all flex flex-col justify-between gap-3">
                    <div class="flex items-start gap-3">
                      <a
                        [routerLink]="['/products', item.product!.id]"
                        class="w-20 h-24 shrink-0 rounded-lg bg-slate-50 border border-slate-100 overflow-hidden flex items-center justify-center p-1"
                      >
                        <img
                          [src]="item.product!.imageUrl"
                          [alt]="item.product!.name"
                          referrerpolicy="no-referrer"
                          class="w-full h-full object-contain"
                        />
                      </a>

                      <div class="min-w-0 flex-1 space-y-1">
                        <a
                          [routerLink]="['/products', item.product!.id]"
                          class="block font-display font-semibold text-[15px] leading-snug text-slate-900 hover:text-[#00449E] line-clamp-2"
                        >
                          {{ item.product!.name }}
                        </a>

                        <div class="flex items-center flex-wrap gap-1.5 text-xs text-slate-600">
                          <span>{{ store.flagForCountry(item.offer.dispatchCountryCode) }}</span>
                          <span class="truncate max-w-[95px]">{{ item.offer.dispatchCountry }}</span>
                          @if (item.seller?.verification?.status === 'verified') {
                            <span class="inline-flex items-center gap-0.5 text-emerald-700 font-medium">
                              <mat-icon class="text-[14px]">check_circle</mat-icon>
                              <span>Verified</span>
                            </span>
                          } @else {
                            <span class="inline-flex items-center gap-0.5 text-amber-700 font-medium">
                              <mat-icon class="text-[14px]">warning_amber</mat-icon>
                              <span>Review</span>
                            </span>
                          }
                        </div>

                        <div class="pt-0.5 font-display font-bold text-[17px] text-slate-900 tabular-nums">
                          {{ store.formatPriceMinor(item.offer.tiers[0].unitPriceMinorPerCase, item.offer.currency) }}
                          <span class="text-xs font-normal text-slate-600">/ case</span>
                        </div>

                        <div class="text-[11px] text-slate-500 tabular-nums leading-snug">
                          {{ item.pkg?.casePackSummary }} · MOQ {{ item.offer.moqCases }} cases
                        </div>

                        <div class="text-[11px] text-slate-500 flex items-center gap-1">
                          <span>{{ item.offer.incoterm }}</span>
                          <span>·</span>
                          <span>{{ item.offer.leadTimeDays }}d lead</span>
                        </div>
                      </div>
                    </div>

                    <div class="flex items-center gap-2 pt-1 border-t border-slate-100">
                      <a
                        [routerLink]="['/products', item.product!.id]"
                        [queryParams]="{offer: item.offer.id}"
                        class="flex-1 h-9 rounded-lg border border-[#0066CC] text-[#00449E] hover:bg-[#00449E] hover:text-white text-xs font-semibold flex items-center justify-center transition-colors whitespace-nowrap"
                      >
                        View offer
                      </a>
                      <button
                        type="button"
                        (click)="store.toggleShortlist(item.offer.id)"
                        [attr.aria-label]="isShortlisted(item.offer.id) ? 'Remove from shortlist' : 'Shortlist offer'"
                        class="w-9 h-9 rounded-lg border flex items-center justify-center transition-colors shrink-0"
                        [class.border-[#0066CC]]="isShortlisted(item.offer.id)"
                        [class.bg-blue-50]="isShortlisted(item.offer.id)"
                        [class.text-[#00449E]]="isShortlisted(item.offer.id)"
                        [class.border-slate-200]="!isShortlisted(item.offer.id)"
                        [class.text-slate-500]="!isShortlisted(item.offer.id)"
                      >
                        <mat-icon class="text-[18px]">
                          {{ isShortlisted(item.offer.id) ? 'bookmark' : 'bookmark_border' }}
                        </mat-icon>
                      </button>
                    </div>
                  </article>
                }
              </div>
            }
          } @else {
            <!-- RFQ Opportunities Tab -->
            <div class="space-y-3">
              @for (rfq of store.rfqs(); track rfq.id) {
                <div class="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div class="space-y-1">
                    <div class="flex items-center gap-2 text-xs text-slate-500">
                      <span class="font-mono font-semibold text-[#00449E]">{{ rfq.id }}</span>
                      <span>·</span>
                      <span>{{ rfq.buyerName }}</span>
                      <span>·</span>
                      <span class="font-medium text-amber-700">{{ rfq.status }}</span>
                    </div>
                    <div class="font-display font-semibold text-base text-slate-900">
                      {{ rfq.title }}
                    </div>
                    <div class="text-xs text-slate-600 tabular-nums">
                      {{ rfq.lines[0].productName }} · {{ rfq.lines[0].equivalentCases }} cases ·
                      {{ rfq.incoterm }} to {{ rfq.destinationCountry }} · Delivery within {{ rfq.requiredDeliveryDays }} days
                    </div>
                  </div>
                  <a
                    routerLink="/rfqs"
                    class="px-4 py-2 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-xs font-semibold whitespace-nowrap shrink-0 self-start sm:self-center"
                  >
                    Open RFQ & quotes ({{ rfq.quotes.length }})
                  </a>
                </div>
              }
            </div>
          }
        </main>

        <!-- Right Sidebar: Your sourcing desk & Open requests -->
        <aside class="hidden lg:block lg:col-span-3 space-y-4">
          <!-- Your sourcing desk -->
          <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div class="bg-[#0A224E] text-white px-4 py-3 flex items-center gap-2.5">
              <mat-icon class="text-[20px] text-cyan-300">shopping_bag</mat-icon>
              <h2 class="font-display font-bold text-[15px]">Your sourcing desk</h2>
            </div>
            <div class="p-4 space-y-3">
              <div class="flex items-center gap-2.5 text-sm text-slate-800 pb-2.5 border-b border-slate-100">
                <mat-icon class="text-[18px] text-[#0055B8]">format_list_bulleted</mat-icon>
                <span class="font-medium tabular-nums">
                  {{ store.shortlistOfferIds().length }} offers shortlisted
                </span>
              </div>
              <div class="flex items-center gap-2.5 text-sm text-slate-800">
                <mat-icon class="text-[18px] text-[#0055B8]">location_on</mat-icon>
                <span>
                  Destination: <strong class="font-semibold">{{ store.selectedDestination() }}</strong>
                </span>
              </div>
              <a
                routerLink="/compare"
                class="w-full h-10 rounded-lg bg-[#0055B8] hover:bg-[#00449E] text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <mat-icon class="text-[18px]">compare_arrows</mat-icon>
                <span>Compare landed cost</span>
              </a>
            </div>
          </div>

          <!-- Open requests -->
          <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div class="bg-[#EAF2FD] px-4 py-3 flex items-center gap-2 border-b border-blue-100">
              <mat-icon class="text-[19px] text-[#00449E]">description</mat-icon>
              <h2 class="font-display font-bold text-[15px] text-slate-900">Open requests</h2>
            </div>
            <div class="p-4 space-y-3">
              @if (topOpenRfq(); as rfq) {
                <div class="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                  <div class="space-y-0.5">
                    <a
                      routerLink="/rfqs"
                      class="text-sm font-semibold text-slate-900 hover:text-[#00449E] tabular-nums"
                    >
                      {{ rfq.lines[0].productName }} · {{ rfq.lines[0].equivalentCases.toLocaleString() }} cases
                    </a>
                    <div class="text-xs text-slate-500">
                      Delivery required: {{ rfq.requiredDeliveryDays }} days
                    </div>
                  </div>
                  <span class="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded shrink-0">
                    {{ rfq.quotes.length > 0 ? rfq.quotes.length + ' quotes' : 'Awaiting offers' }}
                  </span>
                </div>
              } @else {
                <p class="text-xs text-slate-500">No open requests for this organisation.</p>
              }

              <a
                routerLink="/rfqs"
                [queryParams]="{new: 1}"
                class="inline-flex items-center gap-1 text-sm font-semibold text-[#00449E] hover:underline"
              >
                <span>Create an RFQ</span>
                <mat-icon class="text-[17px]">add</mat-icon>
              </a>
            </div>
          </div>

          <!-- Agree terms before ordering -->
          <div class="bg-[#E8F2FE] border border-blue-200/80 rounded-xl p-4 flex items-center gap-3">
            <div class="flex items-center gap-1 text-[#00449E] shrink-0">
              <mat-icon class="text-[22px]">directions_boat</mat-icon>
              <mat-icon class="text-[22px]">article</mat-icon>
            </div>
            <div>
              <div class="font-display font-bold text-sm text-slate-900">
                Agree terms before ordering
              </div>
              <div class="text-xs text-slate-600 mt-0.5">
                Currency · Incoterm · Lead time
              </div>
            </div>
          </div>

          <!-- UK Buyer Demo Callout -->
          <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
            <div class="text-xs font-semibold text-[#00449E]">UK Buyer Walkthrough</div>
            <p class="text-xs text-slate-600 leading-relaxed">
              Explore the end-to-end Albion Retail Group workflow: RFQ quotes, landed cost review, approval, stock reservation, partial dispatch, discrepancy & credit note.
            </p>
            <a
              routerLink="/buyer"
              class="inline-flex items-center gap-1 text-xs font-semibold text-[#00449E] hover:underline"
            >
              <span>Open Buyer Workspace</span>
              <mat-icon class="text-[15px]">arrow_forward</mat-icon>
            </a>
          </div>

          <p class="text-[11px] text-slate-500 text-right">
            Independent platform concept · Synthetic suppliers and offers
          </p>
        </aside>
      </div>
    </div>

    <!-- Mobile Filters Slide-over Drawer -->
    @if (mobileFiltersOpen()) {
      <div class="fixed inset-0 z-50 lg:hidden flex">
        <button
          type="button"
          aria-label="Close filters backdrop"
          (click)="mobileFiltersOpen.set(false)"
          class="fixed inset-0 bg-slate-900/40"
        ></button>
        <div class="relative w-80 max-w-[85vw] bg-white h-full p-5 overflow-y-auto z-10 space-y-5">
          <div class="flex items-center justify-between">
            <h2 class="font-display font-bold text-base text-slate-900">Refine your sourcing</h2>
            <button type="button" (click)="mobileFiltersOpen.set(false)" class="p-1 text-slate-600">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="space-y-1.5">
            <label for="mobile-ship-to" class="block text-xs font-semibold text-slate-700">Ship to:</label>
            <select
              id="mobile-ship-to"
              [value]="store.selectedDestination()"
              (change)="onDestinationChange($event)"
              class="w-full h-10 px-3 text-sm border border-slate-300 rounded-lg"
            >
              @for (dest of destinations; track dest) {
                <option [value]="dest">{{ dest }}</option>
              }
            </select>
          </div>
          <div class="space-y-2">
            <div class="text-xs font-semibold text-slate-700">Supplier region</div>
            @for (reg of regions; track reg) {
              <label class="flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  [checked]="selectedRegions().includes(reg)"
                  (change)="toggleRegion(reg)"
                  class="w-4 h-4 rounded"
                />
                <span>{{ reg }}</span>
              </label>
            }
          </div>
          <div class="space-y-2">
            <div class="text-xs font-semibold text-slate-700">Trade terms</div>
            @for (term of tradeTerms; track term) {
              <label class="flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  [checked]="selectedTerms().includes(term)"
                  (change)="toggleTerm(term)"
                  class="w-4 h-4 rounded"
                />
                <span>{{ term }}</span>
              </label>
            }
          </div>
          <label class="flex items-center gap-2 text-sm font-medium text-slate-800">
            <input
              type="checkbox"
              [checked]="verifiedOnly()"
              (change)="verifiedOnly.set(!verifiedOnly())"
              class="w-4 h-4 rounded"
            />
            <span>Verified business only</span>
          </label>
          <button
            type="button"
            (click)="mobileFiltersOpen.set(false)"
            class="w-full h-11 rounded-lg bg-[#00449E] text-white font-semibold text-sm"
          >
            Apply filters
          </button>
        </div>
      </div>
    }

    <!-- Mobile Sourcing Workspace Drawer -->
    @if (mobileWorkspaceOpen()) {
      <div class="fixed inset-0 z-50 lg:hidden flex justify-end">
        <button
          type="button"
          aria-label="Close workspace backdrop"
          (click)="mobileWorkspaceOpen.set(false)"
          class="fixed inset-0 bg-slate-900/40"
        ></button>
        <div class="relative w-80 max-w-[85vw] bg-white h-full p-5 overflow-y-auto z-10 space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="font-display font-bold text-base text-slate-900">Your sourcing desk</h2>
            <button type="button" (click)="mobileWorkspaceOpen.set(false)" class="p-1 text-slate-600">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="p-3 bg-slate-50 rounded-lg border border-slate-200 text-sm space-y-1">
            <div>{{ store.shortlistOfferIds().length }} offers shortlisted</div>
            <div>Destination: <strong>{{ store.selectedDestination() }}</strong></div>
          </div>
          <a
            routerLink="/compare"
            (click)="mobileWorkspaceOpen.set(false)"
            class="w-full h-11 rounded-lg bg-[#0055B8] text-white font-semibold text-sm flex items-center justify-center"
          >
            Compare landed cost
          </a>
          <a
            routerLink="/buyer"
            (click)="mobileWorkspaceOpen.set(false)"
            class="w-full h-11 rounded-lg border border-slate-300 text-slate-800 font-semibold text-sm flex items-center justify-center"
          >
            Open Buyer Workspace
          </a>
        </div>
      </div>
    }
  `,
})
export class MarketplaceHome {
  readonly store = inject(MarketplaceStore);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly categories: {name: ProductCategory; icon: string}[] = [
    {name: 'Personal care', icon: 'sanitizer'},
    {name: 'Home care', icon: 'home'},
    {name: 'Food & beverage', icon: 'soup_kitchen'},
    {name: 'Health & wellbeing', icon: 'monitor_heart'},
    {name: 'Paper & packaging', icon: 'inventory_2'},
  ];

  readonly destinations = [
    'United Kingdom',
    'Germany',
    'Netherlands',
    'France',
    'United States',
    'Singapore',
    'All destinations',
  ];

  readonly regions: SupplierRegion[] = [
    'Europe',
    'Asia Pacific',
    'Americas',
    'Middle East & Africa',
  ];

  readonly tradeTerms: Incoterm[] = ['FCA', 'FOB', 'DAP', 'CIF'];

  readonly selectedCategory = signal<ProductCategory | null>(null);
  readonly selectedRegions = signal<SupplierRegion[]>([]);
  readonly selectedTerms = signal<Incoterm[]>([]);
  readonly maxMoqInput = signal<string>('');
  readonly moqUnit = signal<'cases' | 'pallets'>('cases');
  readonly verifiedOnly = signal<boolean>(false);
  readonly activeTab = signal<'recommended' | 'recent' | 'rfqs'>('recommended');

  readonly mobileFiltersOpen = signal(false);
  readonly mobileWorkspaceOpen = signal(false);

  constructor() {
    this.route.paramMap.subscribe((params) => {
      const slug = params.get('slug');
      if (slug) {
        const matched = this.categories.find(
          (c) => c.name.toLowerCase().replace(/[^a-z]+/g, '-') === slug,
        );
        if (matched) this.selectedCategory.set(matched.name);
      }
    });
  }

  readonly hasActiveFilters = computed(
    () =>
      this.selectedCategory() !== null ||
      this.selectedRegions().length > 0 ||
      this.selectedTerms().length > 0 ||
      this.maxMoqInput().trim() !== '' ||
      this.verifiedOnly() ||
      this.store.searchQuery().trim() !== '',
  );

  readonly topOpenRfq = computed(() => {
    const list = this.store.rfqs().filter((r) => r.status !== 'Closed');
    return list[0] ?? null;
  });

  readonly filteredOffers = computed(() => {
    const q = this.store.searchQuery().trim().toLowerCase();
    const cat = this.selectedCategory();
    const dest = this.store.selectedDestination();
    const regs = this.selectedRegions();
    const terms = this.selectedTerms();
    const maxMoqRaw = Number(this.maxMoqInput());
    const hasMoq = this.maxMoqInput().trim() !== '' && Number.isFinite(maxMoqRaw) && maxMoqRaw > 0;
    const onlyVerified = this.verifiedOnly();
    const tab = this.activeTab();

    let items = this.store.enrichedOffers().filter(({offer, product, seller, pkg}) => {
      if (!product || !seller) return false;
      if (offer.status !== 'active') return false;
      if (
        q &&
        !product.name.toLowerCase().includes(q) &&
        !product.brand.toLowerCase().includes(q) &&
        !product.sku.toLowerCase().includes(q) &&
        !seller.tradingName.toLowerCase().includes(q)
      ) {
        return false;
      }
      if (cat && product.category !== cat) return false;
      if (
        dest !== 'All destinations' &&
        !offer.permittedDestinations.includes(dest)
      ) {
        return false;
      }
      if (regs.length > 0 && !regs.includes(seller.region)) return false;
      if (terms.length > 0 && !terms.includes(offer.incoterm)) return false;
      if (onlyVerified && seller.verification.status !== 'verified') return false;
      if (hasMoq) {
        const limitCases =
          this.moqUnit() === 'pallets' && pkg
            ? maxMoqRaw * pkg.casesPerPallet
            : maxMoqRaw;
        if (offer.moqCases > limitCases) return false;
      }
      return true;
    });

    if (tab === 'recommended') {
      items = [...items].sort((a, b) => {
        if (a.offer.isRecommended !== b.offer.isRecommended) {
          return a.offer.isRecommended ? -1 : 1;
        }
        return a.offer.leadTimeDays - b.offer.leadTimeDays;
      });
    } else if (tab === 'recent') {
      items = [...items].sort((a, b) =>
        b.offer.listedAt.localeCompare(a.offer.listedAt),
      );
    }

    return items;
  });

  isShortlisted(offerId: string): boolean {
    return this.store.shortlistOfferIds().includes(offerId);
  }

  toggleCategory(cat: ProductCategory): void {
    this.selectedCategory.set(this.selectedCategory() === cat ? null : cat);
  }

  toggleRegion(reg: SupplierRegion): void {
    const curr = this.selectedRegions();
    this.selectedRegions.set(
      curr.includes(reg) ? curr.filter((r) => r !== reg) : [...curr, reg],
    );
  }

  toggleTerm(term: Incoterm): void {
    const curr = this.selectedTerms();
    this.selectedTerms.set(
      curr.includes(term) ? curr.filter((t) => t !== term) : [...curr, term],
    );
  }

  onDestinationChange(event: Event): void {
    this.store.selectedDestination.set((event.target as HTMLSelectElement).value);
  }

  onMaxMoqInput(event: Event): void {
    this.maxMoqInput.set((event.target as HTMLInputElement).value);
  }

  onMoqUnitChange(event: Event): void {
    this.moqUnit.set((event.target as HTMLSelectElement).value as 'cases' | 'pallets');
  }

  resetFilters(): void {
    this.selectedCategory.set(null);
    this.selectedRegions.set([]);
    this.selectedTerms.set([]);
    this.maxMoqInput.set('');
    this.verifiedOnly.set(false);
    this.store.searchQuery.set('');
    this.store.selectedDestination.set('United Kingdom');
  }

  scrollToCatalog(): void {
    if (typeof document !== 'undefined') {
      document.getElementById('wholesale-catalogue')?.scrollIntoView({behavior: 'smooth'});
    } else {
      this.router.navigate(['/']);
    }
  }
}
