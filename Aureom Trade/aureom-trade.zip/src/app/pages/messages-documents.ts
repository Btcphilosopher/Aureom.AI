import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';

@Component({
  selector: 'app-messages-documents',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div>
        <h1 class="font-display font-bold text-2xl text-slate-900">
          Messages & Versioned Document Vault
        </h1>
        <p class="text-sm text-slate-600 mt-0.5">
          Organisation-scoped commercial threads and versioned certificates, SDS/COA sheets, and system templates.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Message Threads -->
        <section class="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <h2 class="font-display font-bold text-lg text-slate-900">
            Authorised Message Threads ({{ store.threads().length }})
          </h2>

          @for (thr of store.threads(); track thr.id) {
            <div class="border border-slate-200 rounded-xl p-4 space-y-3">
              <div class="border-b border-slate-100 pb-2">
                <div class="text-xs font-mono text-[#00449E]">{{ thr.linkedEntityType.toUpperCase() }} · {{ thr.linkedEntityId }}</div>
                <div class="font-semibold text-sm text-slate-900">{{ thr.subject }}</div>
              </div>

              <div class="space-y-2.5 max-h-64 overflow-y-auto">
                @for (m of thr.messages; track m.id) {
                  <div class="bg-slate-50 border border-slate-100 rounded-lg p-3 text-xs space-y-1">
                    <div class="flex items-center justify-between text-slate-500">
                      <strong class="text-slate-800">{{ m.senderName }} ({{ m.senderRole }})</strong>
                      <span>{{ m.createdAt.slice(0, 16) }}</span>
                    </div>
                    <p class="text-slate-700">{{ m.body }}</p>
                    @if (m.attachmentDocId) {
                      <div class="text-[11px] text-[#00449E] font-mono">
                        Attachment: {{ m.attachmentDocId }}
                      </div>
                    }
                  </div>
                }
              </div>

              <div class="flex gap-2 pt-1">
                <input
                  type="text"
                  [value]="replyDraft()[thr.id] ?? ''"
                  (input)="onReplyInput(thr.id, $event)"
                  placeholder="Write a message to thread participants..."
                  class="flex-1 h-9 px-3 text-xs border border-slate-300 rounded-lg"
                />
                <button
                  type="button"
                  (click)="sendReply(thr.id)"
                  class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-xs font-semibold"
                >
                  Send
                </button>
              </div>
            </div>
          }
        </section>

        <!-- Versioned Document Vault -->
        <section class="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="font-display font-bold text-lg text-slate-900">
              Document Vault ({{ store.documents().length }})
            </h2>
            <button
              type="button"
              (click)="showUpload.set(!showUpload())"
              class="h-8 px-3 rounded-lg border border-[#0066CC] text-[#00449E] text-xs font-semibold"
            >
              {{ showUpload() ? 'Close' : 'Upload version' }}
            </button>
          </div>

          @if (showUpload()) {
            <form
              [formGroup]="docForm"
              (ngSubmit)="submitDoc()"
              class="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-xs"
            >
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label for="doc-title" class="block font-semibold text-slate-700 mb-1">Document Title</label>
                  <input id="doc-title" type="text" formControlName="title" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg" />
                </div>
                <div>
                  <label for="doc-type" class="block font-semibold text-slate-700 mb-1">Type</label>
                  <select id="doc-type" formControlName="docType" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg">
                    <option value="COA">COA (Certificate of Analysis)</option>
                    <option value="SDS">SDS (Safety Data Sheet)</option>
                    <option value="ISO_Certificate">ISO Certificate</option>
                    <option value="Customs_Declaration">Customs Declaration</option>
                  </select>
                </div>
                <div>
                  <label for="doc-product" class="block font-semibold text-slate-700 mb-1">Linked Product</label>
                  <select id="doc-product" formControlName="linkedEntityId" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg">
                    @for (p of store.products(); track p.id) {
                      <option [value]="p.id">{{ p.name }}</option>
                    }
                  </select>
                </div>
                <div>
                  <label for="doc-issuer" class="block font-semibold text-slate-700 mb-1">Issuer</label>
                  <input id="doc-issuer" type="text" formControlName="issuer" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg" />
                </div>
              </div>
              <div>
                <label for="doc-summary" class="block font-semibold text-slate-700 mb-1">Summary</label>
                <input id="doc-summary" type="text" formControlName="summary" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg" />
              </div>
              <button
                type="submit"
                [disabled]="docForm.invalid"
                class="h-9 px-4 rounded-lg bg-[#00449E] text-white font-semibold"
              >
                Save new version
              </button>
            </form>
          }

          <div class="space-y-2.5">
            @for (doc of store.documents(); track doc.id) {
              <div class="border border-slate-200 rounded-lg p-3 text-xs space-y-1">
                <div class="flex items-center justify-between gap-2">
                  <span class="font-semibold text-slate-900">{{ doc.title }}</span>
                  <span class="font-mono text-[#00449E]">v{{ doc.version }} · {{ doc.docType }}</span>
                </div>
                <div class="text-slate-500">
                  Issuer: {{ doc.issuer }} · Visibility: {{ doc.visibility }} ·
                  {{ doc.isSystemTemplate ? 'Generated template (non-official)' : 'Uploaded by ' + doc.uploadedBy }}
                </div>
                <p class="text-slate-600">{{ doc.summary }}</p>
              </div>
            }
          </div>
        </section>
      </div>
    </div>
  `,
})
export class MessagesDocumentsPage {
  readonly store = inject(MarketplaceStore);

  readonly replyDraft = signal<Partial<Record<string, string>>>({});
  readonly showUpload = signal(false);

  readonly docForm = new FormGroup({
    title: new FormControl('COA — Batch BW-2026-12B Stability Update', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    docType: new FormControl('COA', {nonNullable: true}),
    linkedEntityId: new FormControl('prod_body_wash', {nonNullable: true}),
    issuer: new FormControl('Thames Quality Lab (Simulated)', {nonNullable: true}),
    summary: new FormControl('Updated microbial and pH stability metrics.', {
      nonNullable: true,
    }),
  });

  onReplyInput(threadId: string, e: Event): void {
    this.replyDraft.update((m) => ({
      ...m,
      [threadId]: (e.target as HTMLInputElement).value,
    }));
  }

  async sendReply(threadId: string): Promise<void> {
    const body = (this.replyDraft()[threadId] ?? '').trim();
    if (!body) return;
    await this.store.sendMessage(threadId, body);
    this.replyDraft.update((m) => ({...m, [threadId]: ''}));
  }

  async submitDoc(): Promise<void> {
    if (this.docForm.invalid) return;
    await this.store.uploadDocument({
      ...this.docForm.getRawValue(),
      linkedEntityType: 'product',
      visibility: 'authorised_parties',
    });
    this.showUpload.set(false);
  }
}
