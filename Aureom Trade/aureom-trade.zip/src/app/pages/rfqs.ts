import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import {ActivatedRoute, Router, RouterLink} from '@angular/router';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {Rfq, RfqQuote} from '../core/models';

@Component({
  selector: 'app-rfqs',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 class="font-display font-bold text-2xl text-slate-900">
            Request for Quotation (RFQ) & Negotiations
          </h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Private quotations are visible only to the buyer organisation and the quoting seller. Awarding creates an order from a preserved term snapshot.
          </p>
        </div>
        <button
          type="button"
          (click)="showCreateForm.set(!showCreateForm())"
          class="h-10 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-sm font-semibold flex items-center gap-1.5 self-start whitespace-nowrap"
        >
          <mat-icon class="text-[18px]">{{ showCreateForm() ? 'close' : 'add' }}</mat-icon>
          <span>{{ showCreateForm() ? 'Close RFQ form' : 'New RFQ' }}</span>
        </button>
      </div>

      <!-- Create RFQ Form -->
      @if (showCreateForm()) {
        <form
          [formGroup]="rfqForm"
          (ngSubmit)="submitNewRfq()"
          class="bg-white border border-slate-200 rounded-xl p-6 space-y-4 shadow-xs"
        >
          <h2 class="font-display font-bold text-lg text-slate-900">Create Request for Quotation</h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div class="md:col-span-2">
              <label for="rfq-title" class="block text-xs font-semibold text-slate-700 mb-1">RFQ Title</label>
              <input
                id="rfq-title"
                type="text"
                formControlName="title"
                class="w-full h-10 px-3 border border-slate-300 rounded-lg"
                placeholder="e.g. Q4 Personal Care Wholesale Replenishment"
              />
            </div>
            <div>
              <label for="rfq-product" class="block text-xs font-semibold text-slate-700 mb-1">Product</label>
              <select id="rfq-product" formControlName="productId" class="w-full h-10 px-3 border border-slate-300 rounded-lg bg-white">
                @for (p of store.products(); track p.id) {
                  <option [value]="p.id">{{ p.name }} ({{ p.sku }})</option>
                }
              </select>
            </div>
            <div>
              <label for="rfq-qty" class="block text-xs font-semibold text-slate-700 mb-1">Quantity</label>
              <input
                id="rfq-qty"
                type="number"
                formControlName="quantity"
                class="w-full h-10 px-3 border border-slate-300 rounded-lg tabular-nums"
              />
            </div>
            <div>
              <label for="rfq-unit" class="block text-xs font-semibold text-slate-700 mb-1">Packaging Unit</label>
              <select id="rfq-unit" formControlName="packUnit" class="w-full h-10 px-3 border border-slate-300 rounded-lg bg-white">
                <option value="case">Cases</option>
                <option value="pallet">Pallets</option>
                <option value="inner_pack">Inner packs</option>
                <option value="unit">Individual units</option>
              </select>
            </div>
            <div>
              <label for="rfq-dest" class="block text-xs font-semibold text-slate-700 mb-1">Destination Country</label>
              <select id="rfq-dest" formControlName="destinationCountry" class="w-full h-10 px-3 border border-slate-300 rounded-lg bg-white">
                <option value="United Kingdom">United Kingdom</option>
                <option value="Germany">Germany</option>
                <option value="Netherlands">Netherlands</option>
                <option value="France">France</option>
                <option value="United States">United States</option>
              </select>
            </div>
            <div>
              <label for="rfq-days" class="block text-xs font-semibold text-slate-700 mb-1">Required Delivery (days)</label>
              <input
                id="rfq-days"
                type="number"
                formControlName="requiredDeliveryDays"
                class="w-full h-10 px-3 border border-slate-300 rounded-lg tabular-nums"
              />
            </div>
            <div>
              <label for="rfq-incoterm" class="block text-xs font-semibold text-slate-700 mb-1">Preferred Incoterm</label>
              <select id="rfq-incoterm" formControlName="incoterm" class="w-full h-10 px-3 border border-slate-300 rounded-lg bg-white">
                <option value="FCA">FCA (Incoterms 2020)</option>
                <option value="FOB">FOB (Sea only)</option>
                <option value="CIF">CIF (Sea only)</option>
                <option value="DAP">DAP</option>
                <option value="DDP">DDP</option>
              </select>
            </div>
            <div>
              <label for="rfq-curr" class="block text-xs font-semibold text-slate-700 mb-1">Preferred Currency</label>
              <select id="rfq-curr" formControlName="preferredCurrency" class="w-full h-10 px-3 border border-slate-300 rounded-lg bg-white">
                <option value="USD">USD</option>
                <option value="GBP">GBP</option>
                <option value="EUR">EUR</option>
              </select>
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <label for="rfq-spec" class="block text-xs font-semibold text-slate-700 mb-1">Specification & Labelling Notes</label>
              <input
                id="rfq-spec"
                type="text"
                formControlName="specification"
                class="w-full h-10 px-3 border border-slate-300 rounded-lg"
                placeholder="Shelf-ready tray, English/EU labels, min 18m shelf life"
              />
            </div>
            <div class="flex items-end gap-4 pb-2">
              <label class="flex items-center gap-2 text-xs font-medium text-slate-700">
                <input type="checkbox" formControlName="permittedSubstitutions" class="w-4 h-4 rounded" />
                <span>Permit equivalent brand substitutions</span>
              </label>
            </div>
          </div>

          <div class="flex justify-end gap-3 pt-2 border-t border-slate-100">
            <button
              type="button"
              (click)="showCreateForm.set(false)"
              class="h-10 px-4 rounded-lg border border-slate-300 text-sm font-medium text-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              [disabled]="rfqForm.invalid"
              class="h-10 px-5 rounded-lg bg-[#00449E] hover:bg-[#00357E] disabled:opacity-50 text-white text-sm font-semibold"
            >
              Publish RFQ & Invite Suppliers
            </button>
          </div>
        </form>
      }

      <!-- Active RFQs List -->
      @for (rfq of store.rfqs(); track rfq.id) {
        <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-5">
          <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div class="space-y-1">
              <div class="flex items-center flex-wrap gap-2 text-xs">
                <span class="font-mono font-bold text-[#00449E]">{{ rfq.id }}</span>
                <span class="text-slate-400">·</span>
                <span class="font-medium text-slate-700">{{ rfq.buyerName }}</span>
                <span class="text-slate-400">·</span>
                <span
                  class="px-2 py-0.5 rounded font-semibold"
                  [class.bg-amber-50]="rfq.status === 'Responses Received' || rfq.status === 'Published'"
                  [class.text-amber-800]="rfq.status === 'Responses Received' || rfq.status === 'Published'"
                  [class.bg-emerald-50]="rfq.status === 'Awarded'"
                  [class.text-emerald-800]="rfq.status === 'Awarded'"
                >
                  {{ rfq.status }}
                </span>
              </div>
              <h2 class="font-display font-bold text-lg text-slate-900">{{ rfq.title }}</h2>
              <div class="text-xs text-slate-600 tabular-nums">
                {{ rfq.lines[0].productName }} · {{ rfq.lines[0].equivalentCases.toLocaleString() }} cases
                ({{ rfq.lines[0].specification }}) · Dest: {{ rfq.deliveryLocation }} ·
                {{ rfq.incoterm }} · {{ rfq.requiredDeliveryDays }}d target · Docs: {{ rfq.requiredDocuments.join(', ') }}
              </div>
            </div>

            @if (rfq.createdOrderId) {
              <a
                routerLink="/orders"
                class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 self-start shrink-0"
              >
                <mat-icon class="text-[16px]">receipt_long</mat-icon>
                <span>View Order {{ rfq.createdOrderId }}</span>
              </a>
            }
          </div>

          <!-- Quotations Table -->
          <div class="space-y-3">
            <div class="flex items-center justify-between">
              <h3 class="font-display font-bold text-sm text-slate-900">
                Versioned Supplier Quotations ({{ rfq.quotes.length }})
              </h3>
              <span class="text-[11px] text-slate-500">
                Showing quotations authorised for {{ store.activePersona().orgName }}
              </span>
            </div>

            @if (rfq.quotes.length === 0) {
              <div class="p-4 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
                No quotations visible or submitted yet for your organisation.
              </div>
            } @else {
              <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                @for (quote of rfq.quotes; track quote.id) {
                  @let latest = latestVersion(quote);
                  <div
                    class="border rounded-xl p-4 space-y-3"
                    [class.border-emerald-400]="quote.status === 'awarded'"
                    [class.bg-emerald-50/30]="quote.status === 'awarded'"
                    [class.border-slate-200]="quote.status !== 'awarded'"
                  >
                    <div class="flex items-start justify-between gap-2">
                      <div>
                        <div class="font-display font-bold text-base text-slate-900">
                          {{ quote.sellerName }}
                        </div>
                        <div class="text-xs text-slate-500">
                          Version v{{ quote.currentVersion }} · {{ latest.incoterm }} {{ latest.namedPlace }} · {{ latest.leadTimeDays }}d lead
                        </div>
                      </div>
                      <span class="text-xs font-semibold uppercase tracking-wide"
                        [class.text-emerald-700]="quote.status === 'awarded'"
                        [class.text-[#00449E]]="quote.status !== 'awarded'"
                      >
                        {{ quote.status }}
                      </span>
                    </div>

                    <div class="grid grid-cols-3 gap-2 text-xs bg-slate-50 rounded-lg p-3 tabular-nums">
                      <div>
                        <div class="text-slate-500">Case Price</div>
                        <div class="font-bold text-slate-900">
                          {{ store.formatExactCurrency(latest.unitPriceMinorPerCase, latest.currency) }}
                        </div>
                      </div>
                      <div>
                        <div class="text-slate-500">Goods Subtotal</div>
                        <div class="font-semibold text-slate-800">
                          {{ store.formatExactCurrency(latest.unitPriceMinorPerCase * rfq.lines[0].equivalentCases, latest.currency) }}
                        </div>
                      </div>
                      <div>
                        <div class="text-slate-500">Est. Landed</div>
                        <div class="font-bold text-[#00449E]">
                          {{ store.formatExactCurrency(estimateQuoteLanded(rfq, quote), latest.currency) }}
                        </div>
                      </div>
                    </div>

                    <div class="text-xs text-slate-600">
                      <strong>Notes:</strong> {{ latest.notes }} · Payment: {{ latest.paymentTerms }}
                    </div>

                    <!-- Version history -->
                    @if (quote.versions.length > 1) {
                      <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2">
                        History:
                        @for (ver of quote.versions; track ver.version) {
                          <span class="mr-3">
                            v{{ ver.version }}: {{ store.formatExactCurrency(ver.unitPriceMinorPerCase, ver.currency) }}/case ({{ ver.submittedAt.slice(0, 10) }})
                          </span>
                        }
                      </div>
                    }

                    @if (canAward(rfq) && quote.status !== 'awarded') {
                      <div class="pt-2 flex justify-end">
                        <button
                          type="button"
                          (click)="awardQuote(rfq, quote)"
                          class="h-9 px-4 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white text-xs font-semibold flex items-center gap-1.5"
                        >
                          <mat-icon class="text-[16px]">gavel</mat-icon>
                          <span>Award quotation & create order</span>
                        </button>
                      </div>
                    }
                  </div>
                }
              </div>
            }
          </div>

          <!-- Seller Quote Submission Box (when active persona is a Seller Manager) -->
          @if (canSubmitSellerQuote(rfq)) {
            <form
              [formGroup]="quoteForm"
              (ngSubmit)="submitSellerQuote(rfq)"
              class="p-4 rounded-xl bg-blue-50/60 border border-blue-200 space-y-3"
            >
              <div class="text-xs font-bold text-[#003E9C]">
                Submit / Revise Supplier Quotation as {{ store.activePersona().orgName }}
              </div>
              <div class="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                <label class="block">
                  <span class="block text-slate-600 mb-1">Price / case (USD cents)</span>
                  <input type="number" formControlName="unitPriceMinorPerCase" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg tabular-nums" />
                </label>
                <label class="block">
                  <span class="block text-slate-600 mb-1">Lead time (days)</span>
                  <input type="number" formControlName="leadTimeDays" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg tabular-nums" />
                </label>
                <label class="block">
                  <span class="block text-slate-600 mb-1">Incoterm</span>
                  <select formControlName="incoterm" class="w-full h-9 px-2 bg-white border border-slate-300 rounded-lg">
                    <option value="FCA">FCA</option>
                    <option value="DAP">DAP</option>
                    <option value="FOB">FOB</option>
                    <option value="DDP">DDP</option>
                  </select>
                </label>
                <label class="block">
                  <span class="block text-slate-600 mb-1">Named place</span>
                  <input type="text" formControlName="namedPlace" class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg" />
                </label>
                <div class="flex items-end">
                  <button
                    type="submit"
                    class="w-full h-9 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white font-semibold"
                  >
                    Submit quote version
                  </button>
                </div>
              </div>
            </form>
          }

          <!-- RFQ Questions & Clarifications -->
          <div class="pt-3 border-t border-slate-100 space-y-2">
            <div class="text-xs font-semibold text-slate-700">Clarification Q&A ({{ rfq.questions.length }})</div>
            @for (q of rfq.questions; track q.id) {
              <div class="text-xs bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-1">
                <div><strong>{{ q.authorName }}:</strong> {{ q.question }}</div>
                @if (q.answer) {
                  <div class="text-emerald-800"><strong>Buyer reply:</strong> {{ q.answer }}</div>
                }
              </div>
            }
          </div>
        </section>
      }
    </div>
  `,
})
export class RfqsPage {
  readonly store = inject(MarketplaceStore);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly showCreateForm = signal(false);

  readonly rfqForm = new FormGroup({
    title: new FormControl('Q1 Personal Care Wholesale Replenishment', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(3)],
    }),
    productId: new FormControl('prod_body_wash', {nonNullable: true}),
    quantity: new FormControl(400, {nonNullable: true, validators: [Validators.min(1)]}),
    packUnit: new FormControl('case', {nonNullable: true}),
    destinationCountry: new FormControl('United Kingdom', {nonNullable: true}),
    requiredDeliveryDays: new FormControl(30, {nonNullable: true}),
    incoterm: new FormControl('FCA', {nonNullable: true}),
    preferredCurrency: new FormControl('USD', {nonNullable: true}),
    specification: new FormControl('Retail shelf-ready cases, minimum 24m expiry', {
      nonNullable: true,
    }),
    permittedSubstitutions: new FormControl(false, {nonNullable: true}),
  });

  readonly quoteForm = new FormGroup({
    unitPriceMinorPerCase: new FormControl(2420, {nonNullable: true}),
    leadTimeDays: new FormControl(5, {nonNullable: true}),
    incoterm: new FormControl('FCA', {nonNullable: true}),
    namedPlace: new FormControl('London Thames Hub', {nonNullable: true}),
  });

  constructor() {
    this.route.queryParamMap.subscribe((q) => {
      if (q.get('new') === '1') {
        this.showCreateForm.set(true);
      }
    });
  }

  latestVersion(quote: RfqQuote) {
    return quote.versions[quote.versions.length - 1];
  }

  estimateQuoteLanded(rfq: Rfq, quote: RfqQuote): number {
    const v = this.latestVersion(quote);
    const cases = rfq.lines[0]?.equivalentCases ?? 1;
    const goods = v.unitPriceMinorPerCase * cases;
    const freight = v.freightTotalMinor ?? 0;
    const ins = v.insuranceMinor ?? 0;
    const base = goods + freight + ins;
    const duties = Math.round((base * (v.dutyRateBps ?? 0)) / 10000);
    const tax = Math.round(((base + duties) * (v.importTaxRateBps ?? 0)) / 10000);
    const fee = Math.round((goods * (this.store.platformConfig()?.marketplaceFeeBps ?? 150)) / 10000);
    return goods + freight + ins + duties + tax + fee;
  }

  canAward(rfq: Rfq): boolean {
    const persona = this.store.activePersona();
    return (
      (persona.orgId === rfq.buyerOrgId || persona.role === 'platform_admin') &&
      rfq.status !== 'Awarded' &&
      rfq.status !== 'Closed'
    );
  }

  canSubmitSellerQuote(rfq: Rfq): boolean {
    const persona = this.store.activePersona();
    return (
      persona.role === 'seller_manager' &&
      rfq.status !== 'Awarded' &&
      rfq.status !== 'Closed'
    );
  }

  async submitNewRfq(): Promise<void> {
    if (this.rfqForm.invalid) return;
    try {
      await this.store.createRfq({
        ...this.rfqForm.getRawValue(),
        publishImmediately: true,
      });
      this.showCreateForm.set(false);
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }

  async awardQuote(rfq: Rfq, quote: RfqQuote): Promise<void> {
    try {
      await this.store.awardRfq(rfq.id, quote.id, 'UK Personal Care');
      this.router.navigate(['/orders']);
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }

  async submitSellerQuote(rfq: Rfq): Promise<void> {
    try {
      const val = this.quoteForm.getRawValue();
      await this.store.submitQuote(rfq.id, {
        ...val,
        currency: 'USD',
        transportMode: 'road',
        freightTotalMinor: val.incoterm === 'DAP' ? 0 : 155000,
        insuranceMinor: 9500,
        dutyRateBps: 0,
        importTaxRateBps: 2000,
        paymentTerms: 'Net 30 days',
        notes: 'Submitted via Seller Workspace RFQ portal',
      });
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }
}
