import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {MarketplaceStore} from '../core/marketplace.store';
import {Shipment} from '../core/models';

@Component({
  selector: 'app-orders-shipments',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="max-w-[1360px] mx-auto px-4 lg:px-6 py-6 space-y-6">
      <div>
        <h1 class="font-display font-bold text-2xl text-slate-900">
          Orders, Shipments & Delivery Discrepancies
        </h1>
        <p class="text-sm text-slate-600 mt-0.5">
          Order confirmation, stock allocation, partial dispatch, synthetic carrier tracking, delivery discrepancies, and commercial templates.
        </p>
      </div>

      <!-- Orders Section -->
      <section class="space-y-4">
        <h2 class="font-display font-bold text-lg text-slate-900">
          Wholesale Orders ({{ store.orders().length }})
        </h2>

        @if (store.orders().length === 0) {
          <div class="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-3">
            <p class="text-sm text-slate-600">
              No orders recorded yet for {{ store.activePersona().orgName }}. Award RFQ-2026-041 or place an order from the marketplace.
            </p>
            <a
              routerLink="/rfqs"
              class="inline-flex items-center px-4 py-2 rounded-lg bg-[#00449E] text-white text-xs font-semibold"
            >
              Go to RFQs
            </a>
          </div>
        } @else {
          @for (ord of store.orders(); track ord.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div class="space-y-1">
                  <div class="flex items-center flex-wrap gap-2 text-xs">
                    <span class="font-mono font-bold text-[#00449E]">{{ ord.id }}</span>
                    <span>·</span>
                    <span class="text-slate-500">Group {{ ord.buyerOrderGroupId }}</span>
                    <span>·</span>
                    <span class="font-semibold text-slate-800">{{ ord.buyerName }} → {{ ord.sellerName }}</span>
                    <span>·</span>
                    <span class="font-semibold"
                      [class.text-emerald-700]="ord.status === 'Allocated' || ord.status === 'Delivered'"
                      [class.text-amber-700]="ord.status === 'Awaiting Approval' || ord.status === 'Partially Dispatched' || ord.status === 'Disputed'"
                      [class.text-slate-500]="ord.status === 'Cancelled'"
                    >
                      {{ ord.status }}
                    </span>
                  </div>
                  <div class="text-xs text-slate-500">
                    {{ ord.incoterm }} {{ ord.namedPlace }} · {{ ord.paymentTerms }} ·
                    Source: {{ ord.sourceType }} ({{ ord.sourceRefId }}) ·
                    Platform Fee Snapshot: {{ ord.platformFeeBpsSnapshot / 100 }}%
                  </div>
                </div>

                <div class="flex items-center gap-3 shrink-0">
                  <div class="text-right">
                    <div class="font-display font-bold text-lg text-slate-900 tabular-nums">
                      {{ store.formatExactCurrency(ord.totalMinor, ord.orderCurrency) }}
                    </div>
                    <div class="text-[11px] text-slate-500">
                      Settlement: {{ ord.settlementCurrency }}
                    </div>
                  </div>
                  @if (ord.status === 'Awaiting Approval' || ord.status === 'Allocated' || ord.status === 'Confirmed') {
                    <button
                      type="button"
                      (click)="store.cancelOrder(ord.id, 'Cancelled by authorised user')"
                      class="h-8 px-3 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium"
                    >
                      Cancel
                    </button>
                  }
                </div>
              </div>

              @for (line of ord.lines; track line.id) {
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs bg-slate-50 rounded-lg p-3">
                  <div>
                    <div class="font-semibold text-slate-900">
                      {{ line.productName }} ({{ line.sku }}) · Pack v{{ line.packagingVersion }} ({{ line.packagingSnapshot.casePackSummary }})
                    </div>
                    <div class="text-slate-500 mt-0.5 tabular-nums">
                      Ordered: {{ line.casesOrdered }} · Allocated: {{ line.casesAllocated }} ·
                      Dispatched: {{ line.casesDispatched }} · Delivered Good: {{ line.casesDelivered }}
                    </div>
                    @if (line.batchAllocations.length > 0) {
                      <div class="text-[11px] text-[#00449E] mt-0.5 font-mono">
                        Batches:
                        @for (b of line.batchAllocations; track b.batchNumber) {
                          <span class="mr-2">{{ b.batchNumber }} ({{ b.cases }}c)</span>
                        }
                      </div>
                    }
                  </div>
                  <div class="font-semibold text-slate-900 tabular-nums">
                    {{ store.formatExactCurrency(line.lineSubtotalMinor, ord.orderCurrency) }}
                  </div>
                </div>
              }
            </article>
          }
        }
      </section>

      <!-- Shipments Section -->
      <section class="space-y-4">
        <h2 class="font-display font-bold text-lg text-slate-900">
          Shipments & Carrier Tracking ({{ store.shipments().length }})
        </h2>

        @for (shp of store.shipments(); track shp.id) {
          <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div class="space-y-1">
                <div class="flex items-center gap-2 text-xs">
                  <span class="font-mono font-bold text-[#00449E]">{{ shp.id }}</span>
                  <span>·</span>
                  <span>Order {{ shp.orderId }}</span>
                  <span>·</span>
                  <span class="font-mono text-slate-600">{{ shp.trackingNumber }}</span>
                  <span>·</span>
                  <span class="font-semibold"
                    [class.text-emerald-700]="shp.status === 'Delivered'"
                    [class.text-amber-700]="shp.status !== 'Delivered'"
                  >
                    {{ shp.status }}
                  </span>
                </div>
                <div class="text-xs text-slate-600 tabular-nums">
                  {{ shp.carrier }} · {{ shp.origin }} → {{ shp.destination }} ·
                  {{ shp.casesShipped }} cases ({{ shp.totalGrossWeightKg }} kg gross)
                </div>
              </div>

              <div class="flex flex-wrap gap-2">
                <button
                  type="button"
                  (click)="previewTemplate(shp, 'commercial_invoice')"
                  class="h-8 px-3 rounded-lg border border-slate-300 hover:border-[#0066CC] text-xs font-medium text-slate-700"
                >
                  Commercial Invoice Template
                </button>
                <button
                  type="button"
                  (click)="previewTemplate(shp, 'packing_list')"
                  class="h-8 px-3 rounded-lg border border-slate-300 hover:border-[#0066CC] text-xs font-medium text-slate-700"
                >
                  Packing List Template
                </button>
              </div>
            </div>

            <!-- Synthetic Carrier Tracking Events -->
            <div class="space-y-1.5 text-xs">
              @for (ev of shp.trackingEvents; track ev.id) {
                <div class="flex items-center gap-3 text-slate-600">
                  <span class="font-mono text-[11px] text-slate-400">{{ ev.timestamp.slice(0, 16) }}</span>
                  <span class="font-semibold text-slate-800">{{ ev.status }}</span>
                  <span>— {{ ev.description }}</span>
                  <span class="text-[11px] text-slate-400">({{ ev.source }})</span>
                </div>
              }
            </div>

            <!-- Record Delivery / Discrepancy Form -->
            @if (shp.status === 'In Transit') {
              <div class="p-4 rounded-xl bg-blue-50/50 border border-blue-200 space-y-3">
                <div class="text-xs font-bold text-[#003E9C]">
                  Record Receiving Inspection & Delivery Discrepancy
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                  <label class="block">
                    <span class="block text-slate-600 mb-1">Delivered cases (of {{ shp.casesShipped }})</span>
                    <input
                      type="number"
                      [value]="deliveredInput()[shp.id] ?? shp.casesShipped - 15"
                      (input)="setDelivered(shp.id, $event)"
                      class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg tabular-nums"
                    />
                  </label>
                  <label class="block">
                    <span class="block text-slate-600 mb-1">Damaged cases</span>
                    <input
                      type="number"
                      [value]="damagedInput()[shp.id] ?? 5"
                      (input)="setDamaged(shp.id, $event)"
                      class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg tabular-nums"
                    />
                  </label>
                  <label class="block">
                    <span class="block text-slate-600 mb-1">Discrepancy reason</span>
                    <input
                      type="text"
                      [value]="reasonInput()[shp.id] ?? '15 cases short-shipped, 5 crushed in transit'"
                      (input)="setReason(shp.id, $event)"
                      class="w-full h-9 px-2.5 bg-white border border-slate-300 rounded-lg"
                    />
                  </label>
                  <div class="flex items-end">
                    <button
                      type="button"
                      (click)="submitDelivery(shp)"
                      class="w-full h-9 rounded-lg bg-[#00449E] hover:bg-[#00357E] text-white font-semibold"
                    >
                      Confirm & Auto-Issue Credit
                    </button>
                  </div>
                </div>
              </div>
            }

            @if (shp.discrepancies.length > 0) {
              <div class="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1">
                @for (d of shp.discrepancies; track d.id) {
                  <div>
                    <strong>Discrepancy {{ d.id }}:</strong> {{ d.shortageCases }} short, {{ d.damagedCases }} damaged — {{ d.reason }}
                    @if (d.creditNoteId) {
                      <span class="font-semibold text-emerald-800 ml-2">· Credit Note {{ d.creditNoteId }} issued</span>
                    }
                  </div>
                }
              </div>
            }
          </article>
        }
      </section>

      <!-- Document Template Modal -->
      @if (activeTemplate(); as tpl) {
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
          <div class="bg-white rounded-xl max-w-2xl w-full p-6 space-y-4 shadow-2xl border border-slate-200">
            <div class="flex items-start justify-between gap-4 border-b border-slate-200 pb-3">
              <div>
                <div class="text-[11px] font-semibold uppercase tracking-wide text-amber-700">
                  Generated Commercial Template — Not an Official Government or Customs Certificate
                </div>
                <h3 class="font-display font-bold text-lg text-slate-900 mt-1">
                  {{ tpl.kind === 'commercial_invoice' ? 'Commercial Invoice Template' : 'Packing List Template' }} · {{ tpl.shipment.id }}
                </h3>
              </div>
              <button type="button" (click)="activeTemplate.set(null)" class="p-1 text-slate-500">
                <mat-icon>close</mat-icon>
              </button>
            </div>
            <div class="text-xs space-y-2 text-slate-700">
              <div><strong>Carrier:</strong> {{ tpl.shipment.carrier }} ({{ tpl.shipment.trackingNumber }})</div>
              <div><strong>Origin:</strong> {{ tpl.shipment.origin }}</div>
              <div><strong>Destination:</strong> {{ tpl.shipment.destination }}</div>
              <div><strong>Packages & Gross Weight:</strong> {{ tpl.shipment.casesShipped }} cartons · {{ tpl.shipment.totalGrossWeightKg }} kg</div>
              <div><strong>Dispatched:</strong> {{ tpl.shipment.dispatchedAt }}</div>
            </div>
            <div class="flex justify-end pt-2 border-t border-slate-100">
              <button
                type="button"
                (click)="activeTemplate.set(null)"
                class="h-9 px-4 rounded-lg bg-[#00449E] text-white text-xs font-semibold"
              >
                Close preview
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class OrdersShipmentsPage {
  readonly store = inject(MarketplaceStore);

  readonly deliveredInput = signal<Partial<Record<string, number>>>({});
  readonly damagedInput = signal<Partial<Record<string, number>>>({});
  readonly reasonInput = signal<Partial<Record<string, string>>>({});
  readonly activeTemplate = signal<{
    shipment: Shipment;
    kind: 'commercial_invoice' | 'packing_list';
  } | null>(null);

  setDelivered(id: string, e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    if (Number.isFinite(val)) {
      this.deliveredInput.update((m) => ({...m, [id]: Math.floor(val)}));
    }
  }

  setDamaged(id: string, e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    if (Number.isFinite(val)) {
      this.damagedInput.update((m) => ({...m, [id]: Math.floor(val)}));
    }
  }

  setReason(id: string, e: Event): void {
    this.reasonInput.update((m) => ({
      ...m,
      [id]: (e.target as HTMLInputElement).value,
    }));
  }

  async submitDelivery(shp: Shipment): Promise<void> {
    const order = this.store.orders().find((o) => o.id === shp.orderId);
    if (!order) return;
    const delivered = this.deliveredInput()[shp.id] ?? Math.max(0, shp.casesShipped - 15);
    const damaged = this.damagedInput()[shp.id] ?? 5;
    const reason =
      this.reasonInput()[shp.id] ?? '15 cases short-shipped, 5 crushed in transit';
    try {
      await this.store.recordDelivery(shp.id, {
        orderLineId: order.lines[0].id,
        deliveredCases: delivered,
        damagedCases: damaged,
        reason,
        autoIssueCreditNote: true,
      });
    } catch (err) {
      this.store.notify(this.store.extractError(err), 'error');
    }
  }

  previewTemplate(
    shipment: Shipment,
    kind: 'commercial_invoice' | 'packing_list',
  ): void {
    this.activeTemplate.set({shipment, kind});
  }
}
