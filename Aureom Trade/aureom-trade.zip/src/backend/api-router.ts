import express, { Request, Response } from 'express';
import { z } from 'zod';
import {
  CurrencyCode,
  Incoterm,
  PackUnit,
  ProductCategory,
  TransportMode,
  UserRole,
} from './types';
import {
  ForbiddenOrgAccessError,
  assertOrgAccess,
  getAuthorizedDocuments,
  getAuthorizedInvoices,
  getAuthorizedOrders,
  getAuthorizedShipments,
  getAuthorizedThreads,
  getDatabase,
  resetDatabaseToSeed,
  saveDatabase,
} from './store';
import {
  calculateLandedCost,
  rankLandedCostBreakdowns,
} from './domains/landed-cost';
import { availableCasesOf, withdrawBatch } from './domains/inventory';
import {
  approveOrder,
  createOrderFromAwardedRfq,
  createOrdersFromBasket,
} from './domains/orders';
import {
  createRfq,
  getAuthorizedRfqs,
  submitRfqQuoteVersion,
} from './domains/rfqs';
import {
  issueCreditNote,
  recordPaymentIdempotent,
} from './domains/payments';
import {
  createPartialOrFullShipment,
  recordDeliveryAndDiscrepancy,
} from './domains/shipments';
import { runProcurementAssistant } from './domains/ai-assistant';

interface ActorContext {
  orgId: string;
  role: UserRole;
  userId: string;
}

function getActor(req: Request): ActorContext {
  const orgId = String(req.header('x-aureom-org-id') || 'org_albion_uk');
  const role = String(req.header('x-aureom-role') || 'buyer') as UserRole;
  const userId = String(req.header('x-aureom-user-id') || 'usr_claire_buyer');
  return { orgId, role, userId };
}

function handleError(res: Response, err: unknown): void {
  if (err instanceof ForbiddenOrgAccessError) {
    res.status(403).json({ error: err.message });
    return;
  }
  const message = err instanceof Error ? err.message : 'Unexpected server error';
  const status =
    message.includes('not found')
      ? 404
      : message.includes('GEMINI_API_KEY')
        ? 503
        : 400;
  res.status(status).json({ error: message });
}

export function createApiRouter(): express.Router {
  const router = express.Router();

  router.get('/health', (_req, res) => {
    res.json({ status: 'ok', service: 'aureom-trade-api', timestamp: new Date().toISOString() });
  });

  router.get('/docs', (_req, res) => {
    res.json({
      openapi: '3.0.3',
      info: {
        title: 'Aureom Trade B2B Marketplace API',
        version: '1.0.0',
        description:
          'Modular commercial wholesale API covering Catalogue, Offers, Landed Cost, RFQs, Orders, Atomic Inventory, Shipments, Invoices/Payments, Governance, and AI Procurement Assistant.',
      },
      endpoints: [
        'GET /api/bootstrap',
        'GET /api/catalog',
        'GET /api/products/:id',
        'POST /api/compare',
        'POST /api/shortlist/toggle',
        'GET /api/rfqs',
        'POST /api/rfqs',
        'POST /api/rfqs/:id/quotes',
        'POST /api/rfqs/:id/questions',
        'POST /api/rfqs/:id/award',
        'GET /api/orders',
        'POST /api/orders/checkout',
        'POST /api/orders/:id/approve',
        'POST /api/orders/:id/cancel',
        'GET /api/inventory',
        'POST /api/inventory/receipt',
        'POST /api/inventory/withdraw-batch',
        'GET /api/shipments',
        'POST /api/shipments/dispatch',
        'POST /api/shipments/:id/deliver',
        'GET /api/invoices',
        'POST /api/invoices/:id/payments',
        'POST /api/invoices/:id/credit-notes',
        'GET /api/messages',
        'POST /api/messages/:threadId',
        'GET /api/documents',
        'POST /api/documents',
        'PATCH /api/orgs/:id',
        'PATCH /api/admin/config',
        'POST /api/admin/orgs/:id/verify',
        'POST /api/ai/procurement',
        'POST /api/demo/reset',
      ],
    });
  });

  router.get('/bootstrap', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    const activeOrg =
      db.organisations.find((o) => o.id === actor.orgId) ?? db.organisations[0];

    res.json({
      actor,
      activeOrg,
      organisations: db.organisations,
      users: db.users,
      products: db.products,
      offers: db.offers,
      rfqs: getAuthorizedRfqs(db, actor.orgId, actor.role),
      orders: getAuthorizedOrders(db, actor.orgId, actor.role),
      shipments: getAuthorizedShipments(db, actor.orgId, actor.role),
      invoices: getAuthorizedInvoices(db, actor.orgId, actor.role),
      inventory: db.inventory.map((rec) => ({
        ...rec,
        availableCases: availableCasesOf(rec),
      })),
      stockLedger: db.stockLedger,
      documents: getAuthorizedDocuments(db, actor.orgId, actor.role),
      threads: getAuthorizedThreads(db, actor.orgId, actor.role),
      shortlistOfferIds: db.shortlistOfferIdsByOrg[actor.orgId] ?? [],
      platformConfig: db.platformConfig,
    });
  });

  router.get('/catalog', (req, res) => {
    const db = getDatabase();
    const search = String(req.query['q'] ?? '').trim().toLowerCase();
    const category = String(req.query['category'] ?? '').trim();
    const destination = String(req.query['destination'] ?? '').trim();
    const region = String(req.query['region'] ?? '').trim();
    const incoterm = String(req.query['incoterm'] ?? '').trim();
    const verifiedOnly = req.query['verifiedOnly'] === 'true';
    const maxMoq = req.query['maxMoq'] ? Number(req.query['maxMoq']) : null;

    const enrichedOffers = db.offers
      .filter((offer) => offer.status === 'active')
      .map((offer) => {
        const product = db.products.find((p) => p.id === offer.productId)!;
        const seller = db.organisations.find((o) => o.id === offer.sellerOrgId)!;
        const pkg =
          product.packagingVersions.find((v) => v.version === offer.packagingVersion) ??
          product.packagingVersions[0];
        return { offer, product, seller, pkg };
      })
      .filter(({ offer, product, seller }) => {
        if (
          search &&
          !product.name.toLowerCase().includes(search) &&
          !product.brand.toLowerCase().includes(search) &&
          !product.sku.toLowerCase().includes(search) &&
          !seller.tradingName.toLowerCase().includes(search)
        ) {
          return false;
        }
        if (category && product.category !== category) return false;
        if (
          destination &&
          destination !== 'All' &&
          !offer.permittedDestinations.includes(destination)
        ) {
          return false;
        }
        if (region && seller.region !== region) return false;
        if (incoterm && offer.incoterm !== incoterm) return false;
        if (verifiedOnly && seller.verification.status !== 'verified') return false;
        if (maxMoq !== null && Number.isFinite(maxMoq) && offer.moqCases > maxMoq) {
          return false;
        }
        return true;
      });

    res.json({
      items: enrichedOffers,
      total: enrichedOffers.length,
    });
  });

  router.get('/products/:id', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    const product = db.products.find((p) => p.id === req.params.id);
    if (!product) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }
    const offers = db.offers
      .filter((o) => o.productId === product.id)
      .map((offer) => ({
        offer,
        seller: db.organisations.find((o) => o.id === offer.sellerOrgId)!,
        pkg:
          product.packagingVersions.find((v) => v.version === offer.packagingVersion) ??
          product.packagingVersions[0],
      }));
    const docs = getAuthorizedDocuments(db, actor.orgId, actor.role).filter(
      (d) => d.linkedEntityType === 'product' && d.linkedEntityId === product.id,
    );
    res.json({ product, offers, documents: docs });
  });

  router.post('/shortlist/toggle', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    const body = z.object({ offerId: z.string() }).parse(req.body);
    const current = db.shortlistOfferIdsByOrg[actor.orgId] ?? [];
    const exists = current.includes(body.offerId);
    db.shortlistOfferIdsByOrg[actor.orgId] = exists
      ? current.filter((id) => id !== body.offerId)
      : [...current, body.offerId];
    saveDatabase();
    res.json({ shortlistOfferIds: db.shortlistOfferIdsByOrg[actor.orgId] });
  });

  router.post('/compare', (req, res) => {
    try {
      const db = getDatabase();
      const body = z
        .object({
          offerIds: z.array(z.string()).min(1),
          cases: z.number().int().positive(),
          transportMode: z.enum(['sea', 'air', 'road', 'multimodal']).default('road'),
          displayCurrency: z.enum(['USD', 'GBP', 'EUR']).default('USD'),
        })
        .parse(req.body);

      const breakdowns = body.offerIds.map((offerId) => {
        const offer = db.offers.find((o) => o.id === offerId);
        if (!offer) throw new Error(`Offer ${offerId} not found`);
        const product = db.products.find((p) => p.id === offer.productId)!;
        const pkg =
          product.packagingVersions.find((v) => v.version === offer.packagingVersion) ??
          product.packagingVersions[0];
        return calculateLandedCost({
          offer,
          pkg,
          cases: Math.max(body.cases, offer.moqCases),
          transportMode: body.transportMode as TransportMode,
          displayCurrency: body.displayCurrency as CurrencyCode,
          fxRatesToUsd: db.platformConfig.fxRatesToUsd,
          fxFeeBps: db.platformConfig.fxFeeBps,
          platformFeeBps: db.platformConfig.marketplaceFeeBps,
        });
      });

      const ranked = rankLandedCostBreakdowns(breakdowns);
      res.json({ ranked });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- RFQs ---
  router.get('/rfqs', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    res.json({ rfqs: getAuthorizedRfqs(db, actor.orgId, actor.role) });
  });

  router.post('/rfqs', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const buyerOrg = db.organisations.find((o) => o.id === actor.orgId);
      if (!buyerOrg) throw new Error('Buyer organisation not found');

      const body = z
        .object({
          title: z.string().min(3),
          productId: z.string(),
          specification: z.string().default(''),
          quantity: z.number().int().positive(),
          packUnit: z.enum(['unit', 'inner_pack', 'case', 'pallet']).default('case'),
          permittedSubstitutions: z.boolean().default(false),
          destinationCountry: z.string().default('United Kingdom'),
          deliveryLocation: z.string().default(buyerOrg.deliveryLocations[0] ?? 'London DC'),
          requiredDeliveryDays: z.number().int().positive().default(30),
          preferredCurrency: z.enum(['USD', 'GBP', 'EUR']).default('USD'),
          incoterm: z.enum(['EXW', 'FCA', 'FOB', 'CIF', 'DAP', 'DDP']).default('FCA'),
          transportMode: z.enum(['sea', 'air', 'road', 'multimodal']).default('road'),
          requiredDocuments: z.array(z.string()).default(['SDS', 'COA']),
          invitedSellerIds: z.array(z.string()).default(['org_aureom_direct', 'org_nordic_rhine']),
          publishImmediately: z.boolean().default(true),
        })
        .parse(req.body);

      const rfq = createRfq({
        db,
        buyerOrg,
        title: body.title,
        productId: body.productId,
        specification: body.specification,
        quantity: body.quantity,
        packUnit: body.packUnit as PackUnit,
        permittedSubstitutions: body.permittedSubstitutions,
        destinationCountry: body.destinationCountry,
        deliveryLocation: body.deliveryLocation,
        requiredDeliveryDays: body.requiredDeliveryDays,
        preferredCurrency: body.preferredCurrency as CurrencyCode,
        incoterm: body.incoterm as Incoterm,
        transportMode: body.transportMode as TransportMode,
        requiredDocuments: body.requiredDocuments,
        invitedSellerIds: body.invitedSellerIds,
        publishImmediately: body.publishImmediately,
      });
      saveDatabase();
      res.status(201).json({ rfq });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/rfqs/:id/quotes', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const sellerOrg = db.organisations.find((o) => o.id === actor.orgId);
      if (!sellerOrg) throw new Error('Seller organisation not found');
      if (actor.role !== 'seller_manager' && actor.role !== 'org_admin' && actor.role !== 'platform_admin') {
        throw new ForbiddenOrgAccessError('Only seller managers or org admins can submit quotations.');
      }

      const body = z
        .object({
          unitPriceMinorPerCase: z.number().int().positive(),
          currency: z.enum(['USD', 'GBP', 'EUR']).default('USD'),
          leadTimeDays: z.number().int().positive(),
          incoterm: z.enum(['EXW', 'FCA', 'FOB', 'CIF', 'DAP', 'DDP']),
          namedPlace: z.string().min(2),
          transportMode: z.enum(['sea', 'air', 'road', 'multimodal']).default('road'),
          freightTotalMinor: z.number().int().nonnegative().nullable().default(0),
          insuranceMinor: z.number().int().nonnegative().nullable().default(0),
          dutyRateBps: z.number().int().nonnegative().nullable().default(0),
          importTaxRateBps: z.number().int().nonnegative().nullable().default(2000),
          paymentTerms: z.string().default('Net 30 days'),
          notes: z.string().default(''),
        })
        .parse(req.body);

      const quote = submitRfqQuoteVersion({
        db,
        rfqId: req.params.id,
        sellerOrg,
        unitPriceMinorPerCase: body.unitPriceMinorPerCase,
        currency: body.currency as CurrencyCode,
        leadTimeDays: body.leadTimeDays,
        incoterm: body.incoterm as Incoterm,
        namedPlace: body.namedPlace,
        transportMode: body.transportMode as TransportMode,
        freightTotalMinor: body.freightTotalMinor,
        insuranceMinor: body.insuranceMinor,
        dutyRateBps: body.dutyRateBps,
        importTaxRateBps: body.importTaxRateBps,
        paymentTerms: body.paymentTerms,
        notes: body.notes,
      });
      saveDatabase();
      res.status(201).json({ quote });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/rfqs/:id/questions', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const rfq = db.rfqs.find((r) => r.id === req.params.id);
      if (!rfq) throw new Error('RFQ not found');
      const org = db.organisations.find((o) => o.id === actor.orgId);
      const body = z
        .object({
          question: z.string().min(3).optional(),
          questionId: z.string().optional(),
          answer: z.string().optional(),
        })
        .parse(req.body);

      if (body.questionId && body.answer) {
        assertOrgAccess(actor.orgId, actor.role, [rfq.buyerOrgId], 'RFQ answer');
        const q = rfq.questions.find((item) => item.id === body.questionId);
        if (!q) throw new Error('Question not found');
        q.answer = body.answer;
      } else if (body.question) {
        rfq.questions.push({
          id: `rfqq_${Date.now()}`,
          authorOrgId: actor.orgId,
          authorName: org?.tradingName ?? actor.orgId,
          question: body.question,
          createdAt: new Date().toISOString(),
        });
      }
      rfq.updatedAt = new Date().toISOString();
      saveDatabase();
      res.json({ rfq });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/rfqs/:id/award', async (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const rfq = db.rfqs.find((r) => r.id === req.params.id);
      if (!rfq) throw new Error('RFQ not found');
      assertOrgAccess(actor.orgId, actor.role, [rfq.buyerOrgId], `RFQ ${rfq.id}`);

      const body = z
        .object({
          quoteId: z.string(),
          businessUnit: z.string().default('UK Personal Care'),
        })
        .parse(req.body);

      const order = await createOrderFromAwardedRfq({
        db,
        rfqId: rfq.id,
        quoteId: body.quoteId,
        actorId: actor.userId,
        businessUnit: body.businessUnit,
      });
      saveDatabase();
      res.status(201).json({ order, rfq });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- Orders & Approvals ---
  router.get('/orders', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    res.json({ orders: getAuthorizedOrders(db, actor.orgId, actor.role) });
  });

  router.post('/orders/checkout', async (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const buyerOrg = db.organisations.find((o) => o.id === actor.orgId);
      if (!buyerOrg) throw new Error('Buyer organisation not found');

      const body = z
        .object({
          businessUnit: z.string().default(buyerOrg.businessUnits[0] ?? 'Wholesale'),
          destinationCountry: z.string().default('United Kingdom'),
          deliveryLocation: z
            .string()
            .default(buyerOrg.deliveryLocations[0] ?? 'London Warehouse'),
          orderCurrency: z.enum(['USD', 'GBP', 'EUR']).default('USD'),
          items: z
            .array(
              z.object({
                offerId: z.string(),
                cases: z.number().int().positive(),
                transportMode: z
                  .enum(['sea', 'air', 'road', 'multimodal'])
                  .optional(),
              }),
            )
            .min(1),
        })
        .parse(req.body);

      const orders = await createOrdersFromBasket({
        db,
        buyerOrg,
        actorId: actor.userId,
        businessUnit: body.businessUnit,
        deliveryLocation: body.deliveryLocation,
        destinationCountry: body.destinationCountry,
        orderCurrency: body.orderCurrency as CurrencyCode,
        items: body.items,
      });
      saveDatabase();
      res.status(201).json({ orders });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/orders/:id/approve', async (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const order = db.orders.find((o) => o.id === req.params.id);
      if (!order) throw new Error('Order not found');
      assertOrgAccess(actor.orgId, actor.role, [order.buyerOrgId], `Order ${order.id}`);

      if (
        actor.role !== 'procurement_approver' &&
        actor.role !== 'org_admin' &&
        actor.role !== 'platform_admin'
      ) {
        throw new ForbiddenOrgAccessError(
          'Only a Procurement Approver or Org Admin may approve or reject held orders.',
        );
      }

      const body = z
        .object({
          approved: z.boolean(),
          comment: z.string().optional(),
        })
        .parse(req.body);

      const actorUser = db.users.find((u) => u.id === actor.userId);
      const updated = await approveOrder({
        db,
        order,
        approverUserId: actor.userId,
        approverName: actorUser?.name ?? 'Procurement Approver',
        approved: body.approved,
        comment: body.comment,
      });
      saveDatabase();
      res.json({ order: updated });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/orders/:id/cancel', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const order = db.orders.find((o) => o.id === req.params.id);
      if (!order) throw new Error('Order not found');
      assertOrgAccess(
        actor.orgId,
        actor.role,
        [order.buyerOrgId, order.sellerOrgId],
        `Order ${order.id}`,
      );
      if (order.status === 'Dispatched' || order.status === 'Delivered' || order.status === 'Closed') {
        throw new Error(`Order in status ${order.status} cannot be cancelled.`);
      }
      const body = z.object({ reason: z.string().default('Cancelled by authorised user') }).parse(req.body);

      // Release reserved stock back to available
      for (const resId of order.reservationIds) {
        const reservation = db.reservations.find((r) => r.id === resId);
        if (reservation && (reservation.status === 'active' || reservation.status === 'allocated')) {
          reservation.status = 'released';
          const inv = db.inventory.find((i) => i.id === reservation.inventoryRecordId);
          if (inv) {
            inv.reservedCases = Math.max(0, inv.reservedCases - reservation.cases);
            db.stockLedger.push({
              id: `led_${Date.now()}`,
              timestamp: new Date().toISOString(),
              inventoryRecordId: inv.id,
              sku: inv.sku,
              batchNumber: inv.batchNumber,
              movementType: 'adjustment',
              deltaCases: reservation.cases,
              referenceId: order.id,
              actorId: actor.userId,
              note: `Released reservation on order cancellation`,
            });
          }
        }
      }

      order.status = 'Cancelled';
      order.cancellationReason = body.reason;
      order.updatedAt = new Date().toISOString();
      saveDatabase();
      res.json({ order });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- Inventory & Traceability ---
  router.get('/inventory', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    const sellerOnly = req.query['sellerOnly'] === 'true';
    const records = db.inventory
      .filter((r) => !sellerOnly || actor.role === 'platform_admin' || r.sellerOrgId === actor.orgId)
      .map((rec) => ({
        ...rec,
        availableCases: availableCasesOf(rec),
      }));
    res.json({ inventory: records, ledger: db.stockLedger });
  });

  router.post('/inventory/receipt', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const body = z
        .object({
          inventoryRecordId: z.string(),
          casesAdded: z.number().int().positive(),
          note: z.string().default('Warehouse stock receipt'),
        })
        .parse(req.body);

      const rec = db.inventory.find((i) => i.id === body.inventoryRecordId);
      if (!rec) throw new Error('Inventory record not found');
      assertOrgAccess(actor.orgId, actor.role, [rec.sellerOrgId], 'Inventory receipt');

      rec.onHandCases += body.casesAdded;
      rec.updatedAt = new Date().toISOString();
      db.stockLedger.unshift({
        id: `led_${Date.now()}`,
        timestamp: rec.updatedAt,
        inventoryRecordId: rec.id,
        sku: rec.sku,
        batchNumber: rec.batchNumber,
        movementType: 'receipt',
        deltaCases: body.casesAdded,
        referenceId: `RCV-${Date.now().toString().slice(-5)}`,
        actorId: actor.userId,
        note: body.note,
      });
      saveDatabase();
      res.json({ record: { ...rec, availableCases: availableCasesOf(rec) } });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/inventory/withdraw-batch', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const body = z
        .object({
          batchNumber: z.string(),
          reason: z.string().min(3),
        })
        .parse(req.body);

      const matching = db.inventory.filter((i) => i.batchNumber === body.batchNumber);
      if (!matching.length) throw new Error('Batch not found');
      assertOrgAccess(
        actor.orgId,
        actor.role,
        matching.map((m) => m.sellerOrgId),
        `Batch ${body.batchNumber}`,
      );

      const affected = withdrawBatch({
        inventory: db.inventory,
        ledger: db.stockLedger,
        batchNumber: body.batchNumber,
        reason: body.reason,
        actorId: actor.userId,
      });
      saveDatabase();
      res.json({ affected });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- Shipments ---
  router.get('/shipments', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    res.json({ shipments: getAuthorizedShipments(db, actor.orgId, actor.role) });
  });

  router.post('/shipments/dispatch', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const body = z
        .object({
          orderId: z.string(),
          carrier: z.string().default('EuroFreight Ro-Ro Express (Simulated)'),
          lineDispatches: z
            .array(
              z.object({
                orderLineId: z.string(),
                cases: z.number().int().positive(),
              }),
            )
            .min(1),
        })
        .parse(req.body);

      const order = db.orders.find((o) => o.id === body.orderId);
      if (!order) throw new Error('Order not found');
      assertOrgAccess(actor.orgId, actor.role, [order.sellerOrgId], `Order ${order.id} dispatch`);

      const shipment = createPartialOrFullShipment({
        db,
        orderId: order.id,
        lineDispatches: body.lineDispatches,
        carrier: body.carrier,
        actorId: actor.userId,
      });
      saveDatabase();
      res.status(201).json({ shipment, order });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/shipments/:id/deliver', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const shipment = db.shipments.find((s) => s.id === req.params.id);
      if (!shipment) throw new Error('Shipment not found');
      assertOrgAccess(
        actor.orgId,
        actor.role,
        [shipment.buyerOrgId, shipment.sellerOrgId],
        `Shipment ${shipment.id}`,
      );

      const body = z
        .object({
          orderLineId: z.string(),
          deliveredCases: z.number().int().nonnegative(),
          damagedCases: z.number().int().nonnegative().default(0),
          reason: z.string().default(''),
          autoIssueCreditNote: z.boolean().default(true),
        })
        .parse(req.body);

      const result = recordDeliveryAndDiscrepancy({
        db,
        shipmentId: shipment.id,
        orderLineId: body.orderLineId,
        deliveredCases: body.deliveredCases,
        damagedCases: body.damagedCases,
        reason: body.reason,
        actorId: actor.userId,
        autoIssueCreditNote: body.autoIssueCreditNote,
      });
      saveDatabase();
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- Invoices & Payments ---
  router.get('/invoices', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    res.json({ invoices: getAuthorizedInvoices(db, actor.orgId, actor.role) });
  });

  router.post('/invoices/:id/payments', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const invoice = db.invoices.find((i) => i.id === req.params.id);
      if (!invoice) throw new Error('Invoice not found');
      assertOrgAccess(
        actor.orgId,
        actor.role,
        [invoice.buyerOrgId, invoice.sellerOrgId],
        `Invoice ${invoice.id}`,
      );

      const body = z
        .object({
          idempotencyKey: z.string().min(4),
          method: z
            .enum(['simulated_bank_transfer', 'hosted_card_adapter'])
            .default('simulated_bank_transfer'),
          amountMinor: z.number().int().positive(),
          currency: z.enum(['USD', 'GBP', 'EUR']),
          reference: z.string().default('BACS-REF-2026'),
        })
        .parse(req.body);

      const result = recordPaymentIdempotent({
        db,
        invoiceId: invoice.id,
        idempotencyKey: body.idempotencyKey,
        method: body.method,
        amountMinor: body.amountMinor,
        currency: body.currency as CurrencyCode,
        reference: body.reference,
      });
      saveDatabase();
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/invoices/:id/credit-notes', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const invoice = db.invoices.find((i) => i.id === req.params.id);
      if (!invoice) throw new Error('Invoice not found');
      assertOrgAccess(actor.orgId, actor.role, [invoice.sellerOrgId], `Invoice ${invoice.id} credit note`);

      const body = z
        .object({
          amountMinor: z.number().int().positive(),
          reason: z.string().min(3),
          discrepancyId: z.string().optional(),
        })
        .parse(req.body);

      const result = issueCreditNote({
        db,
        invoiceId: invoice.id,
        amountMinor: body.amountMinor,
        reason: body.reason,
        issuedBy: actor.userId,
        discrepancyId: body.discrepancyId,
      });
      saveDatabase();
      res.status(201).json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- Messages & Documents ---
  router.get('/messages', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    res.json({ threads: getAuthorizedThreads(db, actor.orgId, actor.role) });
  });

  router.post('/messages/:threadId', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const thread = db.threads.find((t) => t.id === req.params.threadId);
      if (!thread) throw new Error('Message thread not found');
      assertOrgAccess(actor.orgId, actor.role, thread.participantOrgIds, 'Message thread');

      const body = z
        .object({
          body: z.string().min(1),
          attachmentDocId: z.string().optional(),
        })
        .parse(req.body);

      const user = db.users.find((u) => u.id === actor.userId);
      thread.messages.push({
        id: `msg_${Date.now()}`,
        senderOrgId: actor.orgId,
        senderName: user?.name ?? actor.orgId,
        senderRole: actor.role,
        body: body.body,
        attachmentDocId: body.attachmentDocId,
        createdAt: new Date().toISOString(),
      });
      thread.updatedAt = new Date().toISOString();
      saveDatabase();
      res.status(201).json({ thread });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.get('/documents', (req, res) => {
    const db = getDatabase();
    const actor = getActor(req);
    res.json({ documents: getAuthorizedDocuments(db, actor.orgId, actor.role) });
  });

  router.post('/documents', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const body = z
        .object({
          linkedEntityType: z.enum(['product', 'rfq', 'order', 'shipment', 'org']),
          linkedEntityId: z.string(),
          title: z.string().min(3),
          docType: z.enum([
            'SDS',
            'COA',
            'ISO_Certificate',
            'Commercial_Invoice',
            'Packing_List',
            'Customs_Declaration',
            'Handling_Guide',
          ]),
          issuer: z.string().min(2),
          summary: z.string().min(3),
          visibility: z.enum(['public', 'authorised_parties', 'private_org']).default('authorised_parties'),
        })
        .parse(req.body);

      const existingVersions = db.documents.filter(
        (d) =>
          d.linkedEntityId === body.linkedEntityId &&
          d.docType === body.docType &&
          d.organisationId === actor.orgId,
      );
      const nextVer = existingVersions.length
        ? Math.max(...existingVersions.map((d) => d.version)) + 1
        : 1;

      const user = db.users.find((u) => u.id === actor.userId);
      const doc = {
        id: `doc_${Date.now()}`,
        organisationId: actor.orgId,
        linkedEntityType: body.linkedEntityType,
        linkedEntityId: body.linkedEntityId,
        title: body.title,
        docType: body.docType,
        version: nextVer,
        issuer: body.issuer,
        uploadedBy: user?.name ?? actor.userId,
        uploadedAt: new Date().toISOString(),
        isSystemTemplate: false,
        isOfficialCertificate: false,
        visibility: body.visibility,
        summary: body.summary,
      };
      db.documents.unshift(doc);
      saveDatabase();
      res.status(201).json({ document: doc });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- Business Settings & Platform Admin ---
  router.patch('/orgs/:id', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const org = db.organisations.find((o) => o.id === req.params.id);
      if (!org) throw new Error('Organisation not found');
      assertOrgAccess(actor.orgId, actor.role, [org.id], `Organisation ${org.id}`);

      const body = z
        .object({
          preferredCurrency: z.enum(['USD', 'GBP', 'EUR']).optional(),
          preferredLanguage: z.string().optional(),
          approvalThresholdMinor: z.number().int().nonnegative().optional(),
          paymentTerms: z.string().optional(),
          returnPolicyDays: z.number().int().positive().optional(),
        })
        .parse(req.body);

      if (body.preferredCurrency) org.preferredCurrency = body.preferredCurrency;
      if (body.preferredLanguage) org.preferredLanguage = body.preferredLanguage;
      if (body.approvalThresholdMinor !== undefined) {
        org.approvalThresholdMinor = body.approvalThresholdMinor;
      }
      if (body.paymentTerms) org.paymentTerms = body.paymentTerms;
      if (body.returnPolicyDays) org.returnPolicyDays = body.returnPolicyDays;
      saveDatabase();
      res.json({ organisation: org });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.patch('/admin/config', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      if (actor.role !== 'platform_admin') {
        throw new ForbiddenOrgAccessError('Platform admin role required.');
      }

      const body = z
        .object({
          marketplaceFeeBps: z.number().int().min(0).max(2000).optional(),
          defaultReservationTtlMinutes: z.number().int().min(5).max(1440).optional(),
          allowedCurrencies: z.array(z.enum(['USD', 'GBP', 'EUR'])).optional(),
          categories: z.array(z.string()).optional(),
          summary: z.string().default('Updated platform configuration'),
        })
        .parse(req.body);

      if (body.marketplaceFeeBps !== undefined) {
        db.platformConfig.marketplaceFeeBps = body.marketplaceFeeBps;
      }
      if (body.defaultReservationTtlMinutes !== undefined) {
        db.platformConfig.defaultReservationTtlMinutes = body.defaultReservationTtlMinutes;
      }
      if (body.allowedCurrencies) {
        db.platformConfig.allowedCurrencies = body.allowedCurrencies as CurrencyCode[];
      }
      if (body.categories) {
        db.platformConfig.categories = body.categories as ProductCategory[];
      }

      db.platformConfig.configHistory.unshift({
        id: `cfg_${Date.now()}`,
        changedBy: actor.userId,
        changedAt: new Date().toISOString(),
        summary: body.summary,
      });
      saveDatabase();
      res.json({ platformConfig: db.platformConfig });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/admin/orgs/:id/verify', (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      if (actor.role !== 'platform_admin') {
        throw new ForbiddenOrgAccessError('Platform admin role required to update verification.');
      }
      const org = db.organisations.find((o) => o.id === req.params.id);
      if (!org) throw new Error('Organisation not found');

      const body = z
        .object({
          status: z.enum(['verified', 'amber_exception', 'pending']),
          notes: z.string().min(3),
          checkedItem: z.string().optional(),
        })
        .parse(req.body);

      org.verification.status = body.status;
      org.verification.notes = body.notes;
      if (body.checkedItem) org.verification.checkedItem = body.checkedItem;
      org.verification.verifiedBy = actor.userId;
      org.verification.verifiedAt = new Date().toISOString();
      saveDatabase();
      res.json({ organisation: org });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- AI Procurement Assistant ---
  router.post('/ai/procurement', async (req, res) => {
    try {
      const db = getDatabase();
      const actor = getActor(req);
      const body = z
        .object({
          prompt: z.string().min(2),
          displayCurrency: z.enum(['USD', 'GBP', 'EUR']).default('USD'),
        })
        .parse(req.body);

      const result = await runProcurementAssistant({
        db,
        prompt: body.prompt,
        actorOrgId: actor.orgId,
        actorRole: actor.role,
        displayCurrency: body.displayCurrency as CurrencyCode,
      });
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/demo/reset', (_req, res) => {
    const db = resetDatabaseToSeed();
    res.json({ reset: true, rfqCount: db.rfqs.length, orderCount: db.orders.length });
  });

  return router;
}
