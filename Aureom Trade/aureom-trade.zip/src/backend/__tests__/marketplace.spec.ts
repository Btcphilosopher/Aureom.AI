import { describe, expect, it } from 'vitest';
import { createSeedDatabase } from '../domains/seed';
import {
  CurrencyMismatchError,
  addMoney,
  convertCurrencyMinor,
} from '../domains/money';
import {
  PackagingValidationError,
  convertToCases,
  resolveTierPriceMinor,
  validateOrderQuantity,
} from '../domains/packaging';
import {
  calculateLandedCost,
  rankLandedCostBreakdowns,
  validateIncotermForTransport,
} from '../domains/landed-cost';
import {
  InsufficientStockError,
  availableCasesOf,
  reserveStockAtomic,
} from '../domains/inventory';
import {
  approveOrder,
  createOrderFromAwardedRfq,
  createOrdersFromBasket,
} from '../domains/orders';
import { getAuthorizedRfqs, submitRfqQuoteVersion } from '../domains/rfqs';
import { recordPaymentIdempotent } from '../domains/payments';
import {
  createPartialOrFullShipment,
  recordDeliveryAndDiscrepancy,
} from '../domains/shipments';
import { detectProhibitedAutonomousAction } from '../domains/ai-assistant';
import {
  ForbiddenOrgAccessError,
  assertOrgAccess,
  getAuthorizedDocuments,
} from '../store';

describe('Aureom Trade Domain & Security Suite', () => {
  it('1. Enforces cross-organisation access boundaries and private RFQ quotes', () => {
    const db = createSeedDatabase();
    // Nordic & Rhine should ONLY see its own quote on RFQ-2026-041, never Aureom Direct's quote
    const nordicRfqs = getAuthorizedRfqs(db, 'org_nordic_rhine', 'seller_manager');
    const rfq = nordicRfqs.find((r) => r.id === 'RFQ-2026-041');
    expect(rfq).toBeDefined();
    expect(rfq!.quotes.length).toBe(1);
    expect(rfq!.quotes[0].sellerOrgId).toBe('org_nordic_rhine');

    // Unrelated org cannot access buyer's order/RFQ action
    expect(() =>
      assertOrgAccess('org_anatolia_oils', 'seller_manager', ['org_albion_uk'], 'RFQ award'),
    ).toThrow(ForbiddenOrgAccessError);
  });

  it('2. Performs exact packaging conversions and rejects uneven units', () => {
    const db = createSeedDatabase();
    const bodyWash = db.products.find((p) => p.id === 'prod_body_wash')!;
    const pkgV2 = bodyWash.packagingVersions.find((v) => v.version === 2)!;

    expect(convertToCases(240, 'unit', pkgV2)).toBe(10);
    expect(convertToCases(8, 'inner_pack', pkgV2)).toBe(2);
    expect(convertToCases(2, 'pallet', pkgV2)).toBe(128);
    expect(() => convertToCases(25, 'unit', pkgV2)).toThrow(PackagingValidationError);
  });

  it('3. Validates minimum order quantities and case increments', () => {
    expect(() => validateOrderQuantity(30, 40, 10)).toThrow(PackagingValidationError);
    expect(() => validateOrderQuantity(45, 40, 10)).toThrow(PackagingValidationError);
    expect(() => validateOrderQuantity(60, 40, 10)).not.toThrow();
  });

  it('4. Resolves tiered pricing accurately across volume brackets', () => {
    const db = createSeedDatabase();
    const offer = db.offers.find((o) => o.id === 'off_bw_aureom_uk')!;
    expect(resolveTierPriceMinor(offer.tiers, 40).unitPriceMinorPerCase).toBe(2880);
    expect(resolveTierPriceMinor(offer.tiers, 250).unitPriceMinorPerCase).toBe(2690);
    expect(resolveTierPriceMinor(offer.tiers, 1200).unitPriceMinorPerCase).toBe(2450);
  });

  it('5. Tracks quote versions without overwriting history', () => {
    const db = createSeedDatabase();
    const seller = db.organisations.find((o) => o.id === 'org_nordic_rhine')!;
    const updated = submitRfqQuoteVersion({
      db,
      rfqId: 'RFQ-2026-041',
      sellerOrg: seller,
      unitPriceMinorPerCase: 2490,
      currency: 'USD',
      leadTimeDays: 9,
      incoterm: 'DAP',
      namedPlace: 'Felixstowe DC, UK',
      transportMode: 'road',
      freightTotalMinor: 0,
      insuranceMinor: 8900,
      dutyRateBps: 0,
      importTaxRateBps: 2000,
      paymentTerms: 'Net 30 days',
      notes: 'Revised quote v2',
    });
    expect(updated.currentVersion).toBe(2);
    expect(updated.versions.length).toBe(2);
    expect(updated.versions[0].unitPriceMinorPerCase).toBe(2580);
    expect(updated.versions[1].unitPriceMinorPerCase).toBe(2490);
  });

  it('6. Requires procurement approval above org threshold and allocates on approval', async () => {
    const db = createSeedDatabase();
    const buyer = db.organisations.find((o) => o.id === 'org_albion_uk')!;
    const orders = await createOrdersFromBasket({
      db,
      buyerOrg: buyer,
      actorId: 'usr_claire_buyer',
      businessUnit: 'UK Personal Care',
      deliveryLocation: buyer.deliveryLocations[0],
      destinationCountry: 'United Kingdom',
      orderCurrency: 'USD',
      items: [{ offerId: 'off_bw_aureom_uk', cases: 300 }],
    });
    expect(orders[0].status).toBe('Awaiting Approval');
    expect(orders[0].approval.required).toBe(true);

    const approved = await approveOrder({
      db,
      order: orders[0],
      approverUserId: 'usr_marcus_approver',
      approverName: 'Marcus Vance',
      approved: true,
      comment: 'Approved Q4 replenishment',
    });
    expect(approved.status).toBe('Allocated');
    expect(approved.lines[0].casesAllocated).toBe(300);
  });

  it('7. Prevents concurrent stock reservations from double-allocating limited inventory', async () => {
    const db = createSeedDatabase();
    // Available AUR-PC-BW250 at Aureom Direct is 1400 + 985 = 2385 cases
    const p1 = reserveStockAtomic({
      inventory: db.inventory,
      reservations: db.reservations,
      ledger: db.stockLedger,
      sellerOrgId: 'org_aureom_direct',
      sku: 'AUR-PC-BW250',
      cases: 1500,
      orderId: 'ORD-CONC-1',
      actorId: 'usr_claire_buyer',
      ttlMinutes: 60,
    });
    const p2 = reserveStockAtomic({
      inventory: db.inventory,
      reservations: db.reservations,
      ledger: db.stockLedger,
      sellerOrgId: 'org_aureom_direct',
      sku: 'AUR-PC-BW250',
      cases: 1500,
      orderId: 'ORD-CONC-2',
      actorId: 'usr_claire_buyer',
      ttlMinutes: 60,
    });

    const results = await Promise.allSettled([p1, p2]);
    const fulfilled = results.filter((r) => r.status === 'fulfilled');
    const rejected = results.filter((r) => r.status === 'rejected');
    expect(fulfilled.length).toBe(1);
    expect(rejected.length).toBe(1);
    expect((rejected[0] as PromiseRejectedResult).reason).toBeInstanceOf(
      InsufficientStockError,
    );
    const totalRemaining = db.inventory
      .filter((i) => i.sellerOrgId === 'org_aureom_direct' && i.sku === 'AUR-PC-BW250')
      .reduce((s, r) => s + availableCasesOf(r), 0);
    expect(totalRemaining).toBe(885);
  });

  it('8. Splits multi-seller baskets into seller-specific orders under one buyer group', async () => {
    const db = createSeedDatabase();
    const buyer = db.organisations.find((o) => o.id === 'org_albion_uk')!;
    const orders = await createOrdersFromBasket({
      db,
      buyerOrg: buyer,
      actorId: 'usr_claire_buyer',
      businessUnit: 'UK Grocery & Household',
      deliveryLocation: buyer.deliveryLocations[0],
      destinationCountry: 'United Kingdom',
      orderCurrency: 'USD',
      items: [
        { offerId: 'off_bw_aureom_uk', cases: 40 },
        { offerId: 'off_ll_nordic_de', cases: 60 },
      ],
    });
    expect(orders.length).toBe(2);
    expect(orders[0].buyerOrderGroupId).toBe(orders[1].buyerOrderGroupId);
    expect(orders[0].sellerOrgId).not.toBe(orders[1].sellerOrgId);
  });

  it('9. Enforces integer currency precision and throws on mixed-currency arithmetic', () => {
    expect(() =>
      addMoney({ minorUnits: 1000, currency: 'USD' }, { minorUnits: 1000, currency: 'GBP' }),
    ).toThrow(CurrencyMismatchError);

    const conv = convertCurrencyMinor(10000, 'GBP', 'USD', { USD: 1, GBP: 1.27, EUR: 1.08 }, 45);
    expect(conv.convertedMinor).toBe(12757);
  });

  it('10. Flags missing landed-cost terms and validates sea-only Incoterms', () => {
    const db = createSeedDatabase();
    const bw = db.products.find((p) => p.id === 'prod_body_wash')!;
    const completeOffer = db.offers.find((o) => o.id === 'off_bw_aureom_uk')!;
    const incompleteOffer = db.offers.find((o) => o.id === 'off_bw_pacific_us')!;

    const lcComplete = calculateLandedCost({
      offer: completeOffer,
      pkg: bw.packagingVersions[1],
      cases: 100,
      transportMode: 'road',
      displayCurrency: 'USD',
      fxRatesToUsd: db.platformConfig.fxRatesToUsd,
      fxFeeBps: db.platformConfig.fxFeeBps,
      platformFeeBps: db.platformConfig.marketplaceFeeBps,
    });
    const lcIncomplete = calculateLandedCost({
      offer: incompleteOffer,
      pkg: bw.packagingVersions[0],
      cases: 100,
      transportMode: 'sea',
      displayCurrency: 'USD',
      fxRatesToUsd: db.platformConfig.fxRatesToUsd,
      fxFeeBps: db.platformConfig.fxFeeBps,
      platformFeeBps: db.platformConfig.marketplaceFeeBps,
    });

    expect(lcIncomplete.isComplete).toBe(false);
    expect(lcIncomplete.missingTerms).toContain('International freight quote missing');
    expect(lcComplete.isGuaranteedDeliveredPrice).toBe(false);

    const ranked = rankLandedCostBreakdowns([lcIncomplete, lcComplete]);
    // Complete offer must rank ahead of incomplete offer even though incomplete offer had lower goods price
    expect(ranked[0].offerId).toBe(completeOffer.id);

    const airFob = validateIncotermForTransport('FOB', 'air');
    expect(airFob.valid).toBe(false);
  });

  it('11. Deduplicates duplicate payment events using idempotency keys', async () => {
    const db = createSeedDatabase();
    const order = await createOrderFromAwardedRfq({
      db,
      rfqId: 'RFQ-2026-041',
      quoteId: 'qt_aureom_041',
      actorId: 'usr_claire_buyer',
      businessUnit: 'UK Personal Care',
    });
    await approveOrder({
      db,
      order,
      approverUserId: 'usr_marcus_approver',
      approverName: 'Marcus Vance',
      approved: true,
    });
    const invoice = db.invoices.find((i) => i.orderId === order.id)!;

    const first = recordPaymentIdempotent({
      db,
      invoiceId: invoice.id,
      idempotencyKey: 'PAY-IDEMP-001',
      method: 'simulated_bank_transfer',
      amountMinor: 1500000,
      currency: 'USD',
      reference: 'FPS-9012',
    });
    const duplicate = recordPaymentIdempotent({
      db,
      invoiceId: invoice.id,
      idempotencyKey: 'PAY-IDEMP-001',
      method: 'simulated_bank_transfer',
      amountMinor: 1500000,
      currency: 'USD',
      reference: 'FPS-9012',
    });

    expect(first.deduplicated).toBe(false);
    expect(duplicate.deduplicated).toBe(true);
    expect(invoice.payments.length).toBe(1);
    expect(invoice.paidMinor).toBe(1500000);
  });

  it('12. Supports partial shipments, delivery discrepancies, and automatic credit notes', async () => {
    const db = createSeedDatabase();
    const order = await createOrderFromAwardedRfq({
      db,
      rfqId: 'RFQ-2026-041',
      quoteId: 'qt_aureom_041',
      actorId: 'usr_claire_buyer',
      businessUnit: 'UK Personal Care',
    });
    await approveOrder({
      db,
      order,
      approverUserId: 'usr_marcus_approver',
      approverName: 'Marcus Vance',
      approved: true,
    });

    const shipment = createPartialOrFullShipment({
      db,
      orderId: order.id,
      carrier: 'Aureom UK Fleet',
      actorId: 'usr_sam_warehouse',
      lineDispatches: [{ orderLineId: order.lines[0].id, cases: 600 }],
    });
    expect(order.status).toBe('Partially Dispatched');

    const delivery = recordDeliveryAndDiscrepancy({
      db,
      shipmentId: shipment.id,
      orderLineId: order.lines[0].id,
      deliveredCases: 585,
      damagedCases: 5,
      reason: '15 cases short-shipped, 5 crushed cartons',
      actorId: 'usr_claire_buyer',
      autoIssueCreditNote: true,
    });
    expect(delivery.discrepancy?.shortageCases).toBe(15);
    expect(delivery.discrepancy?.damagedCases).toBe(5);
    expect(delivery.creditNoteId).toBeDefined();
    expect(order.status).toBe('Disputed');
  });

  it('13. Restricts private/authorised documents to permitted organisations', () => {
    const db = createSeedDatabase();
    const anatoliaDocs = getAuthorizedDocuments(db, 'org_anatolia_oils', 'seller_manager');
    // Anatolia is NOT involved in Body Wash RFQ/Orders, so authorised-only COA should not be exposed
    expect(anatoliaDocs.some((d) => d.id === 'doc_coa_bodywash_b204')).toBe(false);

    const albionDocs = getAuthorizedDocuments(db, 'org_albion_uk', 'buyer');
    expect(albionDocs.some((d) => d.id === 'doc_coa_bodywash_b204')).toBe(true);
  });

  it('14. Blocks prohibited autonomous AI actions', () => {
    expect(detectProhibitedAutonomousAction('Award the contract to Aureom Direct right now')).not.toBeNull();
    expect(detectProhibitedAutonomousAction('Change bank details to IBAN GB991234')).not.toBeNull();
    expect(detectProhibitedAutonomousAction('Approve supplier Pacific Grove')).not.toBeNull();
    expect(detectProhibitedAutonomousAction('Compare landed cost for 1200 cases of body wash')).toBeNull();
  });
});
