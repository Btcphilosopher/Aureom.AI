export type CurrencyCode = 'USD' | 'GBP' | 'EUR';
export type Incoterm = 'EXW' | 'FCA' | 'FOB' | 'CIF' | 'DAP' | 'DDP';
export type TransportMode = 'sea' | 'air' | 'road' | 'multimodal';
export type PackUnit = 'unit' | 'inner_pack' | 'case' | 'pallet';

export type UserRole =
  | 'org_admin'
  | 'buyer'
  | 'procurement_approver'
  | 'seller_manager'
  | 'warehouse_user'
  | 'finance_user'
  | 'platform_admin';

export type ProductCategory =
  | 'Personal care'
  | 'Home care'
  | 'Food & beverage'
  | 'Health & wellbeing'
  | 'Paper & packaging';

export type SupplierRegion =
  | 'Europe'
  | 'Asia Pacific'
  | 'Americas'
  | 'Middle East & Africa';

export interface VerificationRecord {
  status: 'verified' | 'amber_exception' | 'pending';
  checkedItem: string;
  verifiedBy: string;
  verifiedAt: string;
  notes: string;
  disclaimer: string;
}

export interface Organisation {
  id: string;
  legalName: string;
  tradingName: string;
  kind: 'first_party' | 'buyer' | 'seller' | 'dual';
  countryCode: string;
  countryName: string;
  region: SupplierRegion;
  registeredAddress: string;
  operatingCountries: string[];
  businessIdentifier: string;
  taxIdentifier: string;
  billingLocation: string;
  deliveryLocations: string[];
  preferredLanguage: string;
  preferredCurrency: CurrencyCode;
  verification: VerificationRecord;
  paymentTerms: string;
  creditLimitMinor: number;
  approvalThresholdMinor: number;
  businessUnits: string[];
  onboardingStatus: 'approved' | 'pending_review' | 'suspended';
  returnPolicyDays: number;
}

export interface OrgUser {
  id: string;
  organisationId: string;
  name: string;
  email: string;
  role: UserRole;
  businessUnit?: string;
}

export interface PackagingConfig {
  version: number;
  effectiveFrom: string;
  unitsPerInnerPack: number;
  innerPacksPerCase: number;
  casesPerPallet: number;
  unitVolumeLabel: string;
  casePackSummary: string;
  netWeightKgPerCase: number;
  grossShippingWeightKgPerCase: number;
  caseDimensionsCm: { l: number; w: number; h: number };
}

export interface DocumentRecord {
  id: string;
  organisationId: string;
  linkedEntityType: 'product' | 'rfq' | 'order' | 'shipment' | 'org';
  linkedEntityId: string;
  title: string;
  docType: 'SDS' | 'COA' | 'ISO_Certificate' | 'Commercial_Invoice' | 'Packing_List' | 'Customs_Declaration' | 'Handling_Guide';
  version: number;
  issuer: string;
  uploadedBy: string;
  uploadedAt: string;
  isSystemTemplate: boolean;
  isOfficialCertificate: boolean;
  visibility: 'public' | 'authorised_parties' | 'private_org';
  summary: string;
}

export interface Product {
  id: string;
  brand: string;
  name: string;
  category: ProductCategory;
  sku: string;
  gtin: string;
  description: string;
  imageUrl: string;
  shelfLifeDays: number;
  ingredientsOrMaterials: string;
  commodityCode: string;
  packagingVersions: PackagingConfig[];
  currentPackagingVersion: number;
  handlingDocumentIds: string[];
}

export interface PriceTier {
  minCases: number;
  maxCases: number | null;
  unitPriceMinorPerCase: number;
}

export interface Offer {
  id: string;
  productId: string;
  packagingVersion: number;
  sellerOrgId: string;
  dispatchCountry: string;
  dispatchCountryCode: string;
  dispatchCity: string;
  warehouseId: string;
  permittedDestinations: string[];
  availableCases: number;
  moqCases: number;
  orderIncrementCases: number;
  currency: CurrencyCode;
  tiers: PriceTier[];
  leadTimeDays: number;
  incoterm: Incoterm;
  incotermEdition: 'Incoterms 2020';
  namedPlace: string;
  transportModes: TransportMode[];
  offerExpiresAt: string;
  paymentTerms: string;
  availabilitySource: 'platform_managed' | 'supplier_reported';
  availabilityUpdatedAt: string;
  listedAt: string;
  isRecommended: boolean;
  freightEstimatePerCaseMinor: number | null;
  insuranceRateBps: number | null;
  dutyRateBps: number | null;
  importTaxRateBps: number | null;
  importerOfRecord: 'buyer' | 'seller';
  status: 'active' | 'expired' | 'paused';
}

export interface LandedCostBreakdown {
  offerId: string;
  currency: CurrencyCode;
  cases: number;
  goodsMinor: number;
  freightMinor: number | null;
  insuranceMinor: number | null;
  dutiesMinor: number | null;
  taxesMinor: number | null;
  platformFeeMinor: number;
  estimatedLandedTotalMinor: number | null;
  equivalentPerUnitMinor: number | null;
  equivalentPerCaseMinor: number | null;
  includedInIncoterm: string[];
  missingTerms: string[];
  isComplete: boolean;
  isGuaranteedDeliveredPrice: false;
  adapterSource: string;
  transportValid: boolean;
  transportWarning?: string;
}

export interface InventoryRecord {
  id: string;
  sellerOrgId: string;
  sku: string;
  productId: string;
  warehouseId: string;
  warehouseName: string;
  batchNumber: string;
  expiryDate: string;
  onHandCases: number;
  reservedCases: number;
  quarantinedCases: number;
  damagedCases: number;
  expiredCases: number;
  inTransitCases: number;
  source: 'platform_managed' | 'supplier_reported';
  updatedAt: string;
  withdrawn: boolean;
  withdrawalReason?: string;
}

export interface StockReservation {
  id: string;
  orderId: string;
  inventoryRecordId: string;
  sku: string;
  batchNumber: string;
  cases: number;
  expiresAt: string;
  status: 'active' | 'allocated' | 'dispatched' | 'released' | 'expired';
  createdAt: string;
}

export interface StockLedgerEntry {
  id: string;
  timestamp: string;
  inventoryRecordId: string;
  sku: string;
  batchNumber: string;
  movementType:
    | 'receipt'
    | 'adjustment'
    | 'reservation'
    | 'allocation'
    | 'pick'
    | 'dispatch'
    | 'return'
    | 'quarantine'
    | 'withdrawal';
  deltaCases: number;
  referenceId: string;
  actorId: string;
  note: string;
}

export type RfqStatus =
  | 'Draft'
  | 'Published'
  | 'Responses Received'
  | 'Under Review'
  | 'Awarded'
  | 'Closed';

export interface RfqLine {
  id: string;
  productId: string;
  productName: string;
  specification: string;
  quantity: number;
  packUnit: PackUnit;
  equivalentCases: number;
  permittedSubstitutions: boolean;
}

export interface RfqQuoteVersion {
  version: number;
  submittedAt: string;
  currency: CurrencyCode;
  unitPriceMinorPerCase: number;
  leadTimeDays: number;
  incoterm: Incoterm;
  namedPlace: string;
  transportMode: TransportMode;
  freightTotalMinor: number | null;
  insuranceMinor: number | null;
  dutyRateBps: number | null;
  importTaxRateBps: number | null;
  paymentTerms: string;
  validUntil: string;
  notes: string;
}

export interface RfqQuote {
  id: string;
  rfqId: string;
  sellerOrgId: string;
  sellerName: string;
  offerId?: string;
  currentVersion: number;
  versions: RfqQuoteVersion[];
  status: 'submitted' | 'revised' | 'awarded' | 'declined';
  isPrivate: boolean;
}

export interface RfqQuestion {
  id: string;
  authorOrgId: string;
  authorName: string;
  question: string;
  answer?: string;
  createdAt: string;
}

export interface Rfq {
  id: string;
  buyerOrgId: string;
  buyerName: string;
  title: string;
  status: RfqStatus;
  lines: RfqLine[];
  destinationCountry: string;
  deliveryLocation: string;
  requiredDeliveryDays: number;
  preferredCurrency: CurrencyCode;
  incoterm: Incoterm;
  transportMode: TransportMode;
  requiredDocuments: string[];
  invitedSellerIds: string[];
  questions: RfqQuestion[];
  quotes: RfqQuote[];
  awardedQuoteId?: string;
  createdOrderId?: string;
  createdAt: string;
  updatedAt: string;
}

export type OrderStatus =
  | 'Draft'
  | 'Awaiting Approval'
  | 'Confirmed'
  | 'Allocated'
  | 'Partially Dispatched'
  | 'Dispatched'
  | 'Delivered'
  | 'Closed'
  | 'Cancelled'
  | 'Backordered'
  | 'Disputed'
  | 'Returned';

export interface OrderLine {
  id: string;
  productId: string;
  productName: string;
  sku: string;
  offerId: string;
  packagingVersion: number;
  packagingSnapshot: PackagingConfig;
  casesOrdered: number;
  casesAllocated: number;
  casesDispatched: number;
  casesDelivered: number;
  unitPriceMinorPerCase: number;
  lineSubtotalMinor: number;
  batchAllocations: { batchNumber: string; cases: number }[];
}

export interface ApprovalRecord {
  required: boolean;
  reason: string;
  status: 'not_required' | 'pending' | 'approved' | 'rejected';
  approverUserId?: string;
  approverName?: string;
  decidedAt?: string;
  comment?: string;
}

export interface Order {
  id: string;
  buyerOrderGroupId: string;
  buyerOrgId: string;
  buyerName: string;
  sellerOrgId: string;
  sellerName: string;
  businessUnit: string;
  sourceType: 'fixed_offer' | 'awarded_rfq';
  sourceRefId: string;
  status: OrderStatus;
  lines: OrderLine[];
  listingCurrency: CurrencyCode;
  orderCurrency: CurrencyCode;
  settlementCurrency: CurrencyCode;
  fxRateApplied: number;
  fxSource: string;
  fxTimestamp: string;
  incoterm: Incoterm;
  namedPlace: string;
  transportMode: TransportMode;
  destinationCountry: string;
  deliveryLocation: string;
  paymentTerms: string;
  goodsTotalMinor: number;
  freightMinor: number;
  insuranceMinor: number;
  dutiesAndTaxesMinor: number;
  platformFeeBpsSnapshot: number;
  platformFeeMinor: number;
  totalMinor: number;
  approval: ApprovalRecord;
  reservationIds: string[];
  cancellationReason?: string;
  disputeNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TrackingEvent {
  id: string;
  timestamp: string;
  location: string;
  status: string;
  description: string;
  source: 'synthetic_carrier_feed' | 'manual_warehouse';
}

export interface DeliveryDiscrepancy {
  id: string;
  orderLineId: string;
  sku: string;
  batchNumber: string;
  expectedCases: number;
  deliveredCases: number;
  shortageCases: number;
  damagedCases: number;
  reason: string;
  recordedBy: string;
  recordedAt: string;
  creditNoteId?: string;
}

export interface Shipment {
  id: string;
  orderId: string;
  sellerOrgId: string;
  buyerOrgId: string;
  origin: string;
  destination: string;
  carrier: string;
  trackingNumber: string;
  transportMode: TransportMode;
  totalPackages: number;
  totalGrossWeightKg: number;
  casesShipped: number;
  dispatchedAt: string;
  estimatedArrival: string;
  deliveredAt?: string;
  status: 'In Transit' | 'Delivered' | 'Delivered with Discrepancy';
  trackingEvents: TrackingEvent[];
  discrepancies: DeliveryDiscrepancy[];
  commercialInvoiceDocId: string;
  packingListDocId: string;
}

export interface PaymentTransaction {
  id: string;
  invoiceId: string;
  orderId: string;
  idempotencyKey: string;
  method: 'simulated_bank_transfer' | 'hosted_card_adapter';
  amountMinor: number;
  currency: CurrencyCode;
  settlementAmountMinor: number;
  settlementCurrency: CurrencyCode;
  fxRate: number;
  conversionFeeMinor: number;
  status: 'settled' | 'failed' | 'refunded';
  recordedAt: string;
  reference: string;
}

export interface CreditNote {
  id: string;
  invoiceId: string;
  orderId: string;
  discrepancyId?: string;
  amountMinor: number;
  currency: CurrencyCode;
  reason: string;
  issuedBy: string;
  issuedAt: string;
}

export interface Invoice {
  id: string;
  orderId: string;
  buyerOrgId: string;
  sellerOrgId: string;
  currency: CurrencyCode;
  settlementCurrency: CurrencyCode;
  totalMinor: number;
  paidMinor: number;
  creditedMinor: number;
  balanceDueMinor: number;
  status: 'Issued' | 'Partially Paid' | 'Paid' | 'Credited' | 'Overdue';
  dueDate: string;
  issuedAt: string;
  payments: PaymentTransaction[];
  creditNotes: CreditNote[];
}

export interface MessageItem {
  id: string;
  senderOrgId: string;
  senderName: string;
  senderRole: UserRole;
  body: string;
  attachmentDocId?: string;
  createdAt: string;
}

export interface MessageThread {
  id: string;
  subject: string;
  linkedEntityType: 'rfq' | 'order' | 'general';
  linkedEntityId: string;
  participantOrgIds: string[];
  messages: MessageItem[];
  updatedAt: string;
}

export interface PlatformConfig {
  supportedCountries: string[];
  supportedLanguages: string[];
  allowedCurrencies: CurrencyCode[];
  categories: ProductCategory[];
  marketplaceFeeBps: number;
  defaultReservationTtlMinutes: number;
  fxRatesToUsd: Record<CurrencyCode, number>;
  fxFeeBps: number;
  fxTimestamp: string;
  fxSource: string;
  adapters: {
    freight: 'synthetic' | 'live_configured';
    customs: 'synthetic' | 'live_configured';
    payment: 'simulated' | 'stripe_configured';
    storage: 'local_s3_adapter' | 's3_configured';
  };
  configHistory: {
    id: string;
    changedBy: string;
    changedAt: string;
    summary: string;
  }[];
}
