import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import {
  DocumentRecord,
  Invoice,
  MessageThread,
  Order,
  Shipment,
  UserRole,
} from './types';
import { MarketplaceDatabase, createSeedDatabase } from './domains/seed';

export class ForbiddenOrgAccessError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ForbiddenOrgAccessError';
  }
}

const DATA_FILE = join(process.cwd(), 'data', 'aureom-db.json');

let memoryDb: MarketplaceDatabase | null = null;

export function getDatabase(): MarketplaceDatabase {
  if (memoryDb) return memoryDb;
  try {
    if (existsSync(DATA_FILE)) {
      const raw = readFileSync(DATA_FILE, 'utf-8');
      memoryDb = JSON.parse(raw) as MarketplaceDatabase;
      return memoryDb;
    }
  } catch (err) {
    console.warn('Failed to load persisted DB file, re-seeding:', err);
  }
  memoryDb = createSeedDatabase();
  saveDatabase();
  return memoryDb;
}

export function saveDatabase(): void {
  if (!memoryDb) return;
  try {
    const dir = dirname(DATA_FILE);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(DATA_FILE, JSON.stringify(memoryDb, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Non-fatal: unable to persist aureom-db.json:', err);
  }
}

export function resetDatabaseToSeed(): MarketplaceDatabase {
  memoryDb = createSeedDatabase();
  saveDatabase();
  return memoryDb;
}

export function assertOrgAccess(
  actorOrgId: string,
  actorRole: UserRole,
  allowedOrgIds: string[],
  resourceLabel: string,
): void {
  if (actorRole === 'platform_admin') return;
  if (!allowedOrgIds.includes(actorOrgId)) {
    throw new ForbiddenOrgAccessError(
      `Organisation boundary violation: ${actorOrgId} is not authorised to access ${resourceLabel}.`,
    );
  }
}

export function getAuthorizedOrders(
  db: MarketplaceDatabase,
  orgId: string,
  role: UserRole,
): Order[] {
  if (role === 'platform_admin') return db.orders;
  return db.orders.filter(
    (o) => o.buyerOrgId === orgId || o.sellerOrgId === orgId,
  );
}

export function getAuthorizedShipments(
  db: MarketplaceDatabase,
  orgId: string,
  role: UserRole,
): Shipment[] {
  if (role === 'platform_admin') return db.shipments;
  return db.shipments.filter(
    (s) => s.buyerOrgId === orgId || s.sellerOrgId === orgId,
  );
}

export function getAuthorizedInvoices(
  db: MarketplaceDatabase,
  orgId: string,
  role: UserRole,
): Invoice[] {
  if (role === 'platform_admin') return db.invoices;
  return db.invoices.filter(
    (i) => i.buyerOrgId === orgId || i.sellerOrgId === orgId,
  );
}

export function getAuthorizedDocuments(
  db: MarketplaceDatabase,
  orgId: string,
  role: UserRole,
): DocumentRecord[] {
  if (role === 'platform_admin') return db.documents;
  return db.documents.filter((doc) => {
    if (doc.visibility === 'public') return true;
    if (doc.organisationId === orgId) return true;
    if (doc.visibility === 'authorised_parties') {
      if (doc.linkedEntityType === 'shipment') {
        const shp = db.shipments.find((s) => s.id === doc.linkedEntityId);
        return shp ? shp.buyerOrgId === orgId || shp.sellerOrgId === orgId : false;
      }
      if (doc.linkedEntityType === 'product') {
        // Authorised if org has an RFQ/order involving that product
        const hasRfq = db.rfqs.some(
          (r) =>
            (r.buyerOrgId === orgId || r.invitedSellerIds.includes(orgId)) &&
            r.lines.some((l) => l.productId === doc.linkedEntityId),
        );
        const hasOrder = db.orders.some(
          (o) =>
            (o.buyerOrgId === orgId || o.sellerOrgId === orgId) &&
            o.lines.some((l) => l.productId === doc.linkedEntityId),
        );
        return hasRfq || hasOrder;
      }
    }
    return false;
  });
}

export function getAuthorizedThreads(
  db: MarketplaceDatabase,
  orgId: string,
  role: UserRole,
): MessageThread[] {
  if (role === 'platform_admin') return db.threads;
  return db.threads.filter((t) => t.participantOrgIds.includes(orgId));
}
