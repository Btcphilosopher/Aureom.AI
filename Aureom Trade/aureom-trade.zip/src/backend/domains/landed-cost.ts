import {
  CurrencyCode,
  Incoterm,
  LandedCostBreakdown,
  Offer,
  PackagingConfig,
  TransportMode,
} from '../types';
import { applyBps, convertCurrencyMinor } from './money';
import { resolveTierPriceMinor, unitsPerCase } from './packaging';

const OCEAN_ONLY_INCOTERMS: Incoterm[] = ['FOB', 'CIF'];

export function validateIncotermForTransport(
  incoterm: Incoterm,
  mode: TransportMode,
): { valid: boolean; warning?: string } {
  if (OCEAN_ONLY_INCOTERMS.includes(incoterm) && (mode === 'air' || mode === 'road')) {
    return {
      valid: false,
      warning: `${incoterm} (Incoterms 2020) is restricted to sea and inland waterway transport; use FCA, DAP, or DDP for ${mode} freight.`,
    };
  }
  return { valid: true };
}

export function calculateLandedCost(params: {
  offer: Offer;
  pkg: PackagingConfig;
  cases: number;
  transportMode: TransportMode;
  displayCurrency: CurrencyCode;
  fxRatesToUsd: Record<CurrencyCode, number>;
  fxFeeBps: number;
  platformFeeBps: number;
}): LandedCostBreakdown {
  const {
    offer,
    pkg,
    cases,
    transportMode,
    displayCurrency,
    fxRatesToUsd,
    fxFeeBps,
    platformFeeBps,
  } = params;

  const tier = resolveTierPriceMinor(offer.tiers, cases);
  const rawGoodsMinor = tier.unitPriceMinorPerCase * cases;
  const goodsConv = convertCurrencyMinor(
    rawGoodsMinor,
    offer.currency,
    displayCurrency,
    fxRatesToUsd,
    fxFeeBps,
  );
  const goodsMinor = goodsConv.convertedMinor;

  const transportCheck = validateIncotermForTransport(offer.incoterm, transportMode);
  const includedInIncoterm: string[] = [];
  const missingTerms: string[] = [];

  // Determine which costs are already embedded in the seller's quoted Incoterm (avoid double-counting)
  const freightIncluded =
    offer.incoterm === 'CIF' || offer.incoterm === 'DAP' || offer.incoterm === 'DDP';
  const insuranceIncluded = offer.incoterm === 'CIF' || offer.incoterm === 'DDP';
  const dutyAndTaxIncluded = offer.incoterm === 'DDP';

  if (freightIncluded) includedInIncoterm.push('Main freight');
  if (insuranceIncluded) includedInIncoterm.push('Cargo insurance');
  if (dutyAndTaxIncluded) includedInIncoterm.push('Import duties & VAT/GST');

  let freightMinor: number | null = 0;
  if (!freightIncluded) {
    if (offer.freightEstimatePerCaseMinor === null) {
      freightMinor = null;
      missingTerms.push('International freight quote missing');
    } else {
      const fConv = convertCurrencyMinor(
        offer.freightEstimatePerCaseMinor * cases,
        offer.currency,
        displayCurrency,
        fxRatesToUsd,
        fxFeeBps,
      );
      freightMinor = fConv.convertedMinor;
    }
  }

  let insuranceMinor: number | null = 0;
  if (!insuranceIncluded) {
    if (offer.insuranceRateBps === null) {
      insuranceMinor = null;
      missingTerms.push('Marine/cargo insurance rate missing');
    } else {
      const cifBase = goodsMinor + (freightMinor ?? 0);
      insuranceMinor = applyBps(cifBase, offer.insuranceRateBps);
    }
  }

  let dutiesMinor: number | null = 0;
  let taxesMinor: number | null = 0;
  if (!dutyAndTaxIncluded) {
    if (offer.dutyRateBps === null) {
      dutiesMinor = null;
      missingTerms.push('Destination customs duty rate missing');
    } else {
      const customsValue = goodsMinor + (freightMinor ?? 0) + (insuranceMinor ?? 0);
      dutiesMinor = applyBps(customsValue, offer.dutyRateBps);
    }

    if (offer.importTaxRateBps === null) {
      taxesMinor = null;
      missingTerms.push('Destination import VAT/GST assumption missing');
    } else {
      const taxBase =
        goodsMinor + (freightMinor ?? 0) + (insuranceMinor ?? 0) + (dutiesMinor ?? 0);
      taxesMinor = applyBps(taxBase, offer.importTaxRateBps);
    }
  }

  const platformFeeMinor = applyBps(goodsMinor, platformFeeBps);
  const isComplete = missingTerms.length === 0;

  let estimatedLandedTotalMinor: number | null = null;
  let equivalentPerCaseMinor: number | null = null;
  let equivalentPerUnitMinor: number | null = null;

  if (
    isComplete &&
    freightMinor !== null &&
    insuranceMinor !== null &&
    dutiesMinor !== null &&
    taxesMinor !== null
  ) {
    estimatedLandedTotalMinor =
      goodsMinor +
      freightMinor +
      insuranceMinor +
      dutiesMinor +
      taxesMinor +
      platformFeeMinor;
    equivalentPerCaseMinor = Math.round(estimatedLandedTotalMinor / cases);
    const totalUnits = cases * unitsPerCase(pkg);
    equivalentPerUnitMinor = Math.round(estimatedLandedTotalMinor / totalUnits);
  }

  return {
    offerId: offer.id,
    currency: displayCurrency,
    cases,
    goodsMinor,
    freightMinor,
    insuranceMinor,
    dutiesMinor,
    taxesMinor,
    platformFeeMinor,
    estimatedLandedTotalMinor,
    equivalentPerCaseMinor,
    equivalentPerUnitMinor,
    includedInIncoterm,
    missingTerms,
    isComplete,
    isGuaranteedDeliveredPrice: false,
    adapterSource: 'Synthetic Freight & Customs Estimator (no live carrier API configured)',
    transportValid: transportCheck.valid,
    transportWarning: transportCheck.warning,
  };
}

/**
 * Safely ranks offers for comparison: complete quotes ranked by lowest estimated landed cost first,
 * followed by incomplete quotes (never treating missing freight/duties as zero!).
 */
export function rankLandedCostBreakdowns(
  breakdowns: LandedCostBreakdown[],
): LandedCostBreakdown[] {
  return [...breakdowns].sort((a, b) => {
    if (a.isComplete && !b.isComplete) return -1;
    if (!a.isComplete && b.isComplete) return 1;
    if (a.isComplete && b.isComplete) {
      return (a.estimatedLandedTotalMinor ?? 0) - (b.estimatedLandedTotalMinor ?? 0);
    }
    return a.goodsMinor - b.goodsMinor;
  });
}
