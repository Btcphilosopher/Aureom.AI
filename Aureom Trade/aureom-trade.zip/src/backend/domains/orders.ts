import {
  CurrencyCode,
  Incoterm,
  Order,
  OrderLine,
  OrderStatus,
  Organisation,
  Product,
  TransportMode,
} from '../types';
import { MarketplaceDatabase } from './seed';
import { applyBps, convertCurrencyMinor } from './money';
import { resolveTierPriceMinor, validateOrderQuantity } from './packaging';
import { calculateLandedCost } from './landed-cost';
import { reserveStockAtomic } from './inventory';

export class OrderWorkflowError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'OrderWorkflowError';
  }
}

export interface CartItemInput {
  offerId: string;
  cases: number;
  transportMode?: TransportMode;
}

export async function createOrdersFromBasket(params: {
  db: MarketplaceDatabase;
  buyerOrg: Organisation;
  actorId: string;
  businessUnit: string;
  deliveryLocation: string;
  destinationCountry: string;
  orderCurrency: CurrencyCode;
  items: CartItemInput[];
  nowIso?: string;
}): Promise<Order[]> {
  const {
    db,
    buyerOrg,
    actorId,
    businessUnit,
    deliveryLocation,
    destinationCountry,
    orderCurrency,
    items,
    nowIso = new Date().toISOString(),
  } = params;

  if (!items.length) {
    throw new OrderWorkflowError('Basket is empty.');
  }

  // Group items by sellerOrgId to split multi-seller baskets into seller-specific orders
  const bySeller = new Map<string, CartItemInput[]>();
  for (const item of items) {
    const offer = db.offers.find((o) => o.id === item.offerId);
    if (!offer) {
      throw new OrderWorkflowError(`Offer ${item.offerId} not found.`);
    }
    if (!offer.permittedDestinations.includes(destinationCountry)) {
      throw new OrderWorkflowError(
        `Offer ${offer.id} does not permit delivery to ${destinationCountry}.`,
      );
    }
    validateOrderQuantity(item.cases, offer.moqCases, offer.orderIncrementCases);
    const list = bySeller.get(offer.sellerOrgId) ?? [];
    list.push(item);
    bySeller.set(offer.sellerOrgId, list);
  }

  const buyerOrderGroupId = `GRP-${Date.now().toString().slice(-6)}`;
  const createdOrders: Order[] = [];

  for (const [sellerOrgId, sellerItems] of bySeller.entries()) {
    const sellerOrg = db.organisations.find((o) => o.id === sellerOrgId);
    if (!sellerOrg) {
      throw new OrderWorkflowError(`Seller ${sellerOrgId} not found.`);
    }

    const orderId = `ORD-${Date.now().toString().slice(-5)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`;
    const orderLines: OrderLine[] = [];
    let goodsTotalMinor = 0;
    let freightMinor = 0;
    let insuranceMinor = 0;
    let dutiesAndTaxesMinor = 0;
    let platformFeeMinor = 0;

    const firstOffer = db.offers.find((o) => o.id === sellerItems[0].offerId)!;
    const mode = sellerItems[0].transportMode ?? firstOffer.transportModes[0] ?? 'road';

    for (const item of sellerItems) {
      const offer = db.offers.find((o) => o.id === item.offerId)!;
      const product: Product | undefined = db.products.find(
        (p) => p.id === offer.productId,
      );
      if (!product) {
        throw new OrderWorkflowError(`Product ${offer.productId} not found.`);
      }
      const pkg =
        product.packagingVersions.find((v) => v.version === offer.packagingVersion) ??
        product.packagingVersions[product.packagingVersions.length - 1];

      const tier = resolveTierPriceMinor(offer.tiers, item.cases);
      const unitConv = convertCurrencyMinor(
        tier.unitPriceMinorPerCase,
        offer.currency,
        orderCurrency,
        db.platformConfig.fxRatesToUsd,
        db.platformConfig.fxFeeBps,
      );

      const landed = calculateLandedCost({
        offer,
        pkg,
        cases: item.cases,
        transportMode: item.transportMode ?? mode,
        displayCurrency: orderCurrency,
        fxRatesToUsd: db.platformConfig.fxRatesToUsd,
        fxFeeBps: db.platformConfig.fxFeeBps,
        platformFeeBps: db.platformConfig.marketplaceFeeBps,
      });

      const lineSubtotalMinor = unitConv.convertedMinor * item.cases;
      goodsTotalMinor += lineSubtotalMinor;
      freightMinor += landed.freightMinor ?? 0;
      insuranceMinor += landed.insuranceMinor ?? 0;
      dutiesAndTaxesMinor += (landed.dutiesMinor ?? 0) + (landed.taxesMinor ?? 0);
      platformFeeMinor += landed.platformFeeMinor;

      orderLines.push({
        id: `ol_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        productId: product.id,
        productName: product.name,
        sku: product.sku,
        offerId: offer.id,
        packagingVersion: pkg.version,
        packagingSnapshot: structuredClone(pkg),
        casesOrdered: item.cases,
        casesAllocated: 0,
        casesDispatched: 0,
        casesDelivered: 0,
        unitPriceMinorPerCase: unitConv.convertedMinor,
        lineSubtotalMinor,
        batchAllocations: [],
      });
    }

    const totalMinor =
      goodsTotalMinor +
      freightMinor +
      insuranceMinor +
      dutiesAndTaxesMinor +
      platformFeeMinor;

    const totalUsdMinor = convertCurrencyMinor(
      totalMinor,
      orderCurrency,
      'USD',
      db.platformConfig.fxRatesToUsd,
      0,
    ).convertedMinor;

    const needsApproval = totalUsdMinor > buyerOrg.approvalThresholdMinor;
    const status: OrderStatus = needsApproval ? 'Awaiting Approval' : 'Confirmed';

    const order: Order = {
      id: orderId,
      buyerOrderGroupId,
      buyerOrgId: buyerOrg.id,
      buyerName: buyerOrg.tradingName,
      sellerOrgId: sellerOrg.id,
      sellerName: sellerOrg.tradingName,
      businessUnit,
      sourceType: 'fixed_offer',
      sourceRefId: sellerItems.map((i) => i.offerId).join(','),
      status,
      lines: orderLines,
      listingCurrency: firstOffer.currency,
      orderCurrency,
      settlementCurrency: buyerOrg.preferredCurrency,
      fxRateApplied:
        firstOffer.currency === orderCurrency
          ? 1
          : Number(
              (
                db.platformConfig.fxRatesToUsd[firstOffer.currency] /
                db.platformConfig.fxRatesToUsd[orderCurrency]
              ).toFixed(6),
            ),
      fxSource: db.platformConfig.fxSource,
      fxTimestamp: db.platformConfig.fxTimestamp,
      incoterm: firstOffer.incoterm,
      namedPlace: firstOffer.namedPlace,
      transportMode: mode,
      destinationCountry,
      deliveryLocation,
      paymentTerms: firstOffer.paymentTerms,
      goodsTotalMinor,
      freightMinor,
      insuranceMinor,
      dutiesAndTaxesMinor,
      platformFeeBpsSnapshot: db.platformConfig.marketplaceFeeBps,
      platformFeeMinor,
      totalMinor,
      approval: {
        required: needsApproval,
        reason: needsApproval
          ? `Order value exceeds ${buyerOrg.tradingName} approval threshold ($${(buyerOrg.approvalThresholdMinor / 100).toLocaleString()}).`
          : 'Within buyer delegated authority.',
        status: needsApproval ? 'pending' : 'not_required',
      },
      reservationIds: [],
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    if (status === 'Confirmed') {
      await allocateOrderInventory(db, order, actorId, nowIso);
      issueOrderInvoice(db, order, nowIso);
    }

    db.orders.unshift(order);
    createdOrders.push(order);
  }

  return createdOrders;
}

export async function approveOrder(params: {
  db: MarketplaceDatabase;
  order: Order;
  approverUserId: string;
  approverName: string;
  approved: boolean;
  comment?: string;
  nowIso?: string;
}): Promise<Order> {
  const {
    db,
    order,
    approverUserId,
    approverName,
    approved,
    comment,
    nowIso = new Date().toISOString(),
  } = params;

  if (order.status !== 'Awaiting Approval') {
    throw new OrderWorkflowError(
      `Order ${order.id} is in status ${order.status}, not Awaiting Approval.`,
    );
  }

  order.approval.approverUserId = approverUserId;
  order.approval.approverName = approverName;
  order.approval.decidedAt = nowIso;
  order.approval.comment = comment;

  if (!approved) {
    order.approval.status = 'rejected';
    order.status = 'Cancelled';
    order.cancellationReason = comment || 'Rejected by procurement approver.';
    order.updatedAt = nowIso;
    return order;
  }

  order.approval.status = 'approved';
  order.status = 'Confirmed';
  order.updatedAt = nowIso;
  await allocateOrderInventory(db, order, approverUserId, nowIso);
  issueOrderInvoice(db, order, nowIso);
  return order;
}

export async function allocateOrderInventory(
  db: MarketplaceDatabase,
  order: Order,
  actorId: string,
  nowIso = new Date().toISOString(),
): Promise<void> {
  for (const line of order.lines) {
    if (line.casesAllocated >= line.casesOrdered) continue;
    const { createdReservations, batchAllocations } = await reserveStockAtomic({
      inventory: db.inventory,
      reservations: db.reservations,
      ledger: db.stockLedger,
      sellerOrgId: order.sellerOrgId,
      sku: line.sku,
      cases: line.casesOrdered - line.casesAllocated,
      orderId: order.id,
      actorId,
      ttlMinutes: db.platformConfig.defaultReservationTtlMinutes,
      nowIso,
    });
    for (const r of createdReservations) {
      r.status = 'allocated';
      order.reservationIds.push(r.id);
    }
    line.casesAllocated += batchAllocations.reduce((s, b) => s + b.cases, 0);
    line.batchAllocations.push(...batchAllocations);
  }
  order.status = 'Allocated';
  order.updatedAt = nowIso;
}

export function issueOrderInvoice(
  db: MarketplaceDatabase,
  order: Order,
  nowIso = new Date().toISOString(),
): void {
  const existing = db.invoices.find((inv) => inv.orderId === order.id);
  if (existing) return;

  const dueDate = new Date(
    new Date(nowIso).getTime() + 30 * 24 * 60 * 60 * 1000,
  ).toISOString();

  db.invoices.unshift({
    id: `INV-${order.id.replace('ORD-', '')}`,
    orderId: order.id,
    buyerOrgId: order.buyerOrgId,
    sellerOrgId: order.sellerOrgId,
    currency: order.orderCurrency,
    settlementCurrency: order.settlementCurrency,
    totalMinor: order.totalMinor,
    paidMinor: 0,
    creditedMinor: 0,
    balanceDueMinor: order.totalMinor,
    status: 'Issued',
    dueDate,
    issuedAt: nowIso,
    payments: [],
    creditNotes: [],
  });
}

export async function createOrderFromAwardedRfq(params: {
  db: MarketplaceDatabase;
  rfqId: string;
  quoteId: string;
  actorId: string;
  businessUnit: string;
  nowIso?: string;
}): Promise<Order> {
  const {
    db,
    rfqId,
    quoteId,
    actorId,
    businessUnit,
    nowIso = new Date().toISOString(),
  } = params;

  const rfq = db.rfqs.find((r) => r.id === rfqId);
  if (!rfq) throw new OrderWorkflowError(`RFQ ${rfqId} not found.`);
  if (rfq.status === 'Awarded' || rfq.status === 'Closed') {
    throw new OrderWorkflowError(`RFQ ${rfqId} is already ${rfq.status}.`);
  }

  const quote = rfq.quotes.find((q) => q.id === quoteId);
  if (!quote) throw new OrderWorkflowError(`Quote ${quoteId} not found.`);

  const latestVersion = quote.versions[quote.versions.length - 1];
  const buyerOrg = db.organisations.find((o) => o.id === rfq.buyerOrgId)!;
  const sellerOrg = db.organisations.find((o) => o.id === quote.sellerOrgId)!;
  const line = rfq.lines[0];
  const product = db.products.find((p) => p.id === line.productId)!;
  const pkg =
    product.packagingVersions.find((v) => v.version === product.currentPackagingVersion) ??
    product.packagingVersions[0];

  const cases = line.equivalentCases;
  const goodsTotalMinor = latestVersion.unitPriceMinorPerCase * cases;
  const freightMinor = latestVersion.freightTotalMinor ?? 0;
  const insuranceMinor = latestVersion.insuranceMinor ?? 0;
  const dutyRate = latestVersion.dutyRateBps ?? 0;
  const taxRate = latestVersion.importTaxRateBps ?? 0;
  const customsBase = goodsTotalMinor + freightMinor + insuranceMinor;
  const dutiesMinor = applyBps(customsBase, dutyRate);
  const taxesMinor = applyBps(customsBase + dutiesMinor, taxRate);
  const platformFeeMinor = applyBps(
    goodsTotalMinor,
    db.platformConfig.marketplaceFeeBps,
  );
  const totalMinor =
    goodsTotalMinor +
    freightMinor +
    insuranceMinor +
    dutiesMinor +
    taxesMinor +
    platformFeeMinor;

  const totalUsdMinor = convertCurrencyMinor(
    totalMinor,
    latestVersion.currency,
    'USD',
    db.platformConfig.fxRatesToUsd,
    0,
  ).convertedMinor;
  const needsApproval = totalUsdMinor > buyerOrg.approvalThresholdMinor;

  const orderId = `ORD-${Date.now().toString().slice(-5)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`;
  const order: Order = {
    id: orderId,
    buyerOrderGroupId: `GRP-${rfq.id}`,
    buyerOrgId: buyerOrg.id,
    buyerName: buyerOrg.tradingName,
    sellerOrgId: sellerOrg.id,
    sellerName: sellerOrg.tradingName,
    businessUnit,
    sourceType: 'awarded_rfq',
    sourceRefId: `${rfq.id}:v${latestVersion.version}`,
    status: needsApproval ? 'Awaiting Approval' : 'Confirmed',
    lines: [
      {
        id: `ol_${Date.now()}`,
        productId: product.id,
        productName: product.name,
        sku: product.sku,
        offerId: quote.offerId ?? quote.id,
        packagingVersion: pkg.version,
        packagingSnapshot: structuredClone(pkg),
        casesOrdered: cases,
        casesAllocated: 0,
        casesDispatched: 0,
        casesDelivered: 0,
        unitPriceMinorPerCase: latestVersion.unitPriceMinorPerCase,
        lineSubtotalMinor: goodsTotalMinor,
        batchAllocations: [],
      },
    ],
    listingCurrency: latestVersion.currency,
    orderCurrency: latestVersion.currency,
    settlementCurrency: buyerOrg.preferredCurrency,
    fxRateApplied: 1,
    fxSource: db.platformConfig.fxSource,
    fxTimestamp: db.platformConfig.fxTimestamp,
    incoterm: latestVersion.incoterm as Incoterm,
    namedPlace: latestVersion.namedPlace,
    transportMode: latestVersion.transportMode,
    destinationCountry: rfq.destinationCountry,
    deliveryLocation: rfq.deliveryLocation,
    paymentTerms: latestVersion.paymentTerms,
    goodsTotalMinor,
    freightMinor,
    insuranceMinor,
    dutiesAndTaxesMinor: dutiesMinor + taxesMinor,
    platformFeeBpsSnapshot: db.platformConfig.marketplaceFeeBps,
    platformFeeMinor,
    totalMinor,
    approval: {
      required: needsApproval,
      reason: needsApproval
        ? `Negotiated RFQ order exceeds ${buyerOrg.tradingName} approval threshold ($${(buyerOrg.approvalThresholdMinor / 100).toLocaleString()}).`
        : 'Within delegated buyer authority.',
      status: needsApproval ? 'pending' : 'not_required',
    },
    reservationIds: [],
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  rfq.status = 'Awarded';
  rfq.awardedQuoteId = quote.id;
  rfq.createdOrderId = order.id;
  rfq.updatedAt = nowIso;
  quote.status = 'awarded';
  for (const other of rfq.quotes) {
    if (other.id !== quote.id) other.status = 'declined';
  }

  if (order.status === 'Confirmed') {
    await allocateOrderInventory(db, order, actorId, nowIso);
    issueOrderInvoice(db, order, nowIso);
  }

  db.orders.unshift(order);
  return order;
}
