import {
  CreditNote,
  CurrencyCode,
  Invoice,
  PaymentTransaction,
} from '../types';
import { MarketplaceDatabase } from './seed';
import { convertCurrencyMinor } from './money';

export class PaymentError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PaymentError';
  }
}

export function recordPaymentIdempotent(params: {
  db: MarketplaceDatabase;
  invoiceId: string;
  idempotencyKey: string;
  method: 'simulated_bank_transfer' | 'hosted_card_adapter';
  amountMinor: number;
  currency: CurrencyCode;
  reference: string;
  nowIso?: string;
}): { invoice: Invoice; payment: PaymentTransaction; deduplicated: boolean } {
  const {
    db,
    invoiceId,
    idempotencyKey,
    method,
    amountMinor,
    currency,
    reference,
    nowIso = new Date().toISOString(),
  } = params;

  const invoice = db.invoices.find((i) => i.id === invoiceId);
  if (!invoice) {
    throw new PaymentError(`Invoice ${invoiceId} not found.`);
  }

  const existing = invoice.payments.find(
    (p) => p.idempotencyKey === idempotencyKey,
  );
  if (existing) {
    return { invoice, payment: existing, deduplicated: true };
  }

  if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
    throw new PaymentError('Payment amount must be a positive integer in minor units.');
  }

  // Convert payment currency to invoice currency server-side if different
  const invoiceConv = convertCurrencyMinor(
    amountMinor,
    currency,
    invoice.currency,
    db.platformConfig.fxRatesToUsd,
    0,
  );

  const settlementConv = convertCurrencyMinor(
    amountMinor,
    currency,
    invoice.settlementCurrency,
    db.platformConfig.fxRatesToUsd,
    db.platformConfig.fxFeeBps,
  );

  const payment: PaymentTransaction = {
    id: `PAY-${Date.now().toString().slice(-6)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
    invoiceId: invoice.id,
    orderId: invoice.orderId,
    idempotencyKey,
    method,
    amountMinor: invoiceConv.convertedMinor,
    currency: invoice.currency,
    settlementAmountMinor: settlementConv.convertedMinor,
    settlementCurrency: invoice.settlementCurrency,
    fxRate: settlementConv.effectiveRate,
    conversionFeeMinor: settlementConv.conversionFeeMinor,
    status: 'settled',
    recordedAt: nowIso,
    reference,
  };

  invoice.payments.push(payment);
  recomputeInvoiceBalances(invoice);

  return { invoice, payment, deduplicated: false };
}

export function issueCreditNote(params: {
  db: MarketplaceDatabase;
  invoiceId: string;
  amountMinor: number;
  reason: string;
  issuedBy: string;
  discrepancyId?: string;
  nowIso?: string;
}): { invoice: Invoice; creditNote: CreditNote } {
  const {
    db,
    invoiceId,
    amountMinor,
    reason,
    issuedBy,
    discrepancyId,
    nowIso = new Date().toISOString(),
  } = params;

  const invoice = db.invoices.find((i) => i.id === invoiceId);
  if (!invoice) {
    throw new PaymentError(`Invoice ${invoiceId} not found.`);
  }
  if (!Number.isInteger(amountMinor) || amountMinor <= 0) {
    throw new PaymentError('Credit note amount must be positive minor units.');
  }

  const creditNote: CreditNote = {
    id: `CN-${Date.now().toString().slice(-5)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
    invoiceId: invoice.id,
    orderId: invoice.orderId,
    discrepancyId,
    amountMinor,
    currency: invoice.currency,
    reason,
    issuedBy,
    issuedAt: nowIso,
  };

  invoice.creditNotes.push(creditNote);
  recomputeInvoiceBalances(invoice);

  return { invoice, creditNote };
}

export function recomputeInvoiceBalances(invoice: Invoice): void {
  const paid = invoice.payments
    .filter((p) => p.status === 'settled')
    .reduce((sum, p) => sum + p.amountMinor, 0);
  const credited = invoice.creditNotes.reduce(
    (sum, cn) => sum + cn.amountMinor,
    0,
  );
  invoice.paidMinor = paid;
  invoice.creditedMinor = credited;
  invoice.balanceDueMinor = Math.max(0, invoice.totalMinor - paid - credited);

  if (invoice.balanceDueMinor === 0 && credited > 0 && paid < invoice.totalMinor) {
    invoice.status = credited >= invoice.totalMinor ? 'Credited' : 'Paid';
  } else if (invoice.balanceDueMinor === 0) {
    invoice.status = 'Paid';
  } else if (paid > 0 || credited > 0) {
    invoice.status = 'Partially Paid';
  } else {
    invoice.status = 'Issued';
  }
}
