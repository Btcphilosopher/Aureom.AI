import { CurrencyCode } from '../types';

export class CurrencyMismatchError extends Error {
  constructor(expected: CurrencyCode, actual: CurrencyCode) {
    super(
      `Currency mismatch: cannot combine ${expected} and ${actual} without explicit FX conversion.`,
    );
    this.name = 'CurrencyMismatchError';
  }
}

export interface MoneyValue {
  minorUnits: number;
  currency: CurrencyCode;
}

export function assertSameCurrency(a: CurrencyCode, b: CurrencyCode): void {
  if (a !== b) {
    throw new CurrencyMismatchError(a, b);
  }
}

export function addMoney(a: MoneyValue, b: MoneyValue): MoneyValue {
  assertSameCurrency(a.currency, b.currency);
  return {
    minorUnits: Math.round(a.minorUnits) + Math.round(b.minorUnits),
    currency: a.currency,
  };
}

export function subtractMoney(a: MoneyValue, b: MoneyValue): MoneyValue {
  assertSameCurrency(a.currency, b.currency);
  return {
    minorUnits: Math.round(a.minorUnits) - Math.round(b.minorUnits),
    currency: a.currency,
  };
}

export function applyBps(minorUnits: number, bps: number): number {
  return Math.round((Math.round(minorUnits) * bps) / 10000);
}

export function convertCurrencyMinor(
  amountMinor: number,
  from: CurrencyCode,
  to: CurrencyCode,
  fxRatesToUsd: Record<CurrencyCode, number>,
  fxFeeBps = 0,
): {
  convertedMinor: number;
  effectiveRate: number;
  conversionFeeMinor: number;
} {
  if (from === to) {
    return {
      convertedMinor: Math.round(amountMinor),
      effectiveRate: 1,
      conversionFeeMinor: 0,
    };
  }
  const usdValue = Math.round(amountMinor) * fxRatesToUsd[from];
  const targetRaw = usdValue / fxRatesToUsd[to];
  const baseConverted = Math.round(targetRaw);
  const feeMinor = applyBps(baseConverted, fxFeeBps);
  return {
    convertedMinor: baseConverted + feeMinor,
    effectiveRate: Number((fxRatesToUsd[from] / fxRatesToUsd[to]).toFixed(6)),
    conversionFeeMinor: feeMinor,
  };
}

export function formatMinorCurrency(
  minorUnits: number,
  currency: CurrencyCode,
): string {
  const symbol = currency === 'USD' ? '$' : currency === 'GBP' ? '£' : '€';
  const major = (Math.round(minorUnits) / 100).toFixed(2);
  return `${symbol}${major}`;
}
