import { PackUnit, PackagingConfig, PriceTier } from '../types';

export class PackagingValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PackagingValidationError';
  }
}

export function unitsPerCase(pkg: PackagingConfig): number {
  return pkg.unitsPerInnerPack * pkg.innerPacksPerCase;
}

export function convertToCases(
  quantity: number,
  unit: PackUnit,
  pkg: PackagingConfig,
): number {
  if (!Number.isFinite(quantity) || quantity <= 0) {
    throw new PackagingValidationError('Quantity must be greater than zero.');
  }
  switch (unit) {
    case 'case':
      if (!Number.isInteger(quantity)) {
        throw new PackagingValidationError('Case quantity must be a whole integer.');
      }
      return quantity;
    case 'pallet':
      if (!Number.isInteger(quantity)) {
        throw new PackagingValidationError('Pallet quantity must be a whole integer.');
      }
      return quantity * pkg.casesPerPallet;
    case 'inner_pack': {
      const exact = quantity / pkg.innerPacksPerCase;
      if (!Number.isInteger(exact)) {
        throw new PackagingValidationError(
          `${quantity} inner packs does not divide evenly into cases (${pkg.innerPacksPerCase} inner packs/case).`,
        );
      }
      return exact;
    }
    case 'unit': {
      const perCase = unitsPerCase(pkg);
      const exact = quantity / perCase;
      if (!Number.isInteger(exact)) {
        throw new PackagingValidationError(
          `${quantity} units does not divide evenly into cases (${perCase} units/case).`,
        );
      }
      return exact;
    }
  }
}

export function convertFromCases(
  cases: number,
  pkg: PackagingConfig,
): {
  cases: number;
  pallets: number;
  innerPacks: number;
  units: number;
  grossWeightKg: number;
  netWeightKg: number;
  volumeCubicMeters: number;
} {
  const perCase = unitsPerCase(pkg);
  const caseVolumeM3 =
    (pkg.caseDimensionsCm.l * pkg.caseDimensionsCm.w * pkg.caseDimensionsCm.h) /
    1_000_000;
  return {
    cases,
    pallets: Number((cases / pkg.casesPerPallet).toFixed(2)),
    innerPacks: cases * pkg.innerPacksPerCase,
    units: cases * perCase,
    grossWeightKg: Number((cases * pkg.grossShippingWeightKgPerCase).toFixed(2)),
    netWeightKg: Number((cases * pkg.netWeightKgPerCase).toFixed(2)),
    volumeCubicMeters: Number((cases * caseVolumeM3).toFixed(3)),
  };
}

export function validateOrderQuantity(
  cases: number,
  moqCases: number,
  incrementCases: number,
): void {
  if (!Number.isInteger(cases) || cases <= 0) {
    throw new PackagingValidationError('Order quantity must be a positive whole number of cases.');
  }
  if (cases < moqCases) {
    throw new PackagingValidationError(
      `Order quantity (${cases} cases) is below the minimum order quantity of ${moqCases} cases.`,
    );
  }
  if ((cases - moqCases) % incrementCases !== 0) {
    throw new PackagingValidationError(
      `Order quantity (${cases} cases) must be in increments of ${incrementCases} cases above MOQ ${moqCases}.`,
    );
  }
}

export function resolveTierPriceMinor(
  tiers: PriceTier[],
  cases: number,
): PriceTier {
  const sorted = [...tiers].sort((a, b) => a.minCases - b.minCases);
  let matched = sorted[0];
  for (const tier of sorted) {
    if (cases >= tier.minCases && (tier.maxCases === null || cases <= tier.maxCases)) {
      matched = tier;
    }
  }
  return matched;
}
