import {
  CurrencyCode,
  Incoterm,
  Organisation,
  PackUnit,
  Rfq,
  RfqQuote,
  RfqQuoteVersion,
  TransportMode,
  UserRole,
} from '../types';
import { MarketplaceDatabase } from './seed';
import { convertToCases } from './packaging';

export class RfqError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RfqError';
  }
}

export function getAuthorizedRfqs(
  db: MarketplaceDatabase,
  orgId: string,
  role: UserRole,
): Rfq[] {
  if (role === 'platform_admin') {
    return db.rfqs;
  }
  return db.rfqs
    .filter(
      (rfq) =>
        rfq.buyerOrgId === orgId ||
        rfq.invitedSellerIds.includes(orgId) ||
        rfq.status === 'Published' ||
        rfq.status === 'Responses Received' ||
        rfq.status === 'Under Review',
    )
    .map((rfq) => ({
      ...rfq,
      // Enforce private quotation visibility: buyer sees all quotes on its RFQ;
      // seller sees ONLY its own quotes!
      quotes: rfq.quotes.filter(
        (q) =>
          !q.isPrivate ||
          rfq.buyerOrgId === orgId ||
          q.sellerOrgId === orgId,
      ),
    }));
}

export function createRfq(params: {
  db: MarketplaceDatabase;
  buyerOrg: Organisation;
  title: string;
  productId: string;
  specification: string;
  quantity: number;
  packUnit: PackUnit;
  permittedSubstitutions: boolean;
  destinationCountry: string;
  deliveryLocation: string;
  requiredDeliveryDays: number;
  preferredCurrency: CurrencyCode;
  incoterm: Incoterm;
  transportMode: TransportMode;
  requiredDocuments: string[];
  invitedSellerIds: string[];
  publishImmediately: boolean;
  nowIso?: string;
}): Rfq {
  const {
    db,
    buyerOrg,
    title,
    productId,
    specification,
    quantity,
    packUnit,
    permittedSubstitutions,
    destinationCountry,
    deliveryLocation,
    requiredDeliveryDays,
    preferredCurrency,
    incoterm,
    transportMode,
    requiredDocuments,
    invitedSellerIds,
    publishImmediately,
    nowIso = new Date().toISOString(),
  } = params;

  const product = db.products.find((p) => p.id === productId);
  if (!product) {
    throw new RfqError(`Product ${productId} not found.`);
  }

  const pkg =
    product.packagingVersions.find((v) => v.version === product.currentPackagingVersion) ??
    product.packagingVersions[0];

  const equivalentCases = convertToCases(quantity, packUnit, pkg);
  const rfqId = `RFQ-2026-${Math.floor(100 + Math.random() * 899)}`;

  const rfq: Rfq = {
    id: rfqId,
    buyerOrgId: buyerOrg.id,
    buyerName: buyerOrg.tradingName,
    title,
    status: publishImmediately ? 'Published' : 'Draft',
    lines: [
      {
        id: `rfql_${Date.now()}`,
        productId: product.id,
        productName: product.name,
        specification: specification || pkg.casePackSummary,
        quantity,
        packUnit,
        equivalentCases,
        permittedSubstitutions,
      },
    ],
    destinationCountry,
    deliveryLocation,
    requiredDeliveryDays,
    preferredCurrency,
    incoterm,
    transportMode,
    requiredDocuments,
    invitedSellerIds,
    questions: [],
    quotes: [],
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  db.rfqs.unshift(rfq);
  return rfq;
}

export function submitRfqQuoteVersion(params: {
  db: MarketplaceDatabase;
  rfqId: string;
  sellerOrg: Organisation;
  unitPriceMinorPerCase: number;
  currency: CurrencyCode;
  leadTimeDays: number;
  incoterm: Incoterm;
  namedPlace: string;
  transportMode: TransportMode;
  freightTotalMinor: number | null;
  insuranceMinor: number | null;
  dutyRateBps: number | null;
  importTaxRateBps: number | null;
  paymentTerms: string;
  notes: string;
  nowIso?: string;
}): RfqQuote {
  const {
    db,
    rfqId,
    sellerOrg,
    unitPriceMinorPerCase,
    currency,
    leadTimeDays,
    incoterm,
    namedPlace,
    transportMode,
    freightTotalMinor,
    insuranceMinor,
    dutyRateBps,
    importTaxRateBps,
    paymentTerms,
    notes,
    nowIso = new Date().toISOString(),
  } = params;

  const rfq = db.rfqs.find((r) => r.id === rfqId);
  if (!rfq) throw new RfqError(`RFQ ${rfqId} not found.`);
  if (rfq.status === 'Awarded' || rfq.status === 'Closed') {
    throw new RfqError(`Cannot submit quotation on ${rfq.status} RFQ.`);
  }

  let existingQuote = rfq.quotes.find((q) => q.sellerOrgId === sellerOrg.id);
  const validUntil = new Date(
    new Date(nowIso).getTime() + 30 * 24 * 60 * 60 * 1000,
  ).toISOString();

  if (existingQuote) {
    const nextVersionNum = existingQuote.currentVersion + 1;
    const versionEntry: RfqQuoteVersion = {
      version: nextVersionNum,
      submittedAt: nowIso,
      currency,
      unitPriceMinorPerCase,
      leadTimeDays,
      incoterm,
      namedPlace,
      transportMode,
      freightTotalMinor,
      insuranceMinor,
      dutyRateBps,
      importTaxRateBps,
      paymentTerms,
      validUntil,
      notes,
    };
    existingQuote.versions.push(versionEntry);
    existingQuote.currentVersion = nextVersionNum;
    existingQuote.status = 'revised';
  } else {
    existingQuote = {
      id: `qt_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      rfqId: rfq.id,
      sellerOrgId: sellerOrg.id,
      sellerName: sellerOrg.tradingName,
      currentVersion: 1,
      status: 'submitted',
      isPrivate: true,
      versions: [
        {
          version: 1,
          submittedAt: nowIso,
          currency,
          unitPriceMinorPerCase,
          leadTimeDays,
          incoterm,
          namedPlace,
          transportMode,
          freightTotalMinor,
          insuranceMinor,
          dutyRateBps,
          importTaxRateBps,
          paymentTerms,
          validUntil,
          notes,
        },
      ],
    };
    rfq.quotes.push(existingQuote);
  }

  if (rfq.status === 'Published' || rfq.status === 'Draft') {
    rfq.status = 'Responses Received';
  }
  rfq.updatedAt = nowIso;

  return existingQuote;
}
