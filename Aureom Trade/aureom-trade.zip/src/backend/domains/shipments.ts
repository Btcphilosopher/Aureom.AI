import {
  DeliveryDiscrepancy,
  DocumentRecord,
  Order,
  Shipment,
} from '../types';
import { MarketplaceDatabase } from './seed';
import { dispatchAllocatedStock } from './inventory';
import { issueCreditNote } from './payments';

export class ShipmentError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ShipmentError';
  }
}

export function createPartialOrFullShipment(params: {
  db: MarketplaceDatabase;
  orderId: string;
  lineDispatches: { orderLineId: string; cases: number }[];
  carrier: string;
  actorId: string;
  nowIso?: string;
}): Shipment {
  const {
    db,
    orderId,
    lineDispatches,
    carrier,
    actorId,
    nowIso = new Date().toISOString(),
  } = params;

  const order = db.orders.find((o) => o.id === orderId);
  if (!order) throw new ShipmentError(`Order ${orderId} not found.`);
  if (
    order.status !== 'Allocated' &&
    order.status !== 'Partially Dispatched' &&
    order.status !== 'Confirmed'
  ) {
    throw new ShipmentError(
      `Order ${orderId} in status ${order.status} cannot be dispatched.`,
    );
  }

  let totalCasesShipped = 0;
  let totalWeightKg = 0;

  for (const item of lineDispatches) {
    const line = order.lines.find((l) => l.id === item.orderLineId);
    if (!line) {
      throw new ShipmentError(`Order line ${item.orderLineId} not found.`);
    }
    const remainingToDispatch = line.casesOrdered - line.casesDispatched;
    if (item.cases <= 0 || item.cases > remainingToDispatch) {
      throw new ShipmentError(
        `Cannot dispatch ${item.cases} cases for ${line.sku}; remaining undispatched is ${remainingToDispatch}.`,
      );
    }

    dispatchAllocatedStock({
      inventory: db.inventory,
      reservations: db.reservations,
      ledger: db.stockLedger,
      orderId: order.id,
      sku: line.sku,
      casesToDispatch: item.cases,
      actorId,
      nowIso,
    });

    line.casesDispatched += item.cases;
    totalCasesShipped += item.cases;
    totalWeightKg += Number(
      (item.cases * line.packagingSnapshot.grossShippingWeightKgPerCase).toFixed(2),
    );
  }

  const allDispatched = order.lines.every(
    (l) => l.casesDispatched >= l.casesOrdered,
  );
  order.status = allDispatched ? 'Dispatched' : 'Partially Dispatched';
  order.updatedAt = nowIso;

  const shipmentId = `SHP-${Date.now().toString().slice(-5)}-${Math.random().toString(36).slice(2, 4).toUpperCase()}`;
  const eta = new Date(
    new Date(nowIso).getTime() + 4 * 24 * 60 * 60 * 1000,
  ).toISOString();

  // Create versioned system template documents for Commercial Invoice & Packing List
  const ciDoc: DocumentRecord = {
    id: `doc_ci_${shipmentId}`,
    organisationId: order.sellerOrgId,
    linkedEntityType: 'shipment',
    linkedEntityId: shipmentId,
    title: `Commercial Invoice Template — ${shipmentId}`,
    docType: 'Commercial_Invoice',
    version: 1,
    issuer: 'Aureom Trade Document Template Generator (Not an Official Customs Filing)',
    uploadedBy: actorId,
    uploadedAt: nowIso,
    isSystemTemplate: true,
    isOfficialCertificate: false,
    visibility: 'authorised_parties',
    summary: `Generated template for ${totalCasesShipped} cases under ${order.incoterm} ${order.namedPlace}.`,
  };
  const plDoc: DocumentRecord = {
    id: `doc_pl_${shipmentId}`,
    organisationId: order.sellerOrgId,
    linkedEntityType: 'shipment',
    linkedEntityId: shipmentId,
    title: `Packing List Template — ${shipmentId}`,
    docType: 'Packing_List',
    version: 1,
    issuer: 'Aureom Trade Document Template Generator (Not an Official Customs Filing)',
    uploadedBy: actorId,
    uploadedAt: nowIso,
    isSystemTemplate: true,
    isOfficialCertificate: false,
    visibility: 'authorised_parties',
    summary: `${totalCasesShipped} cartons, ${totalWeightKg} kg gross shipping weight.`,
  };
  db.documents.unshift(ciDoc, plDoc);

  const shipment: Shipment = {
    id: shipmentId,
    orderId: order.id,
    sellerOrgId: order.sellerOrgId,
    buyerOrgId: order.buyerOrgId,
    origin: order.namedPlace,
    destination: order.deliveryLocation,
    carrier,
    trackingNumber: `AUR-TRK-${Math.floor(1000000 + Math.random() * 8999999)}`,
    transportMode: order.transportMode,
    totalPackages: totalCasesShipped,
    totalGrossWeightKg: totalWeightKg,
    casesShipped: totalCasesShipped,
    dispatchedAt: nowIso,
    estimatedArrival: eta,
    status: 'In Transit',
    trackingEvents: [
      {
        id: `trk_${Date.now()}_1`,
        timestamp: nowIso,
        location: order.namedPlace,
        status: 'Dispatched from Warehouse',
        description: `Collected by ${carrier} (${totalCasesShipped} cases, ${totalWeightKg} kg gross).`,
        source: 'synthetic_carrier_feed',
      },
    ],
    discrepancies: [],
    commercialInvoiceDocId: ciDoc.id,
    packingListDocId: plDoc.id,
  };

  db.shipments.unshift(shipment);
  return shipment;
}

export function recordDeliveryAndDiscrepancy(params: {
  db: MarketplaceDatabase;
  shipmentId: string;
  orderLineId: string;
  deliveredCases: number;
  damagedCases: number;
  reason: string;
  actorId: string;
  autoIssueCreditNote: boolean;
  nowIso?: string;
}): {
  shipment: Shipment;
  order: Order;
  discrepancy?: DeliveryDiscrepancy;
  creditNoteId?: string;
} {
  const {
    db,
    shipmentId,
    orderLineId,
    deliveredCases,
    damagedCases,
    reason,
    actorId,
    autoIssueCreditNote,
    nowIso = new Date().toISOString(),
  } = params;

  const shipment = db.shipments.find((s) => s.id === shipmentId);
  if (!shipment) throw new ShipmentError(`Shipment ${shipmentId} not found.`);
  const order = db.orders.find((o) => o.id === shipment.orderId);
  if (!order) throw new ShipmentError(`Order ${shipment.orderId} not found.`);
  const line = order.lines.find((l) => l.id === orderLineId);
  if (!line) throw new ShipmentError(`Order line ${orderLineId} not found.`);

  const expected = shipment.casesShipped;
  if (deliveredCases < 0 || deliveredCases > expected) {
    throw new ShipmentError(
      `Delivered cases (${deliveredCases}) cannot exceed shipped cases (${expected}).`,
    );
  }
  if (damagedCases < 0 || damagedCases > deliveredCases) {
    throw new ShipmentError(
      `Damaged cases (${damagedCases}) cannot exceed delivered cases (${deliveredCases}).`,
    );
  }

  const shortageCases = Math.max(0, expected - deliveredCases);
  const netGoodCases = deliveredCases - damagedCases;
  line.casesDelivered += netGoodCases;

  // Update in-transit inventory count
  for (const alloc of line.batchAllocations) {
    const rec = db.inventory.find(
      (i) => i.sellerOrgId === order.sellerOrgId && i.sku === line.sku && i.batchNumber === alloc.batchNumber,
    );
    if (rec) {
      rec.inTransitCases = Math.max(0, rec.inTransitCases - expected);
      if (damagedCases > 0) {
        rec.damagedCases += damagedCases;
      }
      rec.updatedAt = nowIso;
    }
  }

  const hasDiscrepancy = shortageCases > 0 || damagedCases > 0;
  shipment.deliveredAt = nowIso;
  shipment.status = hasDiscrepancy ? 'Delivered with Discrepancy' : 'Delivered';
  shipment.trackingEvents.unshift({
    id: `trk_${Date.now()}_del`,
    timestamp: nowIso,
    location: shipment.destination,
    status: shipment.status,
    description: hasDiscrepancy
      ? `Received ${deliveredCases}/${expected} cases (${shortageCases} short, ${damagedCases} damaged).`
      : `Delivered in full (${deliveredCases} cases).`,
    source: 'manual_warehouse',
  });

  let discrepancy: DeliveryDiscrepancy | undefined;
  let creditNoteId: string | undefined;

  if (hasDiscrepancy) {
    const impactedCases = shortageCases + damagedCases;
    discrepancy = {
      id: `DISC-${Date.now().toString().slice(-5)}`,
      orderLineId: line.id,
      sku: line.sku,
      batchNumber: line.batchAllocations[0]?.batchNumber ?? 'UNKNOWN',
      expectedCases: expected,
      deliveredCases,
      shortageCases,
      damagedCases,
      reason: reason || 'Delivery discrepancy recorded at receiving bay',
      recordedBy: actorId,
      recordedAt: nowIso,
    };

    if (autoIssueCreditNote) {
      const invoice = db.invoices.find((inv) => inv.orderId === order.id);
      if (invoice) {
        const creditAmountMinor = impactedCases * line.unitPriceMinorPerCase;
        const { creditNote } = issueCreditNote({
          db,
          invoiceId: invoice.id,
          amountMinor: creditAmountMinor,
          reason: `Delivery discrepancy (${shortageCases} short, ${damagedCases} damaged) on ${shipment.id}: ${discrepancy.reason}`,
          issuedBy: actorId,
          discrepancyId: discrepancy.id,
          nowIso,
        });
        discrepancy.creditNoteId = creditNote.id;
        creditNoteId = creditNote.id;
      }
    }

    shipment.discrepancies.push(discrepancy);
    order.status = 'Disputed';
    order.disputeNote = discrepancy.reason;
  } else {
    const allDelivered = order.lines.every(
      (l) => l.casesDelivered >= l.casesOrdered,
    );
    if (allDelivered) {
      order.status = 'Delivered';
    }
  }

  order.updatedAt = nowIso;
  return { shipment, order, discrepancy, creditNoteId };
}
