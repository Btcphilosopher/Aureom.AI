import {
  InventoryRecord,
  StockLedgerEntry,
  StockReservation,
} from '../types';

export class InsufficientStockError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InsufficientStockError';
  }
}

export function availableCasesOf(record: InventoryRecord): number {
  if (record.withdrawn) return 0;
  return Math.max(
    0,
    record.onHandCases -
      record.reservedCases -
      record.quarantinedCases -
      record.damagedCases -
      record.expiredCases,
  );
}

/**
 * Serializes concurrent stock reservations per SKU so two concurrent orders
 * cannot reserve the same available stock.
 */
class AsyncMutex {
  private chain: Promise<void> = Promise.resolve();

  async runExclusive<T>(fn: () => T | Promise<T>): Promise<T> {
    let release!: () => void;
    const next = new Promise<void>((resolve) => {
      release = resolve;
    });
    const prev = this.chain;
    this.chain = prev.then(() => next);
    await prev;
    try {
      return await fn();
    } finally {
      release();
    }
  }
}

const reservationMutex = new AsyncMutex();

export async function reserveStockAtomic(params: {
  inventory: InventoryRecord[];
  reservations: StockReservation[];
  ledger: StockLedgerEntry[];
  sellerOrgId: string;
  sku: string;
  cases: number;
  orderId: string;
  actorId: string;
  ttlMinutes: number;
  nowIso?: string;
}): Promise<{
  createdReservations: StockReservation[];
  batchAllocations: { batchNumber: string; cases: number }[];
}> {
  const {
    inventory,
    reservations,
    ledger,
    sellerOrgId,
    sku,
    cases,
    orderId,
    actorId,
    ttlMinutes,
    nowIso = new Date().toISOString(),
  } = params;

  return reservationMutex.runExclusive(() => {
    // First expire any stale reservations
    releaseExpiredReservations(inventory, reservations, ledger, nowIso);

    const eligible = inventory
      .filter(
        (rec) =>
          rec.sellerOrgId === sellerOrgId &&
          rec.sku === sku &&
          !rec.withdrawn &&
          availableCasesOf(rec) > 0,
      )
      // FEFO: First Expired, First Out
      .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));

    const totalAvailable = eligible.reduce(
      (sum, rec) => sum + availableCasesOf(rec),
      0,
    );

    if (totalAvailable < cases) {
      throw new InsufficientStockError(
        `Insufficient available stock for ${sku}: requested ${cases} cases, available ${totalAvailable} cases.`,
      );
    }

    let remaining = cases;
    const createdReservations: StockReservation[] = [];
    const batchAllocations: { batchNumber: string; cases: number }[] = [];
    const expiresAt = new Date(
      new Date(nowIso).getTime() + ttlMinutes * 60_000,
    ).toISOString();

    for (const rec of eligible) {
      if (remaining <= 0) break;
      const avail = availableCasesOf(rec);
      const take = Math.min(avail, remaining);
      rec.reservedCases += take;
      rec.updatedAt = nowIso;

      const res: StockReservation = {
        id: `res_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        orderId,
        inventoryRecordId: rec.id,
        sku: rec.sku,
        batchNumber: rec.batchNumber,
        cases: take,
        expiresAt,
        status: 'active',
        createdAt: nowIso,
      };
      reservations.push(res);
      createdReservations.push(res);
      batchAllocations.push({ batchNumber: rec.batchNumber, cases: take });

      ledger.push({
        id: `led_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        timestamp: nowIso,
        inventoryRecordId: rec.id,
        sku: rec.sku,
        batchNumber: rec.batchNumber,
        movementType: 'reservation',
        deltaCases: -take,
        referenceId: orderId,
        actorId,
        note: `Atomic reservation (${take} cases) expires ${expiresAt}`,
      });

      remaining -= take;
    }

    return { createdReservations, batchAllocations };
  });
}

export function releaseExpiredReservations(
  inventory: InventoryRecord[],
  reservations: StockReservation[],
  ledger: StockLedgerEntry[],
  nowIso = new Date().toISOString(),
): number {
  let releasedCount = 0;
  for (const res of reservations) {
    if (res.status === 'active' && res.expiresAt <= nowIso) {
      res.status = 'expired';
      const rec = inventory.find((i) => i.id === res.inventoryRecordId);
      if (rec) {
        rec.reservedCases = Math.max(0, rec.reservedCases - res.cases);
        rec.updatedAt = nowIso;
        ledger.push({
          id: `led_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          timestamp: nowIso,
          inventoryRecordId: rec.id,
          sku: rec.sku,
          batchNumber: rec.batchNumber,
          movementType: 'adjustment',
          deltaCases: res.cases,
          referenceId: res.orderId,
          actorId: 'system_expiry_worker',
          note: `Reservation ${res.id} expired and released ${res.cases} cases`,
        });
      }
      releasedCount++;
    }
  }
  return releasedCount;
}

export function dispatchAllocatedStock(params: {
  inventory: InventoryRecord[];
  reservations: StockReservation[];
  ledger: StockLedgerEntry[];
  orderId: string;
  sku: string;
  casesToDispatch: number;
  actorId: string;
  nowIso?: string;
}): { batchNumber: string; cases: number }[] {
  const {
    inventory,
    reservations,
    ledger,
    orderId,
    sku,
    casesToDispatch,
    actorId,
    nowIso = new Date().toISOString(),
  } = params;

  let remaining = casesToDispatch;
  const dispatchedBatches: { batchNumber: string; cases: number }[] = [];

  const orderRes = reservations.filter(
    (r) =>
      r.orderId === orderId &&
      r.sku === sku &&
      (r.status === 'active' || r.status === 'allocated'),
  );

  for (const res of orderRes) {
    if (remaining <= 0) break;
    const take = Math.min(res.cases, remaining);
    const rec = inventory.find((i) => i.id === res.inventoryRecordId);
    if (rec) {
      rec.reservedCases = Math.max(0, rec.reservedCases - take);
      rec.onHandCases = Math.max(0, rec.onHandCases - take);
      rec.inTransitCases += take;
      rec.updatedAt = nowIso;
    }
    res.cases -= take;
    if (res.cases === 0) {
      res.status = 'dispatched';
    }
    dispatchedBatches.push({ batchNumber: res.batchNumber, cases: take });
    ledger.push({
      id: `led_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: nowIso,
      inventoryRecordId: res.inventoryRecordId,
      sku: res.sku,
      batchNumber: res.batchNumber,
      movementType: 'dispatch',
      deltaCases: -take,
      referenceId: orderId,
      actorId,
      note: `Dispatched ${take} cases from batch ${res.batchNumber}`,
    });
    remaining -= take;
  }

  if (remaining > 0) {
    throw new InsufficientStockError(
      `Cannot dispatch ${casesToDispatch} cases of ${sku} for order ${orderId}; only ${casesToDispatch - remaining} reserved.`,
    );
  }

  return dispatchedBatches;
}

export function withdrawBatch(params: {
  inventory: InventoryRecord[];
  ledger: StockLedgerEntry[];
  batchNumber: string;
  reason: string;
  actorId: string;
  nowIso?: string;
}): InventoryRecord[] {
  const {
    inventory,
    ledger,
    batchNumber,
    reason,
    actorId,
    nowIso = new Date().toISOString(),
  } = params;
  const affected: InventoryRecord[] = [];
  for (const rec of inventory) {
    if (rec.batchNumber === batchNumber) {
      const avail = availableCasesOf(rec);
      rec.withdrawn = true;
      rec.withdrawalReason = reason;
      rec.quarantinedCases += avail;
      rec.updatedAt = nowIso;
      affected.push(rec);
      ledger.push({
        id: `led_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        timestamp: nowIso,
        inventoryRecordId: rec.id,
        sku: rec.sku,
        batchNumber: rec.batchNumber,
        movementType: 'withdrawal',
        deltaCases: -avail,
        referenceId: `WD-${batchNumber}`,
        actorId,
        note: `Controlled product withdrawal: ${reason}`,
      });
    }
  }
  return affected;
}
