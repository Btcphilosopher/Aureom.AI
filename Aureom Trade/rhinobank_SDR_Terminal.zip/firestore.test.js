const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validWorkspace(uid, lifecycleState = "MANDATE_DRAFT", ts) {
  return {
    userId: uid,
    seriesCode: "RBN-2027-A",
    mandateCode: "PM-2047",
    purchaserName: "Pennine Global Treasury Ltd.",
    productLabel: "Rhino Custom SDR",
    methodology: "TARGET_WEIGHT",
    lifecycleState,
    principalAmount: "10000000.00",
    reportingCurrency: "USD",
    btcAllocationPct: "10.00",
    fundingModel: "UNSECURED_OBLIGATION",
    noteType: "BASKET_LINKED_PRINCIPAL",
    weightsSummary: "USD 35% / GBP 25% / EUR 15% / JPY 8% / CNY 7% / BTC 10%",
    termsVersion: 3,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validAuditEvent(uid, ts) {
  return {
    userId: uid,
    seriesCode: "RBN-2027-A",
    category: "ISSUANCE",
    action: "AUTHORISE_NOTE",
    actor: "treasury.approver@rhinobank.demo",
    detail: "Dual issuer approval recorded off-chain prior to registry submission.",
    documentCommitmentHash: "sha256_9f8e7d6c5b4a",
    idempotencyKey: "iss-rbn-2027-a-001",
    registryStatus: "PENDING_CONSENSUS",
    createdAt: ts,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write workspaces or audit events", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/workspaces`).get());
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/auditEvents`).get());
});

test("Cross-user isolation: Bob cannot read or create Alice's workspace", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.doc(`users/${ALICE_UID}/workspaces/ws_01`).set(
      validWorkspace(ALICE_UID, "MANDATE_DRAFT", new Date())
    );
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.doc(`users/${ALICE_UID}/workspaces/ws_01`).get());
  await assertFails(bobDb.collection(`users/${ALICE_UID}/workspaces`).get());
  await assertFails(
    bobDb.doc(`users/${ALICE_UID}/workspaces/ws_02`).set(
      validWorkspace(BOB_UID, "MANDATE_DRAFT", new Date())
    )
  );
});

test("Owner can create and list own workspace, and shadow ghost fields are rejected", async () => {
  const aliceCtx = testEnv.authenticatedContext(ALICE_UID);
  const aliceDb = aliceCtx.firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb.doc(`users/${ALICE_UID}/workspaces/ws_rbn_2027_a`).set(
      validWorkspace(ALICE_UID, "TERMS_APPROVED", now)
    )
  );

  await assertSucceeds(
    aliceDb.collection(`users/${ALICE_UID}/workspaces`).get()
  );

  const shadowPayload = validWorkspace(ALICE_UID, "TERMS_APPROVED", now);
  shadowPayload.isAdminBypass = true;
  await assertFails(
    aliceDb.doc(`users/${ALICE_UID}/workspaces/ws_shadow`).set(shadowPayload)
  );
});

test("Terminal state lock: REDEEMED workspace cannot be mutated or deleted", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.doc(`users/${ALICE_UID}/workspaces/ws_redeemed`).set(
      validWorkspace(ALICE_UID, "REDEEMED", now)
    )
  );

  await assertFails(
    aliceDb.doc(`users/${ALICE_UID}/workspaces/ws_redeemed`).update({
      lifecycleState: "ACTIVE",
      updatedAt: new Date(),
    })
  );

  await assertFails(
    aliceDb.doc(`users/${ALICE_UID}/workspaces/ws_redeemed`).delete()
  );
});

test("Audit events are append-only: create succeeds, update and delete fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const ref = aliceDb.doc(`users/${ALICE_UID}/auditEvents/evt_001`);

  await assertSucceeds(ref.set(validAuditEvent(ALICE_UID, now)));
  await assertFails(ref.update({ detail: "tampered history" }));
  await assertFails(ref.delete());
});
