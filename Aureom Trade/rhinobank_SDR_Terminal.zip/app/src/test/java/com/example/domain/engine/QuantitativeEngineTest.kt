package com.example.domain.engine

import com.example.domain.model.AssetCode
import com.example.domain.model.BasketComponent
import com.example.domain.model.BasketDefinition
import com.example.domain.model.BasketMethodology
import com.example.domain.model.BitcoinConfig
import com.example.domain.model.FundingModel
import com.example.domain.model.IssuanceLifecycleState
import com.example.domain.model.NoteStructure
import com.example.domain.model.NoteType
import com.example.domain.model.PurchaserMandate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class QuantitativeEngineTest {

    private fun pennineComponents(): List<BasketComponent> {
        val raw = listOf(
            BasketComponent(AssetCode.USD, true, BigDecimal("35.00"), BigDecimal.ZERO, BigDecimal("1.0000"), BigDecimal("1.0000")),
            BasketComponent(AssetCode.GBP, true, BigDecimal("25.00"), BigDecimal.ZERO, BigDecimal("1.2800"), BigDecimal("1.2800")),
            BasketComponent(AssetCode.EUR, true, BigDecimal("15.00"), BigDecimal.ZERO, BigDecimal("1.0900"), BigDecimal("1.0900")),
            BasketComponent(AssetCode.JPY, true, BigDecimal("8.00"), BigDecimal.ZERO, BigDecimal("154.0000"), BigDecimal("154.0000")),
            BasketComponent(AssetCode.CNY, true, BigDecimal("7.00"), BigDecimal.ZERO, BigDecimal("7.2200"), BigDecimal("7.2200")),
            BasketComponent(AssetCode.BTC, true, BigDecimal("10.00"), BigDecimal.ZERO, BigDecimal("94000.00"), BigDecimal("94000.00"))
        )
        return QuantitativeEngine.deriveInitialQuantities(BigDecimal("10000000.00"), raw)
    }

    private fun pennineBasket(methodology: BasketMethodology = BasketMethodology.TARGET_WEIGHT): BasketDefinition {
        return BasketDefinition(
            basketId = "BSK-PM2047-V3",
            name = "Pennine Custom Reserve Basket",
            baseDate = "2026-11-15",
            baseIndexLevel = BigDecimal("100.00"),
            reportingCurrency = "USD",
            methodology = methodology,
            rebalancingSchedule = "Quarterly (15th of Mar/Jun/Sep/Dec)",
            rebalancingCostBps = 12,
            managementFeeBps = 25,
            roundingScale = 4,
            disruptionRule = "Postpone fixing up to 5 business days; fall back to calculation agent dealer poll.",
            replacementRule = "Substitute only via approved custody/settlement adapter + purchaser consent.",
            components = pennineComponents()
        )
    }

    private fun pennineMandate(): PurchaserMandate {
        return PurchaserMandate(
            mandateCode = "PM-2047",
            version = 3,
            legalEntityName = "Pennine Global Treasury Ltd.",
            jurisdiction = "England & Wales",
            leiCode = "549300PENNINE002047",
            authorisedRepresentatives = listOf("H. Vance (Group Treasurer)", "M. Okafor (CIO)"),
            eligibilityClass = "Institutional / Eligible Counterparty",
            subscriptionAmount = BigDecimal("10000000.00"),
            subscriptionCurrency = "USD",
            preferredReportingCurrency = "USD",
            investmentHorizonMonths = 24,
            liquidityRequirement = "Quarterly redemption gate (T+5 notice)",
            permittedAssets = AssetCode.entries.toSet(),
            maxSingleAssetConcentrationPct = BigDecimal("40.00"),
            maxBitcoinAllocationPct = BigDecimal("10.00"),
            preferredMethodology = BasketMethodology.TARGET_WEIGHT,
            rebalancingPreference = "Quarterly",
            redemptionRequirement = "USD cash settlement at maturity",
            requiredApprovals = listOf("Treasury Dual Approval", "Risk Officer Sign-off"),
            distributionRestriction = "Private placement only; Reg S / QIB equivalent",
            transferRestriction = "Restricted registered note; issuer registrar consent required",
            purchaserAccepted = true,
            acceptanceTimestampUtc = "2026-11-15T09:10:00Z"
        )
    }

    private fun pennineNote(): NoteStructure {
        return NoteStructure(
            seriesCode = "RBN-2027-A",
            productLabel = "Rhino Custom SDR",
            issuerEntity = "RhinoBank Demo Issuer",
            purchaserEntity = "Pennine Global Treasury Ltd.",
            noteType = NoteType.BASKET_LINKED_PRINCIPAL,
            principalAmount = BigDecimal("10000000.00"),
            denominationUnit = BigDecimal("100000.00"),
            subscriptionCurrency = "USD",
            issuePricePct = BigDecimal("100.00"),
            basketReferenceId = "BSK-PM2047-V3",
            participationRatePct = BigDecimal("100.00"),
            couponFormula = "Zero coupon; total-return linked at maturity",
            annualCouponBps = 0,
            structuringFeeBps = 15,
            ongoingFeeBps = 25,
            maturityMonths = 24,
            redemptionFormula = "Principal * (I_T / I_0) - Accrued Fees",
            settlementCurrency = "USD",
            earlyTerminationProvision = "Permitted quarterly with 5 BD notice less unwind cost",
            ranking = "Senior unsecured contractual obligation",
            securityArrangement = "Unsecured issuer obligation",
            fundingModel = FundingModel.UNSECURED_OBLIGATION,
            transferRestriction = "Restricted registered note — no bearer/permissionless transfer",
            defaultProvision = "Standard 5 BD payment grace; English law dispute forum",
            governingDocuments = listOf("Master Note Deed v3", "Series RBN-2027-A Pricing Supplement"),
            capitalProtectionFloorPct = null,
            capitalProtectionDisclaimer = "No principal protection; 100% subject to basket performance and issuer credit risk.",
            termsVersion = 3,
            termsLocked = true
        )
    }

    @Test
    fun fxInversion_jpyAndCnyConvertAccurately() {
        val usdPerJpy = QuantitativeEngine.usdPricePerUnit(AssetCode.JPY, BigDecimal("154.0000"))
        // 154 JPY = 1 USD -> 154 * usdPerJpy == 1.000000
        val reconstructed = usdPerJpy.multiply(BigDecimal("154.0000"))
            .setScale(6, java.math.RoundingMode.HALF_EVEN)
        assertEquals(BigDecimal("1.000000"), reconstructed)
    }

    @Test
    fun basketArithmetic_fixedQuantityBaseValueMatchesTenMillion() {
        val basket = pennineBasket(BasketMethodology.FIXED_QUANTITY)
        val baseValue = QuantitativeEngine.calculateFixedQuantityBasketValue(basket.components, useBasePrices = true)
        assertEquals(BigDecimal("10000000.00"), baseValue)
        assertTrue(QuantitativeEngine.isWeightSumValid(basket.components))
    }

    @Test
    fun rebalancing_computesNonZeroTurnoverWhenSpotDrifts() {
        val drifted = pennineComponents().map {
            if (it.asset == AssetCode.BTC) it.copy(currentSpotRate = BigDecimal("141000.00")) else it
        }
        val basket = pennineBasket(BasketMethodology.TARGET_WEIGHT).copy(components = drifted)
        val (turnover, cost) = QuantitativeEngine.calculateRebalancingTurnoverAndCost(basket, BigDecimal("10000000.00"))
        assertTrue(turnover > BigDecimal("400000.00"))
        assertTrue(cost > BigDecimal.ZERO)
    }

    @Test
    fun mandateValidation_flagsBtcBreachAndStalePriceWithoutRewriting() {
        val overBtc = pennineComponents().map {
            when (it.asset) {
                AssetCode.BTC -> it.copy(targetWeightPct = BigDecimal("15.00"), isStalePrice = true)
                AssetCode.USD -> it.copy(targetWeightPct = BigDecimal("30.00"))
                else -> it
            }
        }
        val basket = pennineBasket().copy(components = overBtc)
        val issues = QuantitativeEngine.validateMandateCompatibility(
            mandate = pennineMandate(),
            basket = basket,
            note = pennineNote(),
            bitcoinConfig = BitcoinConfig()
        )
        assertTrue(issues.any { it.code == "BTC_LIMIT_EXCEEDED" })
        assertTrue(issues.any { it.code == "STALE_PRICE_BTC" })
        // Instruction not silently rewritten:
        assertEquals(BigDecimal("15.00"), basket.components.first { it.asset == AssetCode.BTC }.targetWeightPct)
    }

    @Test
    fun stressScenarios_btcDown50PercentProducesApproximatelyMinus5PctImpact() {
        val scenarios = QuantitativeEngine.runReproducibleStressScenarios(
            basket = pennineBasket(BasketMethodology.FIXED_QUANTITY),
            note = pennineNote(),
            seed = 20270115L
        )
        val btcDown = scenarios.first { it.id == "btc_down_50" }
        assertEquals(BigDecimal("-5.00"), btcDown.basketImpactPct)
        val btcUp = scenarios.first { it.id == "btc_up_50" }
        assertEquals(BigDecimal("5.00"), btcUp.basketImpactPct)
    }

    @Test
    fun couponAndLifecycle_enforceDeterministicRules() {
        val coupon = QuantitativeEngine.calculatePeriodicCouponUsd(
            remainingPrincipalUsd = BigDecimal("10000000.00"),
            annualCouponBps = 400,
            basketIndexRatio = BigDecimal("1.05"),
            noteType = NoteType.FIXED_COUPON_BASKET,
            periodsPerYear = 2
        )
        assertEquals(BigDecimal("210000.00"), coupon)

        assertTrue(QuantitativeEngine.canAdvanceLifecycle(IssuanceLifecycleState.TERMS_APPROVED, IssuanceLifecycleState.SUBSCRIPTION_OPEN))
        assertFalse(QuantitativeEngine.canAdvanceLifecycle(IssuanceLifecycleState.TERMS_APPROVED, IssuanceLifecycleState.ACTIVE))
        assertFalse(QuantitativeEngine.canAdvanceLifecycle(IssuanceLifecycleState.REDEEMED, IssuanceLifecycleState.ACTIVE))
    }
}
