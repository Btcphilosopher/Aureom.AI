package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AuditEventDoc
import com.example.data.model.MandateVersionDoc
import com.example.data.model.SavedWorkspaceDoc
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class RhinoFirestoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveAndObserveWorkspace_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = RhinoFirestoreRepository(firestore)
        val docId = "ws_${UUID.randomUUID().toString().take(8)}"

        val workspace = SavedWorkspaceDoc(
            seriesCode = "RBN-2027-A",
            mandateCode = "PM-2047",
            purchaserName = "Pennine Global Treasury Ltd.",
            productLabel = "Rhino Custom SDR",
            methodology = "TARGET_WEIGHT",
            lifecycleState = "TERMS_APPROVED",
            principalAmount = "10000000.00",
            reportingCurrency = "USD",
            btcAllocationPct = "10.00",
            fundingModel = "UNSECURED_OBLIGATION",
            noteType = "BASKET_LINKED_PRINCIPAL",
            weightsSummary = "USD 35% / GBP 25% / EUR 15% / JPY 8% / CNY 7% / BTC 10%",
            termsVersion = 3
        )

        val saveResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveWorkspace(workspace, customDocId = docId)
        }
        assertTrue("Save workspace failed: ${saveResult.exceptionOrNull()}", saveResult.isSuccess)
        assertEquals(docId, saveResult.getOrThrow())

        val observed = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeWorkspaces(uid).first { list -> list.any { it.id == docId } }
        }
        assertTrue(observed.any { it.id == docId && it.seriesCode == "RBN-2027-A" })
    }

    @Test
    fun appendMandateVersionAndAuditEvent_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = RhinoFirestoreRepository(firestore)
        val versionId = "mv_${UUID.randomUUID().toString().take(8)}"
        val eventId = "evt_${UUID.randomUUID().toString().take(8)}"

        val mandateResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveMandateVersion(
                MandateVersionDoc(
                    mandateCode = "PM-2047",
                    versionNumber = 3,
                    purchaserLegalEntity = "Pennine Global Treasury Ltd.",
                    subscriptionCurrency = "USD",
                    subscriptionAmount = "10000000.00",
                    bitcoinLimitPct = "10.00",
                    purchaserAccepted = true,
                    incompatibilitySummary = "0 blocking issues"
                ),
                docId = versionId
            )
        }
        assertTrue(mandateResult.isSuccess)

        val auditResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.appendAuditEvent(
                AuditEventDoc(
                    seriesCode = "RBN-2027-A",
                    category = "ISSUANCE",
                    action = "MANDATE_COUNTERSINGED",
                    actor = ALICE_EMAIL,
                    detail = "Mandate PM-2047 v3 accepted and hashed.",
                    documentCommitmentHash = "sha256_demo_commitment_001",
                    idempotencyKey = "idem_$eventId",
                    registryStatus = "OFF_CHAIN"
                ),
                docId = eventId
            )
        }
        assertTrue(auditResult.isSuccess)

        val events = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeAuditEvents(uid).first { list -> list.any { it.id == eventId } }
        }
        assertTrue(events.any { it.id == eventId })
    }

    @Test
    fun observeWorkspaces_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = RhinoFirestoreRepository(firestore)
        val docId = "ws_${UUID.randomUUID().toString().take(8)}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.saveWorkspace(
                SavedWorkspaceDoc(
                    seriesCode = "RBN-2027-A",
                    mandateCode = "PM-2047",
                    purchaserName = "Pennine Global Treasury Ltd.",
                    weightsSummary = "USD 35% / BTC 10%"
                ),
                customDocId = docId
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = RhinoFirestoreRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeWorkspaces(aliceUid).first()
            }
        } catch (t: Throwable) {
            caught = t
        }
        val firestoreEx = checkNotNull(caught?.unwrapFirestoreException()) {
            "Expected FirebaseFirestoreException for cross-user read, got $caught"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx.code)
    }

    @Test
    fun observeWorkspaces_unauthenticatedCaller_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = RhinoFirestoreRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeWorkspaces("any_user_id").first()
            }
        } catch (t: Throwable) {
            caught = t
        }
        val firestoreEx = checkNotNull(caught?.unwrapFirestoreException()) {
            "Expected FirebaseFirestoreException when signed out, got $caught"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_treasury@rhinobank.test"
        const val BOB_EMAIL = "bob_external@rhinobank.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3500L
    }
}
