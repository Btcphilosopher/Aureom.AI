package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.engine.QuantitativeEngine
import com.example.domain.model.AssetCode
import com.example.domain.model.BasketMethodology
import com.example.domain.model.BitcoinExposureType
import com.example.domain.model.IssuanceLifecycleState
import com.example.ui.components.BasketDonutChart
import com.example.ui.components.ComponentSelectorRow
import com.example.ui.components.KeyValueMetricRow
import com.example.ui.components.LifecycleStepperStrip
import com.example.ui.components.RegulatoryNoticeBanner
import com.example.ui.components.ScenarioHorizontalBar
import com.example.ui.components.StatusBadge
import com.example.ui.components.TerminalPanel
import com.example.ui.components.formatUsd
import com.example.ui.theme.AmberException
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldMuted
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyanSelected
import com.example.ui.theme.CyanSurface
import com.example.ui.theme.ElevatedSlatePanel
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.IvoryHeading
import com.example.ui.theme.MonoFinancialMedium
import com.example.ui.theme.MonoFinancialSmall
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.PlatinumDivider
import com.example.ui.theme.PlatinumText
import com.example.ui.theme.SlateMuted
import com.example.ui.viewmodel.TerminalUiState
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun BasketStudioSection(
    state: TerminalUiState,
    onSelectComponent: (AssetCode) -> Unit,
    onToggleComponent: (AssetCode) -> Unit,
    onUpdateWeight: (AssetCode, BigDecimal) -> Unit,
    onSelectMethodology: (BasketMethodology) -> Unit,
    onSetBitcoinExposure: (BitcoinExposureType) -> Unit,
    onSaveDraft: () -> Unit,
    onSubmitApproval: () -> Unit,
    onAuthoriseIssuance: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        // Breadcrumb & Header Row matching institutional workstation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Purchaser mandates  /  ${state.mandate.mandateCode}  /  Series ${state.noteStructure.seriesCode}",
                    style = MonoFinancialSmall,
                    color = SlateMuted
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Custom Reserve Note — Purchaser Configuration",
                    style = MaterialTheme.typography.headlineMedium,
                    color = IvoryHeading
                )
                Text(
                    text = "Private RhinoBank basket-linked note  •  Not an IMF allocation or official reserve asset  •  Registered ownership",
                    style = MaterialTheme.typography.bodySmall,
                    color = ChampagneGold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onSaveDraft,
                    modifier = Modifier.testTag("save_draft_button"),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Save,
                        contentDescription = "Save draft",
                        tint = PlatinumText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save draft", color = IvoryHeading)
                }
                Button(
                    onClick = onSubmitApproval,
                    modifier = Modifier.testTag("submit_approval_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ChampagneGold,
                        contentColor = ObsidianVoid
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("Submit for approval", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Responsive 3-column desktop/tablet workstation OR stacked mobile layout
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val isWideWorkstation = maxWidth >= 920.dp
            if (isWideWorkstation) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.weight(0.28f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PurchaserMandatePanel(state)
                        ComponentLibraryPanel(state, onSelectComponent, onToggleComponent, onUpdateWeight, onSetBitcoinExposure)
                    }
                    Column(
                        modifier = Modifier.weight(0.44f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        BasketCompositionPanel(state, onSelectMethodology)
                        ScenarioAnalysisPanel(state)
                        RegisteredNoteLifecyclePanel(state)
                    }
                    Column(
                        modifier = Modifier.weight(0.28f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        NoteTermsPanel(state)
                        IssuanceControlsPanel(state, onAuthoriseIssuance)
                        BlockchainRegistrySummaryPanel(state)
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PurchaserMandatePanel(state)
                    BasketCompositionPanel(state, onSelectMethodology)
                    ComponentLibraryPanel(state, onSelectComponent, onToggleComponent, onUpdateWeight, onSetBitcoinExposure)
                    ScenarioAnalysisPanel(state)
                    RegisteredNoteLifecyclePanel(state)
                    NoteTermsPanel(state)
                    IssuanceControlsPanel(state, onAuthoriseIssuance)
                    BlockchainRegistrySummaryPanel(state)
                }
            }
        }
    }
}

@Composable
private fun PurchaserMandatePanel(state: TerminalUiState) {
    TerminalPanel(
        title = "Purchaser Mandate",
        badgeText = if (state.mandate.purchaserAccepted) "v${state.mandate.version} ACCEPTED" else "DRAFT",
        badgeColor = if (state.mandate.purchaserAccepted) EmeraldVerified else AmberException
    ) {
        Text(
            text = state.mandate.legalEntityName,
            style = MaterialTheme.typography.headlineSmall,
            color = IvoryHeading
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(EmeraldVerified)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = state.mandate.eligibilityClass,
                style = MaterialTheme.typography.bodySmall,
                color = SlateMuted
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        KeyValueMetricRow("Subscription", formatUsd(state.mandate.subscriptionAmount, 0), CyanSelected)
        KeyValueMetricRow("Horizon", "${state.mandate.investmentHorizonMonths} months", IvoryHeading)
        KeyValueMetricRow("Reporting currency", state.mandate.preferredReportingCurrency, IvoryHeading)
        KeyValueMetricRow("Bitcoin limit", "${state.mandate.maxBitcoinAllocationPct.stripTrailingZeros().toPlainString()}%", ChampagneGold)
        KeyValueMetricRow("Transfer", state.mandate.transferRestriction, PlatinumText, monoValue = false)

        val blockingCount = state.incompatibilities.count { it.severity == "BLOCK" }
        if (blockingCount > 0) {
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(
                text = "$blockingCount blocking mandate incompatibility detected (instructions preserved; no silent rewrite).",
                isWarning = true
            )
        }
    }
}

@Composable
private fun ComponentLibraryPanel(
    state: TerminalUiState,
    onSelectComponent: (AssetCode) -> Unit,
    onToggleComponent: (AssetCode) -> Unit,
    onUpdateWeight: (AssetCode, BigDecimal) -> Unit,
    onSetBitcoinExposure: (BitcoinExposureType) -> Unit
) {
    TerminalPanel(title = "Component Library", badgeText = "ADAPTERS VERIFIED", badgeColor = EmeraldVerified) {
        Text(
            text = "Approved currency & digital-asset adapters only. Select component to inspect or adjust allocation.",
            style = MaterialTheme.typography.bodySmall,
            color = SlateMuted
        )
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            state.basket.components.forEach { comp ->
                ComponentSelectorRow(
                    component = comp,
                    selected = comp.asset == state.selectedComponent,
                    onClick = { onSelectComponent(comp.asset) },
                    modifier = Modifier.testTag("component_row_${comp.asset.ticker.lowercase()}")
                )
            }
        }

        val activeComp = state.basket.components.first { it.asset == state.selectedComponent }
        Spacer(modifier = Modifier.height(10.dp))
        Surface(
            color = ElevatedSlatePanel,
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, PlatinumDivider),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${activeComp.asset.displayName} (${activeComp.asset.ticker})",
                        style = MaterialTheme.typography.titleMedium,
                        color = IvoryHeading
                    )
                    Switch(
                        checked = activeComp.enabled,
                        onCheckedChange = { onToggleComponent(activeComp.asset) },
                        modifier = Modifier.testTag("toggle_component_${activeComp.asset.ticker.lowercase()}"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianVoid,
                            checkedTrackColor = ChampagneGold
                        )
                    )
                }
                Text(
                    text = "Target weight: ${activeComp.targetWeightPct.toPlainString()}%  •  Qty: ${activeComp.fixedQuantity.setScale(4, RoundingMode.HALF_EVEN).toPlainString()}",
                    style = MonoFinancialSmall,
                    color = CyanSelected
                )
                Slider(
                    value = activeComp.targetWeightPct.toFloat(),
                    onValueChange = { raw ->
                        val snapped = BigDecimal(raw.toDouble()).setScale(0, RoundingMode.HALF_EVEN)
                        onUpdateWeight(activeComp.asset, snapped)
                    },
                    valueRange = 0f..50f,
                    colors = SliderDefaults.colors(
                        thumbColor = ChampagneGold,
                        activeTrackColor = ChampagneGold
                    )
                )
                Text(
                    text = "Custody: ${activeComp.asset.custodyAdapter}\nFX: ${activeComp.asset.fxConvention.conventionLabel}\nFallback: ${activeComp.asset.fallbackRule}",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateMuted
                )
                if (activeComp.asset == AssetCode.BTC) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "BITCOIN EXPOSURE CLASSIFICATION",
                        style = MonoFinancialSmall,
                        color = ChampagneGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    BitcoinExposureType.entries.forEach { expType ->
                        val isChosen = state.bitcoinConfig.exposureType == expType
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isChosen) CyanSurface else ObsidianVoid)
                                .border(
                                    1.dp,
                                    if (isChosen) CyanSelected else PlatinumDivider,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { onSetBitcoinExposure(expType) }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = expType.label,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isChosen) CyanSelected else PlatinumText
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = state.bitcoinConfig.verificationLimitNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberException
                    )
                }
            }
        }
    }
}

@Composable
private fun BasketCompositionPanel(
    state: TerminalUiState,
    onSelectMethodology: (BasketMethodology) -> Unit
) {
    val totalWeight = QuantitativeEngine.totalEnabledWeightPct(state.basket.components)
    val weightValid = QuantitativeEngine.isWeightSumValid(state.basket.components)
    val effectiveWeights = QuantitativeEngine.effectiveWeightsUsd(state.basket.components)

    TerminalPanel(
        title = "Basket Composition",
        badgeText = if (weightValid) "100.00% VALID" else "${totalWeight.toPlainString()}% INVALID",
        badgeColor = if (weightValid) EmeraldVerified else CrimsonAlert
    ) {
        // Explicit Methodology Selector (Never mix invisibly)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BasketMethodology.entries.forEach { meth ->
                val active = state.basket.methodology == meth
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) CyanSurface else ObsidianVoid)
                        .border(
                            1.dp,
                            if (active) CyanSelected else PlatinumDivider,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectMethodology(meth) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("methodology_${meth.name.lowercase()}")
                ) {
                    Column {
                        Text(
                            text = meth.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (active) CyanSelected else IvoryHeading
                        )
                        Text(
                            text = if (meth == BasketMethodology.TARGET_WEIGHT) state.basket.rebalancingSchedule else "Base quantities locked",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateMuted
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            BasketDonutChart(
                components = state.basket.components,
                totalWeightText = "${totalWeight.toPlainString()}%",
                chartSize = 148.dp
            )
            Column(modifier = Modifier.weight(1f)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Asset", style = MonoFinancialSmall, color = SlateMuted, modifier = Modifier.weight(0.9f))
                    Text("Weight", style = MonoFinancialSmall, color = SlateMuted, modifier = Modifier.weight(1f))
                    Text("Exposure (USD)", style = MonoFinancialSmall, color = SlateMuted, modifier = Modifier.weight(1.3f))
                }
                state.basket.components.filter { it.enabled }.forEach { comp ->
                    val usdExp = comp.fixedQuantity.multiply(
                        QuantitativeEngine.usdPricePerUnit(comp.asset, comp.currentSpotRate),
                        QuantitativeEngine.MC
                    ).setScale(0, RoundingMode.HALF_EVEN)
                    val shownWeight = if (state.basket.methodology == BasketMethodology.TARGET_WEIGHT) {
                        comp.targetWeightPct
                    } else {
                        effectiveWeights[comp.asset] ?: comp.targetWeightPct
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(0.9f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(comp.asset.accentColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(comp.asset.ticker, style = MonoFinancialSmall, color = IvoryHeading)
                        }
                        Text(
                            text = "${shownWeight.toPlainString()}%",
                            style = MonoFinancialSmall,
                            color = PlatinumText,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = formatUsd(usdExp, 0),
                            style = MonoFinancialSmall,
                            color = CyanSelected,
                            modifier = Modifier.weight(1.3f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Total", style = MonoFinancialSmall.copy(fontWeight = FontWeight.Bold), color = IvoryHeading, modifier = Modifier.weight(0.9f))
                    Text("${totalWeight.toPlainString()}%", style = MonoFinancialSmall.copy(fontWeight = FontWeight.Bold), color = IvoryHeading, modifier = Modifier.weight(1f))
                    Text(formatUsd(state.valuation.basketReferenceValueUsd, 0), style = MonoFinancialSmall.copy(fontWeight = FontWeight.Bold), color = CyanSelected, modifier = Modifier.weight(1.3f))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Methodology: ${state.basket.methodology.title}  •  Base index: ${state.valuation.normalisedIndex.toPlainString()}  •  Index level is NOT withdrawable cash.",
            style = MaterialTheme.typography.bodySmall,
            color = SlateMuted
        )
    }
}

@Composable
private fun ScenarioAnalysisPanel(state: TerminalUiState) {
    TerminalPanel(title = "Scenario Analysis", badgeText = "SEED 20270115", badgeColor = ChampagneGold) {
        Text(
            text = "Illustrative basket impact before fees (reproducible deterministic shocks).",
            style = MaterialTheme.typography.bodySmall,
            color = SlateMuted
        )
        Spacer(modifier = Modifier.height(6.dp))
        state.stressScenarios.take(3).forEach { scenario ->
            ScenarioHorizontalBar(scenario = scenario)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Scenarios, not forecasts. Historical correlations & single VaR metrics are incomplete risk measures.",
            style = MaterialTheme.typography.bodySmall,
            color = SlateMuted
        )
    }
}

@Composable
private fun RegisteredNoteLifecyclePanel(state: TerminalUiState) {
    TerminalPanel(
        title = "Registered Note Lifecycle",
        badgeText = state.lifecycleState.displayName.uppercase(),
        badgeColor = if (state.lifecycleState == IssuanceLifecycleState.ACTIVE) EmeraldVerified else AmberException
    ) {
        LifecycleStepperStrip(currentState = state.lifecycleState)
    }
}

@Composable
private fun NoteTermsPanel(state: TerminalUiState) {
    val note = state.noteStructure
    TerminalPanel(title = "Note Terms", badgeText = note.productLabel, badgeColor = ChampagneGold) {
        KeyValueMetricRow("Series", note.seriesCode, CyanSelected)
        KeyValueMetricRow("Issuer", note.issuerEntity, IvoryHeading, monoValue = false)
        KeyValueMetricRow("Type", note.noteType.label, PlatinumText, monoValue = false)
        KeyValueMetricRow("Principal", "${formatUsd(note.principalAmount, 0)} ${note.subscriptionCurrency}", CyanSelected)
        KeyValueMetricRow("Term", "${note.maturityMonths} months", IvoryHeading)
        KeyValueMetricRow("Redemption", note.redemptionFormula, PlatinumText, monoValue = false)
        KeyValueMetricRow("Coupon", note.couponFormula, PlatinumText, monoValue = false)
        KeyValueMetricRow("Security", note.securityArrangement, AmberException, monoValue = false)
        Spacer(modifier = Modifier.height(8.dp))
        RegulatoryNoticeBanner(text = "Rhino Custom SDR • Private contractual note, NOT an IMF SDR.")
    }
}

@Composable
private fun IssuanceControlsPanel(
    state: TerminalUiState,
    onAuthoriseIssuance: () -> Unit
) {
    val check = state.checklist
    val readyToAuthorise = check.allSatisfied && state.incompatibilities.none { it.severity == "BLOCK" }

    TerminalPanel(title = "Issuance Controls") {
        ControlCheckItem(
            passed = check.pricingInputsValid && QuantitativeEngine.isWeightSumValid(state.basket.components),
            text = "Basket weights validated."
        )
        ControlCheckItem(
            passed = check.termsApproved,
            text = "Terms version v${state.noteStructure.termsVersion} locked."
        )
        ControlCheckItem(
            passed = check.subscriptionFundsVerified,
            isPendingWarning = !check.subscriptionFundsVerified,
            text = if (check.subscriptionFundsVerified) "Subscription funds verified." else "Funding confirmation pending."
        )
        ControlCheckItem(
            passed = check.issuerDualApprovalOne && check.issuerDualApprovalTwo,
            text = if (check.issuerDualApprovalOne && check.issuerDualApprovalTwo) "Dual approval recorded." else "Dual approval required."
        )

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = onAuthoriseIssuance,
            enabled = readyToAuthorise,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("authorise_issuance_button"),
            shape = RoundedCornerShape(6.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ChampagneGold,
                contentColor = ObsidianVoid,
                disabledContainerColor = ChampagneGoldMuted,
                disabledContentColor = SlateMuted
            )
        ) {
            Text("Authorise note issuance", fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (readyToAuthorise) "Ready for idempotent registry submission." else "Available after required approvals (open Issue tab).",
            style = MaterialTheme.typography.bodySmall,
            color = SlateMuted
        )
    }
}

@Composable
private fun ControlCheckItem(
    passed: Boolean,
    text: String,
    isPendingWarning: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = when {
                passed -> Icons.Filled.CheckCircle
                isPendingWarning -> Icons.Filled.Warning
                else -> Icons.Filled.RadioButtonUnchecked
            },
            contentDescription = null,
            tint = when {
                passed -> EmeraldVerified
                isPendingWarning -> AmberException
                else -> SlateMuted
            },
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = if (passed) PlatinumText else if (isPendingWarning) AmberException else SlateMuted
        )
    }
}

@Composable
private fun BlockchainRegistrySummaryPanel(state: TerminalUiState) {
    val net = state.poSNetwork
    TerminalPanel(title = "Blockchain Registry", badgeText = "TESTNET", badgeColor = CyanSelected) {
        KeyValueMetricRow("Record type", "Registered note (non-bearer)", IvoryHeading, monoValue = false)
        KeyValueMetricRow("Network", "PoS demonstration", PlatinumText, monoValue = false)
        KeyValueMetricRow("Validator set", "${net.validatorCount} nodes (RhinoBank)", PlatinumText, monoValue = false)
        KeyValueMetricRow("Finalised height", net.finalisedHeight.toString(), CyanSelected)
        KeyValueMetricRow("Indexer lag", "${net.indexerLagMs} ms", EmeraldVerified)
        KeyValueMetricRow("Series status", state.lifecycleState.displayName, if (state.lifecycleState == IssuanceLifecycleState.ACTIVE) EmeraldVerified else AmberException)
        KeyValueMetricRow("Ownership", "Authorised register only", PlatinumText, monoValue = false)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Consensus verifies records, not backing, asset values, or issuer solvency.",
            style = MaterialTheme.typography.bodySmall,
            color = SlateMuted
        )
    }
}
