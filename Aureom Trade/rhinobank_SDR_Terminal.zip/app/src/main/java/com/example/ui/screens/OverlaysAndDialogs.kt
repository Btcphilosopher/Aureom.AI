package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.BasketMethodology
import com.example.ui.components.KeyValueMetricRow
import com.example.ui.components.RegulatoryNoticeBanner
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberException
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyanSelected
import com.example.ui.theme.ElevatedSlatePanel
import com.example.ui.theme.IvoryHeading
import com.example.ui.theme.MidnightPanel
import com.example.ui.theme.MonoFinancialSmall
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.PlatinumDivider
import com.example.ui.theme.PlatinumText
import com.example.ui.theme.SlateMuted
import com.example.ui.viewmodel.AiUiState
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun AiStructuringDialog(
    state: TerminalUiState,
    onAskAi: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var promptText by remember {
        mutableStateOf("Explain the differences between Target-Weight and Fixed-Quantity for RBN-2027-A, summarise the BTC -50% scenario, and flag any missing approvals.")
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = MidnightPanel,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, ChampagneGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("AI Structuring Assistant", style = MaterialTheme.typography.headlineSmall, color = IvoryHeading)
                    StatusBadge("ADVISORY ONLY", AmberException)
                }
                RegulatoryNoticeBanner(
                    text = "AI cites deterministic engine records and NEVER approves its own proposals. Human dual-authorisation is mandatory."
                )

                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    label = { Text("Structuring prompt") },
                    modifier = Modifier.fillMaxWidth().testTag("ai_prompt_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChampagneGold,
                        unfocusedBorderColor = PlatinumDivider,
                        focusedTextColor = IvoryHeading,
                        unfocusedTextColor = PlatinumText
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onAskAi(promptText) },
                        enabled = state.aiUiState !is AiUiState.Loading && promptText.isNotBlank(),
                        modifier = Modifier.weight(1f).testTag("run_ai_analysis_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianVoid)
                    ) {
                        if (state.aiUiState is AiUiState.Loading) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ObsidianVoid, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Analysing...")
                        } else {
                            Text("Generate Draft Analysis", fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedButton(onClick = onDismiss, border = BorderStroke(1.dp, PlatinumDivider)) {
                        Text("Close", color = PlatinumText)
                    }
                }

                when (val ai = state.aiUiState) {
                    AiUiState.Idle -> {
                        Text("Submit a structuring query to analyse Mandate ${state.mandate.mandateCode} or Series ${state.noteStructure.seriesCode}.", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    }
                    AiUiState.Loading -> {
                        Text("Running Gemini structured analysis via Firebase AI Logic...", style = MonoFinancialSmall, color = CyanSelected)
                    }
                    is AiUiState.Error -> {
                        Surface(
                            color = CrimsonSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, CrimsonAlert),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "AI Error: ${ai.message}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CrimsonAlert,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                    is AiUiState.Success -> {
                        val p = ai.proposal
                        Surface(
                            color = ElevatedSlatePanel,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, CyanSelected),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(p.summaryTitle, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                                Text(p.analysisNarrative, style = MaterialTheme.typography.bodySmall, color = PlatinumText)
                                Text("Proposed Changes (Unapproved):", style = MonoFinancialSmall, color = CyanSelected)
                                p.proposedChanges.forEach { ch ->
                                    Text("• $ch", style = MaterialTheme.typography.bodySmall, color = IvoryHeading)
                                }
                                Text("Cited Records: ${p.citedRecordIds.joinToString(", ")}", style = MonoFinancialSmall, color = SlateMuted)
                                if (p.missingTermsOrWarnings.isNotEmpty()) {
                                    Text("Warnings: ${p.missingTermsOrWarnings.joinToString(" | ")}", style = MaterialTheme.typography.bodySmall, color = AmberException)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ComparisonWorkspaceDialog(
    state: TerminalUiState,
    onDismiss: () -> Unit
) {
    val latestPoint = state.backtestPoints.lastOrNull()
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = MidnightPanel,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, CyanSelected),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Purchaser Comparison Workspace", style = MaterialTheme.typography.headlineSmall, color = IvoryHeading)
                    StatusBadge("HYPOTHETICAL", AmberException)
                }
                Text(
                    text = "Comparing Target-Weight Quarterly vs Fixed-Quantity Buy-and-Hold vs USD Benchmark (no future-data leakage).",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateMuted
                )

                KeyValueMetricRow("Active Series", "${state.noteStructure.seriesCode} (${state.noteStructure.productLabel})", CyanSelected, monoValue = false)
                KeyValueMetricRow("Target-Weight Hypothetical Index", latestPoint?.targetWeightIndex?.toPlainString() ?: "100.00", CyanSelected)
                KeyValueMetricRow("Fixed-Quantity Hypothetical Index", latestPoint?.fixedQtyIndex?.toPlainString() ?: "100.00", ChampagneGold)
                KeyValueMetricRow("USD Cash Benchmark Index", latestPoint?.benchmarkUsdOnly?.toPlainString() ?: "100.00", SlateMuted)
                KeyValueMetricRow("Rebalance Cost Assumption", "${state.basket.rebalancingCostBps} bps/rebalance", PlatinumText)
                KeyValueMetricRow("Redemption Mechanics", state.noteStructure.redemptionFormula, IvoryHeading, monoValue = false)
                KeyValueMetricRow("Issuer & Custody Exposure", "${state.noteStructure.fundingModel.label} • ${state.bitcoinConfig.exposureType.label}", AmberException, monoValue = false)

                RegulatoryNoticeBanner(
                    text = "Modifying a basket after issuance requires a contractually permitted amendment with purchaser consent or a new series (${BasketMethodology.TARGET_WEIGHT.title} vs ${BasketMethodology.FIXED_QUANTITY.title})."
                )

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanSelected, contentColor = ObsidianVoid)
                ) {
                    Text("Close Comparison", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
