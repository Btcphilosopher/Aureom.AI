package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BasketComponent
import com.example.domain.model.IssuanceLifecycleState
import com.example.domain.model.StressScenarioResult
import com.example.ui.theme.AmberException
import com.example.ui.theme.AmberSurface
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldMuted
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSurface
import com.example.ui.theme.CyanSelected
import com.example.ui.theme.CyanSurface
import com.example.ui.theme.EmeraldSurface
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.IvoryHeading
import com.example.ui.theme.MidnightPanel
import com.example.ui.theme.MonoFinancialMedium
import com.example.ui.theme.MonoFinancialSmall
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.PlatinumDivider
import com.example.ui.theme.PlatinumText
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SubtleGridLine
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Locale

fun formatUsd(amount: BigDecimal, decimals: Int = 2): String {
    val nf = NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = decimals
        maximumFractionDigits = decimals
    }
    return "$${nf.format(amount)}"
}

@Composable
fun TerminalPanel(
    title: String,
    modifier: Modifier = Modifier,
    badgeText: String? = null,
    badgeColor: Color = CyanSelected,
    accentGoldBorder: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        color = MidnightPanel,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (accentGoldBorder) ChampagneGold.copy(alpha = 0.65f) else PlatinumDivider
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    color = ChampagneGold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (badgeText != null) {
                    StatusBadge(text = badgeText, color = badgeColor)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(SubtleGridLine)
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun StatusBadge(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    val bg = when (color) {
        CyanSelected -> CyanSurface
        EmeraldVerified -> EmeraldSurface
        AmberException -> AmberSurface
        CrimsonAlert -> CrimsonSurface
        else -> ChampagneGoldMuted
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            style = MonoFinancialSmall.copy(fontWeight = FontWeight.SemiBold),
            color = color,
            maxLines = 1
        )
    }
}

@Composable
fun KeyValueMetricRow(
    label: String,
    value: String,
    valueColor: Color = PlatinumText,
    monoValue: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = SlateMuted,
            modifier = Modifier.weight(1f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            style = if (monoValue) MonoFinancialMedium else MaterialTheme.typography.bodyMedium,
            color = valueColor,
            fontWeight = FontWeight.SemiBold
        )
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(0.5.dp)
            .background(SubtleGridLine)
    )
}

@Composable
fun RegulatoryNoticeBanner(
    text: String,
    modifier: Modifier = Modifier,
    isWarning: Boolean = false
) {
    val borderColor = if (isWarning) AmberException else ChampagneGold.copy(alpha = 0.5f)
    val bgColor = if (isWarning) AmberSurface else ChampagneGoldMuted.copy(alpha = 0.5f)
    val iconColor = if (isWarning) AmberException else ChampagneGold

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isWarning) Icons.Filled.Warning else Icons.Filled.Info,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = IvoryHeading.copy(alpha = 0.92f)
        )
    }
}

@Composable
fun BasketDonutChart(
    components: List<BasketComponent>,
    totalWeightText: String,
    chartSize: Dp = 156.dp,
    modifier: Modifier = Modifier
) {
    val enabled = components.filter { it.enabled && it.targetWeightPct > BigDecimal.ZERO }
    val total = enabled.fold(0f) { acc, c -> acc + c.targetWeightPct.toFloat() }.coerceAtLeast(1f)

    Box(
        modifier = modifier.size(chartSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(chartSize)) {
            val strokePx = 28.dp.toPx()
            val inset = strokePx / 2f + 4f
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            var startAngle = -90f
            for (comp in enabled) {
                val sweep = (comp.targetWeightPct.toFloat() / total) * 360f
                drawArc(
                    color = comp.asset.accentColor,
                    startAngle = startAngle,
                    sweepAngle = (sweep - 2f).coerceAtLeast(1f),
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Butt)
                )
                startAngle += sweep
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "BASKET\nWEIGHTS",
                style = MaterialTheme.typography.labelSmall,
                color = SlateMuted,
                lineHeight = 12.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = totalWeightText,
                style = MonoFinancialMedium.copy(fontWeight = FontWeight.Bold),
                color = IvoryHeading
            )
        }
    }
}

@Composable
fun ScenarioHorizontalBar(
    scenario: StressScenarioResult,
    modifier: Modifier = Modifier
) {
    val impactFloat = scenario.basketImpactPct.toFloat()
    val isPositive = impactFloat >= 0f
    val barColor = if (isPositive) CyanSelected else AmberException
    val magnitude = (kotlin.math.abs(impactFloat) / 15f).coerceIn(0.06f, 1f)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = scenario.label,
                style = MaterialTheme.typography.bodyMedium,
                color = PlatinumText,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${if (isPositive) "+" else ""}${scenario.basketImpactPct.toPlainString()}%",
                style = MonoFinancialMedium.copy(fontWeight = FontWeight.Bold),
                color = barColor
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        // Diverging center-axis bar track
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(ObsidianVoid)
                .border(0.5.dp, SubtleGridLine, RoundedCornerShape(3.dp))
        ) {
            // Center baseline
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(1.5.dp)
                    .fillMaxHeight()
                    .background(SlateMuted)
            )
            Row(modifier = Modifier.fillMaxWidth().fillMaxHeight()) {
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    if (!isPositive) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(magnitude)
                                .fillMaxHeight()
                                .background(barColor)
                        )
                    }
                }
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (isPositive) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(magnitude)
                                .fillMaxHeight()
                                .background(barColor)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LifecycleStepperStrip(
    currentState: IssuanceLifecycleState,
    modifier: Modifier = Modifier
) {
    val milestones = listOf(
        IssuanceLifecycleState.TERMS_APPROVED to "Terms approved",
        IssuanceLifecycleState.FUNDS_VERIFIED to "Funding review",
        IssuanceLifecycleState.ISSUANCE_AUTHORISED to "Issuer authorisation",
        IssuanceLifecycleState.ACTIVE to "Registry finality"
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        milestones.forEachIndexed { index, (milestoneState, label) ->
            val reached = !currentState.isException && currentState.stepOrder >= milestoneState.stepOrder
            val isCurrent = currentState.stepOrder == milestoneState.stepOrder ||
                (index == 1 && currentState.stepOrder in 2..4)

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                currentState.isException -> CrimsonSurface
                                reached -> EmeraldSurface
                                isCurrent -> AmberSurface
                                else -> ObsidianVoid
                            }
                        )
                        .border(
                            width = 1.5.dp,
                            color = when {
                                currentState.isException -> CrimsonAlert
                                reached -> EmeraldVerified
                                isCurrent -> AmberException
                                else -> PlatinumDivider
                            },
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            currentState.isException -> Icons.Filled.Error
                            reached -> Icons.Filled.CheckCircle
                            isCurrent -> Icons.Filled.Warning
                            else -> Icons.Filled.Lock
                        },
                        contentDescription = label,
                        tint = when {
                            currentState.isException -> CrimsonAlert
                            reached -> EmeraldVerified
                            isCurrent -> AmberException
                            else -> SlateMuted
                        },
                        modifier = Modifier.size(14.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (reached) IvoryHeading else SlateMuted,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (index < milestones.lastIndex) {
                Box(
                    modifier = Modifier
                        .width(14.dp)
                        .height(2.dp)
                        .background(if (reached) EmeraldVerified else PlatinumDivider)
                )
            }
        }
    }
}

@Composable
fun ComponentSelectorRow(
    component: BasketComponent,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) ChampagneGoldMuted else ObsidianVoid.copy(alpha = 0.65f))
            .border(
                width = 1.dp,
                color = if (selected) ChampagneGold else PlatinumDivider,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (component.enabled) component.asset.accentColor else SlateMuted.copy(alpha = 0.3f))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(ObsidianVoid)
                .border(1.dp, PlatinumDivider, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = component.asset.ticker,
                style = MonoFinancialSmall.copy(fontWeight = FontWeight.Bold),
                color = if (selected) ChampagneGold else IvoryHeading
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = component.asset.displayName,
            style = MaterialTheme.typography.bodyMedium,
            color = if (component.enabled) PlatinumText else SlateMuted,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "${component.targetWeightPct.toPlainString()}%",
            style = MonoFinancialMedium.copy(fontWeight = FontWeight.SemiBold),
            color = if (selected) ChampagneGold else CyanSelected
        )
    }
}
