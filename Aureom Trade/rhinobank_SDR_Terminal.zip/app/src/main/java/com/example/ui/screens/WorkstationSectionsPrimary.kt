package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.engine.QuantitativeEngine
import com.example.domain.model.IssuanceLifecycleState
import com.example.domain.model.NoteType
import com.example.ui.components.KeyValueMetricRow
import com.example.ui.components.LifecycleStepperStrip
import com.example.ui.components.RegulatoryNoticeBanner
import com.example.ui.components.StatusBadge
import com.example.ui.components.TerminalPanel
import com.example.ui.components.formatUsd
import com.example.ui.theme.AmberException
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldMuted
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyanSelected
import com.example.ui.theme.CyanSurface
import com.example.ui.theme.ElevatedSlatePanel
import com.example.ui.theme.EmeraldSurface
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.IvoryHeading
import com.example.ui.theme.MonoFinancialLarge
import com.example.ui.theme.MonoFinancialMedium
import com.example.ui.theme.MonoFinancialSmall
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.PlatinumDivider
import com.example.ui.theme.PlatinumText
import com.example.ui.theme.SlateMuted
import com.example.ui.viewmodel.TerminalUiState
import java.math.BigDecimal

@Composable
fun OverviewSection(
    state: TerminalUiState,
    onRunDemoStep: (Int) -> Unit,
    onOpenComparison: () -> Unit,
    onOpenAiAssistant: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Executive Workstation Overview — Rhino Custom SDR",
            badgeText = state.lifecycleState.displayName.uppercase(),
            badgeColor = if (state.lifecycleState == IssuanceLifecycleState.ACTIVE) EmeraldVerified else ChampagneGold,
            accentGoldBorder = true
        ) {
            Text(
                text = "Private RhinoBank basket-linked note. Not an IMF allocation or official reserve asset.",
                style = MaterialTheme.typography.titleMedium,
                color = ChampagneGold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Institutional demonstration mandate for ${state.mandate.legalEntityName} (${state.mandate.mandateCode}), Series ${state.noteStructure.seriesCode}. Custom 5-currency + optional 10% Bitcoin reserve note.",
                style = MaterialTheme.typography.bodyMedium,
                color = PlatinumText
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile("Basket Value", formatUsd(state.valuation.basketReferenceValueUsd), CyanSelected, Modifier.weight(1f))
                MetricTile("Normalised Index", state.valuation.normalisedIndex.toPlainString(), IvoryHeading, Modifier.weight(1f))
                MetricTile("Model Value", formatUsd(state.valuation.noteModelValueUsd), ChampagneGold, Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpenAiAssistant,
                    modifier = Modifier.testTag("open_ai_assistant_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianVoid)
                ) {
                    Text("AI Structuring Assistant", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onOpenComparison,
                    modifier = Modifier.testTag("open_comparison_button"),
                    border = BorderStroke(1.dp, CyanSelected)
                ) {
                    Text("Compare Configs", color = CyanSelected)
                }
            }
        }

        // 14-Step Complete Demonstration Walkthrough
        TerminalPanel(
            title = "14-Step End-to-End Institutional Demonstration",
            badgeText = "STEP ${state.activeDemoStep} / 14",
            badgeColor = CyanSelected
        ) {
            Text(
                text = "Demonstration mandate only — not a recommended allocation. Tap any step to execute & inspect.",
                style = MaterialTheme.typography.bodySmall,
                color = SlateMuted
            )
            Spacer(modifier = Modifier.height(8.dp))
            state.demoSteps.forEach { step ->
                val isActive = step.number == state.activeDemoStep
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isActive) CyanSurface else ObsidianVoid)
                        .border(
                            1.dp,
                            if (isActive) CyanSelected else PlatinumDivider,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onRunDemoStep(step.number) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("demo_step_${step.number}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = step.number.toString().padStart(2, '0'),
                        style = MonoFinancialMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (step.completed) EmeraldVerified else ChampagneGold
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(step.title, style = MaterialTheme.typography.bodyMedium, color = IvoryHeading, fontWeight = FontWeight.SemiBold)
                        Text(step.description, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    }
                    Icon(
                        imageVector = if (step.completed) Icons.Filled.CheckCircle else Icons.Filled.PlayArrow,
                        contentDescription = "Run step ${step.number}",
                        tint = if (step.completed) EmeraldVerified else ChampagneGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Trading Terminal Integration
        TerminalPanel(
            title = "Trading-Terminal Integration (Controlled Dealer Venues)",
            badgeText = if (state.tradingListings.any { it.published }) "PUBLISHED" else "PRE-ISSUANCE",
            badgeColor = if (state.tradingListings.any { it.published }) EmeraldVerified else AmberException
        ) {
            RegulatoryNoticeBanner(
                text = "Issuance approval, trading eligibility, and legal market admission remain strictly separate. Custom Rhino baskets are NOT official IMF SDR instruments."
            )
            Spacer(modifier = Modifier.height(8.dp))
            state.tradingListings.forEach { venue ->
                Surface(
                    color = ElevatedSlatePanel,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(venue.venueName, style = MaterialTheme.typography.titleMedium, color = IvoryHeading)
                            StatusBadge(
                                text = venue.rfqStatus,
                                color = if (venue.published) EmeraldVerified else AmberException
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        KeyValueMetricRow("Series / Contract", "${venue.seriesCode} (v${venue.contractVersion})", CyanSelected)
                        KeyValueMetricRow("Indicative Bid / Ask", "${venue.indicativeBidPct}% / ${venue.indicativeAskPct}%", ChampagneGold)
                        KeyValueMetricRow("Transfer Restriction", venue.transferRestrictions, PlatinumText, monoValue = false)
                        KeyValueMetricRow("Legal Admission", venue.legalAdmissionStatus, SlateMuted, monoValue = false)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = ElevatedSlatePanel,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, PlatinumDivider)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MonoFinancialLarge, color = color)
        }
    }
}

@Composable
fun PurchasersSection(
    state: TerminalUiState,
    onUpdateBtcLimit: (BigDecimal) -> Unit,
    onAcceptMandate: () -> Unit,
    onSaveMandateToCloud: () -> Unit
) {
    val m = state.mandate
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Purchaser Mandate & Eligibility — ${m.mandateCode}",
            badgeText = if (m.purchaserAccepted) "ACCEPTED v${m.version}" else "PENDING ACCEPTANCE",
            badgeColor = if (m.purchaserAccepted) EmeraldVerified else AmberException
        ) {
            KeyValueMetricRow("Legal Entity", m.legalEntityName, IvoryHeading, monoValue = false)
            KeyValueMetricRow("LEI / Jurisdiction", "${m.leiCode} • ${m.jurisdiction}", PlatinumText, monoValue = false)
            KeyValueMetricRow("Authorised Reps", m.authorisedRepresentatives.joinToString("; "), PlatinumText, monoValue = false)
            KeyValueMetricRow("Investor Eligibility", m.eligibilityClass, EmeraldVerified, monoValue = false)
            KeyValueMetricRow("Subscription", "${formatUsd(m.subscriptionAmount)} ${m.subscriptionCurrency}", CyanSelected)
            KeyValueMetricRow("Reporting Currency", m.preferredReportingCurrency, IvoryHeading)
            KeyValueMetricRow("Horizon & Liquidity", "${m.investmentHorizonMonths}m • ${m.liquidityRequirement}", PlatinumText, monoValue = false)
            KeyValueMetricRow("Single-Asset Cap", "${m.maxSingleAssetConcentrationPct.toPlainString()}%", ChampagneGold)
            KeyValueMetricRow("Bitcoin Limit", "${m.maxBitcoinAllocationPct.toPlainString()}%", ChampagneGold)
            KeyValueMetricRow("Preferred Methodology", m.preferredMethodology.title, CyanSelected, monoValue = false)
            KeyValueMetricRow("Required Approvals", m.requiredApprovals.joinToString(", "), PlatinumText, monoValue = false)
            KeyValueMetricRow("Distribution & Transfer", "${m.distributionRestriction} / ${m.transferRestriction}", PlatinumText, monoValue = false)

            Spacer(modifier = Modifier.height(10.dp))
            Text("Test Mandate BTC Allocation Limit (does NOT silently rewrite basket):", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("0.00", "5.00", "10.00", "15.00").forEach { cap ->
                    OutlinedButton(
                        onClick = { onUpdateBtcLimit(BigDecimal(cap)) },
                        border = BorderStroke(1.dp, if (m.maxBitcoinAllocationPct == BigDecimal(cap)) ChampagneGold else PlatinumDivider)
                    ) {
                        Text("$cap%", style = MonoFinancialSmall, color = ChampagneGold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onAcceptMandate,
                    enabled = !m.purchaserAccepted,
                    modifier = Modifier.testTag("accept_mandate_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldVerified, contentColor = ObsidianVoid)
                ) {
                    Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (m.purchaserAccepted) "Accepted" else "Countersign Mandate", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = onSaveMandateToCloud, border = BorderStroke(1.dp, CyanSelected)) {
                    Text("Persist Version", color = CyanSelected)
                }
            }
        }

        TerminalPanel(
            title = "Automated Mandate Incompatibility Checks",
            badgeText = "${state.incompatibilities.size} ITEMS",
            badgeColor = if (state.incompatibilities.any { it.severity == "BLOCK" }) CrimsonAlert else EmeraldVerified
        ) {
            if (state.incompatibilities.isEmpty()) {
                Text("All basket, term, and custody parameters comply with Mandate ${m.mandateCode} v${m.version}.", style = MaterialTheme.typography.bodyMedium, color = EmeraldVerified)
            } else {
                state.incompatibilities.forEach { issue ->
                    val isBlock = issue.severity == "BLOCK"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isBlock) com.example.ui.theme.CrimsonSurface else com.example.ui.theme.AmberSurface)
                            .border(1.dp, if (isBlock) CrimsonAlert else AmberException, RoundedCornerShape(6.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = if (isBlock) CrimsonAlert else AmberException, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("${issue.severity}: ${issue.code}", style = MonoFinancialSmall, color = if (isBlock) CrimsonAlert else AmberException)
                            Text(issue.message, style = MaterialTheme.typography.bodySmall, color = IvoryHeading)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StructureSection(
    state: TerminalUiState,
    onSelectNoteType: (NoteType) -> Unit
) {
    val note = state.noteStructure
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Note Structure Builder — ${note.seriesCode}",
            badgeText = "TERMS v${note.termsVersion}",
            badgeColor = ChampagneGold
        ) {
            Text("Select Contractual Structure Type:", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
            Spacer(modifier = Modifier.height(6.dp))
            NoteType.entries.forEach { nt ->
                val active = note.noteType == nt
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) CyanSurface else ObsidianVoid)
                        .border(1.dp, if (active) CyanSelected else PlatinumDivider, RoundedCornerShape(6.dp))
                        .clickable { onSelectNoteType(nt) }
                        .padding(10.dp)
                ) {
                    Column {
                        Text(nt.label, style = MaterialTheme.typography.titleMedium, color = if (active) CyanSelected else IvoryHeading)
                        Text(nt.description, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            KeyValueMetricRow("Product Label", note.productLabel, ChampagneGold, monoValue = false)
            KeyValueMetricRow("Issuer / Purchaser", "${note.issuerEntity} -> ${note.purchaserEntity}", IvoryHeading, monoValue = false)
            KeyValueMetricRow("Principal / Denomination", "${formatUsd(note.principalAmount)} / ${formatUsd(note.denominationUnit)}", CyanSelected)
            KeyValueMetricRow("Issue Price / Participation", "${note.issuePricePct}% / ${note.participationRatePct}%", IvoryHeading)
            KeyValueMetricRow("Structuring / Ongoing Fee", "${note.structuringFeeBps} bps / ${note.ongoingFeeBps} bps p.a.", PlatinumText)
            KeyValueMetricRow("Coupon Formula", note.couponFormula, PlatinumText, monoValue = false)
            KeyValueMetricRow("Redemption Formula", note.redemptionFormula, PlatinumText, monoValue = false)
            KeyValueMetricRow("Ranking / Security", "${note.ranking} • ${note.securityArrangement}", AmberException, monoValue = false)
            KeyValueMetricRow("Early Termination", note.earlyTerminationProvision, PlatinumText, monoValue = false)
            KeyValueMetricRow("Default Provisions", note.defaultProvision, PlatinumText, monoValue = false)
            KeyValueMetricRow("Governing Docs", note.governingDocuments.joinToString(", "), SlateMuted, monoValue = false)
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(text = note.capitalProtectionDisclaimer, isWarning = true)
        }
    }
}

@Composable
fun PriceSection(
    state: TerminalUiState,
    onToggleStalePrice: (com.example.domain.model.AssetCode) -> Unit
) {
    val v = state.valuation
    val (turnover, rebalCost) = QuantitativeEngine.calculateRebalancingTurnoverAndCost(
        state.basket,
        state.noteStructure.principalAmount
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Separated Valuation & Pricing Engine",
            badgeText = state.valuationTimestampUtc,
            badgeColor = CyanSelected
        ) {
            KeyValueMetricRow("1. Basket Reference Value (B_t)", formatUsd(v.basketReferenceValueUsd), CyanSelected)
            KeyValueMetricRow("   Normalised Index (I_t = I_0 * B_t/B_0)", v.normalisedIndex.toPlainString(), IvoryHeading)
            KeyValueMetricRow("2. Note Model Value (DCF + Spread)", formatUsd(v.noteModelValueUsd), ChampagneGold)
            KeyValueMetricRow("3. Subscription Price", formatUsd(v.subscriptionPriceUsd), EmeraldVerified)
            KeyValueMetricRow("4. Redemption Entitlement (Net of Fees)", formatUsd(v.redemptionEntitlementUsd), IvoryHeading)
            KeyValueMetricRow("Accrued Ongoing & Mgmt Fees (6m)", formatUsd(v.accruedFeesUsd), AmberException)
            KeyValueMetricRow("Est. Quarterly Rebalance Turnover / Cost", "${formatUsd(turnover)} / ${formatUsd(rebalCost)}", SlateMuted)
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(text = "Index level I_t is a calculation reference only and NEVER represents money available for withdrawal.")
        }

        TerminalPanel(title = "FX Quotation Conventions & Stale-Price Guard") {
            state.basket.components.filter { it.enabled }.forEach { comp ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${comp.asset.ticker} • ${comp.asset.fxConvention.conventionLabel}", style = MaterialTheme.typography.bodyMedium, color = IvoryHeading)
                        Text("Spot: ${comp.currentSpotRate.toPlainString()} | Source: ${comp.asset.priceSource}", style = MonoFinancialSmall, color = if (comp.isStalePrice) CrimsonAlert else SlateMuted)
                    }
                    OutlinedButton(
                        onClick = { onToggleStalePrice(comp.asset) },
                        border = BorderStroke(1.dp, if (comp.isStalePrice) CrimsonAlert else PlatinumDivider)
                    ) {
                        Text(if (comp.isStalePrice) "Stale ON" else "Simulate Stale", style = MonoFinancialSmall, color = if (comp.isStalePrice) CrimsonAlert else SlateMuted)
                    }
                }
            }
        }
    }
}

@Composable
fun IssueSection(
    state: TerminalUiState,
    onVerifyFundingAndApprovals: () -> Unit,
    onAuthoriseIssuance: () -> Unit,
    onConfirmFinality: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Issuance Lifecycle & Segregation of Duties",
            badgeText = state.lifecycleState.displayName.uppercase(),
            badgeColor = if (state.lifecycleState == IssuanceLifecycleState.ACTIVE) EmeraldVerified else ChampagneGold
        ) {
            LifecycleStepperStrip(currentState = state.lifecycleState)
            Spacer(modifier = Modifier.height(10.dp))
            KeyValueMetricRow("Eligible Purchaser", if (state.checklist.eligiblePurchaserVerified) "Verified" else "Pending", EmeraldVerified)
            KeyValueMetricRow("Approved Terms & Pricing", if (state.checklist.termsApproved && state.checklist.pricingInputsValid) "Locked & Valid" else "Blocked", if (state.checklist.pricingInputsValid) EmeraldVerified else CrimsonAlert)
            KeyValueMetricRow("Subscription Funds ($10M)", if (state.checklist.subscriptionFundsVerified) "Fedwire Confirmed" else "Awaiting Confirmation", if (state.checklist.subscriptionFundsVerified) EmeraldVerified else AmberException)
            KeyValueMetricRow("Dual Issuer Approvals", if (state.checklist.issuerDualApprovalOne && state.checklist.issuerDualApprovalTwo) "2 / 2 Recorded" else "0 / 2 Recorded", if (state.checklist.issuerDualApprovalOne) EmeraldVerified else AmberException)
            KeyValueMetricRow("Segregation of Duties", if (state.checklist.segregationOfDutiesPassed) "Enforced (Structurer != Approver)" else "Violation", EmeraldVerified)

            Spacer(modifier = Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onVerifyFundingAndApprovals,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("verify_funding_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanSelected, contentColor = ObsidianVoid)
                ) {
                    Text("1. Verify Subscription Funds & Dual Approvals", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onAuthoriseIssuance,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("submit_registry_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianVoid)
                ) {
                    Text("2. Authorise Idempotent Issuance -> Submit Registry", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onConfirmFinality,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_finality_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldVerified, contentColor = ObsidianVoid)
                ) {
                    Text("3. Confirm PoS Finality & External Settlement -> Activate", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(
                text = "Submitting a blockchain transaction NEVER marks a note Active. Both PoS consensus finality and external settlement confirmation are required."
            )
        }
    }
}
