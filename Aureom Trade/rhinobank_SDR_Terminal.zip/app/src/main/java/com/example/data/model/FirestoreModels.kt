package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class SavedWorkspaceDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val seriesCode: String = "",
    val mandateCode: String = "",
    val purchaserName: String = "",
    val productLabel: String = "Rhino Custom SDR",
    val methodology: String = "TARGET_WEIGHT",
    val lifecycleState: String = "TERMS_APPROVED",
    val principalAmount: String = "10000000.00",
    val reportingCurrency: String = "USD",
    val btcAllocationPct: String = "10.00",
    val fundingModel: String = "UNSECURED_OBLIGATION",
    val noteType: String = "BASKET_LINKED_PRINCIPAL",
    val weightsSummary: String = "",
    val termsVersion: Int = 3,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "seriesCode" to seriesCode,
            "mandateCode" to mandateCode,
            "purchaserName" to purchaserName,
            "productLabel" to productLabel,
            "methodology" to methodology,
            "lifecycleState" to lifecycleState,
            "principalAmount" to principalAmount,
            "reportingCurrency" to reportingCurrency,
            "btcAllocationPct" to btcAllocationPct,
            "fundingModel" to fundingModel,
            "noteType" to noteType,
            "weightsSummary" to weightsSummary,
            "termsVersion" to termsVersion,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    fun toUpdateMap(): Map<String, Any> {
        return mapOf(
            "mandateCode" to mandateCode,
            "purchaserName" to purchaserName,
            "productLabel" to productLabel,
            "methodology" to methodology,
            "lifecycleState" to lifecycleState,
            "principalAmount" to principalAmount,
            "reportingCurrency" to reportingCurrency,
            "btcAllocationPct" to btcAllocationPct,
            "fundingModel" to fundingModel,
            "noteType" to noteType,
            "weightsSummary" to weightsSummary,
            "termsVersion" to termsVersion,
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}

@IgnoreExtraProperties
data class MandateVersionDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val mandateCode: String = "",
    val versionNumber: Int = 1,
    val purchaserLegalEntity: String = "",
    val subscriptionCurrency: String = "USD",
    val subscriptionAmount: String = "10000000.00",
    val bitcoinLimitPct: String = "10.00",
    val purchaserAccepted: Boolean = false,
    val incompatibilitySummary: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "mandateCode" to mandateCode,
            "versionNumber" to versionNumber,
            "purchaserLegalEntity" to purchaserLegalEntity,
            "subscriptionCurrency" to subscriptionCurrency,
            "subscriptionAmount" to subscriptionAmount,
            "bitcoinLimitPct" to bitcoinLimitPct,
            "purchaserAccepted" to purchaserAccepted,
            "incompatibilitySummary" to incompatibilitySummary,
            "createdAt" to FieldValue.serverTimestamp()
        )
    }
}

@IgnoreExtraProperties
data class AuditEventDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val seriesCode: String = "",
    val category: String = "ISSUANCE",
    val action: String = "",
    val actor: String = "",
    val detail: String = "",
    val documentCommitmentHash: String = "",
    val idempotencyKey: String = "",
    val registryStatus: String = "OFF_CHAIN",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "seriesCode" to seriesCode,
            "category" to category,
            "action" to action,
            "actor" to actor,
            "detail" to detail,
            "documentCommitmentHash" to documentCommitmentHash,
            "idempotencyKey" to idempotencyKey,
            "registryStatus" to registryStatus,
            "createdAt" to FieldValue.serverTimestamp()
        )
    }
}
