package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian & Midnight Navy Institutional Surfaces
val ObsidianVoid = Color(0xFF070C14)
val MidnightPanel = Color(0xFF0D1624)
val ElevatedSlatePanel = Color(0xFF132033)
val DeepInputSurface = Color(0xFF09111C)
val GlassOverlay = Color(0xCC0D1624)

// Borders & Dividers
val PlatinumDivider = Color(0xFF283A52)
val SubtleGridLine = Color(0xFF1B293C)
val GoldHairline = Color(0xFF8C7239)

// Typography Colors
val IvoryHeading = Color(0xFFF3EFE4)
val PlatinumText = Color(0xFFD6DFEA)
val SlateMuted = Color(0xFF8C9DB5)
val DimLabel = Color(0xFF64748B)

// Institutional Accents
val ChampagneGold = Color(0xFFD9B25F)
val ChampagneGoldMuted = Color(0xFF332917)
val CyanSelected = Color(0xFF22D3EE)
val CyanSurface = Color(0xFF0F2D3A)
val EmeraldVerified = Color(0xFF34D399)
val EmeraldSurface = Color(0xFF0E2F26)
val AmberException = Color(0xFFF59E0B)
val AmberSurface = Color(0xFF33240C)
val CrimsonAlert = Color(0xFFF87171)
val CrimsonSurface = Color(0xFF351418)

// Basket Component Asset Colors (matching reference chart)
val AssetUsdColor = Color(0xFF2563EB)
val AssetGbpColor = Color(0xFF06B6D4)
val AssetEurColor = Color(0xFF0EA5E9)
val AssetJpyColor = Color(0xFF6366F1)
val AssetCnyColor = Color(0xFF8B5CF6)
val AssetBtcColor = Color(0xFFEAB308)
