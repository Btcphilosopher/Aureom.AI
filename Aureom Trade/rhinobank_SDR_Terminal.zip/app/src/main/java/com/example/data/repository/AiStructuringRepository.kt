package com.example.data.repository

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class AiStructuringProposal(
    val summaryTitle: String,
    val analysisNarrative: String,
    val proposedChanges: List<String>,
    val citedRecordIds: List<String>,
    val missingTermsOrWarnings: List<String>,
    val requiresHumanApproval: Boolean = true
)

/**
 * AI Structuring Assistant powered by Firebase AI Logic (Gemini).
 * Strictly advisory: AI proposals are never self-approved and cite deterministic records.
 */
class AiStructuringRepository {

    private val proposalSchema = Schema.obj(
        properties = mapOf(
            "summaryTitle" to Schema.string(description = "Short institutional headline for the structuring memo"),
            "analysisNarrative" to Schema.string(description = "Detailed institutional analysis citing deterministic figures and record IDs"),
            "proposedChanges" to Schema.array(
                items = Schema.string(),
                description = "Concrete draft configuration recommendations requiring authorised human approval"
            ),
            "citedRecordIds" to Schema.array(
                items = Schema.string(),
                description = "Exact mandate, series, basket, or registry event IDs referenced"
            ),
            "missingTermsOrWarnings" to Schema.array(
                items = Schema.string(),
                description = "Any missing contractual terms, risk disclosures, or reconciliation exceptions"
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = proposalSchema
            }
        )
    }

    suspend fun generateStructuringAnalysis(
        taskPrompt: String,
        deterministicContext: String
    ): Result<AiStructuringProposal> {
        val fullPrompt = """
            You are the institutional structuring assistant inside RHINOBANK — Sovereign Basket & Note Terminal.
            Product label: Rhino Custom SDR (Private contractual note, NOT an IMF SDR or official reserve asset).
            Rules:
            - Cite exact deterministic numbers and record IDs from the context below; do NOT invent numbers.
            - Distinguish Target-Weight vs Fixed-Quantity methodologies clearly.
            - Note that blockchain registry records do not prove unencumbered off-chain Bitcoin backing or issuer solvency.
            - AI NEVER approves its own proposals; all changes require dual human authorisation.

            DETERMINISTIC WORKSPACE CONTEXT:
            $deterministicContext

            STRUCTURING REQUEST:
            $taskPrompt
        """.trimIndent()

        return try {
            val response = withTimeout(60_000L) {
                model.generateContent(fullPrompt)
            }
            val rawJson = response.text ?: return Result.failure(
                IllegalStateException("Gemini returned an empty response.")
            )
            val json = JSONObject(rawJson)
            val changesArr = json.getJSONArray("proposedChanges")
            val citedArr = json.getJSONArray("citedRecordIds")
            val warnArr = json.getJSONArray("missingTermsOrWarnings")

            val proposal = AiStructuringProposal(
                summaryTitle = json.getString("summaryTitle"),
                analysisNarrative = json.getString("analysisNarrative"),
                proposedChanges = (0 until changesArr.length()).map { changesArr.getString(it) },
                citedRecordIds = (0 until citedArr.length()).map { citedArr.getString(it) },
                missingTermsOrWarnings = (0 until warnArr.length()).map { warnArr.getString(it) },
                requiresHumanApproval = true
            )
            Result.success(proposal)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI structuring request timed out", e)
            Result.failure(IllegalStateException("AI request timed out after 60 seconds. Please retry.", e))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI structuring call failed", e)
            Result.failure(e)
        }
    }

    private companion object {
        const val TAG = "AiStructuringRepo"
    }
}
