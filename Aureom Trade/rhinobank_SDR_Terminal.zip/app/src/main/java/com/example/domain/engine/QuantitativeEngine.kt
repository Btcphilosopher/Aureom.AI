package com.example.domain.engine

import com.example.domain.model.AssetCode
import com.example.domain.model.BacktestPoint
import com.example.domain.model.BasketComponent
import com.example.domain.model.BasketDefinition
import com.example.domain.model.BasketMethodology
import com.example.domain.model.BitcoinConfig
import com.example.domain.model.IssuanceLifecycleState
import com.example.domain.model.MandateIncompatibility
import com.example.domain.model.NoteStructure
import com.example.domain.model.NoteType
import com.example.domain.model.PurchaserMandate
import com.example.domain.model.StressScenarioResult
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.security.MessageDigest
import kotlin.random.Random

/**
 * Pure deterministic quantitative & contractual validation engine using exact BigDecimal arithmetic.
 * Never uses floating-point arithmetic for monetary, quantity, weight, or redemption calculations.
 */
object QuantitativeEngine {
    val MC: MathContext = MathContext.DECIMAL128
    private val HUNDRED = BigDecimal("100")
    private val BPS_DIVISOR = BigDecimal("10000")

    /**
     * Converts 1 unit of [asset] into USD reporting currency using explicit FX quotation conventions.
     * - Direct pairs (GBP/USD, EUR/USD, BTC/USD, USD): USD value per 1 unit = spotRate.
     * - Indirect pairs (USD/JPY, USD/CNY): USD value per 1 unit = 1 / spotRate.
     */
    fun usdPricePerUnit(asset: AssetCode, spotRate: BigDecimal): BigDecimal {
        require(spotRate > BigDecimal.ZERO) { "Spot rate for ${asset.ticker} must be positive." }
        return if (asset.fxConvention.isDirectUsdPerUnit) {
            spotRate
        } else {
            BigDecimal.ONE.divide(spotRate, 12, RoundingMode.HALF_EVEN)
        }
    }

    /**
     * Calculates Fixed-Quantity basket value: B_t = sum_i (q_i * P_{i,t}) in USD.
     */
    fun calculateFixedQuantityBasketValue(
        components: List<BasketComponent>,
        useBasePrices: Boolean = false
    ): BigDecimal {
        return components.filter { it.enabled }.fold(BigDecimal.ZERO) { acc, comp ->
            val spot = if (useBasePrices) comp.baseSpotRate else comp.currentSpotRate
            val usdPerUnit = usdPricePerUnit(comp.asset, spot)
            acc.add(comp.fixedQuantity.multiply(usdPerUnit, MC), MC)
        }.setScale(2, RoundingMode.HALF_EVEN)
    }

    /**
     * Calculates Target-Weight basket value relative to base value, accounting for weighted
     * component returns since base date minus explicit rebalancing transaction cost drag.
     */
    fun calculateTargetWeightBasketValue(
        basePrincipalUsd: BigDecimal,
        components: List<BasketComponent>,
        rebalanceCount: Int,
        rebalanceCostBps: Int,
        avgTurnoverFraction: BigDecimal = BigDecimal("0.08")
    ): BigDecimal {
        val enabled = components.filter { it.enabled }
        val totalWeight = enabled.fold(BigDecimal.ZERO) { acc, c -> acc.add(c.targetWeightPct) }
        if (totalWeight.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_EVEN)

        var weightedReturnFactor = BigDecimal.ZERO
        for (comp in enabled) {
            val w = comp.targetWeightPct.divide(totalWeight, MC)
            val baseUsd = usdPricePerUnit(comp.asset, comp.baseSpotRate)
            val currUsd = usdPricePerUnit(comp.asset, comp.currentSpotRate)
            val assetRel = currUsd.divide(baseUsd, MC)
            weightedReturnFactor = weightedReturnFactor.add(w.multiply(assetRel, MC), MC)
        }

        val costRatePerRebal = BigDecimal(rebalanceCostBps)
            .divide(BPS_DIVISOR, MC)
            .multiply(avgTurnoverFraction, MC)
        val cumulativeRebalFactor = BigDecimal.ONE.subtract(
            costRatePerRebal.multiply(BigDecimal(rebalanceCount), MC),
            MC
        ).max(BigDecimal.ZERO)

        return basePrincipalUsd
            .multiply(weightedReturnFactor, MC)
            .multiply(cumulativeRebalFactor, MC)
            .setScale(2, RoundingMode.HALF_EVEN)
    }

    /**
     * Derives initial component quantities on base date from target weights and base principal.
     */
    fun deriveInitialQuantities(
        basePrincipalUsd: BigDecimal,
        components: List<BasketComponent>
    ): List<BasketComponent> {
        return components.map { comp ->
            if (!comp.enabled || comp.targetWeightPct.compareTo(BigDecimal.ZERO) == 0) {
                comp.copy(fixedQuantity = BigDecimal.ZERO.setScale(8, RoundingMode.HALF_EVEN))
            } else {
                val allocatedUsd = basePrincipalUsd.multiply(comp.targetWeightPct, MC).divide(HUNDRED, MC)
                val usdPerUnit = usdPricePerUnit(comp.asset, comp.baseSpotRate)
                val qty = allocatedUsd.divide(usdPerUnit, 8, RoundingMode.HALF_EVEN)
                comp.copy(fixedQuantity = qty)
            }
        }
    }

    /**
     * Normalised Index Level: I_t = I_0 * (B_t / B_0).
     * Never represents cash available for withdrawal.
     */
    fun calculateNormalisedIndex(
        baseIndexLevel: BigDecimal,
        baseBasketValue: BigDecimal,
        currentBasketValue: BigDecimal
    ): BigDecimal {
        if (baseBasketValue.compareTo(BigDecimal.ZERO) == 0) return baseIndexLevel.setScale(4, RoundingMode.HALF_EVEN)
        return baseIndexLevel
            .multiply(currentBasketValue, MC)
            .divide(baseBasketValue, 4, RoundingMode.HALF_EVEN)
    }

    /**
     * Computes exact sum of enabled target weights and validates against 100.00%.
     */
    fun totalEnabledWeightPct(components: List<BasketComponent>): BigDecimal {
        return components.filter { it.enabled }
            .fold(BigDecimal.ZERO) { acc, c -> acc.add(c.targetWeightPct) }
            .setScale(2, RoundingMode.HALF_EVEN)
    }

    fun isWeightSumValid(components: List<BasketComponent>): Boolean {
        return totalEnabledWeightPct(components).compareTo(HUNDRED.setScale(2, RoundingMode.HALF_EVEN)) == 0
    }

    /**
     * Computes actual mark-to-market weights for a Fixed-Quantity basket.
     */
    fun effectiveWeightsUsd(components: List<BasketComponent>): Map<AssetCode, BigDecimal> {
        val total = calculateFixedQuantityBasketValue(components, useBasePrices = false)
        if (total.compareTo(BigDecimal.ZERO) == 0) return emptyMap()
        return components.filter { it.enabled }.associate { comp ->
            val value = comp.fixedQuantity.multiply(usdPricePerUnit(comp.asset, comp.currentSpotRate), MC)
            comp.asset to value.multiply(HUNDRED, MC).divide(total, 2, RoundingMode.HALF_EVEN)
        }
    }

    /**
     * Rebalancing trade delta (in USD) required to move current holdings back to target weights,
     * plus estimated transaction cost in USD.
     */
    fun calculateRebalancingTurnoverAndCost(
        basket: BasketDefinition,
        principalUsd: BigDecimal
    ): Pair<BigDecimal, BigDecimal> {
        if (basket.methodology == BasketMethodology.FIXED_QUANTITY) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_EVEN) to
                BigDecimal.ZERO.setScale(2, RoundingMode.HALF_EVEN)
        }
        val currentBasketVal = calculateFixedQuantityBasketValue(basket.components, useBasePrices = false)
        var oneWayTurnover = BigDecimal.ZERO
        for (comp in basket.components.filter { it.enabled }) {
            val currentVal = comp.fixedQuantity.multiply(usdPricePerUnit(comp.asset, comp.currentSpotRate), MC)
            val targetVal = currentBasketVal.multiply(comp.targetWeightPct, MC).divide(HUNDRED, MC)
            oneWayTurnover = oneWayTurnover.add(currentVal.subtract(targetVal).abs(), MC)
        }
        val twoWayHalf = oneWayTurnover.divide(BigDecimal("2"), 2, RoundingMode.HALF_EVEN)
        val cost = twoWayHalf.multiply(BigDecimal(basket.rebalancingCostBps), MC)
            .divide(BPS_DIVISOR, 2, RoundingMode.HALF_EVEN)
        return twoWayHalf to cost
    }

    /**
     * Separates:
     * 1. Basket Reference Value (B_t)
     * 2. Note Model Value (discounted cash-flow + participation + funding adjustment - fees)
     * 3. Subscription Price (principal * issuePricePct / 100)
     * 4. Redemption Entitlement (contractual formula based on current index & fees)
     */
    data class ValuationBreakdown(
        val basketReferenceValueUsd: BigDecimal,
        val normalisedIndex: BigDecimal,
        val noteModelValueUsd: BigDecimal,
        val subscriptionPriceUsd: BigDecimal,
        val redemptionEntitlementUsd: BigDecimal,
        val accruedFeesUsd: BigDecimal
    )

    fun calculateValuationBreakdown(
        basket: BasketDefinition,
        note: NoteStructure,
        elapsedMonths: Int = 6,
        rebalanceCount: Int = 2,
        issuerFundingSpreadBps: Int = 65
    ): ValuationBreakdown {
        val baseValue = note.principalAmount
        val rawBasketVal = when (basket.methodology) {
            BasketMethodology.FIXED_QUANTITY -> calculateFixedQuantityBasketValue(basket.components, useBasePrices = false)
            BasketMethodology.TARGET_WEIGHT -> calculateTargetWeightBasketValue(
                basePrincipalUsd = baseValue,
                components = basket.components,
                rebalanceCount = rebalanceCount,
                rebalanceCostBps = basket.rebalancingCostBps
            )
        }
        val baseCalcValue = calculateFixedQuantityBasketValue(basket.components, useBasePrices = true)
            .let { if (it.compareTo(BigDecimal.ZERO) == 0) baseValue else it }

        val index = calculateNormalisedIndex(basket.baseIndexLevel, baseCalcValue, rawBasketVal)
        val indexRatio = index.divide(basket.baseIndexLevel, MC)

        val totalOngoingBps = note.ongoingFeeBps + basket.managementFeeBps
        val yearFraction = BigDecimal(elapsedMonths).divide(BigDecimal("12"), MC)
        val accruedFees = note.principalAmount
            .multiply(BigDecimal(totalOngoingBps), MC)
            .divide(BPS_DIVISOR, MC)
            .multiply(yearFraction, MC)
            .setScale(2, RoundingMode.HALF_EVEN)

        val participationFactor = note.participationRatePct.divide(HUNDRED, MC)
        val performanceDelta = indexRatio.subtract(BigDecimal.ONE, MC)
        val participatedReturn = BigDecimal.ONE.add(performanceDelta.multiply(participationFactor, MC), MC)

        val rawRedemption = when (note.noteType) {
            NoteType.BASKET_LINKED_PRINCIPAL -> note.principalAmount.multiply(indexRatio, MC).subtract(accruedFees, MC)
            NoteType.FIXED_COUPON_BASKET -> note.principalAmount.multiply(indexRatio, MC).subtract(accruedFees, MC)
            NoteType.PARTICIPATION -> note.principalAmount.multiply(participatedReturn, MC).subtract(accruedFees, MC)
            NoteType.PROTECTED_STRUCTURE -> {
                val floorPct = (note.capitalProtectionFloorPct ?: HUNDRED).divide(HUNDRED, MC)
                val floorAmt = note.principalAmount.multiply(floorPct, MC)
                note.principalAmount.multiply(participatedReturn, MC).subtract(accruedFees, MC).max(floorAmt)
            }
        }.max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_EVEN)

        // Note model value incorporates issuer funding/credit spread discount over remaining maturity
        val remainingYears = BigDecimal((note.maturityMonths - elapsedMonths).coerceAtLeast(0))
            .divide(BigDecimal("12"), MC)
        val creditDiscount = BigDecimal.ONE.subtract(
            BigDecimal(issuerFundingSpreadBps).divide(BPS_DIVISOR, MC).multiply(remainingYears, MC),
            MC
        ).max(BigDecimal("0.70"))
        val modelValue = rawRedemption.multiply(creditDiscount, MC).setScale(2, RoundingMode.HALF_EVEN)

        val subscriptionPrice = note.principalAmount
            .multiply(note.issuePricePct, MC)
            .divide(HUNDRED, 2, RoundingMode.HALF_EVEN)

        return ValuationBreakdown(
            basketReferenceValueUsd = rawBasketVal,
            normalisedIndex = index,
            noteModelValueUsd = modelValue,
            subscriptionPriceUsd = subscriptionPrice,
            redemptionEntitlementUsd = rawRedemption,
            accruedFeesUsd = accruedFees
        )
    }

    /**
     * Evaluates purchaser mandate against proposed basket & note configuration.
     * Identifies incompatibilities explicitly — NEVER silently rewrites the purchaser's instructions.
     */
    fun validateMandateCompatibility(
        mandate: PurchaserMandate,
        basket: BasketDefinition,
        note: NoteStructure,
        bitcoinConfig: BitcoinConfig
    ): List<MandateIncompatibility> {
        val issues = mutableListOf<MandateIncompatibility>()

        val enabledComponents = basket.components.filter { it.enabled }
        val totalWeight = totalEnabledWeightPct(basket.components)
        if (totalWeight.compareTo(HUNDRED.setScale(2, RoundingMode.HALF_EVEN)) != 0) {
            issues += MandateIncompatibility(
                code = "WEIGHT_SUM_MISMATCH",
                severity = "BLOCK",
                message = "Basket weights sum to ${totalWeight.toPlainString()}%; contract requires exactly 100.00%."
            )
        }

        // Permitted asset check
        for (comp in enabledComponents) {
            if (comp.asset !in mandate.permittedAssets) {
                issues += MandateIncompatibility(
                    code = "UNPERMITTED_ASSET_${comp.asset.ticker}",
                    severity = "BLOCK",
                    message = "${comp.asset.displayName} (${comp.asset.ticker}) is excluded by mandate ${mandate.mandateCode}."
                )
            }
            if (comp.targetWeightPct > mandate.maxSingleAssetConcentrationPct) {
                issues += MandateIncompatibility(
                    code = "CONCENTRATION_BREACH_${comp.asset.ticker}",
                    severity = "BLOCK",
                    message = "${comp.asset.ticker} weight (${comp.targetWeightPct.toPlainString()}%) exceeds purchaser concentration cap (${mandate.maxSingleAssetConcentrationPct.toPlainString()}%)."
                )
            }
            if (comp.isStalePrice) {
                issues += MandateIncompatibility(
                    code = "STALE_PRICE_${comp.asset.ticker}",
                    severity = "BLOCK",
                    message = "${comp.asset.ticker} price feed flagged stale; fallback valuation rule required before pricing or issuance."
                )
            }
        }

        val btcComp = enabledComponents.firstOrNull { it.asset == AssetCode.BTC }
        if (btcComp != null) {
            if (btcComp.targetWeightPct > mandate.maxBitcoinAllocationPct) {
                issues += MandateIncompatibility(
                    code = "BTC_LIMIT_EXCEEDED",
                    severity = "BLOCK",
                    message = "Bitcoin allocation (${btcComp.targetWeightPct.toPlainString()}%) exceeds purchaser mandate limit (${mandate.maxBitcoinAllocationPct.toPlainString()}%)."
                )
            }
            if (!bitcoinConfig.enabled) {
                issues += MandateIncompatibility(
                    code = "BTC_CONFIG_DISABLED",
                    severity = "BLOCK",
                    message = "Bitcoin is weighted in the basket while Bitcoin custody/observation configuration is disabled."
                )
            }
        }

        if (basket.methodology != mandate.preferredMethodology) {
            issues += MandateIncompatibility(
                code = "METHODOLOGY_MISMATCH",
                severity = "WARN",
                message = "Basket methodology (${basket.methodology.title}) differs from mandate preference (${mandate.preferredMethodology.title}). Purchaser consent required."
            )
        }

        if (note.maturityMonths > mandate.investmentHorizonMonths) {
            issues += MandateIncompatibility(
                code = "HORIZON_EXCEEDED",
                severity = "BLOCK",
                message = "Note term (${note.maturityMonths}m) exceeds mandate investment horizon (${mandate.investmentHorizonMonths}m)."
            )
        }

        if (note.principalAmount.compareTo(mandate.subscriptionAmount) != 0) {
            issues += MandateIncompatibility(
                code = "PRINCIPAL_SUBSCRIPTION_DELTA",
                severity = "WARN",
                message = "Note principal (${note.principalAmount.toPlainString()}) differs from mandate subscription (${mandate.subscriptionAmount.toPlainString()})."
            )
        }

        if (!mandate.purchaserAccepted) {
            issues += MandateIncompatibility(
                code = "PURCHASER_ACCEPTANCE_PENDING",
                severity = "WARN",
                message = "Purchaser has not yet countersigned mandate v${mandate.version}."
            )
        }

        return issues
    }

    /**
     * Reproducible stress scenario runner (fixed seed, recorded calibration window & limitations).
     */
    fun runReproducibleStressScenarios(
        basket: BasketDefinition,
        note: NoteStructure,
        seed: Long = 20270115L
    ): List<StressScenarioResult> {
        val baseValuation = calculateValuationBreakdown(basket, note, elapsedMonths = 0, rebalanceCount = 0)
        val baseVal = baseValuation.basketReferenceValueUsd.max(BigDecimal.ONE)
        val rng = Random(seed)

        data class ShockSpec(
            val id: String,
            val label: String,
            val desc: String,
            val assetShocks: Map<AssetCode, BigDecimal>,
            val extraLiquidityHaircutBps: Int,
            val fundingSpreadBps: Int
        )

        val specs = listOf(
            ShockSpec(
                "btc_down_50",
                "BTC -50%; FX unchanged",
                "Spot Bitcoin drawdown of -50% at 16:00 UTC observation; G10/CNY FX held flat.",
                mapOf(AssetCode.BTC to BigDecimal("0.50")),
                extraLiquidityHaircutBps = 0,
                fundingSpreadBps = 65
            ),
            ShockSpec(
                "btc_up_50",
                "BTC +50%; FX unchanged",
                "Spot Bitcoin rally of +50%; verifies upside linearity and concentration drift.",
                mapOf(AssetCode.BTC to BigDecimal("1.50")),
                extraLiquidityHaircutBps = 0,
                fundingSpreadBps = 65
            ),
            ShockSpec(
                "usd_fx_stress",
                "USD valuation FX stress",
                "Broad USD appreciation: GBP -8%, EUR -7%, JPY -10%, CNY -5%, BTC -12%.",
                mapOf(
                    AssetCode.GBP to BigDecimal("0.92"),
                    AssetCode.EUR to BigDecimal("0.93"),
                    AssetCode.JPY to BigDecimal("0.90"),
                    AssetCode.CNY to BigDecimal("0.95"),
                    AssetCode.BTC to BigDecimal("0.88")
                ),
                extraLiquidityHaircutBps = 25,
                fundingSpreadBps = 95
            ),
            ShockSpec(
                "weekend_btc_gap",
                "Weekend BTC gap + custodian halt",
                "Saturday/Sunday BTC -28% gap + 48h qualified-custodian settlement freeze (120 bps liquidity haircut).",
                mapOf(AssetCode.BTC to BigDecimal("0.72")),
                extraLiquidityHaircutBps = 120,
                fundingSpreadBps = 140
            ),
            ShockSpec(
                "corr_funding_stress",
                "Correlation spike & issuer stress",
                "Cross-asset correlation -> 0.85, risk-off FX drop (-6%), issuer credit spread widens to 260 bps.",
                mapOf(
                    AssetCode.GBP to BigDecimal("0.94"),
                    AssetCode.EUR to BigDecimal("0.94"),
                    AssetCode.JPY to BigDecimal("0.96"),
                    AssetCode.CNY to BigDecimal("0.95"),
                    AssetCode.BTC to BigDecimal("0.68")
                ),
                extraLiquidityHaircutBps = 150,
                fundingSpreadBps = 260
            ),
            ShockSpec(
                "early_redemption_run",
                "Delayed liquidation & early exit",
                "Unscheduled redemption demand requiring T+5 liquidation; 85 bps market impact + Monte Carlo noise.",
                mapOf(
                    AssetCode.GBP to BigDecimal("0.97"),
                    AssetCode.EUR to BigDecimal("0.97"),
                    AssetCode.BTC to BigDecimal(0.90 - (rng.nextInt(5) * 0.01))
                ),
                extraLiquidityHaircutBps = 85,
                fundingSpreadBps = 115
            )
        )

        return specs.map { spec ->
            val shockedComponents = basket.components.map { comp ->
                val shockMult = spec.assetShocks[comp.asset] ?: BigDecimal.ONE
                val newSpot = if (comp.asset.fxConvention.isDirectUsdPerUnit) {
                    comp.baseSpotRate.multiply(shockMult, MC)
                } else {
                    // For indirect USD/JPY, USD/CNY: a -10% currency depreciation against USD means USD/JPY rises by 1/0.90
                    comp.baseSpotRate.divide(shockMult, 8, RoundingMode.HALF_EVEN)
                }
                comp.copy(currentSpotRate = newSpot)
            }
            val shockedBasket = basket.copy(components = shockedComponents)
            val shockedValuation = calculateValuationBreakdown(
                basket = shockedBasket,
                note = note,
                elapsedMonths = 6,
                rebalanceCount = 2,
                issuerFundingSpreadBps = spec.fundingSpreadBps
            )

            val haircutFactor = BigDecimal.ONE.subtract(
                BigDecimal(spec.extraLiquidityHaircutBps).divide(BPS_DIVISOR, MC),
                MC
            )
            val netEntitlement = shockedValuation.redemptionEntitlementUsd
                .multiply(haircutFactor, MC)
                .setScale(2, RoundingMode.HALF_EVEN)

            val impactPct = shockedValuation.basketReferenceValueUsd
                .subtract(baseVal, MC)
                .multiply(HUNDRED, MC)
                .divide(baseVal, 2, RoundingMode.HALF_EVEN)

            StressScenarioResult(
                id = spec.id,
                label = spec.label,
                shockDescription = spec.desc,
                basketImpactPct = impactPct,
                noteModelValueUsd = shockedValuation.noteModelValueUsd,
                redemptionEntitlementUsd = netEntitlement,
                seed = seed,
                calibrationWindow = "2021-01-01 to 2026-10-31 (Synthetic Institutional Multi-Asset Panel)",
                distributionModel = "Deterministic factor shock + Student-t (df=5) tail liquidity overlay",
                limitations = "Scenarios are NOT forecasts. Historical correlations break down under sovereign or custodian freezes; single VaR omitted intentionally."
            )
        }
    }

    /**
     * Generates deterministic hypothetical historical backtest (no future-data leakage;
     * uses lagged t-1 weights for t returns and strictly labels series as hypothetical).
     */
    fun generateHypotheticalBacktest(
        basket: BasketDefinition,
        seed: Long = 20261115L
    ): List<BacktestPoint> {
        val rng = Random(seed)
        val months = listOf("Q1'25", "Q2'25", "Q3'25", "Q4'25", "Q1'26", "Q2'26", "Q3'26", "Q4'26")
        val btcWeight = basket.components.firstOrNull { it.asset == AssetCode.BTC && it.enabled }?.targetWeightPct
            ?.divide(HUNDRED, MC) ?: BigDecimal.ZERO
        val nonUsdWeight = basket.components.filter { it.enabled && it.asset != AssetCode.USD && it.asset != AssetCode.BTC }
            .fold(BigDecimal.ZERO) { acc, c -> acc.add(c.targetWeightPct) }
            .divide(HUNDRED, MC)

        var targetIdx = BigDecimal("100.00")
        var fixedIdx = BigDecimal("100.00")
        var usdIdx = BigDecimal("100.00")

        val points = mutableListOf<BacktestPoint>()
        // Synthetic historical quarterly path using causal t-1 weights only
        val btcMoves = listOf(0.00, 0.14, -0.09, 0.22, -0.18, 0.08, 0.12, -0.04)
        val fxMoves = listOf(0.00, 0.018, -0.012, 0.024, -0.015, 0.009, 0.011, -0.006)
        val usdCarry = listOf(0.00, 0.011, 0.011, 0.010, 0.010, 0.009, 0.009, 0.009)

        for (i in months.indices) {
            if (i > 0) {
                val noise = (rng.nextInt(-3, 4)) * 0.001
                val fxRet = BigDecimal(fxMoves[i] + noise)
                val btcRet = BigDecimal(btcMoves[i])
                val carryRet = BigDecimal(usdCarry[i])
                val rebalCost = BigDecimal(basket.rebalancingCostBps).divide(BPS_DIVISOR, MC)
                    .multiply(BigDecimal("0.08"), MC)

                val periodRetTarget = carryRet
                    .add(nonUsdWeight.multiply(fxRet, MC), MC)
                    .add(btcWeight.multiply(btcRet, MC), MC)
                    .subtract(rebalCost, MC)
                val periodRetFixed = carryRet
                    .add(nonUsdWeight.multiply(fxRet, MC), MC)
                    .add(btcWeight.multiply(btcRet.multiply(BigDecimal("1.04"), MC), MC), MC)

                targetIdx = targetIdx.multiply(BigDecimal.ONE.add(periodRetTarget, MC), MC).setScale(2, RoundingMode.HALF_EVEN)
                fixedIdx = fixedIdx.multiply(BigDecimal.ONE.add(periodRetFixed, MC), MC).setScale(2, RoundingMode.HALF_EVEN)
                usdIdx = usdIdx.multiply(BigDecimal.ONE.add(carryRet, MC), MC).setScale(2, RoundingMode.HALF_EVEN)
            }
            points += BacktestPoint(
                dateLabel = months[i],
                targetWeightIndex = targetIdx,
                fixedQtyIndex = fixedIdx,
                benchmarkUsdOnly = usdIdx
            )
        }
        return points
    }

    /**
     * Exact coupon formula evaluation from versioned terms.
     */
    fun calculatePeriodicCouponUsd(
        remainingPrincipalUsd: BigDecimal,
        annualCouponBps: Int,
        basketIndexRatio: BigDecimal,
        noteType: NoteType,
        periodsPerYear: Int = 2
    ): BigDecimal {
        if (annualCouponBps <= 0) return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_EVEN)
        val baseRate = BigDecimal(annualCouponBps)
            .divide(BPS_DIVISOR, MC)
            .divide(BigDecimal(periodsPerYear), MC)
        val effectivePrincipal = if (noteType == NoteType.FIXED_COUPON_BASKET) {
            remainingPrincipalUsd.multiply(basketIndexRatio, MC)
        } else {
            remainingPrincipalUsd
        }
        return effectivePrincipal.multiply(baseRate, MC).setScale(2, RoundingMode.HALF_EVEN)
    }

    /**
     * Computes deterministic SHA-256 commitment digest for off-chain legal documents & terms.
     */
    fun sha256Hex(payload: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Validates permitted issuance lifecycle transitions.
     */
    fun canAdvanceLifecycle(current: IssuanceLifecycleState, target: IssuanceLifecycleState): Boolean {
        if (current == IssuanceLifecycleState.REDEEMED || current == IssuanceLifecycleState.CANCELLED) return false
        if (target.isException) return true
        return target.stepOrder == current.stepOrder + 1
    }
}
