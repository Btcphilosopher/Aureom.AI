package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.FundingModel
import com.example.domain.model.RegistryEventStatus
import com.example.domain.model.ServicingStatus
import com.example.ui.components.KeyValueMetricRow
import com.example.ui.components.RegulatoryNoticeBanner
import com.example.ui.components.ScenarioHorizontalBar
import com.example.ui.components.StatusBadge
import com.example.ui.components.TerminalPanel
import com.example.ui.components.formatUsd
import com.example.ui.theme.AmberException
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyanSelected
import com.example.ui.theme.CyanSurface
import com.example.ui.theme.ElevatedSlatePanel
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.IvoryHeading
import com.example.ui.theme.MonoFinancialSmall
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.PlatinumDivider
import com.example.ui.theme.PlatinumText
import com.example.ui.theme.SlateMuted
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun RegistrySection(state: TerminalUiState) {
    val net = state.poSNetwork
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Registered-Note PoS Ledger & Confidential Boundaries",
            badgeText = "HEIGHT #${net.finalisedHeight}",
            badgeColor = CyanSelected
        ) {
            KeyValueMetricRow("PoS Network", net.networkName, IvoryHeading, monoValue = false)
            KeyValueMetricRow("Validator Count", "${net.validatorCount} nodes (Common RhinoBank Admin)", AmberException, monoValue = false)
            KeyValueMetricRow("Indexer Lag", "${net.indexerLagMs} ms (Pending vs Finalised separated)", EmeraldVerified)
            KeyValueMetricRow("Transfer Policy", "Permissionless transfer DISABLED (Registrar-gated)", ChampagneGold, monoValue = false)
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(text = net.validatorGovernanceDisclosure, isWarning = true)
            Spacer(modifier = Modifier.height(6.dp))
            RegulatoryNoticeBanner(text = net.validatorStakeSeparationNotice)
            Spacer(modifier = Modifier.height(6.dp))
            RegulatoryNoticeBanner(text = net.authoritativeRegisterRule)
            Spacer(modifier = Modifier.height(6.dp))
            RegulatoryNoticeBanner(text = net.privacyWarning, isWarning = true)
            Spacer(modifier = Modifier.height(6.dp))
            Text("Recovery & Court Order Protocol: ${net.recoveryProcedure}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
        }

        TerminalPanel(title = "On-Chain Registry Commitments (Pseudonymous Refs Only)") {
            state.registryEvents.forEach { ev ->
                Surface(
                    color = ElevatedSlatePanel,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${ev.eventId} • ${ev.eventType}", style = MonoFinancialSmall.copy(fontWeight = FontWeight.Bold), color = IvoryHeading)
                            StatusBadge(
                                text = ev.status.label,
                                color = when (ev.status) {
                                    RegistryEventStatus.FINALISED -> EmeraldVerified
                                    RegistryEventStatus.PENDING_CONSENSUS -> AmberException
                                    RegistryEventStatus.FAILED -> CrimsonAlert
                                    RegistryEventStatus.RECOVERED -> CyanSelected
                                }
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Tx: ${ev.txHash}  |  Block: #${ev.blockHeight}  |  HolderRef: ${ev.pseudonymousHolderRef}", style = MonoFinancialSmall, color = CyanSelected)
                        Text("Doc Hash: ${ev.documentCommitmentSha256}  |  ${ev.timestampUtc}", style = MonoFinancialSmall, color = SlateMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(ev.noteDetail, style = MaterialTheme.typography.bodySmall, color = PlatinumText)
                    }
                }
            }
        }
    }
}

@Composable
fun TreasurySection(
    state: TerminalUiState,
    onSelectFundingModel: (FundingModel) -> Unit
) {
    val t = state.treasuryPosition
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Treasury, Funding & Collateral Allocation",
            badgeText = state.noteStructure.fundingModel.label.uppercase(),
            badgeColor = ChampagneGold
        ) {
            Text("Select Issuance Funding Model (Economically & Legally Distinct):", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
            Spacer(modifier = Modifier.height(6.dp))
            FundingModel.entries.forEach { fm ->
                val active = state.noteStructure.fundingModel == fm
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (active) CyanSurface else ObsidianVoid)
                        .border(1.dp, if (active) CyanSelected else PlatinumDivider, RoundedCornerShape(6.dp))
                        .clickable { onSelectFundingModel(fm) }
                        .padding(10.dp)
                ) {
                    Column {
                        Text(fm.label, style = MaterialTheme.typography.titleMedium, color = if (active) CyanSelected else IvoryHeading)
                        Text(fm.legalSummary, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            KeyValueMetricRow("Subscription Proceeds", formatUsd(t.subscriptionProceedsUsd), CyanSelected)
            KeyValueMetricRow("Acquired Replication Assets", formatUsd(t.acquiredAssetsUsd), IvoryHeading)
            KeyValueMetricRow("Hedge Notional", formatUsd(t.hedgeNotionalUsd), IvoryHeading)
            KeyValueMetricRow("Issuer Funding Spread", "${t.annualFundingCostBps} bps p.a.", AmberException)
            KeyValueMetricRow("Collateral Pool / Encumbered", "${formatUsd(t.collateralPoolValueUsd)} / ${formatUsd(t.encumberedCollateralUsd)}", ChampagneGold)
            KeyValueMetricRow("Liquidity Reserve Buffer", formatUsd(t.liquidBufferUsd), EmeraldVerified)
            KeyValueMetricRow("Currency Mismatch", formatUsd(t.fxMismatchUsd), if (t.fxMismatchUsd > java.math.BigDecimal.ZERO) AmberException else EmeraldVerified)
            KeyValueMetricRow("Maturity Mismatch", "${t.maturityMismatchMonths} months", PlatinumText)
            KeyValueMetricRow("Double-Allocation Guard", if (t.doubleAllocationCheckPassed) "PASSED (Unique Ring-Fence)" else "BREACH", EmeraldVerified)
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(text = t.replicationRiskDisclosure, isWarning = true)
        }
    }
}

@Composable
fun RiskSection(state: TerminalUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Reproducible Stress Testing & Scenario Matrix",
            badgeText = "SEED 20270115",
            badgeColor = AmberException
        ) {
            state.stressScenarios.forEach { sc ->
                Surface(
                    color = ElevatedSlatePanel,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        ScenarioHorizontalBar(scenario = sc)
                        Text(sc.shockDescription, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        KeyValueMetricRow("Model Value / Redemption", "${formatUsd(sc.noteModelValueUsd)} / ${formatUsd(sc.redemptionEntitlementUsd)}", CyanSelected)
                        Text("Calibration: ${sc.calibrationWindow} | Model: ${sc.distributionModel}", style = MonoFinancialSmall, color = SlateMuted)
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            RegulatoryNoticeBanner(text = state.stressScenarios.first().limitations, isWarning = true)
        }

        TerminalPanel(
            title = "Hypothetical Historical Backtest (No Future-Data Leakage)",
            badgeText = "HYPOTHETICAL ONLY",
            badgeColor = AmberException
        ) {
            Text(
                text = "Uses lagged t-1 weights only. Hypothetical backtests are NOT indicative of future performance or actual cash availability.",
                style = MaterialTheme.typography.bodySmall,
                color = AmberException
            )
            Spacer(modifier = Modifier.height(10.dp))
            BacktestLineChart(state = state)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Cyan: Target-Weight", style = MonoFinancialSmall, color = CyanSelected)
                Text("Gold: Fixed-Qty", style = MonoFinancialSmall, color = ChampagneGold)
                Text("Slate: USD Benchmark", style = MonoFinancialSmall, color = SlateMuted)
            }
        }
    }
}

@Composable
private fun BacktestLineChart(state: TerminalUiState) {
    val pts = state.backtestPoints
    if (pts.isEmpty()) return

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .background(ObsidianVoid, RoundedCornerShape(6.dp))
            .border(1.dp, PlatinumDivider, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        val values = pts.flatMap { listOf(it.targetWeightIndex.toFloat(), it.fixedQtyIndex.toFloat(), it.benchmarkUsdOnly.toFloat()) }
        val minVal = (values.minOrNull() ?: 90f) - 1f
        val maxVal = (values.maxOrNull() ?: 110f) + 1f
        val span = (maxVal - minVal).coerceAtLeast(1f)
        val stepX = size.width / (pts.size - 1).coerceAtLeast(1)

        fun buildPath(selector: (Int) -> Float): Path {
            val path = Path()
            pts.indices.forEach { i ->
                val x = i * stepX
                val y = size.height - ((selector(i) - minVal) / span) * size.height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            return path
        }

        drawLine(PlatinumDivider.copy(alpha = 0.4f), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1f)
        drawPath(buildPath { pts[it].benchmarkUsdOnly.toFloat() }, SlateMuted, style = Stroke(width = 3f))
        drawPath(buildPath { pts[it].fixedQtyIndex.toFloat() }, ChampagneGold, style = Stroke(width = 4f))
        drawPath(buildPath { pts[it].targetWeightIndex.toFloat() }, CyanSelected, style = Stroke(width = 4f))
    }
}

@Composable
fun ServicingSection(
    state: TerminalUiState,
    onAdvanceServicing: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Coupon, Partial Redemption & Servicing Workflow",
            badgeText = "${state.servicingSchedule.size} EVENTS",
            badgeColor = CyanSelected
        ) {
            RegulatoryNoticeBanner(
                text = "Workflow: Scheduled -> Calculated -> Reviewed -> Approved -> Instructed -> Confirmed -> Reconciled. Registry cancellation NEVER counts as repayment."
            )
            Spacer(modifier = Modifier.height(8.dp))
            state.servicingSchedule.forEach { item ->
                Surface(
                    color = ElevatedSlatePanel,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.periodLabel, style = MaterialTheme.typography.titleMedium, color = IvoryHeading)
                            StatusBadge(
                                text = item.status.label,
                                color = if (item.status == ServicingStatus.RECONCILED) EmeraldVerified else ChampagneGold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        KeyValueMetricRow("Type / Due", "${item.eventKind} • ${item.dueDate}", PlatinumText, monoValue = false)
                        KeyValueMetricRow("Fixing Index / Payment", "${item.basketIndexAtFixing} / ${formatUsd(item.calculatedAmountUsd)}", CyanSelected)
                        KeyValueMetricRow("Remaining Principal", formatUsd(item.remainingPrincipalUsd), IvoryHeading)
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = { onAdvanceServicing(item.id) },
                            enabled = item.status != ServicingStatus.RECONCILED,
                            modifier = Modifier.fillMaxWidth().height(44.dp).testTag("advance_servicing_${item.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianVoid)
                        ) {
                            Text(
                                text = if (item.status == ServicingStatus.RECONCILED) "Reconciled & Settled" else "Advance Servicing State ->",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettlementSection(state: TerminalUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(title = "Settlement & Custody Rail Reconciliation") {
            state.basket.components.filter { it.enabled }.forEach { comp ->
                Surface(
                    color = ElevatedSlatePanel,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("${comp.asset.displayName} (${comp.asset.ticker})", style = MaterialTheme.typography.titleMedium, color = IvoryHeading)
                        KeyValueMetricRow("Settlement Adapter", comp.asset.settlementAdapter, CyanSelected, monoValue = false)
                        KeyValueMetricRow("Custody Adapter", comp.asset.custodyAdapter, PlatinumText, monoValue = false)
                        KeyValueMetricRow("Fallback Rule", comp.asset.fallbackRule, SlateMuted, monoValue = false)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            RegulatoryNoticeBanner(
                text = "Bitcoin Custody Evidence: ${state.bitcoinConfig.custodyEvidenceRef} • ${state.bitcoinConfig.encumbranceStatus}. ${state.bitcoinConfig.verificationLimitNotice}",
                isWarning = true
            )
        }
    }
}

@Composable
fun AuditSection(state: TerminalUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TerminalPanel(
            title = "Protected Append-Only Audit History",
            badgeText = "${state.auditLog.size} RECORDS",
            badgeColor = EmeraldVerified
        ) {
            state.auditLog.forEach { log ->
                Surface(
                    color = ElevatedSlatePanel,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, PlatinumDivider),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${log.id} • ${log.category}:${log.action}", style = MonoFinancialSmall.copy(fontWeight = FontWeight.Bold), color = ChampagneGold)
                            Text(log.timestampUtc, style = MonoFinancialSmall, color = SlateMuted)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(log.detail, style = MaterialTheme.typography.bodySmall, color = IvoryHeading)
                        Text("Actor: ${log.actor} | Key: ${log.idempotencyKey} | ${log.commitmentHash}", style = MonoFinancialSmall, color = CyanSelected)
                    }
                }
            }
        }
    }
}
