package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AuditEventDoc
import com.example.data.model.MandateVersionDoc
import com.example.data.model.SavedWorkspaceDoc
import com.example.data.repository.AiStructuringProposal
import com.example.data.repository.AiStructuringRepository
import com.example.data.repository.RhinoFirestoreRepository
import com.example.domain.engine.QuantitativeEngine
import com.example.domain.model.AssetCode
import com.example.domain.model.AuditLogItem
import com.example.domain.model.BacktestPoint
import com.example.domain.model.BasketComponent
import com.example.domain.model.BasketDefinition
import com.example.domain.model.BasketMethodology
import com.example.domain.model.BitcoinConfig
import com.example.domain.model.BitcoinExposureType
import com.example.domain.model.CashFlowRow
import com.example.domain.model.DemoStep
import com.example.domain.model.DensityMode
import com.example.domain.model.FundingModel
import com.example.domain.model.IssuanceChecklist
import com.example.domain.model.IssuanceLifecycleState
import com.example.domain.model.MandateIncompatibility
import com.example.domain.model.NoteStructure
import com.example.domain.model.NoteType
import com.example.domain.model.PoSNetworkState
import com.example.domain.model.PurchaserMandate
import com.example.domain.model.RegistryEvent
import com.example.domain.model.RegistryEventStatus
import com.example.domain.model.ServicingEvent
import com.example.domain.model.ServicingStatus
import com.example.domain.model.StressScenarioResult
import com.example.domain.model.TerminalSection
import com.example.domain.model.TradingListing
import com.example.domain.model.TreasuryPosition
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

enum class BottomLedgerTab(val label: String) {
    CASH_FLOWS("Cash flows"),
    FUNDING("Funding"),
    REGISTRY_EVENTS("Registry events"),
    AUDIT("Audit")
}

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Success(val proposal: AiStructuringProposal) : AiUiState
    data class Error(val message: String) : AiUiState
}

data class TerminalUiState(
    val currentUserId: String = "",
    val operatorEmail: String = "operator@rhinobank.demo",
    val activeSection: TerminalSection = TerminalSection.BASKET_STUDIO,
    val bottomTab: BottomLedgerTab = BottomLedgerTab.CASH_FLOWS,
    val densityMode: DensityMode = DensityMode.STANDARD,
    val searchQuery: String = "",
    val valuationTimestampUtc: String = "2026-11-15 09:42 UTC",
    val mandate: PurchaserMandate,
    val basket: BasketDefinition,
    val bitcoinConfig: BitcoinConfig = BitcoinConfig(),
    val selectedComponent: AssetCode = AssetCode.BTC,
    val noteStructure: NoteStructure,
    val lifecycleState: IssuanceLifecycleState = IssuanceLifecycleState.TERMS_APPROVED,
    val checklist: IssuanceChecklist,
    val poSNetwork: PoSNetworkState = PoSNetworkState(),
    val registryEvents: List<RegistryEvent>,
    val treasuryPosition: TreasuryPosition,
    val servicingSchedule: List<ServicingEvent>,
    val tradingListings: List<TradingListing>,
    val stressScenarios: List<StressScenarioResult>,
    val backtestPoints: List<BacktestPoint>,
    val incompatibilities: List<MandateIncompatibility>,
    val valuation: QuantitativeEngine.ValuationBreakdown,
    val cashFlows: List<CashFlowRow>,
    val auditLog: List<AuditLogItem>,
    val savedWorkspaces: List<SavedWorkspaceDoc> = emptyList(),
    val mandateVersionHistory: List<MandateVersionDoc> = emptyList(),
    val demoSteps: List<DemoStep>,
    val activeDemoStep: Int = 5,
    val aiUiState: AiUiState = AiUiState.Idle,
    val showAiSheet: Boolean = false,
    val showComparisonSheet: Boolean = false,
    val statusBanner: String? = null,
    val firestoreSyncStatus: String = "Connected",
    val usedIdempotencyKeys: Set<String> = emptySet()
)

class TerminalViewModel(
    private val firestoreRepo: RhinoFirestoreRepository,
    private val aiRepo: AiStructuringRepository,
    private val currentUserId: String,
    private val operatorEmail: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(createInitialPennineState(currentUserId, operatorEmail))
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    init {
        observeCloudData()
    }

    private fun observeCloudData() {
        viewModelScope.launch {
            firestoreRepo.observeWorkspaces(currentUserId)
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    _uiState.update { it.copy(firestoreSyncStatus = "Sync warning: ${fsErr?.code ?: "offline"}") }
                }
                .collect { docs ->
                    _uiState.update { it.copy(savedWorkspaces = docs, firestoreSyncStatus = "Cloud synced") }
                }
        }
        viewModelScope.launch {
            firestoreRepo.observeMandateVersions(currentUserId)
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                }
                .collect { versions ->
                    _uiState.update { it.copy(mandateVersionHistory = versions) }
                }
        }
    }

    fun selectSection(section: TerminalSection) {
        _uiState.update { it.copy(activeSection = section, statusBanner = null) }
    }

    fun selectBottomTab(tab: BottomLedgerTab) {
        _uiState.update { it.copy(bottomTab = tab) }
    }

    fun setDensityMode(mode: DensityMode) {
        _uiState.update { it.copy(densityMode = mode) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectComponent(asset: AssetCode) {
        _uiState.update { it.copy(selectedComponent = asset) }
    }

    fun toggleAiSheet(open: Boolean) {
        _uiState.update { it.copy(showAiSheet = open) }
    }

    fun toggleComparisonSheet(open: Boolean) {
        _uiState.update { it.copy(showComparisonSheet = open) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun updateComponentWeight(asset: AssetCode, newWeightPct: BigDecimal) {
        _uiState.update { state ->
            val clamped = newWeightPct.max(BigDecimal.ZERO).min(BigDecimal("100.00"))
                .setScale(2, RoundingMode.HALF_EVEN)
            val updatedComponents = state.basket.components.map { comp ->
                if (comp.asset == asset) {
                    comp.copy(
                        targetWeightPct = clamped,
                        enabled = clamped > BigDecimal.ZERO
                    )
                } else comp
            }
            val derived = QuantitativeEngine.deriveInitialQuantities(
                state.noteStructure.principalAmount,
                updatedComponents
            )
            val updatedBasket = state.basket.copy(components = derived)
            recalculateAll(state.copy(basket = updatedBasket))
        }
    }

    fun toggleComponentEnabled(asset: AssetCode) {
        _uiState.update { state ->
            val updatedComponents = state.basket.components.map { comp ->
                if (comp.asset == asset) {
                    val nextEnabled = !comp.enabled
                    comp.copy(
                        enabled = nextEnabled,
                        targetWeightPct = if (!nextEnabled) BigDecimal.ZERO.setScale(2) else comp.targetWeightPct
                    )
                } else comp
            }
            val derived = QuantitativeEngine.deriveInitialQuantities(
                state.noteStructure.principalAmount,
                updatedComponents
            )
            val updatedBtcConfig = if (asset == AssetCode.BTC) {
                val btcEnabled = derived.first { it.asset == AssetCode.BTC }.enabled
                state.bitcoinConfig.copy(enabled = btcEnabled)
            } else state.bitcoinConfig

            recalculateAll(
                state.copy(
                    basket = state.basket.copy(components = derived),
                    bitcoinConfig = updatedBtcConfig
                )
            )
        }
    }

    fun setMethodology(methodology: BasketMethodology) {
        _uiState.update { state ->
            val updatedBasket = state.basket.copy(methodology = methodology)
            val updatedListings = state.tradingListings.map {
                it.copy(basketMethodology = methodology.title)
            }
            val next = recalculateAll(
                state.copy(
                    basket = updatedBasket,
                    tradingListings = updatedListings,
                    statusBanner = "Methodology switched to ${methodology.title} (explicitly isolated)."
                )
            )
            appendLocalAudit(
                next,
                category = "BASKET",
                action = "METHODOLOGY_SET",
                detail = "Basket ${updatedBasket.basketId} explicitly configured as ${methodology.title}."
            )
        }
    }

    fun setBitcoinExposureType(type: BitcoinExposureType) {
        _uiState.update { state ->
            state.copy(
                bitcoinConfig = state.bitcoinConfig.copy(exposureType = type),
                statusBanner = "Bitcoin exposure classified as ${type.label}."
            )
        }
    }

    fun toggleStalePriceSimulation(asset: AssetCode) {
        _uiState.update { state ->
            val updated = state.basket.components.map {
                if (it.asset == asset) it.copy(isStalePrice = !it.isStalePrice) else it
            }
            recalculateAll(
                state.copy(
                    basket = state.basket.copy(components = updated),
                    statusBanner = "Updated ${asset.ticker} price-feed staleness test flag."
                )
            )
        }
    }

    fun updateNoteType(noteType: NoteType) {
        _uiState.update { state ->
            val updatedNote = state.noteStructure.copy(
                noteType = noteType,
                annualCouponBps = if (noteType == NoteType.FIXED_COUPON_BASKET) 425 else 0,
                couponFormula = when (noteType) {
                    NoteType.FIXED_COUPON_BASKET -> "4.25% p.a. semi-annual denominated in Rhino Custom SDR units"
                    NoteType.PARTICIPATION -> "Zero coupon; ${state.noteStructure.participationRatePct}% upside participation"
                    NoteType.PROTECTED_STRUCTURE -> "95.00% contractual floor funded via zero-coupon bond + call spread"
                    NoteType.BASKET_LINKED_PRINCIPAL -> "None — total-return basket performance less fees"
                },
                capitalProtectionFloorPct = if (noteType == NoteType.PROTECTED_STRUCTURE) BigDecimal("95.00") else null,
                capitalProtectionDisclaimer = if (noteType == NoteType.PROTECTED_STRUCTURE) {
                    "95% floor relies on zero-coupon Treasury strip + issuer solvency; NOT guaranteed if RhinoBank Demo Issuer defaults."
                } else {
                    "No principal protection; 100% subject to basket performance and issuer credit risk."
                },
                termsVersion = state.noteStructure.termsVersion + 1
            )
            recalculateAll(state.copy(noteStructure = updatedNote))
        }
    }

    fun updateFundingModel(fundingModel: FundingModel) {
        _uiState.update { state ->
            val p = state.noteStructure.principalAmount
            val updatedNote = state.noteStructure.copy(
                fundingModel = fundingModel,
                securityArrangement = fundingModel.label
            )
            val updatedTreasury = when (fundingModel) {
                FundingModel.UNSECURED_OBLIGATION -> state.treasuryPosition.copy(
                    acquiredAssetsUsd = BigDecimal.ZERO.setScale(2),
                    hedgeNotionalUsd = BigDecimal("4500000.00"),
                    collateralPoolValueUsd = BigDecimal.ZERO.setScale(2),
                    encumberedCollateralUsd = BigDecimal.ZERO.setScale(2),
                    fxMismatchUsd = BigDecimal("2150000.00")
                )
                FundingModel.CONTRACTUALLY_COLLATERALISED -> state.treasuryPosition.copy(
                    acquiredAssetsUsd = p,
                    hedgeNotionalUsd = p,
                    collateralPoolValueUsd = BigDecimal("10500000.00"),
                    encumberedCollateralUsd = p,
                    fxMismatchUsd = BigDecimal("120000.00")
                )
                FundingModel.MATCHED_ASSET -> state.treasuryPosition.copy(
                    acquiredAssetsUsd = p,
                    hedgeNotionalUsd = p,
                    collateralPoolValueUsd = BigDecimal("10000000.00"),
                    encumberedCollateralUsd = p,
                    fxMismatchUsd = BigDecimal.ZERO.setScale(2)
                )
            }
            recalculateAll(
                state.copy(
                    noteStructure = updatedNote,
                    treasuryPosition = updatedTreasury,
                    statusBanner = "Treasury funding structure set to ${fundingModel.label}."
                )
            )
        }
    }

    fun updateMandateBitcoinLimit(newLimit: BigDecimal) {
        _uiState.update { state ->
            val updatedMandate = state.mandate.copy(
                version = state.mandate.version + 1,
                maxBitcoinAllocationPct = newLimit.setScale(2, RoundingMode.HALF_EVEN),
                purchaserAccepted = false,
                acceptanceTimestampUtc = null
            )
            recalculateAll(
                state.copy(
                    mandate = updatedMandate,
                    statusBanner = "Mandate v${updatedMandate.version} updated (BTC cap ${newLimit.toPlainString()}%). Purchaser re-acceptance required."
                )
            )
        }
    }

    fun acceptMandate() {
        _uiState.update { state ->
            val updatedMandate = state.mandate.copy(
                purchaserAccepted = true,
                acceptanceTimestampUtc = "2026-11-15T09:45:00Z"
            )
            val next = recalculateAll(
                state.copy(
                    mandate = updatedMandate,
                    statusBanner = "Purchaser acceptance recorded for Mandate ${updatedMandate.mandateCode} v${updatedMandate.version}."
                )
            )
            appendLocalAudit(
                next,
                category = "MANDATE",
                action = "PURCHASER_ACCEPTANCE",
                detail = "${updatedMandate.legalEntityName} countersigned v${updatedMandate.version}."
            )
        }
    }

    fun verifyFundingAndDualApprovals() {
        _uiState.update { state ->
            val updatedChecklist = state.checklist.copy(
                subscriptionFundsVerified = true,
                issuerDualApprovalOne = true,
                issuerDualApprovalTwo = true,
                segregationOfDutiesPassed = true
            )
            val updatedFlows = state.cashFlows.map { row ->
                if (row.id == "cf_sub") {
                    row.copy(stateLabel = "Verified (Fedwire T+0)", isWarning = false)
                } else row
            }
            val next = state.copy(
                checklist = updatedChecklist,
                cashFlows = updatedFlows,
                lifecycleState = if (state.lifecycleState.stepOrder < IssuanceLifecycleState.FUNDS_VERIFIED.stepOrder) {
                    IssuanceLifecycleState.FUNDS_VERIFIED
                } else state.lifecycleState,
                statusBanner = "Subscription funds verified ($10,000,000 USD) and dual issuer approvals recorded."
            )
            appendLocalAudit(
                next,
                category = "ISSUANCE",
                action = "FUNDS_AND_DUAL_APPROVAL",
                detail = "Fedwire cash confirmed + Dual Issuer Signers 1 & 2 verified (Segregation of duties enforced)."
            )
        }
    }

    fun authoriseAndSubmitToRegistry() {
        _uiState.update { state ->
            val blocking = state.incompatibilities.filter { it.severity == "BLOCK" }
            if (blocking.isNotEmpty()) {
                return@update state.copy(
                    statusBanner = "Issuance blocked: ${blocking.first().message}"
                )
            }
            if (!state.checklist.allSatisfied) {
                return@update state.copy(
                    statusBanner = "Complete funding verification and dual approvals before authorising issuance."
                )
            }
            val idempKey = "issue_${state.noteStructure.seriesCode}_v${state.noteStructure.termsVersion}"
            if (idempKey in state.usedIdempotencyKeys) {
                return@update state.copy(
                    statusBanner = "Idempotency guard: Issuance request $idempKey already processed."
                )
            }

            val nextHeight = state.poSNetwork.finalisedHeight + 1L
            val docHash = QuantitativeEngine.sha256Hex(
                "${state.noteStructure.seriesCode}|${state.mandate.mandateCode}|v${state.noteStructure.termsVersion}"
            ).take(24)

            val newEvent = RegistryEvent(
                eventId = "REG-${state.registryEvents.size + 1}",
                txHash = "0x${docHash.take(12)}...${nextHeight}",
                blockHeight = nextHeight,
                eventType = "NOTE_ISSUANCE_REGISTERED",
                seriesCode = state.noteStructure.seriesCode,
                pseudonymousHolderRef = "HOLDER-REF-PM2047-A1",
                documentCommitmentSha256 = "sha256:$docHash",
                status = RegistryEventStatus.PENDING_CONSENSUS,
                timestampUtc = "2026-11-15 09:46 UTC",
                noteDetail = "Submitted to PoS registry. Pending consensus finality; NOT active until finalised & settled."
            )

            val updatedFlows = state.cashFlows.map { row ->
                if (row.id == "cf_iss") row.copy(stateLabel = "Authorised • Pending Finality", isWarning = true)
                else row
            }

            val next = state.copy(
                lifecycleState = IssuanceLifecycleState.REGISTRY_SUBMITTED,
                poSNetwork = state.poSNetwork.copy(finalisedHeight = nextHeight),
                registryEvents = listOf(newEvent) + state.registryEvents,
                cashFlows = updatedFlows,
                usedIdempotencyKeys = state.usedIdempotencyKeys + idempKey,
                statusBanner = "Issuance authorised and submitted to PoS Registry (Pending consensus finality)."
            )
            appendLocalAudit(
                next,
                category = "REGISTRY",
                action = "REGISTRY_SUBMITTED",
                detail = "Idempotent issuance $idempKey submitted to PoS registry; awaiting consensus finality."
            )
        }
    }

    fun confirmRegistryFinalityAndActivate() {
        _uiState.update { state ->
            if (state.lifecycleState != IssuanceLifecycleState.REGISTRY_SUBMITTED &&
                state.lifecycleState != IssuanceLifecycleState.FINALISED
            ) {
                return@update state.copy(
                    statusBanner = "Submit authorised issuance to registry before confirming finality."
                )
            }
            val nextHeight = state.poSNetwork.finalisedHeight + 2L
            val updatedEvents = state.registryEvents.mapIndexed { idx, ev ->
                if (idx == 0 && ev.status == RegistryEventStatus.PENDING_CONSENSUS) {
                    ev.copy(
                        status = RegistryEventStatus.FINALISED,
                        blockHeight = nextHeight,
                        noteDetail = "Consensus finality achieved across 4 RhinoBank PoS validators + external settlement reconciled."
                    )
                } else ev
            }
            val updatedFlows = state.cashFlows.map { row ->
                if (row.id == "cf_iss") row.copy(stateLabel = "Active • Finalised On-Chain", isWarning = false)
                else row
            }
            val updatedListings = state.tradingListings.map {
                it.copy(published = true, rfqStatus = "Dealer RFQ Enabled (Restricted)")
            }
            val next = state.copy(
                lifecycleState = IssuanceLifecycleState.ACTIVE,
                poSNetwork = state.poSNetwork.copy(finalisedHeight = nextHeight),
                registryEvents = updatedEvents,
                cashFlows = updatedFlows,
                tradingListings = updatedListings,
                statusBanner = "Block #$nextHeight finalised. Series ${state.noteStructure.seriesCode} is ACTIVE and published to dealer terminals."
            )
            appendLocalAudit(
                next,
                category = "REGISTRY",
                action = "CONSENSUS_FINALISED_AND_ACTIVE",
                detail = "Block #$nextHeight finalised; external settlement confirmed; note marked ACTIVE."
            )
        }
    }

    fun advanceServicingItem(itemId: String) {
        _uiState.update { state ->
            val updated = state.servicingSchedule.map { item ->
                if (item.id == itemId) {
                    val nextStatus = when (item.status) {
                        ServicingStatus.SCHEDULED -> ServicingStatus.CALCULATED
                        ServicingStatus.CALCULATED -> ServicingStatus.REVIEWED
                        ServicingStatus.REVIEWED -> ServicingStatus.APPROVED
                        ServicingStatus.APPROVED -> ServicingStatus.INSTRUCTED
                        ServicingStatus.INSTRUCTED -> ServicingStatus.CONFIRMED
                        ServicingStatus.CONFIRMED -> ServicingStatus.RECONCILED
                        ServicingStatus.RECONCILED -> ServicingStatus.RECONCILED
                    }
                    item.copy(status = nextStatus)
                } else item
            }
            val target = updated.first { it.id == itemId }
            val isFinalRedemptionReconciled = target.eventKind == "FINAL_REDEMPTION" &&
                target.status == ServicingStatus.RECONCILED

            val nextLifecycle = if (isFinalRedemptionReconciled) {
                IssuanceLifecycleState.REDEEMED
            } else state.lifecycleState

            val nextEvents = if (isFinalRedemptionReconciled) {
                listOf(
                    RegistryEvent(
                        eventId = "REG-${state.registryEvents.size + 1}",
                        txHash = "0xredeem_${state.poSNetwork.finalisedHeight + 3}",
                        blockHeight = state.poSNetwork.finalisedHeight + 3,
                        eventType = "NOTE_REDEEMED_AND_CANCELLED",
                        seriesCode = state.noteStructure.seriesCode,
                        pseudonymousHolderRef = "HOLDER-REF-PM2047-A1",
                        documentCommitmentSha256 = "sha256:redemption_reconciled_final",
                        status = RegistryEventStatus.FINALISED,
                        timestampUtc = "2026-11-15 09:50 UTC",
                        noteDetail = "Cash redemption reconciled off-chain prior to registry cancellation."
                    )
                ) + state.registryEvents
            } else state.registryEvents

            val next = state.copy(
                servicingSchedule = updated,
                lifecycleState = nextLifecycle,
                registryEvents = nextEvents,
                statusBanner = "Servicing ${target.periodLabel} -> ${target.status.label}."
            )
            appendLocalAudit(
                next,
                category = "SERVICING",
                action = "SERVICING_${target.status.name}",
                detail = "${target.periodLabel} (${target.eventKind}) transitioned to ${target.status.label}."
            )
        }
    }

    fun runStepInFourteenStepDemo(stepNumber: Int) {
        val step = _uiState.value.demoSteps.firstOrNull { it.number == stepNumber } ?: return
        when (stepNumber) {
            1 -> selectSection(TerminalSection.PURCHASERS)
            2 -> selectSection(TerminalSection.BASKET_STUDIO)
            3 -> {
                setMethodology(BasketMethodology.TARGET_WEIGHT)
                selectSection(TerminalSection.BASKET_STUDIO)
            }
            4 -> selectSection(TerminalSection.RISK)
            5 -> {
                acceptMandate()
                selectSection(TerminalSection.PURCHASERS)
            }
            6, 7 -> {
                verifyFundingAndDualApprovals()
                selectSection(TerminalSection.ISSUE)
            }
            8 -> {
                authoriseAndSubmitToRegistry()
                selectSection(TerminalSection.ISSUE)
            }
            9, 10 -> {
                confirmRegistryFinalityAndActivate()
                selectSection(TerminalSection.REGISTRY)
            }
            11 -> selectSection(TerminalSection.OVERVIEW)
            12 -> selectSection(TerminalSection.PRICE)
            13 -> {
                val firstCoupon = _uiState.value.servicingSchedule.firstOrNull()
                if (firstCoupon != null) advanceServicingItem(firstCoupon.id)
                selectSection(TerminalSection.SERVICING)
            }
            14 -> {
                val finalRed = _uiState.value.servicingSchedule.lastOrNull()
                if (finalRed != null) {
                    repeat(6) { advanceServicingItem(finalRed.id) }
                }
                selectSection(TerminalSection.SETTLEMENT)
            }
            else -> selectSection(step.targetSection)
        }
        _uiState.update { state ->
            state.copy(
                activeDemoStep = stepNumber,
                demoSteps = state.demoSteps.map {
                    if (it.number <= stepNumber) it.copy(completed = true) else it
                }
            )
        }
    }

    fun requestAiStructuringAnalysis(userPrompt: String) {
        val state = _uiState.value
        val contextSummary = buildString {
            appendLine("Series: ${state.noteStructure.seriesCode}, Product: ${state.noteStructure.productLabel}")
            appendLine("Purchaser: ${state.mandate.legalEntityName} (${state.mandate.mandateCode} v${state.mandate.version})")
            appendLine("Principal: ${state.noteStructure.principalAmount} ${state.noteStructure.subscriptionCurrency}")
            appendLine("Methodology: ${state.basket.methodology.title}, Rebalancing: ${state.basket.rebalancingSchedule}")
            appendLine("Basket Components:")
            state.basket.components.filter { it.enabled }.forEach {
                appendLine("- ${it.asset.ticker}: weight=${it.targetWeightPct}%, qty=${it.fixedQuantity}, spot=${it.currentSpotRate}")
            }
            appendLine("Valuation: Basket=${state.valuation.basketReferenceValueUsd} USD, Index=${state.valuation.normalisedIndex}, ModelValue=${state.valuation.noteModelValueUsd} USD, Redemption=${state.valuation.redemptionEntitlementUsd} USD")
            appendLine("Lifecycle: ${state.lifecycleState.displayName}")
            appendLine("Incompatibilities: ${state.incompatibilities.joinToString { "${it.code}:${it.message}" }}")
        }

        viewModelScope.launch {
            _uiState.update { it.copy(aiUiState = AiUiState.Loading) }
            val result = aiRepo.generateStructuringAnalysis(userPrompt, contextSummary)
            result.fold(
                onSuccess = { proposal ->
                    _uiState.update { current ->
                        val withAudit = appendLocalAudit(
                            current,
                            category = "AI_PROPOSAL",
                            action = "AI_DRAFT_GENERATED",
                            detail = "${proposal.summaryTitle} (Pending mandatory human review; AI cannot self-approve)."
                        )
                        withAudit.copy(aiUiState = AiUiState.Success(proposal))
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(aiUiState = AiUiState.Error(error.localizedMessage ?: "AI analysis failed."))
                    }
                }
            )
        }
    }

    fun saveWorkspaceToCloud() {
        val state = _uiState.value
        val weightsSummary = state.basket.components
            .filter { it.enabled }
            .joinToString(" / ") { "${it.asset.ticker} ${it.targetWeightPct.stripTrailingZeros().toPlainString()}%" }
        val btcWeight = state.basket.components.firstOrNull { it.asset == AssetCode.BTC }?.targetWeightPct
            ?.toPlainString() ?: "0.00"

        val doc = SavedWorkspaceDoc(
            userId = currentUserId,
            seriesCode = state.noteStructure.seriesCode,
            mandateCode = state.mandate.mandateCode,
            purchaserName = state.mandate.legalEntityName,
            productLabel = state.noteStructure.productLabel,
            methodology = state.basket.methodology.name,
            lifecycleState = state.lifecycleState.name,
            principalAmount = state.noteStructure.principalAmount.toPlainString(),
            reportingCurrency = state.mandate.preferredReportingCurrency,
            btcAllocationPct = btcWeight,
            fundingModel = state.noteStructure.fundingModel.name,
            noteType = state.noteStructure.noteType.name,
            weightsSummary = weightsSummary,
            termsVersion = state.noteStructure.termsVersion
        )

        viewModelScope.launch {
            val docId = "ws_${state.noteStructure.seriesCode.replace("-", "_").lowercase()}"
            val saveRes = firestoreRepo.saveWorkspace(doc, customDocId = docId)
            val mandateRes = firestoreRepo.saveMandateVersion(
                MandateVersionDoc(
                    userId = currentUserId,
                    mandateCode = state.mandate.mandateCode,
                    versionNumber = state.mandate.version,
                    purchaserLegalEntity = state.mandate.legalEntityName,
                    subscriptionCurrency = state.mandate.subscriptionCurrency,
                    subscriptionAmount = state.mandate.subscriptionAmount.toPlainString(),
                    bitcoinLimitPct = state.mandate.maxBitcoinAllocationPct.toPlainString(),
                    purchaserAccepted = state.mandate.purchaserAccepted,
                    incompatibilitySummary = "${state.incompatibilities.count { it.severity == "BLOCK" }} blocking, ${state.incompatibilities.count { it.severity == "WARN" }} warnings"
                ),
                docId = "mv_${state.mandate.mandateCode.lowercase()}_v${state.mandate.version}_${UUID.randomUUID().toString().take(4)}"
            )
            val auditRes = firestoreRepo.appendAuditEvent(
                AuditEventDoc(
                    userId = currentUserId,
                    seriesCode = state.noteStructure.seriesCode,
                    category = "MANDATE",
                    action = "WORKSPACE_SAVED",
                    actor = operatorEmail,
                    detail = "Saved workspace ${state.noteStructure.seriesCode} ($weightsSummary)",
                    documentCommitmentHash = QuantitativeEngine.sha256Hex(weightsSummary).take(24),
                    idempotencyKey = "ws_save_${System.currentTimeMillis()}",
                    registryStatus = if (state.lifecycleState == IssuanceLifecycleState.ACTIVE) "FINALISED" else "OFF_CHAIN"
                )
            )
            val err = saveRes.exceptionOrNull() ?: mandateRes.exceptionOrNull() ?: auditRes.exceptionOrNull()
            _uiState.update {
                it.copy(
                    statusBanner = if (err == null) {
                        "Draft workspace & mandate v${state.mandate.version} persisted to Firestore."
                    } else {
                        "Cloud save error: ${err.localizedMessage}"
                    }
                )
            }
        }
    }

    private fun recalculateAll(state: TerminalUiState): TerminalUiState {
        val valuation = QuantitativeEngine.calculateValuationBreakdown(state.basket, state.noteStructure)
        val incompatibilities = QuantitativeEngine.validateMandateCompatibility(
            state.mandate,
            state.basket,
            state.noteStructure,
            state.bitcoinConfig
        )
        val scenarios = QuantitativeEngine.runReproducibleStressScenarios(state.basket, state.noteStructure)
        val checklist = state.checklist.copy(
            termsApproved = state.noteStructure.termsLocked && state.mandate.purchaserAccepted,
            pricingInputsValid = state.basket.components.none { it.isStalePrice } &&
                QuantitativeEngine.isWeightSumValid(state.basket.components)
        )
        return state.copy(
            valuation = valuation,
            incompatibilities = incompatibilities,
            stressScenarios = scenarios,
            checklist = checklist
        )
    }

    private fun appendLocalAudit(
        state: TerminalUiState,
        category: String,
        action: String,
        detail: String
    ): TerminalUiState {
        val id = "AUD-${state.auditLog.size + 101}"
        val item = AuditLogItem(
            id = id,
            category = category,
            action = action,
            actor = state.operatorEmail,
            detail = detail,
            commitmentHash = "sha256:${QuantitativeEngine.sha256Hex("$id|$action|$detail").take(16)}",
            idempotencyKey = "idem_${action.lowercase()}_${state.auditLog.size + 1}",
            timestampUtc = "2026-11-15 09:45 UTC"
        )
        return state.copy(auditLog = listOf(item) + state.auditLog)
    }

    companion object {
        fun createInitialPennineState(uid: String, email: String): TerminalUiState {
            val principal = BigDecimal("10000000.00")
            val rawComponents = listOf(
                BasketComponent(AssetCode.USD, true, BigDecimal("35.00"), BigDecimal.ZERO, BigDecimal("1.0000"), BigDecimal("1.0000")),
                BasketComponent(AssetCode.GBP, true, BigDecimal("25.00"), BigDecimal.ZERO, BigDecimal("1.2800"), BigDecimal("1.2800")),
                BasketComponent(AssetCode.EUR, true, BigDecimal("15.00"), BigDecimal.ZERO, BigDecimal("1.0900"), BigDecimal("1.0900")),
                BasketComponent(AssetCode.JPY, true, BigDecimal("8.00"), BigDecimal.ZERO, BigDecimal("154.0000"), BigDecimal("154.0000")),
                BasketComponent(AssetCode.CNY, true, BigDecimal("7.00"), BigDecimal.ZERO, BigDecimal("7.2200"), BigDecimal("7.2200")),
                BasketComponent(AssetCode.BTC, true, BigDecimal("10.00"), BigDecimal.ZERO, BigDecimal("94000.00"), BigDecimal("94000.00"))
            )
            val derivedComponents = QuantitativeEngine.deriveInitialQuantities(principal, rawComponents)

            val basket = BasketDefinition(
                basketId = "BSK-PM2047-V3",
                name = "Pennine Custom Reserve Basket",
                baseDate = "2026-11-15",
                baseIndexLevel = BigDecimal("100.00"),
                reportingCurrency = "USD",
                methodology = BasketMethodology.TARGET_WEIGHT,
                rebalancingSchedule = "Quarterly rebalancing",
                rebalancingCostBps = 12,
                managementFeeBps = 25,
                roundingScale = 4,
                disruptionRule = "5 BD postponement; fallback to calculation agent dealer poll.",
                replacementRule = "Approved custody/settlement adapters + purchaser consent only.",
                components = derivedComponents
            )

            val mandate = PurchaserMandate(
                mandateCode = "PM-2047",
                version = 3,
                legalEntityName = "Pennine Global Treasury Ltd.",
                jurisdiction = "United Kingdom",
                leiCode = "549300PENNINE002047",
                authorisedRepresentatives = listOf("H. Vance (Group Treasurer)", "M. Okafor (CIO)"),
                eligibilityClass = "Institutional • Demo verified",
                subscriptionAmount = principal,
                subscriptionCurrency = "USD",
                preferredReportingCurrency = "USD",
                investmentHorizonMonths = 24,
                liquidityRequirement = "Quarterly T+5 redemption window",
                permittedAssets = AssetCode.entries.toSet(),
                maxSingleAssetConcentrationPct = BigDecimal("40.00"),
                maxBitcoinAllocationPct = BigDecimal("10.00"),
                preferredMethodology = BasketMethodology.TARGET_WEIGHT,
                rebalancingPreference = "Quarterly",
                redemptionRequirement = "USD cash settlement at maturity",
                requiredApprovals = listOf("Treasury Dual Approval", "Risk Committee"),
                distributionRestriction = "Private placement; non-bearer registered instrument",
                transferRestriction = "Restricted",
                purchaserAccepted = true,
                acceptanceTimestampUtc = "2026-11-15T09:10:00Z"
            )

            val note = NoteStructure(
                seriesCode = "RBN-2027-A",
                productLabel = "Rhino Custom SDR",
                issuerEntity = "RhinoBank Demo Issuer",
                purchaserEntity = "Pennine Global Treasury Ltd.",
                noteType = NoteType.BASKET_LINKED_PRINCIPAL,
                principalAmount = principal,
                denominationUnit = BigDecimal("100000.00"),
                subscriptionCurrency = "USD",
                issuePricePct = BigDecimal("100.00"),
                basketReferenceId = "BSK-PM2047-V3",
                participationRatePct = BigDecimal("100.00"),
                couponFormula = "None",
                annualCouponBps = 0,
                structuringFeeBps = 15,
                ongoingFeeBps = 25,
                maturityMonths = 24,
                redemptionFormula = "Basket performance less fees",
                settlementCurrency = "USD",
                earlyTerminationProvision = "Quarterly T+5 BD notice less unwind cost",
                ranking = "Senior unsecured contractual obligation",
                securityArrangement = "Unsecured issuer obligation",
                fundingModel = FundingModel.UNSECURED_OBLIGATION,
                transferRestriction = "Restricted registered note — registrar consent required",
                defaultProvision = "5 BD payment cure; English law forum",
                governingDocuments = listOf("Master Note Deed v3", "Series RBN-2027-A Supplement", "Custody Attestation QC09"),
                capitalProtectionFloorPct = null,
                capitalProtectionDisclaimer = "No capital protection. Principal at risk to basket performance & RhinoBank Demo Issuer credit.",
                termsVersion = 3,
                termsLocked = true
            )

            val valuation = QuantitativeEngine.calculateValuationBreakdown(basket, note)
            val scenarios = QuantitativeEngine.runReproducibleStressScenarios(basket, note)
            val backtest = QuantitativeEngine.generateHypotheticalBacktest(basket)
            val incompatibilities = QuantitativeEngine.validateMandateCompatibility(
                mandate,
                basket,
                note,
                BitcoinConfig()
            )

            return TerminalUiState(
                currentUserId = uid,
                operatorEmail = email,
                mandate = mandate,
                basket = basket,
                noteStructure = note,
                checklist = IssuanceChecklist(
                    eligiblePurchaserVerified = true,
                    termsApproved = true,
                    pricingInputsValid = true,
                    subscriptionFundsVerified = false,
                    issuerDualApprovalOne = false,
                    issuerDualApprovalTwo = false,
                    principalLimitPassed = true,
                    segregationOfDutiesPassed = true
                ),
                registryEvents = listOf(
                    RegistryEvent(
                        eventId = "REG-001",
                        txHash = "0x7c41e9...3b8a",
                        blockHeight = 1_248_092L,
                        eventType = "SERIES_TERMS_COMMITTED",
                        seriesCode = "RBN-2027-A",
                        pseudonymousHolderRef = "HOLDER-REF-PM2047-A1",
                        documentCommitmentSha256 = "sha256:9f84b2c1d07a4e33",
                        status = RegistryEventStatus.FINALISED,
                        timestampUtc = "2026-11-15 09:20 UTC",
                        noteDetail = "Series shell & Terms v3 SHA-256 commitment recorded; note not yet issued."
                    )
                ),
                treasuryPosition = TreasuryPosition(
                    subscriptionProceedsUsd = principal,
                    acquiredAssetsUsd = BigDecimal.ZERO.setScale(2),
                    hedgeNotionalUsd = BigDecimal("4500000.00"),
                    annualFundingCostBps = 65,
                    collateralPoolValueUsd = BigDecimal.ZERO.setScale(2),
                    encumberedCollateralUsd = BigDecimal.ZERO.setScale(2),
                    liquidBufferUsd = BigDecimal("1500000.00"),
                    fxMismatchUsd = BigDecimal("2150000.00"),
                    maturityMismatchMonths = 6,
                    doubleAllocationCheckPassed = true
                ),
                servicingSchedule = listOf(
                    ServicingEvent("srv_q1", "Q1 Fixing (2027-02-15)", "COUPON", "2027-02-17", BigDecimal("100.0000"), BigDecimal("0.00"), principal, ServicingStatus.SCHEDULED, false, "FED-Q1-PEND"),
                    ServicingEvent("srv_q2", "Q2 Rebalance & Fee Fix (2027-05-15)", "PARTIAL_REDEMPTION", "2027-05-18", BigDecimal("101.4200"), BigDecimal("1000000.00"), BigDecimal("9000000.00"), ServicingStatus.SCHEDULED, false, "FED-Q2-PEND"),
                    ServicingEvent("srv_mat", "Final Maturity Redemption (2028-11-15)", "FINAL_REDEMPTION", "2028-11-17", BigDecimal("104.8500"), BigDecimal("9395000.00"), BigDecimal("0.00"), ServicingStatus.SCHEDULED, false, "FED-MAT-PEND")
                ),
                tradingListings = listOf(
                    TradingListing(
                        venueName = "RhinoBank SDR Markets",
                        seriesCode = "RBN-2027-A",
                        issuer = "RhinoBank Demo Issuer",
                        noteType = "Basket-linked registered note (Rhino Custom SDR)",
                        basketMethodology = BasketMethodology.TARGET_WEIGHT.title,
                        contractVersion = 3,
                        transferRestrictions = "Qualified institutional registered transfer only",
                        settlementMechanics = "USD DVP off-chain + Registrar consent",
                        indicativeBidPct = BigDecimal("99.45"),
                        indicativeAskPct = BigDecimal("100.15"),
                        published = false,
                        rfqStatus = "Pending Active Issuance",
                        legalAdmissionStatus = "Private Placement Exempt (Not Exchange Listed)"
                    ),
                    TradingListing(
                        venueName = "Aureom Trade",
                        seriesCode = "RBN-2027-A",
                        issuer = "RhinoBank Demo Issuer",
                        noteType = "Basket-linked registered note (Rhino Custom SDR)",
                        basketMethodology = BasketMethodology.TARGET_WEIGHT.title,
                        contractVersion = 3,
                        transferRestrictions = "Whitelisted Counterparty RFQ Only",
                        settlementMechanics = "T+2 Institutional Cash Wire + Registry Novation",
                        indicativeBidPct = BigDecimal("99.30"),
                        indicativeAskPct = BigDecimal("100.25"),
                        published = false,
                        rfqStatus = "Pending Active Issuance",
                        legalAdmissionStatus = "Informational Feed Only"
                    )
                ),
                stressScenarios = scenarios,
                backtestPoints = backtest,
                incompatibilities = incompatibilities,
                valuation = valuation,
                cashFlows = listOf(
                    CashFlowRow("cf_sub", "Subscription", "USD 10,000,000", "Pending verification", true, "2026-11-15 09:42 UTC"),
                    CashFlowRow("cf_iss", "Note issuance", "Principal 10,000,000 USD", "Not authorised", false, "—"),
                    CashFlowRow("cf_red", "Redemption", "At maturity", "Contract-defined", false, "2028-11-15")
                ),
                auditLog = listOf(
                    AuditLogItem("AUD-103", "TERMS", "TERMS_V3_LOCKED", "structuring.desk@rhinobank.demo", "Series RBN-2027-A Terms v3 locked for dual approval.", "sha256:9f84b2c1d07a", "idem_terms_v3", "2026-11-15 09:20 UTC"),
                    AuditLogItem("AUD-102", "BASKET", "BASKET_VALIDATED", "quant.engine@rhinobank.demo", "Target weights summed to 100.00% (5 FX + 10% BTC).", "sha256:4b12e8f0912c", "idem_bsk_v3", "2026-11-15 09:15 UTC"),
                    AuditLogItem("AUD-101", "MANDATE", "MANDATE_CREATED", "pennine.treasury@client.demo", "Mandate PM-2047 v3 created for $10,000,000 USD.", "sha256:1a09c7d5581e", "idem_mnd_v3", "2026-11-15 09:10 UTC")
                ),
                demoSteps = listOf(
                    DemoStep(1, "Mandate creation", TerminalSection.PURCHASERS, "Configure Pennine Global Treasury Ltd. (PM-2047) with 10% BTC cap.", true),
                    DemoStep(2, "Basket design", TerminalSection.BASKET_STUDIO, "Build 5 currencies + optional 10% BTC reserve basket.", true),
                    DemoStep(3, "Methodology selection", TerminalSection.BASKET_STUDIO, "Explicitly select Target-Weight vs Fixed-Quantity.", true),
                    DemoStep(4, "Pricing & stress testing", TerminalSection.RISK, "Run reproducible BTC -50% & FX stress scenarios.", true),
                    DemoStep(5, "Purchaser acceptance", TerminalSection.PURCHASERS, "Record Pennine countersignature on Mandate v3.", true),
                    DemoStep(6, "Issuer approval", TerminalSection.ISSUE, "Record dual issuer signers with segregation of duties.", false),
                    DemoStep(7, "Simulated funding", TerminalSection.ISSUE, "Confirm $10M USD Fedwire subscription evidence.", false),
                    DemoStep(8, "Note issuance", TerminalSection.ISSUE, "Authorise idempotent issuance & submit to PoS registry.", false),
                    DemoStep(9, "Blockchain finality", TerminalSection.REGISTRY, "Achieve 4-validator consensus finality on RhinoReg PoS.", false),
                    DemoStep(10, "Registered ownership", TerminalSection.REGISTRY, "Verify pseudonymous holder ref & legal register authority.", false),
                    DemoStep(11, "Terminal publication", TerminalSection.OVERVIEW, "Publish eligible note to RhinoBank SDR Markets & Aureom Trade.", false),
                    DemoStep(12, "Valuation updates", TerminalSection.PRICE, "Separate Basket Value, Model Value, Subscription & Redemption.", false),
                    DemoStep(13, "Coupon servicing", TerminalSection.SERVICING, "Advance servicing workflow through Scheduled -> Reconciled.", false),
                    DemoStep(14, "Redemption & reconciliation", TerminalSection.SETTLEMENT, "Reconcile final cash redemption before registry cancellation.", false)
                )
            )
        }
    }
}
