package com.example.domain.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AssetBtcColor
import com.example.ui.theme.AssetCnyColor
import com.example.ui.theme.AssetEurColor
import com.example.ui.theme.AssetGbpColor
import com.example.ui.theme.AssetJpyColor
import com.example.ui.theme.AssetUsdColor
import java.math.BigDecimal

enum class TerminalSection(val label: String) {
    OVERVIEW("Overview"),
    PURCHASERS("Purchasers"),
    BASKET_STUDIO("Basket Studio"),
    STRUCTURE("Structure"),
    PRICE("Price"),
    ISSUE("Issue"),
    REGISTRY("Registry"),
    TREASURY("Treasury"),
    RISK("Risk"),
    SERVICING("Servicing"),
    SETTLEMENT("Settlement"),
    AUDIT("Audit")
}

enum class DensityMode(val label: String) {
    COMPACT("Compact"),
    STANDARD("Standard"),
    COMFORTABLE("Comfortable")
}

enum class BasketMethodology(val title: String, val subtitle: String) {
    TARGET_WEIGHT(
        "Target-weight basket",
        "Weights follow an explicitly defined rebalancing schedule with transaction-cost and execution assumptions."
    ),
    FIXED_QUANTITY(
        "Fixed-quantity basket",
        "Component quantities are established on a base date and remain unchanged unless the contract permits adjustment."
    )
}

enum class FxQuotationConvention(val conventionLabel: String, val isDirectUsdPerUnit: Boolean) {
    USD_BASE("1.0000 USD", true),
    GBP_USD("GBP/USD (USD per 1 GBP)", true),
    EUR_USD("EUR/USD (USD per 1 EUR)", true),
    USD_JPY("USD/JPY (JPY per 1 USD, inverted)", false),
    USD_CNY("USD/CNY (CNY per 1 USD, inverted)", false),
    BTC_USD("BTC/USD (USD per 1 BTC)", true)
}

enum class AssetCode(
    val ticker: String,
    val displayName: String,
    val adapterApproved: Boolean,
    val custodyAdapter: String,
    val settlementAdapter: String,
    val priceSource: String,
    val observationTimeUtc: String,
    val fxConvention: FxQuotationConvention,
    val fallbackRule: String,
    val accentColor: Color
) {
    USD(
        ticker = "USD",
        displayName = "US dollar",
        adapterApproved = true,
        custodyAdapter = "FRB-NY Fedwire Cash Omnibus",
        settlementAdapter = "Fedwire / CHIPS T+0",
        priceSource = "Par Numeraire (1.0000)",
        observationTimeUtc = "16:00 UTC",
        fxConvention = FxQuotationConvention.USD_BASE,
        fallbackRule = "Numeraire currency; no FX fallback required.",
        accentColor = AssetUsdColor
    ),
    GBP(
        ticker = "GBP",
        displayName = "Pound sterling",
        adapterApproved = true,
        custodyAdapter = "BoE RTGS Clearing Correspondent",
        settlementAdapter = "CHAPS T+1",
        priceSource = "WM/Refinitiv 16:00 LDN Fix",
        observationTimeUtc = "16:00 UTC",
        fxConvention = FxQuotationConvention.GBP_USD,
        fallbackRule = "ECB 14:15 CET reference cross, then prior London BD fix.",
        accentColor = AssetGbpColor
    ),
    EUR(
        ticker = "EUR",
        displayName = "Euro",
        adapterApproved = true,
        custodyAdapter = "TARGET2 Eurosystem Custody Account",
        settlementAdapter = "TARGET2 T+1",
        priceSource = "WM/Refinitiv 16:00 LDN Fix",
        observationTimeUtc = "16:00 UTC",
        fxConvention = FxQuotationConvention.EUR_USD,
        fallbackRule = "ECB euro reference rate, then prior TARGET2 BD fix.",
        accentColor = AssetEurColor
    ),
    JPY(
        ticker = "JPY",
        displayName = "Japanese yen",
        adapterApproved = true,
        custodyAdapter = "BOJ-NET Tokyo Correspondent",
        settlementAdapter = "BOJ-NET T+2",
        priceSource = "Tokyo 15:00 JST / WM 16:00 LDN",
        observationTimeUtc = "16:00 UTC",
        fxConvention = FxQuotationConvention.USD_JPY,
        fallbackRule = "BOJ 17:00 JST indicative rate, then calculation agent dealer poll (3 banks).",
        accentColor = AssetJpyColor
    ),
    CNY(
        ticker = "CNY",
        displayName = "Chinese renminbi",
        adapterApproved = true,
        custodyAdapter = "CIPS Onshore/CNH Settlement Window",
        settlementAdapter = "CIPS / RTGS T+2",
        priceSource = "CFETS / WM CNH-CNY Bridge Fix",
        observationTimeUtc = "16:00 UTC",
        fxConvention = FxQuotationConvention.USD_CNY,
        fallbackRule = "CNH offshore proxy + onshore basis spread cap (50 bps).",
        accentColor = AssetCnyColor
    ),
    BTC(
        ticker = "BTC",
        displayName = "Bitcoin",
        adapterApproved = true,
        custodyAdapter = "Segregated Qualified Cold Vault (MPC-HSM)",
        settlementAdapter = "Custodian Internal Book + L1 Finality (6 confs)",
        priceSource = "CF Benchmarks BRRNY / CoinDesk XBX",
        observationTimeUtc = "16:00 UTC (60m TWAP)",
        fxConvention = FxQuotationConvention.BTC_USD,
        fallbackRule = "Secondary Kaiko median if spread > 150 bps; else valuation disruption postponement.",
        accentColor = AssetBtcColor
    )
}

enum class BitcoinExposureType(val label: String, val riskNote: String) {
    DIRECT_CUSTODY(
        "Direct segregated Bitcoin custody",
        "Held by qualified custodian in segregated cold vault; subject to custodian insolvency, key governance, and encumbrance verification."
    ),
    THIRD_PARTY_EXPOSURE(
        "Third-party ETP / omnibus exposure",
        "Indirect exposure via institutional trust or prime broker; adds issuer/vehicle credit and tracking-error risk."
    ),
    DERIVATIVE_EXPOSURE(
        "CME / OTC cash-settled derivative",
        "Synthetic delta via cleared futures or OTC swap; introduces roll yield, margin funding, and counterparty exposure."
    )
}

data class BitcoinConfig(
    val enabled: Boolean = true,
    val exposureType: BitcoinExposureType = BitcoinExposureType.DIRECT_CUSTODY,
    val primaryPriceSource: String = "CF Benchmarks BRRNY (16:00 UTC 60-min TWAP)",
    val secondaryPriceSources: List<String> = listOf("CoinDesk XBX Index", "Kaiko Institutional Composite"),
    val weekendHolidayRule: String = "24/7 spot monitored; contractual NAV uses Friday 16:00 UTC fix or next London/NY business day unless Monday 08:00 UTC gap exceeds 8%.",
    val disagreementThresholdBps: Int = 150,
    val liquidityAssumption: String = "$25.0M daily institutional execution capacity (max 15 bps slippage for $1.0M tranche).",
    val custodyConfig: String = "Qualified Custodian Vault ID: QC-BTC-VAULT-09 (No private keys in app DB or logs).",
    val settlementConfirmationPolicy: String = "6 Bitcoin L1 confirmations (~60 min) + signed custodian attestation.",
    val operationalRestrictions: String = "No permissionless withdrawal; transfers restricted to whitelisted settlement vaults.",
    val custodyEvidenceRef: String = "ATT-2026-11-15-QC09 (Hash: 4a91f0...c82e)",
    val encumbranceStatus: String = "Unencumbered allocation tagged to RBN-2027-A (Pending final settlement sweep)",
    val verificationLimitNotice: String = "A blockchain entry stating Bitcoin backs a note is NOT cryptographic proof that the issuer controls unencumbered Bitcoin. Off-chain custodian legal title and periodic reconciliation govern."
)

data class BasketComponent(
    val asset: AssetCode,
    val enabled: Boolean,
    val targetWeightPct: BigDecimal, // e.g., 35.00
    val fixedQuantity: BigDecimal,   // units of asset (e.g., 3500000 USD, or 10.63829787 BTC)
    val baseSpotRate: BigDecimal,    // quoted per AssetCode.fxConvention
    val currentSpotRate: BigDecimal, // live/scenario spot quoted per AssetCode.fxConvention
    val isStalePrice: Boolean = false
)

data class BasketDefinition(
    val basketId: String,
    val name: String,
    val baseDate: String,
    val baseIndexLevel: BigDecimal,
    val reportingCurrency: String,
    val methodology: BasketMethodology,
    val rebalancingSchedule: String,
    val rebalancingCostBps: Int,
    val managementFeeBps: Int,
    val roundingScale: Int,
    val disruptionRule: String,
    val replacementRule: String,
    val components: List<BasketComponent>
)

data class MandateIncompatibility(
    val code: String,
    val severity: String, // "BLOCK" or "WARN"
    val message: String
)

data class PurchaserMandate(
    val mandateCode: String,
    val version: Int,
    val legalEntityName: String,
    val jurisdiction: String,
    val leiCode: String,
    val authorisedRepresentatives: List<String>,
    val eligibilityClass: String,
    val subscriptionAmount: BigDecimal,
    val subscriptionCurrency: String,
    val preferredReportingCurrency: String,
    val investmentHorizonMonths: Int,
    val liquidityRequirement: String,
    val permittedAssets: Set<AssetCode>,
    val maxSingleAssetConcentrationPct: BigDecimal,
    val maxBitcoinAllocationPct: BigDecimal,
    val preferredMethodology: BasketMethodology,
    val rebalancingPreference: String,
    val redemptionRequirement: String,
    val requiredApprovals: List<String>,
    val distributionRestriction: String,
    val transferRestriction: String,
    val purchaserAccepted: Boolean,
    val acceptanceTimestampUtc: String?
)

enum class NoteType(val label: String, val description: String) {
    BASKET_LINKED_PRINCIPAL(
        "Basket-linked registered note",
        "Principal redemption tracks normalised custom basket index less accrued fees."
    ),
    FIXED_COUPON_BASKET(
        "Fixed-coupon basket-unit note",
        "Pays fixed semi-annual coupon denominated in Rhino Custom SDR basket units."
    ),
    PARTICIPATION(
        "Basket participation note",
        "Configurable upside participation rate linked to custom basket appreciation."
    ),
    PROTECTED_STRUCTURE(
        "Contractually protected structure",
        "Principal floor funded via explicit zero-coupon bond + basket call overlay; subject to issuer credit risk."
    )
}

enum class FundingModel(val label: String, val legalSummary: String) {
    UNSECURED_OBLIGATION(
        "Unsecured issuer obligation",
        "Direct senior unsecured contractual obligation of RhinoBank Demo Issuer; holder relies on issuer balance sheet."
    ),
    CONTRACTUALLY_COLLATERALISED(
        "Contractually collateralised note",
        "Secured by ring-fenced pledge pool under English-law security deed; no double allocation permitted."
    ),
    MATCHED_ASSET(
        "Matched-asset replication book",
        "Treasury holds matched FX deposits and segregated BTC custody to hedge market delta; custody/liquidity risks remain."
    )
}

data class NoteStructure(
    val seriesCode: String,
    val productLabel: String, // Always "Rhino Custom SDR"
    val issuerEntity: String,
    val purchaserEntity: String,
    val noteType: NoteType,
    val principalAmount: BigDecimal,
    val denominationUnit: BigDecimal,
    val subscriptionCurrency: String,
    val issuePricePct: BigDecimal,
    val basketReferenceId: String,
    val participationRatePct: BigDecimal,
    val couponFormula: String,
    val annualCouponBps: Int,
    val structuringFeeBps: Int,
    val ongoingFeeBps: Int,
    val maturityMonths: Int,
    val redemptionFormula: String,
    val settlementCurrency: String,
    val earlyTerminationProvision: String,
    val ranking: String,
    val securityArrangement: String,
    val fundingModel: FundingModel,
    val transferRestriction: String,
    val defaultProvision: String,
    val governingDocuments: List<String>,
    val capitalProtectionFloorPct: BigDecimal?,
    val capitalProtectionDisclaimer: String,
    val termsVersion: Int,
    val termsLocked: Boolean
)

enum class IssuanceLifecycleState(
    val displayName: String,
    val stepOrder: Int,
    val isException: Boolean = false
) {
    MANDATE_DRAFT("Mandate Draft", 0),
    BASKET_APPROVED("Basket Approved", 1),
    TERMS_APPROVED("Terms Approved", 2),
    SUBSCRIPTION_OPEN("Subscription Open", 3),
    FUNDS_VERIFIED("Funds Verified", 4),
    ISSUANCE_AUTHORISED("Issuance Authorised", 5),
    REGISTRY_SUBMITTED("Registry Submitted", 6),
    FINALISED("Finalised", 7),
    ACTIVE("Active", 8),
    REDEEMED("Redeemed", 9),
    REJECTED("Rejected", -1, true),
    CANCELLED("Cancelled", -2, true),
    FAILED_SETTLEMENT("Failed Settlement", -3, true),
    EXCEPTION("Exception", -4, true)
}

data class IssuanceChecklist(
    val eligiblePurchaserVerified: Boolean,
    val termsApproved: Boolean,
    val pricingInputsValid: Boolean,
    val subscriptionFundsVerified: Boolean,
    val issuerDualApprovalOne: Boolean,
    val issuerDualApprovalTwo: Boolean,
    val principalLimitPassed: Boolean,
    val segregationOfDutiesPassed: Boolean
) {
    val allSatisfied: Boolean
        get() = eligiblePurchaserVerified &&
            termsApproved &&
            pricingInputsValid &&
            subscriptionFundsVerified &&
            issuerDualApprovalOne &&
            issuerDualApprovalTwo &&
            principalLimitPassed &&
            segregationOfDutiesPassed
}

enum class RegistryEventStatus(val label: String) {
    PENDING_CONSENSUS("Pending Consensus"),
    FINALISED("Finalised"),
    FAILED("Failed"),
    RECOVERED("Recovered / Court Order")
}

data class RegistryEvent(
    val eventId: String,
    val txHash: String,
    val blockHeight: Long,
    val eventType: String,
    val seriesCode: String,
    val pseudonymousHolderRef: String,
    val documentCommitmentSha256: String,
    val status: RegistryEventStatus,
    val timestampUtc: String,
    val noteDetail: String
)

data class PoSNetworkState(
    val networkName: String = "RhinoReg PoS Testnet (CometBFT-based Institutional Ledger)",
    val validatorCount: Int = 4,
    val validatorGovernanceDisclosure: String = "All 4 validators are operated under common RhinoBank administration for demonstration; not an independent decentralized institutional validator set.",
    val validatorStakeSeparationNotice: String = "Validator staking tokens are strictly segregated from note proceeds, investor assets, collateral pools, issuer capital, and liquidity reserves.",
    val finalisedHeight: Long = 1_248_092L,
    val indexerLagMs: Long = 140L,
    val authoritativeRegisterRule: String = "Master Note Deed & Private Placement Memorandum designate the Off-Chain Legal Register maintained by RhinoBank Registrar as authoritative for legal title; on-chain state mirrors commitments and flags discrepancies for dual-control reconciliation.",
    val privacyWarning: String = "Confidential purchaser identities and legal agreements remain strictly off-chain. Only pseudonymous holder refs and SHA-256 commitments are written on-chain; timing/amount metadata may still reveal activity patterns (hashing PII does not anonymise it).",
    val recoveryProcedure: String = "Controlled recovery, clerical correction, and court-order reassignment require Registrar + Compliance dual-signature + Legal Hold clearance, appending a superseding governance event without erasing history."
)

data class TreasuryPosition(
    val subscriptionProceedsUsd: BigDecimal,
    val acquiredAssetsUsd: BigDecimal,
    val hedgeNotionalUsd: BigDecimal,
    val annualFundingCostBps: Int,
    val collateralPoolValueUsd: BigDecimal,
    val encumberedCollateralUsd: BigDecimal,
    val liquidBufferUsd: BigDecimal,
    val fxMismatchUsd: BigDecimal,
    val maturityMismatchMonths: Int,
    val doubleAllocationCheckPassed: Boolean,
    val replicationRiskDisclosure: String = "A matched-asset replication strategy does NOT eliminate counterparty, qualified-custody, weekend gap, or market liquidity risk."
)

enum class ServicingStatus(val label: String) {
    SCHEDULED("Scheduled"),
    CALCULATED("Calculated"),
    REVIEWED("Reviewed"),
    APPROVED("Approved"),
    INSTRUCTED("Instructed"),
    CONFIRMED("Confirmed"),
    RECONCILED("Reconciled")
}

data class ServicingEvent(
    val id: String,
    val periodLabel: String,
    val eventKind: String, // "COUPON", "PARTIAL_REDEMPTION", "FINAL_REDEMPTION"
    val dueDate: String,
    val basketIndexAtFixing: BigDecimal,
    val calculatedAmountUsd: BigDecimal,
    val remainingPrincipalUsd: BigDecimal,
    val status: ServicingStatus,
    val usedFallbackPrice: Boolean,
    val settlementRef: String
)

data class CashFlowRow(
    val id: String,
    val eventName: String,
    val amountDisplay: String,
    val stateLabel: String,
    val isWarning: Boolean,
    val timestampUtc: String
)

data class StressScenarioResult(
    val id: String,
    val label: String,
    val shockDescription: String,
    val basketImpactPct: BigDecimal,
    val noteModelValueUsd: BigDecimal,
    val redemptionEntitlementUsd: BigDecimal,
    val seed: Long,
    val calibrationWindow: String,
    val distributionModel: String,
    val limitations: String
)

data class BacktestPoint(
    val dateLabel: String,
    val targetWeightIndex: BigDecimal,
    val fixedQtyIndex: BigDecimal,
    val benchmarkUsdOnly: BigDecimal
)

data class TradingListing(
    val venueName: String, // "RhinoBank SDR Markets" or "Aureom Trade"
    val seriesCode: String,
    val issuer: String,
    val noteType: String,
    val basketMethodology: String,
    val contractVersion: Int,
    val transferRestrictions: String,
    val settlementMechanics: String,
    val indicativeBidPct: BigDecimal,
    val indicativeAskPct: BigDecimal,
    val published: Boolean,
    val rfqStatus: String,
    val legalAdmissionStatus: String
)

data class AuditLogItem(
    val id: String,
    val category: String,
    val action: String,
    val actor: String,
    val detail: String,
    val commitmentHash: String,
    val idempotencyKey: String,
    val timestampUtc: String
)

data class DemoStep(
    val number: Int,
    val title: String,
    val targetSection: TerminalSection,
    val description: String,
    val completed: Boolean
)
