package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RhinoDarkColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = ObsidianVoid,
    primaryContainer = ChampagneGoldMuted,
    onPrimaryContainer = ChampagneGold,
    secondary = CyanSelected,
    onSecondary = ObsidianVoid,
    secondaryContainer = CyanSurface,
    onSecondaryContainer = CyanSelected,
    tertiary = EmeraldVerified,
    onTertiary = ObsidianVoid,
    tertiaryContainer = EmeraldSurface,
    onTertiaryContainer = EmeraldVerified,
    background = ObsidianVoid,
    onBackground = PlatinumText,
    surface = MidnightPanel,
    onSurface = PlatinumText,
    surfaceVariant = ElevatedSlatePanel,
    onSurfaceVariant = SlateMuted,
    outline = PlatinumDivider,
    outlineVariant = SubtleGridLine,
    error = CrimsonAlert,
    onError = ObsidianVoid,
    errorContainer = CrimsonSurface,
    onErrorContainer = CrimsonAlert
)

val RhinoShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(10.dp),
    extraLarge = RoundedCornerShape(14.dp)
)

@Composable
fun RhinoBankTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RhinoDarkColorScheme,
        typography = RhinoTypography,
        shapes = RhinoShapes,
        content = content
    )
}
