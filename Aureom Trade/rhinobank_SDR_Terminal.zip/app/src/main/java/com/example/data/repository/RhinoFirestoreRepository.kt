package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AuditEventDoc
import com.example.data.model.MandateVersionDoc
import com.example.data.model.SavedWorkspaceDoc
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class RhinoFirestoreRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return Firebase.auth.currentUser?.uid
            ?: throw IllegalStateException("Authenticated operator session required.")
    }

    fun observeWorkspaces(userId: String): Flow<List<SavedWorkspaceDoc>> = flow {
        val path = "users/$userId/workspaces"
        db.collection("users").document(userId).collection("workspaces")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    SavedWorkspaceDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val ex = firestoreError ?: (error as? Exception)
                if (ex != null && Firebase.auth.currentUser?.uid == userId) {
                    handleFirestoreError(ex, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun saveWorkspace(workspace: SavedWorkspaceDoc, customDocId: String? = null): Result<String> {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("workspaces")
        val docRef = if (workspace.id.isNotBlank()) {
            colRef.document(workspace.id)
        } else if (!customDocId.isNullOrBlank()) {
            colRef.document(customDocId)
        } else {
            colRef.document()
        }
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(workspace.toUpdateMap()).await()
            } else {
                docRef.set(workspace.toCreateMap(uid)).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val op = if (workspace.id.isNotBlank()) OperationType.UPDATE else OperationType.CREATE
            handleFirestoreError(e, op, docRef.path)
            Result.failure(e)
        }
    }

    fun observeMandateVersions(userId: String): Flow<List<MandateVersionDoc>> = flow {
        val path = "users/$userId/mandateVersions"
        db.collection("users").document(userId).collection("mandateVersions")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    MandateVersionDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).sortedByDescending { it.versionNumber }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val ex = firestoreError ?: (error as? Exception)
                if (ex != null && Firebase.auth.currentUser?.uid == userId) {
                    handleFirestoreError(ex, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun saveMandateVersion(record: MandateVersionDoc, docId: String? = null): Result<String> {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("mandateVersions")
        val docRef = if (!docId.isNullOrBlank()) colRef.document(docId) else colRef.document()
        return try {
            docRef.set(record.toCreateMap(uid)).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeAuditEvents(userId: String): Flow<List<AuditEventDoc>> = flow {
        val path = "users/$userId/auditEvents"
        db.collection("users").document(userId).collection("auditEvents")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    AuditEventDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val ex = firestoreError ?: (error as? Exception)
                if (ex != null && Firebase.auth.currentUser?.uid == userId) {
                    handleFirestoreError(ex, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun appendAuditEvent(event: AuditEventDoc, docId: String? = null): Result<String> {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("auditEvents")
        val docRef = if (!docId.isNullOrBlank()) colRef.document(docId) else colRef.document()
        return try {
            docRef.set(event.toCreateMap(uid)).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }
}
