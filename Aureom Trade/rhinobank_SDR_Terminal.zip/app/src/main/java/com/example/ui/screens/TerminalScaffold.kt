package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.DensityMode
import com.example.domain.model.TerminalSection
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatUsd
import com.example.ui.theme.AmberException
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldMuted
import com.example.ui.theme.CyanSelected
import com.example.ui.theme.CyanSurface
import com.example.ui.theme.ElevatedSlatePanel
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.IvoryHeading
import com.example.ui.theme.MidnightPanel
import com.example.ui.theme.MonoFinancialSmall
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.PlatinumDivider
import com.example.ui.theme.PlatinumText
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SubtleGridLine
import com.example.ui.viewmodel.BottomLedgerTab
import com.example.ui.viewmodel.TerminalUiState
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun TerminalWorkstationScreen(
    viewModel: TerminalViewModel,
    state: TerminalUiState,
    onSignOut: () -> Unit
) {
    var bottomExpanded by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // 1. Top Institutional Header & 12-Section Navigation Strip
        TopTerminalHeader(
            state = state,
            onSelectSection = viewModel::selectSection,
            onCycleDensity = {
                val next = when (state.densityMode) {
                    DensityMode.COMPACT -> DensityMode.STANDARD
                    DensityMode.STANDARD -> DensityMode.COMFORTABLE
                    DensityMode.COMFORTABLE -> DensityMode.COMPACT
                }
                viewModel.setDensityMode(next)
            },
            onOpenAi = { viewModel.toggleAiSheet(true) },
            onOpenCompare = { viewModel.toggleComparisonSheet(true) },
            onSignOut = onSignOut
        )

        // Optional status notification banner
        if (state.statusBanner != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyanSurface)
                    .border(0.5.dp, CyanSelected)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = state.statusBanner,
                    style = MaterialTheme.typography.bodySmall,
                    color = IvoryHeading,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = viewModel::dismissBanner,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "Dismiss notification", tint = CyanSelected, modifier = Modifier.size(16.dp))
                }
            }
        }

        // 2. Main Scrollable Terminal Content Area
        val contentPadding = when (state.densityMode) {
            DensityMode.COMPACT -> 8.dp
            DensityMode.STANDARD -> 14.dp
            DensityMode.COMFORTABLE -> 18.dp
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(contentPadding)
        ) {
            when (state.activeSection) {
                TerminalSection.OVERVIEW -> OverviewSection(
                    state = state,
                    onRunDemoStep = viewModel::runStepInFourteenStepDemo,
                    onOpenComparison = { viewModel.toggleComparisonSheet(true) },
                    onOpenAiAssistant = { viewModel.toggleAiSheet(true) }
                )
                TerminalSection.PURCHASERS -> PurchasersSection(
                    state = state,
                    onUpdateBtcLimit = viewModel::updateMandateBitcoinLimit,
                    onAcceptMandate = viewModel::acceptMandate,
                    onSaveMandateToCloud = viewModel::saveWorkspaceToCloud
                )
                TerminalSection.BASKET_STUDIO -> BasketStudioSection(
                    state = state,
                    onSelectComponent = viewModel::selectComponent,
                    onToggleComponent = viewModel::toggleComponentEnabled,
                    onUpdateWeight = viewModel::updateComponentWeight,
                    onSelectMethodology = viewModel::setMethodology,
                    onSetBitcoinExposure = viewModel::setBitcoinExposureType,
                    onSaveDraft = viewModel::saveWorkspaceToCloud,
                    onSubmitApproval = { viewModel.selectSection(TerminalSection.ISSUE) },
                    onAuthoriseIssuance = viewModel::authoriseAndSubmitToRegistry
                )
                TerminalSection.STRUCTURE -> StructureSection(
                    state = state,
                    onSelectNoteType = viewModel::updateNoteType
                )
                TerminalSection.PRICE -> PriceSection(
                    state = state,
                    onToggleStalePrice = viewModel::toggleStalePriceSimulation
                )
                TerminalSection.ISSUE -> IssueSection(
                    state = state,
                    onVerifyFundingAndApprovals = viewModel::verifyFundingAndDualApprovals,
                    onAuthoriseIssuance = viewModel::authoriseAndSubmitToRegistry,
                    onConfirmFinality = viewModel::confirmRegistryFinalityAndActivate
                )
                TerminalSection.REGISTRY -> RegistrySection(state = state)
                TerminalSection.TREASURY -> TreasurySection(
                    state = state,
                    onSelectFundingModel = viewModel::updateFundingModel
                )
                TerminalSection.RISK -> RiskSection(state = state)
                TerminalSection.SERVICING -> ServicingSection(
                    state = state,
                    onAdvanceServicing = viewModel::advanceServicingItem
                )
                TerminalSection.SETTLEMENT -> SettlementSection(state = state)
                TerminalSection.AUDIT -> AuditSection(state = state)
            }
        }

        // 3. Bottom Tabbed Ledger Panel (Cash flows / Funding / Registry events / Audit)
        BottomLedgerPanel(
            state = state,
            expanded = bottomExpanded,
            onToggleExpand = { bottomExpanded = !bottomExpanded },
            onSelectTab = viewModel::selectBottomTab
        )

        // 4. Persistent Bottom Regulatory & Connection Status Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MidnightPanel)
                .border(0.5.dp, PlatinumDivider)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SYNTHETIC DATA • PRIVATE ISSUER OBLIGATION • NOT AN IMF SDR",
                style = MonoFinancialSmall,
                color = SlateMuted,
                modifier = Modifier.weight(1f)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(EmeraldVerified))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${state.firestoreSyncStatus} • Lag ${state.poSNetwork.indexerLagMs}ms",
                    style = MonoFinancialSmall,
                    color = EmeraldVerified
                )
            }
        }
    }

    if (state.showAiSheet) {
        AiStructuringDialog(
            state = state,
            onAskAi = viewModel::requestAiStructuringAnalysis,
            onDismiss = { viewModel.toggleAiSheet(false) }
        )
    }

    if (state.showComparisonSheet) {
        ComparisonWorkspaceDialog(
            state = state,
            onDismiss = { viewModel.toggleComparisonSheet(false) }
        )
    }
}

@Composable
private fun TopTerminalHeader(
    state: TerminalUiState,
    onSelectSection: (TerminalSection) -> Unit,
    onCycleDensity: () -> Unit,
    onOpenAi: () -> Unit,
    onOpenCompare: () -> Unit,
    onSignOut: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MidnightPanel)
            .border(0.5.dp, PlatinumDivider)
    ) {
        // Brand & Telemetry Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.rhinobank_crest_1794737708019),
                    contentDescription = "RhinoBank Logo",
                    modifier = Modifier.size(28.dp).clip(RoundedCornerShape(6.dp))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("RHINOBANK", style = MaterialTheme.typography.titleLarge, color = IvoryHeading)
                        Text("  |  CUSTOM RESERVE NOTES", style = MonoFinancialSmall, color = SlateMuted)
                    }
                    Text(
                        text = "${state.valuationTimestampUtc}  •  ${state.operatorEmail}",
                        style = MonoFinancialSmall,
                        color = SlateMuted
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                StatusBadge(text = "TESTNET / SIM", color = CyanSelected)
                IconButton(
                    onClick = onOpenCompare,
                    modifier = Modifier.size(48.dp).testTag("header_compare_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = "Compare configurations", tint = CyanSelected)
                }
                IconButton(
                    onClick = onOpenAi,
                    modifier = Modifier.size(48.dp).testTag("header_ai_button")
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = "AI Structuring Assistant", tint = ChampagneGold)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ElevatedSlatePanel)
                        .border(1.dp, PlatinumDivider, RoundedCornerShape(4.dp))
                        .clickable(onClick = onCycleDensity)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(state.densityMode.label, style = MonoFinancialSmall, color = PlatinumText)
                }
                IconButton(
                    onClick = onSignOut,
                    modifier = Modifier.size(48.dp).testTag("sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Sign out", tint = SlateMuted)
                }
            }
        }

        // 12-Section Institutional Navigation Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ObsidianVoid.copy(alpha = 0.7f))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TerminalSection.entries.forEach { section ->
                val selected = state.activeSection == section
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (selected) ChampagneGoldMuted else ObsidianVoid)
                        .border(
                            width = if (selected) 1.dp else 0.5.dp,
                            color = if (selected) ChampagneGold else SubtleGridLine,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { onSelectSection(section) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("nav_${section.name.lowercase()}")
                ) {
                    Text(
                        text = section.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) ChampagneGold else PlatinumText,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomLedgerPanel(
    state: TerminalUiState,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    onSelectTab: (BottomLedgerTab) -> Unit
) {
    Surface(
        color = MidnightPanel,
        border = BorderStroke(1.dp, PlatinumDivider),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ElevatedSlatePanel)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    BottomLedgerTab.entries.forEach { tab ->
                        val active = state.bottomTab == tab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (active) ChampagneGoldMuted else ObsidianVoid)
                                .border(1.dp, if (active) ChampagneGold else PlatinumDivider, RoundedCornerShape(4.dp))
                                .clickable { onSelectTab(tab) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("bottom_tab_${tab.name.lowercase()}")
                        ) {
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (active) ChampagneGold else PlatinumText
                            )
                        }
                    }
                }
                IconButton(
                    onClick = onToggleExpand,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Filled.ExpandMore else Icons.Filled.ExpandLess,
                        contentDescription = if (expanded) "Collapse ledger" else "Expand ledger",
                        tint = PlatinumText
                    )
                }
            }

            if (expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    when (state.bottomTab) {
                        BottomLedgerTab.CASH_FLOWS -> {
                            state.cashFlows.forEach { row ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(row.eventName, style = MaterialTheme.typography.bodySmall, color = IvoryHeading, modifier = Modifier.weight(1f))
                                    Text(row.amountDisplay, style = MonoFinancialSmall, color = CyanSelected, modifier = Modifier.weight(1.2f))
                                    Text(
                                        text = row.stateLabel,
                                        style = MonoFinancialSmall,
                                        color = if (row.isWarning) AmberException else PlatinumText,
                                        modifier = Modifier.weight(1.2f)
                                    )
                                }
                            }
                        }
                        BottomLedgerTab.FUNDING -> {
                            val t = state.treasuryPosition
                            Text("Model: ${state.noteStructure.fundingModel.label}  •  Proceeds: ${formatUsd(t.subscriptionProceedsUsd)}  •  Buffer: ${formatUsd(t.liquidBufferUsd)}  •  FX Mismatch: ${formatUsd(t.fxMismatchUsd)}", style = MonoFinancialSmall, color = CyanSelected)
                        }
                        BottomLedgerTab.REGISTRY_EVENTS -> {
                            state.registryEvents.take(2).forEach { ev ->
                                Text("${ev.eventId} [${ev.status.label}] ${ev.eventType} • #${ev.blockHeight} • ${ev.documentCommitmentSha256}", style = MonoFinancialSmall, color = PlatinumText)
                            }
                        }
                        BottomLedgerTab.AUDIT -> {
                            state.auditLog.take(2).forEach { a ->
                                Text("${a.id} ${a.action} (${a.actor}) — ${a.detail}", style = MonoFinancialSmall, color = SlateMuted)
                            }
                        }
                    }
                }
            }
        }
    }
}
