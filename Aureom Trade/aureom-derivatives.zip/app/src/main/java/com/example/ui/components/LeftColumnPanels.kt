package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.OpenInNew
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ApprovalStatus
import com.example.domain.model.Instrument
import com.example.domain.model.ReportingCurrency
import com.example.ui.theme.CyanBright
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.InputSurface
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.RowSelected
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.formatCurrency

@Composable
fun InstrumentExplorerCard(
    instruments: List<Instrument>,
    selectedInstrumentId: String,
    searchQuery: String,
    currency: ReportingCurrency,
    onSearchChange: (String) -> Unit,
    onSelectInstrument: (String) -> Unit,
    onOpenStructureImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val filtered = instruments.filter { inst ->
        if (searchQuery.isBlank()) true
        else {
            val q = searchQuery.trim().lowercase()
            inst.explorerCode.lowercase().contains(q) ||
                inst.displayName.lowercase().contains(q) ||
                inst.shortName.lowercase().contains(q) ||
                inst.ticker.lowercase().contains(q) ||
                inst.productType.displayLabel.lowercase().contains(q)
        }
    }

    AureomPanel(modifier = modifier) {
        PanelHeaderRow(
            title = "Instrument Explorer",
            trailing = {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable(onClick = onOpenStructureImport)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                        .testTag("open_structure_import_button"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AddCircleOutline,
                        contentDescription = "Import from Aureom Structure",
                        tint = CyanPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Structure",
                        style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary)
                    )
                }
            }
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Search input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(InputSurface)
                .border(1.dp, SteelBorder, RoundedCornerShape(5.dp))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.Search,
                contentDescription = "Search instruments",
                tint = TextMuted,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (searchQuery.isEmpty()) {
                    Text(
                        text = "Search instruments (e.g. HCB, swap, cap)...",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                    cursorBrush = SolidColor(CyanPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("explorer_search_input")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Instrument",
                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Indicative premium",
                    style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = "Indicative model values only",
                    tint = TextMuted,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)
        Spacer(modifier = Modifier.height(4.dp))

        // Instrument rows
        filtered.forEach { inst ->
            val selected = inst.id == selectedInstrumentId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (selected) RowSelected else Color.Transparent)
                    .then(
                        if (selected) Modifier.border(1.dp, CyanPrimary, RoundedCornerShape(5.dp))
                        else Modifier
                    )
                    .clickable { onSelectInstrument(inst.id) }
                    .padding(horizontal = 8.dp, vertical = 8.dp)
                    .testTag("instrument_row_${inst.id}"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = inst.explorerCode,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (selected) TextPrimary else TextPrimary.copy(alpha = 0.9f),
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!inst.tradingPermissionEnabled) {
                        Text(
                            text = "Discoverable only • Permission off",
                            style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber, fontSize = 9.sp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (inst.isStaleModel) "STALE" else formatCurrency(inst.indicativeModelValue, currency),
                    style = MonoTextStyle.copy(
                        color = if (inst.isStaleModel) WarningAmber else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    textAlign = TextAlign.End
                )
            }
            if (!selected) {
                HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Indicative model values for synthetic instruments. Not executable prices.",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontStyle = FontStyle.Italic,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
fun ContractSnapshotCard(
    instrument: Instrument,
    currency: ReportingCurrency,
    onViewApprovedTerms: () -> Unit,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(
            title = "Contract Snapshot",
            trailing = {
                if (instrument.approvalStatus != ApprovalStatus.APPROVED || !instrument.tradingPermissionEnabled) {
                    StatusPill(
                        label = if (!instrument.tradingPermissionEnabled) "No Exec Perm" else instrument.approvalStatus.label,
                        color = WarningAmber
                    )
                }
            }
        )
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = instrument.shortName.let {
                if (instrument.id == "INST-HCB-CALL-MAR27") "Home Care Basket call" else instrument.shortName
            },
            style = MaterialTheme.typography.titleSmall.copy(
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = instrument.styleSubtitle,
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
        )
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)
        Spacer(modifier = Modifier.height(6.dp))

        KeyValueRow(
            label = if (instrument.productType.name.contains("SWAP")) "Fixed rate" else "Strike",
            value = "${instrument.strikeOrFixedRate} ${instrument.strikeUnitLabel}",
            isMono = true
        )
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        KeyValueRow(
            label = "Expiry",
            value = instrument.expiryDisplay,
            isMono = false
        )
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        KeyValueRow(
            label = "Multiplier",
            value = "${formatCurrency(instrument.contractMultiplier, currency)} / point",
            isMono = true
        )
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        KeyValueRow(
            label = "Contract version",
            value = instrument.contractVersion,
            isMono = true
        )
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable(onClick = onViewApprovedTerms)
                    .padding(vertical = 4.dp)
                    .testTag("view_approved_terms_link"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "View approved terms",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = CyanBright,
                        fontWeight = FontWeight.SemiBold
                    )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.OpenInNew,
                    contentDescription = "Open approved term sheet",
                    tint = CyanBright,
                    modifier = Modifier.size(13.dp)
                )
            }
            Text(
                text = "Origin: ${instrument.origin}",
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
            )
        }
    }
}
