package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DealerQuote
import com.example.domain.model.Instrument
import com.example.domain.model.PayoffPoint
import com.example.domain.model.QuoteStatus
import com.example.domain.model.ReportingCurrency
import com.example.domain.model.ValuationPoint
import com.example.ui.theme.CyanBright
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLeaf
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.RowSelected
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.formatCurrency
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun SelectedInstrumentHeaderCard(
    instrument: Instrument,
    currency: ReportingCurrency,
    onRevalueShift: (BigDecimal) -> Unit,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = instrument.displayName,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${instrument.ticker} • ${instrument.underlyingRef} • Ref ${instrument.currentReferenceIndex}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = PanelElevated,
                        border = BorderStroke(1.dp, SteelBorder),
                        modifier = Modifier
                            .testTag("revalue_down_btn")
                            .clickable { onRevalueShift(BigDecimal("-1.00")) }
                    ) {
                        Text(
                            text = "Ref -1.00",
                            style = MonoTextStyle.copy(color = TextSecondary, fontSize = 10.sp),
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = PanelElevated,
                        border = BorderStroke(1.dp, SteelBorder),
                        modifier = Modifier
                            .testTag("revalue_up_btn")
                            .clickable { onRevalueShift(BigDecimal("1.00")) }
                    ) {
                        Text(
                            text = "Ref +1.00",
                            style = MonoTextStyle.copy(color = CyanPrimary, fontSize = 10.sp),
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                if (instrument.isStaleModel) {
                    Text(
                        text = "STALE INPUTS",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = WarningAmber,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Valuation suspended (${instrument.modelVersion})",
                        style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber)
                    )
                } else {
                    Text(
                        text = formatCurrency(instrument.indicativeModelValue, currency),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            color = TextPrimary,
                            fontSize = 24.sp
                        ),
                        modifier = Modifier.testTag("selected_instrument_model_value")
                    )
                    Text(
                        text = "Indicative ${instrument.priceBasis.label.lowercase()}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    Text(
                        text = "Model updated ${instrument.modelUpdatedUtc} • ${instrument.modelVersion}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }
            }
        }
    }
}

@Composable
fun IndicativePremiumHistoryChart(
    series: List<ValuationPoint>,
    currency: ReportingCurrency,
    isStale: Boolean,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(
            title = "Indicative Premium History",
            trailing = {
                if (isStale) {
                    StatusPill(label = "Stale Feed", color = WarningAmber)
                } else {
                    Text(
                        text = "Model marks (non-executable)",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }
            }
        )
        Spacer(modifier = Modifier.height(10.dp))

        if (series.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No historical observations recorded yet.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                )
            }
        } else {
            val values = series.map { it.value.toFloat() }
            val rawMin = values.minOrNull() ?: 0f
            val rawMax = values.maxOrNull() ?: 1f
            val pad = ((rawMax - rawMin) * 0.18f).coerceAtLeast(250f)
            val yMin = ((rawMin - pad) / 1000f).toInt() * 1000f
            val yMax = (((rawMax + pad) / 1000f).toInt() + 1) * 1000f
            val yMid1 = yMin + (yMax - yMin) * 0.33f
            val yMid2 = yMin + (yMax - yMin) * 0.66f

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                // Y-Axis Labels
                Column(
                    modifier = Modifier
                        .width(58.dp)
                        .height(140.dp)
                        .padding(end = 6.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.End
                ) {
                    listOf(yMax, yMid2, yMid1, yMin).forEach { tick ->
                        Text(
                            text = formatCurrency(BigDecimal.valueOf(tick.toDouble()), currency),
                            style = MonoTextStyle.copy(color = TextSecondary, fontSize = 10.sp)
                        )
                    }
                }

                // Chart Canvas
                Box(modifier = Modifier.weight(1f).height(140.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val range = (yMax - yMin).coerceAtLeast(1f)

                        // Horizontal gridlines
                        listOf(0f, 0.33f, 0.66f, 1f).forEach { frac ->
                            val y = h * frac
                            drawLine(
                                color = SteelDivider,
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Vertical gridlines
                        listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
                            val x = w * frac
                            drawLine(
                                color = SteelDivider.copy(alpha = 0.7f),
                                start = Offset(x, 0f),
                                end = Offset(x, h),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        val linePath = Path()
                        val areaPath = Path()
                        val count = values.size

                        values.forEachIndexed { i, v ->
                            val x = if (count == 1) w / 2f else (i.toFloat() / (count - 1)) * w
                            val normY = ((v - yMin) / range).coerceIn(0f, 1f)
                            val y = h - (normY * h)
                            if (i == 0) {
                                linePath.moveTo(x, y)
                                areaPath.moveTo(x, h)
                                areaPath.lineTo(x, y)
                            } else {
                                linePath.lineTo(x, y)
                                areaPath.lineTo(x, y)
                            }
                            if (i == count - 1) {
                                areaPath.lineTo(x, h)
                                areaPath.close()
                            }
                        }

                        val lineColor = if (isStale) WarningAmber else CyanPrimary
                        drawPath(
                            path = areaPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    lineColor.copy(alpha = 0.32f),
                                    lineColor.copy(alpha = 0.02f)
                                )
                            )
                        )
                        drawPath(
                            path = linePath,
                            color = lineColor,
                            style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 58.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("10 Nov", "11 Nov", "12 Nov", "13 Nov", "14 Nov").forEach { lbl ->
                    Text(
                        text = lbl,
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                }
            }
        }
    }
}

@Composable
fun DealerRfqsPanel(
    quotes: List<DealerQuote>,
    selectedQuoteId: String?,
    serverNowMillis: Long,
    currency: ReportingCurrency,
    onSelectQuote: (DealerQuote) -> Unit,
    onForceExpireTop: () -> Unit,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(
            title = "Dealer RFQs",
            trailing = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (quotes.any { it.status == QuoteStatus.FIRM_ACTIVE }) {
                        Text(
                            text = "Expire top",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = WarningAmber,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable(onClick = onForceExpireTop)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                .testTag("force_expire_quote_button")
                        )
                    }
                    AureomBadge(text = "Simulation")
                }
            }
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dealer",
                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary),
                modifier = Modifier.weight(1.3f)
            )
            Text(
                text = "Bid",
                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary),
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
            )
            Text(
                text = "Ask",
                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary),
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
            )
            Text(
                text = "Valid for",
                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary),
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.75f)
            )
        }
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)

        if (quotes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 22.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No dealer quotes yet — request an RFQ on the right ticket.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                )
            }
        } else {
            quotes.take(5).forEach { quote ->
                val isSelected = quote.id == selectedQuoteId
                val remainingSec = ((quote.expiresAtMillis - serverNowMillis) / 1000L).coerceAtLeast(0L)
                val isExpired = quote.status == QuoteStatus.EXPIRED || remainingSec <= 0L
                val statusTag = when {
                    quote.status == QuoteStatus.ACCEPTED -> "ACCEPTED"
                    quote.status == QuoteStatus.SUPERSEDED -> "SUPERSEDED"
                    quote.status == QuoteStatus.DECLINED -> "DECLINED"
                    isExpired -> "EXPIRED"
                    else -> String.format("%02d:%02d", remainingSec / 60L, remainingSec % 60L)
                }
                val timerColor = when {
                    quote.status == QuoteStatus.ACCEPTED -> PositiveGreen
                    isExpired || quote.status == QuoteStatus.DECLINED -> NegativeCoral
                    remainingSec <= 10L -> WarningAmber
                    else -> TextPrimary
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) RowSelected else Color.Transparent)
                        .then(
                            if (isSelected) Modifier.border(1.dp, CyanPrimary, RoundedCornerShape(4.dp))
                            else Modifier
                        )
                        .clickable { onSelectQuote(quote) }
                        .padding(horizontal = 4.dp, vertical = 7.dp)
                        .testTag("dealer_quote_row_${quote.id}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Text(
                            text = quote.counterpartyName,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isExpired) TextMuted else TextPrimary,
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = if (quote.isFirm) "Firm v${quote.version}" else "Indicative",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                        )
                    }
                    Text(
                        text = formatCurrency(quote.bidPrice, currency),
                        style = MonoTextStyle.copy(
                            color = if (isExpired) TextMuted else TextPrimary,
                            fontSize = 11.sp
                        ),
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.9f)
                    )
                    Text(
                        text = formatCurrency(quote.askPrice, currency),
                        style = MonoTextStyle.copy(
                            color = if (isExpired) TextMuted else CyanBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.9f)
                    )
                    Text(
                        text = statusTag,
                        style = MonoTextStyle.copy(
                            color = timerColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.75f)
                    )
                }
                HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Quotes subject to counterparty eligibility. Click a firm quote to review in ticket.",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontStyle = FontStyle.Italic,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
fun ExpiryPayoffChart(
    instrument: Instrument,
    payoffCurve: List<PayoffPoint>,
    showNetOverlay: Boolean,
    onToggleNetOverlay: () -> Unit,
    currency: ReportingCurrency,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(
            title = "Expiry Payoff",
            trailing = {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (showNetOverlay) CyanPrimary.copy(alpha = 0.15f) else PanelElevated,
                    border = BorderStroke(1.dp, if (showNetOverlay) CyanPrimary else SteelBorder),
                    modifier = Modifier
                        .testTag("toggle_net_payoff_button")
                        .clickable(onClick = onToggleNetOverlay)
                ) {
                    Text(
                        text = if (showNetOverlay) "Gross + Net" else "Gross only",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (showNetOverlay) CyanPrimary else TextSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (showNetOverlay) "Cyan: Gross payoff • Green: Net profit after premium & fees"
            else "Gross payoff • Excludes premium (K=${instrument.strikeOrFixedRate}, M=${formatCurrency(instrument.contractMultiplier, currency)})",
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 10.sp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (payoffCurve.isNotEmpty()) {
            val allY = if (showNetOverlay) {
                payoffCurve.flatMap { listOf(it.grossPayoff.toFloat(), it.netProfitAfterPremium.toFloat()) }
            } else {
                payoffCurve.map { it.grossPayoff.toFloat() }
            }
            val minY = minOf(0f, allY.minOrNull() ?: 0f)
            val maxY = maxOf(10_000f, allY.maxOrNull() ?: 100_000f)
            val rangeY = (maxY - minY).coerceAtLeast(1f)
            val minX = payoffCurve.first().referenceIndex.toFloat()
            val maxX = payoffCurve.last().referenceIndex.toFloat()
            val strikeX = instrument.strikeOrFixedRate.toFloat()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(135.dp)
            ) {
                Column(
                    modifier = Modifier
                        .width(62.dp)
                        .height(135.dp)
                        .padding(end = 6.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.End
                ) {
                    val midY = minY + rangeY * 0.5f
                    listOf(maxY, midY, minY).forEach { yVal ->
                        Text(
                            text = formatCurrency(BigDecimal.valueOf(yVal.toDouble()), currency),
                            style = MonoTextStyle.copy(color = TextSecondary, fontSize = 10.sp)
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f).height(135.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Zero baseline
                        val zeroFrac = ((0f - minY) / rangeY).coerceIn(0f, 1f)
                        val zeroY = h - zeroFrac * h
                        drawLine(
                            color = SteelBorder,
                            start = Offset(0f, zeroY),
                            end = Offset(w, zeroY),
                            strokeWidth = 1.dp.toPx()
                        )
                        listOf(0.25f, 0.5f, 0.75f).forEach { f ->
                            drawLine(
                                color = SteelDivider,
                                start = Offset(0f, h * f),
                                end = Offset(w, h * f),
                                strokeWidth = 0.8.dp.toPx()
                            )
                        }

                        // Strike vertical dashed line
                        val strikeFrac = ((strikeX - minX) / (maxX - minX).coerceAtLeast(0.01f)).coerceIn(0f, 1f)
                        val strikePx = strikeFrac * w
                        drawLine(
                            color = TextPrimary.copy(alpha = 0.75f),
                            start = Offset(strikePx, 0f),
                            end = Offset(strikePx, h),
                            strokeWidth = 1.3.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
                        )

                        // Gross payoff path
                        val grossPath = Path()
                        val netPath = Path()
                        val n = payoffCurve.size
                        payoffCurve.forEachIndexed { idx, pt ->
                            val x = (idx.toFloat() / (n - 1).coerceAtLeast(1)) * w
                            val gy = h - (((pt.grossPayoff.toFloat() - minY) / rangeY).coerceIn(0f, 1f) * h)
                            val ny = h - (((pt.netProfitAfterPremium.toFloat() - minY) / rangeY).coerceIn(0f, 1f) * h)
                            if (idx == 0) {
                                grossPath.moveTo(x, gy)
                                netPath.moveTo(x, ny)
                            } else {
                                grossPath.lineTo(x, gy)
                                netPath.lineTo(x, ny)
                            }
                        }

                        drawPath(
                            path = grossPath,
                            color = CyanPrimary,
                            style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
                        )
                        if (showNetOverlay) {
                            drawPath(
                                path = netPath,
                                color = EmeraldLeaf,
                                style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }

                    Text(
                        text = "Strike ${instrument.strikeOrFixedRate}",
                        style = MonoTextStyle.copy(color = TextPrimary, fontSize = 10.sp),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 2.dp)
                            .background(PanelElevated.copy(alpha = 0.85f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 62.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val midIdx = payoffCurve.size / 2
                listOf(payoffCurve.first(), payoffCurve[midIdx], payoffCurve.last()).forEach { pt ->
                    Text(
                        text = pt.referenceIndex.setScale(0, RoundingMode.HALF_UP).toPlainString(),
                        style = MonoTextStyle.copy(color = TextSecondary, fontSize = 10.sp)
                    )
                }
            }
            Text(
                text = "Reference index",
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
