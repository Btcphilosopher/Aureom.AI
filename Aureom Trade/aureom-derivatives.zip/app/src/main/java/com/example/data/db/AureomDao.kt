package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AureomDao {
    @Query("SELECT * FROM instruments ORDER BY id ASC")
    fun observeInstruments(): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments ORDER BY id ASC")
    suspend fun getInstrumentsSnapshot(): List<InstrumentEntity>

    @Query("SELECT * FROM instruments WHERE id = :id LIMIT 1")
    suspend fun getInstrumentById(id: String): InstrumentEntity?

    @Query("SELECT COUNT(*) FROM instruments")
    suspend fun countInstruments(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInstruments(items: List<InstrumentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertInstrument(item: InstrumentEntity)

    @Query("SELECT * FROM rfqs WHERE organisationId = :orgId ORDER BY createdAtMillis DESC")
    fun observeRfqs(orgId: String): Flow<List<RfqEntity>>

    @Query("SELECT * FROM rfqs WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getRfqByIdempotencyKey(key: String): RfqEntity?

    @Query("SELECT * FROM rfqs WHERE id = :id LIMIT 1")
    suspend fun getRfqById(id: String): RfqEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRfqs(items: List<RfqEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRfq(item: RfqEntity)

    @Query("SELECT * FROM dealer_quotes ORDER BY createdAtMillis DESC, version DESC")
    fun observeQuotes(): Flow<List<DealerQuoteEntity>>

    @Query("SELECT * FROM dealer_quotes")
    suspend fun getQuotesSnapshot(): List<DealerQuoteEntity>

    @Query("SELECT * FROM dealer_quotes WHERE id = :id LIMIT 1")
    suspend fun getQuoteById(id: String): DealerQuoteEntity?

    @Query("SELECT * FROM dealer_quotes WHERE rfqId = :rfqId")
    suspend fun getQuotesForRfq(rfqId: String): List<DealerQuoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertQuotes(items: List<DealerQuoteEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertQuote(item: DealerQuoteEntity)

    @Query("SELECT * FROM trades WHERE organisationId = :orgId ORDER BY executedAtMillis DESC")
    fun observeTrades(orgId: String): Flow<List<TradeEntity>>

    @Query("SELECT * FROM trades WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getTradeByIdempotencyKey(key: String): TradeEntity?

    @Query("SELECT * FROM trades WHERE id = :id LIMIT 1")
    suspend fun getTradeById(id: String): TradeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrades(items: List<TradeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrade(item: TradeEntity)

    @Query("SELECT * FROM positions WHERE organisationId = :orgId ORDER BY id DESC")
    fun observePositions(orgId: String): Flow<List<PositionEntity>>

    @Query("SELECT * FROM positions WHERE tradeId = :tradeId LIMIT 1")
    suspend fun getPositionByTradeId(tradeId: String): PositionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPositions(items: List<PositionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPosition(item: PositionEntity)

    @Query("SELECT * FROM cash_flows WHERE organisationId = :orgId ORDER BY dueDate ASC")
    fun observeCashFlows(orgId: String): Flow<List<CashFlowEntity>>

    @Query("SELECT * FROM cash_flows WHERE id = :id LIMIT 1")
    suspend fun getCashFlowById(id: String): CashFlowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCashFlows(items: List<CashFlowEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCashFlow(item: CashFlowEntity)

    @Query("SELECT * FROM collateral_agreements WHERE organisationId = :orgId")
    fun observeCollateralAgreements(orgId: String): Flow<List<CollateralAgreementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCollateralAgreements(items: List<CollateralAgreementEntity>)

    @Query("SELECT * FROM collateral_movements WHERE organisationId = :orgId ORDER BY timestampMillis DESC")
    fun observeCollateralMovements(orgId: String): Flow<List<CollateralMovementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCollateralMovements(items: List<CollateralMovementEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCollateralMovement(item: CollateralMovementEntity)

    @Query("SELECT * FROM settlement_events WHERE organisationId = :orgId ORDER BY dateIso ASC")
    fun observeSettlementEvents(orgId: String): Flow<List<SettlementEventEntity>>

    @Query("SELECT * FROM settlement_events WHERE id = :id LIMIT 1")
    suspend fun getSettlementEventById(id: String): SettlementEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettlementEvents(items: List<SettlementEventEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettlementEvent(item: SettlementEventEntity)

    @Query("SELECT * FROM audit_logs WHERE organisationId = :orgId ORDER BY timestampMillis DESC LIMIT 200")
    fun observeAuditLogs(orgId: String): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(entry: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLogs(entries: List<AuditLogEntity>)

    @Query("SELECT * FROM workspace_layouts")
    fun observeLayouts(): Flow<List<WorkspaceLayoutEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLayout(layout: WorkspaceLayoutEntity)

    @Transaction
    suspend fun commitAcceptedQuoteTransaction(
        rfq: RfqEntity,
        acceptedQuote: DealerQuoteEntity,
        supersededQuotes: List<DealerQuoteEntity>,
        trade: TradeEntity,
        position: PositionEntity,
        cashFlow: CashFlowEntity,
        settlementEvent: SettlementEventEntity,
        auditLog: AuditLogEntity
    ) {
        upsertRfq(rfq)
        upsertQuote(acceptedQuote)
        if (supersededQuotes.isNotEmpty()) upsertQuotes(supersededQuotes)
        upsertTrade(trade)
        upsertPosition(position)
        upsertCashFlow(cashFlow)
        upsertSettlementEvent(settlementEvent)
        insertAuditLog(auditLog)
    }
}
