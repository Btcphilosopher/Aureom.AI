package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BottomWorkspaceTab
import com.example.domain.model.CashFlowObligation
import com.example.domain.model.Position
import com.example.domain.model.ReportingCurrency
import com.example.domain.model.RfqRequest
import com.example.domain.model.RfqStatus
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.Trade
import com.example.domain.model.TradeDirection
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.formatCurrency
import com.example.ui.viewmodel.formatSignedCurrency
import java.math.BigDecimal

@Composable
fun BottomPositionsAndOpsCard(
    selectedTab: BottomWorkspaceTab,
    onSelectTab: (BottomWorkspaceTab) -> Unit,
    positions: List<Position>,
    rfqs: List<RfqRequest>,
    trades: List<Trade>,
    cashFlows: List<CashFlowObligation>,
    currency: ReportingCurrency,
    onCancelRfq: (String) -> Unit,
    onAdvanceCashFlow: (String, SettlementState) -> Unit,
    modifier: Modifier = Modifier
) {
    val openRfqCount = rfqs.count { it.status == RfqStatus.QUOTES_RECEIVED || it.status == RfqStatus.QUOTING }

    AureomPanel(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomWorkspaceTab.entries.forEach { tab ->
                val label = if (tab == BottomWorkspaceTab.OPEN_RFQS) {
                    "Open RFQs ($openRfqCount)"
                } else tab.label
                AureomNavTabChip(
                    label = label,
                    selected = tab == selectedTab,
                    onClick = { onSelectTab(tab) },
                    testTag = "bottom_tab_${tab.name.lowercase()}"
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)
        Spacer(modifier = Modifier.height(6.dp))

        when (selectedTab) {
            BottomWorkspaceTab.POSITIONS -> {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Instrument", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), modifier = Modifier.weight(1.4f))
                    Text("Direction", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), modifier = Modifier.weight(1.1f))
                    Text("Contracts", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                    Text("Model value", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), textAlign = TextAlign.End, modifier = Modifier.weight(0.95f))
                    Text("Unrealised P&L", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                    Text("Status", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), textAlign = TextAlign.End, modifier = Modifier.weight(0.7f))
                }
                HorizontalDivider(thickness = 1.dp, color = SteelDivider)
                positions.forEach { pos ->
                    val dirColor = when (pos.direction) {
                        TradeDirection.RECEIVE_FLOATING_PAY_FIXED, TradeDirection.PAY_FLOATING_RECEIVE_FIXED -> CyanPrimary
                        TradeDirection.BUY_OPTION, TradeDirection.BUY_SPREAD -> PositiveGreen
                        else -> NegativeCoral
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 7.dp)
                            .testTag("position_row_${pos.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.4f)) {
                            Text(
                                text = "${pos.instrumentShortName} (${pos.contractVersion})",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.Medium),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${pos.counterpartyName} • Exp ${pos.expiryDate}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                            )
                        }
                        Text(
                            text = pos.direction.positionLabel,
                            style = MaterialTheme.typography.bodySmall.copy(color = dirColor, fontWeight = FontWeight.Medium),
                            modifier = Modifier.weight(1.1f)
                        )
                        Text(
                            text = pos.quantity.toString(),
                            style = MonoTextStyle.copy(color = TextPrimary, fontSize = 12.sp),
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(0.75f)
                        )
                        Text(
                            text = if (pos.isValuationStale) "STALE" else formatCurrency(pos.totalModelValue, currency),
                            style = MonoTextStyle.copy(
                                color = if (pos.isValuationStale) WarningAmber else TextPrimary,
                                fontSize = 12.sp
                            ),
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(0.95f)
                        )
                        Text(
                            text = if (pos.isValuationStale) "--" else formatSignedCurrency(pos.unrealisedPnl, currency),
                            style = MonoTextStyle.copy(
                                color = if (pos.unrealisedPnl >= BigDecimal.ZERO) PositiveGreen else NegativeCoral,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            ),
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(1f)
                        )
                        Row(modifier = Modifier.weight(0.7f), horizontalArrangement = Arrangement.End) {
                            StatusPill(
                                label = pos.lifecycleStatus,
                                color = if (pos.lifecycleStatus == "Open") CyanPrimary else PositiveGreen
                            )
                        }
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
                }
            }

            BottomWorkspaceTab.OPEN_RFQS -> {
                rfqs.forEach { rfq ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${rfq.id} • ${rfq.instrumentShortName} (${rfq.contractVersion})",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "${rfq.direction.label} • ${rfq.quantity} contracts • ${rfq.requestedTerms}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            StatusPill(
                                label = rfq.status.label,
                                color = when (rfq.status) {
                                    RfqStatus.ACCEPTED -> PositiveGreen
                                    RfqStatus.EXPIRED, RfqStatus.CANCELLED, RfqStatus.DECLINED -> NegativeCoral
                                    else -> CyanPrimary
                                }
                            )
                            if (rfq.status == RfqStatus.QUOTES_RECEIVED || rfq.status == RfqStatus.QUOTING) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = PanelElevated,
                                    border = BorderStroke(1.dp, SteelBorder),
                                    modifier = Modifier.clickable { onCancelRfq(rfq.id) }
                                ) {
                                    Text(
                                        text = "Cancel",
                                        style = MaterialTheme.typography.labelSmall.copy(color = NegativeCoral),
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
                }
            }

            BottomWorkspaceTab.TRADES -> {
                trades.forEach { trd ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${trd.id} • ${trd.instrumentShortName} (${trd.contractVersion})",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "${trd.direction.positionLabel} ${trd.quantity} @ ${formatCurrency(trd.executedPricePerContract, currency)} • ${trd.counterpartyName} • ${trd.mode}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }
                        Text(
                            text = formatCurrency(trd.totalConsideration, currency, includeDecimals = true),
                            style = MonoTextStyle.copy(color = CyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
                }
            }

            BottomWorkspaceTab.CASH_FLOWS -> {
                cashFlows.forEach { cf ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${cf.id} • ${cf.instrumentShortName} (${cf.category})",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "Due ${cf.dueDate} • ${cf.counterpartyName} • ${cf.reconciliationRef ?: "Unreconciled"}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = formatCurrency(cf.amount, currency, includeDecimals = true),
                                style = MonoTextStyle.copy(color = TextPrimary, fontSize = 12.sp)
                            )
                            val nextState = when (cf.state) {
                                SettlementState.SCHEDULED -> SettlementState.APPROVED
                                SettlementState.CALCULATED -> SettlementState.APPROVED
                                SettlementState.APPROVED -> SettlementState.INSTRUCTED
                                SettlementState.INSTRUCTED -> SettlementState.PAID
                                SettlementState.PAID -> SettlementState.RECONCILED
                                else -> null
                            }
                            StatusPill(
                                label = cf.state.label,
                                color = if (cf.state == SettlementState.RECONCILED) PositiveGreen else CyanPrimary
                            )
                            if (nextState != null) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = PanelElevated,
                                    border = BorderStroke(1.dp, CyanPrimary),
                                    modifier = Modifier
                                        .testTag("advance_cashflow_${cf.id}")
                                        .clickable { onAdvanceCashFlow(cf.id, nextState) }
                                ) {
                                    Text(
                                        text = nextState.label,
                                        style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                    HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@Composable
fun SettlementCalendarCard(
    events: List<SettlementEvent>,
    onObserveAndSettle: (SettlementEvent, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(title = "Settlement Calendar")
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Date", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), modifier = Modifier.width(68.dp))
            Text("Event", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), modifier = Modifier.weight(1f))
            Text("Status", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary), textAlign = TextAlign.End)
        }
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)

        events.take(5).forEach { evt ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 7.dp)
                    .testTag("settlement_row_${evt.id}"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = evt.displayDate,
                    style = MonoTextStyle.copy(color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium),
                    modifier = Modifier.width(68.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = evt.eventLabel,
                        style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (evt.observedIndex != null) {
                        Text(
                            text = "Fix ${evt.observedIndex} • Payoff $${evt.calculatedPayoff}",
                            style = MonoTextStyle.copy(color = PositiveGreen, fontSize = 9.sp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (evt.eventCategory == "EXPIRY" || evt.eventCategory == "OBSERVATION") {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = PanelElevated,
                            border = BorderStroke(1.dp, SteelBorder),
                            modifier = Modifier.clickable {
                                onObserveAndSettle(evt, evt.observedIndex != null)
                            }
                        ) {
                            Text(
                                text = if (evt.observedIndex == null) "Observe" else "Correct",
                                style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary, fontSize = 9.sp),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    StatusPill(
                        label = evt.state.label,
                        color = when (evt.state) {
                            SettlementState.RECONCILED, SettlementState.PAID -> PositiveGreen
                            SettlementState.DISPUTED, SettlementState.FAILED -> NegativeCoral
                            else -> CyanPrimary
                        }
                    )
                }
            }
            HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        }
    }
}
