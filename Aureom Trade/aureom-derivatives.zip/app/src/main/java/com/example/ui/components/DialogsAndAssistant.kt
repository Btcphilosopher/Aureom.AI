package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.assistant.AssistantIntent
import com.example.data.assistant.AssistantResponse
import com.example.data.assistant.ProposedActionType
import com.example.domain.model.Instrument
import com.example.domain.model.RiskConfiguration
import com.example.domain.model.SettlementEvent
import com.example.ui.theme.CyanDarkText
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelNavy
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.math.BigDecimal

@Composable
fun ApprovedTermsDialog(
    instrument: Instrument,
    onTogglePermission: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelNavy,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Text(
                text = "Approved Term Sheet • ${instrument.termSheetVersion}",
                style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                KeyValueRow("Instrument ID", instrument.id, isMono = true)
                KeyValueRow("Contract Version", instrument.contractVersion, isMono = true)
                KeyValueRow("Origin", instrument.origin)
                KeyValueRow("Approval Status", instrument.approvalStatus.label, valueColor = PositiveGreen)
                KeyValueRow("Effective Date", instrument.effectiveDate, isMono = true)
                KeyValueRow("Expiry Date", instrument.expiryDate, isMono = true)
                KeyValueRow("Calendar / TZ", "${instrument.businessCalendar} • ${instrument.timezoneRule}")
                HorizontalDivider(color = SteelDivider)
                Text("Observation Schedule", style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary))
                Text(instrument.observationSchedule, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                Text("Payment Schedule", style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary))
                Text(instrument.paymentSchedule, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                Text("Settlement Rules", style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary))
                Text(instrument.settlementRules, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                Text("Reference Methodology", style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary))
                Text(instrument.referenceMethodology, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                HorizontalDivider(color = SteelDivider)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Desk Execution Permission", style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                    Switch(
                        checked = instrument.tradingPermissionEnabled,
                        onCheckedChange = onTogglePermission
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = CyanPrimary)
            }
        }
    )
}

@Composable
fun StructureImportDialog(
    onImportValid: (Boolean) -> Unit,
    onImportBroken: () -> Unit,
    onDismiss: () -> Unit
) {
    var grantPerm by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelNavy,
        title = {
            Text(
                text = "Aureom Structure Adapter",
                style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Import approved synthetic instruments from Aureom Structure. Publishing makes instruments discoverable; execution permission is controlled separately.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Grant execution permission on import", style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary))
                    Switch(checked = grantPerm, onCheckedChange = { grantPerm = it })
                }
                Button(
                    onClick = {
                        onImportValid(grantPerm)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = CyanDarkText),
                    modifier = Modifier.fillMaxWidth().testTag("import_v11_call_btn")
                ) {
                    Text("Import HCB Call MAR27 (v1.1)")
                }
                OutlinedButton(
                    onClick = {
                        onImportBroken()
                        onDismiss()
                    },
                    border = BorderStroke(1.dp, NegativeCoral),
                    modifier = Modifier.fillMaxWidth().testTag("import_invalid_def_btn")
                ) {
                    Text("Test Incomplete Definition Rejection", color = NegativeCoral)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = TextSecondary) }
        }
    )
}

@Composable
fun RiskSettingsDialog(
    riskConfig: RiskConfiguration,
    onSave: (Int, BigDecimal, String) -> Unit,
    onDismiss: () -> Unit
) {
    var maxContractsText by remember { mutableStateOf(riskConfig.maxContractsPerOrder.toString()) }
    var thresholdText by remember { mutableStateOf(riskConfig.dualApprovalNotionalThreshold.toPlainString()) }
    var role by remember { mutableStateOf(riskConfig.userRole) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelNavy,
        title = {
            Text("Pre-Trade Risk Limits & SoD", style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = maxContractsText,
                    onValueChange = { maxContractsText = it.filter { c -> c.isDigit() } },
                    label = { Text("Max Contracts Per Ticket") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanPrimary,
                        unfocusedBorderColor = SteelBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
                OutlinedTextField(
                    value = thresholdText,
                    onValueChange = { thresholdText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Dual-Control Approval Threshold (USD)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanPrimary,
                        unfocusedBorderColor = SteelBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("SENIOR_TRADER", "VIEWER").forEach { candidate ->
                        OutlinedButton(
                            onClick = { role = candidate },
                            border = BorderStroke(1.dp, if (role == candidate) CyanPrimary else SteelBorder)
                        ) {
                            Text(candidate, style = MaterialTheme.typography.labelSmall.copy(color = if (role == candidate) CyanPrimary else TextSecondary))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val maxC = maxContractsText.toIntOrNull() ?: 25
                    val thr = thresholdText.toBigDecimalOrNull() ?: BigDecimal("250000")
                    onSave(maxC, thr, role)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = CyanDarkText)
            ) { Text("Apply Limits") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}

@Composable
fun SettlementObservationDialog(
    event: SettlementEvent,
    isCorrection: Boolean,
    onConfirm: (BigDecimal) -> Unit,
    onDismiss: () -> Unit
) {
    var indexText by remember { mutableStateOf(event.observedIndex?.toPlainString() ?: "106.50") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelNavy,
        title = {
            Text(
                text = if (isCorrection) "Correct Reference Observation" else "Record Expiry Observation",
                style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${event.instrumentShortName} • ${event.eventLabel}", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                Text("Calendar: ${event.calendarRule} (${event.timezoneRule})", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                OutlinedTextField(
                    value = indexText,
                    onValueChange = { indexText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Observed Reference Index (I_T)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanPrimary,
                        unfocusedBorderColor = SteelBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val idx = indexText.toBigDecimalOrNull() ?: BigDecimal("106.50")
                    onConfirm(idx)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = CyanDarkText)
            ) {
                Text(if (isCorrection) "Recalculate Corrected Settlement" else "Observe & Calculate Payoff")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}

@Composable
fun DeskAssistantDialog(
    response: AssistantResponse?,
    onSelectIntent: (AssistantIntent) -> Unit,
    onExecuteProposedAction: (AssistantResponse) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelNavy,
        title = {
            Text(
                text = "Aureom Desk Assistant",
                style = MaterialTheme.typography.titleMedium.copy(color = CyanPrimary, fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Uses live quantitative engine functions & cites database records. Never acts without explicit human approval.",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AssistantIntent.entries.forEach { intent ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(PanelElevated, RoundedCornerShape(5.dp))
                                .border(1.dp, SteelBorder, RoundedCornerShape(5.dp))
                                .clickable { onSelectIntent(intent) }
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                                .testTag("assistant_intent_${intent.name.lowercase()}")
                        ) {
                            Text(
                                text = intent.label,
                                style = MaterialTheme.typography.labelMedium.copy(color = TextPrimary)
                            )
                        }
                    }
                }
                if (response != null) {
                    HorizontalDivider(color = SteelDivider)
                    Text(
                        text = response.title,
                        style = MaterialTheme.typography.titleSmall.copy(color = CyanPrimary, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = response.body,
                        style = MonoTextStyle.copy(color = TextPrimary, fontSize = 11.sp, lineHeight = 16.sp)
                    )
                    if (response.citations.isNotEmpty()) {
                        Text(
                            text = "Citations: ${response.citations.joinToString(", ")}",
                            style = MaterialTheme.typography.labelSmall.copy(color = PositiveGreen)
                        )
                    }
                    Text(
                        text = response.warningBanner,
                        style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber)
                    )
                    if (response.proposedActionType != ProposedActionType.NONE && response.proposedActionLabel != null) {
                        Button(
                            onClick = { onExecuteProposedAction(response) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = CyanDarkText),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(response.proposedActionLabel, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = CyanPrimary) }
        }
    )
}
