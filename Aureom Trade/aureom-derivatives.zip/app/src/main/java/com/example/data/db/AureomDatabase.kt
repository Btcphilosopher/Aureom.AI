package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        InstrumentEntity::class,
        RfqEntity::class,
        DealerQuoteEntity::class,
        TradeEntity::class,
        PositionEntity::class,
        CashFlowEntity::class,
        CollateralAgreementEntity::class,
        CollateralMovementEntity::class,
        SettlementEventEntity::class,
        AuditLogEntity::class,
        WorkspaceLayoutEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun aureomDao(): AureomDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getInstance(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_trading_desk.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
