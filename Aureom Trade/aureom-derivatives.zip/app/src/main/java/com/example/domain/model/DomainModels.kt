package com.example.domain.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class TopNavSection(val label: String) {
    MARKETS("Markets"),
    TRADE("Trade"),
    RFQS("RFQs"),
    POSITIONS("Positions"),
    COLLATERAL("Collateral"),
    SETTLEMENT("Settlement"),
    REPORTS("Reports")
}

enum class ProductTab(val label: String) {
    SWAPS("Swaps"),
    OPTIONS("Options"),
    CAPS_AND_FLOORS("Caps & Floors"),
    BASKETS("Baskets"),
    CALENDAR_SPREADS("Calendar Spreads")
}

enum class ProductType(val displayLabel: String) {
    EUROPEAN_CALL("European Call"),
    EUROPEAN_PUT("European Put"),
    FIXED_FLOATING_SWAP("Fixed/Floating Swap"),
    CAP("Interest / Commodity Cap"),
    FLOOR("Interest / Commodity Floor"),
    BASKET_CALL("Basket European Call"),
    CALENDAR_SPREAD("Calendar Spread")
}

enum class PriceBasis(val label: String, val unitSuffix: String) {
    PREMIUM_PER_CONTRACT("Premium per contract", "/ contract"),
    PRICE_PER_UNIT("Price per physical unit", "/ unit"),
    INDEX_POINTS("Index points", "pts"),
    RATE_BPS("Rate / spread", "bps"),
    TOTAL_CONSIDERATION("Total consideration", "total")
}

enum class QuoteKind(val label: String) {
    INDICATIVE_MODEL("Indicative model value"),
    INDICATIVE_DEALER("Indicative dealer interest"),
    FIRM_EXECUTABLE("Firm executable quote"),
    EXECUTED_TRADE("Executed trade price"),
    SETTLEMENT_VALUE("Settlement value")
}

enum class QuoteStatus {
    ACTIVE_INDICATIVE,
    FIRM_ACTIVE,
    ACCEPTED,
    DECLINED,
    SUPERSEDED,
    EXPIRED
}

enum class RfqStatus(val label: String) {
    DRAFT("Draft"),
    SUBMITTED("Submitted"),
    QUOTING("Quoting"),
    QUOTES_RECEIVED("Quotes Received"),
    ACCEPTED("Accepted"),
    DECLINED("Declined"),
    CANCELLED("Cancelled"),
    EXPIRED("Expired")
}

enum class TradeDirection(val label: String, val positionLabel: String) {
    BUY_OPTION("Buy option", "Long"),
    SELL_OPTION("Sell option", "Short"),
    RECEIVE_FLOATING_PAY_FIXED("Receive floating / Pay fixed", "Receive floating"),
    PAY_FLOATING_RECEIVE_FIXED("Pay floating / Receive fixed", "Pay floating"),
    BUY_SPREAD("Buy spread", "Long spread"),
    SELL_SPREAD("Sell spread", "Short spread")
}

enum class ApprovalStatus(val label: String) {
    APPROVED("Approved"),
    PENDING_REVIEW("Pending Review"),
    REJECTED("Rejected"),
    SUSPENDED("Suspended")
}

enum class CheckOutcome(val label: String) {
    PASSED("Passed"),
    FAILED("Failed"),
    PENDING("Pending"),
    NOT_APPLICABLE("Not Applicable")
}

enum class SettlementState(val label: String) {
    SCHEDULED("Scheduled"),
    OBSERVED("Observed"),
    CALCULATED("Calculated"),
    APPROVED("Approved"),
    INSTRUCTED("Instructed"),
    PAID("Paid"),
    RECONCILED("Reconciled"),
    DISPUTED("Disputed"),
    FAILED("Failed")
}

enum class CollateralMovementType(val label: String) {
    POSTED("Posted"),
    RECEIVED("Received"),
    CALL("Margin Call"),
    DISPUTE("Dispute"),
    TRANSFER_SIMULATED("Simulated Transfer"),
    RELEASED("Released")
}

enum class FeedHealth(val label: String) {
    HEALTHY("Stream healthy"),
    STALE("Stale data"),
    RECONNECTING("Reconnecting..."),
    DISCONNECTED("Disconnected")
}

enum class ReportingCurrency(val code: String, val symbol: String, val fxFromUsd: BigDecimal) {
    USD("USD", "$", BigDecimal("1.0000")),
    EUR("EUR", "€", BigDecimal("0.9250")),
    GBP("GBP", "£", BigDecimal("0.7900"))
}

enum class BottomWorkspaceTab(val label: String) {
    POSITIONS("Positions"),
    OPEN_RFQS("Open RFQs"),
    TRADES("Trades"),
    CASH_FLOWS("Cash flows")
}

data class ValuationPoint(
    val label: String,
    val value: BigDecimal,
    val timestampMillis: Long
)

data class PayoffPoint(
    val referenceIndex: BigDecimal,
    val grossPayoff: BigDecimal,
    val netProfitAfterPremium: BigDecimal
)

data class Instrument(
    val id: String,
    val ticker: String,
    val explorerCode: String,
    val displayName: String,
    val shortName: String,
    val contractVersion: String,
    val productType: ProductType,
    val productTab: ProductTab,
    val styleSubtitle: String,
    val underlyingRef: String,
    val currency: String,
    val quantityUnit: String,
    val priceBasis: PriceBasis,
    val contractMultiplier: BigDecimal,
    val strikeOrFixedRate: BigDecimal,
    val strikeUnitLabel: String,
    val effectiveDate: String,
    val expiryDate: String,
    val expiryDisplay: String,
    val observationSchedule: String,
    val paymentSchedule: String,
    val settlementRules: String,
    val businessCalendar: String,
    val timezoneRule: String,
    val tradingPermissionEnabled: Boolean,
    val approvalStatus: ApprovalStatus,
    val termSheetVersion: String,
    val referenceMethodology: String,
    val origin: String,
    val modelVersion: String,
    val indicativeModelValue: BigDecimal,
    val modelInputsTimestampMillis: Long,
    val modelUpdatedUtc: String,
    val currentReferenceIndex: BigDecimal,
    val isStaleModel: Boolean,
    val historicalSeries: List<ValuationPoint>
)

data class Counterparty(
    val id: String,
    val name: String,
    val eligibleProductTypes: Set<ProductType>,
    val creditLimitUsd: BigDecimal,
    val currentExposureUsd: BigDecimal,
    val isPermitted: Boolean,
    val csaAgreementId: String
)

data class RfqRequest(
    val id: String,
    val idempotencyKey: String,
    val organisationId: String,
    val instrumentId: String,
    val instrumentShortName: String,
    val contractVersion: String,
    val direction: TradeDirection,
    val quantity: Int,
    val eligibleCounterpartyIds: List<String>,
    val deadlineMillis: Long,
    val requestedTerms: String,
    val status: RfqStatus,
    val createdAtMillis: Long
)

data class DealerQuote(
    val id: String,
    val rfqId: String,
    val version: Int,
    val counterpartyId: String,
    val counterpartyName: String,
    val direction: TradeDirection,
    val quantity: Int,
    val bidPrice: BigDecimal,
    val askPrice: BigDecimal,
    val priceBasis: PriceBasis,
    val fees: BigDecimal,
    val currency: String,
    val settlementTerms: String,
    val expiresAtMillis: Long,
    val isFirm: Boolean,
    val status: QuoteStatus,
    val createdAtMillis: Long
) {
    fun executablePriceFor(direction: TradeDirection): BigDecimal = when (direction) {
        TradeDirection.BUY_OPTION,
        TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
        TradeDirection.BUY_SPREAD -> askPrice
        TradeDirection.SELL_OPTION,
        TradeDirection.PAY_FLOATING_RECEIVE_FIXED,
        TradeDirection.SELL_SPREAD -> bidPrice
    }
}

data class Trade(
    val id: String,
    val idempotencyKey: String,
    val organisationId: String,
    val rfqId: String,
    val quoteId: String,
    val instrumentId: String,
    val instrumentShortName: String,
    val contractVersion: String,
    val productType: ProductType,
    val direction: TradeDirection,
    val quantity: Int,
    val multiplier: BigDecimal,
    val strikeOrFixedRate: BigDecimal,
    val executedPricePerContract: BigDecimal,
    val priceBasis: PriceBasis,
    val fees: BigDecimal,
    val totalConsideration: BigDecimal,
    val currency: String,
    val counterpartyId: String,
    val counterpartyName: String,
    val paymentDate: String,
    val expiryDate: String,
    val mode: String,
    val executedAtMillis: Long,
    val status: String
)

data class Position(
    val id: String,
    val organisationId: String,
    val tradeId: String,
    val instrumentId: String,
    val instrumentShortName: String,
    val contractVersion: String,
    val productType: ProductType,
    val direction: TradeDirection,
    val quantity: Int,
    val multiplier: BigDecimal,
    val entryPricePerContract: BigDecimal,
    val currentModelValuePerContract: BigDecimal,
    val feesPaid: BigDecimal,
    val realisedPnl: BigDecimal,
    val unrealisedPnl: BigDecimal,
    val paidCashFlows: BigDecimal,
    val unpaidCashFlows: BigDecimal,
    val expiryDate: String,
    val counterpartyName: String,
    val lifecycleStatus: String,
    val isValuationStale: Boolean = false,
    val valuationErrorReason: String? = null
) {
    val totalModelValue: BigDecimal
        get() = currentModelValuePerContract.multiply(BigDecimal(quantity)).setScale(2, RoundingMode.HALF_UP)
}

data class CashFlowObligation(
    val id: String,
    val organisationId: String,
    val tradeId: String,
    val instrumentShortName: String,
    val category: String,
    val amount: BigDecimal,
    val currency: String,
    val dueDate: String,
    val counterpartyName: String,
    val state: SettlementState,
    val reconciliationRef: String?,
    val updatedAtMillis: Long
)

data class CollateralAgreement(
    val id: String,
    val organisationId: String,
    val name: String,
    val counterpartyName: String,
    val eligibleAssets: List<String>,
    val haircutPct: BigDecimal,
    val nettingSetId: String,
    val independentAmount: BigDecimal,
    val variationThreshold: BigDecimal
)

data class CollateralMovement(
    val id: String,
    val organisationId: String,
    val agreementId: String,
    val movementType: CollateralMovementType,
    val assetType: String,
    val grossAmount: BigDecimal,
    val haircutPct: BigDecimal,
    val effectiveValue: BigDecimal,
    val currency: String,
    val isSimulated: Boolean,
    val status: String,
    val timestampMillis: Long,
    val notes: String
)

data class SettlementEvent(
    val id: String,
    val organisationId: String,
    val tradeId: String,
    val dateIso: String,
    val displayDate: String,
    val eventLabel: String,
    val eventCategory: String,
    val instrumentShortName: String,
    val calendarRule: String,
    val timezoneRule: String,
    val observedIndex: BigDecimal?,
    val calculatedPayoff: BigDecimal?,
    val state: SettlementState,
    val notes: String
)

data class PreTradeCheckItem(
    val code: String,
    val label: String,
    val outcome: CheckOutcome,
    val explanation: String
)

data class AuditLogEntry(
    val id: String,
    val organisationId: String,
    val actorRole: String,
    val action: String,
    val entityType: String,
    val entityId: String,
    val details: String,
    val timestampMillis: Long
)

data class WorkspaceLayoutConfig(
    val name: String,
    val showLeftPane: Boolean = true,
    val showRightPane: Boolean = true,
    val showBottomPane: Boolean = true,
    val leftWeight: Float = 0.23f,
    val centerWeight: Float = 0.49f,
    val rightWeight: Float = 0.28f
)

data class PortfolioSummary(
    val totalModelValue: BigDecimal,
    val totalUnrealisedPnl: BigDecimal,
    val totalRealisedPnl: BigDecimal,
    val totalPaidCashFlows: BigDecimal,
    val totalUnpaidCashFlows: BigDecimal,
    val excludedOrUnvaluedCount: Int
)

data class CollateralSummary(
    val postedGross: BigDecimal,
    val postedAfterHaircut: BigDecimal,
    val receivedAfterHaircut: BigDecimal,
    val requiredInitialMargin: BigDecimal,
    val availableCollateral: BigDecimal
)

data class RiskConfiguration(
    val userRole: String = "SENIOR_TRADER",
    val dualApprovalNotionalThreshold: BigDecimal = BigDecimal("250000"),
    val maxContractsPerOrder: Int = 25,
    val organisationId: String = "ORG-AUREOM-01",
    val organisationEligible: Boolean = true,
    val liveExecutionEnabled: Boolean = false
)
