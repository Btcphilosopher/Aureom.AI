package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.TopNavSection
import com.example.ui.theme.CyanDarkText
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.TradingDeskUiState
import com.example.ui.viewmodel.formatCurrency
import com.example.ui.viewmodel.formatSignedCurrency
import java.math.BigDecimal

@Composable
fun SecondarySectionWorkspace(
    section: TopNavSection,
    state: TradingDeskUiState,
    onSelectInstrumentAndTrade: (String) -> Unit,
    onToggleTradingPermission: (String, Boolean) -> Unit,
    onOpenStructureImport: () -> Unit,
    onStageQuoteAndTrade: (com.example.domain.model.DealerQuote) -> Unit,
    onCancelRfq: (String) -> Unit,
    onPostCollateral: (String, BigDecimal, BigDecimal, CollateralMovementType) -> Unit,
    onObserveSettlement: (SettlementEvent, Boolean) -> Unit,
    onAdvanceCashFlow: (String, SettlementState) -> Unit,
    onTestDuplicateAccept: () -> Unit,
    onTestExpiredQuote: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        when (section) {
            TopNavSection.MARKETS -> {
                AureomPanel {
                    PanelHeaderRow(
                        title = "Aureom Structure Instrument Registry",
                        trailing = {
                            OutlinedButton(
                                onClick = onOpenStructureImport,
                                border = BorderStroke(1.dp, CyanPrimary),
                                shape = RoundedCornerShape(5.dp)
                            ) {
                                Text("Import from Structure", style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary))
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    state.instruments.forEach { inst ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${inst.displayName} (${inst.contractVersion})",
                                    style = MaterialTheme.typography.titleSmall.copy(color = TextPrimary, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${inst.ticker} • ${inst.styleSubtitle} • Exp ${inst.expiryDisplay} • ${inst.termSheetVersion}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                )
                                Text(
                                    text = inst.settlementRules,
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = formatCurrency(inst.indicativeModelValue, state.reportingCurrency),
                                    style = MonoTextStyle.copy(color = CyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = PanelElevated,
                                    border = BorderStroke(1.dp, if (inst.tradingPermissionEnabled) PositiveGreen else WarningAmber),
                                    modifier = Modifier.clickable {
                                        onToggleTradingPermission(inst.id, !inst.tradingPermissionEnabled)
                                    }
                                ) {
                                    Text(
                                        text = if (inst.tradingPermissionEnabled) "Exec Enabled" else "Enable Exec",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (inst.tradingPermissionEnabled) PositiveGreen else WarningAmber
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Button(
                                    onClick = { onSelectInstrumentAndTrade(inst.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = CyanDarkText),
                                    shape = RoundedCornerShape(5.dp)
                                ) {
                                    Text("Trade", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider)
                    }
                }
            }

            TopNavSection.RFQS -> {
                AureomPanel {
                    PanelHeaderRow(
                        title = "Dealer RFQ Blotter & Audit History",
                        trailing = {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = onTestExpiredQuote,
                                    border = BorderStroke(1.dp, WarningAmber),
                                    shape = RoundedCornerShape(5.dp)
                                ) {
                                    Text("Test Expiry", style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber))
                                }
                                OutlinedButton(
                                    onClick = onTestDuplicateAccept,
                                    border = BorderStroke(1.dp, NegativeCoral),
                                    shape = RoundedCornerShape(5.dp)
                                ) {
                                    Text("Test Duplicate Accept", style = MaterialTheme.typography.labelSmall.copy(color = NegativeCoral))
                                }
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    state.rfqs.forEach { rfq ->
                        val rfqQuotes = state.quotes.filter { it.rfqId == rfq.id }
                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${rfq.id} • ${rfq.instrumentShortName} (${rfq.contractVersion}) • ${rfq.direction.label} x${rfq.quantity}",
                                    style = MaterialTheme.typography.titleSmall.copy(color = TextPrimary)
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StatusPill(label = rfq.status.label, color = CyanPrimary)
                                    if (rfq.status.name in setOf("QUOTES_RECEIVED", "QUOTING")) {
                                        Text(
                                            text = "Cancel RFQ",
                                            style = MaterialTheme.typography.labelSmall.copy(color = NegativeCoral),
                                            modifier = Modifier
                                                .clickable { onCancelRfq(rfq.id) }
                                                .padding(4.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            rfqQuotes.forEach { q ->
                                val rem = ((q.expiresAtMillis - state.serverNowMillis) / 1000L).coerceAtLeast(0L)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 12.dp, top = 4.dp, bottom = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${q.id} v${q.version} • ${q.counterpartyName} • Bid ${formatCurrency(q.bidPrice, state.reportingCurrency)} / Ask ${formatCurrency(q.askPrice, state.reportingCurrency)} • Fee ${formatCurrency(q.fees, state.reportingCurrency)}",
                                        style = MonoTextStyle.copy(color = TextSecondary, fontSize = 11.sp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        StatusPill(
                                            label = if (q.status.name == "FIRM_ACTIVE" && rem > 0) "${rem}s" else q.status.name,
                                            color = if (q.status.name == "FIRM_ACTIVE" && rem > 0) PositiveGreen else TextMuted
                                        )
                                        if (q.status.name == "FIRM_ACTIVE" && rem > 0) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = CyanPrimary,
                                                modifier = Modifier.clickable { onStageQuoteAndTrade(q) }
                                            ) {
                                                Text(
                                                    text = "Review in Ticket",
                                                    style = MaterialTheme.typography.labelSmall.copy(color = CyanDarkText, fontWeight = FontWeight.Bold),
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider)
                    }
                }
            }

            TopNavSection.POSITIONS -> {
                PortfolioOverviewCard(
                    portfolio = state.portfolioSummary,
                    collateral = state.collateralSummary,
                    currency = state.reportingCurrency
                )
                BottomPositionsAndOpsCard(
                    selectedTab = com.example.domain.model.BottomWorkspaceTab.POSITIONS,
                    onSelectTab = {},
                    positions = state.positions,
                    rfqs = state.rfqs,
                    trades = state.trades,
                    cashFlows = state.cashFlows,
                    currency = state.reportingCurrency,
                    onCancelRfq = onCancelRfq,
                    onAdvanceCashFlow = onAdvanceCashFlow
                )
            }

            TopNavSection.COLLATERAL -> {
                AureomPanel {
                    PanelHeaderRow(
                        title = "Demonstration Collateral Ledger (CSA)",
                        trailing = { AureomBadge(text = "Separate from Portfolio Value") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    KeyValueRow("Posted Gross", formatCurrency(state.collateralSummary.postedGross, state.reportingCurrency, true), isMono = true)
                    KeyValueRow("Posted Effective (After Haircut)", formatCurrency(state.collateralSummary.postedAfterHaircut, state.reportingCurrency, true), isMono = true)
                    KeyValueRow("Required Initial Margin", formatCurrency(state.collateralSummary.requiredInitialMargin, state.reportingCurrency, true), valueColor = WarningAmber, isMono = true)
                    KeyValueRow("Available Collateral", formatCurrency(state.collateralSummary.availableCollateral, state.reportingCurrency, true), valueColor = PositiveGreen, isMono = true)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                onPostCollateral("USD Cash", BigDecimal("15000.00"), BigDecimal.ZERO, CollateralMovementType.TRANSFER_SIMULATED)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = CyanDarkText),
                            shape = RoundedCornerShape(5.dp),
                            modifier = Modifier.testTag("post_sim_cash_collateral_btn")
                        ) {
                            Text("+ Post $15k Sim Cash", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                        OutlinedButton(
                            onClick = {
                                onPostCollateral("US T-Bills <=1Y", BigDecimal("10000.00"), BigDecimal("2.00"), CollateralMovementType.RELEASED)
                            },
                            border = BorderStroke(1.dp, WarningAmber),
                            shape = RoundedCornerShape(5.dp)
                        ) {
                            Text("Release $10k T-Bills", style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber))
                        }
                        OutlinedButton(
                            onClick = {
                                onPostCollateral("USD Cash", BigDecimal("5000.00"), BigDecimal.ZERO, CollateralMovementType.DISPUTE)
                            },
                            border = BorderStroke(1.dp, NegativeCoral),
                            shape = RoundedCornerShape(5.dp)
                        ) {
                            Text("Log Dispute", style = MaterialTheme.typography.labelSmall.copy(color = NegativeCoral))
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(thickness = 1.dp, color = SteelDivider)
                    Spacer(modifier = Modifier.height(6.dp))
                    state.collateralMovements.forEach { mov ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${mov.id} • ${mov.movementType.label} • ${mov.assetType}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = "Haircut ${mov.haircutPct}% • ${mov.notes}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatCurrency(mov.effectiveValue, state.reportingCurrency, true),
                                    style = MonoTextStyle.copy(color = TextPrimary, fontSize = 12.sp)
                                )
                                StatusPill(
                                    label = mov.status,
                                    color = if (mov.status == "Disputed") NegativeCoral else CyanPrimary
                                )
                            }
                        }
                        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
                    }
                }
            }

            TopNavSection.SETTLEMENT -> {
                SettlementCalendarCard(
                    events = state.settlementEvents,
                    onObserveAndSettle = onObserveSettlement
                )
                BottomPositionsAndOpsCard(
                    selectedTab = com.example.domain.model.BottomWorkspaceTab.CASH_FLOWS,
                    onSelectTab = {},
                    positions = state.positions,
                    rfqs = state.rfqs,
                    trades = state.trades,
                    cashFlows = state.cashFlows,
                    currency = state.reportingCurrency,
                    onCancelRfq = onCancelRfq,
                    onAdvanceCashFlow = onAdvanceCashFlow
                )
            }

            TopNavSection.REPORTS -> {
                AureomPanel {
                    PanelHeaderRow(title = "Protected Audit Log & Reconciliation Ledger")
                    Spacer(modifier = Modifier.height(8.dp))
                    KeyValueRow("Total Realised P&L", formatSignedCurrency(state.portfolioSummary.totalRealisedPnl, state.reportingCurrency), isMono = true)
                    KeyValueRow("Paid Cash Flows", formatCurrency(state.portfolioSummary.totalPaidCashFlows, state.reportingCurrency, true), isMono = true)
                    KeyValueRow("Unpaid Cash Flows", formatCurrency(state.portfolioSummary.totalUnpaidCashFlows, state.reportingCurrency, true), isMono = true)
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(thickness = 1.dp, color = SteelDivider)
                    Spacer(modifier = Modifier.height(6.dp))
                    state.auditLogs.take(20).forEach { log ->
                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    text = "${log.action} • ${log.entityType} (${log.entityId})",
                                    style = MonoTextStyle.copy(color = CyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = log.actorRole,
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }
                            Text(
                                text = log.details,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
                    }
                }
            }

            TopNavSection.TRADE -> Unit
        }
    }
}
