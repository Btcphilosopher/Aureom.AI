package com.example.domain.engine

import com.example.domain.model.CashFlowObligation
import com.example.domain.model.CollateralAgreement
import com.example.domain.model.CollateralMovement
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.CollateralSummary
import com.example.domain.model.Instrument
import com.example.domain.model.PortfolioSummary
import com.example.domain.model.Position
import com.example.domain.model.SettlementState
import com.example.domain.model.Trade
import com.example.domain.model.TradeDirection
import java.math.BigDecimal
import java.math.RoundingMode

object PositionAndPnlCalculator {

    /**
     * Revalues positions using current instrument valuations while keeping
     * incompatible contracts (different version/direction/counterparty) strictly separate.
     */
    fun revaluePositions(
        positions: List<Position>,
        instrumentsById: Map<String, Instrument>,
        cashFlows: List<CashFlowObligation>,
        serverNowMillis: Long
    ): List<Position> {
        return positions.map { pos ->
            val inst = instrumentsById[pos.instrumentId]
            val relatedFlows = cashFlows.filter { it.tradeId == pos.tradeId }
            val paid = relatedFlows
                .filter { it.state == SettlementState.PAID || it.state == SettlementState.RECONCILED }
                .fold(BigDecimal.ZERO) { acc, cf -> acc.add(cf.amount) }
                .setScale(2, RoundingMode.HALF_UP)
            val unpaid = relatedFlows
                .filter { it.state != SettlementState.PAID && it.state != SettlementState.RECONCILED }
                .fold(BigDecimal.ZERO) { acc, cf -> acc.add(cf.amount) }
                .setScale(2, RoundingMode.HALF_UP)

            if (pos.lifecycleStatus == "Settled") {
                return@map pos.copy(
                    paidCashFlows = paid,
                    unpaidCashFlows = unpaid
                )
            }

            if (inst == null) {
                return@map pos.copy(
                    isValuationStale = true,
                    valuationErrorReason = "Instrument missing from registry",
                    paidCashFlows = paid,
                    unpaidCashFlows = unpaid
                )
            }

            val assessment = QuantPayoffEngine.assessValuation(inst, serverNowMillis)
            if (assessment.isStale || assessment.indicativeValuePerContract == null) {
                return@map pos.copy(
                    isValuationStale = true,
                    valuationErrorReason = assessment.flagReason ?: "Stale valuation inputs",
                    paidCashFlows = paid,
                    unpaidCashFlows = unpaid
                )
            }

            val currentUnitVal = assessment.indicativeValuePerContract
            val sign = when (pos.direction) {
                TradeDirection.BUY_OPTION,
                TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
                TradeDirection.BUY_SPREAD -> BigDecimal.ONE
                TradeDirection.SELL_OPTION,
                TradeDirection.PAY_FLOATING_RECEIVE_FIXED,
                TradeDirection.SELL_SPREAD -> BigDecimal.ONE.negate()
            }
            // Unrealised P&L = signed MTM delta vs entry price, never double-counting settled cash flows
            val priceDelta = currentUnitVal.subtract(pos.entryPricePerContract)
            val unrealised = priceDelta
                .multiply(BigDecimal(pos.quantity))
                .multiply(sign)
                .setScale(2, RoundingMode.HALF_UP)

            pos.copy(
                currentModelValuePerContract = currentUnitVal,
                unrealisedPnl = unrealised,
                paidCashFlows = paid,
                unpaidCashFlows = unpaid,
                isValuationStale = false,
                valuationErrorReason = null
            )
        }
    }

    fun summarizePortfolio(positions: List<Position>): PortfolioSummary {
        var totalModelValue = BigDecimal.ZERO
        var totalUnrealised = BigDecimal.ZERO
        var totalRealised = BigDecimal.ZERO
        var totalPaid = BigDecimal.ZERO
        var totalUnpaid = BigDecimal.ZERO
        var excludedCount = 0

        for (pos in positions) {
            totalRealised = totalRealised.add(pos.realisedPnl)
            totalPaid = totalPaid.add(pos.paidCashFlows)
            totalUnpaid = totalUnpaid.add(pos.unpaidCashFlows)
            if (pos.isValuationStale) {
                excludedCount++
            } else if (pos.lifecycleStatus != "Settled") {
                val sign = when (pos.direction) {
                    TradeDirection.BUY_OPTION,
                    TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
                    TradeDirection.BUY_SPREAD -> BigDecimal.ONE
                    TradeDirection.SELL_OPTION,
                    TradeDirection.PAY_FLOATING_RECEIVE_FIXED,
                    TradeDirection.SELL_SPREAD -> BigDecimal.ONE.negate()
                }
                totalModelValue = totalModelValue.add(pos.totalModelValue.multiply(sign))
                totalUnrealised = totalUnrealised.add(pos.unrealisedPnl)
            }
        }
        return PortfolioSummary(
            totalModelValue = totalModelValue.setScale(2, RoundingMode.HALF_UP),
            totalUnrealisedPnl = totalUnrealised.setScale(2, RoundingMode.HALF_UP),
            totalRealisedPnl = totalRealised.setScale(2, RoundingMode.HALF_UP),
            totalPaidCashFlows = totalPaid.setScale(2, RoundingMode.HALF_UP),
            totalUnpaidCashFlows = totalUnpaid.setScale(2, RoundingMode.HALF_UP),
            excludedOrUnvaluedCount = excludedCount
        )
    }

    fun summarizeCollateral(
        agreements: List<CollateralAgreement>,
        movements: List<CollateralMovement>,
        openPositions: List<Position>,
        instrumentsById: Map<String, Instrument>
    ): CollateralSummary {
        var postedGross = BigDecimal.ZERO
        var postedEffective = BigDecimal.ZERO
        var receivedEffective = BigDecimal.ZERO

        for (m in movements) {
            if (m.status == "Disputed" || m.status == "Cancelled") continue
            when (m.movementType) {
                CollateralMovementType.POSTED,
                CollateralMovementType.TRANSFER_SIMULATED -> {
                    postedGross = postedGross.add(m.grossAmount)
                    postedEffective = postedEffective.add(m.effectiveValue)
                }
                CollateralMovementType.RELEASED -> {
                    postedGross = postedGross.subtract(m.grossAmount)
                    postedEffective = postedEffective.subtract(m.effectiveValue)
                }
                CollateralMovementType.RECEIVED -> {
                    receivedEffective = receivedEffective.add(m.effectiveValue)
                }
                CollateralMovementType.CALL,
                CollateralMovementType.DISPUTE -> Unit
            }
        }

        // Calculate required initial margin per position & agreement
        val requiredMargin = openPositions
            .filter { it.lifecycleStatus != "Settled" }
            .fold(BigDecimal.ZERO) { acc, pos ->
                val inst = instrumentsById[pos.instrumentId]
                val rate = if (inst != null) {
                    PreTradeRiskEngine.estimateRequiredCollateral(inst, pos.quantity, pos.entryPricePerContract)
                } else {
                    BigDecimal.ZERO
                }
                acc.add(rate)
            }
            .setScale(2, RoundingMode.HALF_UP)

        val available = postedEffective.subtract(requiredMargin).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP)
        return CollateralSummary(
            postedGross = postedGross.setScale(2, RoundingMode.HALF_UP),
            postedAfterHaircut = postedEffective.setScale(2, RoundingMode.HALF_UP),
            receivedAfterHaircut = receivedEffective.setScale(2, RoundingMode.HALF_UP),
            requiredInitialMargin = requiredMargin,
            availableCollateral = available
        )
    }

    fun createPositionFromTrade(trade: Trade, currentModelValue: BigDecimal): Position {
        return Position(
            id = "POS-${trade.id.removePrefix("TRD-")}",
            organisationId = trade.organisationId,
            tradeId = trade.id,
            instrumentId = trade.instrumentId,
            instrumentShortName = trade.instrumentShortName,
            contractVersion = trade.contractVersion,
            productType = trade.productType,
            direction = trade.direction,
            quantity = trade.quantity,
            multiplier = trade.multiplier,
            entryPricePerContract = trade.executedPricePerContract,
            currentModelValuePerContract = currentModelValue,
            feesPaid = trade.fees,
            realisedPnl = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP),
            unrealisedPnl = currentModelValue.subtract(trade.executedPricePerContract)
                .multiply(BigDecimal(trade.quantity))
                .setScale(2, RoundingMode.HALF_UP),
            paidCashFlows = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP),
            unpaidCashFlows = trade.totalConsideration,
            expiryDate = trade.expiryDate,
            counterpartyName = trade.counterpartyName,
            lifecycleStatus = "Open"
        )
    }
}
