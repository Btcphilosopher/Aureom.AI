package com.example.domain.engine

import com.example.domain.model.Instrument
import com.example.domain.model.PayoffPoint
import com.example.domain.model.ProductType
import com.example.domain.model.TradeDirection
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.max

data class ValuationAssessment(
    val modelVersion: String,
    val indicativeValuePerContract: BigDecimal?,
    val isStale: Boolean,
    val flagReason: String?
)

object QuantPayoffEngine {
    const val ENGINE_VERSION = "Aureom-Quant-v2.4.1"
    const val STALE_THRESHOLD_MILLIS = 5 * 60 * 1000L

    /**
     * Gross expiry payoff separated from valuation and net profit.
     * For European Call: N * M * max(I_T - K, 0) for long, negated for short.
     */
    fun calculateGrossExpiryPayoff(
        productType: ProductType,
        direction: TradeDirection,
        quantity: Int,
        multiplier: BigDecimal,
        strikeOrFixedRate: BigDecimal,
        terminalReferenceIndex: BigDecimal
    ): BigDecimal {
        if (quantity <= 0) return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
        val n = BigDecimal(quantity)
        val rawIntrinsic = when (productType) {
            ProductType.EUROPEAN_CALL,
            ProductType.BASKET_CALL,
            ProductType.CAP -> {
                val diff = terminalReferenceIndex.subtract(strikeOrFixedRate)
                if (diff > BigDecimal.ZERO) diff else BigDecimal.ZERO
            }
            ProductType.EUROPEAN_PUT,
            ProductType.FLOOR -> {
                val diff = strikeOrFixedRate.subtract(terminalReferenceIndex)
                if (diff > BigDecimal.ZERO) diff else BigDecimal.ZERO
            }
            ProductType.FIXED_FLOATING_SWAP,
            ProductType.CALENDAR_SPREAD -> {
                terminalReferenceIndex.subtract(strikeOrFixedRate)
            }
        }
        val sign = when (direction) {
            TradeDirection.BUY_OPTION,
            TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
            TradeDirection.BUY_SPREAD -> BigDecimal.ONE
            TradeDirection.SELL_OPTION,
            TradeDirection.PAY_FLOATING_RECEIVE_FIXED,
            TradeDirection.SELL_SPREAD -> BigDecimal.ONE.negate()
        }
        return n.multiply(multiplier).multiply(rawIntrinsic).multiply(sign)
            .setScale(2, RoundingMode.HALF_UP)
    }

    /**
     * Net profit at expiry = gross payoff minus premium paid & fees (for buyers)
     * or gross payoff plus premium received minus fees (for sellers).
     */
    fun calculateNetProfitAfterPremiumAndFees(
        grossExpiryPayoff: BigDecimal,
        direction: TradeDirection,
        quantity: Int,
        premiumPerContract: BigDecimal,
        fees: BigDecimal
    ): BigDecimal {
        val totalPremium = premiumPerContract.multiply(BigDecimal(quantity))
        return when (direction) {
            TradeDirection.BUY_OPTION,
            TradeDirection.BUY_SPREAD -> grossExpiryPayoff.subtract(totalPremium).subtract(fees)
            TradeDirection.SELL_OPTION,
            TradeDirection.SELL_SPREAD -> grossExpiryPayoff.add(totalPremium).subtract(fees)
            TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
            TradeDirection.PAY_FLOATING_RECEIVE_FIXED -> grossExpiryPayoff.subtract(fees)
        }.setScale(2, RoundingMode.HALF_UP)
    }

    fun calculateTotalConsideration(
        quantity: Int,
        pricePerContract: BigDecimal,
        fees: BigDecimal
    ): BigDecimal {
        return pricePerContract.multiply(BigDecimal(quantity))
            .add(fees)
            .setScale(2, RoundingMode.HALF_UP)
    }

    fun generatePayoffCurve(
        instrument: Instrument,
        direction: TradeDirection,
        quantity: Int,
        premiumPerContract: BigDecimal = instrument.indicativeModelValue,
        fees: BigDecimal = BigDecimal.ZERO
    ): List<PayoffPoint> {
        val k = instrument.strikeOrFixedRate
        val span = when (instrument.productType) {
            ProductType.CALENDAR_SPREAD -> BigDecimal("4.00")
            else -> BigDecimal("5.00")
        }
        val minX = k.subtract(span)
        val stepCount = 24
        val step = span.multiply(BigDecimal("2")).divide(BigDecimal(stepCount), 4, RoundingMode.HALF_UP)

        return (0..stepCount).map { i ->
            val ref = minX.add(step.multiply(BigDecimal(i))).setScale(2, RoundingMode.HALF_UP)
            val gross = calculateGrossExpiryPayoff(
                productType = instrument.productType,
                direction = direction,
                quantity = quantity,
                multiplier = instrument.contractMultiplier,
                strikeOrFixedRate = k,
                terminalReferenceIndex = ref
            )
            val net = calculateNetProfitAfterPremiumAndFees(
                grossExpiryPayoff = gross,
                direction = direction,
                quantity = quantity,
                premiumPerContract = premiumPerContract,
                fees = fees
            )
            PayoffPoint(
                referenceIndex = ref,
                grossPayoff = gross,
                netProfitAfterPremium = net
            )
        }
    }

    /**
     * Separate valuation logic: never invents a price when inputs are missing or stale.
     */
    fun assessValuation(
        instrument: Instrument,
        serverNowMillis: Long,
        referenceIndexOverride: BigDecimal? = null
    ): ValuationAssessment {
        if (instrument.isStaleModel) {
            return ValuationAssessment(
                modelVersion = instrument.modelVersion,
                indicativeValuePerContract = null,
                isStale = true,
                flagReason = "Reference feed stale — model revaluation suspended"
            )
        }
        val ageMillis = serverNowMillis - instrument.modelInputsTimestampMillis
        if (ageMillis > STALE_THRESHOLD_MILLIS) {
            return ValuationAssessment(
                modelVersion = instrument.modelVersion,
                indicativeValuePerContract = null,
                isStale = true,
                flagReason = "Model inputs older than 5m (${max(1L, ageMillis / 60000L)}m)"
            )
        }
        val ref = referenceIndexOverride ?: instrument.currentReferenceIndex
        if (ref <= BigDecimal.ZERO && instrument.productType != ProductType.CALENDAR_SPREAD) {
            return ValuationAssessment(
                modelVersion = instrument.modelVersion,
                indicativeValuePerContract = null,
                isStale = true,
                flagReason = "Missing reference index observation"
            )
        }
        // Deterministic valuation anchored to intrinsic + smooth time value sensitivity
        val deltaShift = ref.subtract(instrument.currentReferenceIndex)
        val multiplierScale = instrument.contractMultiplier.multiply(BigDecimal("0.48"))
        val adjusted = when (instrument.productType) {
            ProductType.EUROPEAN_CALL, ProductType.BASKET_CALL, ProductType.CAP ->
                instrument.indicativeModelValue.add(deltaShift.multiply(multiplierScale))
            ProductType.EUROPEAN_PUT, ProductType.FLOOR ->
                instrument.indicativeModelValue.subtract(deltaShift.multiply(multiplierScale))
            ProductType.FIXED_FLOATING_SWAP, ProductType.CALENDAR_SPREAD ->
                instrument.indicativeModelValue.add(deltaShift.multiply(instrument.contractMultiplier))
        }.let { value ->
            if (instrument.productType != ProductType.FIXED_FLOATING_SWAP &&
                instrument.productType != ProductType.CALENDAR_SPREAD &&
                value < BigDecimal("100.00")
            ) {
                BigDecimal("100.00")
            } else {
                value
            }
        }.setScale(2, RoundingMode.HALF_UP)

        return ValuationAssessment(
            modelVersion = instrument.modelVersion,
            indicativeValuePerContract = adjusted,
            isStale = false,
            flagReason = null
        )
    }
}
