package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightCanvas = Color(0xFF06111F)
val MidnightHeader = Color(0xFF081628)
val PanelNavy = Color(0xFF0A192D)
val PanelElevated = Color(0xFF0E223D)
val RowSelected = Color(0xFF0E2B48)
val InputSurface = Color(0xFF071426)

val SteelBorder = Color(0xFF1F3B5C)
val SteelBorderBright = Color(0xFF2B527E)
val SteelDivider = Color(0xFF152A44)

val CyanPrimary = Color(0xFF16D9EC)
val CyanBright = Color(0xFF3CE8F5)
val CyanDarkText = Color(0xFF041320)
val CyanMutedFill = Color(0xFF0D3A52)

val EmeraldLeaf = Color(0xFF39D98A)
val PositiveGreen = Color(0xFF3DD68C)
val NegativeCoral = Color(0xFFE96E6E)
val WarningAmber = Color(0xFFF0B449)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF9CB2CB)
val TextMuted = Color(0xFF6B84A3)
