package com.example.domain.engine

import com.example.domain.model.ApprovalStatus
import com.example.domain.model.AuditLogEntry
import com.example.domain.model.CashFlowObligation
import com.example.domain.model.CollateralAgreement
import com.example.domain.model.CollateralMovement
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.Counterparty
import com.example.domain.model.DealerQuote
import com.example.domain.model.Instrument
import com.example.domain.model.Position
import com.example.domain.model.PriceBasis
import com.example.domain.model.ProductTab
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteStatus
import com.example.domain.model.RfqRequest
import com.example.domain.model.RfqStatus
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.Trade
import com.example.domain.model.TradeDirection
import com.example.domain.model.ValuationPoint
import java.math.BigDecimal

object SeedDataFactory {

    private fun buildHistory(base: Double, nowMillis: Long, points: List<Double>): List<ValuationPoint> {
        val labels = listOf("10 Nov", "11 Nov", "12 Nov", "13 Nov", "14 Nov")
        val stepMillis = (4L * 24 * 3600 * 1000) / (points.size - 1).coerceAtLeast(1)
        val startMillis = nowMillis - 4L * 24 * 3600 * 1000
        return points.mapIndexed { idx, v ->
            val labelIdx = (idx * (labels.size - 1)) / (points.size - 1).coerceAtLeast(1)
            ValuationPoint(
                label = labels[labelIdx],
                value = BigDecimal.valueOf(v).setScale(2),
                timestampMillis = startMillis + idx * stepMillis
            )
        }
    }

    fun seedInstruments(nowMillis: Long): List<Instrument> = listOf(
        Instrument(
            id = "INST-HCB-CALL-MAR27",
            ticker = "HCB-C-102-MAR27",
            explorerCode = "HCB CALL • MAR27 • K102",
            displayName = "HOME CARE BASKET — MAR27 CALL",
            shortName = "HCB Call MAR27",
            contractVersion = "v1.0",
            productType = ProductType.EUROPEAN_CALL,
            productTab = ProductTab.OPTIONS,
            styleSubtitle = "European • Cash settled",
            underlyingRef = "Synthetic reference index",
            currency = "USD",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            contractMultiplier = BigDecimal("10000.00"),
            strikeOrFixedRate = BigDecimal("102.00"),
            strikeUnitLabel = "index points",
            effectiveDate = "2026-11-15",
            expiryDate = "2027-03-31",
            expiryDisplay = "31 Mar 2027",
            observationSchedule = "Monthly last business day; final fixing 31 Mar 2027 16:00 UTC",
            paymentSchedule = "Premium T+2 (18 Nov 2026); Cash settlement T+2 post-expiry",
            settlementRules = "Cash settled: N × $10,000 × max(I_T - 102.00, 0)",
            businessCalendar = "US-NY / UK-LON Joint",
            timezoneRule = "UTC (Fixing 16:00 UTC)",
            tradingPermissionEnabled = true,
            approvalStatus = ApprovalStatus.APPROVED,
            termSheetVersion = "TS-HCB-2027-v1.0",
            referenceMethodology = "Aureom Synthetic Home-Care Input Basket Index (weighted arithmetic mean)",
            origin = "Aureom Structure",
            modelVersion = QuantPayoffEngine.ENGINE_VERSION,
            indicativeModelValue = BigDecimal("24500.00"),
            modelInputsTimestampMillis = nowMillis,
            modelUpdatedUtc = "14:45:08 UTC",
            currentReferenceIndex = BigDecimal("103.85"),
            isStaleModel = false,
            historicalSeries = buildHistory(
                24500.0,
                nowMillis,
                listOf(
                    21000.0, 21150.0, 21380.0, 21100.0, 21520.0, 21800.0,
                    22150.0, 22400.0, 22650.0, 22890.0, 22740.0, 23100.0,
                    23020.0, 23310.0, 23480.0, 23150.0, 23390.0, 23680.0,
                    23720.0, 23940.0, 24180.0, 24050.0, 24360.0, 24610.0,
                    24420.0, 24500.0
                )
            )
        ),
        Instrument(
            id = "INST-HCB-PUT-MAR27",
            ticker = "HCB-P-102-MAR27",
            explorerCode = "HCB PUT • MAR27 • K102",
            displayName = "HOME CARE BASKET — MAR27 PUT",
            shortName = "HCB Put MAR27",
            contractVersion = "v1.0",
            productType = ProductType.EUROPEAN_PUT,
            productTab = ProductTab.OPTIONS,
            styleSubtitle = "European • Cash settled",
            underlyingRef = "Synthetic reference index",
            currency = "USD",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            contractMultiplier = BigDecimal("10000.00"),
            strikeOrFixedRate = BigDecimal("102.00"),
            strikeUnitLabel = "index points",
            effectiveDate = "2026-11-15",
            expiryDate = "2027-03-31",
            expiryDisplay = "31 Mar 2027",
            observationSchedule = "Monthly last business day; final fixing 31 Mar 2027 16:00 UTC",
            paymentSchedule = "Premium T+2 (18 Nov 2026); Cash settlement T+2 post-expiry",
            settlementRules = "Cash settled: N × $10,000 × max(102.00 - I_T, 0)",
            businessCalendar = "US-NY / UK-LON Joint",
            timezoneRule = "UTC (Fixing 16:00 UTC)",
            tradingPermissionEnabled = true,
            approvalStatus = ApprovalStatus.APPROVED,
            termSheetVersion = "TS-HCB-P-2027-v1.0",
            referenceMethodology = "Aureom Synthetic Home-Care Input Basket Index (weighted arithmetic mean)",
            origin = "Aureom Structure",
            modelVersion = QuantPayoffEngine.ENGINE_VERSION,
            indicativeModelValue = BigDecimal("18900.00"),
            modelInputsTimestampMillis = nowMillis,
            modelUpdatedUtc = "14:45:08 UTC",
            currentReferenceIndex = BigDecimal("103.85"),
            isStaleModel = false,
            historicalSeries = buildHistory(
                18900.0,
                nowMillis,
                listOf(
                    21200.0, 20950.0, 20800.0, 20600.0, 20450.0, 20120.0,
                    19900.0, 19650.0, 19820.0, 19500.0, 19380.0, 19150.0,
                    19240.0, 19010.0, 18980.0, 18820.0, 18950.0, 18900.0
                )
            )
        ),
        Instrument(
            id = "INST-HC-SWAP-Q227",
            ticker = "HCS-FF-Q227",
            explorerCode = "HOMECARE SWAP • Q227",
            displayName = "HOMECARE FIXED/FLOATING SWAP — Q2 2027",
            shortName = "Homecare Swap Q227",
            contractVersion = "v1.0",
            productType = ProductType.FIXED_FLOATING_SWAP,
            productTab = ProductTab.SWAPS,
            styleSubtitle = "Fixed/Floating • Quarterly net settled",
            underlyingRef = "Homecare Synthetic Input Index",
            currency = "USD",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.TOTAL_CONSIDERATION,
            contractMultiplier = BigDecimal("5000.00"),
            strikeOrFixedRate = BigDecimal("100.50"),
            strikeUnitLabel = "fixed index",
            effectiveDate = "2026-11-15",
            expiryDate = "2027-06-30",
            expiryDisplay = "30 Jun 2027",
            observationSchedule = "Quarterly average observation (Q1/Q2 2027)",
            paymentSchedule = "08 Jan 2027 interim reset; 02 Jul 2027 final net settlement",
            settlementRules = "Net cash settled: N × $5,000 × (I_T - Fixed 100.50)",
            businessCalendar = "US-NY",
            timezoneRule = "America/New_York (17:00 EST)",
            tradingPermissionEnabled = true,
            approvalStatus = ApprovalStatus.APPROVED,
            termSheetVersion = "TS-HCS-Q227-v1.0",
            referenceMethodology = "Arithmetic mean of daily Homecare Synthetic Input fixings",
            origin = "Aureom Structure",
            modelVersion = QuantPayoffEngine.ENGINE_VERSION,
            indicativeModelValue = BigDecimal("8420.00"),
            modelInputsTimestampMillis = nowMillis,
            modelUpdatedUtc = "14:45:08 UTC",
            currentReferenceIndex = BigDecimal("102.18"),
            isStaleModel = false,
            historicalSeries = buildHistory(
                8420.0,
                nowMillis,
                listOf(
                    7650.0, 7790.0, 7840.0, 7920.0, 8010.0, 7950.0,
                    8110.0, 8240.0, 8190.0, 8300.0, 8360.0, 8420.0
                )
            )
        ),
        Instrument(
            id = "INST-OIL-CAP-2027",
            ticker = "COIL-CAP-2027",
            explorerCode = "OIL CAP • 2027",
            displayName = "COOKING OIL CAP — 2027",
            shortName = "OIL Cap 2027",
            contractVersion = "v1.0",
            productType = ProductType.CAP,
            productTab = ProductTab.CAPS_AND_FLOORS,
            styleSubtitle = "Commodity Cap • Cash settled",
            underlyingRef = "Refined Cooking Oil Index",
            currency = "USD",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            contractMultiplier = BigDecimal("10000.00"),
            strikeOrFixedRate = BigDecimal("88.00"),
            strikeUnitLabel = "index points",
            effectiveDate = "2026-11-15",
            expiryDate = "2027-12-31",
            expiryDisplay = "31 Dec 2027",
            observationSchedule = "Monthly caplet fixings Jan–Dec 2027",
            paymentSchedule = "Premium T+2; Caplet payout 5BD post-month end",
            settlementRules = "Cash settled: N × $10,000 × max(I_T - 88.00, 0)",
            businessCalendar = "UK-LON",
            timezoneRule = "Europe/London (16:30 GMT)",
            tradingPermissionEnabled = true,
            approvalStatus = ApprovalStatus.APPROVED,
            termSheetVersion = "TS-COIL-2027-v1.0",
            referenceMethodology = "Aureom Refined Cooking Oil Synthetic Benchmark",
            origin = "Aureom Structure",
            modelVersion = QuantPayoffEngine.ENGINE_VERSION,
            indicativeModelValue = BigDecimal("31200.00"),
            modelInputsTimestampMillis = nowMillis,
            modelUpdatedUtc = "14:45:08 UTC",
            currentReferenceIndex = BigDecimal("90.80"),
            isStaleModel = false,
            historicalSeries = buildHistory(
                31200.0,
                nowMillis,
                listOf(
                    28900.0, 29150.0, 29400.0, 29800.0, 29650.0, 30100.0,
                    30450.0, 30300.0, 30780.0, 30920.0, 31050.0, 31200.0
                )
            )
        ),
        Instrument(
            id = "INST-PAPER-SPREAD-JS27",
            ticker = "PPR-CS-JUNSEP27",
            explorerCode = "PAPER SPREAD • JUN/SEP",
            displayName = "PAPER CALENDAR SPREAD — JUN/SEP 2027",
            shortName = "Paper Spread JUN/SEP",
            contractVersion = "v1.0",
            productType = ProductType.CALENDAR_SPREAD,
            productTab = ProductTab.CALENDAR_SPREADS,
            styleSubtitle = "Calendar Spread • Cash settled",
            underlyingRef = "Packaging Paper Sep-Jun Differential",
            currency = "USD",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            contractMultiplier = BigDecimal("4000.00"),
            strikeOrFixedRate = BigDecimal("4.50"),
            strikeUnitLabel = "spread pts",
            effectiveDate = "2026-11-15",
            expiryDate = "2027-09-15",
            expiryDisplay = "15 Sep 2027",
            observationSchedule = "Jun 2027 & Sep 2027 benchmark fixing",
            paymentSchedule = "Settlement 17 Sep 2027",
            settlementRules = "Cash settled: N × $4,000 × ((I_Sep - I_Jun) - 4.50)",
            businessCalendar = "EU-TARGET",
            timezoneRule = "CET (17:00 CET)",
            tradingPermissionEnabled = true,
            approvalStatus = ApprovalStatus.APPROVED,
            termSheetVersion = "TS-PPR-JS27-v1.0",
            referenceMethodology = "Aureom Packaging Pulp & Paper Term Structure Differential",
            origin = "Aureom Structure",
            modelVersion = QuantPayoffEngine.ENGINE_VERSION,
            indicativeModelValue = BigDecimal("4600.00"),
            modelInputsTimestampMillis = nowMillis,
            modelUpdatedUtc = "14:45:08 UTC",
            currentReferenceIndex = BigDecimal("5.65"),
            isStaleModel = false,
            historicalSeries = buildHistory(
                4600.0,
                nowMillis,
                listOf(
                    4100.0, 4180.0, 4220.0, 4310.0, 4290.0, 4400.0,
                    4480.0, 4520.0, 4490.0, 4560.0, 4600.0
                )
            )
        )
    )

    /**
     * Catalog of additional Aureom Structure definitions available to import on demand
     * (including a v1.1 call to demonstrate contract-version preservation).
     */
    fun structureCatalog(): List<AureomStructureDefinition> = listOf(
        AureomStructureDefinition(
            id = "INST-HCB-CALL-MAR27-V11",
            ticker = "HCB-C-102-MAR27-V11",
            explorerCode = "HCB CALL • MAR27 • v1.1",
            displayName = "HOME CARE BASKET — MAR27 CALL (v1.1)",
            shortName = "HCB Call MAR27 v1.1",
            contractVersion = "v1.1",
            productType = ProductType.BASKET_CALL,
            productTab = ProductTab.BASKETS,
            styleSubtitle = "Basket European • Cash settled",
            underlyingRef = "Synthetic Home Care Basket v1.1",
            currency = "USD",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            contractMultiplier = BigDecimal("10000.00"),
            strikeOrFixedRate = BigDecimal("102.00"),
            strikeUnitLabel = "index points",
            effectiveDate = "2026-11-15",
            expiryDate = "2027-03-31",
            expiryDisplay = "31 Mar 2027",
            observationSchedule = "Monthly last business day; final fixing 31 Mar 2027 16:00 UTC",
            paymentSchedule = "Premium T+2; Cash settlement T+2 post-expiry",
            settlementRules = "Cash settled: N × $10,000 × max(I_T - 102.00, 0)",
            businessCalendar = "US-NY / UK-LON Joint",
            timezoneRule = "UTC (Fixing 16:00 UTC)",
            approvalStatus = ApprovalStatus.APPROVED,
            termSheetVersion = "TS-HCB-2027-v1.1",
            referenceMethodology = "Aureom Reweighted Home-Care Input Basket Index v1.1",
            indicativeModelValue = BigDecimal("25150.00"),
            currentReferenceIndex = BigDecimal("104.05"),
            modelVersion = QuantPayoffEngine.ENGINE_VERSION,
            historicalSeries = emptyList()
        ),
        AureomStructureDefinition(
            id = "INST-BROKEN-DEF",
            ticker = "",
            explorerCode = "INVALID",
            displayName = "Incomplete Draft",
            shortName = "Incomplete",
            contractVersion = "",
            productType = null,
            productTab = ProductTab.OPTIONS,
            styleSubtitle = "",
            underlyingRef = "",
            currency = "US",
            quantityUnit = "Contracts",
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            contractMultiplier = BigDecimal("-5"),
            strikeOrFixedRate = null,
            strikeUnitLabel = "",
            effectiveDate = "2027-05-01",
            expiryDate = "2027-01-01",
            expiryDisplay = "",
            observationSchedule = "",
            paymentSchedule = "",
            settlementRules = "",
            businessCalendar = "",
            timezoneRule = "",
            approvalStatus = ApprovalStatus.PENDING_REVIEW,
            termSheetVersion = "",
            referenceMethodology = "",
            indicativeModelValue = BigDecimal.ZERO,
            currentReferenceIndex = BigDecimal.ZERO,
            modelVersion = "",
            historicalSeries = emptyList()
        )
    )

    fun seedCounterparties(): List<Counterparty> = listOf(
        Counterparty(
            id = "CPTY-NORTHBRIDGE",
            name = "Northbridge",
            eligibleProductTypes = ProductType.entries.toSet(),
            creditLimitUsd = BigDecimal("500000.00"),
            currentExposureUsd = BigDecimal("49000.00"),
            isPermitted = true,
            csaAgreementId = "CSA-NB-2026-A"
        ),
        Counterparty(
            id = "CPTY-CALDER",
            name = "Calder Markets",
            eligibleProductTypes = ProductType.entries.toSet(),
            creditLimitUsd = BigDecimal("350000.00"),
            currentExposureUsd = BigDecimal("31200.00"),
            isPermitted = true,
            csaAgreementId = "CSA-CM-2026-B"
        ),
        Counterparty(
            id = "CPTY-PENNINE",
            name = "Pennine Capital",
            eligibleProductTypes = ProductType.entries.toSet(),
            creditLimitUsd = BigDecimal("250000.00"),
            currentExposureUsd = BigDecimal("8420.00"),
            isPermitted = true,
            csaAgreementId = "CSA-PC-2026-C"
        ),
        Counterparty(
            id = "CPTY-RESTRICTED",
            name = "Meridian Restricted",
            eligibleProductTypes = setOf(ProductType.FIXED_FLOATING_SWAP),
            creditLimitUsd = BigDecimal("50000.00"),
            currentExposureUsd = BigDecimal("48000.00"),
            isPermitted = false,
            csaAgreementId = "NO-CSA"
        )
    )

    fun seedRfqs(nowMillis: Long): List<RfqRequest> = listOf(
        RfqRequest(
            id = "RFQ-1001",
            idempotencyKey = "seed-rfq-1001",
            organisationId = "ORG-AUREOM-01",
            instrumentId = "INST-HCB-CALL-MAR27",
            instrumentShortName = "HCB Call MAR27",
            contractVersion = "v1.0",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            eligibleCounterpartyIds = listOf("CPTY-NORTHBRIDGE", "CPTY-CALDER", "CPTY-PENNINE"),
            deadlineMillis = nowMillis + 180_000L,
            requestedTerms = "European Cash Settled • T+2 Premium",
            status = RfqStatus.QUOTES_RECEIVED,
            createdAtMillis = nowMillis - 15_000L
        ),
        RfqRequest(
            id = "RFQ-1002",
            idempotencyKey = "seed-rfq-1002",
            organisationId = "ORG-AUREOM-01",
            instrumentId = "INST-OIL-CAP-2027",
            instrumentShortName = "OIL Cap 2027",
            contractVersion = "v1.0",
            direction = TradeDirection.BUY_OPTION,
            quantity = 1,
            eligibleCounterpartyIds = listOf("CPTY-NORTHBRIDGE", "CPTY-CALDER"),
            deadlineMillis = nowMillis + 240_000L,
            requestedTerms = "Monthly Caplet • UK-LON Calendar",
            status = RfqStatus.QUOTES_RECEIVED,
            createdAtMillis = nowMillis - 45_000L
        ),
        RfqRequest(
            id = "RFQ-1003",
            idempotencyKey = "seed-rfq-1003",
            organisationId = "ORG-AUREOM-01",
            instrumentId = "INST-HC-SWAP-Q227",
            instrumentShortName = "Homecare Swap Q227",
            contractVersion = "v1.0",
            direction = TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
            quantity = 1,
            eligibleCounterpartyIds = listOf("CPTY-NORTHBRIDGE", "CPTY-PENNINE"),
            deadlineMillis = nowMillis + 300_000L,
            requestedTerms = "Quarterly Net Settlement • Fixed 100.50",
            status = RfqStatus.QUOTES_RECEIVED,
            createdAtMillis = nowMillis - 60_000L
        )
    )

    fun seedQuotes(nowMillis: Long): List<DealerQuote> = listOf(
        DealerQuote(
            id = "QT-1001-NB",
            rfqId = "RFQ-1001",
            version = 1,
            counterpartyId = "CPTY-NORTHBRIDGE",
            counterpartyName = "Northbridge",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            bidPrice = BigDecimal("23900.00"),
            askPrice = BigDecimal("25100.00"),
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            fees = BigDecimal("180.00"),
            currency = "USD",
            settlementTerms = "Cash T+2 (18 Nov 2026)",
            expiresAtMillis = nowMillis + 28_000L,
            isFirm = true,
            status = QuoteStatus.FIRM_ACTIVE,
            createdAtMillis = nowMillis - 5_000L
        ),
        DealerQuote(
            id = "QT-1001-CM",
            rfqId = "RFQ-1001",
            version = 1,
            counterpartyId = "CPTY-CALDER",
            counterpartyName = "Calder Markets",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            bidPrice = BigDecimal("23700.00"),
            askPrice = BigDecimal("25300.00"),
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            fees = BigDecimal("200.00"),
            currency = "USD",
            settlementTerms = "Cash T+2 (18 Nov 2026)",
            expiresAtMillis = nowMillis + 22_000L,
            isFirm = true,
            status = QuoteStatus.FIRM_ACTIVE,
            createdAtMillis = nowMillis - 5_000L
        ),
        DealerQuote(
            id = "QT-1001-PC",
            rfqId = "RFQ-1001",
            version = 1,
            counterpartyId = "CPTY-PENNINE",
            counterpartyName = "Pennine Capital",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            bidPrice = BigDecimal("23500.00"),
            askPrice = BigDecimal("25500.00"),
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            fees = BigDecimal("150.00"),
            currency = "USD",
            settlementTerms = "Cash T+2 (18 Nov 2026)",
            expiresAtMillis = nowMillis + 19_000L,
            isFirm = true,
            status = QuoteStatus.FIRM_ACTIVE,
            createdAtMillis = nowMillis - 5_000L
        ),
        DealerQuote(
            id = "QT-1002-NB",
            rfqId = "RFQ-1002",
            version = 1,
            counterpartyId = "CPTY-NORTHBRIDGE",
            counterpartyName = "Northbridge",
            direction = TradeDirection.BUY_OPTION,
            quantity = 1,
            bidPrice = BigDecimal("30600.00"),
            askPrice = BigDecimal("31800.00"),
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            fees = BigDecimal("140.00"),
            currency = "USD",
            settlementTerms = "Cash T+2",
            expiresAtMillis = nowMillis + 180_000L,
            isFirm = true,
            status = QuoteStatus.FIRM_ACTIVE,
            createdAtMillis = nowMillis - 20_000L
        ),
        DealerQuote(
            id = "QT-1003-PC",
            rfqId = "RFQ-1003",
            version = 1,
            counterpartyId = "CPTY-PENNINE",
            counterpartyName = "Pennine Capital",
            direction = TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
            quantity = 1,
            bidPrice = BigDecimal("8180.00"),
            askPrice = BigDecimal("8650.00"),
            priceBasis = PriceBasis.TOTAL_CONSIDERATION,
            fees = BigDecimal("120.00"),
            currency = "USD",
            settlementTerms = "Quarterly Net Settlement",
            expiresAtMillis = nowMillis + 240_000L,
            isFirm = true,
            status = QuoteStatus.FIRM_ACTIVE,
            createdAtMillis = nowMillis - 25_000L
        )
    )

    fun seedTrades(nowMillis: Long): List<Trade> = listOf(
        Trade(
            id = "TRD-2001",
            idempotencyKey = "seed-trd-2001",
            organisationId = "ORG-AUREOM-01",
            rfqId = "RFQ-0991",
            quoteId = "QT-0991-NB",
            instrumentId = "INST-HCB-CALL-MAR27",
            instrumentShortName = "HCB Call MAR27",
            contractVersion = "v1.0",
            productType = ProductType.EUROPEAN_CALL,
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            multiplier = BigDecimal("10000.00"),
            strikeOrFixedRate = BigDecimal("102.00"),
            executedPricePerContract = BigDecimal("23900.00"),
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            fees = BigDecimal("180.00"),
            totalConsideration = BigDecimal("47980.00"),
            currency = "USD",
            counterpartyId = "CPTY-NORTHBRIDGE",
            counterpartyName = "Northbridge",
            paymentDate = "2026-11-18",
            expiryDate = "2027-03-31",
            mode = "Simulation",
            executedAtMillis = nowMillis - 86_400_000L,
            status = "Confirmed"
        ),
        Trade(
            id = "TRD-2002",
            idempotencyKey = "seed-trd-2002",
            organisationId = "ORG-AUREOM-01",
            rfqId = "RFQ-0992",
            quoteId = "QT-0992-CM",
            instrumentId = "INST-OIL-CAP-2027",
            instrumentShortName = "OIL Cap 2027",
            contractVersion = "v1.0",
            productType = ProductType.CAP,
            direction = TradeDirection.BUY_OPTION,
            quantity = 1,
            multiplier = BigDecimal("10000.00"),
            strikeOrFixedRate = BigDecimal("88.00"),
            executedPricePerContract = BigDecimal("30520.00"),
            priceBasis = PriceBasis.PREMIUM_PER_CONTRACT,
            fees = BigDecimal("140.00"),
            totalConsideration = BigDecimal("30660.00"),
            currency = "USD",
            counterpartyId = "CPTY-CALDER",
            counterpartyName = "Calder Markets",
            paymentDate = "2026-11-18",
            expiryDate = "2027-12-31",
            mode = "Simulation",
            executedAtMillis = nowMillis - 172_800_000L,
            status = "Confirmed"
        ),
        Trade(
            id = "TRD-2003",
            idempotencyKey = "seed-trd-2003",
            organisationId = "ORG-AUREOM-01",
            rfqId = "RFQ-0993",
            quoteId = "QT-0993-PC",
            instrumentId = "INST-HC-SWAP-Q227",
            instrumentShortName = "Homecare Swap Q227",
            contractVersion = "v1.0",
            productType = ProductType.FIXED_FLOATING_SWAP,
            direction = TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
            quantity = 1,
            multiplier = BigDecimal("5000.00"),
            strikeOrFixedRate = BigDecimal("100.50"),
            executedPricePerContract = BigDecimal("8660.00"),
            priceBasis = PriceBasis.TOTAL_CONSIDERATION,
            fees = BigDecimal("120.00"),
            totalConsideration = BigDecimal("8780.00"),
            currency = "USD",
            counterpartyId = "CPTY-PENNINE",
            counterpartyName = "Pennine Capital",
            paymentDate = "2027-01-08",
            expiryDate = "2027-06-30",
            mode = "Simulation",
            executedAtMillis = nowMillis - 259_200_000L,
            status = "Confirmed"
        )
    )

    fun seedCashFlows(nowMillis: Long): List<CashFlowObligation> = listOf(
        CashFlowObligation(
            id = "CF-3001",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2001",
            instrumentShortName = "HCB Call MAR27",
            category = "PREMIUM",
            amount = BigDecimal("47980.00"),
            currency = "USD",
            dueDate = "2026-11-18",
            counterpartyName = "Northbridge",
            state = SettlementState.SCHEDULED,
            reconciliationRef = null,
            updatedAtMillis = nowMillis
        ),
        CashFlowObligation(
            id = "CF-3002",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2002",
            instrumentShortName = "OIL Cap 2027",
            category = "PREMIUM",
            amount = BigDecimal("30660.00"),
            currency = "USD",
            dueDate = "2026-11-18",
            counterpartyName = "Calder Markets",
            state = SettlementState.SCHEDULED,
            reconciliationRef = null,
            updatedAtMillis = nowMillis
        ),
        CashFlowObligation(
            id = "CF-3003",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2003",
            instrumentShortName = "Homecare Swap Q227",
            category = "COUPON",
            amount = BigDecimal("8780.00"),
            currency = "USD",
            dueDate = "2027-01-08",
            counterpartyName = "Pennine Capital",
            state = SettlementState.SCHEDULED,
            reconciliationRef = null,
            updatedAtMillis = nowMillis
        )
    )

    fun seedCollateralAgreements(): List<CollateralAgreement> = listOf(
        CollateralAgreement(
            id = "CSA-NB-2026-A",
            organisationId = "ORG-AUREOM-01",
            name = "Aureom Bilateral CSA — Master Set",
            counterpartyName = "Northbridge / Calder / Pennine",
            eligibleAssets = listOf("USD Cash (0% haircut)", "US T-Bills <=1Y (2% haircut)", "EUR Cash (5% haircut)"),
            haircutPct = BigDecimal("2.00"),
            nettingSetId = "NET-SET-AUREOM-01",
            independentAmount = BigDecimal("10000.00"),
            variationThreshold = BigDecimal("25000.00")
        )
    )

    fun seedCollateralMovements(nowMillis: Long): List<CollateralMovement> = listOf(
        CollateralMovement(
            id = "COL-4001",
            organisationId = "ORG-AUREOM-01",
            agreementId = "CSA-NB-2026-A",
            movementType = CollateralMovementType.POSTED,
            assetType = "USD Cash",
            grossAmount = BigDecimal("60000.00"),
            haircutPct = BigDecimal("0.00"),
            effectiveValue = BigDecimal("60000.00"),
            currency = "USD",
            isSimulated = true,
            status = "Confirmed (Sim)",
            timestampMillis = nowMillis - 172_800_000L,
            notes = "Initial cash margin buffer"
        ),
        CollateralMovement(
            id = "COL-4002",
            organisationId = "ORG-AUREOM-01",
            agreementId = "CSA-NB-2026-A",
            movementType = CollateralMovementType.POSTED,
            assetType = "US T-Bills <=1Y",
            grossAmount = BigDecimal("31321.43"),
            haircutPct = BigDecimal("2.00"),
            effectiveValue = BigDecimal("30695.00"),
            currency = "USD",
            isSimulated = true,
            status = "Confirmed (Sim)",
            timestampMillis = nowMillis - 86_400_000L,
            notes = "Eligible T-Bill pledge after 2% haircut"
        )
    )

    fun seedSettlementEvents(): List<SettlementEvent> = listOf(
        SettlementEvent(
            id = "SET-5001",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2001",
            dateIso = "2026-11-18",
            displayDate = "18 Nov",
            eventLabel = "Premium due (options)",
            eventCategory = "PREMIUM",
            instrumentShortName = "HCB Call MAR27",
            calendarRule = "US-NY / UK-LON",
            timezoneRule = "UTC",
            observedIndex = null,
            calculatedPayoff = BigDecimal("47980.00"),
            state = SettlementState.SCHEDULED,
            notes = "Initial premium T+2 settlement"
        ),
        SettlementEvent(
            id = "SET-5002",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2001",
            dateIso = "2026-12-31",
            displayDate = "31 Dec",
            eventLabel = "Reference observation (baskets)",
            eventCategory = "OBSERVATION",
            instrumentShortName = "HCB Call MAR27",
            calendarRule = "US-NY / UK-LON",
            timezoneRule = "UTC 16:00",
            observedIndex = null,
            calculatedPayoff = null,
            state = SettlementState.SCHEDULED,
            notes = "Year-end basket fixing observation"
        ),
        SettlementEvent(
            id = "SET-5003",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2003",
            dateIso = "2027-01-08",
            displayDate = "08 Jan",
            eventLabel = "Swap settlement (Q227)",
            eventCategory = "SETTLEMENT",
            instrumentShortName = "Homecare Swap Q227",
            calendarRule = "US-NY",
            timezoneRule = "EST 17:00",
            observedIndex = null,
            calculatedPayoff = BigDecimal("8780.00"),
            state = SettlementState.SCHEDULED,
            notes = "Interim fixed/floating reset settlement"
        ),
        SettlementEvent(
            id = "SET-5004",
            organisationId = "ORG-AUREOM-01",
            tradeId = "TRD-2001",
            dateIso = "2027-03-31",
            displayDate = "31 Mar 27",
            eventLabel = "Expiry & fixing (HCB Call MAR27)",
            eventCategory = "EXPIRY",
            instrumentShortName = "HCB Call MAR27",
            calendarRule = "US-NY / UK-LON",
            timezoneRule = "UTC 16:00",
            observedIndex = null,
            calculatedPayoff = null,
            state = SettlementState.SCHEDULED,
            notes = "Final European option exercise & cash settlement"
        )
    )

    fun seedAuditLogs(nowMillis: Long): List<AuditLogEntry> = listOf(
        AuditLogEntry(
            id = "AUD-1",
            organisationId = "ORG-AUREOM-01",
            actorRole = "STRUCTURE_ADAPTER",
            action = "INSTRUMENTS_IMPORTED",
            entityType = "INSTRUMENT",
            entityId = "INST-HCB-CALL-MAR27",
            details = "Imported 5 approved synthetic definitions from Aureom Structure (Simulation mode only).",
            timestampMillis = nowMillis - 300_000L
        ),
        AuditLogEntry(
            id = "AUD-2",
            organisationId = "ORG-AUREOM-01",
            actorRole = "DEALER_ADAPTER",
            action = "QUOTES_RECEIVED",
            entityType = "RFQ",
            entityId = "RFQ-1001",
            details = "Received 3 firm quotes for HCB Call MAR27 (Northbridge, Calder Markets, Pennine Capital).",
            timestampMillis = nowMillis - 5_000L
        )
    )
}
