package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.PreTradeRiskEngine
import com.example.domain.engine.QuantPayoffEngine
import com.example.domain.model.CheckOutcome
import com.example.domain.model.CollateralSummary
import com.example.domain.model.Counterparty
import com.example.domain.model.DealerQuote
import com.example.domain.model.Instrument
import com.example.domain.model.PortfolioSummary
import com.example.domain.model.PreTradeCheckItem
import com.example.domain.model.ProductType
import com.example.domain.model.ReportingCurrency
import com.example.domain.model.TradeDirection
import com.example.ui.theme.CyanDarkText
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.InputSurface
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.TicketStage
import com.example.ui.viewmodel.formatCurrency
import com.example.ui.viewmodel.formatSignedCurrency
import java.math.BigDecimal

@Composable
fun TradeTicketCard(
    instruments: List<Instrument>,
    selectedInstrument: Instrument,
    counterparties: List<Counterparty>,
    direction: TradeDirection,
    contracts: Int,
    selectedCounterpartyId: String?,
    selectedQuote: DealerQuote?,
    stage: TicketStage,
    currency: ReportingCurrency,
    canCommit: Boolean,
    needsDualApproval: Boolean,
    dualApprovalGranted: Boolean,
    onSelectInstrument: (String) -> Unit,
    onSelectDirection: (TradeDirection) -> Unit,
    onChangeContracts: (Int) -> Unit,
    onSelectCounterparty: (String?) -> Unit,
    onRequestQuote: () -> Unit,
    onConfirmTrade: () -> Unit,
    onResetTicket: () -> Unit,
    onToggleDualApproval: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var instMenuOpen by remember { mutableStateOf(false) }
    var cptyMenuOpen by remember { mutableStateOf(false) }

    val dirOptions = when (selectedInstrument.productType) {
        ProductType.FIXED_FLOATING_SWAP -> listOf(
            TradeDirection.RECEIVE_FLOATING_PAY_FIXED to "Receive Floating",
            TradeDirection.PAY_FLOATING_RECEIVE_FIXED to "Pay Fixed"
        )
        ProductType.CALENDAR_SPREAD -> listOf(
            TradeDirection.BUY_SPREAD to "Buy spread",
            TradeDirection.SELL_SPREAD to "Sell spread"
        )
        else -> listOf(
            TradeDirection.BUY_OPTION to "Buy option",
            TradeDirection.SELL_OPTION to "Sell option"
        )
    }

    val unitPrice = selectedQuote?.executablePriceFor(direction) ?: selectedInstrument.indicativeModelValue
    val fees = selectedQuote?.fees ?: BigDecimal.ZERO
    val totalConsideration = QuantPayoffEngine.calculateTotalConsideration(contracts, unitPrice, fees)
    val requiredCollateral = PreTradeRiskEngine.estimateRequiredCollateral(selectedInstrument, contracts, unitPrice)

    AureomPanel(modifier = modifier) {
        // Header with directional segmented toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "TRADE TICKET",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
            )
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(InputSurface)
                    .border(1.dp, SteelBorder, RoundedCornerShape(5.dp))
            ) {
                dirOptions.forEach { (dirEnum, label) ->
                    val active = direction == dirEnum
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (active) CyanPrimary else Color.Transparent)
                            .clickable { onSelectDirection(dirEnum) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("ticket_dir_${dirEnum.name.lowercase()}")
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (active) CyanDarkText else TextSecondary,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)
        Spacer(modifier = Modifier.height(8.dp))

        // Instrument selector row
        TicketFieldRow(label = "Instrument") {
            Box {
                TicketDropdownBox(
                    text = "${selectedInstrument.shortName} (${selectedInstrument.contractVersion})",
                    onClick = { instMenuOpen = true },
                    testTag = "ticket_instrument_dropdown"
                )
                DropdownMenu(
                    expanded = instMenuOpen,
                    onDismissRequest = { instMenuOpen = false },
                    containerColor = PanelElevated
                ) {
                    instruments.forEach { inst ->
                        DropdownMenuItem(
                            text = { Text("${inst.shortName} (${inst.contractVersion})", color = TextPrimary) },
                            onClick = {
                                onSelectInstrument(inst.id)
                                instMenuOpen = false
                            }
                        )
                    }
                }
            }
        }

        // Contracts stepper
        TicketFieldRow(label = "Contracts") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(InputSurface)
                    .border(1.dp, SteelBorder, RoundedCornerShape(4.dp)),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = { onChangeContracts(contracts - 1) },
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("contracts_dec_btn")
                ) {
                    Icon(Icons.Outlined.Remove, contentDescription = "Decrease contracts", tint = TextSecondary, modifier = Modifier.size(14.dp))
                }
                Text(
                    text = contracts.toString(),
                    style = MonoTextStyle.copy(color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.testTag("ticket_contracts_value")
                )
                IconButton(
                    onClick = { onChangeContracts(contracts + 1) },
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("contracts_inc_btn")
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "Increase contracts", tint = CyanPrimary, modifier = Modifier.size(14.dp))
                }
            }
        }

        TicketFieldRow(label = "Quote type") {
            TicketReadonlyBox(
                text = if (selectedQuote != null) "Firm Quote v${selectedQuote.version}" else "Dealer RFQ"
            )
        }

        // Counterparty selector
        TicketFieldRow(label = "Counterparty") {
            val cptyLabel = counterparties.find { it.id == selectedCounterpartyId }?.name ?: "Select eligible dealer"
            Box {
                TicketDropdownBox(
                    text = cptyLabel,
                    onClick = { cptyMenuOpen = true },
                    testTag = "ticket_counterparty_dropdown"
                )
                DropdownMenu(
                    expanded = cptyMenuOpen,
                    onDismissRequest = { cptyMenuOpen = false },
                    containerColor = PanelElevated
                ) {
                    DropdownMenuItem(
                        text = { Text("All eligible dealers (RFQ)", color = CyanPrimary) },
                        onClick = {
                            onSelectCounterparty(null)
                            cptyMenuOpen = false
                        }
                    )
                    counterparties.forEach { cpty ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (cpty.isPermitted) cpty.name else "${cpty.name} (Restricted)",
                                    color = if (cpty.isPermitted) TextPrimary else NegativeCoral
                                )
                            },
                            onClick = {
                                onSelectCounterparty(cpty.id)
                                cptyMenuOpen = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider)
        Spacer(modifier = Modifier.height(6.dp))

        KeyValueRow(
            label = if (selectedQuote != null) "Firm price (${selectedQuote.priceBasis.unitSuffix})" else "Indicative premium",
            value = formatCurrency(unitPrice.multiply(BigDecimal(contracts)), currency),
            valueColor = if (selectedQuote != null) CyanPrimary else TextPrimary,
            isMono = true
        )
        if (selectedQuote != null) {
            KeyValueRow(
                label = "Dealer fees",
                value = formatCurrency(fees, currency, includeDecimals = true),
                isMono = true
            )
            KeyValueRow(
                label = "Total consideration",
                value = formatCurrency(totalConsideration, currency, includeDecimals = true),
                valueColor = TextPrimary,
                isMono = true
            )
            KeyValueRow(
                label = "Payment date",
                value = "18 Nov 2026 (T+2)",
                isMono = false
            )
        }
        KeyValueRow(
            label = "Collateral req.",
            value = formatCurrency(requiredCollateral, currency),
            valueColor = TextSecondary,
            isMono = true
        )
        KeyValueRow(
            label = "Settlement currency",
            value = currency.code,
            isMono = true
        )
        KeyValueRow(
            label = "Trade mode",
            value = "Simulation",
            valueColor = CyanPrimary,
            isMono = false
        )

        if (needsDualApproval && !dualApprovalGranted) {
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(
                onClick = { onToggleDualApproval(true) },
                border = BorderStroke(1.dp, WarningAmber),
                shape = RoundedCornerShape(5.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("grant_dual_approval_btn")
            ) {
                Text(
                    text = "Record Supervisor SoD Approval",
                    style = MaterialTheme.typography.labelMedium.copy(color = WarningAmber)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Primary CTA Progression: Request Quote -> Review Firm Quote -> Confirm Trade
        when {
            selectedQuote == null || stage == TicketStage.CONFIGURE_RFQ -> {
                Button(
                    onClick = onRequestQuote,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanPrimary,
                        contentColor = CyanDarkText
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("request_quote_button")
                ) {
                    Text(
                        text = "Request dealer quote",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = CyanDarkText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowForward,
                        contentDescription = null,
                        tint = CyanDarkText,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            stage == TicketStage.REVIEW_FIRM_QUOTE -> {
                Button(
                    onClick = onConfirmTrade,
                    enabled = canCommit,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PositiveGreen,
                        contentColor = CyanDarkText,
                        disabledContainerColor = SteelBorder,
                        disabledContentColor = TextMuted
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("confirm_trade_button")
                ) {
                    Text(
                        text = if (canCommit) "Confirm Trade (${selectedQuote.counterpartyName})" else "Resolve Pre-Trade Checks",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = onResetTicket,
                    border = BorderStroke(1.dp, SteelBorder),
                    shape = RoundedCornerShape(5.dp),
                    modifier = Modifier.fillMaxWidth().height(34.dp)
                ) {
                    Text("Clear staged quote", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                }
            }

            stage == TicketStage.CONFIRMED -> {
                Button(
                    onClick = onResetTicket,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanPrimary,
                        contentColor = CyanDarkText
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("new_ticket_button")
                ) {
                    Text(
                        text = "Trade Confirmed • Start New Ticket",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = CyanDarkText,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Review final terms before acceptance.",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontStyle = FontStyle.Italic,
                fontSize = 10.sp
            ),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun TicketFieldRow(
    label: String,
    control: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
            modifier = Modifier.weight(0.44f)
        )
        Box(modifier = Modifier.weight(0.56f)) {
            control()
        }
    }
}

@Composable
private fun TicketDropdownBox(
    text: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(InputSurface)
            .border(1.dp, SteelBorder, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.Outlined.KeyboardArrowDown,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(14.dp)
        )
    }
}

@Composable
private fun TicketReadonlyBox(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(InputSurface.copy(alpha = 0.7f))
            .border(1.dp, SteelDivider, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun PreTradeChecksCard(
    checks: List<PreTradeCheckItem>,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(
            title = "Pre-Trade Checks",
            trailing = {
                Text(
                    text = "Limits",
                    style = MaterialTheme.typography.labelSmall.copy(color = CyanPrimary),
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable(onClick = onOpenSettings)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        )
        Spacer(modifier = Modifier.height(6.dp))

        checks.forEach { check ->
            val (icon, tint) = when (check.outcome) {
                CheckOutcome.PASSED -> Icons.Outlined.CheckCircle to PositiveGreen
                CheckOutcome.FAILED -> Icons.Outlined.Cancel to NegativeCoral
                CheckOutcome.PENDING -> Icons.Outlined.AccessTime to WarningAmber
                CheckOutcome.NOT_APPLICABLE -> Icons.Outlined.AccessTime to TextMuted
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .testTag("pretrade_check_${check.code.lowercase()}"),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = check.outcome.label,
                    tint = tint,
                    modifier = Modifier
                        .padding(top = 1.dp)
                        .size(15.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = check.label,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (check.outcome == CheckOutcome.NOT_APPLICABLE) TextSecondary else TextPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Text(
                        text = check.explanation,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (check.outcome == CheckOutcome.FAILED) NegativeCoral else TextMuted,
                            fontSize = 10.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun PortfolioOverviewCard(
    portfolio: PortfolioSummary,
    collateral: CollateralSummary,
    currency: ReportingCurrency,
    modifier: Modifier = Modifier
) {
    AureomPanel(modifier = modifier) {
        PanelHeaderRow(title = "Portfolio Overview")
        Spacer(modifier = Modifier.height(8.dp))

        KeyValueRow(
            label = "Model value",
            value = formatCurrency(portfolio.totalModelValue, currency),
            isMono = true
        )
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        KeyValueRow(
            label = "Unrealised P&L",
            value = formatSignedCurrency(portfolio.totalUnrealisedPnl, currency),
            valueColor = if (portfolio.totalUnrealisedPnl >= BigDecimal.ZERO) PositiveGreen else NegativeCoral,
            isMono = true
        )
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        KeyValueRow(
            label = "Realised P&L",
            value = formatSignedCurrency(portfolio.totalRealisedPnl, currency),
            valueColor = if (portfolio.totalRealisedPnl >= BigDecimal.ZERO) PositiveGreen else NegativeCoral,
            isMono = true
        )
        HorizontalDivider(thickness = 0.5.dp, color = SteelDivider.copy(alpha = 0.6f))
        KeyValueRow(
            label = "Available collateral",
            value = formatCurrency(collateral.availableCollateral, currency),
            valueColor = TextPrimary,
            isMono = true
        )
        if (portfolio.excludedOrUnvaluedCount > 0) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${portfolio.excludedOrUnvaluedCount} position(s) excluded due to stale inputs.",
                style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Requirements depend on product and agreement.",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontStyle = FontStyle.Italic,
                fontSize = 10.sp
            )
        )
    }
}
