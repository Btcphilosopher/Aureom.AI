package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.ViewQuilt
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FeedHealth
import com.example.domain.model.ProductTab
import com.example.domain.model.ReportingCurrency
import com.example.domain.model.TopNavSection
import com.example.domain.model.WorkspaceLayoutConfig
import com.example.ui.theme.CyanBright
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.InputSurface
import com.example.ui.theme.MidnightHeader
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelNavy
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun TopHeaderBar(
    selectedSection: TopNavSection,
    onSelectSection: (TopNavSection) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    currency: ReportingCurrency,
    onCurrencyChange: (ReportingCurrency) -> Unit,
    savedLayouts: List<WorkspaceLayoutConfig>,
    activeLayout: WorkspaceLayoutConfig,
    onSelectLayout: (WorkspaceLayoutConfig) -> Unit,
    onOpenAssistant: () -> Unit,
    onOpenRiskSettings: () -> Unit,
    isCompact: Boolean
) {
    var currencyMenuOpen by remember { mutableStateOf(false) }
    var layoutMenuOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MidnightHeader)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand: Aureom globe & leaf + AUREOM DERIVATIVES / TRADING DESK
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onSelectSection(TopNavSection.TRADE) }
            ) {
                AureomGlobeLeafLogo(modifier = Modifier.size(30.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "AUREOM DERIVATIVES",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isCompact) 13.sp else 15.sp,
                            letterSpacing = 0.8.sp
                        )
                    )
                    Text(
                        text = "TRADING DESK",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontSize = 9.sp,
                            letterSpacing = 2.0.sp
                        )
                    )
                }
            }

            if (!isCompact) {
                Spacer(modifier = Modifier.width(12.dp))
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TopNavSection.entries.forEach { section ->
                        AureomNavTabChip(
                            label = section.label,
                            selected = section == selectedSection,
                            onClick = { onSelectSection(section) },
                            testTag = "top_nav_${section.name.lowercase()}"
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!isCompact) {
                    // Global search field
                    Row(
                        modifier = Modifier
                            .widthIn(min = 180.dp, max = 250.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(InputSurface)
                            .border(1.dp, SteelBorder, RoundedCornerShape(5.dp))
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "Global search",
                            tint = TextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "Search instruments, baskets, dealers...",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted),
                                    maxLines = 1
                                )
                            }
                            BasicTextField(
                                value = searchQuery,
                                onValueChange = onSearchChange,
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                                cursorBrush = SolidColor(CyanPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("global_search_input")
                            )
                        }
                    }
                }

                // Reporting currency selector
                Box {
                    Row(
                        modifier = Modifier
                            .height(32.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .clickable { currencyMenuOpen = true }
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currency.code,
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        )
                        Icon(
                            imageVector = Icons.Outlined.KeyboardArrowDown,
                            contentDescription = "Select reporting currency",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = currencyMenuOpen,
                        onDismissRequest = { currencyMenuOpen = false },
                        containerColor = PanelElevated
                    ) {
                        ReportingCurrency.entries.forEach { curr ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "${curr.code} (${curr.symbol})",
                                        color = if (curr == currency) CyanPrimary else TextPrimary
                                    )
                                },
                                onClick = {
                                    onCurrencyChange(curr)
                                    currencyMenuOpen = false
                                }
                            )
                        }
                    }
                }

                // Saved Layouts & Risk config icons on wider screens
                if (!isCompact) {
                    Box {
                        IconButton(
                            onClick = { layoutMenuOpen = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ViewQuilt,
                                contentDescription = "Saved workspace layouts",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        DropdownMenu(
                            expanded = layoutMenuOpen,
                            onDismissRequest = { layoutMenuOpen = false },
                            containerColor = PanelElevated
                        ) {
                            val presets = (savedLayouts + listOf(
                                WorkspaceLayoutConfig("Default 3-Pane"),
                                WorkspaceLayoutConfig("Focus Chart & Ticket", showLeftPane = false, leftWeight = 0f, centerWeight = 0.62f, rightWeight = 0.38f),
                                WorkspaceLayoutConfig("Explorer + Execution", showRightPane = true, showBottomPane = false)
                            )).distinctBy { it.name }
                            presets.forEach { cfg ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            cfg.name,
                                            color = if (cfg.name == activeLayout.name) CyanPrimary else TextPrimary
                                        )
                                    },
                                    onClick = {
                                        onSelectLayout(cfg)
                                        layoutMenuOpen = false
                                    }
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onOpenRiskSettings,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = "Pre-trade risk configuration",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Discreet Desk Assistant trigger
                IconButton(
                    onClick = onOpenAssistant,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("open_assistant_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = "Open Desk Assistant",
                        tint = CyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Persistent SIMULATION badge
                AureomBadge(
                    text = "SIMULATION",
                    borderColor = CyanPrimary,
                    textColor = CyanBright,
                    modifier = Modifier.testTag("simulation_badge")
                )
            }
        }

        // Compact phone navigation row
        if (isCompact) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TopNavSection.entries.forEach { section ->
                    AureomNavTabChip(
                        label = section.label,
                        selected = section == selectedSection,
                        onClick = { onSelectSection(section) },
                        testTag = "top_nav_${section.name.lowercase()}"
                    )
                }
            }
        }

        HorizontalDivider(thickness = 1.dp, color = SteelBorder)
    }
}

@Composable
fun ProductTabsBar(
    selectedTab: ProductTab,
    onSelectTab: (ProductTab) -> Unit,
    isCompact: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelNavy.copy(alpha = 0.6f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProductTab.entries.forEach { tab ->
                AureomNavTabChip(
                    label = tab.label,
                    selected = tab == selectedTab,
                    onClick = { onSelectTab(tab) },
                    testTag = "product_tab_${tab.name.lowercase()}"
                )
            }
        }
        if (!isCompact) {
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Synthetic instruments • No live execution",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontStyle = FontStyle.Italic
                )
            )
        }
    }
    HorizontalDivider(thickness = 1.dp, color = SteelDivider)
}

@Composable
fun StatusFooterBar(
    feedHealth: FeedHealth,
    lastUpdateText: String,
    onSimulateStale: () -> Unit,
    onReconnect: () -> Unit,
    isCompact: Boolean
) {
    val dotColor = when (feedHealth) {
        FeedHealth.HEALTHY -> PositiveGreen
        FeedHealth.STALE -> WarningAmber
        FeedHealth.RECONNECTING -> CyanPrimary
        FeedHealth.DISCONNECTED -> NegativeCoral
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MidnightHeader)
    ) {
        HorizontalDivider(thickness = 1.dp, color = SteelBorder)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (isCompact) {
                    "SIMULATION • SYNTHETIC PRICES"
                } else {
                    "DEMONSTRATION ONLY • SYNTHETIC PRICES • MODEL VALUES ARE NOT EXECUTABLE QUOTES"
                },
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                ),
                modifier = Modifier.weight(1f)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                )
                Text(
                    text = if (isCompact) feedHealth.label else "Workspace saved • ${feedHealth.label} ($lastUpdateText)",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextPrimary)
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = PanelElevated,
                    border = BorderStroke(1.dp, SteelBorder),
                    modifier = Modifier
                        .testTag("stream_toggle_button")
                        .clickable {
                            if (feedHealth == FeedHealth.HEALTHY) onSimulateStale() else onReconnect()
                        }
                ) {
                    Text(
                        text = if (feedHealth == FeedHealth.HEALTHY) "Test Stale" else "Reconnect",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (feedHealth == FeedHealth.HEALTHY) TextSecondary else CyanPrimary
                        ),
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }
        }
    }
}
