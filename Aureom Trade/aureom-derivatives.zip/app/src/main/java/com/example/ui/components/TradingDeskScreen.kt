package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.assistant.ProposedActionType
import com.example.domain.engine.PreTradeRiskEngine
import com.example.domain.model.CheckOutcome
import com.example.domain.model.QuoteStatus
import com.example.domain.model.SettlementEvent
import com.example.domain.model.TopNavSection
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.MidnightCanvas
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.TradingDeskUiState
import com.example.ui.viewmodel.TradingDeskViewModel
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private enum class CompactSubPane(val label: String) {
    MARKET("Market & Charts"),
    TICKET("Ticket & Risk"),
    PORTFOLIO("Positions & Cal")
}

@Composable
fun TradingDeskScreen(
    state: TradingDeskUiState,
    viewModel: TradingDeskViewModel
) {
    var pendingSettlementTarget by remember { mutableStateOf<Pair<SettlementEvent, Boolean>?>(null) }
    var compactSubPane by remember { mutableStateOf(CompactSubPane.MARKET) }

    val lastUpdateUtc = remember(state.lastStreamUpdateMillis) {
        SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date(state.lastStreamUpdateMillis))
    }

    val filteredInstruments = remember(state.instruments, state.globalSearchQuery) {
        if (state.globalSearchQuery.isBlank()) state.instruments
        else {
            val q = state.globalSearchQuery.trim().lowercase()
            state.instruments.filter {
                it.displayName.lowercase().contains(q) ||
                    it.explorerCode.lowercase().contains(q) ||
                    it.ticker.lowercase().contains(q)
            }
        }
    }

    Scaffold(
        containerColor = MidnightCanvas,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        modifier = Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown && keyEvent.isCtrlPressed) {
                    when (keyEvent.key) {
                        Key.One -> { viewModel.selectTopNav(TopNavSection.MARKETS); true }
                        Key.Two -> { viewModel.selectTopNav(TopNavSection.TRADE); true }
                        Key.Three -> { viewModel.selectTopNav(TopNavSection.RFQS); true }
                        Key.Four -> { viewModel.selectTopNav(TopNavSection.POSITIONS); true }
                        Key.Five -> { viewModel.selectTopNav(TopNavSection.COLLATERAL); true }
                        Key.Six -> { viewModel.selectTopNav(TopNavSection.SETTLEMENT); true }
                        Key.Seven -> { viewModel.selectTopNav(TopNavSection.REPORTS); true }
                        else -> false
                    }
                } else false
            }
    ) { _ ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(MidnightCanvas)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            val isExpanded = maxWidth >= 900.dp
            val isMedium = maxWidth in 600.dp..899.dp
            val isCompact = maxWidth < 600.dp

            Column(modifier = Modifier.fillMaxSize()) {
                TopHeaderBar(
                    selectedSection = state.topNavSection,
                    onSelectSection = viewModel::selectTopNav,
                    searchQuery = state.globalSearchQuery,
                    onSearchChange = viewModel::setGlobalSearch,
                    currency = state.reportingCurrency,
                    onCurrencyChange = viewModel::setReportingCurrency,
                    savedLayouts = state.savedLayouts,
                    activeLayout = state.activeLayout,
                    onSelectLayout = viewModel::applyAndSaveLayout,
                    onOpenAssistant = { viewModel.toggleAssistantSheet(true) },
                    onOpenRiskSettings = { viewModel.toggleRiskSettingsDialog(true) },
                    isCompact = isCompact
                )

                ProductTabsBar(
                    selectedTab = state.productTab,
                    onSelectTab = {
                        viewModel.selectProductTab(it)
                        viewModel.selectTopNav(TopNavSection.TRADE)
                    },
                    isCompact = isCompact
                )

                // Operational feedback banner
                if (state.statusBanner != null) {
                    val bannerColor = if (state.isBannerError) NegativeCoral else PositiveGreen
                    Surface(
                        color = bannerColor.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, bannerColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .testTag("status_feedback_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = state.statusBanner,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary),
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "Dismiss",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = bannerColor,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier
                                    .clickable { viewModel.dismissBanner() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                if (state.isLoading || state.selectedInstrument == null) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = CyanPrimary)
                    }
                } else {
                    val selectedInst = state.selectedInstrument!!
                    val canCommit = PreTradeRiskEngine.canCommitTrade(state.preTradeChecks)
                    val needsDual = state.preTradeChecks.any {
                        it.code == "APPROVALS" && it.outcome == CheckOutcome.PENDING
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(10.dp)
                    ) {
                        if (state.topNavSection != TopNavSection.TRADE) {
                            SecondarySectionWorkspace(
                                section = state.topNavSection,
                                state = state,
                                onSelectInstrumentAndTrade = { id ->
                                    viewModel.selectInstrument(id)
                                    viewModel.selectTopNav(TopNavSection.TRADE)
                                },
                                onToggleTradingPermission = viewModel::toggleInstrumentTradingPermission,
                                onOpenStructureImport = { viewModel.toggleStructureImportDialog(true) },
                                onStageQuoteAndTrade = { quote ->
                                    viewModel.stageQuoteInTicket(quote)
                                    viewModel.selectTopNav(TopNavSection.TRADE)
                                },
                                onCancelRfq = viewModel::cancelRfq,
                                onPostCollateral = viewModel::postCollateralMovement,
                                onObserveSettlement = { evt, isCorr ->
                                    pendingSettlementTarget = evt to isCorr
                                },
                                onAdvanceCashFlow = viewModel::advanceCashFlow,
                                onTestDuplicateAccept = {
                                    val acceptedOrFirst = state.quotes.firstOrNull { it.status == QuoteStatus.ACCEPTED }
                                        ?: state.activeQuotesForSelectedInstrument.firstOrNull()
                                    if (acceptedOrFirst != null) {
                                        viewModel.stageQuoteInTicket(acceptedOrFirst)
                                        viewModel.confirmAndExecuteQuote(idempotencyOverride = "dup-attempt-${System.currentTimeMillis()}")
                                    }
                                },
                                onTestExpiredQuote = viewModel::forceExpireSelectedOrTopQuote
                            )
                        } else if (isExpanded) {
                            // Faithful 3-Column Workstation + Bottom Row matching the attached screenshot
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    if (state.activeLayout.showLeftPane) {
                                        Column(
                                            modifier = Modifier.weight(state.activeLayout.leftWeight.coerceAtLeast(0.20f)),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            InstrumentExplorerCard(
                                                instruments = filteredInstruments,
                                                selectedInstrumentId = selectedInst.id,
                                                searchQuery = state.explorerSearchQuery,
                                                currency = state.reportingCurrency,
                                                onSearchChange = viewModel::setExplorerSearch,
                                                onSelectInstrument = viewModel::selectInstrument,
                                                onOpenStructureImport = { viewModel.toggleStructureImportDialog(true) }
                                            )
                                            ContractSnapshotCard(
                                                instrument = selectedInst,
                                                currency = state.reportingCurrency,
                                                onViewApprovedTerms = { viewModel.toggleTermSheetDialog(true) }
                                            )
                                        }
                                    }

                                    // Center Column
                                    Column(
                                        modifier = Modifier.weight(state.activeLayout.centerWeight),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        SelectedInstrumentHeaderCard(
                                            instrument = selectedInst,
                                            currency = state.reportingCurrency,
                                            onRevalueShift = viewModel::revalueSelectedInstrument
                                        )
                                        IndicativePremiumHistoryChart(
                                            series = selectedInst.historicalSeries,
                                            currency = state.reportingCurrency,
                                            isStale = selectedInst.isStaleModel
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            DealerRfqsPanel(
                                                quotes = state.activeQuotesForSelectedInstrument,
                                                selectedQuoteId = state.selectedQuoteId,
                                                serverNowMillis = state.serverNowMillis,
                                                currency = state.reportingCurrency,
                                                onSelectQuote = viewModel::stageQuoteInTicket,
                                                onForceExpireTop = viewModel::forceExpireSelectedOrTopQuote,
                                                modifier = Modifier.weight(1f)
                                            )
                                            ExpiryPayoffChart(
                                                instrument = selectedInst,
                                                payoffCurve = state.payoffCurve,
                                                showNetOverlay = state.showNetPayoffOverlay,
                                                onToggleNetOverlay = viewModel::toggleNetPayoffOverlay,
                                                currency = state.reportingCurrency,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }

                                    if (state.activeLayout.showRightPane) {
                                        Column(
                                            modifier = Modifier.weight(state.activeLayout.rightWeight),
                                            verticalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            TradeTicketCard(
                                                instruments = state.instruments,
                                                selectedInstrument = selectedInst,
                                                counterparties = state.counterparties,
                                                direction = state.ticketDirection,
                                                contracts = state.ticketContracts,
                                                selectedCounterpartyId = state.ticketCounterpartyId,
                                                selectedQuote = state.selectedQuote,
                                                stage = state.ticketStage,
                                                currency = state.reportingCurrency,
                                                canCommit = canCommit,
                                                needsDualApproval = needsDual,
                                                dualApprovalGranted = state.dualApprovalGranted,
                                                onSelectInstrument = viewModel::selectInstrument,
                                                onSelectDirection = viewModel::setTicketDirection,
                                                onChangeContracts = viewModel::setTicketContracts,
                                                onSelectCounterparty = viewModel::setTicketCounterparty,
                                                onRequestQuote = { viewModel.requestDealerQuote() },
                                                onConfirmTrade = { viewModel.confirmAndExecuteQuote() },
                                                onResetTicket = viewModel::resetTicketToConfigure,
                                                onToggleDualApproval = viewModel::toggleDualApproval
                                            )
                                            PreTradeChecksCard(
                                                checks = state.preTradeChecks,
                                                onOpenSettings = { viewModel.toggleRiskSettingsDialog(true) }
                                            )
                                            PortfolioOverviewCard(
                                                portfolio = state.portfolioSummary,
                                                collateral = state.collateralSummary,
                                                currency = state.reportingCurrency
                                            )
                                        }
                                    }
                                }

                                if (state.activeLayout.showBottomPane) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        BottomPositionsAndOpsCard(
                                            selectedTab = state.bottomTab,
                                            onSelectTab = viewModel::selectBottomTab,
                                            positions = state.positions,
                                            rfqs = state.rfqs,
                                            trades = state.trades,
                                            cashFlows = state.cashFlows,
                                            currency = state.reportingCurrency,
                                            onCancelRfq = viewModel::cancelRfq,
                                            onAdvanceCashFlow = viewModel::advanceCashFlow,
                                            modifier = Modifier.weight(0.64f)
                                        )
                                        SettlementCalendarCard(
                                            events = state.settlementEvents,
                                            onObserveAndSettle = { evt, isCorr ->
                                                pendingSettlementTarget = evt to isCorr
                                            },
                                            modifier = Modifier.weight(0.36f)
                                        )
                                    }
                                }
                            }
                        } else if (isMedium) {
                            // Tablet Portrait / Foldable 2-Column Layout
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                SelectedInstrumentHeaderCard(
                                    instrument = selectedInst,
                                    currency = state.reportingCurrency,
                                    onRevalueShift = viewModel::revalueSelectedInstrument
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(
                                        modifier = Modifier.weight(0.55f),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        InstrumentExplorerCard(
                                            instruments = filteredInstruments,
                                            selectedInstrumentId = selectedInst.id,
                                            searchQuery = state.explorerSearchQuery,
                                            currency = state.reportingCurrency,
                                            onSearchChange = viewModel::setExplorerSearch,
                                            onSelectInstrument = viewModel::selectInstrument,
                                            onOpenStructureImport = { viewModel.toggleStructureImportDialog(true) }
                                        )
                                        IndicativePremiumHistoryChart(
                                            series = selectedInst.historicalSeries,
                                            currency = state.reportingCurrency,
                                            isStale = selectedInst.isStaleModel
                                        )
                                        DealerRfqsPanel(
                                            quotes = state.activeQuotesForSelectedInstrument,
                                            selectedQuoteId = state.selectedQuoteId,
                                            serverNowMillis = state.serverNowMillis,
                                            currency = state.reportingCurrency,
                                            onSelectQuote = viewModel::stageQuoteInTicket,
                                            onForceExpireTop = viewModel::forceExpireSelectedOrTopQuote
                                        )
                                        ExpiryPayoffChart(
                                            instrument = selectedInst,
                                            payoffCurve = state.payoffCurve,
                                            showNetOverlay = state.showNetPayoffOverlay,
                                            onToggleNetOverlay = viewModel::toggleNetPayoffOverlay,
                                            currency = state.reportingCurrency
                                        )
                                    }
                                    Column(
                                        modifier = Modifier.weight(0.45f),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        TradeTicketCard(
                                            instruments = state.instruments,
                                            selectedInstrument = selectedInst,
                                            counterparties = state.counterparties,
                                            direction = state.ticketDirection,
                                            contracts = state.ticketContracts,
                                            selectedCounterpartyId = state.ticketCounterpartyId,
                                            selectedQuote = state.selectedQuote,
                                            stage = state.ticketStage,
                                            currency = state.reportingCurrency,
                                            canCommit = canCommit,
                                            needsDualApproval = needsDual,
                                            dualApprovalGranted = state.dualApprovalGranted,
                                            onSelectInstrument = viewModel::selectInstrument,
                                            onSelectDirection = viewModel::setTicketDirection,
                                            onChangeContracts = viewModel::setTicketContracts,
                                            onSelectCounterparty = viewModel::setTicketCounterparty,
                                            onRequestQuote = { viewModel.requestDealerQuote() },
                                            onConfirmTrade = { viewModel.confirmAndExecuteQuote() },
                                            onResetTicket = viewModel::resetTicketToConfigure,
                                            onToggleDualApproval = viewModel::toggleDualApproval
                                        )
                                        PreTradeChecksCard(
                                            checks = state.preTradeChecks,
                                            onOpenSettings = { viewModel.toggleRiskSettingsDialog(true) }
                                        )
                                        ContractSnapshotCard(
                                            instrument = selectedInst,
                                            currency = state.reportingCurrency,
                                            onViewApprovedTerms = { viewModel.toggleTermSheetDialog(true) }
                                        )
                                        PortfolioOverviewCard(
                                            portfolio = state.portfolioSummary,
                                            collateral = state.collateralSummary,
                                            currency = state.reportingCurrency
                                        )
                                    }
                                }
                                BottomPositionsAndOpsCard(
                                    selectedTab = state.bottomTab,
                                    onSelectTab = viewModel::selectBottomTab,
                                    positions = state.positions,
                                    rfqs = state.rfqs,
                                    trades = state.trades,
                                    cashFlows = state.cashFlows,
                                    currency = state.reportingCurrency,
                                    onCancelRfq = viewModel::cancelRfq,
                                    onAdvanceCashFlow = viewModel::advanceCashFlow
                                )
                                SettlementCalendarCard(
                                    events = state.settlementEvents,
                                    onObserveAndSettle = { evt, isCorr ->
                                        pendingSettlementTarget = evt to isCorr
                                    }
                                )
                            }
                        } else {
                            // Compact Phone Monitoring & Execution View
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                SelectedInstrumentHeaderCard(
                                    instrument = selectedInst,
                                    currency = state.reportingCurrency,
                                    onRevalueShift = viewModel::revalueSelectedInstrument
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    CompactSubPane.entries.forEach { pane ->
                                        AureomNavTabChip(
                                            label = pane.label,
                                            selected = pane == compactSubPane,
                                            onClick = { compactSubPane = pane },
                                            testTag = "compact_pane_${pane.name.lowercase()}",
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                when (compactSubPane) {
                                    CompactSubPane.MARKET -> {
                                        InstrumentExplorerCard(
                                            instruments = filteredInstruments,
                                            selectedInstrumentId = selectedInst.id,
                                            searchQuery = state.explorerSearchQuery,
                                            currency = state.reportingCurrency,
                                            onSearchChange = viewModel::setExplorerSearch,
                                            onSelectInstrument = viewModel::selectInstrument,
                                            onOpenStructureImport = { viewModel.toggleStructureImportDialog(true) }
                                        )
                                        IndicativePremiumHistoryChart(
                                            series = selectedInst.historicalSeries,
                                            currency = state.reportingCurrency,
                                            isStale = selectedInst.isStaleModel
                                        )
                                        ExpiryPayoffChart(
                                            instrument = selectedInst,
                                            payoffCurve = state.payoffCurve,
                                            showNetOverlay = state.showNetPayoffOverlay,
                                            onToggleNetOverlay = viewModel::toggleNetPayoffOverlay,
                                            currency = state.reportingCurrency
                                        )
                                        ContractSnapshotCard(
                                            instrument = selectedInst,
                                            currency = state.reportingCurrency,
                                            onViewApprovedTerms = { viewModel.toggleTermSheetDialog(true) }
                                        )
                                    }
                                    CompactSubPane.TICKET -> {
                                        DealerRfqsPanel(
                                            quotes = state.activeQuotesForSelectedInstrument,
                                            selectedQuoteId = state.selectedQuoteId,
                                            serverNowMillis = state.serverNowMillis,
                                            currency = state.reportingCurrency,
                                            onSelectQuote = viewModel::stageQuoteInTicket,
                                            onForceExpireTop = viewModel::forceExpireSelectedOrTopQuote
                                        )
                                        TradeTicketCard(
                                            instruments = state.instruments,
                                            selectedInstrument = selectedInst,
                                            counterparties = state.counterparties,
                                            direction = state.ticketDirection,
                                            contracts = state.ticketContracts,
                                            selectedCounterpartyId = state.ticketCounterpartyId,
                                            selectedQuote = state.selectedQuote,
                                            stage = state.ticketStage,
                                            currency = state.reportingCurrency,
                                            canCommit = canCommit,
                                            needsDualApproval = needsDual,
                                            dualApprovalGranted = state.dualApprovalGranted,
                                            onSelectInstrument = viewModel::selectInstrument,
                                            onSelectDirection = viewModel::setTicketDirection,
                                            onChangeContracts = viewModel::setTicketContracts,
                                            onSelectCounterparty = viewModel::setTicketCounterparty,
                                            onRequestQuote = { viewModel.requestDealerQuote() },
                                            onConfirmTrade = { viewModel.confirmAndExecuteQuote() },
                                            onResetTicket = viewModel::resetTicketToConfigure,
                                            onToggleDualApproval = viewModel::toggleDualApproval
                                        )
                                        PreTradeChecksCard(
                                            checks = state.preTradeChecks,
                                            onOpenSettings = { viewModel.toggleRiskSettingsDialog(true) }
                                        )
                                    }
                                    CompactSubPane.PORTFOLIO -> {
                                        PortfolioOverviewCard(
                                            portfolio = state.portfolioSummary,
                                            collateral = state.collateralSummary,
                                            currency = state.reportingCurrency
                                        )
                                        BottomPositionsAndOpsCard(
                                            selectedTab = state.bottomTab,
                                            onSelectTab = viewModel::selectBottomTab,
                                            positions = state.positions,
                                            rfqs = state.rfqs,
                                            trades = state.trades,
                                            cashFlows = state.cashFlows,
                                            currency = state.reportingCurrency,
                                            onCancelRfq = viewModel::cancelRfq,
                                            onAdvanceCashFlow = viewModel::advanceCashFlow
                                        )
                                        SettlementCalendarCard(
                                            events = state.settlementEvents,
                                            onObserveAndSettle = { evt, isCorr ->
                                                pendingSettlementTarget = evt to isCorr
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                StatusFooterBar(
                    feedHealth = state.feedHealth,
                    lastUpdateText = lastUpdateUtc,
                    onSimulateStale = viewModel::simulateStaleFeed,
                    onReconnect = viewModel::reconnectAndReconcileFeed,
                    isCompact = isCompact
                )
            }
        }
    }

    // Dialogs & Sheets
    if (state.showTermSheetDialog && state.selectedInstrument != null) {
        ApprovedTermsDialog(
            instrument = state.selectedInstrument!!,
            onTogglePermission = { enabled ->
                viewModel.toggleInstrumentTradingPermission(state.selectedInstrument!!.id, enabled)
            },
            onDismiss = { viewModel.toggleTermSheetDialog(false) }
        )
    }

    if (state.showStructureImportDialog) {
        StructureImportDialog(
            onImportValid = { grantPerm -> viewModel.importStructureDefinition(0, grantPerm) },
            onImportBroken = { viewModel.importStructureDefinition(1, false) },
            onDismiss = { viewModel.toggleStructureImportDialog(false) }
        )
    }

    if (state.showRiskSettingsDialog) {
        RiskSettingsDialog(
            riskConfig = state.riskConfig,
            onSave = viewModel::updateRiskConfig,
            onDismiss = { viewModel.toggleRiskSettingsDialog(false) }
        )
    }

    pendingSettlementTarget?.let { (evt, isCorrection) ->
        SettlementObservationDialog(
            event = evt,
            isCorrection = isCorrection,
            onConfirm = { indexVal ->
                viewModel.processSettlementObservation(evt.id, indexVal, isCorrection)
            },
            onDismiss = { pendingSettlementTarget = null }
        )
    }

    if (state.showAssistantSheet) {
        DeskAssistantDialog(
            response = state.assistantResponse,
            onSelectIntent = viewModel::queryAssistant,
            onExecuteProposedAction = { resp ->
                when (resp.proposedActionType) {
                    ProposedActionType.REQUEST_QUOTE -> viewModel.requestDealerQuote()
                    ProposedActionType.STAGE_QUOTE_IN_TICKET -> {
                        val q = state.quotes.find { it.id == resp.proposedQuoteId }
                        if (q != null) viewModel.stageQuoteInTicket(q)
                    }
                    ProposedActionType.NONE -> Unit
                }
                viewModel.toggleAssistantSheet(false)
            },
            onDismiss = { viewModel.toggleAssistantSheet(false) }
        )
    }
}
