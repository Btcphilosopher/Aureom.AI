package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AureomDarkColorScheme = darkColorScheme(
    primary = CyanPrimary,
    onPrimary = CyanDarkText,
    primaryContainer = CyanMutedFill,
    onPrimaryContainer = TextPrimary,
    secondary = EmeraldLeaf,
    onSecondary = CyanDarkText,
    tertiary = WarningAmber,
    onTertiary = CyanDarkText,
    background = MidnightCanvas,
    onBackground = TextPrimary,
    surface = PanelNavy,
    onSurface = TextPrimary,
    surfaceVariant = PanelElevated,
    onSurfaceVariant = TextSecondary,
    outline = SteelBorder,
    outlineVariant = SteelDivider,
    error = NegativeCoral,
    onError = CyanDarkText
)

@Composable
fun AureomTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AureomDarkColorScheme,
        typography = AureomTypography,
        content = content
    )
}
