package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanBright
import com.example.ui.theme.CyanDarkText
import com.example.ui.theme.CyanMutedFill
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLeaf
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.NegativeCoral
import com.example.ui.theme.PanelNavy
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.SteelBorder
import com.example.ui.theme.SteelDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun AureomPanel(
    modifier: Modifier = Modifier,
    borderColor: Color = SteelBorder,
    contentPadding: PaddingValues = PaddingValues(12.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = PanelNavy,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

@Composable
fun PanelHeaderRow(
    title: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (trailing != null) {
                trailing()
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(thickness = 1.dp, color = SteelDivider)
    }
}

@Composable
fun AureomBadge(
    text: String,
    borderColor: Color = CyanPrimary,
    fillColor: Color = CyanMutedFill.copy(alpha = 0.5f),
    textColor: Color = CyanBright,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(fillColor)
            .border(1.dp, borderColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                color = textColor,
                fontWeight = FontWeight.SemiBold
            ),
            maxLines = 1
        )
    }
}

@Composable
fun StatusPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = color,
                fontWeight = FontWeight.SemiBold
            ),
            maxLines = 1
        )
    }
}

@Composable
fun AureomNavTabChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(5.dp))
            .background(if (selected) CyanPrimary else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
                color = if (selected) CyanDarkText else TextSecondary,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.sp
            ),
            maxLines = 1
        )
    }
}

@Composable
fun KeyValueRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    isMono: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            style = if (isMono) {
                MonoTextStyle.copy(color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            } else {
                MaterialTheme.typography.bodyMedium.copy(color = valueColor, fontWeight = FontWeight.SemiBold)
            },
            maxLines = 1
        )
    }
}

@Composable
fun AureomGlobeLeafLogo(
    modifier: Modifier = Modifier.size(30.dp)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val radius = minOf(w, h) * 0.44f
        val center = Offset(w / 2f, h / 2f)

        // Outer glowing cyan globe circle
        drawCircle(
            color = CyanPrimary,
            radius = radius,
            center = center,
            style = Stroke(width = w * 0.065f)
        )
        // Latitude & meridian grid arcs inside globe
        drawLine(
            color = CyanPrimary.copy(alpha = 0.8f),
            start = Offset(center.x - radius, center.y),
            end = Offset(center.x + radius * 0.45f, center.y),
            strokeWidth = w * 0.04f
        )
        drawLine(
            color = CyanPrimary.copy(alpha = 0.8f),
            start = Offset(center.x, center.y - radius),
            end = Offset(center.x, center.y + radius * 0.35f),
            strokeWidth = w * 0.04f
        )
        drawArc(
            color = CyanPrimary.copy(alpha = 0.75f),
            startAngle = 115f,
            sweepAngle = 155f,
            useCenter = false,
            topLeft = Offset(center.x - radius * 0.55f, center.y - radius),
            size = Size(radius * 1.1f, radius * 2f),
            style = Stroke(width = w * 0.04f)
        )

        // Stylized emerald leaf sweeping across lower-right
        val leafPath = Path().apply {
            moveTo(center.x - radius * 0.35f, center.y + radius * 0.72f)
            quadraticTo(
                center.x + radius * 0.1f, center.y + radius * 0.05f,
                center.x + radius * 0.96f, center.y - radius * 0.25f
            )
            quadraticTo(
                center.x + radius * 0.85f, center.y + radius * 0.85f,
                center.x - radius * 0.35f, center.y + radius * 0.72f
            )
            close()
        }
        drawPath(
            path = leafPath,
            color = EmeraldLeaf.copy(alpha = 0.28f)
        )
        drawPath(
            path = leafPath,
            color = EmeraldLeaf,
            style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
        )
        // Leaf center vein
        drawLine(
            color = EmeraldLeaf,
            start = Offset(center.x - radius * 0.15f, center.y + radius * 0.58f),
            end = Offset(center.x + radius * 0.68f, center.y - radius * 0.02f),
            strokeWidth = w * 0.04f,
            cap = StrokeCap.Round
        )
    }
}

fun outcomeColor(isPositive: Boolean?, isWarning: Boolean = false): Color = when {
    isWarning -> WarningAmber
    isPositive == true -> PositiveGreen
    isPositive == false -> NegativeCoral
    else -> TextMuted
}
