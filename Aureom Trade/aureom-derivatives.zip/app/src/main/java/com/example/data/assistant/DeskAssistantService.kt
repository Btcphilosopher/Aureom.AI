package com.example.data.assistant

import com.example.domain.engine.QuantPayoffEngine
import com.example.domain.model.CashFlowObligation
import com.example.domain.model.CollateralSummary
import com.example.domain.model.DealerQuote
import com.example.domain.model.Instrument
import com.example.domain.model.PortfolioSummary
import com.example.domain.model.Position
import com.example.domain.model.QuoteStatus
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.TradeDirection
import java.math.BigDecimal

enum class AssistantIntent(val label: String) {
    EXPLAIN_INSTRUMENT("Explain selected instrument"),
    COMPARE_QUOTES("Compare authorised quotes"),
    SUMMARISE_PORTFOLIO("Summarise portfolio & P&L"),
    EXPLAIN_VALUATION("Explain valuation & payoff"),
    APPROACHING_PAYMENTS("Identify approaching payments"),
    DRAFT_REVIEW_NOTE("Draft internal trade-review note")
}

enum class ProposedActionType {
    NONE,
    REQUEST_QUOTE,
    STAGE_QUOTE_IN_TICKET
}

data class AssistantResponse(
    val title: String,
    val body: String,
    val citations: List<String>,
    val warningBanner: String = "Advisory only — model values are not executable quotes. Human confirmation required for all actions.",
    val proposedActionLabel: String? = null,
    val proposedActionType: ProposedActionType = ProposedActionType.NONE,
    val proposedQuoteId: String? = null
)

object DeskAssistantService {

    fun generateResponse(
        intent: AssistantIntent,
        selectedInstrument: Instrument,
        direction: TradeDirection,
        quantity: Int,
        quotes: List<DealerQuote>,
        positions: List<Position>,
        portfolioSummary: PortfolioSummary,
        collateralSummary: CollateralSummary,
        cashFlows: List<CashFlowObligation>,
        settlementEvents: List<SettlementEvent>,
        serverNowMillis: Long
    ): AssistantResponse {
        return when (intent) {
            AssistantIntent.EXPLAIN_INSTRUMENT -> {
                val samplePayoff = QuantPayoffEngine.calculateGrossExpiryPayoff(
                    productType = selectedInstrument.productType,
                    direction = direction,
                    quantity = quantity,
                    multiplier = selectedInstrument.contractMultiplier,
                    strikeOrFixedRate = selectedInstrument.strikeOrFixedRate,
                    terminalReferenceIndex = selectedInstrument.strikeOrFixedRate.add(BigDecimal("4.00"))
                )
                AssistantResponse(
                    title = "${selectedInstrument.shortName} (${selectedInstrument.contractVersion})",
                    body = buildString {
                        appendLine("Product: ${selectedInstrument.productType.displayLabel} (${selectedInstrument.styleSubtitle}).")
                        appendLine("Origin: ${selectedInstrument.origin} | Term Sheet: ${selectedInstrument.termSheetVersion} | Approval: ${selectedInstrument.approvalStatus.label}.")
                        appendLine("Economics: Strike/Rate ${selectedInstrument.strikeOrFixedRate} ${selectedInstrument.strikeUnitLabel}, Multiplier $${selectedInstrument.contractMultiplier}/pt, Expiry ${selectedInstrument.expiryDisplay}.")
                        appendLine("Settlement Rule: ${selectedInstrument.settlementRules}.")
                        appendLine("Current Indicative Model Value: $${selectedInstrument.indicativeModelValue} (${selectedInstrument.priceBasis.label}) — NOT an executable dealer quote.")
                        append("Illustrative +4.00 pt move above strike yields $$samplePayoff gross payoff on $quantity contract(s) before premium & fees.")
                    },
                    citations = listOf(selectedInstrument.id, selectedInstrument.ticker, selectedInstrument.termSheetVersion)
                )
            }

            AssistantIntent.COMPARE_QUOTES -> {
                val activeFirm = quotes.filter {
                    it.isFirm && it.status == QuoteStatus.FIRM_ACTIVE && it.expiresAtMillis > serverNowMillis
                }
                if (activeFirm.isEmpty()) {
                    AssistantResponse(
                        title = "No active firm dealer quotes",
                        body = "No unexpired firm dealer quotes are active for ${selectedInstrument.shortName}. Indicative model value is $${selectedInstrument.indicativeModelValue}, which cannot be executed directly.",
                        citations = listOf(selectedInstrument.id),
                        proposedActionLabel = "Request Dealer Quote (requires approval)",
                        proposedActionType = ProposedActionType.REQUEST_QUOTE
                    )
                } else {
                    val best = when (direction) {
                        TradeDirection.BUY_OPTION,
                        TradeDirection.RECEIVE_FLOATING_PAY_FIXED,
                        TradeDirection.BUY_SPREAD -> activeFirm.minBy { it.askPrice.multiply(BigDecimal(quantity)).add(it.fees) }
                        TradeDirection.SELL_OPTION,
                        TradeDirection.PAY_FLOATING_RECEIVE_FIXED,
                        TradeDirection.SELL_SPREAD -> activeFirm.maxBy { it.bidPrice.multiply(BigDecimal(quantity)).subtract(it.fees) }
                    }
                    val lines = activeFirm.joinToString("\n") { q ->
                        val px = q.executablePriceFor(direction)
                        val total = QuantPayoffEngine.calculateTotalConsideration(quantity, px, q.fees)
                        val remSec = ((q.expiresAtMillis - serverNowMillis) / 1000L).coerceAtLeast(0L)
                        "• ${q.counterpartyName} (${q.id} v${q.version}): Exec $$px | Fees $${q.fees} | Total $$total | Valid ${remSec}s"
                    }
                    AssistantResponse(
                        title = "Authorised Firm Quote Comparison (${activeFirm.size} active)",
                        body = "Compared against Indicative Model $${selectedInstrument.indicativeModelValue}:\n$lines\n\nBest executable quote: ${best.counterpartyName} (${best.id}) at $${best.executablePriceFor(direction)}.",
                        citations = activeFirm.map { it.id } + selectedInstrument.id,
                        proposedActionLabel = "Stage ${best.counterpartyName} Quote in Ticket",
                        proposedActionType = ProposedActionType.STAGE_QUOTE_IN_TICKET,
                        proposedQuoteId = best.id
                    )
                }
            }

            AssistantIntent.SUMMARISE_PORTFOLIO -> {
                val openCount = positions.count { it.lifecycleStatus != "Settled" }
                AssistantResponse(
                    title = "Reconciled Portfolio Summary",
                    body = buildString {
                        appendLine("Open Positions: $openCount | Stale/Excluded: ${portfolioSummary.excludedOrUnvaluedCount}.")
                        appendLine("Total Model Value: $${portfolioSummary.totalModelValue} (reconciled from constituent records).")
                        appendLine("Unrealised P&L: $${portfolioSummary.totalUnrealisedPnl} | Realised P&L: $${portfolioSummary.totalRealisedPnl}.")
                        appendLine("Cash Flows: Paid $${portfolioSummary.totalPaidCashFlows} | Unpaid $${portfolioSummary.totalUnpaidCashFlows}.")
                        append("Collateral Ledger (separate from portfolio value): Posted $${collateralSummary.postedAfterHaircut} after haircut | Required IM $${collateralSummary.requiredInitialMargin} | Available $${collateralSummary.availableCollateral}.")
                    },
                    citations = positions.map { it.id }
                )
            }

            AssistantIntent.EXPLAIN_VALUATION -> {
                val assessment = QuantPayoffEngine.assessValuation(selectedInstrument, serverNowMillis)
                val statusMsg = if (assessment.isStale) {
                    "STALE WARNING: ${assessment.flagReason}"
                } else {
                    "Model ${assessment.modelVersion} fresh (${selectedInstrument.modelUpdatedUtc}); current reference index ${selectedInstrument.currentReferenceIndex}."
                }
                AssistantResponse(
                    title = "Valuation & Payoff Breakdown",
                    body = "$statusMsg\nFormula: ${selectedInstrument.settlementRules}\nMethodology: ${selectedInstrument.referenceMethodology}.",
                    citations = listOf(selectedInstrument.id, selectedInstrument.modelVersion)
                )
            }

            AssistantIntent.APPROACHING_PAYMENTS -> {
                val unpaid = cashFlows.filter {
                    it.state != SettlementState.PAID && it.state != SettlementState.RECONCILED
                }
                val scheduledEvents = settlementEvents.filter { it.state == SettlementState.SCHEDULED }
                val flowLines = if (unpaid.isEmpty()) "None" else unpaid.joinToString("\n") {
                    "• ${it.dueDate} | ${it.instrumentShortName} (${it.category}): $${it.amount} ${it.currency} [${it.state.label}] (${it.id})"
                }
                AssistantResponse(
                    title = "Approaching Payments & Calendar (${unpaid.size} open)",
                    body = "Unpaid Cash-Flow Obligations:\n$flowLines\n\nUpcoming Calendar Events: ${scheduledEvents.size} scheduled.",
                    citations = unpaid.map { it.id } + scheduledEvents.map { it.id }
                )
            }

            AssistantIntent.DRAFT_REVIEW_NOTE -> {
                val activeQuote = quotes.firstOrNull { it.status == QuoteStatus.FIRM_ACTIVE && it.expiresAtMillis > serverNowMillis }
                val quoteText = if (activeQuote != null) {
                    "Best firm quote ${activeQuote.id} from ${activeQuote.counterpartyName} at $${activeQuote.executablePriceFor(direction)} (fees $${activeQuote.fees})."
                } else {
                    "No firm quote currently active; model indicative reference is $${selectedInstrument.indicativeModelValue}."
                }
                AssistantResponse(
                    title = "Internal Trade-Review Note (Draft)",
                    body = "MEMO — AUREOM TRADING DESK (SIMULATION)\n" +
                        "Instrument: ${selectedInstrument.displayName} [${selectedInstrument.id} ${selectedInstrument.contractVersion}]\n" +
                        "Proposed Order: ${direction.label} x $quantity contracts\n" +
                        "Pricing Context: $quoteText\n" +
                        "Available Collateral: $${collateralSummary.availableCollateral}\n" +
                        "Note: Treated as untrusted draft pending pre-trade checks and trader confirmation.",
                    citations = listOfNotNull(selectedInstrument.id, activeQuote?.id)
                )
            }
        }
    }
}
