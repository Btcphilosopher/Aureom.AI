package com.example.data.repository

import com.example.data.db.AureomDao
import com.example.data.db.EntityMappers.toDomain
import com.example.data.db.EntityMappers.toEntity
import com.example.domain.engine.AureomStructureAdapter
import com.example.domain.engine.AureomStructureDefinition
import com.example.domain.engine.PositionAndPnlCalculator
import com.example.domain.engine.PreTradeRiskEngine
import com.example.domain.engine.QuantPayoffEngine
import com.example.domain.engine.SeedDataFactory
import com.example.domain.engine.StructureImportResult
import com.example.domain.model.AuditLogEntry
import com.example.domain.model.CashFlowObligation
import com.example.domain.model.CollateralAgreement
import com.example.domain.model.CollateralMovement
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.Counterparty
import com.example.domain.model.DealerQuote
import com.example.domain.model.FeedHealth
import com.example.domain.model.Instrument
import com.example.domain.model.Position
import com.example.domain.model.QuoteStatus
import com.example.domain.model.RfqRequest
import com.example.domain.model.RfqStatus
import com.example.domain.model.RiskConfiguration
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.Trade
import com.example.domain.model.TradeDirection
import com.example.domain.model.WorkspaceLayoutConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

sealed interface DeskOperationResult {
    data class Success(val message: String, val entityId: String? = null) : DeskOperationResult
    data class Rejected(val reason: String) : DeskOperationResult
}

data class DeskStreamEvent(
    val id: String,
    val type: String,
    val summary: String,
    val timestampMillis: Long
)

interface ServerClock {
    fun nowMillis(): Long
}

class SystemServerClock : ServerClock {
    override fun nowMillis(): Long = System.currentTimeMillis()
}

class TradingDeskRepository(
    private val dao: AureomDao,
    private val clock: ServerClock = SystemServerClock()
) {
    private val commitMutex = Mutex()

    private val _feedHealth = MutableStateFlow(FeedHealth.HEALTHY)
    val feedHealth: StateFlow<FeedHealth> = _feedHealth.asStateFlow()

    private val _lastStreamUpdateMillis = MutableStateFlow(clock.nowMillis())
    val lastStreamUpdateMillis: StateFlow<Long> = _lastStreamUpdateMillis.asStateFlow()

    private val _streamEvents = MutableSharedFlow<DeskStreamEvent>(extraBufferCapacity = 32)
    val streamEvents: SharedFlow<DeskStreamEvent> = _streamEvents.asSharedFlow()

    private val _counterparties = MutableStateFlow(SeedDataFactory.seedCounterparties())
    val counterparties: StateFlow<List<Counterparty>> = _counterparties.asStateFlow()

    fun observeInstruments(): Flow<List<Instrument>> =
        dao.observeInstruments().map { list -> list.map { it.toDomain() } }

    fun observeRfqs(orgId: String): Flow<List<RfqRequest>> =
        dao.observeRfqs(orgId).map { list -> list.map { it.toDomain() } }

    fun observeQuotes(): Flow<List<DealerQuote>> =
        dao.observeQuotes().map { list -> list.map { it.toDomain() } }

    fun observeTrades(orgId: String): Flow<List<Trade>> =
        dao.observeTrades(orgId).map { list -> list.map { it.toDomain() } }

    fun observePositions(orgId: String): Flow<List<Position>> =
        dao.observePositions(orgId).map { list -> list.map { it.toDomain() } }

    fun observeCashFlows(orgId: String): Flow<List<CashFlowObligation>> =
        dao.observeCashFlows(orgId).map { list -> list.map { it.toDomain() } }

    fun observeCollateralAgreements(orgId: String): Flow<List<CollateralAgreement>> =
        dao.observeCollateralAgreements(orgId).map { list -> list.map { it.toDomain() } }

    fun observeCollateralMovements(orgId: String): Flow<List<CollateralMovement>> =
        dao.observeCollateralMovements(orgId).map { list -> list.map { it.toDomain() } }

    fun observeSettlementEvents(orgId: String): Flow<List<SettlementEvent>> =
        dao.observeSettlementEvents(orgId).map { list -> list.map { it.toDomain() } }

    fun observeAuditLogs(orgId: String): Flow<List<AuditLogEntry>> =
        dao.observeAuditLogs(orgId).map { list -> list.map { it.toDomain() } }

    fun observeLayouts(): Flow<List<WorkspaceLayoutConfig>> =
        dao.observeLayouts().map { list -> list.map { it.toDomain() } }

    suspend fun ensureSeeded() {
        if (dao.countInstruments() > 0) {
            // Re-anchor seed quote expiry timers ONLY if nothing has been mutated? No — preserve authoritative DB state across restarts!
            return
        }
        val now = clock.nowMillis()
        val instruments = SeedDataFactory.seedInstruments(now)
        val instMap = instruments.associateBy { it.id }
        val trades = SeedDataFactory.seedTrades(now)
        val positions = trades.map { trade ->
            val inst = instMap[trade.instrumentId]
            val modelVal = inst?.indicativeModelValue ?: trade.executedPricePerContract
            PositionAndPnlCalculator.createPositionFromTrade(trade, modelVal)
        }
        val cashFlows = SeedDataFactory.seedCashFlows(now)
        val revaluedPositions = PositionAndPnlCalculator.revaluePositions(positions, instMap, cashFlows, now)

        dao.upsertInstruments(instruments.map { it.toEntity() })
        dao.upsertRfqs(SeedDataFactory.seedRfqs(now).map { it.toEntity() })
        dao.upsertQuotes(SeedDataFactory.seedQuotes(now).map { it.toEntity() })
        dao.upsertTrades(trades.map { it.toEntity() })
        dao.upsertPositions(revaluedPositions.map { it.toEntity() })
        dao.upsertCashFlows(cashFlows.map { it.toEntity() })
        dao.upsertCollateralAgreements(SeedDataFactory.seedCollateralAgreements().map { it.toEntity() })
        dao.upsertCollateralMovements(SeedDataFactory.seedCollateralMovements(now).map { it.toEntity() })
        dao.upsertSettlementEvents(SeedDataFactory.seedSettlementEvents().map { it.toEntity() })
        dao.insertAuditLogs(SeedDataFactory.seedAuditLogs(now).map { it.toEntity() })
        dao.upsertLayout(WorkspaceLayoutConfig("Default 3-Pane").toEntity())
        dao.upsertLayout(WorkspaceLayoutConfig("Focus Chart & Ticket", showLeftPane = false, leftWeight = 0f, centerWeight = 0.62f, rightWeight = 0.38f).toEntity())
        _lastStreamUpdateMillis.value = now
    }

    suspend fun importFromAureomStructure(
        definition: AureomStructureDefinition,
        grantTradingPermission: Boolean,
        orgId: String,
        actorRole: String
    ): DeskOperationResult {
        val now = clock.nowMillis()
        return when (val result = AureomStructureAdapter.importDefinition(definition, now, formatUtcTime(now))) {
            is StructureImportResult.Rejected -> {
                val msg = result.reasons.joinToString(" ")
                dao.insertAuditLog(
                    AuditLogEntry(
                        id = nextId("AUD"),
                        organisationId = orgId,
                        actorRole = actorRole,
                        action = "STRUCTURE_IMPORT_REJECTED",
                        entityType = "INSTRUMENT",
                        entityId = definition.id.ifBlank { "UNKNOWN" },
                        details = msg,
                        timestampMillis = now
                    ).toEntity()
                )
                DeskOperationResult.Rejected(msg)
            }
            is StructureImportResult.Imported -> {
                val inst = result.instrument.copy(tradingPermissionEnabled = grantTradingPermission)
                dao.upsertInstrument(inst.toEntity())
                dao.insertAuditLog(
                    AuditLogEntry(
                        id = nextId("AUD"),
                        organisationId = orgId,
                        actorRole = actorRole,
                        action = "STRUCTURE_IMPORT_ACCEPTED",
                        entityType = "INSTRUMENT",
                        entityId = inst.id,
                        details = "Imported ${inst.ticker} (${inst.contractVersion}); tradingPermission=$grantTradingPermission.",
                        timestampMillis = now
                    ).toEntity()
                )
                _streamEvents.tryEmit(DeskStreamEvent(nextId("EVT"), "STRUCTURE_IMPORT", "Imported ${inst.shortName} ${inst.contractVersion}", now))
                DeskOperationResult.Success("Imported ${inst.shortName} (${inst.contractVersion}) from Aureom Structure.", inst.id)
            }
        }
    }

    suspend fun setInstrumentTradingPermission(
        instrumentId: String,
        enabled: Boolean,
        orgId: String,
        actorRole: String
    ): DeskOperationResult {
        val existing = dao.getInstrumentById(instrumentId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Instrument not found.")
        val updated = existing.copy(tradingPermissionEnabled = enabled)
        dao.upsertInstrument(updated.toEntity())
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = if (enabled) "TRADING_PERMISSION_GRANTED" else "TRADING_PERMISSION_REVOKED",
                entityType = "INSTRUMENT",
                entityId = instrumentId,
                details = "${existing.ticker} (${existing.contractVersion}) permission=${enabled}.",
                timestampMillis = clock.nowMillis()
            ).toEntity()
        )
        return DeskOperationResult.Success("Trading permission ${if (enabled) "enabled" else "disabled"} for ${existing.shortName}.")
    }

    suspend fun requestDealerQuotes(
        idempotencyKey: String,
        instrumentId: String,
        direction: TradeDirection,
        quantity: Int,
        counterpartyIds: List<String>,
        quoteTtlSeconds: Long = 35L,
        riskConfig: RiskConfiguration
    ): DeskOperationResult {
        val now = clock.nowMillis()
        val existingRfq = dao.getRfqByIdempotencyKey(idempotencyKey)?.toDomain()
        if (existingRfq != null) {
            return DeskOperationResult.Success("Idempotent replay: existing RFQ ${existingRfq.id} returned.", existingRfq.id)
        }
        val inst = dao.getInstrumentById(instrumentId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Instrument $instrumentId not found.")
        if (_feedHealth.value != FeedHealth.HEALTHY) {
            return DeskOperationResult.Rejected("Cannot request quotes while stream is ${_feedHealth.value.label}. Reconnect first.")
        }
        if (quantity <= 0) {
            return DeskOperationResult.Rejected("Quantity must be at least 1 contract.")
        }

        val eligibleDealers = _counterparties.value.filter { it.id in counterpartyIds && it.isPermitted }
        if (eligibleDealers.isEmpty()) {
            return DeskOperationResult.Rejected("No permitted counterparties selected for RFQ.")
        }

        val rfqId = nextId("RFQ")
        val rfq = RfqRequest(
            id = rfqId,
            idempotencyKey = idempotencyKey,
            organisationId = riskConfig.organisationId,
            instrumentId = inst.id,
            instrumentShortName = inst.shortName,
            contractVersion = inst.contractVersion,
            direction = direction,
            quantity = quantity,
            eligibleCounterpartyIds = eligibleDealers.map { it.id },
            deadlineMillis = now + 180_000L,
            requestedTerms = "${inst.styleSubtitle} • ${inst.paymentSchedule}",
            status = RfqStatus.QUOTES_RECEIVED,
            createdAtMillis = now
        )

        // Generate synthetic firm quotes from fictional dealer adapters around indicative model value
        val base = inst.indicativeModelValue
        val newQuotes = eligibleDealers.mapIndexed { idx, cpty ->
            val spreadHalf = base.multiply(BigDecimal("0.022")).add(BigDecimal(idx * 150))
            val bid = base.subtract(spreadHalf).setScale(2, RoundingMode.HALF_UP)
            val ask = base.add(spreadHalf).setScale(2, RoundingMode.HALF_UP)
            val fee = BigDecimal(150 + idx * 25).setScale(2, RoundingMode.HALF_UP)
            DealerQuote(
                id = nextId("QT"),
                rfqId = rfqId,
                version = 1,
                counterpartyId = cpty.id,
                counterpartyName = cpty.name,
                direction = direction,
                quantity = quantity,
                bidPrice = bid,
                askPrice = ask,
                priceBasis = inst.priceBasis,
                fees = fee,
                currency = inst.currency,
                settlementTerms = "Cash T+2 (${inst.businessCalendar})",
                expiresAtMillis = now + (quoteTtlSeconds - idx * 4L).coerceAtLeast(10L) * 1000L,
                isFirm = true,
                status = QuoteStatus.FIRM_ACTIVE,
                createdAtMillis = now
            )
        }

        dao.upsertRfq(rfq.toEntity())
        dao.upsertQuotes(newQuotes.map { it.toEntity() })
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = riskConfig.organisationId,
                actorRole = riskConfig.userRole,
                action = "RFQ_QUOTES_RECEIVED",
                entityType = "RFQ",
                entityId = rfqId,
                details = "Requested $quantity x ${inst.shortName} (${inst.contractVersion}); ${newQuotes.size} firm quotes received.",
                timestampMillis = now
            ).toEntity()
        )
        _streamEvents.tryEmit(DeskStreamEvent(nextId("EVT"), "RFQ_QUOTES", "Received ${newQuotes.size} firm quotes for $rfqId", now))
        return DeskOperationResult.Success("Received ${newQuotes.size} firm dealer quotes ($rfqId).", rfqId)
    }

    suspend fun expireElapsedQuotes(): Int {
        val now = clock.nowMillis()
        val quotes = dao.getQuotesSnapshot()
        val toExpire = quotes.filter {
            it.status == QuoteStatus.FIRM_ACTIVE.name && it.expiresAtMillis <= now
        }
        if (toExpire.isEmpty()) return 0
        val updated = toExpire.map { it.copy(status = QuoteStatus.EXPIRED.name) }
        dao.upsertQuotes(updated)

        // Update RFQs whose quotes are all expired
        val affectedRfqIds = updated.map { it.rfqId }.toSet()
        for (rfqId in affectedRfqIds) {
            val rfq = dao.getRfqById(rfqId)?.toDomain() ?: continue
            val rfqQuotes = dao.getQuotesForRfq(rfqId).map { it.toDomain() }
            if (rfq.status == RfqStatus.QUOTES_RECEIVED && rfqQuotes.none { it.status == QuoteStatus.FIRM_ACTIVE }) {
                dao.upsertRfq(rfq.copy(status = RfqStatus.EXPIRED).toEntity())
            }
        }
        return updated.size
    }

    suspend fun forceExpireQuoteForDemo(quoteId: String, orgId: String, actorRole: String): DeskOperationResult {
        val quote = dao.getQuoteById(quoteId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Quote $quoteId not found.")
        val now = clock.nowMillis()
        dao.upsertQuote(quote.copy(expiresAtMillis = now - 1000L, status = QuoteStatus.EXPIRED).toEntity())
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = "QUOTE_EXPIRED_SERVER_CLOCK",
                entityType = "QUOTE",
                entityId = quoteId,
                details = "Quote $quoteId from ${quote.counterpartyName} expired by server clock.",
                timestampMillis = now
            ).toEntity()
        )
        return DeskOperationResult.Success("Quote $quoteId marked EXPIRED.")
    }

    suspend fun cancelRfq(rfqId: String, orgId: String, actorRole: String): DeskOperationResult {
        return commitMutex.withLock {
            val rfq = dao.getRfqById(rfqId)?.toDomain()
                ?: return@withLock DeskOperationResult.Rejected("RFQ $rfqId not found.")
            if (rfq.status == RfqStatus.ACCEPTED) {
                return@withLock DeskOperationResult.Rejected("Cannot cancel RFQ $rfqId after trade acceptance.")
            }
            val now = clock.nowMillis()
            dao.upsertRfq(rfq.copy(status = RfqStatus.CANCELLED).toEntity())
            val quotes = dao.getQuotesForRfq(rfqId).map { it.toDomain() }
            val declined = quotes.filter { it.status == QuoteStatus.FIRM_ACTIVE }
                .map { it.copy(status = QuoteStatus.DECLINED).toEntity() }
            if (declined.isNotEmpty()) dao.upsertQuotes(declined)
            dao.insertAuditLog(
                AuditLogEntry(
                    id = nextId("AUD"),
                    organisationId = orgId,
                    actorRole = actorRole,
                    action = "RFQ_CANCELLED",
                    entityType = "RFQ",
                    entityId = rfqId,
                    details = "RFQ cancelled; ${declined.size} open quotes declined in audit trail.",
                    timestampMillis = now
                ).toEntity()
            )
            DeskOperationResult.Success("Cancelled $rfqId and preserved declined quotes in audit history.")
        }
    }

    /**
     * Atomic, idempotent quote acceptance with full server-time expiry, permission, limit, and collateral re-checks.
     */
    suspend fun acceptQuoteAtomic(
        idempotencyKey: String,
        quoteId: String,
        requestedQuantity: Int,
        availableCollateralUsd: BigDecimal,
        riskConfig: RiskConfiguration,
        dualApprovalGranted: Boolean
    ): DeskOperationResult {
        return commitMutex.withLock {
            val now = clock.nowMillis()
            val existingTrade = dao.getTradeByIdempotencyKey(idempotencyKey)?.toDomain()
            if (existingTrade != null) {
                return@withLock DeskOperationResult.Success(
                    "Idempotent replay: trade ${existingTrade.id} already committed.",
                    existingTrade.id
                )
            }

            val quote = dao.getQuoteById(quoteId)?.toDomain()
                ?: return@withLock DeskOperationResult.Rejected("Quote $quoteId not found.")
            val rfq = dao.getRfqById(quote.rfqId)?.toDomain()
                ?: return@withLock DeskOperationResult.Rejected("Parent RFQ ${quote.rfqId} not found.")
            val instrument = dao.getInstrumentById(rfq.instrumentId)?.toDomain()
                ?: return@withLock DeskOperationResult.Rejected("Instrument ${rfq.instrumentId} not found.")
            val counterparty = _counterparties.value.find { it.id == quote.counterpartyId }

            // Guard against duplicate acceptance, cancelled RFQ, expired quote, or overfill
            if (rfq.status == RfqStatus.ACCEPTED) {
                return@withLock DeskOperationResult.Rejected("Duplicate acceptance blocked: RFQ ${rfq.id} already accepted.")
            }
            if (rfq.status == RfqStatus.CANCELLED || rfq.status == RfqStatus.DECLINED) {
                return@withLock DeskOperationResult.Rejected("Acceptance blocked: RFQ ${rfq.id} is ${rfq.status.label}.")
            }
            if (quote.status != QuoteStatus.FIRM_ACTIVE) {
                return@withLock DeskOperationResult.Rejected("Acceptance blocked: quote $quoteId is ${quote.status}.")
            }
            if (quote.expiresAtMillis <= now) {
                dao.upsertQuote(quote.copy(status = QuoteStatus.EXPIRED).toEntity())
                return@withLock DeskOperationResult.Rejected("Acceptance blocked: quote $quoteId expired against server time.")
            }
            if (requestedQuantity > quote.quantity) {
                return@withLock DeskOperationResult.Rejected("Overfill blocked: requested $requestedQuantity > quoted ${quote.quantity}.")
            }

            val checks = PreTradeRiskEngine.evaluate(
                instrument = instrument,
                quantity = requestedQuantity,
                direction = rfq.direction,
                counterparty = counterparty,
                selectedQuote = quote,
                availableCollateralUsd = availableCollateralUsd,
                feedHealth = _feedHealth.value,
                riskConfig = riskConfig,
                serverNowMillis = now,
                dualApprovalGranted = dualApprovalGranted,
                isSimulationMode = true
            )
            if (!PreTradeRiskEngine.canCommitTrade(checks)) {
                val failures = checks.filter {
                    it.outcome == com.example.domain.model.CheckOutcome.FAILED ||
                        it.outcome == com.example.domain.model.CheckOutcome.PENDING
                }.joinToString("; ") { "${it.label}: ${it.explanation}" }
                dao.insertAuditLog(
                    AuditLogEntry(
                        id = nextId("AUD"),
                        organisationId = riskConfig.organisationId,
                        actorRole = riskConfig.userRole,
                        action = "TRADE_PRECHECK_BLOCKED",
                        entityType = "QUOTE",
                        entityId = quoteId,
                        details = failures,
                        timestampMillis = now
                    ).toEntity()
                )
                return@withLock DeskOperationResult.Rejected("Pre-trade check failed: $failures")
            }

            val execPrice = quote.executablePriceFor(rfq.direction)
            val totalConsideration = QuantPayoffEngine.calculateTotalConsideration(
                quantity = requestedQuantity,
                pricePerContract = execPrice,
                fees = quote.fees
            )

            val tradeId = nextId("TRD")
            val trade = Trade(
                id = tradeId,
                idempotencyKey = idempotencyKey,
                organisationId = riskConfig.organisationId,
                rfqId = rfq.id,
                quoteId = quote.id,
                instrumentId = instrument.id,
                instrumentShortName = instrument.shortName,
                contractVersion = rfq.contractVersion,
                productType = instrument.productType,
                direction = rfq.direction,
                quantity = requestedQuantity,
                multiplier = instrument.contractMultiplier,
                strikeOrFixedRate = instrument.strikeOrFixedRate,
                executedPricePerContract = execPrice,
                priceBasis = quote.priceBasis,
                fees = quote.fees,
                totalConsideration = totalConsideration,
                currency = quote.currency,
                counterpartyId = quote.counterpartyId,
                counterpartyName = quote.counterpartyName,
                paymentDate = "2026-11-18",
                expiryDate = instrument.expiryDate,
                mode = "Simulation",
                executedAtMillis = now,
                status = "Confirmed"
            )

            val position = PositionAndPnlCalculator.createPositionFromTrade(
                trade = trade,
                currentModelValue = instrument.indicativeModelValue
            )

            val cashFlow = CashFlowObligation(
                id = nextId("CF"),
                organisationId = riskConfig.organisationId,
                tradeId = tradeId,
                instrumentShortName = instrument.shortName,
                category = "PREMIUM",
                amount = totalConsideration,
                currency = quote.currency,
                dueDate = "2026-11-18",
                counterpartyName = quote.counterpartyName,
                state = SettlementState.SCHEDULED,
                reconciliationRef = null,
                updatedAtMillis = now
            )

            val settlementEvent = SettlementEvent(
                id = nextId("SET"),
                organisationId = riskConfig.organisationId,
                tradeId = tradeId,
                dateIso = instrument.expiryDate,
                displayDate = instrument.expiryDisplay.take(6),
                eventLabel = "Expiry settlement (${instrument.shortName})",
                eventCategory = "EXPIRY",
                instrumentShortName = instrument.shortName,
                calendarRule = instrument.businessCalendar,
                timezoneRule = instrument.timezoneRule,
                observedIndex = null,
                calculatedPayoff = null,
                state = SettlementState.SCHEDULED,
                notes = "Contract ${instrument.contractVersion} • ${trade.id}"
            )

            val siblingQuotes = dao.getQuotesForRfq(rfq.id)
                .map { it.toDomain() }
                .filter { it.id != quote.id && it.status == QuoteStatus.FIRM_ACTIVE }
                .map { it.copy(status = QuoteStatus.SUPERSEDED).toEntity() }

            val audit = AuditLogEntry(
                id = nextId("AUD"),
                organisationId = riskConfig.organisationId,
                actorRole = riskConfig.userRole,
                action = "TRADE_EXECUTED",
                entityType = "TRADE",
                entityId = tradeId,
                details = "Accepted ${quote.id} (${quote.counterpartyName}) for $requestedQuantity x ${instrument.shortName} ${rfq.contractVersion} @ $$execPrice; Total $$totalConsideration.",
                timestampMillis = now
            )

            dao.commitAcceptedQuoteTransaction(
                rfq = rfq.copy(status = RfqStatus.ACCEPTED).toEntity(),
                acceptedQuote = quote.copy(status = QuoteStatus.ACCEPTED).toEntity(),
                supersededQuotes = siblingQuotes,
                trade = trade.toEntity(),
                position = position.toEntity(),
                cashFlow = cashFlow.toEntity(),
                settlementEvent = settlementEvent.toEntity(),
                auditLog = audit.toEntity()
            )

            // Update counterparty exposure in memory
            _counterparties.value = _counterparties.value.map { c ->
                if (c.id == quote.counterpartyId) {
                    c.copy(currentExposureUsd = c.currentExposureUsd.add(totalConsideration))
                } else c
            }

            _streamEvents.tryEmit(
                DeskStreamEvent(nextId("EVT"), "TRADE_COMMITTED", "Trade $tradeId booked (${instrument.shortName})", now)
            )
            DeskOperationResult.Success("Trade $tradeId committed; position ${position.id} and obligation ${cashFlow.id} created.", tradeId)
        }
    }

    suspend fun revalueInstrumentIndex(
        instrumentId: String,
        newReferenceIndex: BigDecimal,
        orgId: String,
        actorRole: String
    ): DeskOperationResult {
        val now = clock.nowMillis()
        val inst = dao.getInstrumentById(instrumentId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Instrument not found.")
        val updatedBase = inst.copy(
            modelInputsTimestampMillis = now,
            modelUpdatedUtc = formatUtcTime(now),
            isStaleModel = false
        )
        val assessment = QuantPayoffEngine.assessValuation(updatedBase, now, newReferenceIndex)
        val newVal = assessment.indicativeValuePerContract ?: inst.indicativeModelValue
        val updatedInst = updatedBase.copy(
            currentReferenceIndex = newReferenceIndex.setScale(2, RoundingMode.HALF_UP),
            indicativeModelValue = newVal,
            historicalSeries = (inst.historicalSeries + com.example.domain.model.ValuationPoint("Live", newVal, now)).takeLast(30)
        )
        dao.upsertInstrument(updatedInst.toEntity())
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = "INSTRUMENT_REVALUED",
                entityType = "INSTRUMENT",
                entityId = instrumentId,
                details = "Revalued ${inst.shortName} at index $newReferenceIndex -> model value $$newVal.",
                timestampMillis = now
            ).toEntity()
        )
        _lastStreamUpdateMillis.value = now
        return DeskOperationResult.Success("Revalued ${inst.shortName} to $$newVal (index $newReferenceIndex).")
    }

    suspend fun setFeedHealthState(
        health: FeedHealth,
        orgId: String,
        actorRole: String
    ) {
        val now = clock.nowMillis()
        _feedHealth.value = health
        if (health == FeedHealth.STALE || health == FeedHealth.DISCONNECTED) {
            val allInst = dao.getInstrumentsSnapshot().map { it.toDomain() }
            dao.upsertInstruments(allInst.map { it.copy(isStaleModel = true).toEntity() })
        } else if (health == FeedHealth.HEALTHY) {
            val allInst = dao.getInstrumentsSnapshot().map { it.toDomain() }
            dao.upsertInstruments(
                allInst.map {
                    it.copy(
                        isStaleModel = false,
                        modelInputsTimestampMillis = now,
                        modelUpdatedUtc = formatUtcTime(now)
                    ).toEntity()
                }
            )
            _lastStreamUpdateMillis.value = now
        }
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = "STREAM_STATE_${health.name}",
                entityType = "FEED",
                entityId = "MARKET_STREAM",
                details = "Market stream transitioned to ${health.label}.",
                timestampMillis = now
            ).toEntity()
        )
    }

    suspend fun postSimulatedCollateralTransfer(
        agreementId: String,
        assetType: String,
        grossAmount: BigDecimal,
        haircutPct: BigDecimal,
        movementType: CollateralMovementType,
        orgId: String,
        actorRole: String
    ): DeskOperationResult {
        if (grossAmount <= BigDecimal.ZERO) {
            return DeskOperationResult.Rejected("Transfer amount must be positive.")
        }
        val now = clock.nowMillis()
        val effective = grossAmount.multiply(BigDecimal.ONE.subtract(haircutPct.divide(BigDecimal("100"))))
            .setScale(2, RoundingMode.HALF_UP)
        val movement = CollateralMovement(
            id = nextId("COL"),
            organisationId = orgId,
            agreementId = agreementId,
            movementType = movementType,
            assetType = assetType,
            grossAmount = grossAmount.setScale(2, RoundingMode.HALF_UP),
            haircutPct = haircutPct.setScale(2, RoundingMode.HALF_UP),
            effectiveValue = effective,
            currency = "USD",
            isSimulated = true,
            status = if (movementType == CollateralMovementType.DISPUTE) "Disputed" else "Confirmed (Sim)",
            timestampMillis = now,
            notes = "Simulated ledger movement (${movementType.label})"
        )
        dao.upsertCollateralMovement(movement.toEntity())
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = "COLLATERAL_${movementType.name}",
                entityType = "COLLATERAL",
                entityId = movement.id,
                details = "${movementType.label} $$grossAmount $assetType (effective $$effective after $haircutPct% haircut).",
                timestampMillis = now
            ).toEntity()
        )
        return DeskOperationResult.Success("Recorded simulated collateral movement ${movement.id} ($$effective effective).")
    }

    suspend fun processExpiryObservationAndSettlement(
        settlementEventId: String,
        observedIndex: BigDecimal,
        isCorrection: Boolean,
        orgId: String,
        actorRole: String
    ): DeskOperationResult {
        val now = clock.nowMillis()
        val event = dao.getSettlementEventById(settlementEventId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Settlement event not found.")
        val trade = dao.getTradeById(event.tradeId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Trade ${event.tradeId} not found.")

        val grossPayoff = QuantPayoffEngine.calculateGrossExpiryPayoff(
            productType = trade.productType,
            direction = trade.direction,
            quantity = trade.quantity,
            multiplier = trade.multiplier,
            strikeOrFixedRate = trade.strikeOrFixedRate,
            terminalReferenceIndex = observedIndex
        )

        val updatedEvent = event.copy(
            observedIndex = observedIndex.setScale(2, RoundingMode.HALF_UP),
            calculatedPayoff = grossPayoff,
            state = SettlementState.CALCULATED,
            notes = if (isCorrection) "Corrected fixing to $observedIndex -> Payoff $$grossPayoff" else "Observed fixing $observedIndex -> Payoff $$grossPayoff"
        )
        dao.upsertSettlementEvent(updatedEvent.toEntity())

        // Create or update settlement cash flow obligation
        val cfId = "CF-SET-${event.id}"
        val settlementFlow = CashFlowObligation(
            id = cfId,
            organisationId = orgId,
            tradeId = trade.id,
            instrumentShortName = trade.instrumentShortName,
            category = "SETTLEMENT",
            amount = grossPayoff.abs(),
            currency = trade.currency,
            dueDate = event.dateIso,
            counterpartyName = trade.counterpartyName,
            state = SettlementState.CALCULATED,
            reconciliationRef = null,
            updatedAtMillis = now
        )
        dao.upsertCashFlow(settlementFlow.toEntity())

        // Update position lifecycle and realised P&L if expiry
        if (event.eventCategory == "EXPIRY") {
            val pos = dao.getPositionByTradeId(trade.id)?.toDomain()
            if (pos != null) {
                val netRealised = QuantPayoffEngine.calculateNetProfitAfterPremiumAndFees(
                    grossExpiryPayoff = grossPayoff,
                    direction = trade.direction,
                    quantity = trade.quantity,
                    premiumPerContract = trade.executedPricePerContract,
                    fees = trade.fees
                )
                dao.upsertPosition(
                    pos.copy(
                        lifecycleStatus = "Settled",
                        realisedPnl = netRealised,
                        unrealisedPnl = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
                    ).toEntity()
                )
            }
        }

        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = if (isCorrection) "OBSERVATION_CORRECTED" else "EXPIRY_SETTLEMENT_CALCULATED",
                entityType = "SETTLEMENT",
                entityId = settlementEventId,
                details = "Observed index $observedIndex on ${trade.id}; gross payoff $$grossPayoff.",
                timestampMillis = now
            ).toEntity()
        )
        return DeskOperationResult.Success("Settlement calculated: observed $observedIndex -> payoff $$grossPayoff.")
    }

    suspend fun advanceCashFlowState(
        cashFlowId: String,
        targetState: SettlementState,
        orgId: String,
        actorRole: String
    ): DeskOperationResult {
        val now = clock.nowMillis()
        val cf = dao.getCashFlowById(cashFlowId)?.toDomain()
            ?: return DeskOperationResult.Rejected("Cash flow $cashFlowId not found.")
        val reconRef = if (targetState == SettlementState.RECONCILED) "SIM-PAY-${cf.id.takeLast(4)}-${now % 10000}" else cf.reconciliationRef
        dao.upsertCashFlow(
            cf.copy(state = targetState, reconciliationRef = reconRef, updatedAtMillis = now).toEntity()
        )
        if (cf.id.startsWith("CF-SET-")) {
            val setId = cf.id.removePrefix("CF-SET-")
            val setEvt = dao.getSettlementEventById(setId)?.toDomain()
            if (setEvt != null) {
                dao.upsertSettlementEvent(setEvt.copy(state = targetState).toEntity())
            }
        }
        dao.insertAuditLog(
            AuditLogEntry(
                id = nextId("AUD"),
                organisationId = orgId,
                actorRole = actorRole,
                action = "CASHFLOW_${targetState.name}",
                entityType = "CASH_FLOW",
                entityId = cashFlowId,
                details = "Cash flow ${cf.id} (${cf.amount} ${cf.currency}) moved to ${targetState.label}.",
                timestampMillis = now
            ).toEntity()
        )
        return DeskOperationResult.Success("Cash flow ${cf.id} transitioned to ${targetState.label}.")
    }

    suspend fun saveWorkspaceLayout(config: WorkspaceLayoutConfig) {
        dao.upsertLayout(config.toEntity())
    }

    private fun formatUtcTime(millis: Long): String {
        val fmt = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return fmt.format(Date(millis))
    }

    private fun nextId(prefix: String): String =
        "$prefix-${UUID.randomUUID().toString().take(6).uppercase(Locale.US)}"
}

// Helper snapshot queries added cleanly via extension? Better to add directly to AureomDao!
