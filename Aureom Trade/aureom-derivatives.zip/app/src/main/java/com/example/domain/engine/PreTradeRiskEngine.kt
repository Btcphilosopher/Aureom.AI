package com.example.domain.engine

import com.example.domain.model.ApprovalStatus
import com.example.domain.model.CheckOutcome
import com.example.domain.model.Counterparty
import com.example.domain.model.DealerQuote
import com.example.domain.model.FeedHealth
import com.example.domain.model.Instrument
import com.example.domain.model.PreTradeCheckItem
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteStatus
import com.example.domain.model.RiskConfiguration
import com.example.domain.model.TradeDirection
import java.math.BigDecimal
import java.math.RoundingMode

object PreTradeRiskEngine {

    fun evaluate(
        instrument: Instrument,
        quantity: Int,
        direction: TradeDirection,
        counterparty: Counterparty?,
        selectedQuote: DealerQuote?,
        availableCollateralUsd: BigDecimal,
        feedHealth: FeedHealth,
        riskConfig: RiskConfiguration,
        serverNowMillis: Long,
        dualApprovalGranted: Boolean,
        isSimulationMode: Boolean = true
    ): List<PreTradeCheckItem> {
        val checks = mutableListOf<PreTradeCheckItem>()

        // 1. User authority
        val hasAuthority = riskConfig.userRole in setOf("SENIOR_TRADER", "HEAD_OF_DESK")
        checks += PreTradeCheckItem(
            code = "USER_AUTH",
            label = "User authority (${riskConfig.userRole})",
            outcome = if (hasAuthority) CheckOutcome.PASSED else CheckOutcome.FAILED,
            explanation = if (hasAuthority) "Trader authorised for simulated derivatives execution." else "Role lacks trading authority."
        )

        // 2. Organisation eligibility
        checks += PreTradeCheckItem(
            code = "ORG_ELIG",
            label = "Organisation eligibility (${riskConfig.organisationId})",
            outcome = if (riskConfig.organisationEligible) CheckOutcome.PASSED else CheckOutcome.FAILED,
            explanation = if (riskConfig.organisationEligible) "Organisation enabled on Aureom Trade desk." else "Organisation suspended."
        )

        // 3. Instrument status & trading permission
        val instrumentReady = instrument.approvalStatus == ApprovalStatus.APPROVED &&
            instrument.tradingPermissionEnabled
        checks += PreTradeCheckItem(
            code = "INST_STATUS",
            label = if (instrumentReady) "Product approved for simulation" else "Product approval / permission",
            outcome = if (instrumentReady) CheckOutcome.PASSED else CheckOutcome.FAILED,
            explanation = when {
                instrument.approvalStatus != ApprovalStatus.APPROVED ->
                    "Instrument status is ${instrument.approvalStatus.label}."
                !instrument.tradingPermissionEnabled ->
                    "Published from Aureom Structure but trading permission is not enabled."
                else -> "${instrument.approvalStatus.label} (${instrument.contractVersion}) with active desk permission."
            }
        )

        // 4. Product restrictions (Live vs Simulation)
        val modeAllowed = isSimulationMode || riskConfig.liveExecutionEnabled
        checks += PreTradeCheckItem(
            code = "PROD_RESTR",
            label = "Execution mode restriction",
            outcome = if (modeAllowed) CheckOutcome.PASSED else CheckOutcome.FAILED,
            explanation = if (modeAllowed) "Simulation mode active; live execution adapters disabled." else "Live execution adapter is disabled."
        )

        // 5. Counterparty permission
        checks += when {
            counterparty == null -> PreTradeCheckItem(
                code = "CPTY_PERM",
                label = "Counterparty permission available",
                outcome = CheckOutcome.PENDING,
                explanation = "Select an eligible dealer counterparty to verify Bilateral CSA."
            )
            !counterparty.isPermitted || instrument.productType !in counterparty.eligibleProductTypes -> PreTradeCheckItem(
                code = "CPTY_PERM",
                label = "Counterparty permission (${counterparty.name})",
                outcome = CheckOutcome.FAILED,
                explanation = "${counterparty.name} is not permitted for ${instrument.productType.displayLabel}."
            )
            else -> PreTradeCheckItem(
                code = "CPTY_PERM",
                label = "Counterparty permission available",
                outcome = CheckOutcome.PASSED,
                explanation = "${counterparty.name} approved under ${counterparty.csaAgreementId}."
            )
        }

        // 6. Quantity limits
        val qtyOk = quantity in 1..riskConfig.maxContractsPerOrder
        checks += PreTradeCheckItem(
            code = "QTY_LIMIT",
            label = "Quantity limit ($quantity / ${riskConfig.maxContractsPerOrder} max)",
            outcome = if (qtyOk) CheckOutcome.PASSED else CheckOutcome.FAILED,
            explanation = if (qtyOk) "Contract quantity within desk per-ticket limit." else "Quantity $quantity exceeds desk limit of ${riskConfig.maxContractsPerOrder}."
        )

        // 7. Quote validity & feed health
        checks += when {
            feedHealth != FeedHealth.HEALTHY -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Quote & market stream validity",
                outcome = CheckOutcome.FAILED,
                explanation = "Market feed is ${feedHealth.label}; reconcile state before trading."
            )
            selectedQuote == null -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Firm quote validity",
                outcome = CheckOutcome.PENDING,
                explanation = "Request and select a firm dealer quote before confirming."
            )
            !selectedQuote.isFirm -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Firm quote validity",
                outcome = CheckOutcome.FAILED,
                explanation = "Indicative values cannot be executed."
            )
            selectedQuote.status == QuoteStatus.EXPIRED || selectedQuote.expiresAtMillis <= serverNowMillis -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Firm quote expired",
                outcome = CheckOutcome.FAILED,
                explanation = "Quote ${selectedQuote.id} expired against server clock."
            )
            selectedQuote.status != QuoteStatus.FIRM_ACTIVE -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Firm quote status (${selectedQuote.status})",
                outcome = CheckOutcome.FAILED,
                explanation = "Quote is ${selectedQuote.status} and cannot be accepted again."
            )
            selectedQuote.quantity < quantity -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Quote quantity coverage",
                outcome = CheckOutcome.FAILED,
                explanation = "Requested $quantity exceeds quoted size ${selectedQuote.quantity}."
            )
            else -> PreTradeCheckItem(
                code = "QUOTE_VALID",
                label = "Firm quote v${selectedQuote.version} valid",
                outcome = CheckOutcome.PASSED,
                explanation = "Executable quote from ${selectedQuote.counterpartyName} active."
            )
        }

        // Estimate consideration & required collateral
        val pricePerContract = selectedQuote?.executablePriceFor(direction) ?: instrument.indicativeModelValue
        val fees = selectedQuote?.fees ?: BigDecimal("180.00")
        val totalConsideration = QuantPayoffEngine.calculateTotalConsideration(quantity, pricePerContract, fees)
        val requiredMargin = estimateRequiredCollateral(instrument, quantity, pricePerContract)

        // 8. Credit exposure
        checks += if (counterparty == null) {
            PreTradeCheckItem(
                code = "CREDIT_EXP",
                label = "Credit exposure check",
                outcome = CheckOutcome.PENDING,
                explanation = "Awaiting counterparty selection."
            )
        } else {
            val projected = counterparty.currentExposureUsd.add(totalConsideration)
            val withinLimit = projected <= counterparty.creditLimitUsd
            PreTradeCheckItem(
                code = "CREDIT_EXP",
                label = "Credit exposure vs limit",
                outcome = if (withinLimit) CheckOutcome.PASSED else CheckOutcome.FAILED,
                explanation = if (withinLimit) {
                    "Projected exposure $$projected within $$${counterparty.creditLimitUsd} limit."
                } else {
                    "Projected exposure $$projected breaches $$${counterparty.creditLimitUsd} credit limit."
                }
            )
        }

        // 9. Collateral availability (strictly separate from portfolio value!)
        checks += if (selectedQuote == null) {
            PreTradeCheckItem(
                code = "COLLAT_AVAIL",
                label = "Collateral check on final quote",
                outcome = CheckOutcome.PENDING,
                explanation = "Estimated requirement $$requiredMargin vs $$availableCollateralUsd available."
            )
        } else {
            val enoughCollateral = availableCollateralUsd >= requiredMargin
            PreTradeCheckItem(
                code = "COLLAT_AVAIL",
                label = "Collateral availability",
                outcome = if (enoughCollateral) CheckOutcome.PASSED else CheckOutcome.FAILED,
                explanation = if (enoughCollateral) {
                    "Available collateral $$availableCollateralUsd covers requirement $$requiredMargin."
                } else {
                    "Insufficient collateral: requires $$requiredMargin, available $$availableCollateralUsd."
                }
            )
        }

        // 10. Required approvals (Segregation of duties / dual-control threshold)
        val needsDualApproval = totalConsideration > riskConfig.dualApprovalNotionalThreshold
        checks += when {
            !needsDualApproval -> PreTradeCheckItem(
                code = "APPROVALS",
                label = "Dual-control approval",
                outcome = CheckOutcome.NOT_APPLICABLE,
                explanation = "Consideration $$totalConsideration below dual-approval threshold $$${riskConfig.dualApprovalNotionalThreshold}."
            )
            dualApprovalGranted -> PreTradeCheckItem(
                code = "APPROVALS",
                label = "Supervisor approval (SoD)",
                outcome = CheckOutcome.PASSED,
                explanation = "Independent risk supervisor approval recorded."
            )
            else -> PreTradeCheckItem(
                code = "APPROVALS",
                label = "Supervisor approval required",
                outcome = CheckOutcome.PENDING,
                explanation = "Consideration $$totalConsideration exceeds $$${riskConfig.dualApprovalNotionalThreshold}; requires second-pair approval."
            )
        }

        return checks
    }

    fun estimateRequiredCollateral(
        instrument: Instrument,
        quantity: Int,
        pricePerContract: BigDecimal
    ): BigDecimal {
        val grossNotional = pricePerContract.multiply(BigDecimal(quantity))
        val rate = when (instrument.productType) {
            ProductType.FIXED_FLOATING_SWAP -> BigDecimal("0.35")
            ProductType.CALENDAR_SPREAD -> BigDecimal("0.30")
            ProductType.EUROPEAN_CALL,
            ProductType.EUROPEAN_PUT,
            ProductType.BASKET_CALL,
            ProductType.CAP,
            ProductType.FLOOR -> BigDecimal("0.20")
        }
        return grossNotional.multiply(rate).setScale(2, RoundingMode.HALF_UP)
    }

    fun canCommitTrade(checks: List<PreTradeCheckItem>): Boolean {
        return checks.none { it.outcome == CheckOutcome.FAILED || it.outcome == CheckOutcome.PENDING }
    }
}
