package com.example.domain.engine

import com.example.domain.model.ApprovalStatus
import com.example.domain.model.Instrument
import com.example.domain.model.PriceBasis
import com.example.domain.model.ProductTab
import com.example.domain.model.ProductType
import com.example.domain.model.ValuationPoint
import java.math.BigDecimal

data class AureomStructureDefinition(
    val id: String,
    val ticker: String,
    val explorerCode: String,
    val displayName: String,
    val shortName: String,
    val contractVersion: String,
    val productType: ProductType?,
    val productTab: ProductTab,
    val styleSubtitle: String,
    val underlyingRef: String,
    val currency: String,
    val quantityUnit: String,
    val priceBasis: PriceBasis,
    val contractMultiplier: BigDecimal?,
    val strikeOrFixedRate: BigDecimal?,
    val strikeUnitLabel: String,
    val effectiveDate: String,
    val expiryDate: String,
    val expiryDisplay: String,
    val observationSchedule: String,
    val paymentSchedule: String,
    val settlementRules: String,
    val businessCalendar: String,
    val timezoneRule: String,
    val approvalStatus: ApprovalStatus,
    val termSheetVersion: String,
    val referenceMethodology: String,
    val indicativeModelValue: BigDecimal,
    val currentReferenceIndex: BigDecimal,
    val modelVersion: String,
    val historicalSeries: List<ValuationPoint>
)

sealed interface StructureImportResult {
    data class Imported(val instrument: Instrument) : StructureImportResult
    data class Rejected(val reasons: List<String>) : StructureImportResult
}

object AureomStructureAdapter {
    fun importDefinition(
        definition: AureomStructureDefinition,
        nowMillis: Long,
        updatedUtcLabel: String
    ): StructureImportResult {
        val errors = mutableListOf<String>()
        if (definition.id.isBlank() || definition.ticker.isBlank()) {
            errors += "Stable instrument identifier and ticker are required."
        }
        if (definition.contractVersion.isBlank()) {
            errors += "Contract version is required."
        }
        if (definition.productType == null) {
            errors += "Unsupported or missing product type."
        }
        if (definition.underlyingRef.isBlank() || definition.referenceMethodology.isBlank()) {
            errors += "Underlying reference and methodology must be specified."
        }
        if (definition.contractMultiplier == null || definition.contractMultiplier <= BigDecimal.ZERO) {
            errors += "Contract multiplier must be strictly positive."
        }
        if (definition.strikeOrFixedRate == null) {
            errors += "Strike or fixed rate is required."
        }
        if (definition.effectiveDate.isBlank() || definition.expiryDate.isBlank() ||
            definition.expiryDate <= definition.effectiveDate
        ) {
            errors += "Expiry date must be strictly after effective date."
        }
        if (definition.settlementRules.isBlank() || definition.observationSchedule.isBlank() ||
            definition.paymentSchedule.isBlank()
        ) {
            errors += "Observation, payment, and settlement rules are mandatory."
        }
        if (definition.currency.length != 3) {
            errors += "Currency must be a valid 3-letter ISO code."
        }
        if (errors.isNotEmpty()) {
            return StructureImportResult.Rejected(errors)
        }

        // Publishing makes an instrument discoverable, NEVER automatically grants trading permission.
        val instrument = Instrument(
            id = definition.id,
            ticker = definition.ticker,
            explorerCode = definition.explorerCode,
            displayName = definition.displayName,
            shortName = definition.shortName,
            contractVersion = definition.contractVersion,
            productType = definition.productType!!,
            productTab = definition.productTab,
            styleSubtitle = definition.styleSubtitle,
            underlyingRef = definition.underlyingRef,
            currency = definition.currency,
            quantityUnit = definition.quantityUnit,
            priceBasis = definition.priceBasis,
            contractMultiplier = definition.contractMultiplier!!,
            strikeOrFixedRate = definition.strikeOrFixedRate!!,
            strikeUnitLabel = definition.strikeUnitLabel,
            effectiveDate = definition.effectiveDate,
            expiryDate = definition.expiryDate,
            expiryDisplay = definition.expiryDisplay,
            observationSchedule = definition.observationSchedule,
            paymentSchedule = definition.paymentSchedule,
            settlementRules = definition.settlementRules,
            businessCalendar = definition.businessCalendar,
            timezoneRule = definition.timezoneRule,
            tradingPermissionEnabled = false,
            approvalStatus = definition.approvalStatus,
            termSheetVersion = definition.termSheetVersion,
            referenceMethodology = definition.referenceMethodology,
            origin = "Aureom Structure",
            modelVersion = definition.modelVersion,
            indicativeModelValue = definition.indicativeModelValue,
            modelInputsTimestampMillis = nowMillis,
            modelUpdatedUtc = updatedUtcLabel,
            currentReferenceIndex = definition.currentReferenceIndex,
            isStaleModel = false,
            historicalSeries = definition.historicalSeries
        )
        return StructureImportResult.Imported(instrument)
    }
}
