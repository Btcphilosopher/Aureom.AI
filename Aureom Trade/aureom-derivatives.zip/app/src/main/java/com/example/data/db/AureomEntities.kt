package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ApprovalStatus
import com.example.domain.model.AuditLogEntry
import com.example.domain.model.CashFlowObligation
import com.example.domain.model.CollateralAgreement
import com.example.domain.model.CollateralMovement
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.DealerQuote
import com.example.domain.model.Instrument
import com.example.domain.model.Position
import com.example.domain.model.PriceBasis
import com.example.domain.model.ProductTab
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteStatus
import com.example.domain.model.RfqRequest
import com.example.domain.model.RfqStatus
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.Trade
import com.example.domain.model.TradeDirection
import com.example.domain.model.ValuationPoint
import com.example.domain.model.WorkspaceLayoutConfig
import java.math.BigDecimal

@Entity(tableName = "instruments")
data class InstrumentEntity(
    @PrimaryKey val id: String,
    val ticker: String,
    val explorerCode: String,
    val displayName: String,
    val shortName: String,
    val contractVersion: String,
    val productType: String,
    val productTab: String,
    val styleSubtitle: String,
    val underlyingRef: String,
    val currency: String,
    val quantityUnit: String,
    val priceBasis: String,
    val contractMultiplier: String,
    val strikeOrFixedRate: String,
    val strikeUnitLabel: String,
    val effectiveDate: String,
    val expiryDate: String,
    val expiryDisplay: String,
    val observationSchedule: String,
    val paymentSchedule: String,
    val settlementRules: String,
    val businessCalendar: String,
    val timezoneRule: String,
    val tradingPermissionEnabled: Boolean,
    val approvalStatus: String,
    val termSheetVersion: String,
    val referenceMethodology: String,
    val origin: String,
    val modelVersion: String,
    val indicativeModelValue: String,
    val modelInputsTimestampMillis: Long,
    val modelUpdatedUtc: String,
    val currentReferenceIndex: String,
    val isStaleModel: Boolean,
    val historySerialized: String
)

@Entity(tableName = "rfqs")
data class RfqEntity(
    @PrimaryKey val id: String,
    val idempotencyKey: String,
    val organisationId: String,
    val instrumentId: String,
    val instrumentShortName: String,
    val contractVersion: String,
    val direction: String,
    val quantity: Int,
    val eligibleCounterpartyIdsCsv: String,
    val deadlineMillis: Long,
    val requestedTerms: String,
    val status: String,
    val createdAtMillis: Long
)

@Entity(tableName = "dealer_quotes")
data class DealerQuoteEntity(
    @PrimaryKey val id: String,
    val rfqId: String,
    val version: Int,
    val counterpartyId: String,
    val counterpartyName: String,
    val direction: String,
    val quantity: Int,
    val bidPrice: String,
    val askPrice: String,
    val priceBasis: String,
    val fees: String,
    val currency: String,
    val settlementTerms: String,
    val expiresAtMillis: Long,
    val isFirm: Boolean,
    val status: String,
    val createdAtMillis: Long
)

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey val id: String,
    val idempotencyKey: String,
    val organisationId: String,
    val rfqId: String,
    val quoteId: String,
    val instrumentId: String,
    val instrumentShortName: String,
    val contractVersion: String,
    val productType: String,
    val direction: String,
    val quantity: Int,
    val multiplier: String,
    val strikeOrFixedRate: String,
    val executedPricePerContract: String,
    val priceBasis: String,
    val fees: String,
    val totalConsideration: String,
    val currency: String,
    val counterpartyId: String,
    val counterpartyName: String,
    val paymentDate: String,
    val expiryDate: String,
    val mode: String,
    val executedAtMillis: Long,
    val status: String
)

@Entity(tableName = "positions")
data class PositionEntity(
    @PrimaryKey val id: String,
    val organisationId: String,
    val tradeId: String,
    val instrumentId: String,
    val instrumentShortName: String,
    val contractVersion: String,
    val productType: String,
    val direction: String,
    val quantity: Int,
    val multiplier: String,
    val entryPricePerContract: String,
    val currentModelValuePerContract: String,
    val feesPaid: String,
    val realisedPnl: String,
    val unrealisedPnl: String,
    val paidCashFlows: String,
    val unpaidCashFlows: String,
    val expiryDate: String,
    val counterpartyName: String,
    val lifecycleStatus: String
)

@Entity(tableName = "cash_flows")
data class CashFlowEntity(
    @PrimaryKey val id: String,
    val organisationId: String,
    val tradeId: String,
    val instrumentShortName: String,
    val category: String,
    val amount: String,
    val currency: String,
    val dueDate: String,
    val counterpartyName: String,
    val state: String,
    val reconciliationRef: String?,
    val updatedAtMillis: Long
)

@Entity(tableName = "collateral_agreements")
data class CollateralAgreementEntity(
    @PrimaryKey val id: String,
    val organisationId: String,
    val name: String,
    val counterpartyName: String,
    val eligibleAssetsCsv: String,
    val haircutPct: String,
    val nettingSetId: String,
    val independentAmount: String,
    val variationThreshold: String
)

@Entity(tableName = "collateral_movements")
data class CollateralMovementEntity(
    @PrimaryKey val id: String,
    val organisationId: String,
    val agreementId: String,
    val movementType: String,
    val assetType: String,
    val grossAmount: String,
    val haircutPct: String,
    val effectiveValue: String,
    val currency: String,
    val isSimulated: Boolean,
    val status: String,
    val timestampMillis: Long,
    val notes: String
)

@Entity(tableName = "settlement_events")
data class SettlementEventEntity(
    @PrimaryKey val id: String,
    val organisationId: String,
    val tradeId: String,
    val dateIso: String,
    val displayDate: String,
    val eventLabel: String,
    val eventCategory: String,
    val instrumentShortName: String,
    val calendarRule: String,
    val timezoneRule: String,
    val observedIndex: String?,
    val calculatedPayoff: String?,
    val state: String,
    val notes: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val organisationId: String,
    val actorRole: String,
    val action: String,
    val entityType: String,
    val entityId: String,
    val details: String,
    val timestampMillis: Long
)

@Entity(tableName = "workspace_layouts")
data class WorkspaceLayoutEntity(
    @PrimaryKey val name: String,
    val showLeftPane: Boolean,
    val showRightPane: Boolean,
    val showBottomPane: Boolean,
    val leftWeight: Float,
    val centerWeight: Float,
    val rightWeight: Float
)

object EntityMappers {
    private fun serializeHistory(points: List<ValuationPoint>): String =
        points.joinToString(";") { "${it.label}|${it.value.toPlainString()}|${it.timestampMillis}" }

    private fun deserializeHistory(raw: String): List<ValuationPoint> {
        if (raw.isBlank()) return emptyList()
        return raw.split(";").mapNotNull { entry ->
            val parts = entry.split("|")
            if (parts.size == 3) {
                ValuationPoint(
                    label = parts[0],
                    value = BigDecimal(parts[1]),
                    timestampMillis = parts[2].toLongOrNull() ?: 0L
                )
            } else null
        }
    }

    fun Instrument.toEntity() = InstrumentEntity(
        id, ticker, explorerCode, displayName, shortName, contractVersion,
        productType.name, productTab.name, styleSubtitle, underlyingRef, currency,
        quantityUnit, priceBasis.name, contractMultiplier.toPlainString(),
        strikeOrFixedRate.toPlainString(), strikeUnitLabel, effectiveDate, expiryDate,
        expiryDisplay, observationSchedule, paymentSchedule, settlementRules,
        businessCalendar, timezoneRule, tradingPermissionEnabled, approvalStatus.name,
        termSheetVersion, referenceMethodology, origin, modelVersion,
        indicativeModelValue.toPlainString(), modelInputsTimestampMillis, modelUpdatedUtc,
        currentReferenceIndex.toPlainString(), isStaleModel, serializeHistory(historicalSeries)
    )

    fun InstrumentEntity.toDomain() = Instrument(
        id, ticker, explorerCode, displayName, shortName, contractVersion,
        ProductType.valueOf(productType), ProductTab.valueOf(productTab), styleSubtitle,
        underlyingRef, currency, quantityUnit, PriceBasis.valueOf(priceBasis),
        BigDecimal(contractMultiplier), BigDecimal(strikeOrFixedRate), strikeUnitLabel,
        effectiveDate, expiryDate, expiryDisplay, observationSchedule, paymentSchedule,
        settlementRules, businessCalendar, timezoneRule, tradingPermissionEnabled,
        ApprovalStatus.valueOf(approvalStatus), termSheetVersion, referenceMethodology,
        origin, modelVersion, BigDecimal(indicativeModelValue), modelInputsTimestampMillis,
        modelUpdatedUtc, BigDecimal(currentReferenceIndex), isStaleModel,
        deserializeHistory(historySerialized)
    )

    fun RfqRequest.toEntity() = RfqEntity(
        id, idempotencyKey, organisationId, instrumentId, instrumentShortName, contractVersion,
        direction.name, quantity, eligibleCounterpartyIds.joinToString(","), deadlineMillis,
        requestedTerms, status.name, createdAtMillis
    )

    fun RfqEntity.toDomain() = RfqRequest(
        id, idempotencyKey, organisationId, instrumentId, instrumentShortName, contractVersion,
        TradeDirection.valueOf(direction), quantity,
        eligibleCounterpartyIdsCsv.split(",").filter { it.isNotBlank() },
        deadlineMillis, requestedTerms, RfqStatus.valueOf(status), createdAtMillis
    )

    fun DealerQuote.toEntity() = DealerQuoteEntity(
        id, rfqId, version, counterpartyId, counterpartyName, direction.name, quantity,
        bidPrice.toPlainString(), askPrice.toPlainString(), priceBasis.name, fees.toPlainString(),
        currency, settlementTerms, expiresAtMillis, isFirm, status.name, createdAtMillis
    )

    fun DealerQuoteEntity.toDomain() = DealerQuote(
        id, rfqId, version, counterpartyId, counterpartyName, TradeDirection.valueOf(direction),
        quantity, BigDecimal(bidPrice), BigDecimal(askPrice), PriceBasis.valueOf(priceBasis),
        BigDecimal(fees), currency, settlementTerms, expiresAtMillis, isFirm,
        QuoteStatus.valueOf(status), createdAtMillis
    )

    fun Trade.toEntity() = TradeEntity(
        id, idempotencyKey, organisationId, rfqId, quoteId, instrumentId, instrumentShortName,
        contractVersion, productType.name, direction.name, quantity, multiplier.toPlainString(),
        strikeOrFixedRate.toPlainString(), executedPricePerContract.toPlainString(), priceBasis.name,
        fees.toPlainString(), totalConsideration.toPlainString(), currency, counterpartyId,
        counterpartyName, paymentDate, expiryDate, mode, executedAtMillis, status
    )

    fun TradeEntity.toDomain() = Trade(
        id, idempotencyKey, organisationId, rfqId, quoteId, instrumentId, instrumentShortName,
        contractVersion, ProductType.valueOf(productType), TradeDirection.valueOf(direction),
        quantity, BigDecimal(multiplier), BigDecimal(strikeOrFixedRate),
        BigDecimal(executedPricePerContract), PriceBasis.valueOf(priceBasis), BigDecimal(fees),
        BigDecimal(totalConsideration), currency, counterpartyId, counterpartyName, paymentDate,
        expiryDate, mode, executedAtMillis, status
    )

    fun Position.toEntity() = PositionEntity(
        id, organisationId, tradeId, instrumentId, instrumentShortName, contractVersion,
        productType.name, direction.name, quantity, multiplier.toPlainString(),
        entryPricePerContract.toPlainString(), currentModelValuePerContract.toPlainString(),
        feesPaid.toPlainString(), realisedPnl.toPlainString(), unrealisedPnl.toPlainString(),
        paidCashFlows.toPlainString(), unpaidCashFlows.toPlainString(), expiryDate,
        counterpartyName, lifecycleStatus
    )

    fun PositionEntity.toDomain() = Position(
        id, organisationId, tradeId, instrumentId, instrumentShortName, contractVersion,
        ProductType.valueOf(productType), TradeDirection.valueOf(direction), quantity,
        BigDecimal(multiplier), BigDecimal(entryPricePerContract),
        BigDecimal(currentModelValuePerContract), BigDecimal(feesPaid), BigDecimal(realisedPnl),
        BigDecimal(unrealisedPnl), BigDecimal(paidCashFlows), BigDecimal(unpaidCashFlows),
        expiryDate, counterpartyName, lifecycleStatus
    )

    fun CashFlowObligation.toEntity() = CashFlowEntity(
        id, organisationId, tradeId, instrumentShortName, category, amount.toPlainString(),
        currency, dueDate, counterpartyName, state.name, reconciliationRef, updatedAtMillis
    )

    fun CashFlowEntity.toDomain() = CashFlowObligation(
        id, organisationId, tradeId, instrumentShortName, category, BigDecimal(amount),
        currency, dueDate, counterpartyName, SettlementState.valueOf(state),
        reconciliationRef, updatedAtMillis
    )

    fun CollateralAgreement.toEntity() = CollateralAgreementEntity(
        id, organisationId, name, counterpartyName, eligibleAssets.joinToString("|"),
        haircutPct.toPlainString(), nettingSetId, independentAmount.toPlainString(),
        variationThreshold.toPlainString()
    )

    fun CollateralAgreementEntity.toDomain() = CollateralAgreement(
        id, organisationId, name, counterpartyName,
        eligibleAssetsCsv.split("|").filter { it.isNotBlank() },
        BigDecimal(haircutPct), nettingSetId, BigDecimal(independentAmount),
        BigDecimal(variationThreshold)
    )

    fun CollateralMovement.toEntity() = CollateralMovementEntity(
        id, organisationId, agreementId, movementType.name, assetType,
        grossAmount.toPlainString(), haircutPct.toPlainString(), effectiveValue.toPlainString(),
        currency, isSimulated, status, timestampMillis, notes
    )

    fun CollateralMovementEntity.toDomain() = CollateralMovement(
        id, organisationId, agreementId, CollateralMovementType.valueOf(movementType),
        assetType, BigDecimal(grossAmount), BigDecimal(haircutPct), BigDecimal(effectiveValue),
        currency, isSimulated, status, timestampMillis, notes
    )

    fun SettlementEvent.toEntity() = SettlementEventEntity(
        id, organisationId, tradeId, dateIso, displayDate, eventLabel, eventCategory,
        instrumentShortName, calendarRule, timezoneRule,
        observedIndex?.toPlainString(), calculatedPayoff?.toPlainString(), state.name, notes
    )

    fun SettlementEventEntity.toDomain() = SettlementEvent(
        id, organisationId, tradeId, dateIso, displayDate, eventLabel, eventCategory,
        instrumentShortName, calendarRule, timezoneRule,
        observedIndex?.let { BigDecimal(it) }, calculatedPayoff?.let { BigDecimal(it) },
        SettlementState.valueOf(state), notes
    )

    fun AuditLogEntry.toEntity() = AuditLogEntity(
        id, organisationId, actorRole, action, entityType, entityId, details, timestampMillis
    )

    fun AuditLogEntity.toDomain() = AuditLogEntry(
        id, organisationId, actorRole, action, entityType, entityId, details, timestampMillis
    )

    fun WorkspaceLayoutConfig.toEntity() = WorkspaceLayoutEntity(
        name, showLeftPane, showRightPane, showBottomPane, leftWeight, centerWeight, rightWeight
    )

    fun WorkspaceLayoutEntity.toDomain() = WorkspaceLayoutConfig(
        name, showLeftPane, showRightPane, showBottomPane, leftWeight, centerWeight, rightWeight
    )
}
