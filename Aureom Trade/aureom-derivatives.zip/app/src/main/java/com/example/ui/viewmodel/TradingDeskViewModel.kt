package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.assistant.AssistantIntent
import com.example.data.assistant.AssistantResponse
import com.example.data.assistant.DeskAssistantService
import com.example.data.db.AureomDatabase
import com.example.data.repository.DeskOperationResult
import com.example.data.repository.DeskStreamEvent
import com.example.data.repository.SystemServerClock
import com.example.data.repository.TradingDeskRepository
import com.example.domain.engine.PositionAndPnlCalculator
import com.example.domain.engine.PreTradeRiskEngine
import com.example.domain.engine.QuantPayoffEngine
import com.example.domain.engine.SeedDataFactory
import com.example.domain.model.AuditLogEntry
import com.example.domain.model.BottomWorkspaceTab
import com.example.domain.model.CashFlowObligation
import com.example.domain.model.CollateralAgreement
import com.example.domain.model.CollateralMovement
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.CollateralSummary
import com.example.domain.model.Counterparty
import com.example.domain.model.DealerQuote
import com.example.domain.model.FeedHealth
import com.example.domain.model.Instrument
import com.example.domain.model.PayoffPoint
import com.example.domain.model.PortfolioSummary
import com.example.domain.model.Position
import com.example.domain.model.PreTradeCheckItem
import com.example.domain.model.ProductTab
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteStatus
import com.example.domain.model.ReportingCurrency
import com.example.domain.model.RfqRequest
import com.example.domain.model.RiskConfiguration
import com.example.domain.model.SettlementEvent
import com.example.domain.model.SettlementState
import com.example.domain.model.TopNavSection
import com.example.domain.model.Trade
import com.example.domain.model.TradeDirection
import com.example.domain.model.WorkspaceLayoutConfig
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

enum class TicketStage {
    CONFIGURE_RFQ,
    REVIEW_FIRM_QUOTE,
    CONFIRMED
}

data class TradingDeskUiState(
    val isLoading: Boolean = true,
    val topNavSection: TopNavSection = TopNavSection.TRADE,
    val productTab: ProductTab = ProductTab.OPTIONS,
    val bottomTab: BottomWorkspaceTab = BottomWorkspaceTab.POSITIONS,
    val reportingCurrency: ReportingCurrency = ReportingCurrency.USD,
    val globalSearchQuery: String = "",
    val explorerSearchQuery: String = "",
    val instruments: List<Instrument> = emptyList(),
    val selectedInstrumentId: String = "INST-HCB-CALL-MAR27",
    val counterparties: List<Counterparty> = emptyList(),
    val rfqs: List<RfqRequest> = emptyList(),
    val quotes: List<DealerQuote> = emptyList(),
    val trades: List<Trade> = emptyList(),
    val positions: List<Position> = emptyList(),
    val cashFlows: List<CashFlowObligation> = emptyList(),
    val collateralAgreements: List<CollateralAgreement> = emptyList(),
    val collateralMovements: List<CollateralMovement> = emptyList(),
    val settlementEvents: List<SettlementEvent> = emptyList(),
    val auditLogs: List<AuditLogEntry> = emptyList(),
    val savedLayouts: List<WorkspaceLayoutConfig> = emptyList(),
    val activeLayout: WorkspaceLayoutConfig = WorkspaceLayoutConfig("Default 3-Pane"),
    val ticketDirection: TradeDirection = TradeDirection.BUY_OPTION,
    val ticketContracts: Int = 2,
    val ticketCounterpartyId: String? = null,
    val selectedQuoteId: String? = null,
    val ticketStage: TicketStage = TicketStage.CONFIGURE_RFQ,
    val dualApprovalGranted: Boolean = false,
    val riskConfig: RiskConfiguration = RiskConfiguration(),
    val preTradeChecks: List<PreTradeCheckItem> = emptyList(),
    val portfolioSummary: PortfolioSummary = PortfolioSummary(
        BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, 0
    ),
    val collateralSummary: CollateralSummary = CollateralSummary(
        BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO
    ),
    val payoffCurve: List<PayoffPoint> = emptyList(),
    val showNetPayoffOverlay: Boolean = false,
    val feedHealth: FeedHealth = FeedHealth.HEALTHY,
    val lastStreamUpdateMillis: Long = System.currentTimeMillis(),
    val serverNowMillis: Long = System.currentTimeMillis(),
    val recentEvents: List<DeskStreamEvent> = emptyList(),
    val statusBanner: String? = null,
    val isBannerError: Boolean = false,
    val showTermSheetDialog: Boolean = false,
    val showAssistantSheet: Boolean = false,
    val assistantResponse: AssistantResponse? = null,
    val showRiskSettingsDialog: Boolean = false,
    val showStructureImportDialog: Boolean = false
) {
    val selectedInstrument: Instrument?
        get() = instruments.find { it.id == selectedInstrumentId } ?: instruments.firstOrNull()

    val activeQuotesForSelectedInstrument: List<DealerQuote>
        get() {
            val instId = selectedInstrument?.id ?: return emptyList()
            val matchingRfqIds = rfqs.filter { it.instrumentId == instId }.map { it.id }.toSet()
            return quotes.filter { it.rfqId in matchingRfqIds }
                .sortedWith(compareByDescending<DealerQuote> { it.status == QuoteStatus.FIRM_ACTIVE }.thenByDescending { it.createdAtMillis })
        }

    val selectedQuote: DealerQuote?
        get() = quotes.find { it.id == selectedQuoteId }
}

private data class NavFilterParams(
    val topNav: TopNavSection,
    val productTab: ProductTab,
    val bottomTab: BottomWorkspaceTab,
    val currency: ReportingCurrency,
    val globalSearch: String,
    val explorerSearch: String,
    val selectedInstId: String,
    val layout: WorkspaceLayoutConfig
)

private data class TicketParams(
    val direction: TradeDirection,
    val contracts: Int,
    val counterpartyId: String?,
    val selectedQuoteId: String?,
    val stage: TicketStage,
    val dualApprovalGranted: Boolean,
    val riskConfig: RiskConfiguration,
    val showNetPayoff: Boolean
)

private data class ModalParams(
    val showTermSheet: Boolean,
    val showAssistant: Boolean,
    val assistantResponse: AssistantResponse?,
    val showRiskSettings: Boolean,
    val showStructureImport: Boolean,
    val statusBanner: String?,
    val isBannerError: Boolean,
    val serverNowMillis: Long
)

class TradingDeskViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AureomDatabase.getInstance(application)
    private val clock = SystemServerClock()
    val repository = TradingDeskRepository(database.aureomDao(), clock)

    private val _navParams = MutableStateFlow(
        NavFilterParams(
            topNav = TopNavSection.TRADE,
            productTab = ProductTab.OPTIONS,
            bottomTab = BottomWorkspaceTab.POSITIONS,
            currency = ReportingCurrency.USD,
            globalSearch = "",
            explorerSearch = "",
            selectedInstId = "INST-HCB-CALL-MAR27",
            layout = WorkspaceLayoutConfig("Default 3-Pane")
        )
    )

    private val _ticketParams = MutableStateFlow(
        TicketParams(
            direction = TradeDirection.BUY_OPTION,
            contracts = 2,
            counterpartyId = null,
            selectedQuoteId = null,
            stage = TicketStage.CONFIGURE_RFQ,
            dualApprovalGranted = false,
            riskConfig = RiskConfiguration(),
            showNetPayoff = false
        )
    )

    private val _modalParams = MutableStateFlow(
        ModalParams(
            showTermSheet = false,
            showAssistant = false,
            assistantResponse = null,
            showRiskSettings = false,
            showStructureImport = false,
            statusBanner = null,
            isBannerError = false,
            serverNowMillis = clock.nowMillis()
        )
    )

    private val _recentEvents = MutableStateFlow<List<DeskStreamEvent>>(emptyList())

    private val orgId: String
        get() = _ticketParams.value.riskConfig.organisationId

    private val coreDataFlow = combine(
        repository.observeInstruments(),
        repository.observeRfqs("ORG-AUREOM-01"),
        repository.observeQuotes(),
        repository.observeTrades("ORG-AUREOM-01"),
        repository.observePositions("ORG-AUREOM-01")
    ) { instruments, rfqs, quotes, trades, positions ->
        CoreDataBundle(instruments, rfqs, quotes, trades, positions)
    }

    private val opsDataFlow = combine(
        repository.observeCashFlows("ORG-AUREOM-01"),
        repository.observeCollateralAgreements("ORG-AUREOM-01"),
        repository.observeCollateralMovements("ORG-AUREOM-01"),
        repository.observeSettlementEvents("ORG-AUREOM-01"),
        repository.observeAuditLogs("ORG-AUREOM-01")
    ) { cashFlows, agreements, movements, settlements, audits ->
        OpsDataBundle(cashFlows, agreements, movements, settlements, audits)
    }

    private val streamBundleFlow = combine(
        repository.counterparties,
        repository.feedHealth,
        repository.lastStreamUpdateMillis,
        repository.observeLayouts(),
        _recentEvents
    ) { cptys, health, lastUpd, layouts, events ->
        StreamBundle(cptys, health, lastUpd, layouts, events)
    }

    val uiState: StateFlow<TradingDeskUiState> = combine(
        coreDataFlow,
        opsDataFlow,
        streamBundleFlow,
        _navParams,
        _ticketParams,
        _modalParams
    ) { values ->
        val core = values[0] as CoreDataBundle
        val ops = values[1] as OpsDataBundle
        val stream = values[2] as StreamBundle
        val nav = values[3] as NavFilterParams
        val ticket = values[4] as TicketParams
        val modal = values[5] as ModalParams

        val instMap = core.instruments.associateBy { it.id }
        val selectedInst = instMap[nav.selectedInstId] ?: core.instruments.firstOrNull()
        val revaluedPositions = PositionAndPnlCalculator.revaluePositions(
            positions = core.positions,
            instrumentsById = instMap,
            cashFlows = ops.cashFlows,
            serverNowMillis = modal.serverNowMillis
        )
        val portfolioSummary = PositionAndPnlCalculator.summarizePortfolio(revaluedPositions)
        val collateralSummary = PositionAndPnlCalculator.summarizeCollateral(
            agreements = ops.agreements,
            movements = ops.movements,
            openPositions = revaluedPositions,
            instrumentsById = instMap
        )

        val selectedQuote = core.quotes.find { it.id == ticket.selectedQuoteId }
        val resolvedCounterparty = stream.counterparties.find {
            it.id == (selectedQuote?.counterpartyId ?: ticket.counterpartyId)
        }
        val checks = if (selectedInst != null) {
            PreTradeRiskEngine.evaluate(
                instrument = selectedInst,
                quantity = ticket.contracts,
                direction = ticket.direction,
                counterparty = resolvedCounterparty,
                selectedQuote = selectedQuote,
                availableCollateralUsd = collateralSummary.availableCollateral,
                feedHealth = stream.feedHealth,
                riskConfig = ticket.riskConfig,
                serverNowMillis = modal.serverNowMillis,
                dualApprovalGranted = ticket.dualApprovalGranted,
                isSimulationMode = true
            )
        } else emptyList()

        val payoffCurve = if (selectedInst != null) {
            val prem = selectedQuote?.executablePriceFor(ticket.direction) ?: selectedInst.indicativeModelValue
            val fees = selectedQuote?.fees ?: BigDecimal.ZERO
            QuantPayoffEngine.generatePayoffCurve(
                instrument = selectedInst,
                direction = ticket.direction,
                quantity = ticket.contracts,
                premiumPerContract = prem,
                fees = fees
            )
        } else emptyList()

        TradingDeskUiState(
            isLoading = core.instruments.isEmpty(),
            topNavSection = nav.topNav,
            productTab = nav.productTab,
            bottomTab = nav.bottomTab,
            reportingCurrency = nav.currency,
            globalSearchQuery = nav.globalSearch,
            explorerSearchQuery = nav.explorerSearch,
            instruments = core.instruments,
            selectedInstrumentId = selectedInst?.id ?: nav.selectedInstId,
            counterparties = stream.counterparties,
            rfqs = core.rfqs,
            quotes = core.quotes,
            trades = core.trades,
            positions = revaluedPositions,
            cashFlows = ops.cashFlows,
            collateralAgreements = ops.agreements,
            collateralMovements = ops.movements,
            settlementEvents = ops.settlementEvents,
            auditLogs = ops.audits,
            savedLayouts = stream.layouts,
            activeLayout = nav.layout,
            ticketDirection = ticket.direction,
            ticketContracts = ticket.contracts,
            ticketCounterpartyId = ticket.counterpartyId,
            selectedQuoteId = ticket.selectedQuoteId,
            ticketStage = ticket.stage,
            dualApprovalGranted = ticket.dualApprovalGranted,
            riskConfig = ticket.riskConfig,
            preTradeChecks = checks,
            portfolioSummary = portfolioSummary,
            collateralSummary = collateralSummary,
            payoffCurve = payoffCurve,
            showNetPayoffOverlay = ticket.showNetPayoff,
            feedHealth = stream.feedHealth,
            lastStreamUpdateMillis = stream.lastStreamUpdateMillis,
            serverNowMillis = modal.serverNowMillis,
            recentEvents = stream.recentEvents,
            statusBanner = modal.statusBanner,
            isBannerError = modal.isBannerError,
            showTermSheetDialog = modal.showTermSheet,
            showAssistantSheet = modal.showAssistant,
            assistantResponse = modal.assistantResponse,
            showRiskSettingsDialog = modal.showRiskSettings,
            showStructureImportDialog = modal.showStructureImport
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TradingDeskUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
        viewModelScope.launch {
            repository.streamEvents.collect { evt ->
                _recentEvents.value = (listOf(evt) + _recentEvents.value).take(20)
            }
        }
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                _modalParams.value = _modalParams.value.copy(serverNowMillis = clock.nowMillis())
                repository.expireElapsedQuotes()
            }
        }
    }

    fun selectTopNav(section: TopNavSection) {
        _navParams.value = _navParams.value.copy(topNav = section)
    }

    fun selectProductTab(tab: ProductTab) {
        val current = uiState.value
        val matchingInst = current.instruments.firstOrNull { it.productTab == tab }
        _navParams.value = _navParams.value.copy(
            productTab = tab,
            selectedInstId = matchingInst?.id ?: _navParams.value.selectedInstId
        )
        matchingInst?.let { syncDirectionForInstrument(it) }
    }

    fun selectInstrument(instrumentId: String) {
        val inst = uiState.value.instruments.find { it.id == instrumentId } ?: return
        _navParams.value = _navParams.value.copy(
            selectedInstId = instrumentId,
            productTab = inst.productTab
        )
        syncDirectionForInstrument(inst)
    }

    private fun syncDirectionForInstrument(inst: Instrument) {
        val defaultDir = when (inst.productType) {
            ProductType.FIXED_FLOATING_SWAP -> TradeDirection.RECEIVE_FLOATING_PAY_FIXED
            ProductType.CALENDAR_SPREAD -> TradeDirection.BUY_SPREAD
            else -> TradeDirection.BUY_OPTION
        }
        _ticketParams.value = _ticketParams.value.copy(
            direction = defaultDir,
            selectedQuoteId = null,
            stage = TicketStage.CONFIGURE_RFQ
        )
    }

    fun selectBottomTab(tab: BottomWorkspaceTab) {
        _navParams.value = _navParams.value.copy(bottomTab = tab)
    }

    fun setReportingCurrency(currency: ReportingCurrency) {
        _navParams.value = _navParams.value.copy(currency = currency)
    }

    fun setGlobalSearch(query: String) {
        _navParams.value = _navParams.value.copy(globalSearch = query)
    }

    fun setExplorerSearch(query: String) {
        _navParams.value = _navParams.value.copy(explorerSearch = query)
    }

    fun setTicketDirection(direction: TradeDirection) {
        _ticketParams.value = _ticketParams.value.copy(direction = direction)
    }

    fun setTicketContracts(count: Int) {
        val clamped = count.coerceIn(1, 500)
        _ticketParams.value = _ticketParams.value.copy(contracts = clamped)
    }

    fun setTicketCounterparty(counterpartyId: String?) {
        _ticketParams.value = _ticketParams.value.copy(counterpartyId = counterpartyId)
    }

    fun toggleNetPayoffOverlay() {
        _ticketParams.value = _ticketParams.value.copy(showNetPayoff = !_ticketParams.value.showNetPayoff)
    }

    fun toggleDualApproval(granted: Boolean) {
        _ticketParams.value = _ticketParams.value.copy(dualApprovalGranted = granted)
    }

    fun updateRiskConfig(maxContracts: Int, dualThreshold: BigDecimal, role: String) {
        _ticketParams.value = _ticketParams.value.copy(
            riskConfig = _ticketParams.value.riskConfig.copy(
                maxContractsPerOrder = maxContracts.coerceAtLeast(1),
                dualApprovalNotionalThreshold = dualThreshold,
                userRole = role
            )
        )
        setBanner("Updated pre-trade risk thresholds (Max $maxContracts contracts, Dual approval > $$dualThreshold).", false)
    }

    fun stageQuoteInTicket(quote: DealerQuote) {
        val rfq = uiState.value.rfqs.find { it.id == quote.rfqId }
        if (rfq != null) {
            _navParams.value = _navParams.value.copy(selectedInstId = rfq.instrumentId)
        }
        _ticketParams.value = _ticketParams.value.copy(
            selectedQuoteId = quote.id,
            counterpartyId = quote.counterpartyId,
            direction = quote.direction,
            contracts = quote.quantity,
            stage = TicketStage.REVIEW_FIRM_QUOTE
        )
        setBanner("Staged firm quote ${quote.id} from ${quote.counterpartyName} for review. Confirm terms to commit.", false)
    }

    fun resetTicketToConfigure() {
        _ticketParams.value = _ticketParams.value.copy(
            selectedQuoteId = null,
            stage = TicketStage.CONFIGURE_RFQ
        )
    }

    fun requestDealerQuote(customTtlSeconds: Long = 35L) {
        val state = uiState.value
        val inst = state.selectedInstrument ?: return
        val selectedCpty = state.ticketCounterpartyId
        val cptyIds = if (selectedCpty != null) {
            listOf(selectedCpty)
        } else {
            state.counterparties.filter { it.isPermitted }.map { it.id }
        }
        val idempKey = "rfq-${inst.id}-${state.ticketDirection}-${state.ticketContracts}-${System.currentTimeMillis() / 1000}"
        viewModelScope.launch {
            when (
                val res = repository.requestDealerQuotes(
                    idempotencyKey = idempKey,
                    instrumentId = inst.id,
                    direction = state.ticketDirection,
                    quantity = state.ticketContracts,
                    counterpartyIds = cptyIds,
                    quoteTtlSeconds = customTtlSeconds,
                    riskConfig = state.riskConfig
                )
            ) {
                is DeskOperationResult.Success -> {
                    // Auto-select top quote for review only (never executes trade automatically!)
                    setBanner(res.message, false)
                }
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun confirmAndExecuteQuote(idempotencyOverride: String? = null) {
        val state = uiState.value
        val quote = state.selectedQuote ?: run {
            setBanner("Select a firm dealer quote first.", true)
            return
        }
        val key = idempotencyOverride ?: "trade-${quote.id}-${state.ticketContracts}"
        viewModelScope.launch {
            when (
                val res = repository.acceptQuoteAtomic(
                    idempotencyKey = key,
                    quoteId = quote.id,
                    requestedQuantity = state.ticketContracts,
                    availableCollateralUsd = state.collateralSummary.availableCollateral,
                    riskConfig = state.riskConfig,
                    dualApprovalGranted = state.dualApprovalGranted
                )
            ) {
                is DeskOperationResult.Success -> {
                    _ticketParams.value = _ticketParams.value.copy(stage = TicketStage.CONFIRMED)
                    setBanner(res.message, false)
                }
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun importStructureDefinition(index: Int, grantPermission: Boolean) {
        val def = SeedDataFactory.structureCatalog().getOrNull(index) ?: return
        viewModelScope.launch {
            when (
                val res = repository.importFromAureomStructure(
                    definition = def,
                    grantTradingPermission = grantPermission,
                    orgId = orgId,
                    actorRole = _ticketParams.value.riskConfig.userRole
                )
            ) {
                is DeskOperationResult.Success -> {
                    res.entityId?.let { selectInstrument(it) }
                    setBanner(res.message, false)
                }
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun toggleInstrumentTradingPermission(instrumentId: String, enabled: Boolean) {
        viewModelScope.launch {
            when (
                val res = repository.setInstrumentTradingPermission(
                    instrumentId = instrumentId,
                    enabled = enabled,
                    orgId = orgId,
                    actorRole = _ticketParams.value.riskConfig.userRole
                )
            ) {
                is DeskOperationResult.Success -> setBanner(res.message, false)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun revalueSelectedInstrument(deltaIndex: BigDecimal) {
        val inst = uiState.value.selectedInstrument ?: return
        val newIndex = inst.currentReferenceIndex.add(deltaIndex)
        viewModelScope.launch {
            when (
                val res = repository.revalueInstrumentIndex(
                    instrumentId = inst.id,
                    newReferenceIndex = newIndex,
                    orgId = orgId,
                    actorRole = _ticketParams.value.riskConfig.userRole
                )
            ) {
                is DeskOperationResult.Success -> setBanner(res.message, false)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun simulateStaleFeed() {
        viewModelScope.launch {
            repository.setFeedHealthState(FeedHealth.STALE, orgId, _ticketParams.value.riskConfig.userRole)
            setBanner("Market stream marked STALE — valuations suspended and quote acceptance blocked until reconciled.", true)
        }
    }

    fun reconnectAndReconcileFeed() {
        viewModelScope.launch {
            repository.setFeedHealthState(FeedHealth.RECONNECTING, orgId, _ticketParams.value.riskConfig.userRole)
            delay(650L)
            repository.expireElapsedQuotes()
            repository.setFeedHealthState(FeedHealth.HEALTHY, orgId, _ticketParams.value.riskConfig.userRole)
            setBanner("Stream reconnected and state reconciled against authoritative database.", false)
        }
    }

    fun forceExpireSelectedOrTopQuote() {
        val state = uiState.value
        val quote = state.selectedQuote ?: state.activeQuotesForSelectedInstrument.firstOrNull() ?: return
        viewModelScope.launch {
            when (val res = repository.forceExpireQuoteForDemo(quote.id, orgId, state.riskConfig.userRole)) {
                is DeskOperationResult.Success -> setBanner(res.message, true)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun cancelRfq(rfqId: String) {
        viewModelScope.launch {
            when (val res = repository.cancelRfq(rfqId, orgId, _ticketParams.value.riskConfig.userRole)) {
                is DeskOperationResult.Success -> setBanner(res.message, false)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun postCollateralMovement(
        assetType: String,
        grossAmount: BigDecimal,
        haircutPct: BigDecimal,
        movementType: CollateralMovementType
    ) {
        val agreementId = uiState.value.collateralAgreements.firstOrNull()?.id ?: "CSA-NB-2026-A"
        viewModelScope.launch {
            when (
                val res = repository.postSimulatedCollateralTransfer(
                    agreementId = agreementId,
                    assetType = assetType,
                    grossAmount = grossAmount,
                    haircutPct = haircutPct,
                    movementType = movementType,
                    orgId = orgId,
                    actorRole = _ticketParams.value.riskConfig.userRole
                )
            ) {
                is DeskOperationResult.Success -> setBanner(res.message, false)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun processSettlementObservation(eventId: String, observedIndex: BigDecimal, isCorrection: Boolean) {
        viewModelScope.launch {
            when (
                val res = repository.processExpiryObservationAndSettlement(
                    settlementEventId = eventId,
                    observedIndex = observedIndex,
                    isCorrection = isCorrection,
                    orgId = orgId,
                    actorRole = _ticketParams.value.riskConfig.userRole
                )
            ) {
                is DeskOperationResult.Success -> setBanner(res.message, false)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun advanceCashFlow(cashFlowId: String, targetState: SettlementState) {
        viewModelScope.launch {
            when (
                val res = repository.advanceCashFlowState(
                    cashFlowId = cashFlowId,
                    targetState = targetState,
                    orgId = orgId,
                    actorRole = _ticketParams.value.riskConfig.userRole
                )
            ) {
                is DeskOperationResult.Success -> setBanner(res.message, false)
                is DeskOperationResult.Rejected -> setBanner(res.reason, true)
            }
        }
    }

    fun applyAndSaveLayout(layout: WorkspaceLayoutConfig) {
        _navParams.value = _navParams.value.copy(layout = layout)
        viewModelScope.launch {
            repository.saveWorkspaceLayout(layout)
            setBanner("Workspace layout '${layout.name}' saved.", false)
        }
    }

    fun toggleTermSheetDialog(show: Boolean) {
        _modalParams.value = _modalParams.value.copy(showTermSheet = show)
    }

    fun toggleRiskSettingsDialog(show: Boolean) {
        _modalParams.value = _modalParams.value.copy(showRiskSettings = show)
    }

    fun toggleStructureImportDialog(show: Boolean) {
        _modalParams.value = _modalParams.value.copy(showStructureImport = show)
    }

    fun toggleAssistantSheet(show: Boolean) {
        _modalParams.value = _modalParams.value.copy(showAssistant = show)
        if (show && _modalParams.value.assistantResponse == null) {
            queryAssistant(AssistantIntent.EXPLAIN_INSTRUMENT)
        }
    }

    fun queryAssistant(intent: AssistantIntent) {
        val state = uiState.value
        val inst = state.selectedInstrument ?: return
        val response = DeskAssistantService.generateResponse(
            intent = intent,
            selectedInstrument = inst,
            direction = state.ticketDirection,
            quantity = state.ticketContracts,
            quotes = state.activeQuotesForSelectedInstrument,
            positions = state.positions,
            portfolioSummary = state.portfolioSummary,
            collateralSummary = state.collateralSummary,
            cashFlows = state.cashFlows,
            settlementEvents = state.settlementEvents,
            serverNowMillis = state.serverNowMillis
        )
        _modalParams.value = _modalParams.value.copy(assistantResponse = response)
    }

    fun dismissBanner() {
        _modalParams.value = _modalParams.value.copy(statusBanner = null, isBannerError = false)
    }

    private fun setBanner(msg: String, isError: Boolean) {
        _modalParams.value = _modalParams.value.copy(statusBanner = msg, isBannerError = isError)
    }
}

private data class CoreDataBundle(
    val instruments: List<Instrument>,
    val rfqs: List<RfqRequest>,
    val quotes: List<DealerQuote>,
    val trades: List<Trade>,
    val positions: List<Position>
)

private data class OpsDataBundle(
    val cashFlows: List<CashFlowObligation>,
    val agreements: List<CollateralAgreement>,
    val movements: List<CollateralMovement>,
    val settlementEvents: List<SettlementEvent>,
    val audits: List<AuditLogEntry>
)

private data class StreamBundle(
    val counterparties: List<Counterparty>,
    val feedHealth: FeedHealth,
    val lastStreamUpdateMillis: Long,
    val layouts: List<WorkspaceLayoutConfig>,
    val recentEvents: List<DeskStreamEvent>
)

fun formatCurrency(amountUsd: BigDecimal, currency: ReportingCurrency, includeDecimals: Boolean = false): String {
    val converted = amountUsd.multiply(currency.fxFromUsd)
    val absVal = converted.abs().setScale(if (includeDecimals) 2 else 0, RoundingMode.HALF_UP)
    val nf = NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = if (includeDecimals) 2 else 0
        maximumFractionDigits = if (includeDecimals) 2 else 0
    }
    val formatted = nf.format(absVal)
    return if (converted < BigDecimal.ZERO) "-${currency.symbol}$formatted" else "${currency.symbol}$formatted"
}

fun formatSignedCurrency(amountUsd: BigDecimal, currency: ReportingCurrency): String {
    val converted = amountUsd.multiply(currency.fxFromUsd)
    val absVal = converted.abs().setScale(0, RoundingMode.HALF_UP)
    val nf = NumberFormat.getNumberInstance(Locale.US).apply {
        maximumFractionDigits = 0
    }
    val formatted = nf.format(absVal)
    return when {
        converted > BigDecimal.ZERO -> "+${currency.symbol}$formatted"
        converted < BigDecimal.ZERO -> "-${currency.symbol}$formatted"
        else -> "${currency.symbol}0"
    }
}
