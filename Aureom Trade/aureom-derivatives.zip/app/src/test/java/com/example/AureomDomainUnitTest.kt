package com.example

import com.example.data.assistant.AssistantIntent
import com.example.data.assistant.DeskAssistantService
import com.example.data.assistant.ProposedActionType
import com.example.domain.engine.AureomStructureAdapter
import com.example.domain.engine.PositionAndPnlCalculator
import com.example.domain.engine.PreTradeRiskEngine
import com.example.domain.engine.QuantPayoffEngine
import com.example.domain.engine.SeedDataFactory
import com.example.domain.engine.StructureImportResult
import com.example.domain.model.CheckOutcome
import com.example.domain.model.CollateralMovement
import com.example.domain.model.CollateralMovementType
import com.example.domain.model.FeedHealth
import com.example.domain.model.ProductType
import com.example.domain.model.QuoteStatus
import com.example.domain.model.RiskConfiguration
import com.example.domain.model.SettlementState
import com.example.domain.model.TradeDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class AureomDomainUnitTest {

    @Test
    fun `payoff boundaries and multiplier calculation follow N x M x max(I_T - K, 0)`() {
        val k = BigDecimal("102.00")
        val m = BigDecimal("10000.00")

        // Below strike: 0
        val below = QuantPayoffEngine.calculateGrossExpiryPayoff(
            ProductType.EUROPEAN_CALL, TradeDirection.BUY_OPTION, 2, m, k, BigDecimal("100.00")
        )
        assertEquals(BigDecimal("0.00"), below)

        // At strike: 0
        val atStrike = QuantPayoffEngine.calculateGrossExpiryPayoff(
            ProductType.EUROPEAN_CALL, TradeDirection.BUY_OPTION, 2, m, k, BigDecimal("102.00")
        )
        assertEquals(BigDecimal("0.00"), atStrike)

        // Above strike: 2 * 10000 * (106 - 102) = 80,000.00
        val above = QuantPayoffEngine.calculateGrossExpiryPayoff(
            ProductType.EUROPEAN_CALL, TradeDirection.BUY_OPTION, 2, m, k, BigDecimal("106.00")
        )
        assertEquals(BigDecimal("80000.00"), above)

        // Net profit after premium ($25,100 x 2 = $50,200) and fees ($180) = 80,000 - 50,200 - 180 = 29,620.00
        val net = QuantPayoffEngine.calculateNetProfitAfterPremiumAndFees(
            grossExpiryPayoff = above,
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            premiumPerContract = BigDecimal("25100.00"),
            fees = BigDecimal("180.00")
        )
        assertEquals(BigDecimal("29620.00"), net)
    }

    @Test
    fun `structure adapter rejects incomplete definition and defaults imported permission to false`() {
        val now = 1_700_000_000_000L
        val broken = SeedDataFactory.structureCatalog()[1]
        val rejected = AureomStructureAdapter.importDefinition(broken, now, "14:45:00 UTC")
        assertTrue(rejected is StructureImportResult.Rejected)

        val valid = SeedDataFactory.structureCatalog()[0]
        val imported = AureomStructureAdapter.importDefinition(valid, now, "14:45:00 UTC") as StructureImportResult.Imported
        assertFalse(imported.instrument.tradingPermissionEnabled)
    }

    @Test
    fun `stale valuation inputs are flagged instead of inventing prices`() {
        val now = 1_700_000_000_000L
        val inst = SeedDataFactory.seedInstruments(now).first()
            .copy(modelInputsTimestampMillis = now - 10 * 60 * 1000L)
        val assessment = QuantPayoffEngine.assessValuation(inst, now)
        assertTrue(assessment.isStale)
        assertNull(assessment.indicativeValuePerContract)
    }

    @Test
    fun `pre-trade checks reject unpermitted counterparty, excess quantity, and expired quote`() {
        val now = 1_700_000_000_000L
        val inst = SeedDataFactory.seedInstruments(now).first()
        val restrictedCpty = SeedDataFactory.seedCounterparties().last()
        val expiredQuote = SeedDataFactory.seedQuotes(now).first().copy(expiresAtMillis = now - 1000L)

        val checks = PreTradeRiskEngine.evaluate(
            instrument = inst,
            quantity = 30,
            direction = TradeDirection.BUY_OPTION,
            counterparty = restrictedCpty,
            selectedQuote = expiredQuote,
            availableCollateralUsd = BigDecimal("72000.00"),
            feedHealth = FeedHealth.HEALTHY,
            riskConfig = RiskConfiguration(maxContractsPerOrder = 25),
            serverNowMillis = now,
            dualApprovalGranted = false
        )
        assertFalse(PreTradeRiskEngine.canCommitTrade(checks))
        assertEquals(CheckOutcome.FAILED, checks.first { it.code == "CPTY_PERM" }.outcome)
        assertEquals(CheckOutcome.FAILED, checks.first { it.code == "QTY_LIMIT" }.outcome)
        assertEquals(CheckOutcome.FAILED, checks.first { it.code == "QUOTE_VALID" }.outcome)
    }

    @Test
    fun `portfolio and collateral reconcile accurately without double counting paid flows`() {
        val now = 1_700_000_000_000L
        val instruments = SeedDataFactory.seedInstruments(now)
        val instMap = instruments.associateBy { it.id }
        val trades = SeedDataFactory.seedTrades(now)
        val cashFlows = SeedDataFactory.seedCashFlows(now).mapIndexed { idx, cf ->
            if (idx == 0) cf.copy(state = SettlementState.RECONCILED) else cf
        }
        val rawPositions = trades.map { t ->
            PositionAndPnlCalculator.createPositionFromTrade(t, instMap[t.instrumentId]!!.indicativeModelValue)
        }
        val positions = PositionAndPnlCalculator.revaluePositions(rawPositions, instMap, cashFlows, now)
        val summary = PositionAndPnlCalculator.summarizePortfolio(positions)

        assertEquals(BigDecimal("88620.00"), summary.totalModelValue)
        assertEquals(BigDecimal("1640.00"), summary.totalUnrealisedPnl)
        assertEquals(BigDecimal("47980.00"), summary.totalPaidCashFlows)

        val movements = SeedDataFactory.seedCollateralMovements(now) + CollateralMovement(
            id = "COL-TEST",
            organisationId = "ORG-AUREOM-01",
            agreementId = "CSA-NB-2026-A",
            movementType = CollateralMovementType.DISPUTE,
            assetType = "USD Cash",
            grossAmount = BigDecimal("5000.00"),
            haircutPct = BigDecimal.ZERO,
            effectiveValue = BigDecimal("5000.00"),
            currency = "USD",
            isSimulated = true,
            status = "Disputed",
            timestampMillis = now,
            notes = "Disputed call"
        )
        val colSummary = PositionAndPnlCalculator.summarizeCollateral(
            SeedDataFactory.seedCollateralAgreements(),
            movements,
            positions,
            instMap
        )
        assertEquals(BigDecimal("72000.00"), colSummary.availableCollateral)
    }

    @Test
    fun `assistant requires human approval and cites records`() {
        val now = 1_700_000_000_000L
        val inst = SeedDataFactory.seedInstruments(now).first()
        val quotes = SeedDataFactory.seedQuotes(now).filter { it.rfqId == "RFQ-1001" }
        val resp = DeskAssistantService.generateResponse(
            intent = AssistantIntent.COMPARE_QUOTES,
            selectedInstrument = inst,
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            quotes = quotes,
            positions = emptyList(),
            portfolioSummary = PositionAndPnlCalculator.summarizePortfolio(emptyList()),
            collateralSummary = PositionAndPnlCalculator.summarizeCollateral(emptyList(), emptyList(), emptyList(), emptyMap()),
            cashFlows = emptyList(),
            settlementEvents = emptyList(),
            serverNowMillis = now
        )
        assertEquals(ProposedActionType.STAGE_QUOTE_IN_TICKET, resp.proposedActionType)
        assertTrue(resp.warningBanner.contains("Human confirmation required"))
        assertTrue(resp.citations.contains(inst.id))
    }
}
