package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AureomDatabase
import com.example.data.repository.DeskOperationResult
import com.example.data.repository.ServerClock
import com.example.data.repository.TradingDeskRepository
import com.example.domain.engine.SeedDataFactory
import com.example.domain.model.FeedHealth
import com.example.domain.model.RiskConfiguration
import com.example.domain.model.SettlementState
import com.example.domain.model.TradeDirection
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.math.BigDecimal

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AureomRepositoryRobolectricTest {

    private class FakeClock(var currentMillis: Long) : ServerClock {
        override fun nowMillis(): Long = currentMillis
    }

    private lateinit var db: AureomDatabase
    private lateinit var clock: FakeClock
    private lateinit var repo: TradingDeskRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        clock = FakeClock(1_700_000_000_000L)
        repo = TradingDeskRepository(db.aureomDao(), clock)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `complete RFQ to settlement workflow with contract version preservation and duplicate protection`() = runTest {
        repo.ensureSeeded()
        val riskConfig = RiskConfiguration()

        // 1. Request quotes from 3 dealers
        val rfqRes = repo.requestDealerQuotes(
            idempotencyKey = "rfq-journey-1",
            instrumentId = "INST-HCB-CALL-MAR27",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            counterpartyIds = listOf("CPTY-NORTHBRIDGE", "CPTY-CALDER", "CPTY-PENNINE"),
            quoteTtlSeconds = 40L,
            riskConfig = riskConfig
        )
        assertTrue(rfqRes is DeskOperationResult.Success)
        val rfqId = (rfqRes as DeskOperationResult.Success).entityId!!

        // Idempotent duplicate RFQ key returns same RFQ without creating another
        val rfqReplay = repo.requestDealerQuotes(
            idempotencyKey = "rfq-journey-1",
            instrumentId = "INST-HCB-CALL-MAR27",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            counterpartyIds = listOf("CPTY-NORTHBRIDGE"),
            riskConfig = riskConfig
        )
        assertEquals(rfqId, (rfqReplay as DeskOperationResult.Success).entityId)

        val quotes = db.aureomDao().getQuotesForRfq(rfqId)
        assertEquals(3, quotes.size)
        val chosenQuote = quotes.first()

        // 2. Atomic quote acceptance creates trade, position, cash flow, and settlement event
        val tradeRes = repo.acceptQuoteAtomic(
            idempotencyKey = "accept-journey-1",
            quoteId = chosenQuote.id,
            requestedQuantity = 2,
            availableCollateralUsd = BigDecimal("72000.00"),
            riskConfig = riskConfig,
            dualApprovalGranted = false
        )
        assertTrue(tradeRes is DeskOperationResult.Success)
        val tradeId = (tradeRes as DeskOperationResult.Success).entityId!!

        // 3. Duplicate acceptance with DIFFERENT idempotency key on same RFQ is blocked!
        val dupAccept = repo.acceptQuoteAtomic(
            idempotencyKey = "accept-journey-duplicate",
            quoteId = quotes[1].id,
            requestedQuantity = 2,
            availableCollateralUsd = BigDecimal("72000.00"),
            riskConfig = riskConfig,
            dualApprovalGranted = false
        )
        assertTrue(dupAccept is DeskOperationResult.Rejected)

        // 4. Import v1.1 call and verify original trade preserves v1.0
        repo.importFromAureomStructure(SeedDataFactory.structureCatalog()[0], true, "ORG-AUREOM-01", "SENIOR_TRADER")
        val savedTrade = db.aureomDao().getTradeById(tradeId)!!
        assertEquals("v1.0", savedTrade.contractVersion)

        // 5. Expiry observation + corrected fixing + payment reconciliation
        val events = repo.observeSettlementEvents("ORG-AUREOM-01").first()
        val newTradeEvent = events.first { it.tradeId == tradeId }
        val settleRes = repo.processExpiryObservationAndSettlement(newTradeEvent.id, BigDecimal("106.00"), false, "ORG-AUREOM-01", "SENIOR_TRADER")
        assertTrue(settleRes is DeskOperationResult.Success)

        val correctedRes = repo.processExpiryObservationAndSettlement(newTradeEvent.id, BigDecimal("107.00"), true, "ORG-AUREOM-01", "SENIOR_TRADER")
        assertTrue(correctedRes is DeskOperationResult.Success)
        val updatedEvent = db.aureomDao().getSettlementEventById(newTradeEvent.id)!!
        assertEquals("100000.00", updatedEvent.calculatedPayoff)

        val reconRes = repo.advanceCashFlowState("CF-SET-${newTradeEvent.id}", SettlementState.RECONCILED, "ORG-AUREOM-01", "SENIOR_TRADER")
        assertTrue(reconRes is DeskOperationResult.Success)

        // 6. Cross-organisation isolation
        val otherOrgTrades = repo.observeTrades("ORG-OTHER-99").first()
        assertTrue(otherOrgTrades.isEmpty())
    }

    @Test
    fun `quote expiry and stale feed recovery enforce strict safety gates`() = runTest {
        repo.ensureSeeded()
        val riskConfig = RiskConfiguration()

        val rfqRes = repo.requestDealerQuotes(
            idempotencyKey = "rfq-expiry-test",
            instrumentId = "INST-HCB-CALL-MAR27",
            direction = TradeDirection.BUY_OPTION,
            quantity = 2,
            counterpartyIds = listOf("CPTY-NORTHBRIDGE"),
            quoteTtlSeconds = 15L,
            riskConfig = riskConfig
        ) as DeskOperationResult.Success
        val quote = db.aureomDao().getQuotesForRfq(rfqRes.entityId!!).first()

        // Advance server clock past expiry
        clock.currentMillis += 60_000L
        val expiredCount = repo.expireElapsedQuotes()
        assertTrue(expiredCount >= 1)

        val attemptAfterExpiry = repo.acceptQuoteAtomic(
            idempotencyKey = "accept-expired",
            quoteId = quote.id,
            requestedQuantity = 2,
            availableCollateralUsd = BigDecimal("72000.00"),
            riskConfig = riskConfig,
            dualApprovalGranted = false
        )
        assertTrue(attemptAfterExpiry is DeskOperationResult.Rejected)

        // Stale feed blocks quote requests, reconnect restores healthy state
        repo.setFeedHealthState(FeedHealth.STALE, "ORG-AUREOM-01", "SENIOR_TRADER")
        val staleReq = repo.requestDealerQuotes(
            idempotencyKey = "rfq-during-stale",
            instrumentId = "INST-HCB-CALL-MAR27",
            direction = TradeDirection.BUY_OPTION,
            quantity = 1,
            counterpartyIds = listOf("CPTY-NORTHBRIDGE"),
            riskConfig = riskConfig
        )
        assertTrue(staleReq is DeskOperationResult.Rejected)

        repo.setFeedHealthState(FeedHealth.HEALTHY, "ORG-AUREOM-01", "SENIOR_TRADER")
        assertEquals(FeedHealth.HEALTHY, repo.feedHealth.value)
    }
}
