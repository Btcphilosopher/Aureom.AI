/**
 * AUREOM.AI — BIOMASS.OS
 * Interactive 3D Digital Twin Component
 * Procedural PBR 3D Power Station, Particle Simulation, Multi-Layer Visualizations & Equipment Raycasting
 */

import {
  Component,
  ElementRef,
  ViewChild,
  OnInit,
  OnDestroy,
  inject,
  ChangeDetectionStrategy,
  signal,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { PlantSimulatorService } from '../../core/simulation/plant-simulator.service';

export type VisMode =
  | 'realistic'
  | 'temperature'
  | 'pressure'
  | 'steam_flow'
  | 'fuel_flow'
  | 'electrical'
  | 'health'
  | 'alarms';

export interface SelectedEquipmentCard {
  tag: string;
  name: string;
  status: string;
  temperature: string;
  pressure: string;
  throughput: string;
  health: string;
  description: string;
}

@Component({
  selector: 'app-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#080d14] overflow-hidden select-none">
      <!-- Three.js Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: HUD Title & Mode Selector -->
      <div class="absolute top-4 left-4 z-10 flex items-center gap-3 bg-slate-900/85 border border-slate-800 rounded-xl px-4 py-2.5 shadow-lg backdrop-blur-sm">
        <div class="flex flex-col">
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold tracking-wider uppercase text-sky-400">3D Digital Twin</span>
            <span class="text-slate-500 text-xs font-mono">·</span>
            <span class="text-xs font-mono text-slate-300">20 MWe MCR Plant</span>
          </div>
          <span class="text-[11px] text-slate-400">Real-time dynamic physics & telemetry overlay</span>
        </div>

        <div class="h-6 w-px bg-slate-800 mx-1"></div>

        <!-- Layer Selector Tabs -->
        <div class="flex items-center gap-1 bg-slate-950/80 p-1 rounded-lg border border-slate-800/80">
          @for (mode of visModes; track mode.id) {
            <button
              (click)="setVisMode(mode.id)"
              class="px-2.5 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap"
              [class.bg-sky-600]="activeVisMode() === mode.id"
              [class.text-white]="activeVisMode() === mode.id"
              [class.text-slate-400]="activeVisMode() !== mode.id"
              [class.hover:text-slate-200]="activeVisMode() !== mode.id"
            >
              {{ mode.label }}
            </button>
          }
        </div>
      </div>

      <!-- Top Right: Camera Presets -->
      <div class="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-slate-900/85 border border-slate-800 rounded-xl p-1.5 shadow-lg backdrop-blur-sm">
        @for (view of cameraViews; track view.id) {
          <button
            (click)="setCameraView(view.id)"
            class="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap"
          >
            {{ view.label }}
          </button>
        }
      </div>

      <!-- Selected Equipment Telemetry Callout (Floating Card) -->
      @if (selectedEquipment(); as eq) {
        <div
          class="absolute top-20 right-4 z-10 w-80 bg-slate-900/90 border border-slate-700/80 rounded-xl p-4 shadow-2xl backdrop-blur-md"
        >
          <div class="flex items-start justify-between pb-2 mb-3 border-b border-slate-800">
            <div>
              <span class="text-[10px] font-mono uppercase tracking-wider text-sky-400">{{ eq.tag }}</span>
              <h4 class="text-sm font-semibold text-white">{{ eq.name }}</h4>
            </div>
            <button
              (click)="closeInspector()"
              class="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors"
            >
              <mat-icon class="text-base">close</mat-icon>
            </button>
          </div>

          <div class="space-y-2 text-xs">
            <div class="flex justify-between items-center py-1 border-b border-slate-800/60 font-mono">
              <span class="text-slate-400">Operating Status:</span>
              <span class="text-emerald-400 font-semibold">{{ eq.status }}</span>
            </div>
            <div class="flex justify-between items-center py-1 border-b border-slate-800/60 font-mono">
              <span class="text-slate-400">Process Temperature:</span>
              <span class="text-slate-200 font-bold tabular-nums">{{ eq.temperature }}</span>
            </div>
            <div class="flex justify-between items-center py-1 border-b border-slate-800/60 font-mono">
              <span class="text-slate-400">Operating Pressure:</span>
              <span class="text-slate-200 font-bold tabular-nums">{{ eq.pressure }}</span>
            </div>
            <div class="flex justify-between items-center py-1 border-b border-slate-800/60 font-mono">
              <span class="text-slate-400">Throughput / Flow:</span>
              <span class="text-slate-200 font-bold tabular-nums">{{ eq.throughput }}</span>
            </div>
            <div class="flex justify-between items-center py-1 border-b border-slate-800/60 font-mono">
              <span class="text-slate-400">Equipment Health:</span>
              <span class="text-emerald-400 font-bold tabular-nums">{{ eq.health }}</span>
            </div>
            <p class="text-[11px] text-slate-400 pt-1 leading-relaxed">
              {{ eq.description }}
            </p>
          </div>
        </div>
      }

      <!-- Collapsible Bottom Dock -->
      <div
        class="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 transition-all duration-300"
        [class.translate-y-28]="isDockCollapsed()"
      >
        <div class="relative bg-slate-900/90 border border-slate-800 rounded-2xl px-5 py-3 shadow-2xl backdrop-blur-md flex items-center gap-6">
          <!-- Dock Collapse Toggle Pill -->
          <button
            (click)="toggleDock()"
            class="absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-900/90 border border-slate-800 text-slate-400 hover:text-white px-3 py-0.5 rounded-t-lg text-[10px] font-mono tracking-wider uppercase transition-colors"
          >
            {{ isDockCollapsed() ? '▲ Show Controls' : '▼ Hide Controls' }}
          </button>

          <!-- Live Plant Telemetry KPI Strip in Dock -->
          <div class="flex items-center gap-4 text-xs font-mono">
            <div class="flex flex-col">
              <span class="text-[10px] text-slate-500 uppercase">Net Electrical</span>
              <span class="text-base font-bold text-sky-400 tabular-nums">
                {{ simService.netElectricalMW() | number:'1.2-2' }} <span class="text-xs font-normal text-slate-400">MW</span>
              </span>
            </div>
            <div class="h-8 w-px bg-slate-800"></div>
            <div class="flex flex-col">
              <span class="text-[10px] text-slate-500 uppercase">Boiler Thermal</span>
              <span class="text-base font-bold text-amber-400 tabular-nums">
                {{ simService.thermalInputMW() | number:'1.1-1' }} <span class="text-xs font-normal text-slate-400">MWth</span>
              </span>
            </div>
            <div class="h-8 w-px bg-slate-800"></div>
            <div class="flex flex-col">
              <span class="text-[10px] text-slate-500 uppercase">Steam Generation</span>
              <span class="text-base font-bold text-slate-200 tabular-nums">
                {{ simService.steamFlowTonnesHr() | number:'1.1-1' }} <span class="text-xs font-normal text-slate-400">t/h</span>
              </span>
            </div>
            <div class="h-8 w-px bg-slate-800"></div>
            <div class="flex flex-col">
              <span class="text-[10px] text-slate-500 uppercase">Net Efficiency</span>
              <span class="text-base font-bold text-emerald-400 tabular-nums">
                {{ simService.netEfficiencyPct() | number:'1.2-2' }}%
              </span>
            </div>
          </div>

          <div class="h-8 w-px bg-slate-800"></div>

          <!-- Controls in Dock -->
          <div class="flex items-center gap-3">
            <button
              (click)="toggleExplodedView()"
              class="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-700 hover:bg-slate-800 transition-colors"
              [class.bg-sky-600]="isExploded()"
              [class.text-white]="isExploded()"
              [class.text-slate-300]="!isExploded()"
            >
              <mat-icon class="text-sm align-middle mr-1">layers</mat-icon>
              Exploded View
            </button>

            <button
              (click)="resetCamera()"
              class="px-3 py-1.5 text-xs font-medium text-slate-300 rounded-lg border border-slate-700 hover:bg-slate-800 transition-colors"
            >
              <mat-icon class="text-sm align-middle mr-1">center_focus_strong</mat-icon>
              Reset View
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class DigitalTwinComponent implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  public readonly simService = inject(PlantSimulatorService);

  public readonly activeVisMode = signal<VisMode>('realistic');
  public readonly isDockCollapsed = signal<boolean>(false);
  public readonly isExploded = signal<boolean>(false);
  public readonly selectedEquipment = signal<SelectedEquipmentCard | null>(null);

  public readonly visModes = [
    { id: 'realistic' as VisMode, label: 'Realistic' },
    { id: 'temperature' as VisMode, label: 'Thermal IR' },
    { id: 'pressure' as VisMode, label: 'Pressure' },
    { id: 'steam_flow' as VisMode, label: 'Steam Mass' },
    { id: 'fuel_flow' as VisMode, label: 'Biomass Flow' },
    { id: 'electrical' as VisMode, label: 'Electrical Grid' },
    { id: 'alarms' as VisMode, label: 'Alarms / Health' },
  ];

  public readonly cameraViews = [
    { id: 'overview', label: 'Full Facility' },
    { id: 'fuel_yard', label: 'Fuel Handling' },
    { id: 'boiler', label: 'Furnace & Boiler' },
    { id: 'turbine', label: 'Turbine Hall' },
    { id: 'emissions', label: 'Emissions & Stack' },
    { id: 'substation', label: 'Grid Substation' },
  ];

  // Three.js State
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private animationFrameId = 0;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // 3D Objects & Meshes registry
  private equipmentGroup = new THREE.Group();
  private clickableMeshes: THREE.Mesh[] = [];
  private animatedSteamParticles: THREE.Points | null = null;
  private animatedFuelParticles: THREE.Points | null = null;
  private animatedCoolingTowerPlumes: THREE.Points[] = [];
  private animatedStackPlume: THREE.Points | null = null;
  private turbineRotorMesh: THREE.Mesh | null = null;
  private fireLight!: THREE.PointLight;

  constructor() {
    // React to selected equipment changes from the service
    effect(() => {
      const eqId = this.simService.state().selectedEquipmentId;
      if (eqId) {
        this.updateInspectorFromId(eqId);
      }
    });
  }

  ngOnInit(): void {
    this.initThree();
    this.buildPowerStation();
    this.animate();
  }

  ngOnDestroy(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree(): void {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 1000;
    const height = container.clientHeight || 700;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a101d);
    this.scene.fog = new THREE.FogExp2(0x0a101d, 0.0035);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 2000);
    this.camera.position.set(130, 95, 175);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.02; // prevent camera going below ground
    this.controls.minDistance = 15;
    this.controls.maxDistance = 500;
    this.controls.target.set(0, 15, 0);

    // Studio Lighting Rig
    const ambientLight = new THREE.HemisphereLight(0x60a5fa, 0x1e293b, 0.65);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfff7ed, 1.4);
    dirLight.position.set(150, 220, 100);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 600;
    dirLight.shadow.camera.left = -160;
    dirLight.shadow.camera.right = 160;
    dirLight.shadow.camera.top = 160;
    dirLight.shadow.camera.bottom = -160;
    dirLight.shadow.bias = -0.0005;
    this.scene.add(dirLight);

    // Fill Light
    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.5);
    fillLight.position.set(-120, 80, -90);
    this.scene.add(fillLight);

    // Dynamic fire pointlight inside furnace
    this.fireLight = new THREE.PointLight(0xff7700, 2.8, 45);
    this.fireLight.position.set(-15, 12, 0);
    this.scene.add(this.fireLight);

    // Ground Plane with industrial grid texture
    const groundGeo = new THREE.PlaneGeometry(600, 600);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.85,
      metalness: 0.15,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // Circular perimeter road and safety marking
    const roadRingGeo = new THREE.RingGeometry(110, 125, 64);
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.9 });
    const road = new THREE.Mesh(roadRingGeo, roadMat);
    road.rotation.x = -Math.PI / 2;
    road.position.y = 0.05;
    this.scene.add(road);

    this.scene.add(this.equipmentGroup);

    // Window Resize Handler
    window.addEventListener('resize', this.onWindowResize.bind(this));

    // Pointer Raycasting on Click
    container.addEventListener('pointerdown', this.onPointerDown.bind(this));
  }

  /**
   * Build the entire 3D biomass power plant with multi-part procedural models
   */
  private buildPowerStation(): void {
    // Common PBR materials
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.35 });
    const darkSteelMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.75, roughness: 0.45 });
    const safetyYellowMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.5 });
    const concreteMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.9, metalness: 0.05 });
    const boilerRedMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, metalness: 0.5, roughness: 0.4 });
    const turbineBlueMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.85, roughness: 0.25 });
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.4, roughness: 0.1 });

    // 1. FUEL RECEPTION & STORAGE AREA (Left flank, x = -80 to -40)
    // Truck Weighbridge & Unloader
    const truckBay = new THREE.Group();
    truckBay.position.set(-95, 0, 30);
    const weighbridge = new THREE.Mesh(new THREE.BoxGeometry(18, 1, 32), concreteMat);
    weighbridge.position.y = 0.5;
    weighbridge.receiveShadow = true;
    truckBay.add(weighbridge);
    
    // Truck mesh placeholder
    const truckCabin = new THREE.Mesh(new THREE.BoxGeometry(6, 6, 7), new THREE.MeshStandardMaterial({ color: 0x2563eb }));
    truckCabin.position.set(0, 4, 8);
    truckCabin.castShadow = true;
    const truckTrailer = new THREE.Mesh(new THREE.BoxGeometry(7, 7, 16), steelMat);
    truckTrailer.position.set(0, 4.5, -4);
    truckTrailer.castShadow = true;
    truckBay.add(truckCabin, truckTrailer);
    this.equipmentGroup.add(truckBay);

    // Fuel Silo (Cylindrical tower with conical roof)
    const siloGroup = new THREE.Group();
    siloGroup.position.set(-75, 0, -10);
    const siloBody = new THREE.Mesh(new THREE.CylinderGeometry(12, 12, 34, 32), steelMat);
    siloBody.position.y = 17;
    siloBody.castShadow = true;
    siloBody.receiveShadow = true;
    const siloRoof = new THREE.Mesh(new THREE.ConeGeometry(12.5, 6, 32), darkSteelMat);
    siloRoof.position.y = 37;
    siloRoof.castShadow = true;
    siloGroup.add(siloBody, siloRoof);
    this.tagEquipment(siloBody, 'silo', 'Biomass Storage Silo', 'SILO-01');
    this.equipmentGroup.add(siloGroup);

    // Rotary Drum Biomass Dryer
    const dryerGroup = new THREE.Group();
    dryerGroup.position.set(-50, 0, 25);
    const dryerDrum = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.5, 26, 24), darkSteelMat);
    dryerDrum.rotation.z = Math.PI / 2;
    dryerDrum.rotation.y = 0.15; // slight slope
    dryerDrum.position.y = 7;
    dryerDrum.castShadow = true;
    const dryerLeg1 = new THREE.Mesh(new THREE.BoxGeometry(2, 7, 6), steelMat);
    dryerLeg1.position.set(-10, 3.5, 0);
    const dryerLeg2 = new THREE.Mesh(new THREE.BoxGeometry(2, 6, 6), steelMat);
    dryerLeg2.position.set(10, 3, 0);
    dryerGroup.add(dryerDrum, dryerLeg1, dryerLeg2);
    this.tagEquipment(dryerDrum, 'dryer', 'Rotary Drum Biomass Dryer', 'DRY-01');
    this.equipmentGroup.add(dryerGroup);

    // Inclined Belt Conveyor from Yard to Furnace
    const conveyorGroup = new THREE.Group();
    const conveyorLength = 48;
    const conveyorSlope = Math.PI / 8;
    const conveyorBelt = new THREE.Mesh(new THREE.BoxGeometry(conveyorLength, 1.2, 3.2), safetyYellowMat);
    conveyorBelt.position.set(-35, 14, 0);
    conveyorBelt.rotation.z = conveyorSlope;
    conveyorBelt.castShadow = true;
    conveyorGroup.add(conveyorBelt);
    this.tagEquipment(conveyorBelt, 'conveyor', 'Fuel Feed Belt Conveyor', 'CV-101');
    this.equipmentGroup.add(conveyorGroup);

    // 2. COMBUSTION CHAMBER & BOILER ISLAND (Center-Left, x = -15 to 10)
    const boilerGroup = new THREE.Group();
    boilerGroup.position.set(-10, 0, 0);

    // Lower Furnace (Moving Grate combustion chamber)
    const furnaceMesh = new THREE.Mesh(new THREE.BoxGeometry(22, 22, 20), boilerRedMat);
    furnaceMesh.position.y = 11;
    furnaceMesh.castShadow = true;
    furnaceMesh.receiveShadow = true;
    boilerGroup.add(furnaceMesh);
    this.tagEquipment(furnaceMesh, 'furnace_boiler', 'Moving Grate Biomass Furnace', 'FUR-01');

    // Upper Tower Boiler (Membrane waterwall tower with superheater & economiser)
    const boilerTower = new THREE.Mesh(new THREE.BoxGeometry(18, 32, 18), darkSteelMat);
    boilerTower.position.y = 38;
    boilerTower.castShadow = true;
    boilerTower.receiveShadow = true;
    boilerGroup.add(boilerTower);

    // Steam Drum on top of boiler
    const steamDrum = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.2, 22, 24), steelMat);
    steamDrum.rotation.z = Math.PI / 2;
    steamDrum.position.set(0, 56, 0);
    steamDrum.castShadow = true;
    boilerGroup.add(steamDrum);
    this.tagEquipment(steamDrum, 'steam_drum', 'Boiler Steam Drum & Headers', 'DRUM-01');

    // High Pressure Main Steam Pipe leading to Turbine
    const steamPipeCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-10, 56, 0),
      new THREE.Vector3(5, 52, 0),
      new THREE.Vector3(25, 30, 0),
      new THREE.Vector3(35, 14, 0),
    ]);
    const steamPipeGeo = new THREE.TubeGeometry(steamPipeCurve, 32, 1.4, 16, false);
    const steamPipeMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.3, metalness: 0.8 }); // amber insulation
    const steamPipe = new THREE.Mesh(steamPipeGeo, steamPipeMat);
    this.scene.add(steamPipe);

    this.equipmentGroup.add(boilerGroup);

    // 3. TURBINE HALL & GENERATOR (Center, x = 30 to 60)
    const turbineHall = new THREE.Group();
    turbineHall.position.set(40, 0, 0);

    // Building structure (semi-transparent glass walls to view inside machinery)
    const hallFloor = new THREE.Mesh(new THREE.BoxGeometry(32, 1, 28), concreteMat);
    hallFloor.position.y = 0.5;
    const hallRoof = new THREE.Mesh(new THREE.BoxGeometry(34, 1.5, 30), darkSteelMat);
    hallRoof.position.y = 26;
    hallRoof.castShadow = true;
    const hallGlass = new THREE.Mesh(new THREE.BoxGeometry(31.8, 25, 27.8), glassMat);
    hallGlass.position.y = 13;
    turbineHall.add(hallFloor, hallRoof, hallGlass);

    // Multi-stage Steam Turbine Casing
    const turbineCasing = new THREE.Mesh(new THREE.CylinderGeometry(4.2, 5.8, 14, 24), turbineBlueMat);
    turbineCasing.rotation.z = Math.PI / 2;
    turbineCasing.position.set(-4, 7, 0);
    turbineCasing.castShadow = true;
    turbineHall.add(turbineCasing);
    this.tagEquipment(turbineCasing, 'turbine', 'Multistage Condensing Steam Turbine', 'ST-01');

    // Internal spinning rotor shaft
    const rotorGeo = new THREE.CylinderGeometry(1.4, 1.4, 24, 16);
    const rotorMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95, roughness: 0.15 });
    this.turbineRotorMesh = new THREE.Mesh(rotorGeo, rotorMat);
    this.turbineRotorMesh.rotation.z = Math.PI / 2;
    this.turbineRotorMesh.position.set(2, 7, 0);
    turbineHall.add(this.turbineRotorMesh);

    // 4-Pole Synchronous Generator
    const generatorMesh = new THREE.Mesh(new THREE.BoxGeometry(10, 8.5, 9), darkSteelMat);
    generatorMesh.position.set(9, 7, 0);
    generatorMesh.castShadow = true;
    turbineHall.add(generatorMesh);
    this.tagEquipment(generatorMesh, 'generator', 'Synchronous Power Generator (11 kV)', 'GEN-01');

    // Surface Condenser beneath turbine
    const condenserMesh = new THREE.Mesh(new THREE.CylinderGeometry(5.2, 5.2, 13, 20), steelMat);
    condenserMesh.rotation.z = Math.PI / 2;
    condenserMesh.position.set(-4, 2.5, 0);
    condenserMesh.castShadow = true;
    turbineHall.add(condenserMesh);
    this.tagEquipment(condenserMesh, 'condenser', 'Surface Water Condenser', 'COND-01');

    this.equipmentGroup.add(turbineHall);

    // 4. COOLING TOWERS (Back-Right, x = 65, z = -55)
    for (let i = 0; i < 2; i++) {
      const zOffset = -45 - i * 36;
      const coolingTowerGroup = new THREE.Group();
      coolingTowerGroup.position.set(70, 0, zOffset);

      // Hyperbolic shape using LatheGeometry
      const points: THREE.Vector2[] = [];
      for (let j = 0; j <= 20; j++) {
        const y = (j / 20) * 36;
        const normY = (y - 18) / 18; // -1 to 1
        const r = 12 + normY * normY * 3.5 - normY * 1.5;
        points.push(new THREE.Vector2(r, y));
      }
      const towerGeo = new THREE.LatheGeometry(points, 32);
      const towerMesh = new THREE.Mesh(towerGeo, concreteMat);
      towerMesh.castShadow = true;
      towerMesh.receiveShadow = true;
      coolingTowerGroup.add(towerMesh);
      this.tagEquipment(towerMesh, 'cooling_tower', `Natural Draft Cooling Tower #${i + 1}`, `CT-0${i + 1}`);
      this.equipmentGroup.add(coolingTowerGroup);

      // Create animated vapor plume particles on top of cooling tower
      const plume = this.createVaporPlume(new THREE.Vector3(70, 36, zOffset), 0x93c5fd, 180, 25);
      this.animatedCoolingTowerPlumes.push(plume);
      this.scene.add(plume);
    }

    // 5. FLUE GAS CLEANING & EMISSIONS TRAIN (Center-Back, x = -10 to 15, z = -40)
    const emissionsGroup = new THREE.Group();
    emissionsGroup.position.set(-5, 0, -35);

    // Selective Catalytic Reduction (SCR) De-NOx Reactor
    const scrReactor = new THREE.Mesh(new THREE.BoxGeometry(10, 16, 9), darkSteelMat);
    scrReactor.position.set(-15, 8, 0);
    scrReactor.castShadow = true;
    emissionsGroup.add(scrReactor);
    this.tagEquipment(scrReactor, 'scr', 'Selective Catalytic Reduction (SCR) De-NOx', 'SCR-01');

    // Pulse-Jet Fabric Baghouse Filter
    const baghouseMesh = new THREE.Mesh(new THREE.BoxGeometry(16, 20, 12), steelMat);
    baghouseMesh.position.set(0, 10, 0);
    baghouseMesh.castShadow = true;
    emissionsGroup.add(baghouseMesh);
    this.tagEquipment(baghouseMesh, 'baghouse', 'Pulse-Jet Fabric Filter Baghouse', 'BAG-01');

    // Induced Draft (ID) Fan
    const idFanMesh = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.5, 5, 20), safetyYellowMat);
    idFanMesh.rotation.x = Math.PI / 2;
    idFanMesh.position.set(13, 4, 0);
    idFanMesh.castShadow = true;
    emissionsGroup.add(idFanMesh);
    this.tagEquipment(idFanMesh, 'id_fan', 'Induced Draft (ID) Flue Gas Fan', 'FAN-ID');

    // Tall 80m Emissions Stack (Chimney)
    const stackMesh = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 4.8, 68, 32), concreteMat);
    stackMesh.position.set(26, 34, 0);
    stackMesh.castShadow = true;
    stackMesh.receiveShadow = true;
    emissionsGroup.add(stackMesh);
    this.tagEquipment(stackMesh, 'stack', 'CEMS Monitored Emissions Stack (80m)', 'STK-01');

    // Animated stack smoke plume
    this.animatedStackPlume = this.createVaporPlume(new THREE.Vector3(21, 68, -35), 0x94a3b8, 120, 32);
    this.scene.add(this.animatedStackPlume);

    this.equipmentGroup.add(emissionsGroup);

    // 6. HIGH VOLTAGE ELECTRICAL SUBSTATION (Front-Right, x = 75, z = 35)
    const substationGroup = new THREE.Group();
    substationGroup.position.set(75, 0, 35);

    // Main Step-Up Power Transformer (11 kV / 132 kV)
    const transformerMesh = new THREE.Mesh(new THREE.BoxGeometry(12, 11, 10), darkSteelMat);
    transformerMesh.position.y = 5.5;
    transformerMesh.castShadow = true;
    // Bushings on top
    for (let b = -3; b <= 3; b += 3) {
      const bushing = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.6, 5, 12), new THREE.MeshStandardMaterial({ color: 0x854d0e }));
      bushing.position.set(b, 13, 0);
      transformerMesh.add(bushing);
    }
    substationGroup.add(transformerMesh);
    this.tagEquipment(transformerMesh, 'transformer', 'Main Step-Up Transformer (11/132 kV)', 'TR-01');

    // Transmission Line Towers (Pylons)
    const pylon = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 2.5, 38, 4), steelMat);
    pylon.position.set(25, 19, 0);
    substationGroup.add(pylon);

    this.equipmentGroup.add(substationGroup);

    // 7. Setup Particle Systems (Steam particles and Fuel particles)
    this.initParticleFlows();
  }

  private tagEquipment(mesh: THREE.Mesh, id: string, name: string, tag: string): void {
    mesh.userData = {
      equipmentId: id,
      name,
      tag,
      isInteractive: true,
    };
    this.clickableMeshes.push(mesh);
  }

  private createVaporPlume(origin: THREE.Vector3, colorHex: number, count: number, heightSpan: number): THREE.Points {
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      const radius = Math.random() * 4.5;
      const angle = Math.random() * Math.PI * 2;
      positions[i * 3] = origin.x + Math.cos(angle) * radius;
      positions[i * 3 + 1] = origin.y + Math.random() * heightSpan;
      positions[i * 3 + 2] = origin.z + Math.sin(angle) * radius;
      velocities[i] = 0.2 + Math.random() * 0.4;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.userData = { velocities, origin, heightSpan };

    const mat = new THREE.PointsMaterial({
      color: colorHex,
      size: 3.5,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
    });

    return new THREE.Points(geo, mat);
  }

  private initParticleFlows(): void {
    // Steam particles flowing from boiler to turbine
    const steamCount = 120;
    const steamGeo = new THREE.BufferGeometry();
    const steamPos = new Float32Array(steamCount * 3);

    for (let i = 0; i < steamCount; i++) {
      const alpha = i / steamCount;
      steamPos[i * 3] = -10 + alpha * 45;
      steamPos[i * 3 + 1] = 52 - alpha * 38;
      steamPos[i * 3 + 2] = (Math.random() - 0.5) * 1.5;
    }
    steamGeo.setAttribute('position', new THREE.BufferAttribute(steamPos, 3));
    const steamMat = new THREE.PointsMaterial({ color: 0x38bdf8, size: 2.2, transparent: true, opacity: 0.8 });
    this.animatedSteamParticles = new THREE.Points(steamGeo, steamMat);
    this.scene.add(this.animatedSteamParticles);

    // Fuel particles on conveyor belt
    const fuelCount = 90;
    const fuelGeo = new THREE.BufferGeometry();
    const fuelPos = new Float32Array(fuelCount * 3);

    for (let i = 0; i < fuelCount; i++) {
      const alpha = i / fuelCount;
      fuelPos[i * 3] = -58 + alpha * 42;
      fuelPos[i * 3 + 1] = 4 + alpha * 16;
      fuelPos[i * 3 + 2] = (Math.random() - 0.5) * 2.2;
    }
    fuelGeo.setAttribute('position', new THREE.BufferAttribute(fuelPos, 3));
    const fuelMat = new THREE.PointsMaterial({ color: 0xd97706, size: 2.6, transparent: true, opacity: 0.95 });
    this.animatedFuelParticles = new THREE.Points(fuelGeo, fuelMat);
    this.scene.add(this.animatedFuelParticles);
  }

  private animate(): void {
    this.animationFrameId = requestAnimationFrame(this.animate.bind(this));

    // Rotate turbine rotor
    if (this.turbineRotorMesh && this.simService.state().isRunning) {
      this.turbineRotorMesh.rotation.x += 0.25;
    }

    // Flicker furnace fire light
    if (this.fireLight) {
      this.fireLight.intensity = 2.4 + Math.sin(Date.now() * 0.012) * 0.6;
    }

    // Animate Plumes (Cooling towers & stack)
    for (const plume of this.animatedCoolingTowerPlumes) {
      this.updatePlumeParticles(plume);
    }
    if (this.animatedStackPlume) {
      this.updatePlumeParticles(this.animatedStackPlume);
    }

    // Animate Steam particles
    if (this.animatedSteamParticles) {
      const pos = this.animatedSteamParticles.geometry.attributes['position'].array as Float32Array;
      for (let i = 0; i < pos.length; i += 3) {
        pos[i] += 0.45; // move along X towards turbine
        if (pos[i] > 36) {
          pos[i] = -10;
        }
      }
      this.animatedSteamParticles.geometry.attributes['position'].needsUpdate = true;
    }

    // Animate Fuel particles
    if (this.animatedFuelParticles) {
      const pos = this.animatedFuelParticles.geometry.attributes['position'].array as Float32Array;
      for (let i = 0; i < pos.length; i += 3) {
        pos[i] += 0.18;
        pos[i + 1] += 0.068;
        if (pos[i] > -16) {
          pos[i] = -58;
          pos[i + 1] = 4;
        }
      }
      this.animatedFuelParticles.geometry.attributes['position'].needsUpdate = true;
    }

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  private updatePlumeParticles(plume: THREE.Points): void {
    const geo = plume.geometry;
    const pos = geo.attributes['position'].array as Float32Array;
    const velocities = geo.userData['velocities'] as Float32Array;
    const origin = geo.userData['origin'] as THREE.Vector3;
    const heightSpan = geo.userData['heightSpan'] as number;

    for (let i = 0; i < velocities.length; i++) {
      const idx = i * 3;
      pos[idx + 1] += velocities[i]; // rise up Y
      pos[idx] += 0.04;              // slight wind drift along X
      if (pos[idx + 1] > origin.y + heightSpan) {
        pos[idx + 1] = origin.y;
        const radius = Math.random() * 3.5;
        const angle = Math.random() * Math.PI * 2;
        pos[idx] = origin.x + Math.cos(angle) * radius;
        pos[idx + 2] = origin.z + Math.sin(angle) * radius;
      }
    }
    geo.attributes['position'].needsUpdate = true;
  }

  private onPointerDown(event: MouseEvent): void {
    const rect = this.canvasContainer.nativeElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.clickableMeshes, true);

    if (intersects.length > 0) {
      let target: THREE.Object3D | null = intersects[0].object;
      while (target && !target.userData['isInteractive']) {
        target = target.parent;
      }

      if (target && target.userData['equipmentId']) {
        const eqId = target.userData['equipmentId'];
        this.simService.selectEquipment(eqId);
        this.updateInspectorFromId(eqId);
      }
    }
  }

  private updateInspectorFromId(eqId: string): void {
    const state = this.simService.state();
    switch (eqId) {
      case 'furnace_boiler':
        this.selectedEquipment.set({
          tag: 'FUR-01 / BOIL-01',
          name: 'Moving Grate Biomass Furnace & Tower Boiler',
          status: 'Online (Continuous Baseload)',
          temperature: `${state.furnaceTemperatureC.toFixed(0)} °C Bed / ${state.boiler.steamTemperatureC.toFixed(0)} °C Steam`,
          pressure: `${state.boiler.drumPressureBar.toFixed(1)} bar drum`,
          throughput: `${state.fuelFeedRateTonnesHr.toFixed(1)} t/h Fuel · ${state.boiler.steamFlowTonnesHr.toFixed(1)} t/h Steam`,
          health: '98.5% Nominal',
          description:
            'Reciprocating air-cooled moving grate with primary under-grate air and secondary overfire air ports. Membrane waterwalls feed natural circulation steam drum.',
        });
        break;
      case 'turbine':
        this.selectedEquipment.set({
          tag: 'ST-01',
          name: 'Multistage Condensing Steam Turbine',
          status: 'Synchronized & Loaded',
          temperature: `${state.turbine.inletTemperatureC.toFixed(0)} °C Inlet / ${state.turbine.exhaustTemperatureC.toFixed(0)} °C Exhaust`,
          pressure: `${state.turbine.inletPressureBar.toFixed(1)} bar inlet / ${state.turbine.exhaustPressureBar.toFixed(3)} bar exhaust`,
          throughput: `${state.turbine.mechanicalPowerMW.toFixed(2)} MW Shaft Power`,
          health: `${(100 - state.turbine.vibrationRMS_mm_s * 5).toFixed(1)}% (Vib: ${state.turbine.vibrationRMS_mm_s.toFixed(2)} mm/s)`,
          description:
            'Reaction/impulse multistage steam turbine driving synchronous 4-pole alternator. Equipped with controlled intermediate steam extraction for district heating.',
        });
        break;
      case 'generator':
        this.selectedEquipment.set({
          tag: 'GEN-01',
          name: 'Synchronous Alternator (11 kV, 50 Hz)',
          status: 'Grid Synchronized',
          temperature: '68.5 °C Stator Winding',
          pressure: '0.98 bar H2/Air coolant',
          throughput: `${state.electrical.grossElectricalPowerMW.toFixed(2)} MW Gross / ${state.electrical.reactivePowerMVAR.toFixed(2)} MVAR`,
          health: '99.2% Nominal',
          description:
            'Three-phase synchronous generator rated 25 MVA, cos φ 0.88 with brushless excitation and automatic voltage regulator (AVR).',
        });
        break;
      case 'stack':
        this.selectedEquipment.set({
          tag: 'STK-01 / CEMS',
          name: 'Concrete Emissions Chimney (80m) & CEMS',
          status: 'Compliant & Continuous Logging',
          temperature: `${state.emissions.stack_temperature_c.toFixed(0)} °C Flue Gas`,
          pressure: '-20 Pa draft',
          throughput: `${(state.emissions.flue_gas_flow_nm3_hr / 1000).toFixed(1)} kNm3/h Exhaust`,
          health: 'CEMS Calibrated (FID/NDIR)',
          description:
            'Reinforced concrete stack equipped with dual redundant Continuous Emissions Monitoring Systems (CEMS) measuring O2, CO2, NOx, SO2, CO, HCl, and dust opacity.',
        });
        break;
      case 'silo':
        this.selectedEquipment.set({
          tag: 'SILO-01',
          name: 'Biomass Storage Silo',
          status: 'Active Inventory',
          temperature: '24.2 °C Internal (No hot spots)',
          pressure: 'Ambient',
          throughput: `${state.bunkerInventoryTonnes.toFixed(0)} tonnes stored`,
          health: '100% (CO/Dust probers clear)',
          description:
            'Enclosed storage silo with live-bottom screw reclaimer, nitrogen inerting safety system, and temperature-probing cable array for spontaneous heating risk monitoring.',
        });
        break;
      default:
        this.selectedEquipment.set({
          tag: 'GEN-EQUIP',
          name: 'Plant Auxiliary Unit',
          status: 'In Service',
          temperature: 'Nominal',
          pressure: 'Nominal',
          throughput: 'Full Duty',
          health: '99% Clean',
          description: 'Industrial balance-of-plant subsystem verified by supervisory instrumentation.',
        });
    }
  }

  public setVisMode(mode: VisMode): void {
    this.activeVisMode.set(mode);
    // Adjust visual representation in 3D scene
    this.clickableMeshes.forEach((mesh) => {
      if (!mesh.material) return;
      const mat = mesh.material as THREE.MeshStandardMaterial;

      if (mode === 'temperature') {
        if (mesh.userData['equipmentId'] === 'furnace_boiler') mat.color.setHex(0xef4444); // red hot
        else if (mesh.userData['equipmentId'] === 'turbine') mat.color.setHex(0xf59e0b);    // warm amber
        else if (mesh.userData['equipmentId'] === 'condenser') mat.color.setHex(0x3b82f6);  // cool blue
        else mat.color.setHex(0x334155);
      } else if (mode === 'pressure') {
        if (mesh.userData['equipmentId'] === 'steam_drum') mat.color.setHex(0xdc2626);   // high pressure 65 bar
        else if (mesh.userData['equipmentId'] === 'condenser') mat.color.setHex(0x7c3aed); // deep vacuum
        else mat.color.setHex(0x10b981); // atmospheric
      } else if (mode === 'electrical') {
        if (mesh.userData['equipmentId'] === 'transformer' || mesh.userData['equipmentId'] === 'generator') {
          mat.color.setHex(0x38bdf8);
        } else {
          mat.color.setHex(0x1e293b);
        }
      } else {
        // Restore realistic material colors
        if (mesh.userData['equipmentId'] === 'furnace_boiler') mat.color.setHex(0x991b1b);
        else if (mesh.userData['equipmentId'] === 'turbine') mat.color.setHex(0x0284c7);
        else mat.color.setHex(0x475569);
      }
    });
  }

  public setCameraView(viewId: string): void {
    switch (viewId) {
      case 'overview':
        this.camera.position.set(130, 95, 175);
        this.controls.target.set(0, 15, 0);
        break;
      case 'fuel_yard':
        this.camera.position.set(-65, 40, 85);
        this.controls.target.set(-60, 10, 10);
        break;
      case 'boiler':
        this.camera.position.set(-15, 45, 65);
        this.controls.target.set(-10, 25, 0);
        break;
      case 'turbine':
        this.camera.position.set(45, 25, 45);
        this.controls.target.set(40, 8, 0);
        break;
      case 'emissions':
        this.camera.position.set(20, 50, -95);
        this.controls.target.set(5, 25, -35);
        break;
      case 'substation':
        this.camera.position.set(95, 30, 80);
        this.controls.target.set(75, 8, 35);
        break;
    }
  }

  public toggleExplodedView(): void {
    this.isExploded.update((v) => !v);
    const exploded = this.isExploded();
    // Smoothly offset key equipment groups
    this.equipmentGroup.children.forEach((child, index) => {
      const targetY = exploded ? (index % 4) * 12 : 0;
      child.position.y = targetY;
    });
  }

  public resetCamera(): void {
    this.setCameraView('overview');
  }

  public toggleDock(): void {
    this.isDockCollapsed.update((v) => !v);
  }

  public closeInspector(): void {
    this.selectedEquipment.set(null);
    this.simService.selectEquipment(null);
  }

  private onWindowResize(): void {
    if (!this.canvasContainer) return;
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }
}
