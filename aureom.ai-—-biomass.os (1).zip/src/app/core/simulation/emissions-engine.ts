/**
 * AUREOM.AI — BIOMASS.OS
 * Flue Gas Cleaning, Environmental Emissions & CEMS Reference Normalization
 */

import { BiomassFuel, FlueGasEmissions } from '../models/plant.models';

export class EmissionsEngine {
  /**
   * Calculate raw emissions, flue gas abatement efficiencies, and normalized concentrations (mg/Nm3 @ 6% O2 dry)
   */
  public static calculateEmissions(
    fuel: BiomassFuel,
    fuelFeedRateKgS: number,
    moisturePct: number,
    flueGasFlowNm3Hr: number,
    flueGasO2DryPct: number,
    furnaceTempC: number,
    sncrReagentFlowKgH = 35,
    limeInjectionKgH = 25,
    baghouseOperational = true,
    scrOperational = true
  ): FlueGasEmissions {
    const dryFraction = 1 - moisturePct / 100;
    const fuelDryKgS = fuelFeedRateKgS * dryFraction;

    // Carbon and CO2 mass rate
    const carbonMassKgS = fuelDryKgS * (fuel.carbon_dry / 100);
    const co2MassRateKgS = carbonMassKgS * (44.01 / 12.011);
    const biogenicCo2TonnesDay = (co2MassRateKgS * 86400) / 1000;
    const fossilCo2TonnesDay = 0.0; // 100% biomass, 0 auxiliary gas during baseload

    // 1. NOx Formation: Fuel-N conversion + Thermal NOx (Zeldovich mechanism above 1000°C)
    // Typical biomass fuel-N conversion to raw NOx is 15-25%
    const n_in_fuel_kg_s = fuelDryKgS * (fuel.nitrogen_dry / 100);
    const thermalNoxFactor = furnaceTempC > 950 ? 1 + 0.002 * (furnaceTempC - 950) : 1.0;
    const rawNoxMassKgS = n_in_fuel_kg_s * 0.18 * (46.0 / 14.0) * thermalNoxFactor;
    const rawNoxMgNm3 = flueGasFlowNm3Hr > 0 ? (rawNoxMassKgS * 3.6e9) / flueGasFlowNm3Hr : 350;

    // SNCR / SCR abatement:
    // Molar ratio NH3/NOx determines reduction efficiency (typically 60-80% for SNCR, up to 90% for SCR)
    const sncrEfficiencyPct = scrOperational
      ? Math.min(88, Math.max(20, 50 + 0.8 * sncrReagentFlowKgH))
      : 0;
    const stackNoxMgNm3_actual = rawNoxMgNm3 * (1 - sncrEfficiencyPct / 100);

    // 2. SO2 Formation: ~90-95% of fuel sulfur converts to SO2
    const s_in_fuel_kg_s = fuelDryKgS * (fuel.sulfur_dry / 100);
    const rawSo2MassKgS = s_in_fuel_kg_s * 0.92 * (64.06 / 32.06);
    const rawSo2MgNm3 = flueGasFlowNm3Hr > 0 ? (rawSo2MassKgS * 3.6e9) / flueGasFlowNm3Hr : 120;
    
    // Scrubber / Dry Sorbent Injection efficiency with hydrated lime
    const scrubberEfficiencyPct = Math.min(92, Math.max(15, 60 + 0.9 * limeInjectionKgH));
    const stackSo2MgNm3_actual = rawSo2MgNm3 * (1 - scrubberEfficiencyPct / 100);

    // 3. Carbon Monoxide (CO): Incomplete combustion indicator, depends on excess air & temperature
    // Optimal around 3.5 - 5% O2; rises if O2 too low (<2.5%) or furnace cools (<800°C)
    let rawCoMgNm3 = 65;
    if (flueGasO2DryPct < 3.0) {
      rawCoMgNm3 += (3.0 - flueGasO2DryPct) * 120;
    }
    if (furnaceTempC < 850) {
      rawCoMgNm3 += (850 - furnaceTempC) * 0.8;
    }
    const stackCoMgNm3_actual = Math.max(15, rawCoMgNm3);

    // 4. Particulate Matter (PM / Dust): Raw fly ash is ~60-80% of total fuel ash
    const ash_in_fuel_kg_s = fuelDryKgS * (fuel.ash_dry / 100);
    const rawPmMจุMassKgS = ash_in_fuel_kg_s * 0.70;
    const rawPmMgNm3 = flueGasFlowNm3Hr > 0 ? (rawPmMจุMassKgS * 3.6e9) / flueGasFlowNm3Hr : 3200;
    
    // Pulse-jet baghouse fabric filter efficiency: 99.85%
    const baghouseEfficiencyPct = baghouseOperational ? 99.85 : 0;
    const stackPmMgNm3_actual = rawPmMgNm3 * (1 - baghouseEfficiencyPct / 100);

    // 5. Hydrochloric Acid (HCl) from fuel chlorine
    const cl_in_fuel_kg_s = fuelDryKgS * (fuel.chlorine_dry / 100);
    const rawHclMassKgS = cl_in_fuel_kg_s * 0.95 * (36.46 / 35.45);
    const rawHclMgNm3 = flueGasFlowNm3Hr > 0 ? (rawHclMassKgS * 3.6e9) / flueGasFlowNm3Hr : 25;
    const stackHclMgNm3_actual = rawHclMgNm3 * (1 - scrubberEfficiencyPct * 0.9 / 100);

    // ==========================================
    // Reference Oxygen Normalization (6% O2 dry)
    // C_ref = C_meas * (21 - 6) / (21 - O2_meas)
    // ==========================================
    const O2_ref = 6.0;
    const o2_meas = Math.max(1.0, Math.min(18.0, flueGasO2DryPct));
    const o2CorrectionFactor = (20.95 - O2_ref) / Math.max(0.5, 20.95 - o2_meas);

    const nox_ref6 = stackNoxMgNm3_actual * o2CorrectionFactor;
    const so2_ref6 = stackSo2MgNm3_actual * o2CorrectionFactor;
    const co_ref6 = stackCoMgNm3_actual * o2CorrectionFactor;
    const pm_ref6 = stackPmMgNm3_actual * o2CorrectionFactor;
    const hcl_ref6 = stackHclMgNm3_actual * o2CorrectionFactor;

    return {
      o2_dry_pct: flueGasO2DryPct,
      co2_wet_pct: 13.8,
      co2_mass_rate_kg_s: co2MassRateKgS,
      biogenic_co2_tonnes_day: biogenicCo2TonnesDay,
      fossil_co2_tonnes_day: fossilCo2TonnesDay,
      nox_ppm: nox_ref6 / 2.05, // mg/Nm3 NO2 to ppm approx
      nox_mg_nm3_ref6o2: nox_ref6,
      so2_ppm: so2_ref6 / 2.86,
      so2_mg_nm3_ref6o2: so2_ref6,
      co_ppm: co_ref6 / 1.25,
      co_mg_nm3_ref6o2: co_ref6,
      pm_mg_nm3_ref6o2: pm_ref6,
      hcl_mg_nm3_ref6o2: hcl_ref6,
      flue_gas_flow_nm3_hr: flueGasFlowNm3Hr,
      stack_temperature_c: 142,
      sncr_efficiency_pct: sncrEfficiencyPct,
      baghouse_efficiency_pct: baghouseEfficiencyPct,
      scrubber_efficiency_pct: scrubberEfficiencyPct,
    };
  }
}
