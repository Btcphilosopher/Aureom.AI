/**
 * AUREOM.AI — BIOMASS.OS
 * Financial Engineering (LCOE, CAPEX, OPEX, NPV, IRR) & Carbon Accounting (RED II Lifecycle)
 */

import { BiomassFuel, FinancialMetrics } from '../models/plant.models';

export interface CarbonAccountingMetrics {
  biogenicStackCo2TonnesYear: number;
  fossilStackCo2TonnesYear: number;
  upstreamFuelHarvestCo2TonnesYear: number;
  transportSupplyChainCo2TonnesYear: number;
  totalLifecycleCo2eTonnesYear: number;
  lifecycleEmissionIntensityGCo2ePerKwh: number;
  fossilGridDisplacedCo2TonnesYear: number;
  netAnnualCarbonAvoidedTonnes: number;
  red2GhgSavingsPct: number;
  red2Compliant: boolean;
}

export class FinancialAndCarbonEngine {
  /**
   * Financial model evaluation based on rated power, fuel costs, electricity/heat tariffs, and discount rate
   */
  public static calculateFinancials(
    ratedElectricalMW: number,
    netElectricalMW: number,
    annualFuelTonnes: number,
    fuelCostPerTonne: number,
    annualGenerationMWh: number,
    annualHeatMWh: number,
    electricityTariffUSDPerMWh = 115.0,
    heatTariffUSDPerMWh = 42.0,
    carbonCreditUSDPerTonne = 35.0,
    discountRatePct = 7.5,
    projectLifetimeYears = 25
  ): FinancialMetrics {
    // Specific overnight capital cost for industrial biomass power plants: ~$3,800 - $4,600 / kW
    const specificCapexUsdPerKw = 4100;
    const capexUSD = ratedElectricalMW * 1000 * specificCapexUsdPerKw;

    // Annual OPEX items:
    const fuelCostAnnualUSD = annualFuelTonnes * fuelCostPerTonne;
    // Fixed O&M: ~$95 / kW-year (staff, insurance, scheduled outages)
    const fixedOpex = ratedElectricalMW * 1000 * 95;
    // Variable O&M: ~$4.8 / MWh (water treatment, lime, ammonia reagents, baghouse filter bags, lube oils)
    const variableOpex = annualGenerationMWh * 4.8;
    // Ash disposal: ~$28 / tonne ash
    const ashDisposal = annualFuelTonnes * 0.025 * 28;
    const opexAnnualUSD = fuelCostAnnualUSD + fixedOpex + variableOpex + ashDisposal;

    // Revenues
    const electricityRevenueAnnualUSD = annualGenerationMWh * electricityTariffUSDPerMWh;
    const heatRevenueAnnualUSD = annualHeatMWh * heatTariffUSDPerMWh;
    // Carbon offset credit revenue (e.g., premium certificates / green credits)
    const carbonCreditsAnnualUSD = (annualGenerationMWh * 0.45) * carbonCreditUSDPerTonne; // 0.45 t/MWh displaced

    const totalRevenueUSD = electricityRevenueAnnualUSD + heatRevenueAnnualUSD + carbonCreditsAnnualUSD;
    const ebitdaAnnualUSD = totalRevenueUSD - opexAnnualUSD;

    // Levelized Cost of Electricity (LCOE)
    // LCOE = (CRF * CAPEX + OPEX_annual - Heat_Credit) / Generation_annual
    const r = discountRatePct / 100;
    const n = projectLifetimeYears;
    const crf = (r * Math.pow(1 + r, n)) / Math.max(0.001, Math.pow(1 + r, n) - 1); // Capital Recovery Factor
    const annualCapitalCharge = capexUSD * crf;
    const netAnnualGenerationCost = annualCapitalCharge + opexAnnualUSD - heatRevenueAnnualUSD;
    const lcoeUSDPerMWh = annualGenerationMWh > 0 ? netAnnualGenerationCost / annualGenerationMWh : 0;

    // Net Present Value (NPV)
    let npvUSD = -capexUSD;
    for (let t = 1; t <= n; t++) {
      npvUSD += ebitdaAnnualUSD / Math.pow(1 + r, t);
    }

    // Simple Payback
    const simplePaybackYears = ebitdaAnnualUSD > 0 ? capexUSD / ebitdaAnnualUSD : 99;

    // Internal Rate of Return (IRR) approximation
    let irrPct = 0;
    if (ebitdaAnnualUSD > 0) {
      // Newton approximation for IRR
      let irr = 0.10;
      for (let iter = 0; iter < 10; iter++) {
        let f = -capexUSD;
        let df = 0;
        for (let t = 1; t <= n; t++) {
          f += ebitdaAnnualUSD / Math.pow(1 + irr, t);
          df -= (t * ebitdaAnnualUSD) / Math.pow(1 + irr, t + 1);
        }
        if (Math.abs(f) < 1000) break;
        irr = irr - f / (df || 1);
      }
      irrPct = Math.max(-5, Math.min(45, irr * 100));
    }

    return {
      capexUSD,
      opexAnnualUSD,
      fuelCostAnnualUSD,
      electricityRevenueAnnualUSD,
      heatRevenueAnnualUSD,
      carbonCreditsAnnualUSD,
      ebitdaAnnualUSD,
      lcoeUSDPerMWh,
      npvUSD,
      irrPct,
      simplePaybackYears,
    };
  }

  /**
   * Transparent Carbon Accounting and RED II / RED III Sustainability Assessment
   */
  public static calculateCarbonAccounting(
    fuel: BiomassFuel,
    annualFuelTonnes: number,
    annualGenerationMWh: number,
    annualHeatMWh: number,
    averageTransportDistanceKm = 75
  ): CarbonAccountingMetrics {
    // 1. Biogenic Carbon at Stack:
    // Every kg Carbon produces 44/12 kg CO2. Biogenic cycle is closed by forest/crop regrowth.
    const carbonFractionDry = fuel.carbon_dry / 100;
    const dryFuelTonnes = annualFuelTonnes * (1 - fuel.moisture_ar / 100);
    const biogenicStackCo2TonnesYear = dryFuelTonnes * carbonFractionDry * (44.01 / 12.011);
    const fossilStackCo2TonnesYear = 0.0; // 0 fossil fuel in steady state

    // 2. Upstream harvesting, cultivation, and chipping:
    const upstreamFuelHarvestCo2TonnesYear = annualFuelTonnes * (fuel.upstream_co2_kg_per_tonne / 1000);

    // 3. Transport emissions:
    // Heavy truck: ~0.082 kg CO2e / tonne-km
    const transportSupplyChainCo2TonnesYear = annualFuelTonnes * averageTransportDistanceKm * (0.082 / 1000);

    // Total Lifecycle Fossil GHG footprint:
    const totalLifecycleCo2eTonnesYear = upstreamFuelHarvestCo2TonnesYear + transportSupplyChainCo2TonnesYear;

    // Specific Emission Intensity per electrical output:
    const totalUsefulEnergyMWh = annualGenerationMWh + annualHeatMWh;
    const lifecycleEmissionIntensityGCo2ePerKwh = totalUsefulEnergyMWh > 0
      ? (totalLifecycleCo2eTonnesYear * 1e6) / (totalUsefulEnergyMWh * 1000)
      : 32;

    // Fossil grid baseline comparison (EU standard fossil comparator: 183 g CO2eq/MJ = 660 g CO2/kWh):
    const fossilBaselineGPerKwh = 660; // g CO2/kWh
    const fossilGridDisplacedCo2TonnesYear = (annualGenerationMWh * 1000 * fossilBaselineGPerKwh) / 1e6;
    const netAnnualCarbonAvoidedTonnes = fossilGridDisplacedCo2TonnesYear - totalLifecycleCo2eTonnesYear;

    // EU RED II GHG savings threshold:
    // GHG_savings = (Fossil_comparator - Actual_lifecycle) / Fossil_comparator
    const red2GhgSavingsPct = ((fossilBaselineGPerKwh - lifecycleEmissionIntensityGCo2ePerKwh) / fossilBaselineGPerKwh) * 100;
    const red2Compliant = red2GhgSavingsPct >= 80.0; // RED II requires ≥70-80% savings for new biomass plants

    return {
      biogenicStackCo2TonnesYear,
      fossilStackCo2TonnesYear,
      upstreamFuelHarvestCo2TonnesYear,
      transportSupplyChainCo2TonnesYear,
      totalLifecycleCo2eTonnesYear,
      lifecycleEmissionIntensityGCo2ePerKwh,
      fossilGridDisplacedCo2TonnesYear,
      netAnnualCarbonAvoidedTonnes,
      red2GhgSavingsPct,
      red2Compliant,
    };
  }
}
