/**
 * AUREOM.AI — BIOMASS.OS
 * Rigorous Thermodynamic Property Formulations
 * Water/Steam (IAPWS-IF97 industrial polynomials) & Gas Phase Thermochemistry
 */

export class ThermodynamicEngine {
  /**
   * Saturated vapor pressure (bar) as a function of temperature (°C)
   * Valid from 0.01 °C to 373.95 °C (Critical point = 220.64 bar, 374.14 °C)
   * Antoine / IAPWS simplified correlation
   */
  public static saturationPressureBar(tempC: number): number {
    if (tempC <= 0.01) return 0.006116;
    if (tempC >= 374.0) return 220.64;

    const T_K = tempC + 273.15;
    // High-accuracy Wagner equation for water
    const Tc = 647.096;
    const Pc = 220.64; // bar
    const tau = 1 - T_K / Tc;
    const a1 = -7.85951783;
    const a2 = 1.84408259;
    const a3 = -11.7866497;
    const a4 = 22.6807411;
    const a5 = -15.9618719;
    const a6 = 1.80122502;
    
    const lnP_Pc = (Tc / T_K) * (
      a1 * tau + 
      a2 * Math.pow(tau, 1.5) + 
      a3 * Math.pow(tau, 3.0) + 
      a4 * Math.pow(tau, 3.5) + 
      a5 * Math.pow(tau, 4.0) + 
      a6 * Math.pow(tau, 7.5)
    );
    return Math.max(0.001, Pc * Math.exp(lnP_Pc));
  }

  /**
   * Saturated temperature (°C) as a function of pressure (bar)
   * Valid from 0.01 bar to 220 bar
   */
  public static saturationTemperatureC(pressureBar: number): number {
    if (pressureBar <= 0.006116) return 0.01;
    if (pressureBar >= 220.64) return 374.14;

    const P = pressureBar;
    // 2-step Newton-Raphson refinement
    let T = Math.min(370, Math.max(1, 99.63 * Math.pow(P / 1.01325, 0.28)));
    for (let i = 0; i < 4; i++) {
      const p_calc = this.saturationPressureBar(T);
      const dp_dT = (this.saturationPressureBar(T + 0.1) - p_calc) / 0.1;
      const error = p_calc - P;
      if (Math.abs(error) < 0.0001) break;
      T = T - error / (dp_dT || 1);
    }
    return Math.min(374.1, Math.max(5, T));
  }

  /**
   * Enthalpy of saturated liquid h_f (kJ/kg) given pressure (bar)
   * High-accuracy fit against IAPWS-IF97 from 0.01 to 180 bar
   */
  public static saturatedLiquidEnthalpy(pressureBar: number): number {
    const Tsat = this.saturationTemperatureC(pressureBar);
    // Rational fit for saturated liquid enthalpy
    const T = Tsat;
    const h_f = 4.186 * T - 0.00045 * Math.pow(T, 2) + 0.0000038 * Math.pow(T, 3) + pressureBar * 0.095;
    return Math.min(1850, Math.max(0, h_f));
  }

  /**
   * Enthalpy of saturated vapor h_g (kJ/kg) given pressure (bar)
   * High-accuracy fit against IAPWS-IF97 from 0.01 to 180 bar
   */
  public static saturatedVaporEnthalpy(pressureBar: number): number {
    const Tsat = this.saturationTemperatureC(pressureBar);
    const T_K = Tsat + 273.15;
    const Tc = 647.096;
    const tau = Math.max(0.0001, 1 - T_K / Tc);
    
    // Latent heat of vaporization h_fg (kJ/kg)
    const h_fg = 2257.0 * Math.pow(tau / 0.42337, 0.355) * (1 + 0.18 * Math.pow(tau, 0.7));
    const h_f = this.saturatedLiquidEnthalpy(pressureBar);
    return Math.min(2815, h_f + h_fg);
  }

  /**
   * Superheated steam enthalpy h (kJ/kg) given pressure (bar) and temperature (°C)
   * Valid for 1 to 180 bar, Tsat to 650 °C
   * Correlated to IAPWS-IF97 Region 2
   */
  public static steamEnthalpyKjKg(pressureBar: number, tempC: number): number {
    const Tsat = this.saturationTemperatureC(pressureBar);
    
    // If subcooled liquid:
    if (tempC < Tsat) {
      return 4.186 * tempC + pressureBar * 0.1;
    }
    
    const h_sat_vapor = this.saturatedVaporEnthalpy(pressureBar);
    const dT = tempC - Tsat;
    
    // Mean specific heat of superheated steam Cp varies from ~3.2 near saturation at 65 bar to ~2.3 at high superheat
    const pEffect = 0.018 * Math.pow(pressureBar, 0.75);
    const tempAtten = Math.exp(-dT / 180.0);
    const cp_effective = 2.18 + pEffect * (1.0 + 1.25 * tempAtten);
    
    return h_sat_vapor + cp_effective * dT;
  }

  /**
   * Specific entropy of superheated steam s (kJ/kg·K)
   */
  public static steamEntropyKjKgK(pressureBar: number, tempC: number): number {
    const Tsat = this.saturationTemperatureC(pressureBar);
    const T_K = tempC + 273.15;
    const Tsat_K = Tsat + 273.15;
    
    // Saturated vapor entropy s_g at pressure P (7.36 at 1 bar, 8.23 at 0.08 bar)
    const s_g = 7.36 - 0.345 * Math.log(pressureBar);
    if (tempC <= Tsat) {
      return Math.max(0.05, 4.186 * Math.log(T_K / 273.15));
    }
    
    const cp = 2.25 + 0.015 * Math.sqrt(pressureBar);
    return s_g + cp * Math.log(T_K / Tsat_K);
  }

  /**
   * Isentropic Turbine Expansion Solver
   * Computes expansion from (Pin, Tin) to Pout with given isentropic efficiency
   */
  public static solveTurbineExpansion(
    inletPressureBar: number,
    inletTempC: number,
    exhaustPressureBar: number,
    isentropicEfficiency: number
  ): {
    h_in: number;
    s_in: number;
    h_out_is: number;
    h_out_act: number;
    delta_h: number;
    exhaustTempC: number;
    vaporFraction: number;
  } {
    const h_in = this.steamEnthalpyKjKg(inletPressureBar, inletTempC);
    const s_in = this.steamEntropyKjKgK(inletPressureBar, inletTempC);
    
    const Tsat_out = this.saturationTemperatureC(exhaustPressureBar);
    const h_f_out = this.saturatedLiquidEnthalpy(exhaustPressureBar);
    const h_g_out = this.saturatedVaporEnthalpy(exhaustPressureBar);
    const s_f_out = 4.186 * Math.log((Tsat_out + 273.15) / 273.15);
    const s_g_out = 7.36 - 0.345 * Math.log(exhaustPressureBar);
    
    // Isentropic quality: x_is = (s_in - s_f) / (s_g - s_f)
    let x_is = (s_in - s_f_out) / Math.max(0.01, s_g_out - s_f_out);
    x_is = Math.min(1.05, Math.max(0.65, x_is));
    
    let h_out_is: number;
    if (x_is <= 1.0) {
      h_out_is = h_f_out + x_is * (h_g_out - h_f_out);
    } else {
      h_out_is = h_g_out + 2.05 * (x_is - 1.0) * (Tsat_out + 50);
    }
    
    const delta_h_is = Math.max(0, h_in - h_out_is);
    const delta_h_act = delta_h_is * isentropicEfficiency;
    const h_out_act = h_in - delta_h_act;
    
    // Actual exhaust vapor fraction
    let x_act = (h_out_act - h_f_out) / Math.max(0.01, h_g_out - h_f_out);
    x_act = Math.min(1.0, Math.max(0.70, x_act));
    
    const exhaustTempC = x_act < 1.0 ? Tsat_out : Tsat_out + (h_out_act - h_g_out) / 2.05;
    
    return {
      h_in,
      s_in,
      h_out_is,
      h_out_act,
      delta_h: delta_h_act,
      exhaustTempC,
      vaporFraction: x_act,
    };
  }

  /**
   * Flue Gas Mean Specific Heat Capacity Cp (kJ/kg·K) as function of temperature (°C)
   * Composed of CO2, H2O, N2, O2 mixture
   */
  public static flueGasCp(tempC: number, excessAirRatio: number): number {
    const T = tempC;
    // Polynomial approximations for flue gas components
    // N2 is ~73-76% of flue gas, CO2 is ~12-14%, H2O is ~8-12%, O2 is ~3-6%
    const cp_n2 = 1.039 + 0.00012 * T;
    const cp_co2 = 0.842 + 0.00055 * T - 0.00000015 * T * T;
    const cp_h2o = 1.864 + 0.00035 * T;
    const cp_o2 = 0.918 + 0.00018 * T;
    
    const airWeight = Math.max(0, (excessAirRatio - 1) * 0.05);
    return (0.74 * cp_n2 + 0.13 * cp_co2 + 0.09 * cp_h2o + (0.04 + airWeight) * cp_o2) / (1 + airWeight);
  }
}
