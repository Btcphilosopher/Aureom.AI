/**
 * AUREOM.AI — BIOMASS.OS
 * Combustion Physics, Stoichiometry, Flue Gas Balances & ASME PTC 4 Heat Loss Method
 */

import { BiomassFuel, BoilerPerformance } from '../models/plant.models';
import { FuelLaboratoryService } from './fuel-laboratory';
import { ThermodynamicEngine } from './thermodynamics';

export interface CombustionResult {
  excessAirRatioLambda: number;
  totalAirFlowKgS: number;
  primaryAirFlowKgS: number;
  secondaryAirFlowKgS: number;
  flueGasFlowKgS: number;
  flueGasFlowNm3Hr: number;
  flueGasO2DryPct: number;
  flueGasO2WetPct: number;
  flueGasCo2DryPct: number;
  flueGasH2oWetPct: number;
  adiabaticFlameTempC: number;
  furnaceBedTempC: number;
  boilerPerformance: BoilerPerformance;
}

export class CombustionEngine {
  /**
   * Solve complete combustion, stoichiometry, flue gas mass balance and ASME PTC 4 heat loss
   */
  public static solveCombustion(
    fuel: BiomassFuel,
    fuelFeedRateKgS: number,
    moisturePct: number,
    targetExcessO2DryPct: number,
    primaryAirFraction = 0.65,
    ambientTempC = 20,
    stackTempC = 145,
    steamPressureBar = 65,
    steamTempC = 480,
    feedwaterTempC = 135,
    foulingFactor = 1.0
  ): CombustionResult {
    const C = fuel.carbon_dry / 100;
    const H = fuel.hydrogen_dry / 100;
    const N = fuel.nitrogen_dry / 100;
    const S = fuel.sulfur_dry / 100;
    const Ash = fuel.ash_dry / 100;
    const M = moisturePct / 100;
    const dryFraction = 1 - M;

    // Heating values
    const lhvAr = FuelLaboratoryService.calculateLhvAsReceived(fuel, moisturePct);
    const fuelThermalInputMW = fuelFeedRateKgS * lhvAr;

    // Convert target dry O2 % to excess air ratio lambda:
    // lambda ≈ 21 / (21 - O2_dry_pct)
    const o2_target = Math.max(2.0, Math.min(10.0, targetExcessO2DryPct));
    const lambda = 20.95 / (20.95 - o2_target);

    // Stoichiometric air (kg air per kg fuel AR)
    const stoichAirKgKgAr = FuelLaboratoryService.stoichiometricAirKgPerKgAr(fuel, moisturePct);
    const actualAirKgKgAr = stoichAirKgKgAr * lambda;
    const totalAirFlowKgS = actualAirKgKgAr * fuelFeedRateKgS;

    const primaryAirFlowKgS = totalAirFlowKgS * primaryAirFraction;
    const secondaryAirFlowKgS = totalAirFlowKgS * (1 - primaryAirFraction);

    // Flue gas products per kg fuel AR:
    // CO2 produced = (C * dryFraction) * (44 / 12)
    const m_co2 = C * dryFraction * (44.01 / 12.011);
    // H2O from H combustion + fuel moisture = (H * dryFraction * 9) + M
    const m_h2o = (H * dryFraction * 8.936) + M;
    // SO2 produced = (S * dryFraction) * (64 / 32)
    const m_so2 = S * dryFraction * (64.06 / 32.06);
    // N2 from fuel + N2 from combustion air (air is 76.8% N2 by mass)
    const m_n2 = (N * dryFraction) + actualAirKgKgAr * 0.768;
    // Excess O2 in flue gas = (lambda - 1) * stoichAir * 0.232
    const m_o2 = (lambda - 1) * stoichAirKgKgAr * 0.232;

    const m_flue_gas_kg_kg_fuel = m_co2 + m_h2o + m_so2 + m_n2 + m_o2;
    const flueGasFlowKgS = m_flue_gas_kg_kg_fuel * fuelFeedRateKgS;

    // Convert to dry basis molar / volume percentages
    const mol_co2 = m_co2 / 44.01;
    const mol_so2 = m_so2 / 64.06;
    const mol_n2 = m_n2 / 28.013;
    const mol_o2 = m_o2 / 32.0;
    const mol_h2o = m_h2o / 18.015;

    const total_moles_dry = mol_co2 + mol_so2 + mol_n2 + mol_o2;
    const total_moles_wet = total_moles_dry + mol_h2o;

    const o2_dry_calc = (mol_o2 / total_moles_dry) * 100;
    const o2_wet_calc = (mol_o2 / total_moles_wet) * 100;
    const co2_dry_calc = (mol_co2 / total_moles_dry) * 100;
    const h2o_wet_calc = (mol_h2o / total_moles_wet) * 100;

    // Volume flow in Nm3/hr (at 0°C, 101.325 kPa, 22.414 Nm3/kmol)
    const nm3_per_kg_fuel = total_moles_wet * 22.414;
    const flueGasFlowNm3Hr = nm3_per_kg_fuel * (fuelFeedRateKgS * 3600);

    // Adiabatic flame temperature estimation
    // Energy in = Fuel LHV_ar + Air preheat sensible heat
    // Energy out = flue gas sensible heat
    const cp_flue = ThermodynamicEngine.flueGasCp(950, lambda);
    const adiabaticDeltaT = (lhvAr * 1000) / (m_flue_gas_kg_kg_fuel * cp_flue);
    const adiabaticFlameTempC = Math.min(1600, ambientTempC + adiabaticDeltaT);
    
    // Furnace bed temperature accounts for direct radiation to furnace waterwalls (~45% absorption in furnace)
    const furnaceBedTempC = ambientTempC + (adiabaticFlameTempC - ambientTempC) * (0.62 / Math.sqrt(foulingFactor));

    // ==========================================
    // ASME PTC 4 / DIN 1942 Heat Loss Method (LHV Basis)
    // ==========================================
    // 1. Dry flue gas loss (sensible heat lost out stack)
    const cp_dry_gas = 1.025; // kJ/kg·K
    const dryGasMassKgKg = m_co2 + m_so2 + m_n2 + m_o2;
    const deltaT_stack = Math.max(10, stackTempC - ambientTempC);
    const q_loss_dry_gas = (dryGasMassKgKg * cp_dry_gas * deltaT_stack) / (lhvAr * 1000) * 100;

    // 2. Fuel moisture sensible loss (against LHV basis, latent heat is already deducted in LHV)
    // Sensible superheating of water vapor from ambient to stack temperature
    const cp_vapor = 1.92; // kJ/kg·K
    const q_loss_fuel_moisture = (M * cp_vapor * deltaT_stack) / (lhvAr * 1000) * 100;

    // 3. Moisture from combustion of hydrogen sensible loss
    const waterFromH = H * dryFraction * 8.936;
    const q_loss_h2_moisture = (waterFromH * cp_vapor * deltaT_stack) / (lhvAr * 1000) * 100;

    // 4. Radiation and convection surface losses (standard ABMA curve: ~0.4% - 1.2% for 20-80 MW)
    const q_loss_radiation = Math.max(0.60, 1.35 / Math.sqrt(Math.max(5, fuelThermalInputMW / 20)));

    // 5. Unburned carbon and CO combustibles loss (typically 0.4 - 1.0% for industrial grate)
    const q_loss_unburned_carbon = 0.65 * (1 + 0.1 * Math.abs(lambda - 1.3));

    // 6. Ash sensible heat loss and standard ASME unaccounted margin
    const q_loss_ash_sensible = (Ash * dryFraction * 0.85 * 400.0) / (lhvAr * 1000) * 100;
    const q_loss_unaccounted = 2.2; // ASME PTC 4 manufacturer and unmeasured tolerance

    // Total ASME / DIN losses
    const totalLosses = q_loss_dry_gas + q_loss_fuel_moisture + q_loss_h2_moisture + q_loss_radiation + q_loss_unburned_carbon + q_loss_ash_sensible + q_loss_unaccounted;
    const boilerEfficiencyPct = Math.max(65.0, Math.min(92.0, (100 - totalLosses) / foulingFactor));

    // Boiler thermal heat absorbed into steam cycle (MW)
    const thermalPowerMW = fuelThermalInputMW * (boilerEfficiencyPct / 100);

    // Steam generation rate calculation:
    // Q_absorbed = m_steam * (h_superheat - h_feedwater)
    const h_steam = ThermodynamicEngine.steamEnthalpyKjKg(steamPressureBar, steamTempC);
    const h_fw = ThermodynamicEngine.steamEnthalpyKjKg(steamPressureBar * 1.15, feedwaterTempC);
    const deltaH_steam = Math.max(1500, h_steam - h_fw); // kJ/kg
    
    // m_steam = Q (kW) / deltaH (kJ/kg) -> kg/s
    const steamMassFlowKgS = (thermalPowerMW * 1000) / deltaH_steam;
    const steamFlowTonnesHr = steamMassFlowKgS * 3.6;

    const boilerPerformance: BoilerPerformance = {
      thermalPowerMW,
      steamFlowTonnesHr,
      efficiencyASME_pct: boilerEfficiencyPct,
      heatLossDryGas_pct: q_loss_dry_gas,
      heatLossFuelMoisture_pct: q_loss_fuel_moisture,
      heatLossHydrogenMoisture_pct: q_loss_h2_moisture,
      heatLossRadiationConvection_pct: q_loss_radiation,
      heatLossUnburnedCarbon_pct: q_loss_unburned_carbon,
      drumPressureBar: steamPressureBar + 4.5, // accounting for superheater pressure drop
      drumWaterLevelMm: 0, // centered nominal
      steamTemperatureC: steamTempC,
      feedwaterPressureBar: steamPressureBar + 12.0,
      feedwaterTemperatureC: feedwaterTempC,
      economizerExitTempC: 220,
      airPreheaterExitTempC: stackTempC,
      foulingFactor,
    };

    return {
      excessAirRatioLambda: lambda,
      totalAirFlowKgS,
      primaryAirFlowKgS,
      secondaryAirFlowKgS,
      flueGasFlowKgS,
      flueGasFlowNm3Hr,
      flueGasO2DryPct: o2_dry_calc,
      flueGasO2WetPct: o2_wet_calc,
      flueGasCo2DryPct: co2_dry_calc,
      flueGasH2oWetPct: h2o_wet_calc,
      adiabaticFlameTempC,
      furnaceBedTempC,
      boilerPerformance,
    };
  }
}
