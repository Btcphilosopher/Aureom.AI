/**
 * AUREOM.AI — BIOMASS.OS
 * Scientific Engineering Test Suite
 * Validates physical conservation laws, heating value formulas, and 20 MWe reference plant design point
 */

import { describe, it, expect } from 'vitest';
import { PRESET_BIOMASS_FUELS, FuelLaboratoryService } from './fuel-laboratory';
import { CombustionEngine } from './combustion-engine';
import { ThermodynamicEngine } from './thermodynamics';
import { SteamCycleEngine } from './steam-cycle';
import { EmissionsEngine } from './emissions-engine';
import { FinancialAndCarbonEngine } from './financial-carbon';

describe('Biomass Fuel Laboratory & Calorimetry', () => {
  const woodChips = PRESET_BIOMASS_FUELS[0];

  it('should compute dry HHV according to Channiwala & Parikh within physical range (18-21 MJ/kg)', () => {
    const hhvDry = FuelLaboratoryService.calculateHhvDry(woodChips);
    expect(hhvDry).toBeGreaterThan(18.0);
    expect(hhvDry).toBeLessThan(21.5);
  });

  it('should compute lower heating value on as-received basis with correct water latent heat deduction', () => {
    const lhvAr = FuelLaboratoryService.calculateLhvAsReceived(woodChips, 35.0);
    // At 35% moisture, forestry wood chips typically yield ~10.5 - 11.5 MJ/kg
    expect(lhvAr).toBeGreaterThan(9.5);
    expect(lhvAr).toBeLessThan(12.0);
  });

  it('should satisfy consistency check: 20 MW net at 25% efficiency requires ~80 MW thermal input and ~28 t/h fuel at 10.3 MJ/kg', () => {
    const metrics = FuelLaboratoryService.calculateConsumptionMetrics(80.0, woodChips, 35.0);
    expect(metrics.feedRateKgS).toBeGreaterThan(6.5);
    expect(metrics.feedRateKgS).toBeLessThan(8.5);
    expect(metrics.feedRateTonnesHr).toBeGreaterThan(24.0);
    expect(metrics.feedRateTonnesHr).toBeLessThan(30.0);
  });
});

describe('Water and Steam Thermodynamic Properties (IAPWS-IF97)', () => {
  it('should accurately calculate saturation pressure: 100°C -> ~1.013 bar', () => {
    const pSat = ThermodynamicEngine.saturationPressureBar(100);
    expect(pSat).toBeGreaterThan(0.98);
    expect(pSat).toBeLessThan(1.05);
  });

  it('should accurately calculate saturation temperature: 65 bar -> ~280°C', () => {
    const tSat = ThermodynamicEngine.saturationTemperatureC(65.0);
    expect(tSat).toBeGreaterThan(275.0);
    expect(tSat).toBeLessThan(286.0);
  });

  it('should calculate superheated steam enthalpy at 65 bar, 480°C to be approximately 3,370 kJ/kg', () => {
    const h = ThermodynamicEngine.steamEnthalpyKjKg(65.0, 480.0);
    expect(h).toBeGreaterThan(3300.0);
    expect(h).toBeLessThan(3450.0);
  });

  it('should compute turbine isentropic expansion with positive enthalpy drop and realistic exhaust vapor fraction', () => {
    const expansion = ThermodynamicEngine.solveTurbineExpansion(65.0, 480.0, 0.08, 0.84);
    expect(expansion.delta_h).toBeGreaterThan(800.0);
    expect(expansion.delta_h).toBeLessThan(1250.0);
    expect(expansion.vaporFraction).toBeGreaterThan(0.85);
    expect(expansion.vaporFraction).toBeLessThanOrEqual(1.0);
  });
});

describe('Combustion Stoichiometry & ASME PTC 4 Heat Balance', () => {
  const woodChips = PRESET_BIOMASS_FUELS[0];

  it('should close boiler energy balance with reasonable efficiency (82 - 89%)', () => {
    const res = CombustionEngine.solveCombustion(woodChips, 7.5, 35.0, 4.2);
    expect(res.boilerPerformance.efficiencyASME_pct).toBeGreaterThan(80.0);
    expect(res.boilerPerformance.efficiencyASME_pct).toBeLessThan(90.0);
    expect(res.adiabaticFlameTempC).toBeGreaterThan(1200.0);
    expect(res.furnaceBedTempC).toBeGreaterThan(800.0);
    expect(res.furnaceBedTempC).toBeLessThan(1100.0);
  });
});

describe('Rankine Steam Turbomachinery Cycle & Auxiliary Accounting', () => {
  it('should generate ~20 MW net electrical output from ~78 t/h steam flow at 65 bar / 480°C', () => {
    const steamMassFlowKgS = 80.0 / 3.6; // ~22.2 kg/s (80 t/h)
    const res = SteamCycleEngine.solveCycle(steamMassFlowKgS, 65.0, 480.0, 0.08, 0.84, 0.975, 0, 3.5, 80.0);
    expect(res.electrical.grossElectricalPowerMW).toBeGreaterThan(19.5);
    expect(res.electrical.grossElectricalPowerMW).toBeLessThan(24.5);
    expect(res.electrical.netElectricalPowerMW).toBeGreaterThan(17.5);
    expect(res.electrical.netElectricalPowerMW).toBeLessThan(22.0);
    expect(res.electrical.netElectricalEfficiencyPct).toBeGreaterThan(22.0);
    expect(res.electrical.netElectricalEfficiencyPct).toBeLessThan(28.0);
  });
});

describe('Environmental Emissions & RED II Carbon Accounting', () => {
  const woodChips = PRESET_BIOMASS_FUELS[0];

  it('should verify EU RED II compliance with > 80% GHG savings versus fossil baseline', () => {
    const carbon = FinancialAndCarbonEngine.calculateCarbonAccounting(
      woodChips,
      210000,
      148920,
      0,
      75
    );
    expect(carbon.red2Compliant).toBe(true);
    expect(carbon.red2GhgSavingsPct).toBeGreaterThan(80.0);
    expect(carbon.lifecycleEmissionIntensityGCo2ePerKwh).toBeLessThan(80.0);
  });

  it('should compute stack emissions with SNCR and baghouse active to be within regulatory limits', () => {
    const emissions = EmissionsEngine.calculateEmissions(woodChips, 7.5, 35.0, 95000, 4.2, 920, 35, 25, true, true);
    expect(emissions.nox_mg_nm3_ref6o2).toBeLessThan(200);
    expect(emissions.pm_mg_nm3_ref6o2).toBeLessThan(10);
  });
});
