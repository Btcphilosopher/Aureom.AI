/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Master Semiconductor Engineering Workstation & Scientific Lab
 */

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from './core/simulation/hbm-simulator';
import { HBMGenKey } from './core/models/hbm-spec';
import { HBMStack3DComponent } from './components/hbm-stack-3d/hbm-stack-3d';
import { ThermalProbeComponent } from './components/instruments/thermal-probe';
import { DramCommandTimelineComponent } from './components/instruments/dram-command-timeline';
import { BandwidthLatencyAnalyzerComponent } from './components/instruments/bandwidth-latency-analyzer';
import { OscilloscopePdnComponent } from './components/instruments/oscilloscope-pdn';
import { TsvFaultLabComponent } from './components/instruments/tsv-fault-lab';
import { ExperimentsSuiteComponent } from './components/instruments/experiments-suite';
import { MonteCarloYieldComponent } from './components/instruments/monte-carlo-yield';

export type InstrumentTab =
  | 'thermal'
  | 'dram'
  | 'bandwidth'
  | 'oscilloscope'
  | 'tsv'
  | 'experiments'
  | 'monte_carlo';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    HBMStack3DComponent,
    ThermalProbeComponent,
    DramCommandTimelineComponent,
    BandwidthLatencyAnalyzerComponent,
    OscilloscopePdnComponent,
    TsvFaultLabComponent,
    ExperimentsSuiteComponent,
    MonteCarloYieldComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public simulator = inject(HBMSimulatorService);

  public activeTab = signal<InstrumentTab>('thermal');
  public isWorkbenchCollapsed = signal<boolean>(false);
  public showExportMenu = signal<boolean>(false);

  public readonly generations: HBMGenKey[] = ['HBM2', 'HBM2E', 'HBM3', 'HBM3E', 'HBM4'];
  public readonly speeds = [1, 2, 5, 20, 100];

  public setTab(tab: InstrumentTab): void {
    this.activeTab.set(tab);
    if (this.isWorkbenchCollapsed()) {
      this.isWorkbenchCollapsed.set(false);
    }
  }

  public toggleWorkbench(): void {
    this.isWorkbenchCollapsed.update((v) => !v);
  }

  public toggleExportMenu(): void {
    this.showExportMenu.update((v) => !v);
  }

  public setGeneration(gen: HBMGenKey): void {
    this.simulator.setGeneration(gen);
  }

  public exportTelemetry(format: 'json' | 'csv'): void {
    this.simulator.exportTelemetryData(format);
    this.showExportMenu.set(false);
  }
}
