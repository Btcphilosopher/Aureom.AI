/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Coherent Scientific Simulation State Data Model
 */

import { HBMGenKey } from './hbm-spec';

export type DRAMCommandType = 'ACT' | 'RD' | 'WR' | 'PRE' | 'REF';

export interface DRAMCommandEvent {
  id: number;
  timeNs: number;
  type: DRAMCommandType;
  channel: number;
  bank: number;
  row: number;
  col: number;
  durationNs: number;
  latencyNs: number;
  isHit: boolean;
}

export type BankStatus = 'IDLE' | 'ACTIVATING' | 'ROW_OPEN' | 'READING' | 'WRITING' | 'PRECHARGING' | 'REFRESHING';

export interface BankState {
  channel: number;
  bank: number;
  status: BankStatus;
  openRow: number | null;
  busyUntilNs: number;
}

export interface TSVNode {
  id: number;
  col: number;
  row: number;
  xMm: number;
  zMm: number;
  signalName: string;
  signalType: 'DQ' | 'DQS' | 'CLK' | 'CMD' | 'VDD' | 'VSS';
  channel: number;
  nominalResistanceMOhms: number;
  actualResistanceMOhms: number;
  capacitanceFF: number;
  fault: 'nominal' | 'open' | 'high_r' | 'bridged' | 'rerouted';
  activePulse: number; // 0 to 1 for visual activity glow
  temperatureK: number;
}

export interface DieThermalState {
  dieIndex: number;
  name: string;
  isBaseDie: boolean;
  temperatureK: number;
  temperatureC: number;
  peakHotspotC: number;
  hotspotX: number;
  hotspotZ: number;
  /** 4x4 spatial finite-difference grid temperatures (Celsius) */
  spatialGridC: number[][];
  powerWatts: {
    background: number;
    active: number;
    refresh: number;
    leakage: number;
    total: number;
  };
}

export interface LatencyHistogramBin {
  latencyNs: number;
  count: number;
}

export type CoolingType = 'passive' | 'forced_air' | 'vapor_chamber' | 'liquid_coldplate';

export interface CoolingCondition {
  type: CoolingType;
  name: string;
  ambientTemperatureC: number;
  heatTransferCoeffH: number; // W / (m^2 * K)
  sinkThermalResistanceKPerW: number;
}

export type WorkloadType =
  | 'sequential_read'
  | 'sequential_write'
  | 'random_read_64b'
  | 'random_write_64b'
  | 'mixed_70_30'
  | 'ai_gemm_burst'
  | 'ai_llm_attention'
  | 'refresh_stress';

export interface WorkloadConfig {
  type: WorkloadType;
  name: string;
  description: string;
  intensityPercent: number; // 0 to 100%
  readRatio: number; // 0 to 1
  concurrencyChannels: number;
  burstLength: number;
}

export interface SimulationClockState {
  /** Master simulation physical time in nanoseconds (discrete DRAM clock) */
  timeNs: number;
  /** Thermal / macro physical time in milliseconds */
  timeMs: number;
  /** Running or paused */
  isPaused: boolean;
  /** Simulation speed multiplier: 1x, 2x, 5x, 20x, 100x */
  speedMultiplier: number;
  /** Number of discrete simulation steps executed */
  stepCount: number;
}

export interface PDNState {
  nominalVddV: number;
  instantaneousVddV: number;
  droopPercent: number;
  currentAmps: number;
  powerDeliveryLossW: number;
  voltageWaveform: { timeNs: number; voltageV: number }[];
}

export interface SignalWaveformPoint {
  timeNs: number;
  voltageV: number;
}

export interface SignalOscilloscopeData {
  timeVectorNs: number[];
  dq0SignalV: number[];
  dqsStrobeV: number[];
  clockSignalV: number[];
  eyeDiagramTraces: number[][];
  jitterPs: number;
  riseTimePs: number;
  voltageMarginMv: number;
}

export interface MonteCarloSample {
  iteration: number;
  tsvResistanceMOhms: number;
  bumpResistanceMOhms: number;
  dieThicknessUm: number;
  peakTemperatureC: number;
  deliveredBandwidthGBs: number;
  totalPowerW: number;
  yieldPass: boolean;
}

export interface MonteCarloDistribution {
  samples: MonteCarloSample[];
  meanBandwidthGBs: number;
  meanPeakTempC: number;
  yieldRatePercent: number;
  active: boolean;
}

export interface HBMSimulationState {
  clock: SimulationClockState;
  generation: HBMGenKey;
  dieCount: number;
  dies: DieThermalState[];
  tsvs: TSVNode[];
  banks: BankState[];
  recentCommands: DRAMCommandEvent[];
  workload: WorkloadConfig;
  cooling: CoolingCondition;
  pdn: PDNState;
  oscilloscope: SignalOscilloscopeData;
  monteCarlo: MonteCarloDistribution;
  
  // Aggregated Performance Metrics
  metrics: {
    theoreticalPeakBandwidthGBs: number;
    deliveredBandwidthGBs: number;
    readThroughputGBs: number;
    writeThroughputGBs: number;
    bandwidthEfficiencyPercent: number;
    channelUtilizationPercent: number;
    rowBufferHitRatePercent: number;
    totalTransactions: number;
    transferredBytesMB: number;
    
    // Latency
    latencyAvgNs: number;
    latencyMedianNs: number;
    latencyP95Ns: number;
    latencyP99Ns: number;
    latencyMaxNs: number;
    latencyHistogram: LatencyHistogramBin[];
    
    // Power
    totalPowerW: number;
    backgroundPowerW: number;
    activePowerW: number;
    refreshPowerW: number;
    leakagePowerW: number;
    
    // Thermal
    stackAvgTempC: number;
    stackMaxTempC: number;
    maxHotspotDieIndex: number;
    thermalRunawayWarning: boolean;
    
    // Refresh & Retention
    currentRefreshIntervalNs: number;
    refreshMultiplier: number; // 1x, 2x, etc.
    retentionFailureProb: number;
    faultCount: number;
  };
}
