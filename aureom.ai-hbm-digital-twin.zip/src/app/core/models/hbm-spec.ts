/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Physical, Architecture & Material Specifications for HBM Generations
 */

export type HBMGenKey = 'HBM2' | 'HBM2E' | 'HBM3' | 'HBM3E' | 'HBM4';

export interface TimingConstraints {
  /** Row to Column Delay (ns) */
  tRCD: number;
  /** Row Precharge Time (ns) */
  tRP: number;
  /** Row Active Time (ns) */
  tRAS: number;
  /** Row Cycle Time (ns) = tRAS + tRP */
  tRC: number;
  /** Column Address Strobe / CAS Read Latency (ns) */
  tCAS: number;
  /** Refresh Cycle Time (ns) */
  tRFC: number;
  /** Average Refresh Interval (ns) - typically 3900 ns (3.9 us) at standard temp */
  tREFI: number;
  /** Write Recovery Time (ns) */
  tWR: number;
}

export interface DieGeometry {
  /** Length in mm (X axis) */
  lengthMm: number;
  /** Width in mm (Z axis) */
  widthMm: number;
  /** Silicon die thickness in micrometers */
  thicknessUm: number;
  /** Microbump standoff height in micrometers */
  bumpHeightUm: number;
}

export interface TSVGeometry {
  /** Array layout columns */
  columns: number;
  /** Array layout rows */
  rows: number;
  /** TSV diameter in micrometers */
  diameterUm: number;
  /** TSV pitch in micrometers */
  pitchUm: number;
  /** Typical DC resistance per via (mOhms) */
  nominalResistanceMOhms: number;
  /** Typical parasitic capacitance per via (fF) */
  nominalCapacitanceFF: number;
  /** Approximate self inductance (pH) */
  nominalInductancePH: number;
}

export interface ThermalProperties {
  /** Silicon density rho (kg/m3) */
  density: number;
  /** Specific heat capacity cp (J / (kg * K)) */
  specificHeat: number;
  /** Silicon thermal conductivity k (W / (m * K)) */
  thermalConductivitySi: number;
  /** Underfill thermal conductivity (W / (m * K)) */
  thermalConductivityUnderfill: number;
  /** Thermal Interface Material (TIM) conductivity (W / (m * K)) */
  thermalConductivityTIM: number;
  /** Copper TSV thermal conductivity (W / (m * K)) */
  thermalConductivityCu: number;
}

export interface HBMProfile {
  generation: HBMGenKey;
  name: string;
  description: string;
  /** Total bus data width in bits (e.g. 1024 or 2048) */
  busWidthBits: number;
  /** Data transfer rate per pin in Gbps (e.g. 2.0, 3.6, 6.4, 9.6, 10.0) */
  transferRateGbps: number;
  /** Core / interface supply voltage VDD (Volts) */
  vddVolts: number;
  /** Default stack DRAM die count (4, 8, 12, or 16) */
  defaultDieCount: number;
  /** Capacity in Gigabytes */
  capacityGB: number;
  /** Number of independent memory channels */
  channels: number;
  /** Number of banks per channel */
  banksPerChannel: number;
  /** Rows per bank */
  rowsPerBank: number;
  /** Columns per row */
  columnsPerRow: number;
  /** Die geometry */
  geometry: DieGeometry;
  /** TSV parameters */
  tsv: TSVGeometry;
  /** Timing constraints */
  timing: TimingConstraints;
  /** Thermal physical constants */
  thermal: ThermalProperties;
  /** Baseline background power per die in Watts */
  pBackgroundPerDieW: number;
  /** Energy per Read operation in picojoules per bit */
  energyPerReadPjPerBit: number;
  /** Energy per Write operation in picojoules per bit */
  energyPerWritePjPerBit: number;
  /** Base logic PHY power in Watts */
  baseDiePowerW: number;
}

export const HBM_PROFILES: Record<HBMGenKey, HBMProfile> = {
  HBM2: {
    generation: 'HBM2',
    name: 'JEDEC HBM2 (JESD235B)',
    description: 'First widespread AI/HPC 3D stacked DRAM standard. 1024-bit wide bus, 2.0 Gbps/pin.',
    busWidthBits: 1024,
    transferRateGbps: 2.0,
    vddVolts: 1.2,
    defaultDieCount: 4,
    capacityGB: 8,
    channels: 8,
    banksPerChannel: 16,
    rowsPerBank: 32768,
    columnsPerRow: 64,
    geometry: {
      lengthMm: 7.75,
      widthMm: 11.87,
      thicknessUm: 50,
      bumpHeightUm: 20,
    },
    tsv: {
      columns: 16,
      rows: 32,
      diameterUm: 5.5,
      pitchUm: 55,
      nominalResistanceMOhms: 38,
      nominalCapacitanceFF: 65,
      nominalInductancePH: 45,
    },
    timing: {
      tRCD: 14.0,
      tRP: 14.0,
      tRAS: 32.0,
      tRC: 46.0,
      tCAS: 14.0,
      tRFC: 260.0,
      tREFI: 3900.0,
      tWR: 15.0,
    },
    thermal: {
      density: 2330,
      specificHeat: 700,
      thermalConductivitySi: 148,
      thermalConductivityUnderfill: 0.6,
      thermalConductivityTIM: 3.5,
      thermalConductivityCu: 400,
    },
    pBackgroundPerDieW: 0.45,
    energyPerReadPjPerBit: 4.8,
    energyPerWritePjPerBit: 5.4,
    baseDiePowerW: 1.8,
  },

  HBM2E: {
    generation: 'HBM2E',
    name: 'JEDEC HBM2E Extended',
    description: 'Enhanced signaling rates up to 3.6 Gbps, 8-Hi stack with 16GB capacity per cube.',
    busWidthBits: 1024,
    transferRateGbps: 3.6,
    vddVolts: 1.2,
    defaultDieCount: 8,
    capacityGB: 16,
    channels: 8,
    banksPerChannel: 16,
    rowsPerBank: 32768,
    columnsPerRow: 64,
    geometry: {
      lengthMm: 7.75,
      widthMm: 11.87,
      thicknessUm: 45,
      bumpHeightUm: 18,
    },
    tsv: {
      columns: 16,
      rows: 32,
      diameterUm: 5.0,
      pitchUm: 50,
      nominalResistanceMOhms: 34,
      nominalCapacitanceFF: 58,
      nominalInductancePH: 42,
    },
    timing: {
      tRCD: 13.0,
      tRP: 13.0,
      tRAS: 30.0,
      tRC: 43.0,
      tCAS: 13.0,
      tRFC: 280.0,
      tREFI: 3900.0,
      tWR: 14.0,
    },
    thermal: {
      density: 2330,
      specificHeat: 700,
      thermalConductivitySi: 148,
      thermalConductivityUnderfill: 0.7,
      thermalConductivityTIM: 4.2,
      thermalConductivityCu: 400,
    },
    pBackgroundPerDieW: 0.52,
    energyPerReadPjPerBit: 4.2,
    energyPerWritePjPerBit: 4.7,
    baseDiePowerW: 2.2,
  },

  HBM3: {
    generation: 'HBM3',
    name: 'JEDEC HBM3 (JESD238)',
    description: 'High-density 16-channel architecture, 6.4 Gbps transfer rate, delivering >819 GB/s.',
    busWidthBits: 1024,
    transferRateGbps: 6.4,
    vddVolts: 1.1,
    defaultDieCount: 12,
    capacityGB: 24,
    channels: 16,
    banksPerChannel: 32,
    rowsPerBank: 65536,
    columnsPerRow: 64,
    geometry: {
      lengthMm: 7.5,
      widthMm: 11.0,
      thicknessUm: 38,
      bumpHeightUm: 15,
    },
    tsv: {
      columns: 20,
      rows: 36,
      diameterUm: 4.2,
      pitchUm: 40,
      nominalResistanceMOhms: 29,
      nominalCapacitanceFF: 48,
      nominalInductancePH: 36,
    },
    timing: {
      tRCD: 11.5,
      tRP: 11.5,
      tRAS: 26.0,
      tRC: 37.5,
      tCAS: 11.5,
      tRFC: 310.0,
      tREFI: 3900.0,
      tWR: 12.0,
    },
    thermal: {
      density: 2330,
      specificHeat: 700,
      thermalConductivitySi: 148,
      thermalConductivityUnderfill: 0.8,
      thermalConductivityTIM: 5.0,
      thermalConductivityCu: 400,
    },
    pBackgroundPerDieW: 0.60,
    energyPerReadPjPerBit: 3.5,
    energyPerWritePjPerBit: 3.9,
    baseDiePowerW: 2.8,
  },

  HBM3E: {
    generation: 'HBM3E',
    name: 'JEDEC HBM3E Extended Speed',
    description: 'Premier AI accelerator memory. Up to 9.6 Gbps, 1.23 TB/s bandwidth per stack, 12-Hi 36GB.',
    busWidthBits: 1024,
    transferRateGbps: 9.6,
    vddVolts: 1.1,
    defaultDieCount: 12,
    capacityGB: 36,
    channels: 16,
    banksPerChannel: 32,
    rowsPerBank: 65536,
    columnsPerRow: 64,
    geometry: {
      lengthMm: 7.5,
      widthMm: 11.0,
      thicknessUm: 33,
      bumpHeightUm: 13,
    },
    tsv: {
      columns: 24,
      rows: 40,
      diameterUm: 3.8,
      pitchUm: 35,
      nominalResistanceMOhms: 26,
      nominalCapacitanceFF: 42,
      nominalInductancePH: 32,
    },
    timing: {
      tRCD: 10.0,
      tRP: 10.0,
      tRAS: 24.0,
      tRC: 34.0,
      tCAS: 10.0,
      tRFC: 340.0,
      tREFI: 3900.0,
      tWR: 10.5,
    },
    thermal: {
      density: 2330,
      specificHeat: 700,
      thermalConductivitySi: 148,
      thermalConductivityUnderfill: 0.9,
      thermalConductivityTIM: 6.5,
      thermalConductivityCu: 400,
    },
    pBackgroundPerDieW: 0.75,
    energyPerReadPjPerBit: 3.1,
    energyPerWritePjPerBit: 3.5,
    baseDiePowerW: 3.6,
  },

  HBM4: {
    generation: 'HBM4',
    name: 'JEDEC HBM4 Next-Gen (2048-Bit)',
    description: 'Revolutionary 2048-bit wide direct-bonded interconnect, 16-Hi stack, >2.5 TB/s bandwidth.',
    busWidthBits: 2048,
    transferRateGbps: 10.0,
    vddVolts: 0.75,
    defaultDieCount: 16,
    capacityGB: 64,
    channels: 32,
    banksPerChannel: 32,
    rowsPerBank: 131072,
    columnsPerRow: 64,
    geometry: {
      lengthMm: 8.5,
      widthMm: 12.5,
      thicknessUm: 28,
      bumpHeightUm: 8, // Hybrid copper-copper direct bond
    },
    tsv: {
      columns: 32,
      rows: 64,
      diameterUm: 2.8,
      pitchUm: 25,
      nominalResistanceMOhms: 19,
      nominalCapacitanceFF: 32,
      nominalInductancePH: 24,
    },
    timing: {
      tRCD: 9.0,
      tRP: 9.0,
      tRAS: 22.0,
      tRC: 31.0,
      tCAS: 9.0,
      tRFC: 380.0,
      tREFI: 3900.0,
      tWR: 9.0,
    },
    thermal: {
      density: 2330,
      specificHeat: 700,
      thermalConductivitySi: 148,
      thermalConductivityUnderfill: 1.1,
      thermalConductivityTIM: 8.0,
      thermalConductivityCu: 400,
    },
    pBackgroundPerDieW: 0.88,
    energyPerReadPjPerBit: 2.2,
    energyPerWritePjPerBit: 2.5,
    baseDiePowerW: 4.8,
  },
};

/**
 * Theoretical Peak Bandwidth formula:
 * B_peak = (W_bits * R_transfers_per_sec) / 8
 * Returns GB/s
 */
export function calculateTheoreticalPeakBandwidth(busWidthBits: number, transferRateGbps: number): number {
  return (busWidthBits * transferRateGbps) / 8;
}
