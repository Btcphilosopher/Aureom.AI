/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Discrete-Event DRAM Timing, Command & Memory Controller Engine
 */

import { HBMProfile } from '../models/hbm-spec';
import { BankState, DRAMCommandEvent, WorkloadConfig } from '../models/simulation-state';

export interface MemoryTransactionRequest {
  id: number;
  arrivalTimeNs: number;
  channel: number;
  bank: number;
  row: number;
  col: number;
  isWrite: boolean;
  burstBytes: number;
}

export class DRAMControllerEngine {
  private commandCounter = 0;
  private pendingQueue: MemoryTransactionRequest[] = [];
  private completedLatencies: number[] = [];
  private lastRefreshNs = 0;

  /**
   * Generates synthetic memory requests according to the selected workload profile.
   */
  public generateWorkloadRequests(
    currentTimeNs: number,
    dtNs: number,
    workload: WorkloadConfig,
    profile: HBMProfile
  ): MemoryTransactionRequest[] {
    const requests: MemoryTransactionRequest[] = [];
    if (workload.intensityPercent <= 0) return requests;

    // Peak request rate calculation based on bus width and transfer rate
    // e.g., for 1024-bit at 6.4 Gbps -> 1 transaction (32B or 64B) per ~0.5ns
    const burstBytes = profile.busWidthBits / 8; // e.g. 128 bytes per burst for 1024b
    const maxTransactionsPerNs = (profile.transferRateGbps * 1e9 / 8) / (burstBytes * 1e9); // ops per ns
    const targetOps = Math.max(1, Math.floor(maxTransactionsPerNs * dtNs * (workload.intensityPercent / 100)));

    for (let i = 0; i < targetOps; i++) {
      const isWrite = Math.random() > workload.readRatio;
      let channel = 0;
      let bank = 0;
      let row = 0;
      const col = Math.floor(Math.random() * profile.columnsPerRow);

      switch (workload.type) {
        case 'sequential_read':
        case 'sequential_write': {
          channel = (this.commandCounter) % profile.channels;
          bank = (Math.floor(this.commandCounter / profile.channels)) % profile.banksPerChannel;
          row = 100 + Math.floor(this.commandCounter / (profile.channels * profile.banksPerChannel * 32));
          break;
        }

        case 'random_read_64b':
        case 'random_write_64b': {
          channel = Math.floor(Math.random() * profile.channels);
          bank = Math.floor(Math.random() * profile.banksPerChannel);
          row = Math.floor(Math.random() * profile.rowsPerBank);
          break;
        }

        case 'ai_gemm_burst': {
          // GEMM matrix multiplication: high concurrency across all channels with repeated row activations
          channel = i % profile.channels;
          bank = (Math.floor(i / 2)) % profile.banksPerChannel;
          row = 512 + (this.commandCounter % 16);
          break;
        }

        case 'ai_llm_attention': {
          // KV-cache reads: scattered head lookups across banks with sequential token strides
          channel = Math.floor(Math.random() * workload.concurrencyChannels);
          bank = Math.floor(Math.random() * profile.banksPerChannel);
          row = (this.commandCounter % 8 === 0) ? Math.floor(Math.random() * profile.rowsPerBank) : (1024 + (this.commandCounter % 64));
          break;
        }

        case 'refresh_stress':
        case 'mixed_70_30':
        default: {
          channel = Math.floor(Math.random() * profile.channels);
          bank = Math.floor(Math.random() * profile.banksPerChannel);
          row = (Math.random() < 0.65) ? 420 : Math.floor(Math.random() * profile.rowsPerBank);
          break;
        }
      }

      this.commandCounter++;
      requests.push({
        id: this.commandCounter,
        arrivalTimeNs: currentTimeNs + (i / targetOps) * dtNs,
        channel,
        bank,
        row,
        col,
        isWrite,
        burstBytes,
      });
    }

    return requests;
  }

  /**
   * Advances the discrete DRAM controller scheduling and execution.
   */
  public stepDRAM(
    currentTimeNs: number,
    dtNs: number,
    banks: BankState[],
    incomingRequests: MemoryTransactionRequest[],
    profile: HBMProfile,
    currentTempC: number
  ): {
    executedCommands: DRAMCommandEvent[];
    transferredBytes: number;
    readBytes: number;
    writeBytes: number;
    activePowerW: number;
    rowHits: number;
    rowMisses: number;
  } {
    this.pendingQueue.push(...incomingRequests);

    // Limit pending queue to prevent unbounded memory growth during extreme saturation
    if (this.pendingQueue.length > 500) {
      this.pendingQueue.splice(0, this.pendingQueue.length - 500);
    }

    const executedCommands: DRAMCommandEvent[] = [];
    let transferredBytes = 0;
    let readBytes = 0;
    let writeBytes = 0;
    let rowHits = 0;
    let rowMisses = 0;

    // Check refresh interval (tREFI)
    // JEDEC Rule: If temperature > 85 C, double refresh rate (tREFI / 2) to maintain retention
    const effectiveTREFI = currentTempC > 85.0 ? profile.timing.tREFI / 2 : profile.timing.tREFI;
    if (currentTimeNs - this.lastRefreshNs >= effectiveTREFI) {
      this.lastRefreshNs = currentTimeNs;
      // Schedule auto-refresh command lock
      const refChannel = Math.floor(Math.random() * profile.channels);
      executedCommands.push({
        id: ++this.commandCounter,
        timeNs: currentTimeNs,
        type: 'REF',
        channel: refChannel,
        bank: 0,
        row: 0,
        col: 0,
        durationNs: profile.timing.tRFC,
        latencyNs: profile.timing.tRFC,
        isHit: false,
      });

      // Lock banks in this channel for tRFC
      for (const b of banks) {
        if (b.channel === refChannel) {
          b.status = 'REFRESHING';
          b.busyUntilNs = currentTimeNs + profile.timing.tRFC;
          b.openRow = null;
        }
      }
    }

    // Process pending memory requests using FR-FCFS (First-Ready First-Come First-Served)
    const remainingQueue: MemoryTransactionRequest[] = [];

    for (const req of this.pendingQueue) {
      const bankIndex = banks.findIndex((b) => b.channel === req.channel && b.bank === req.bank);
      if (bankIndex === -1) continue;

      const bank = banks[bankIndex];

      // Check if bank is currently busy
      if (bank.busyUntilNs > currentTimeNs) {
        remainingQueue.push(req);
        continue;
      }

      // Bank is available! Evaluate Row Buffer state
      const isHit = bank.openRow === req.row;
      let latency = 0;

      if (isHit) {
        // ROW BUFFER HIT!
        rowHits++;
        latency = profile.timing.tCAS;
        bank.status = req.isWrite ? 'WRITING' : 'READING';
        bank.busyUntilNs = currentTimeNs + latency;

        executedCommands.push({
          id: ++this.commandCounter,
          timeNs: currentTimeNs,
          type: req.isWrite ? 'WR' : 'RD',
          channel: req.channel,
          bank: req.bank,
          row: req.row,
          col: req.col,
          durationNs: latency,
          latencyNs: (currentTimeNs - req.arrivalTimeNs) + latency,
          isHit: true,
        });
      } else {
        // ROW BUFFER MISS OR CONFLICT
        rowMisses++;
        if (bank.openRow !== null) {
          // CONFLICT: Must precharge previous row first
          latency = profile.timing.tRP + profile.timing.tRCD + profile.timing.tCAS;
          bank.status = 'PRECHARGING';
          executedCommands.push({
            id: ++this.commandCounter,
            timeNs: currentTimeNs,
            type: 'PRE',
            channel: req.channel,
            bank: req.bank,
            row: bank.openRow,
            col: 0,
            durationNs: profile.timing.tRP,
            latencyNs: profile.timing.tRP,
            isHit: false,
          });
        } else {
          // IDLE BANK MISS: Activate row
          latency = profile.timing.tRCD + profile.timing.tCAS;
        }

        // Issue Activate command
        executedCommands.push({
          id: ++this.commandCounter,
          timeNs: currentTimeNs + profile.timing.tRP,
          type: 'ACT',
          channel: req.channel,
          bank: req.bank,
          row: req.row,
          col: 0,
          durationNs: profile.timing.tRCD,
          latencyNs: profile.timing.tRCD,
          isHit: false,
        });

        // Issue Read or Write command
        executedCommands.push({
          id: ++this.commandCounter,
          timeNs: currentTimeNs + latency - profile.timing.tCAS,
          type: req.isWrite ? 'WR' : 'RD',
          channel: req.channel,
          bank: req.bank,
          row: req.row,
          col: req.col,
          durationNs: profile.timing.tCAS,
          latencyNs: (currentTimeNs - req.arrivalTimeNs) + latency,
          isHit: false,
        });

        bank.openRow = req.row;
        bank.status = req.isWrite ? 'WRITING' : 'READING';
        bank.busyUntilNs = currentTimeNs + latency;
      }

      // Record latency metrics
      const totalTurnaroundLatency = (currentTimeNs - req.arrivalTimeNs) + latency;
      this.completedLatencies.push(totalTurnaroundLatency);
      if (this.completedLatencies.length > 200) {
        this.completedLatencies.shift();
      }

      // Tally bytes
      transferredBytes += req.burstBytes;
      if (req.isWrite) {
        writeBytes += req.burstBytes;
      } else {
        readBytes += req.burstBytes;
      }
    }

    this.pendingQueue = remainingQueue;

    // Update bank status if busy time has elapsed
    for (const b of banks) {
      if (b.busyUntilNs <= currentTimeNs) {
        if (b.openRow !== null) {
          b.status = 'ROW_OPEN';
        } else {
          b.status = 'IDLE';
        }
      }
    }

    // Calculate active energy & power dissipation:
    // E_read = (read_bits) * energyPerReadPjPerBit
    // P = E / dt
    const readBits = readBytes * 8;
    const writeBits = writeBytes * 8;
    const energyJoules = (readBits * profile.energyPerReadPjPerBit + writeBits * profile.energyPerWritePjPerBit) * 1e-12;
    const activePowerW = dtNs > 0 ? (energyJoules / (dtNs * 1e-9)) : 0;

    return {
      executedCommands,
      transferredBytes,
      readBytes,
      writeBytes,
      activePowerW,
      rowHits,
      rowMisses,
    };
  }

  /**
   * Initializes bank state matrix according to HBM architecture.
   */
  public initializeBanks(profile: HBMProfile): BankState[] {
    const banks: BankState[] = [];
    for (let c = 0; c < profile.channels; c++) {
      for (let b = 0; b < profile.banksPerChannel; b++) {
        banks.push({
          channel: c,
          bank: b,
          status: 'IDLE',
          openRow: null,
          busyUntilNs: 0,
        });
      }
    }
    return banks;
  }

  /**
   * Calculates current latency statistics from completed transaction history.
   */
  public calculateLatencyStats(): {
    avg: number;
    median: number;
    p95: number;
    p99: number;
    max: number;
    histogram: { latencyNs: number; count: number }[];
  } {
    if (this.completedLatencies.length === 0) {
      return { avg: 14.5, median: 14.0, p95: 38.0, p99: 45.0, max: 52.0, histogram: [] };
    }

    const sorted = [...this.completedLatencies].sort((a, b) => a - b);
    const sum = sorted.reduce((acc, val) => acc + val, 0);
    const avg = sum / sorted.length;
    const median = sorted[Math.floor(sorted.length * 0.5)];
    const p95 = sorted[Math.floor(sorted.length * 0.95)] || sorted[sorted.length - 1];
    const p99 = sorted[Math.floor(sorted.length * 0.99)] || sorted[sorted.length - 1];
    const max = sorted[sorted.length - 1];

    // Compute 8 histogram bins
    const minVal = Math.min(...sorted);
    const maxVal = Math.max(...sorted, minVal + 1);
    const binCount = 8;
    const binSize = (maxVal - minVal) / binCount;
    const histogram: { latencyNs: number; count: number }[] = [];

    for (let i = 0; i < binCount; i++) {
      const binStart = minVal + i * binSize;
      const binEnd = binStart + binSize;
      const count = sorted.filter((v) => v >= binStart && (i === binCount - 1 ? v <= binEnd : v < binEnd)).length;
      histogram.push({
        latencyNs: Number((binStart + binSize / 2).toFixed(1)),
        count,
      });
    }

    return {
      avg: Number(avg.toFixed(1)),
      median: Number(median.toFixed(1)),
      p95: Number(p95.toFixed(1)),
      p99: Number(p99.toFixed(1)),
      max: Number(max.toFixed(1)),
      histogram,
    };
  }
}
