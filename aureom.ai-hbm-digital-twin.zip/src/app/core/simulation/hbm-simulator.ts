/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Master Multiphysics Simulation Coordinator & State Manager
 */

import { Injectable, signal, computed, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {
  HBMGenKey,
  HBMProfile,
  HBM_PROFILES,
  calculateTheoreticalPeakBandwidth,
} from '../models/hbm-spec';
import {
  CoolingCondition,
  HBMSimulationState,
  WorkloadConfig,
  WorkloadType,
} from '../models/simulation-state';
import { NumericalThermalSolver } from './thermal-solver';
import { DRAMControllerEngine } from './dram-engine';
import { ElectricalPDNEngine } from './electrical-pdn-engine';

export interface PredefinedExperiment {
  id: string;
  code: string;
  title: string;
  description: string;
  category: 'Bandwidth' | 'Thermal' | 'Interconnect' | 'Timing' | 'Packaging' | 'AI' | 'Power';
  setup: {
    generation: HBMGenKey;
    workloadType: WorkloadType;
    intensity: number;
    coolingType: 'passive' | 'forced_air' | 'vapor_chamber' | 'liquid_coldplate';
    ambientC: number;
    faultTsvId?: number;
  };
}

export const EXPERIMENTS_SUITE: PredefinedExperiment[] = [
  {
    id: 'exp-a',
    code: 'EXP-A',
    title: 'Bandwidth Saturation & Queue Latency',
    description: 'Ramp memory request concurrency to 100% and observe delivered bandwidth asymptotes and FR-FCFS queue queuing delays.',
    category: 'Bandwidth',
    setup: {
      generation: 'HBM3E',
      workloadType: 'sequential_read',
      intensity: 100,
      coolingType: 'vapor_chamber',
      ambientC: 25,
    },
  },
  {
    id: 'exp-b',
    code: 'EXP-B',
    title: 'Thermal Runaway Investigation',
    description: 'Switch to passive natural convection at 100% AI tensor load. Watch leakage power escalate exponentially, threatening thermal breakdown.',
    category: 'Thermal',
    setup: {
      generation: 'HBM3',
      workloadType: 'ai_gemm_burst',
      intensity: 95,
      coolingType: 'passive',
      ambientC: 45,
    },
  },
  {
    id: 'exp-c',
    code: 'EXP-C',
    title: 'TSV Open-Circuit Defect & Redundancy',
    description: 'Inject a mechanical open-circuit fracture on high-speed DQ via. Observe signal collapse and automated failover rerouting.',
    category: 'Interconnect',
    setup: {
      generation: 'HBM3E',
      workloadType: 'random_read_64b',
      intensity: 75,
      coolingType: 'forced_air',
      ambientC: 30,
      faultTsvId: 42,
    },
  },
  {
    id: 'exp-d',
    code: 'EXP-D',
    title: 'Refresh Overhead & Temperature Scaling',
    description: 'Observe DRAM tRFC refresh command locks. When die temperature exceeds 85°C, auto-refresh frequency doubles to safeguard retention.',
    category: 'Timing',
    setup: {
      generation: 'HBM2E',
      workloadType: 'refresh_stress',
      intensity: 80,
      coolingType: 'forced_air',
      ambientC: 55,
    },
  },
  {
    id: 'exp-e',
    code: 'EXP-E',
    title: '3D Stack Height Comparison (4-Hi vs 16-Hi)',
    description: 'Compare thermal gradients and latency across 4-Hi HBM2 and 16-Hi HBM4 stacks with direct-bonded interconnects.',
    category: 'Packaging',
    setup: {
      generation: 'HBM4',
      workloadType: 'mixed_70_30',
      intensity: 85,
      coolingType: 'liquid_coldplate',
      ambientC: 25,
    },
  },
  {
    id: 'exp-f',
    code: 'EXP-F',
    title: 'AI LLM KV-Cache & GEMM Traffic',
    description: 'Simulate high-concurrency transformer matrix multiplications and scattered token lookups across all 16 channels.',
    category: 'AI',
    setup: {
      generation: 'HBM3E',
      workloadType: 'ai_gemm_burst',
      intensity: 90,
      coolingType: 'liquid_coldplate',
      ambientC: 25,
    },
  },
  {
    id: 'exp-g',
    code: 'EXP-G',
    title: 'PDN Power Droop & Inductive Kick',
    description: 'Apply instantaneous current step and observe package L*di/dt transient droop on the VDD supply rail.',
    category: 'Power',
    setup: {
      generation: 'HBM3',
      workloadType: 'ai_gemm_burst',
      intensity: 100,
      coolingType: 'vapor_chamber',
      ambientC: 30,
    },
  },
  {
    id: 'exp-h',
    code: 'EXP-H',
    title: 'Cooling Boundary Optimization',
    description: 'Evaluate microchannel liquid cold plate vs forced air heatsink heat dissipation under 25W sustained stack power.',
    category: 'Thermal',
    setup: {
      generation: 'HBM3E',
      workloadType: 'mixed_70_30',
      intensity: 85,
      coolingType: 'liquid_coldplate',
      ambientC: 20,
    },
  },
];

@Injectable({
  providedIn: 'root',
})
export class HBMSimulatorService {
  private thermalSolver = new NumericalThermalSolver();
  private dramEngine = new DRAMControllerEngine();
  private electricalEngine = new ElectricalPDNEngine();

  private loopIntervalId: number | null = null;
  private lastWallTimeMs = performance.now();

  // Primary State Signal
  public readonly state = signal<HBMSimulationState>(this.createInitialState('HBM3E'));

  // Active Selected Entity for Inspection
  public readonly selectedEntity = signal<{
    type: 'die' | 'tsv' | 'bank' | 'pdn' | 'none';
    id: number;
    title: string;
    data: Record<string, unknown>;
  }>({
    type: 'none',
    id: 0,
    title: 'No Component Selected',
    data: {},
  });

  // Current Experiment Active
  public readonly activeExperiment = signal<PredefinedExperiment | null>(null);

  // Computed Properties for easy UI binding
  public readonly currentProfile = computed<HBMProfile>(() => {
    return HBM_PROFILES[this.state().generation];
  });

  public readonly peakBandwidthGBs = computed<number>(() => {
    const prof = this.currentProfile();
    return calculateTheoreticalPeakBandwidth(prof.busWidthBits, prof.transferRateGbps);
  });

  private platformId = inject(PLATFORM_ID);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.startSimulationLoop();
    }
  }

  /**
   * Builds an initial coherent scientific state for the given HBM generation.
   */
  public createInitialState(generationKey: HBMGenKey): HBMSimulationState {
    const profile = HBM_PROFILES[generationKey];
    const initialTempC = 28.0;

    const dies = this.thermalSolver.initializeDies(profile.defaultDieCount + 1, initialTempC);
    const tsvs = this.electricalEngine.generateTSVMatrix(profile);
    const banks = this.dramEngine.initializeBanks(profile);

    const cooling: CoolingCondition = {
      type: 'vapor_chamber',
      name: 'Vapor Chamber + Heatsink',
      ambientTemperatureC: 25.0,
      heatTransferCoeffH: 1200, // W / (m^2 * K)
      sinkThermalResistanceKPerW: 0.85,
    };

    const workload: WorkloadConfig = {
      type: 'mixed_70_30',
      name: 'Standard Mixed 70/30 Traffic',
      description: '70% Reads, 30% Writes with uniform bank stride',
      intensityPercent: 65,
      readRatio: 0.70,
      concurrencyChannels: profile.channels,
      burstLength: 8,
    };

    const theoreticalPeakBandwidthGBs = calculateTheoreticalPeakBandwidth(profile.busWidthBits, profile.transferRateGbps);

    const pdn = this.electricalEngine.stepPDN(0, profile.vddVolts, 14.5, workload.intensityPercent);
    const osc = this.electricalEngine.generateOscilloscopeData(0, profile.vddVolts, profile.transferRateGbps, false);
    const mc = this.electricalEngine.runMonteCarloSimulation(profile, 30);

    return {
      clock: {
        timeNs: 0,
        timeMs: 0,
        isPaused: false,
        speedMultiplier: 1,
        stepCount: 0,
      },
      generation: generationKey,
      dieCount: profile.defaultDieCount,
      dies,
      tsvs,
      banks,
      recentCommands: [],
      workload,
      cooling,
      pdn,
      oscilloscope: osc,
      monteCarlo: mc,
      metrics: {
        theoreticalPeakBandwidthGBs,
        deliveredBandwidthGBs: theoreticalPeakBandwidthGBs * 0.72,
        readThroughputGBs: theoreticalPeakBandwidthGBs * 0.50,
        writeThroughputGBs: theoreticalPeakBandwidthGBs * 0.22,
        bandwidthEfficiencyPercent: 72.0,
        channelUtilizationPercent: 68.0,
        rowBufferHitRatePercent: 74.0,
        totalTransactions: 0,
        transferredBytesMB: 0,
        latencyAvgNs: 14.2,
        latencyMedianNs: 13.5,
        latencyP95Ns: 36.0,
        latencyP99Ns: 42.5,
        latencyMaxNs: 48.0,
        latencyHistogram: [],
        totalPowerW: 14.8,
        backgroundPowerW: 6.2,
        activePowerW: 6.8,
        refreshPowerW: 0.6,
        leakagePowerW: 1.2,
        stackAvgTempC: initialTempC,
        stackMaxTempC: initialTempC,
        maxHotspotDieIndex: 1,
        thermalRunawayWarning: false,
        currentRefreshIntervalNs: profile.timing.tREFI,
        refreshMultiplier: 1,
        retentionFailureProb: 1e-9,
        faultCount: 0,
      },
    };
  }

  /**
   * Starts the high-frequency physical simulation loop.
   */
  private startSimulationLoop(): void {
    if (this.loopIntervalId !== null) return;

    this.lastWallTimeMs = performance.now();
    // Advance simulation at 30 Hz for steady scientific calculations and smooth rendering
    this.loopIntervalId = window.setInterval(() => {
      this.tick();
    }, 33);
  }

  /**
   * Executes a single advance of the multidisciplinary simulation engine.
   */
  public tick(forcedDtSec?: number): void {
    const currentState = this.state();
    if (currentState.clock.isPaused && forcedDtSec === undefined) {
      return;
    }

    const nowWall = performance.now();
    const rawDtMs = forcedDtSec !== undefined ? forcedDtSec * 1000 : (nowWall - this.lastWallTimeMs);
    this.lastWallTimeMs = nowWall;

    // Cap dt to prevent numerical divergence if browser tab is backgrounded
    const safeDtMs = Math.min(100, Math.max(10, rawDtMs));
    const effectiveDtMs = safeDtMs * currentState.clock.speedMultiplier;
    const effectiveDtSec = effectiveDtMs * 1e-3;

    // Multirate scaling: In physical silicon, 1 ms of thermal time corresponds to ~1000 ns of memory clock sample
    const discreteDtNs = Math.min(200, 50 * currentState.clock.speedMultiplier);

    const profile = HBM_PROFILES[currentState.generation];
    const newTimeNs = currentState.clock.timeNs + discreteDtNs;
    const newTimeMs = currentState.clock.timeMs + effectiveDtMs;

    // 1. Generate workload memory requests
    const incomingRequests = this.dramEngine.generateWorkloadRequests(
      newTimeNs,
      discreteDtNs,
      currentState.workload,
      profile
    );

    // 2. Advance DRAM controller scheduling & command execution
    const dramResult = this.dramEngine.stepDRAM(
      newTimeNs,
      discreteDtNs,
      currentState.banks,
      incomingRequests,
      profile,
      currentState.metrics.stackMaxTempC
    );

    // 3. Compute active dynamic power per die
    const activePowerW = dramResult.activePowerW;
    const numDramDies = currentState.dies.length - 1;
    const perDieActiveW = numDramDies > 0 ? (activePowerW / numDramDies) : 0;

    // Allocate power to dies
    for (const die of currentState.dies) {
      if (die.isBaseDie) {
        die.powerWatts.background = profile.baseDiePowerW;
        die.powerWatts.active = activePowerW * 0.25; // PHY serialization power
      } else {
        die.powerWatts.background = profile.pBackgroundPerDieW;
        die.powerWatts.active = perDieActiveW * 0.75;
      }
    }

    // 4. Map active command activity to TSVs for 3D signal pulse rendering
    const activeBankList = dramResult.executedCommands.map((c) => ({
      channel: c.channel,
      bank: c.bank,
      isWrite: c.type === 'WR',
    }));

    for (const tsv of currentState.tsvs) {
      if (tsv.activePulse > 0.05) {
        tsv.activePulse *= 0.85; // Exponential decay
      } else {
        tsv.activePulse = 0;
      }

      // Check if this TSV belongs to an active channel
      const isChannelActive = activeBankList.some((a) => a.channel === tsv.channel);
      if (isChannelActive && Math.random() < 0.25) {
        tsv.activePulse = 1.0;
      }
    }

    // 5. Numerical Thermal Solver Step
    this.thermalSolver.stepThermalField(
      currentState.dies,
      profile,
      currentState.cooling,
      effectiveDtSec,
      activeBankList
    );

    // Compute thermal stack statistics
    let sumTemp = 0;
    let maxTemp = -999;
    let maxDieIdx = 0;
    for (const die of currentState.dies) {
      sumTemp += die.temperatureC;
      if (die.peakHotspotC > maxTemp) {
        maxTemp = die.peakHotspotC;
        maxDieIdx = die.dieIndex;
      }
    }
    const stackAvgTempC = Number((sumTemp / currentState.dies.length).toFixed(2));
    const stackMaxTempC = Number(maxTemp.toFixed(2));
    const thermalRunaway = stackMaxTempC > 115.0;

    // Calculate stack power breakdown
    let totalBgW = 0;
    let totalActW = 0;
    let totalRefW = 0;
    let totalLeakW = 0;
    for (const die of currentState.dies) {
      totalBgW += die.powerWatts.background;
      totalActW += die.powerWatts.active;
      totalRefW += die.powerWatts.refresh;
      totalLeakW += die.powerWatts.leakage;
    }
    const totalStackPowerW = totalBgW + totalActW + totalRefW + totalLeakW;

    // 6. Power Delivery Network (PDN) Step
    const pdnState = this.electricalEngine.stepPDN(
      newTimeNs,
      profile.vddVolts,
      totalStackPowerW,
      currentState.workload.intensityPercent
    );

    // 7. High-Speed Signal Integrity & Oscilloscope
    const hasActiveFault = currentState.tsvs.some((t) => t.fault === 'open' || t.fault === 'high_r');
    const oscState = this.electricalEngine.generateOscilloscopeData(
      newTimeNs,
      pdnState.instantaneousVddV,
      profile.transferRateGbps,
      hasActiveFault
    );

    // 8. Performance Metrics Calculation
    const theoreticalPeakBandwidthGBs = calculateTheoreticalPeakBandwidth(profile.busWidthBits, profile.transferRateGbps);
    // Instantaneous delivered bandwidth from transferred bytes in this step
    const instantBwGBs = (discreteDtNs > 0) ? (dramResult.transferredBytes / (discreteDtNs * 1e-9)) / 1e9 : 0;
    // Smoothed delivered bandwidth
    const deliveredBandwidthGBs = Number(
      (currentState.metrics.deliveredBandwidthGBs * 0.85 + Math.min(theoreticalPeakBandwidthGBs * 0.98, instantBwGBs) * 0.15).toFixed(1)
    );

    const readBwGBs = Number((deliveredBandwidthGBs * currentState.workload.readRatio).toFixed(1));
    const writeBwGBs = Number((deliveredBandwidthGBs * (1 - currentState.workload.readRatio)).toFixed(1));
    const bandwidthEfficiency = Number(((deliveredBandwidthGBs / theoreticalPeakBandwidthGBs) * 100).toFixed(1));

    // Latency statistics
    const latencyStats = this.dramEngine.calculateLatencyStats();

    // Row buffer hit rate
    const totalOps = dramResult.rowHits + dramResult.rowMisses;
    const stepHitRate = totalOps > 0 ? (dramResult.rowHits / totalOps) * 100 : 70.0;
    const rowBufferHitRate = Number((currentState.metrics.rowBufferHitRatePercent * 0.9 + stepHitRate * 0.1).toFixed(1));

    // Refresh interval multiplier
    const refreshMultiplier = stackMaxTempC > 85.0 ? 2 : 1;
    const currentRefreshIntervalNs = profile.timing.tREFI / refreshMultiplier;

    // Retention failure probability: Arrhenius thermal activation
    // P_fail ~ 10^-9 * 2^((T - 85)/10)
    const retentionExponent = Math.max(0, (stackMaxTempC - 85.0) / 10.0);
    const retentionFailureProb = Number((1e-9 * Math.pow(2, retentionExponent)).toExponential(2));

    // Fault count
    const faultCount = currentState.tsvs.filter((t) => t.fault !== 'nominal').length;

    // Keep rolling command list
    const combinedCommands = [...dramResult.executedCommands, ...currentState.recentCommands].slice(0, 30);

    // Commit state update
    this.state.set({
      ...currentState,
      clock: {
        ...currentState.clock,
        timeNs: Number(newTimeNs.toFixed(1)),
        timeMs: Number(newTimeMs.toFixed(1)),
        stepCount: currentState.clock.stepCount + 1,
      },
      dies: [...currentState.dies],
      tsvs: [...currentState.tsvs],
      banks: [...currentState.banks],
      recentCommands: combinedCommands,
      pdn: pdnState,
      oscilloscope: oscState,
      metrics: {
        theoreticalPeakBandwidthGBs,
        deliveredBandwidthGBs,
        readThroughputGBs: readBwGBs,
        writeThroughputGBs: writeBwGBs,
        bandwidthEfficiencyPercent: bandwidthEfficiency,
        channelUtilizationPercent: Math.min(100, Number((bandwidthEfficiency * 1.15).toFixed(1))),
        rowBufferHitRatePercent: rowBufferHitRate,
        totalTransactions: currentState.metrics.totalTransactions + dramResult.executedCommands.length,
        transferredBytesMB: Number((currentState.metrics.transferredBytesMB + dramResult.transferredBytes / 1e6).toFixed(2)),
        latencyAvgNs: latencyStats.avg,
        latencyMedianNs: latencyStats.median,
        latencyP95Ns: latencyStats.p95,
        latencyP99Ns: latencyStats.p99,
        latencyMaxNs: latencyStats.max,
        latencyHistogram: latencyStats.histogram,
        totalPowerW: Number(totalStackPowerW.toFixed(2)),
        backgroundPowerW: Number(totalBgW.toFixed(2)),
        activePowerW: Number(totalActW.toFixed(2)),
        refreshPowerW: Number(totalRefW.toFixed(2)),
        leakagePowerW: Number(totalLeakW.toFixed(2)),
        stackAvgTempC,
        stackMaxTempC,
        maxHotspotDieIndex: maxDieIdx,
        thermalRunawayWarning: thermalRunaway,
        currentRefreshIntervalNs,
        refreshMultiplier,
        retentionFailureProb: Number(retentionFailureProb),
        faultCount,
      },
    });

    // Update inspector if entity is selected
    const activeEntity = this.selectedEntity();
    if (activeEntity.type === 'die' && currentState.dies[activeEntity.id]) {
      const d = currentState.dies[activeEntity.id];
      this.selectedEntity.set({
        ...activeEntity,
        data: {
          name: d.name,
          temperatureC: d.temperatureC,
          peakHotspotC: d.peakHotspotC,
          hotspotCoordinates: `X: ${d.hotspotX.toFixed(2)} mm, Z: ${d.hotspotZ.toFixed(2)} mm`,
          totalPowerW: d.powerWatts.total.toFixed(2),
          backgroundPowerW: d.powerWatts.background.toFixed(2),
          activePowerW: d.powerWatts.active.toFixed(2),
          leakagePowerW: d.powerWatts.leakage.toFixed(2),
        },
      });
    }
  }

  // --- Clock Controls ---
  public togglePause(): void {
    const s = this.state();
    this.state.set({
      ...s,
      clock: {
        ...s.clock,
        isPaused: !s.clock.isPaused,
      },
    });
  }

  public setSpeed(multiplier: number): void {
    const s = this.state();
    this.state.set({
      ...s,
      clock: {
        ...s.clock,
        speedMultiplier: multiplier,
      },
    });
  }

  public stepOnce(): void {
    this.tick(0.033);
  }

  public resetSimulation(): void {
    const s = this.state();
    this.state.set(this.createInitialState(s.generation));
    this.activeExperiment.set(null);
  }

  // --- Parameter Modification Controls ---
  public setGeneration(gen: HBMGenKey): void {
    this.state.set(this.createInitialState(gen));
    this.activeExperiment.set(null);
  }

  public setWorkload(workloadType: WorkloadType, intensity = 70): void {
    const s = this.state();
    let name = 'Custom Workload';
    let description = '';
    let readRatio = 0.7;

    switch (workloadType) {
      case 'sequential_read':
        name = 'Sequential Streaming Reads';
        description = 'Maximal row-buffer hits, continuous burst reads';
        readRatio = 1.0;
        break;
      case 'sequential_write':
        name = 'Sequential Streaming Writes';
        description = 'Sustained burst writes with write-recovery timing';
        readRatio = 0.0;
        break;
      case 'random_read_64b':
        name = 'Random 64-Byte Strided Reads';
        description = 'Frequent row misses and bank precharge overhead';
        readRatio = 1.0;
        break;
      case 'random_write_64b':
        name = 'Random 64-Byte Strided Writes';
        description = 'Random bank activations with write turnaround';
        readRatio = 0.0;
        break;
      case 'ai_gemm_burst':
        name = 'AI Tensor Matrix GEMM Bursts';
        description = 'Deep neural net weight tensor matrix multiply streaming';
        readRatio = 0.85;
        break;
      case 'ai_llm_attention':
        name = 'AI LLM Multi-Head KV Attention';
        description = 'Scattered KV-cache attention head lookups';
        readRatio = 0.80;
        break;
      case 'refresh_stress':
        name = 'Thermal & Retention Stress';
        description = 'Rapid row cycling creating maximum localized heating';
        readRatio = 0.50;
        break;
      case 'mixed_70_30':
      default:
        name = 'Mixed Enterprise 70/30';
        description = 'Standard 70% read, 30% write distribution';
        readRatio = 0.70;
        break;
    }

    this.state.set({
      ...s,
      workload: {
        ...s.workload,
        type: workloadType,
        name,
        description,
        intensityPercent: intensity,
        readRatio,
      },
    });
  }

  public setWorkloadIntensity(intensity: number): void {
    const s = this.state();
    this.state.set({
      ...s,
      workload: {
        ...s.workload,
        intensityPercent: Math.max(0, Math.min(100, intensity)),
      },
    });
  }

  public setCooling(type: 'passive' | 'forced_air' | 'vapor_chamber' | 'liquid_coldplate', ambientC = 25): void {
    const s = this.state();
    let name = '';
    let h = 50;
    let rSink = 3.5;

    switch (type) {
      case 'passive':
        name = 'Natural Convection (No Fan)';
        h = 35;
        rSink = 3.8;
        break;
      case 'forced_air':
        name = 'Forced Air Copper Fin Heatsink';
        h = 450;
        rSink = 1.6;
        break;
      case 'vapor_chamber':
        name = 'Vapor Chamber Heat Pipe';
        h = 1200;
        rSink = 0.85;
        break;
      case 'liquid_coldplate':
        name = 'Direct-to-Die Microchannel Liquid Coldplate';
        h = 5500;
        rSink = 0.22;
        break;
    }

    this.state.set({
      ...s,
      cooling: {
        type,
        name,
        ambientTemperatureC: ambientC,
        heatTransferCoeffH: h,
        sinkThermalResistanceKPerW: rSink,
      },
    });
  }

  // --- Fault Injection Laboratory ---
  public injectTSVFault(tsvId: number, fault: 'open' | 'high_r' | 'bridged' | 'rerouted' | 'nominal'): void {
    const s = this.state();
    const updatedTsvs = s.tsvs.map((t) => {
      if (t.id === tsvId) {
        let actualR = t.nominalResistanceMOhms;
        if (fault === 'open') actualR = 1e6; // Infinite open circuit
        if (fault === 'high_r') actualR = t.nominalResistanceMOhms * 8.5; // High contact resistance
        if (fault === 'bridged') actualR = 0.05; // Shorted
        if (fault === 'rerouted') actualR = t.nominalResistanceMOhms * 1.05; // Redundancy lane reroute
        return {
          ...t,
          fault,
          actualResistanceMOhms: actualR,
        };
      }
      return t;
    });

    this.state.set({
      ...s,
      tsvs: updatedTsvs,
    });
  }

  public clearAllFaults(): void {
    const s = this.state();
    const cleanTsvs = s.tsvs.map((t) => ({
      ...t,
      fault: 'nominal' as const,
      actualResistanceMOhms: t.nominalResistanceMOhms,
    }));
    this.state.set({
      ...s,
      tsvs: cleanTsvs,
    });
  }

  // --- Predefined Experiment Launcher ---
  public launchExperiment(exp: PredefinedExperiment): void {
    this.activeExperiment.set(exp);
    this.setGeneration(exp.setup.generation);
    this.setWorkload(exp.setup.workloadType, exp.setup.intensity);
    this.setCooling(exp.setup.coolingType, exp.setup.ambientC);

    if (exp.setup.faultTsvId) {
      this.injectTSVFault(exp.setup.faultTsvId, 'open');
    }
  }

  // --- Scientific Telemetry Export ---
  public exportTelemetryData(format: 'json' | 'csv'): void {
    const s = this.state();
    let fileContent = '';
    let fileName = `aureom_hbm_telemetry_${Date.now()}`;
    let mimeType = 'text/plain';

    if (format === 'json') {
      fileContent = JSON.stringify(s, null, 2);
      fileName += '.json';
      mimeType = 'application/json';
    } else {
      // CSV format
      mimeType = 'text/csv';
      fileName += '.csv';
      const headers = [
        'Time_ns',
        'Time_ms',
        'Delivered_BW_GBs',
        'Theoretical_BW_GBs',
        'Efficiency_Pct',
        'Stack_Avg_Temp_C',
        'Stack_Max_Temp_C',
        'Total_Power_W',
        'Active_Power_W',
        'Leakage_Power_W',
        'VDD_V',
        'Droop_Pct',
        'Avg_Latency_ns',
        'P95_Latency_ns',
        'Fault_Count',
      ].join(',');

      const row = [
        s.clock.timeNs,
        s.clock.timeMs,
        s.metrics.deliveredBandwidthGBs,
        s.metrics.theoreticalPeakBandwidthGBs,
        s.metrics.bandwidthEfficiencyPercent,
        s.metrics.stackAvgTempC,
        s.metrics.stackMaxTempC,
        s.metrics.totalPowerW,
        s.metrics.activePowerW,
        s.metrics.leakagePowerW,
        s.pdn.instantaneousVddV,
        s.pdn.droopPercent,
        s.metrics.latencyAvgNs,
        s.metrics.latencyP95Ns,
        s.metrics.faultCount,
      ].join(',');

      fileContent = `${headers}\n${row}\n`;
    }

    const blob = new Blob([fileContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  }
}
