/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Electrical Signal, Power Delivery Network (PDN) & TSV Matrix Engine
 */

import { HBMProfile } from '../models/hbm-spec';
import { MonteCarloDistribution, MonteCarloSample, PDNState, SignalOscilloscopeData, TSVNode } from '../models/simulation-state';

export class ElectricalPDNEngine {
  private currentVddV = 1.1;
  private currentAmps = 4.2;
  private currentLoadDIdt = 0;

  /**
   * Generates TSV 3D matrix nodes according to HBM architecture specs.
   */
  public generateTSVMatrix(profile: HBMProfile): TSVNode[] {
    const tsvs: TSVNode[] = [];
    const cols = profile.tsv.columns;
    const rows = profile.tsv.rows;
    const pitchMm = profile.tsv.pitchUm * 1e-3;

    let id = 0;
    const startX = -((cols - 1) * pitchMm) / 2;
    const startZ = -((rows - 1) * pitchMm) / 2;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        id++;
        const xMm = startX + c * pitchMm;
        const zMm = startZ + r * pitchMm;

        // Assign signals based on standard HBM TSV pinout partition
        let signalType: TSVNode['signalType'] = 'DQ';
        let signalName = `DQ_${(id % 64)}`;
        const channel = Math.floor((c / cols) * profile.channels);

        if ((c === 0 || c === cols - 1) && (r % 2 === 0)) {
          signalType = 'VDD';
          signalName = 'VDD_PWR';
        } else if ((c === 1 || c === cols - 2) && (r % 2 === 1)) {
          signalType = 'VSS';
          signalName = 'VSS_GND';
        } else if (r === Math.floor(rows / 2)) {
          signalType = (c % 4 === 0) ? 'CLK' : 'CMD';
          signalName = (c % 4 === 0) ? `CLK_c${channel}` : `CMD_c${channel}`;
        } else if (c % 8 === 0) {
          signalType = 'DQS';
          signalName = `DQS_c${channel}_${Math.floor(r / 4)}`;
        }

        tsvs.push({
          id,
          col: c,
          row: r,
          xMm: Number(xMm.toFixed(3)),
          zMm: Number(zMm.toFixed(3)),
          signalName,
          signalType,
          channel,
          nominalResistanceMOhms: profile.tsv.nominalResistanceMOhms,
          actualResistanceMOhms: profile.tsv.nominalResistanceMOhms + (Math.random() * 2 - 1) * 1.5,
          capacitanceFF: profile.tsv.nominalCapacitanceFF,
          fault: 'nominal',
          activePulse: 0,
          temperatureK: 320.0,
        });
      }
    }

    return tsvs;
  }

  /**
   * Advances the Power Delivery Network (PDN) transient simulation.
   * Models: V_droop = V_nom - I * R_pkg - L_pkg * (dI/dt)
   */
  public stepPDN(
    currentTimeNs: number,
    nominalVddV: number,
    totalPowerW: number,
    workloadIntensity: number
  ): PDNState {
    // Dynamic load current: I = P / V
    const targetCurrent = Math.max(1.5, totalPowerW / nominalVddV);
    const dI = targetCurrent - this.currentAmps;
    this.currentLoadDIdt = dI * (0.1 + workloadIntensity * 0.001); // Rate of current change scaled by intensity
    this.currentAmps += dI * 0.2; // Damped low-pass current draw

    // Parasitic package parameters: R_pkg ~ 3.5 mOhm, L_pkg ~ 25 pH, C_decap ~ 120 nF
    const rPkgOhms = 0.0035;
    const lPkgHenry = 25e-12;
    const irDrop = this.currentAmps * rPkgOhms;
    const inductiveKick = lPkgHenry * (this.currentLoadDIdt / 1e-9);

    // Dynamic ripple + noise
    const noise = (Math.sin(currentTimeNs * 0.05) * 0.004) + ((Math.random() - 0.5) * 0.003);

    // Instantaneous VDD with droop
    const vInstantaneous = Math.max(0.6, nominalVddV - irDrop - inductiveKick + noise);
    this.currentVddV = vInstantaneous;
    const droopPercent = ((nominalVddV - vInstantaneous) / nominalVddV) * 100;
    const powerLossW = (this.currentAmps * this.currentAmps) * rPkgOhms;

    // Build rolling waveform for PDN monitor
    const voltageWaveform: { timeNs: number; voltageV: number }[] = [];
    const pts = 24;
    for (let i = 0; i < pts; i++) {
      const t = currentTimeNs - (pts - i) * 2;
      const ripple = Math.sin(t * 0.08) * (droopPercent * 0.002);
      voltageWaveform.push({
        timeNs: t,
        voltageV: Number((vInstantaneous + ripple).toFixed(4)),
      });
    }

    return {
      nominalVddV,
      instantaneousVddV: Number(vInstantaneous.toFixed(4)),
      droopPercent: Number(droopPercent.toFixed(2)),
      currentAmps: Number(this.currentAmps.toFixed(2)),
      powerDeliveryLossW: Number(powerLossW.toFixed(3)),
      voltageWaveform,
    };
  }

  /**
   * Generates high-fidelity oscilloscope waveforms for high-speed signal integrity analysis.
   */
  public generateOscilloscopeData(
    currentTimeNs: number,
    vddV: number,
    transferRateGbps: number,
    hasTsvFault: boolean
  ): SignalOscilloscopeData {
    const bitPeriodNs = 1.0 / transferRateGbps; // e.g. ~0.156 ns for 6.4 Gbps
    const pointsCount = 48;
    const timeVectorNs: number[] = [];
    const dq0SignalV: number[] = [];
    const dqsStrobeV: number[] = [];
    const clockSignalV: number[] = [];

    // If TSV has fault, signal degrades: slower rise time, lower swing, higher jitter
    const tauPs = hasTsvFault ? 140 : 35; // RC time constant
    const tauNs = tauPs * 1e-3;
    const swingV = hasTsvFault ? vddV * 0.65 : vddV * 0.95;
    const jitterPs = hasTsvFault ? 42.0 : 8.5;
    const marginMv = hasTsvFault ? 110 : 340;

    for (let i = 0; i < pointsCount; i++) {
      const t = (i / pointsCount) * (bitPeriodNs * 4);
      timeVectorNs.push(Number(t.toFixed(3)));

      // Clock differential signal
      const clkPhase = (2 * Math.PI * t) / (bitPeriodNs * 2);
      const clkV = (vddV / 2) + (vddV * 0.45) * Math.sin(clkPhase);
      clockSignalV.push(Number(clkV.toFixed(3)));

      // DQS Strobe (quadrature phase relative to DQ)
      const dqsPhase = (2 * Math.PI * t) / bitPeriodNs;
      const dqsV = (vddV / 2) + (swingV / 2) * Math.sin(dqsPhase);
      dqsStrobeV.push(Number(dqsV.toFixed(3)));

      // DQ0 Data Signal with exponential RC settling
      const bitIndex = Math.floor(t / bitPeriodNs);
      const targetBitVal = (bitIndex % 3 === 0 || bitIndex % 5 === 0) ? 1 : 0;
      const targetVoltage = targetBitVal ? swingV : 0.05;
      const subTime = t - bitIndex * bitPeriodNs;
      const settledV = targetBitVal
        ? targetVoltage * (1 - Math.exp(-subTime / tauNs))
        : targetVoltage + (swingV * 0.9) * Math.exp(-subTime / tauNs);
      
      const noise = (Math.random() - 0.5) * (hasTsvFault ? 0.06 : 0.015);
      dq0SignalV.push(Number(Math.max(0, Math.min(vddV, settledV + noise)).toFixed(3)));
    }

    // Generate Eye-Diagram Overlay Traces (folded across 1.5 UI)
    const eyeDiagramTraces: number[][] = [];
    const numTraces = 12;
    for (let trace = 0; trace < numTraces; trace++) {
      const tracePts: number[] = [];
      const bitPolarity = trace % 2 === 0 ? 1 : 0;
      const traceJitter = ((Math.random() - 0.5) * jitterPs * 1e-3);
      for (let i = 0; i < 24; i++) {
        const u = i / 24;
        const normalizedT = u + traceJitter;
        let v = bitPolarity
          ? swingV * (1 - Math.exp(-normalizedT / (tauNs * 1.5)))
          : swingV * Math.exp(-normalizedT / (tauNs * 1.5));
        v += (Math.random() - 0.5) * (hasTsvFault ? 0.05 : 0.015);
        tracePts.push(Number(Math.max(0, Math.min(vddV, v)).toFixed(3)));
      }
      eyeDiagramTraces.push(tracePts);
    }

    return {
      timeVectorNs,
      dq0SignalV,
      dqsStrobeV,
      clockSignalV,
      eyeDiagramTraces,
      jitterPs,
      riseTimePs: tauPs * 2.2, // 10% to 90% rise time = 2.2 * tau
      voltageMarginMv: marginMv,
    };
  }

  /**
   * Runs a Monte Carlo manufacturing variation simulation.
   */
  public runMonteCarloSimulation(
    profile: HBMProfile,
    numSamples = 30
  ): MonteCarloDistribution {
    const samples: MonteCarloSample[] = [];
    let sumBw = 0;
    let sumTemp = 0;
    let passCount = 0;

    const nominalBw = (profile.busWidthBits * profile.transferRateGbps / 8) * 0.82; // ~82% efficiency

    for (let i = 1; i <= numSamples; i++) {
      // Gaussian distribution for TSV resistance (nominal +/- 12%)
      const rTsv = profile.tsv.nominalResistanceMOhms * (1 + (Math.random() + Math.random() - 1) * 0.12);
      // Gaussian bump resistance
      const rBump = 15.0 * (1 + (Math.random() + Math.random() - 1) * 0.15);
      // Die thickness variation (3D grinding +/- 3 um)
      const dieThick = profile.geometry.thicknessUm + (Math.random() + Math.random() - 1) * 3.0;

      // Simulated thermal impact: thicker dies and higher contact R increase thermal resistance
      const rThermFactor = (dieThick / profile.geometry.thicknessUm) * 0.5 + (rBump / 15.0) * 0.5;
      const peakTemp = 58.0 + (rThermFactor - 1.0) * 18.0 + (Math.random() * 4);

      // Bandwidth degradation if resistance causes timing margin violation
      const bwDegrade = rTsv > profile.tsv.nominalResistanceMOhms * 1.18 ? 0.88 : 1.0;
      const deliveredBw = nominalBw * bwDegrade * (1 - (Math.random() * 0.03));
      const totalPwr = 14.5 + (rTsv / profile.tsv.nominalResistanceMOhms - 1.0) * 2.2;

      // Quality yield pass criterion: peakTemp < 85C and deliveredBw >= nominalBw * 0.92
      const yieldPass = peakTemp < 85.0 && deliveredBw >= (nominalBw * 0.90);
      if (yieldPass) passCount++;

      sumBw += deliveredBw;
      sumTemp += peakTemp;

      samples.push({
        iteration: i,
        tsvResistanceMOhms: Number(rTsv.toFixed(2)),
        bumpResistanceMOhms: Number(rBump.toFixed(2)),
        dieThicknessUm: Number(dieThick.toFixed(1)),
        peakTemperatureC: Number(peakTemp.toFixed(1)),
        deliveredBandwidthGBs: Number(deliveredBw.toFixed(1)),
        totalPowerW: Number(totalPwr.toFixed(2)),
        yieldPass,
      });
    }

    return {
      samples,
      meanBandwidthGBs: Number((sumBw / numSamples).toFixed(1)),
      meanPeakTempC: Number((sumTemp / numSamples).toFixed(1)),
      yieldRatePercent: Number(((passCount / numSamples) * 100).toFixed(1)),
      active: true,
    };
  }
}
