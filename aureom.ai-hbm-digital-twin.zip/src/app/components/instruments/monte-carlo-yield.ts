/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Manufacturing Variation & Monte Carlo Yield Instrument
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';
import { ElectricalPDNEngine } from '../../core/simulation/electrical-pdn-engine';

@Component({
  selector: 'app-monte-carlo-yield',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <!-- Monte Carlo Header & Yield Card -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <div>
            <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Monte Carlo Manufacturing Variation</span>
            <p class="text-[10px] text-slate-400 mt-0.5">
              Stochastic variation across TSV diameter, microbump contact resistance, and grinding thickness tolerances.
            </p>
          </div>
          <button
            (click)="runNewMonteCarlo()"
            class="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-bold rounded border border-cyan-400 shadow transition-colors">
            Run 30-Die Monte Carlo
          </button>
        </div>

        <div class="grid grid-cols-4 gap-2.5 mt-2">
          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-center">
            <span class="text-[9px] text-slate-400">Predicted Stack Yield:</span>
            <div class="text-lg font-bold text-emerald-400">
              {{ simulator.state().monteCarlo.yieldRatePercent }}%
            </div>
            <span class="text-[9px] text-slate-500">T_peak &lt; 85°C &amp; BW &gt; 90%</span>
          </div>

          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-center">
            <span class="text-[9px] text-slate-400">Mean Delivered BW:</span>
            <div class="text-lg font-bold text-cyan-300">
              {{ simulator.state().monteCarlo.meanBandwidthGBs }} <span class="text-xs text-slate-400">GB/s</span>
            </div>
            <span class="text-[9px] text-slate-500">Across sample lot</span>
          </div>

          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-center">
            <span class="text-[9px] text-slate-400">Mean Peak Hotspot:</span>
            <div class="text-lg font-bold text-amber-400">
              {{ simulator.state().monteCarlo.meanPeakTempC }}°C
            </div>
            <span class="text-[9px] text-slate-500">Thermal resistance variance</span>
          </div>

          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-center">
            <span class="text-[9px] text-slate-400">Lot Sample Size:</span>
            <div class="text-lg font-bold text-slate-200">
              {{ simulator.state().monteCarlo.samples.length }} <span class="text-xs text-slate-400">Units</span>
            </div>
            <span class="text-[9px] text-slate-500">Seed: 0x4B3A8F</span>
          </div>
        </div>
      </div>

      <!-- Monte Carlo Sample Distribution Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Simulated Die Lot Samples</span>
          <span class="text-[10px] text-slate-500">Real-Time Parametric Inspection</span>
        </div>

        <div class="h-44 overflow-y-auto border border-slate-800 rounded bg-slate-950">
          <table class="w-full text-left text-[10px]">
            <thead class="bg-slate-900 text-slate-400 border-b border-slate-800 sticky top-0">
              <tr>
                <th class="p-1.5">Lot ID</th>
                <th class="p-1.5">TSV R (mΩ)</th>
                <th class="p-1.5">Bump R (mΩ)</th>
                <th class="p-1.5">Thickness (µm)</th>
                <th class="p-1.5">Peak Temp (°C)</th>
                <th class="p-1.5">Delivered BW</th>
                <th class="p-1.5 text-center">Yield</th>
              </tr>
            </thead>
            <tbody>
              @for (s of simulator.state().monteCarlo.samples; track s.iteration) {
                <tr class="border-b border-slate-800/60 hover:bg-slate-900/60">
                  <td class="p-1.5 font-bold text-slate-300">#{{ s.iteration }}</td>
                  <td class="p-1.5 text-slate-300">{{ s.tsvResistanceMOhms }}</td>
                  <td class="p-1.5 text-slate-400">{{ s.bumpResistanceMOhms }}</td>
                  <td class="p-1.5 text-slate-400">{{ s.dieThicknessUm }}</td>
                  <td class="p-1.5" [class.text-rose-400]="s.peakTemperatureC > 80" [class.text-emerald-400]="s.peakTemperatureC <= 80">
                    {{ s.peakTemperatureC }}°C
                  </td>
                  <td class="p-1.5 text-cyan-300 font-semibold">{{ s.deliveredBandwidthGBs }} GB/s</td>
                  <td class="p-1.5 text-center">
                    <span class="px-1.5 py-0.5 rounded text-[8px] font-bold"
                          [class.bg-emerald-950]="s.yieldPass"
                          [class.text-emerald-400]="s.yieldPass"
                          [class.bg-rose-950]="!s.yieldPass"
                          [class.text-rose-400]="!s.yieldPass">
                      {{ s.yieldPass ? 'PASS' : 'FAIL' }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class MonteCarloYieldComponent {
  public simulator = inject(HBMSimulatorService);
  private electricalEngine = new ElectricalPDNEngine();

  public runNewMonteCarlo(): void {
    const prof = this.simulator.currentProfile();
    const result = this.electricalEngine.runMonteCarloSimulation(prof, 30);
    const s = this.simulator.state();
    this.simulator.state.set({
      ...s,
      monteCarlo: result,
    });
  }
}
