/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * DRAM Command & Timing Matrix Scientific Instrument
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';
import { WorkloadType } from '../../core/models/simulation-state';

@Component({
  selector: 'app-dram-command-timeline',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <!-- Workload Selector & Concurrency Controls -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Active Workload Generator</span>
          <span class="text-[11px] text-cyan-400 font-bold">{{ simulator.state().workload.name }}</span>
        </div>

        <div class="grid grid-cols-4 gap-1.5 mb-3">
          <button
            (click)="setWorkload('sequential_read')"
            [class.bg-cyan-950]="simulator.state().workload.type === 'sequential_read'"
            [class.border-cyan-500]="simulator.state().workload.type === 'sequential_read'"
            class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
            <div class="font-bold text-slate-200">Seq Read</div>
            <div class="text-[9px] text-slate-400">95% Hit Rate</div>
          </button>
          <button
            (click)="setWorkload('random_read_64b')"
            [class.bg-cyan-950]="simulator.state().workload.type === 'random_read_64b'"
            [class.border-cyan-500]="simulator.state().workload.type === 'random_read_64b'"
            class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
            <div class="font-bold text-slate-200">Random 64B</div>
            <div class="text-[9px] text-slate-400">High Conflicts</div>
          </button>
          <button
            (click)="setWorkload('ai_gemm_burst')"
            [class.bg-cyan-950]="simulator.state().workload.type === 'ai_gemm_burst'"
            [class.border-cyan-500]="simulator.state().workload.type === 'ai_gemm_burst'"
            class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
            <div class="font-bold text-slate-200">AI GEMM</div>
            <div class="text-[9px] text-slate-400">All Channels</div>
          </button>
          <button
            (click)="setWorkload('ai_llm_attention')"
            [class.bg-cyan-950]="simulator.state().workload.type === 'ai_llm_attention'"
            [class.border-cyan-500]="simulator.state().workload.type === 'ai_llm_attention'"
            class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
            <div class="font-bold text-slate-200">LLM Attention</div>
            <div class="text-[9px] text-slate-400">KV-Cache Strides</div>
          </button>
        </div>

        <!-- Concurrency & Request Rate Slider -->
        <div class="flex items-center justify-between text-[11px] mb-1">
          <span class="text-slate-400">Traffic Request Intensity:</span>
          <span class="text-cyan-300 font-bold">{{ simulator.state().workload.intensityPercent }}% Request Rate</span>
        </div>
        <input
          type="range"
          min="5"
          max="100"
          step="5"
          [value]="simulator.state().workload.intensityPercent"
          (input)="simulator.setWorkloadIntensity(+$any($event.target).value)"
          class="w-full h-1.5 bg-slate-800 rounded accent-cyan-400 cursor-pointer"
        />
      </div>

      <!-- Real-Time DRAM Command Waterfall Sequence -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Discrete DRAM Command Sequence</span>
          <span class="text-[10px] text-slate-400 font-mono">
            tRC: {{ simulator.currentProfile().timing.tRC }}ns | tRCD: {{ simulator.currentProfile().timing.tRCD }}ns | tCAS: {{ simulator.currentProfile().timing.tCAS }}ns
          </span>
        </div>

        <div class="h-36 overflow-y-auto flex flex-col gap-1 border border-slate-800/80 rounded p-1.5 bg-slate-950">
          @for (cmd of simulator.state().recentCommands; track cmd.id) {
            <div class="flex items-center justify-between px-2 py-1 rounded text-[11px] border"
                 [class.bg-blue-950]="cmd.type === 'RD'"
                 [class.border-blue-800]="cmd.type === 'RD'"
                 [class.bg-emerald-950]="cmd.type === 'WR'"
                 [class.border-emerald-800]="cmd.type === 'WR'"
                 [class.bg-amber-950]="cmd.type === 'ACT'"
                 [class.border-amber-800]="cmd.type === 'ACT'"
                 [class.bg-purple-950]="cmd.type === 'PRE'"
                 [class.border-purple-800]="cmd.type === 'PRE'"
                 [class.bg-rose-950]="cmd.type === 'REF'"
                 [class.border-rose-800]="cmd.type === 'REF'">
              <div class="flex items-center gap-2">
                <span class="font-bold px-1.5 py-0.2 rounded text-[10px]"
                      [class.bg-blue-600]="cmd.type === 'RD'"
                      [class.bg-emerald-600]="cmd.type === 'WR'"
                      [class.bg-amber-600]="cmd.type === 'ACT'"
                      [class.bg-purple-600]="cmd.type === 'PRE'"
                      [class.bg-rose-600]="cmd.type === 'REF'">
                  {{ cmd.type }}
                </span>
                <span class="text-slate-300">Ch {{ cmd.channel }}</span>
                <span class="text-slate-400">Bank {{ cmd.bank }}</span>
                @if (cmd.type !== 'REF') {
                  <span class="text-slate-500">Row {{ cmd.row }}</span>
                }
              </div>

              <div class="flex items-center gap-3">
                @if (cmd.isHit) {
                  <span class="text-[10px] text-emerald-400 font-semibold">ROW HIT</span>
                }
                <span class="text-[10px] text-slate-400">Lat: {{ cmd.latencyNs.toFixed(1) }}ns</span>
                <span class="text-[10px] text-slate-500">t: {{ cmd.timeNs.toFixed(0) }}ns</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Bank State Matrix (Channel x Bank Grid) -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">DRAM Bank Occupancy Matrix</span>
          <div class="flex items-center gap-2 text-[10px]">
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded bg-slate-700"></span> IDLE</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded bg-emerald-500"></span> OPEN</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded bg-cyan-500"></span> RD/WR</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded bg-rose-500"></span> REFRESH</span>
          </div>
        </div>

        <div class="grid grid-cols-8 gap-1 p-2 bg-slate-950 rounded border border-slate-800">
          @for (b of sampleBanks(); track b.channel + '-' + b.bank) {
            <div class="flex flex-col items-center justify-center p-1 rounded border text-[9px]"
                 [class.bg-slate-800]="b.status === 'IDLE'"
                 [class.border-slate-700]="b.status === 'IDLE'"
                 [class.bg-emerald-950]="b.status === 'ROW_OPEN'"
                 [class.border-emerald-600]="b.status === 'ROW_OPEN'"
                 [class.bg-cyan-900]="b.status === 'READING' || b.status === 'WRITING'"
                 [class.border-cyan-400]="b.status === 'READING' || b.status === 'WRITING'"
                 [class.bg-rose-950]="b.status === 'REFRESHING'"
                 [class.border-rose-600]="b.status === 'REFRESHING'">
              <span class="font-bold">C{{ b.channel }}B{{ b.bank }}</span>
              <span class="text-[8px] text-slate-400 truncate w-full text-center">
                {{ b.status === 'ROW_OPEN' ? 'R:' + b.openRow : b.status }}
              </span>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class DramCommandTimelineComponent {
  public simulator = inject(HBMSimulatorService);

  public setWorkload(type: WorkloadType): void {
    this.simulator.setWorkload(type, this.simulator.state().workload.intensityPercent);
  }

  // Display a representative 32-bank subset for high density layout
  public sampleBanks() {
    return this.simulator.state().banks.slice(0, 32);
  }
}
