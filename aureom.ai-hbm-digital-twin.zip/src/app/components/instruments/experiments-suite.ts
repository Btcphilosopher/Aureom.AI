/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Predefined Virtual Engineering Experiments Instrument
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EXPERIMENTS_SUITE, HBMSimulatorService, PredefinedExperiment } from '../../core/simulation/hbm-simulator';

@Component({
  selector: 'app-experiments-suite',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <div class="flex items-center justify-between">
        <div>
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Virtual Engineering Experiments Suite</span>
          <p class="text-[10px] text-slate-400 mt-0.5">
            Pre-packaged semiconductor test scenarios testing thermal, timing, and interconnect limits.
          </p>
        </div>
        @if (simulator.activeExperiment()) {
          <div class="px-2.5 py-1 rounded bg-cyan-950 border border-cyan-500 text-cyan-300 text-[10px] font-bold">
            RUNNING: {{ simulator.activeExperiment()!.code }}
          </div>
        }
      </div>

      <!-- Experiments Grid -->
      <div class="grid grid-cols-2 gap-2.5">
        @for (exp of experiments; track exp.id) {
          <div class="p-3 rounded-lg border transition-all text-left flex flex-col justify-between"
               [class.bg-slate-900]="simulator.activeExperiment()?.id !== exp.id"
               [class.border-slate-800]="simulator.activeExperiment()?.id !== exp.id"
               [class.bg-cyan-950]="simulator.activeExperiment()?.id === exp.id"
               [class.border-cyan-500]="simulator.activeExperiment()?.id === exp.id">
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider"
                      [class.bg-cyan-900]="exp.category === 'Bandwidth'"
                      [class.text-cyan-300]="exp.category === 'Bandwidth'"
                      [class.bg-rose-900]="exp.category === 'Thermal'"
                      [class.text-rose-300]="exp.category === 'Thermal'"
                      [class.bg-amber-900]="exp.category === 'Interconnect'"
                      [class.text-amber-300]="exp.category === 'Interconnect'"
                      [class.bg-purple-900]="exp.category === 'Timing'"
                      [class.text-purple-300]="exp.category === 'Timing'"
                      [class.bg-blue-900]="exp.category === 'AI'"
                      [class.text-blue-300]="exp.category === 'AI'"
                      [class.bg-emerald-900]="exp.category === 'Power'"
                      [class.text-emerald-300]="exp.category === 'Power'"
                      [class.bg-slate-800]="exp.category === 'Packaging'"
                      [class.text-slate-300]="exp.category === 'Packaging'">
                  {{ exp.code }} • {{ exp.category }}
                </span>
                <span class="text-[10px] text-slate-400 font-bold">{{ exp.setup.generation }}</span>
              </div>

              <div class="font-bold text-slate-100 text-xs mb-1">{{ exp.title }}</div>
              <p class="text-[10px] text-slate-400 leading-relaxed mb-3">{{ exp.description }}</p>
            </div>

            <div class="flex items-center justify-between pt-2 border-t border-slate-800/80">
              <span class="text-[9px] text-slate-500">
                Load: {{ exp.setup.intensity }}% | {{ exp.setup.coolingType }}
              </span>
              <button
                (click)="launch(exp)"
                class="px-2.5 py-1 rounded bg-slate-800 hover:bg-cyan-600 text-slate-200 hover:text-white text-[10px] font-bold border border-slate-700 hover:border-cyan-400 transition-colors">
                {{ simulator.activeExperiment()?.id === exp.id ? 'Re-Run' : 'Launch Experiment' }}
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class ExperimentsSuiteComponent {
  public simulator = inject(HBMSimulatorService);
  public experiments = EXPERIMENTS_SUITE;

  public launch(exp: PredefinedExperiment): void {
    this.simulator.launchExperiment(exp);
  }
}
