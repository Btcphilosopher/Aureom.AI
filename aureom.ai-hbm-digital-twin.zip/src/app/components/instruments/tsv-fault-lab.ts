/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * TSV Physical Model & Fault Injection Laboratory Instrument
 */

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';
import { TSVNode } from '../../core/models/simulation-state';

@Component({
  selector: 'app-tsv-fault-lab',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <!-- Defect Injection Toolbar -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Fault Injection Laboratory</span>
          <div class="flex items-center gap-2">
            <span class="text-[10px] text-slate-400">Active Faults:</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
                  [class.bg-emerald-950]="simulator.state().metrics.faultCount === 0"
                  [class.text-emerald-400]="simulator.state().metrics.faultCount === 0"
                  [class.bg-rose-950]="simulator.state().metrics.faultCount > 0"
                  [class.text-rose-400]="simulator.state().metrics.faultCount > 0">
              {{ simulator.state().metrics.faultCount }} Vias
            </span>
            <button
              (click)="simulator.clearAllFaults()"
              class="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] rounded border border-slate-700 transition-colors">
              Clear All Faults
            </button>
          </div>
        </div>

        <!-- Quick Fault Inject Buttons -->
        <div class="grid grid-cols-4 gap-2 mb-2">
          <button
            (click)="injectFaultOnSelected('open')"
            class="px-2 py-1.5 bg-rose-950/80 hover:bg-rose-900 border border-rose-700 rounded text-left transition-colors">
            <div class="font-bold text-rose-300 text-[10px]">Inject Open Circuit</div>
            <div class="text-[9px] text-slate-400">Broken via (R → ∞)</div>
          </button>
          <button
            (click)="injectFaultOnSelected('high_r')"
            class="px-2 py-1.5 bg-amber-950/80 hover:bg-amber-900 border border-amber-700 rounded text-left transition-colors">
            <div class="font-bold text-amber-300 text-[10px]">Inject High Resistance</div>
            <div class="text-[9px] text-slate-400">Micro-voids (8.5× R)</div>
          </button>
          <button
            (click)="injectFaultOnSelected('bridged')"
            class="px-2 py-1.5 bg-purple-950/80 hover:bg-purple-900 border border-purple-700 rounded text-left transition-colors">
            <div class="font-bold text-purple-300 text-[10px]">Inject Bridged Via</div>
            <div class="text-[9px] text-slate-400">Dielectric breach</div>
          </button>
          <button
            (click)="injectFaultOnSelected('rerouted')"
            class="px-2 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700 rounded text-left transition-colors">
            <div class="font-bold text-emerald-300 text-[10px]">Redundancy Reroute</div>
            <div class="text-[9px] text-slate-400">Spare lane failover</div>
          </button>
        </div>

        <div class="text-[10px] text-slate-400">
          Selected Via: <span class="text-cyan-300 font-bold">{{ selectedTsv() ? selectedTsv()!.signalName + ' (ID #' + selectedTsv()!.id + ')' : 'None (Click a via below to inspect/inject)' }}</span>
        </div>
      </div>

      <!-- TSV Array Matrix Map -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Through-Silicon Via Array Grid Map</span>
          <!-- Signal Type Legend -->
          <div class="flex items-center gap-3 text-[9px]">
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#b87333]"></span> DQ</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#f59e0b]"></span> DQS</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#38bdf8]"></span> CLK</span>
            <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-[#ef4444]"></span> FAULT</span>
          </div>
        </div>

        <!-- Density Grid (Interactive via nodes) -->
        <div class="h-44 overflow-y-auto p-2 bg-slate-950 rounded border border-slate-800 grid grid-cols-16 gap-1">
          @for (tsv of sampleTsvs(); track tsv.id) {
            <button
              (click)="selectTsv(tsv)"
              [class.ring-2]="selectedTsv()?.id === tsv.id"
              [class.ring-cyan-400]="selectedTsv()?.id === tsv.id"
              [style.background-color]="getTsvNodeColor(tsv)"
              class="w-full h-5 rounded flex items-center justify-center text-[7px] font-bold text-slate-950 transition-transform hover:scale-110"
              [title]="tsv.signalName + ' | ' + tsv.actualResistanceMOhms.toFixed(1) + ' mΩ | ' + tsv.fault">
              {{ tsv.fault !== 'nominal' ? '!' : (tsv.signalType === 'DQ' ? '' : tsv.signalType[0]) }}
            </button>
          }
        </div>
      </div>

      <!-- Selected TSV Detailed Parameter Card -->
      @if (selectedTsv()) {
        <div class="bg-slate-900 border border-cyan-800/80 rounded-lg p-3">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold text-cyan-300">TSV Electrical Parameters: {{ selectedTsv()!.signalName }}</span>
            <span class="text-[10px] px-2 py-0.5 rounded font-bold uppercase"
                  [class.bg-emerald-950]="selectedTsv()!.fault === 'nominal'"
                  [class.text-emerald-400]="selectedTsv()!.fault === 'nominal'"
                  [class.bg-rose-950]="selectedTsv()!.fault === 'open'"
                  [class.text-rose-400]="selectedTsv()!.fault === 'open'"
                  [class.bg-amber-950]="selectedTsv()!.fault === 'high_r'"
                  [class.text-amber-400]="selectedTsv()!.fault === 'high_r'">
              {{ selectedTsv()!.fault }}
            </span>
          </div>

          <div class="grid grid-cols-4 gap-2 text-[10px]">
            <div class="bg-slate-950 p-2 rounded border border-slate-800">
              <span class="text-slate-500">Coordinates (X, Z):</span>
              <div class="font-bold text-slate-200">{{ selectedTsv()!.xMm }} mm, {{ selectedTsv()!.zMm }} mm</div>
            </div>
            <div class="bg-slate-950 p-2 rounded border border-slate-800">
              <span class="text-slate-500">DC Resistance:</span>
              <div class="font-bold" [class.text-rose-400]="selectedTsv()!.actualResistanceMOhms > 100" [class.text-slate-200]="selectedTsv()!.actualResistanceMOhms <= 100">
                {{ selectedTsv()!.actualResistanceMOhms >= 1000 ? (selectedTsv()!.actualResistanceMOhms / 1000).toFixed(0) + ' Ω' : selectedTsv()!.actualResistanceMOhms.toFixed(2) + ' mΩ' }}
              </div>
            </div>
            <div class="bg-slate-950 p-2 rounded border border-slate-800">
              <span class="text-slate-500">Parasitic Capacitance:</span>
              <div class="font-bold text-slate-200">{{ selectedTsv()!.capacitanceFF.toFixed(1) }} fF</div>
            </div>
            <div class="bg-slate-950 p-2 rounded border border-slate-800">
              <span class="text-slate-500">Channel Association:</span>
              <div class="font-bold text-cyan-400">Channel {{ selectedTsv()!.channel }}</div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class TsvFaultLabComponent {
  public simulator = inject(HBMSimulatorService);
  public selectedTsv = signal<TSVNode | null>(null);

  public sampleTsvs(): TSVNode[] {
    // Return first 128 TSVs for compact interactive matrix inspection
    return this.simulator.state().tsvs.slice(0, 128);
  }

  public selectTsv(tsv: TSVNode): void {
    this.selectedTsv.set(tsv);
    this.simulator.selectedEntity.set({
      type: 'tsv',
      id: tsv.id,
      title: `${tsv.signalName} (TSV #${tsv.id})`,
      data: {
        signalName: tsv.signalName,
        signalType: tsv.signalType,
        channel: tsv.channel,
        coordinates: `X: ${tsv.xMm} mm, Z: ${tsv.zMm} mm`,
        actualResistance: `${tsv.actualResistanceMOhms.toFixed(2)} mOhm`,
        parasiticCapacitance: `${tsv.capacitanceFF} fF`,
        faultStatus: tsv.fault,
      },
    });
  }

  public injectFaultOnSelected(fault: 'open' | 'high_r' | 'bridged' | 'rerouted'): void {
    const curr = this.selectedTsv();
    const targetId = curr ? curr.id : (this.simulator.state().tsvs[16]?.id || 1);
    this.simulator.injectTSVFault(targetId, fault);

    const updated = this.simulator.state().tsvs.find((t) => t.id === targetId);
    if (updated) {
      this.selectedTsv.set(updated);
    }
  }

  public getTsvNodeColor(tsv: TSVNode): string {
    if (tsv.fault === 'open') return '#ef4444'; // Red
    if (tsv.fault === 'high_r') return '#f59e0b'; // Amber
    if (tsv.fault === 'rerouted') return '#10b981'; // Green
    if (tsv.signalType === 'CLK') return '#38bdf8'; // Blue
    if (tsv.signalType === 'DQS') return '#fbbf24'; // Yellow
    if (tsv.signalType === 'CMD') return '#c084fc'; // Purple
    return '#b87333'; // Copper
  }
}
