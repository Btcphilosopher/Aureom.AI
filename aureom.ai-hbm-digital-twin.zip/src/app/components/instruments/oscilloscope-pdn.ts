/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Virtual Oscilloscope & Power Delivery Network (PDN) Instrument
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';

@Component({
  selector: 'app-oscilloscope-pdn',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <!-- High-Speed Signal Integrity Oscilloscope -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <div class="flex items-center gap-2">
            <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Virtual Mixed-Signal Oscilloscope</span>
            <span class="text-[9px] bg-cyan-950 text-cyan-400 border border-cyan-800 px-1.5 py-0.5 rounded">
              {{ simulator.currentProfile().transferRateGbps }} Gbps PHY
            </span>
          </div>
          <div class="flex items-center gap-3 text-[10px]">
            <span class="text-cyan-400 flex items-center gap-1"><span class="w-2 h-0.5 bg-cyan-400"></span> DQ0 Signal</span>
            <span class="text-amber-400 flex items-center gap-1"><span class="w-2 h-0.5 bg-amber-400"></span> DQS Strobe</span>
            <span class="text-blue-400 flex items-center gap-1"><span class="w-2 h-0.5 bg-blue-400"></span> Diff Clock</span>
          </div>
        </div>

        <!-- Waveform Display Screen (SVG) -->
        <div class="h-36 bg-[#060a12] border border-slate-800 rounded relative overflow-hidden flex items-center justify-center">
          <!-- Oscilloscope Reticle Grid -->
          <div class="absolute inset-0 grid grid-cols-8 grid-rows-4 pointer-events-none opacity-20">
            @for (i of [1,2,3,4,5,6,7,8]; track i) {
              <div class="border-r border-cyan-500"></div>
            }
          </div>

          <svg class="w-full h-full relative z-10" viewBox="0 0 400 120" preserveAspectRatio="none">
            <!-- Clock Waveform (Blue) -->
            <path [attr.d]="getClockPath()" fill="none" stroke="#38bdf8" stroke-width="1.2" opacity="0.6" />
            <!-- DQS Strobe (Amber) -->
            <path [attr.d]="getDqsPath()" fill="none" stroke="#f59e0b" stroke-width="1.4" opacity="0.8" />
            <!-- DQ0 Data Waveform (Cyan) -->
            <path [attr.d]="getDqPath()" fill="none" stroke="#06b6d4" stroke-width="2.0" />
          </svg>
        </div>

        <!-- Signal Integrity Quality Metrics -->
        <div class="grid grid-cols-3 gap-2 mt-2.5">
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">10-90% Rise Time:</div>
            <div class="text-sm font-bold text-slate-200">
              {{ simulator.state().oscilloscope.riseTimePs.toFixed(1) }} ps
            </div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Deterministic Jitter:</div>
            <div class="text-sm font-bold text-amber-400">
              {{ simulator.state().oscilloscope.jitterPs.toFixed(1) }} ps
            </div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Voltage Eye Margin:</div>
            <div class="text-sm font-bold text-emerald-400">
              ±{{ simulator.state().oscilloscope.voltageMarginMv }} mV
            </div>
          </div>
        </div>
      </div>

      <!-- Power Delivery Network (PDN) Transient Droop -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Power Delivery Network (PDN) Rail</span>
          <span class="text-[10px] text-slate-400 font-mono">
            V_nom: {{ simulator.state().pdn.nominalVddV.toFixed(2) }}V | L_pkg: 25pH | R_pkg: 3.5mΩ
          </span>
        </div>

        <div class="grid grid-cols-3 gap-2 mb-2">
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Instantaneous VDD:</div>
            <div class="text-base font-bold text-cyan-300">
              {{ simulator.state().pdn.instantaneousVddV }} V
            </div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Supply Droop (L·di/dt):</div>
            <div class="text-base font-bold text-amber-400">
              -{{ simulator.state().pdn.droopPercent }}%
            </div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Total Load Current:</div>
            <div class="text-base font-bold text-emerald-400">
              {{ simulator.state().pdn.currentAmps }} A
            </div>
          </div>
        </div>

        <!-- PDN Voltage Waveform Mini Display -->
        <div class="h-20 bg-[#060a12] border border-slate-800 rounded relative overflow-hidden flex items-center justify-center p-1">
          <svg class="w-full h-full" viewBox="0 0 300 60" preserveAspectRatio="none">
            <!-- Reference Nominal Line -->
            <line x1="0" y1="15" x2="300" y2="15" stroke="#334155" stroke-dasharray="2,2" stroke-width="1" />
            <!-- Droop Curve -->
            <path [attr.d]="getPdnPath()" fill="none" stroke="#f59e0b" stroke-width="2.0" />
          </svg>
        </div>
      </div>
    </div>
  `,
})
export class OscilloscopePdnComponent {
  public simulator = inject(HBMSimulatorService);

  public getDqPath(): string {
    const data = this.simulator.state().oscilloscope.dq0SignalV;
    const vdd = this.simulator.state().pdn.nominalVddV;
    if (!data || data.length === 0) return '';

    return data
      .map((val, i) => {
        const x = (i / (data.length - 1)) * 400;
        // Invert Y for SVG coordinates (0 at top)
        const y = 110 - (val / vdd) * 100;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }

  public getDqsPath(): string {
    const data = this.simulator.state().oscilloscope.dqsStrobeV;
    const vdd = this.simulator.state().pdn.nominalVddV;
    if (!data || data.length === 0) return '';

    return data
      .map((val, i) => {
        const x = (i / (data.length - 1)) * 400;
        const y = 110 - (val / vdd) * 100;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }

  public getClockPath(): string {
    const data = this.simulator.state().oscilloscope.clockSignalV;
    const vdd = this.simulator.state().pdn.nominalVddV;
    if (!data || data.length === 0) return '';

    return data
      .map((val, i) => {
        const x = (i / (data.length - 1)) * 400;
        const y = 110 - (val / vdd) * 100;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }

  public getPdnPath(): string {
    const waveform = this.simulator.state().pdn.voltageWaveform;
    const vNom = this.simulator.state().pdn.nominalVddV;
    if (!waveform || waveform.length === 0) return '';

    return waveform
      .map((pt, i) => {
        const x = (i / (waveform.length - 1)) * 300;
        // Map voltage delta around 30px center
        const delta = vNom - pt.voltageV;
        const y = 15 + delta * 250;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  }
}
