/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Thermal & Hotspot Probe Scientific Instrument
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';
import { CoolingType } from '../../core/models/simulation-state';

@Component({
  selector: 'app-thermal-probe',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <!-- Hotspot & Runaway Status Banner -->
      <div class="flex items-center justify-between p-3 rounded-lg border"
           [class.bg-rose-950]="simulator.state().metrics.thermalRunawayWarning"
           [class.border-rose-600]="simulator.state().metrics.thermalRunawayWarning"
           [class.bg-slate-900]="!simulator.state().metrics.thermalRunawayWarning"
           [class.border-slate-800]="!simulator.state().metrics.thermalRunawayWarning">
        <div>
          <div class="text-[11px] text-slate-400 uppercase tracking-wider">Governing Thermal State</div>
          <div class="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>Peak Die Temperature:</span>
            <span [class.text-rose-400]="simulator.state().metrics.stackMaxTempC > 85"
                  [class.text-amber-400]="simulator.state().metrics.stackMaxTempC > 65 && simulator.state().metrics.stackMaxTempC <= 85"
                  [class.text-emerald-400]="simulator.state().metrics.stackMaxTempC <= 65">
              {{ simulator.state().metrics.stackMaxTempC }}°C ({{ (simulator.state().metrics.stackMaxTempC + 273.15).toFixed(1) }} K)
            </span>
          </div>
          <div class="text-[11px] text-slate-400 mt-0.5">
            Stack Average: <span class="text-cyan-300 font-medium">{{ simulator.state().metrics.stackAvgTempC }}°C</span> |
            Hotspot on: <span class="text-amber-300">{{ simulator.state().dies[simulator.state().metrics.maxHotspotDieIndex]?.name || 'Base Die' }}</span>
          </div>
        </div>

        @if (simulator.state().metrics.thermalRunawayWarning) {
          <div class="px-2.5 py-1 rounded bg-rose-900/80 border border-rose-500 text-rose-200 text-xs font-bold animate-none">
            THERMAL RUNAWAY RISK
          </div>
        }
      </div>

      <!-- Die-by-Die Vertical Temperature Gradient -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Vertical Die Temperature Gradient</span>
          <span class="text-[10px] text-slate-500">Base Die (Bottom) → DRAM Stack (Top)</span>
        </div>

        <div class="flex flex-col gap-1.5">
          @for (die of simulator.state().dies; track die.dieIndex) {
            <button type="button"
                 class="w-full flex items-center gap-3 p-1.5 rounded hover:bg-slate-800/60 cursor-pointer border border-transparent hover:border-slate-700 transition-colors text-left"
                 (click)="selectDie(die.dieIndex)">
              <div class="w-28 truncate text-[11px] font-medium" [class.text-cyan-400]="die.isBaseDie" [class.text-slate-300]="!die.isBaseDie">
                {{ die.name }}
              </div>

              <!-- Bar gauge -->
              <div class="flex-1 bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
                <div class="h-full rounded-full transition-all duration-300"
                     [style.width.%]="getTempPercent(die.temperatureC)"
                     [style.background-color]="getBarColor(die.temperatureC)">
                </div>
              </div>

              <div class="w-16 text-right font-mono font-semibold" [style.color]="getBarColor(die.temperatureC)">
                {{ die.temperatureC }}°C
              </div>

              <div class="w-20 text-right text-[10px] text-slate-400">
                {{ die.powerWatts.total.toFixed(2) }} W
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Power Breakdown & Leakage Feedback -->
      <div class="grid grid-cols-2 gap-3">
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
          <div class="text-[11px] uppercase tracking-wider text-slate-400 mb-2 font-semibold">Stack Power Breakdown</div>
          <div class="flex flex-col gap-1 text-[11px]">
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-400">Dynamic Active (Rd/Wr):</span>
              <span class="text-cyan-300 font-semibold">{{ simulator.state().metrics.activePowerW }} W</span>
            </div>
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-400">Static Background:</span>
              <span class="text-slate-300">{{ simulator.state().metrics.backgroundPowerW }} W</span>
            </div>
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-400">Refresh Overheads:</span>
              <span class="text-amber-300">{{ simulator.state().metrics.refreshPowerW }} W</span>
            </div>
            <div class="flex justify-between py-0.5 border-b border-slate-800">
              <span class="text-slate-400">Temp-Dependent Leakage:</span>
              <span class="text-rose-400 font-semibold">{{ simulator.state().metrics.leakagePowerW }} W</span>
            </div>
            <div class="flex justify-between pt-1 font-bold">
              <span class="text-slate-200">Total Stack Power:</span>
              <span class="text-emerald-400">{{ simulator.state().metrics.totalPowerW }} W</span>
            </div>
          </div>
        </div>

        <!-- Cooling Boundary Condition Controls -->
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
          <div class="text-[11px] uppercase tracking-wider text-slate-400 mb-2 font-semibold">Cooling Boundary Condition</div>
          <div class="grid grid-cols-2 gap-1.5 mb-2.5">
            <button
              (click)="setCooling('passive')"
              [class.bg-cyan-950]="simulator.state().cooling.type === 'passive'"
              [class.border-cyan-500]="simulator.state().cooling.type === 'passive'"
              class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
              <div class="font-bold text-slate-200">Passive</div>
              <div class="text-[9px] text-slate-400">35 W/m²K</div>
            </button>
            <button
              (click)="setCooling('forced_air')"
              [class.bg-cyan-950]="simulator.state().cooling.type === 'forced_air'"
              [class.border-cyan-500]="simulator.state().cooling.type === 'forced_air'"
              class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
              <div class="font-bold text-slate-200">Forced Air</div>
              <div class="text-[9px] text-slate-400">450 W/m²K</div>
            </button>
            <button
              (click)="setCooling('vapor_chamber')"
              [class.bg-cyan-950]="simulator.state().cooling.type === 'vapor_chamber'"
              [class.border-cyan-500]="simulator.state().cooling.type === 'vapor_chamber'"
              class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
              <div class="font-bold text-slate-200">Vapor Chamber</div>
              <div class="text-[9px] text-slate-400">1200 W/m²K</div>
            </button>
            <button
              (click)="setCooling('liquid_coldplate')"
              [class.bg-cyan-950]="simulator.state().cooling.type === 'liquid_coldplate'"
              [class.border-cyan-500]="simulator.state().cooling.type === 'liquid_coldplate'"
              class="px-2 py-1 text-[10px] rounded border border-slate-700 hover:border-slate-500 text-left transition-colors">
              <div class="font-bold text-slate-200">Liquid Coldplate</div>
              <div class="text-[9px] text-slate-400">5500 W/m²K</div>
            </button>
          </div>

          <!-- Ambient Temp Slider -->
          <div class="flex items-center justify-between text-[11px] mb-1">
            <span class="text-slate-400">Ambient Temp:</span>
            <span class="text-cyan-300 font-bold">{{ simulator.state().cooling.ambientTemperatureC }}°C</span>
          </div>
          <input
            type="range"
            min="10"
            max="65"
            step="1"
            [value]="simulator.state().cooling.ambientTemperatureC"
            (input)="onAmbientChange(+$any($event.target).value)"
            class="w-full h-1.5 bg-slate-800 rounded accent-cyan-400 cursor-pointer"
          />
        </div>
      </div>
    </div>
  `,
})
export class ThermalProbeComponent {
  public simulator = inject(HBMSimulatorService);

  public setCooling(type: CoolingType): void {
    this.simulator.setCooling(type, this.simulator.state().cooling.ambientTemperatureC);
  }

  public onAmbientChange(val: number): void {
    this.simulator.setCooling(this.simulator.state().cooling.type, val);
  }

  public selectDie(dieIndex: number): void {
    const die = this.simulator.state().dies[dieIndex];
    if (die) {
      this.simulator.selectedEntity.set({
        type: 'die',
        id: dieIndex,
        title: die.name,
        data: {
          name: die.name,
          temperatureC: die.temperatureC,
          peakHotspotC: die.peakHotspotC,
          hotspotCoordinates: `X: ${die.hotspotX.toFixed(2)} mm, Z: ${die.hotspotZ.toFixed(2)} mm`,
          totalPowerW: die.powerWatts.total.toFixed(2),
          backgroundPowerW: die.powerWatts.background.toFixed(2),
          activePowerW: die.powerWatts.active.toFixed(2),
          leakagePowerW: die.powerWatts.leakage.toFixed(2),
        },
      });
    }
  }

  public getTempPercent(tempC: number): number {
    return Math.max(5, Math.min(100, ((tempC - 20) / (110 - 20)) * 100));
  }

  public getBarColor(tempC: number): string {
    if (tempC > 95) return '#ef4444';
    if (tempC > 80) return '#f59e0b';
    if (tempC > 60) return '#10b981';
    if (tempC > 40) return '#06b6d4';
    return '#3b82f6';
  }
}
