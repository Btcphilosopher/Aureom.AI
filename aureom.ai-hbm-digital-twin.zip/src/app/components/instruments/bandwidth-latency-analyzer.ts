/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Bandwidth & Latency Analyzer Scientific Instrument
 */

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';

@Component({
  selector: 'app-bandwidth-latency-analyzer',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 p-4 overflow-y-auto font-mono text-xs text-slate-300">
      <!-- Theoretical Peak vs Delivered Bandwidth -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Memory Bandwidth Engine</span>
          <span class="text-[10px] text-cyan-400 font-mono">
            B_peak = ({{ simulator.currentProfile().busWidthBits }}b × {{ simulator.currentProfile().transferRateGbps }}Gbps) / 8
          </span>
        </div>

        <div class="grid grid-cols-3 gap-3 mb-3">
          <div class="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div class="text-[10px] text-slate-400">Theoretical Peak:</div>
            <div class="text-lg font-bold text-slate-100">
              {{ simulator.state().metrics.theoreticalPeakBandwidthGBs.toFixed(1) }} <span class="text-xs text-slate-400">GB/s</span>
            </div>
            <div class="text-[9px] text-slate-500">Physical pin limit</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div class="text-[10px] text-slate-400">Delivered Bandwidth:</div>
            <div class="text-lg font-bold text-cyan-400">
              {{ simulator.state().metrics.deliveredBandwidthGBs.toFixed(1) }} <span class="text-xs text-slate-400">GB/s</span>
            </div>
            <div class="text-[9px] text-slate-400">
              Read: {{ simulator.state().metrics.readThroughputGBs }} | Write: {{ simulator.state().metrics.writeThroughputGBs }}
            </div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded border border-slate-800">
            <div class="text-[10px] text-slate-400">Bandwidth Efficiency:</div>
            <div class="text-lg font-bold text-emerald-400">
              {{ simulator.state().metrics.bandwidthEfficiencyPercent }}%
            </div>
            <div class="text-[9px] text-slate-400">
              Channel Util: {{ simulator.state().metrics.channelUtilizationPercent }}%
            </div>
          </div>
        </div>

        <!-- Bandwidth Utilization Gauge Bar -->
        <div class="flex flex-col gap-1">
          <div class="flex justify-between text-[10px] text-slate-400">
            <span>Delivered Bandwidth Utilization Ratio</span>
            <span class="text-cyan-300 font-bold">
              {{ ((simulator.state().metrics.deliveredBandwidthGBs / simulator.state().metrics.theoreticalPeakBandwidthGBs) * 100).toFixed(1) }}% of Peak
            </span>
          </div>
          <div class="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
            <div class="h-full bg-gradient-to-r from-blue-600 via-cyan-500 to-emerald-400 rounded-full transition-all duration-300"
                 [style.width.%]="(simulator.state().metrics.deliveredBandwidthGBs / simulator.state().metrics.theoreticalPeakBandwidthGBs) * 100">
            </div>
          </div>
        </div>
      </div>

      <!-- Discrete-Event Latency Distributions & Percentiles -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Discrete-Event Latency Statistics</span>
          <span class="text-[10px] text-slate-400">FR-FCFS Turnaround (ns)</span>
        </div>

        <!-- Latency Percentiles Grid -->
        <div class="grid grid-cols-5 gap-2 mb-3 text-center">
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Average</div>
            <div class="text-sm font-bold text-slate-200">{{ simulator.state().metrics.latencyAvgNs }} ns</div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Median</div>
            <div class="text-sm font-bold text-cyan-300">{{ simulator.state().metrics.latencyMedianNs }} ns</div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">P95 Tail</div>
            <div class="text-sm font-bold text-amber-400">{{ simulator.state().metrics.latencyP95Ns }} ns</div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">P99 Tail</div>
            <div class="text-sm font-bold text-rose-400">{{ simulator.state().metrics.latencyP99Ns }} ns</div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-400">Worst Case</div>
            <div class="text-sm font-bold text-rose-500">{{ simulator.state().metrics.latencyMaxNs }} ns</div>
          </div>
        </div>

        <!-- Latency Histogram -->
        <div class="text-[10px] text-slate-400 mb-1.5 flex justify-between">
          <span>Latency Density Histogram (Recorded Transactions)</span>
          <span>Row Hit Rate: {{ simulator.state().metrics.rowBufferHitRatePercent }}%</span>
        </div>

        <div class="h-28 bg-slate-950 border border-slate-800 rounded p-2 flex items-end gap-2 justify-between">
          @for (bin of simulator.state().metrics.latencyHistogram; track bin.latencyNs) {
            <div class="flex-1 flex flex-col items-center gap-1 h-full justify-end">
              <div class="w-full bg-cyan-500/80 hover:bg-cyan-400 rounded-t transition-all"
                   [style.height.%]="getHistogramBinHeight(bin.count)"
                   [title]="bin.latencyNs + ' ns: ' + bin.count + ' transactions'">
              </div>
              <span class="text-[8px] text-slate-500">{{ bin.latencyNs }}ns</span>
            </div>
          }
        </div>
      </div>

      <!-- Execution Cumulative Telemetry -->
      <div class="bg-slate-900 border border-slate-800 rounded-lg p-3 flex items-center justify-between">
        <div>
          <span class="text-[10px] text-slate-400">Total Completed Transactions:</span>
          <div class="text-base font-bold text-slate-100">{{ simulator.state().metrics.totalTransactions.toLocaleString() }}</div>
        </div>
        <div>
          <span class="text-[10px] text-slate-400">Cumulative Data Transferred:</span>
          <div class="text-base font-bold text-cyan-400">{{ simulator.state().metrics.transferredBytesMB.toFixed(2) }} MB</div>
        </div>
        <div>
          <span class="text-[10px] text-slate-400">Refresh Overheads:</span>
          <div class="text-base font-bold text-amber-400">
            {{ simulator.state().metrics.refreshMultiplier }}x ({{ (simulator.state().metrics.currentRefreshIntervalNs / 1000).toFixed(1) }} µs)
          </div>
        </div>
      </div>
    </div>
  `,
})
export class BandwidthLatencyAnalyzerComponent {
  public simulator = inject(HBMSimulatorService);

  public getHistogramBinHeight(count: number): number {
    const maxCount = Math.max(1, ...this.simulator.state().metrics.latencyHistogram.map((b) => b.count));
    return Math.max(5, (count / maxCount) * 100);
  }
}
