/**
 * AUREOM.AI — HBM DIGITAL TWIN
 * Interactive 3D Semiconductor Stack View (Three.js)
 * 
 * Renders:
 * - Package substrate & BGA solder balls
 * - Silicon interposer with metallization traces
 * - Base Logic / PHY die (Die 0)
 * - Microbump solder arrays between each tier
 * - DRAM Silicon Dies (Die 1..N)
 * - High-density Copper TSV arrays with active signal pulse propagation
 * - Calibrated thermal colormap overlay
 * - Exploded-layer kinematics and cross-section clipping planes
 */

import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  effect,
  inject,
  PLATFORM_ID,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { HBMSimulatorService } from '../../core/simulation/hbm-simulator';
import { HBMProfile } from '../../core/models/hbm-spec';
import { DieThermalState, TSVNode } from '../../core/models/simulation-state';

@Component({
  selector: 'app-hbm-stack-3d',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './hbm-stack-3d.html',
  styleUrl: './hbm-stack-3d.css',
})
export class HBMStack3DComponent implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true })
  private containerRef!: ElementRef<HTMLDivElement>;

  public simulator = inject(HBMSimulatorService);

  // Visualization Control Signals
  public explodedSpacing = 0.0; // 0 = compact, 1.0 = fully exploded
  public targetExplodedSpacing = 0.0;
  public showHeatmap = true;
  public showTSVs = true;
  public showMicrobumps = true;
  public crossSectionCut = false;
  public activeCameraPreset = 'iso';
  public hoveredEntityName = '';

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private pmremGenerator!: THREE.PMREMGenerator;

  private stackGroup = new THREE.Group();
  private dieMeshes: { mesh: THREE.Mesh; dieIndex: number; basePosY: number }[] = [];
  private bumpGroups: { group: THREE.Group; tierIndex: number; basePosY: number }[] = [];
  private tsvInstancedMesh: THREE.InstancedMesh | null = null;
  private tsvDataList: TSVNode[] = [];
  private tsvBasePosY = 0;

  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private animationFrameId: number | null = null;
  private isSoftwareGl = false;

  // Reusable vectors to avoid GC in animation loop
  private readonly _vec3 = new THREE.Vector3();
  private readonly _color = new THREE.Color();
  private readonly _mat4 = new THREE.Matrix4();

  // Clipping Plane for Cross-Section View
  private clippingPlane = new THREE.Plane(new THREE.Vector3(1, 0, 0), 0);
  private platformId = inject(PLATFORM_ID);

  constructor() {
    // Re-render when simulation state updates
    effect(() => {
      const state = this.simulator.state();
      if (isPlatformBrowser(this.platformId) && this.renderer) {
        this.updateDieTemperatures(state.dies);
        this.updateTSVVisuals(state.tsvs);
      }
    });
  }

  public ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    this.initThreeJS();
    this.buildSemiconductorStack();
    this.startRenderLoop();
  }

  public ngOnDestroy(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    if (this.renderer?.domElement) {
      this.renderer.domElement.removeEventListener('mousemove', this.onPointerMove);
      this.renderer.domElement.removeEventListener('click', this.onPointerClick);
    }
    if (this.controls) {
      this.controls.dispose();
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
    if (this.pmremGenerator) {
      this.pmremGenerator.dispose();
    }
  }

  /**
   * Initializes the Three.js viewport with calibrated lighting and camera.
   */
  private initThreeJS(): void {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Detect software WebGL guard
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x080c14); // Deep semiconductor CAD background
    this.scene.fog = new THREE.FogExp2(0x080c14, 0.015);

    // Camera
    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    this.camera.position.set(12, 10, 16);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: true,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;

    container.appendChild(this.renderer.domElement);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.05;
    this.controls.maxDistance = 50;
    this.controls.minDistance = 3;
    this.controls.target.set(0, 1.5, 0);

    // Procedural Studio Environment Reflection
    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = this.pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    // Lighting Rig (Key, Fill, Rim)
    const keyLight = new THREE.DirectionalLight(0xfffaed, 2.8);
    keyLight.position.set(10, 18, 12);
    keyLight.castShadow = !this.isSoftwareGl;
    if (keyLight.shadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
    }
    this.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x7ea8d8, 1.2);
    fillLight.position.set(-12, 10, -10);
    this.scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight(0xdce7f5, 0x0f1826, 0.8);
    this.scene.add(hemiLight);

    // Floor Contact Shadow Plane
    const floorGeo = new THREE.PlaneGeometry(30, 30);
    const floorMat = new THREE.MeshBasicMaterial({
      color: 0x05080f,
      depthWrite: false,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = -0.02;
    this.scene.add(floorMesh);

    // Coordinate Grid Helper
    const gridHelper = new THREE.GridHelper(24, 24, 0x1e293b, 0x0f172a);
    gridHelper.position.y = 0.01;
    this.scene.add(gridHelper);

    this.scene.add(this.stackGroup);

    // Resize Handler
    window.addEventListener('resize', this.onWindowResize);

    // Mouse Move & Click Raycaster Handler
    const domEl = this.renderer.domElement;
    domEl.addEventListener('mousemove', this.onPointerMove);
    domEl.addEventListener('click', this.onPointerClick);
  }

  /**
   * Constructs the complete physical 3D High Bandwidth Memory stack.
   */
  private buildSemiconductorStack(): void {
    // Clear previous objects
    while (this.stackGroup.children.length > 0) {
      const obj = this.stackGroup.children[0];
      this.stackGroup.remove(obj);
    }
    this.dieMeshes = [];
    this.bumpGroups = [];

    const profile = this.simulator.currentProfile();
    const numDies = this.simulator.state().dies.length;

    // Geometric scale: 1 world unit = 1 mm
    const dieLen = profile.geometry.lengthMm;
    const dieWid = profile.geometry.widthMm;
    const dieThickness = 0.35; // Visually enhanced thickness for clear inspection
    const bumpHeight = 0.22; // Microbump gap

    // 1. Package Substrate (Organic PCB BGA base)
    const subLen = dieLen * 1.5;
    const subWid = dieWid * 1.4;
    const subThick = 0.6;
    const subGeo = new THREE.BoxGeometry(subLen, subThick, subWid);
    const subMat = new THREE.MeshStandardMaterial({
      color: 0x1b281f, // Deep green solder mask
      roughness: 0.6,
      metalness: 0.2,
      clippingPlanes: this.crossSectionCut ? [this.clippingPlane] : [],
    });
    const subMesh = new THREE.Mesh(subGeo, subMat);
    subMesh.position.set(0, subThick / 2, 0);
    subMesh.castShadow = true;
    subMesh.receiveShadow = true;
    subMesh.userData = { name: 'Package Substrate (Organic PCB)' };
    this.stackGroup.add(subMesh);

    // Substrate BGA Solder Balls underneath
    const bgaGeo = new THREE.SphereGeometry(0.18, 8, 8);
    const bgaMat = new THREE.MeshStandardMaterial({
      color: 0xcccccc,
      metalness: 0.9,
      roughness: 0.15,
    });
    const bgaGroup = new THREE.Group();
    for (let bx = -subLen / 2 + 0.6; bx <= subLen / 2 - 0.6; bx += 0.9) {
      for (let bz = -subWid / 2 + 0.6; bz <= subWid / 2 - 0.6; bz += 0.9) {
        const ball = new THREE.Mesh(bgaGeo, bgaMat);
        ball.position.set(bx, -0.15, bz);
        bgaGroup.add(ball);
      }
    }
    this.stackGroup.add(bgaGroup);

    // 2. Silicon Interposer (Fine-pitch RDL routing)
    const intLen = dieLen * 1.25;
    const intWid = dieWid * 1.2;
    const intThick = 0.3;
    const intGeo = new THREE.BoxGeometry(intLen, intThick, intWid);
    const intMat = new THREE.MeshStandardMaterial({
      color: 0x222d3d,
      roughness: 0.3,
      metalness: 0.5,
      clippingPlanes: this.crossSectionCut ? [this.clippingPlane] : [],
    });
    const intMesh = new THREE.Mesh(intGeo, intMat);
    const intPosY = subThick + intThick / 2 + 0.05;
    intMesh.position.set(0, intPosY, 0);
    intMesh.castShadow = true;
    intMesh.userData = { name: 'Silicon Passive Interposer (CoWoS RDL)' };
    this.stackGroup.add(intMesh);

    let currentY = intPosY + intThick / 2 + 0.08;

    // 3. Stacked Silicon Dies (Die 0 = Base Logic, Die 1..N = DRAM)
    const bumpRadius = 0.055;
    const bumpGeo = new THREE.SphereGeometry(bumpRadius, 6, 6);
    const bumpMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37, // Gold / solder finish
      metalness: 0.9,
      roughness: 0.1,
    });

    for (let d = 0; d < numDies; d++) {
      const isBase = d === 0;
      const dieName = isBase ? 'Base Logic / PHY Die 0' : `DRAM Memory Die ${d}`;

      // Microbump array beneath each die
      const bumpTier = new THREE.Group();
      if (this.showMicrobumps) {
        const bumpStepX = dieLen / 10;
        const bumpStepZ = dieWid / 10;
        for (let x = -dieLen / 2 + 0.4; x <= dieLen / 2 - 0.4; x += bumpStepX) {
          for (let z = -dieWid / 2 + 0.4; z <= dieWid / 2 - 0.4; z += bumpStepZ) {
            const b = new THREE.Mesh(bumpGeo, bumpMat);
            b.position.set(x, 0, z);
            bumpTier.add(b);
          }
        }
      }
      bumpTier.position.set(0, currentY + bumpHeight / 2, 0);
      this.bumpGroups.push({
        group: bumpTier,
        tierIndex: d,
        basePosY: currentY + bumpHeight / 2,
      });
      this.stackGroup.add(bumpTier);

      currentY += bumpHeight;

      // Die Silicon Body
      const dieGeo = new THREE.BoxGeometry(dieLen, dieThickness, dieWid);
      const dieMat = new THREE.MeshStandardMaterial({
        color: isBase ? 0x1e3a5f : 0x2563eb,
        roughness: 0.25,
        metalness: 0.4,
        transparent: true,
        opacity: 0.92,
        clippingPlanes: this.crossSectionCut ? [this.clippingPlane] : [],
      });

      const dieMesh = new THREE.Mesh(dieGeo, dieMat);
      const dieCenterY = currentY + dieThickness / 2;
      dieMesh.position.set(0, dieCenterY, 0);
      dieMesh.castShadow = true;
      dieMesh.receiveShadow = true;
      dieMesh.userData = {
        name: dieName,
        dieIndex: d,
        isDie: true,
      };

      this.dieMeshes.push({
        mesh: dieMesh,
        dieIndex: d,
        basePosY: dieCenterY,
      });
      this.stackGroup.add(dieMesh);

      currentY += dieThickness;
    }

    // 4. Top Thermal Interface Material (TIM) & Heat Spreader
    const timThick = 0.15;
    const timGeo = new THREE.BoxGeometry(dieLen * 1.05, timThick, dieWid * 1.05);
    const timMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8, // Metallic thermal grease / indium foil
      metalness: 0.8,
      roughness: 0.4,
      clippingPlanes: this.crossSectionCut ? [this.clippingPlane] : [],
    });
    const timMesh = new THREE.Mesh(timGeo, timMat);
    timMesh.position.set(0, currentY + timThick / 2, 0);
    timMesh.userData = { name: 'Top Thermal Interface Material (TIM-1)' };
    this.stackGroup.add(timMesh);

    // 5. Through-Silicon Vias (TSVs) - Rendered via InstancedMesh
    this.buildTSVInstancedMesh(profile, currentY - intPosY);
  }

  /**
   * Builds high-performance InstancedMesh for thousands of TSV copper pillars.
   */
  private buildTSVInstancedMesh(profile: HBMProfile, totalStackHeight: number): void {
    if (this.tsvInstancedMesh) {
      this.stackGroup.remove(this.tsvInstancedMesh);
      this.tsvInstancedMesh.geometry.dispose();
      (this.tsvInstancedMesh.material as THREE.Material).dispose();
      this.tsvInstancedMesh = null;
    }

    const tsvList = this.simulator.state().tsvs;
    this.tsvDataList = tsvList;
    const count = tsvList.length;

    const tsvRadius = 0.045; // mm (visual scale)
    const tsvHeight = totalStackHeight * 0.95;
    const tsvGeo = new THREE.CylinderGeometry(tsvRadius, tsvRadius, tsvHeight, 8);
    const tsvMat = new THREE.MeshStandardMaterial({
      color: 0xb87333, // Copper standard
      metalness: 0.85,
      roughness: 0.2,
      clippingPlanes: this.crossSectionCut ? [this.clippingPlane] : [],
    });

    this.tsvInstancedMesh = new THREE.InstancedMesh(tsvGeo, tsvMat, count);
    this.tsvInstancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.tsvBasePosY = tsvHeight / 2 + 0.95;

    for (let i = 0; i < count; i++) {
      const node = tsvList[i];
      this._mat4.makeTranslation(node.xMm, this.tsvBasePosY, node.zMm);
      this.tsvInstancedMesh.setMatrixAt(i, this._mat4);
      this.tsvInstancedMesh.setColorAt(i, this.getTSVColor(node));
    }

    this.tsvInstancedMesh.instanceMatrix.needsUpdate = true;
    if (this.tsvInstancedMesh.instanceColor) {
      this.tsvInstancedMesh.instanceColor.needsUpdate = true;
    }
    this.tsvInstancedMesh.userData = { isTSVArray: true };

    this.stackGroup.add(this.tsvInstancedMesh);
  }

  /**
   * Maps TSV status to appropriate visual color (Copper, High-R warning, Open-circuit failure, or Activity pulse).
   */
  private getTSVColor(node: TSVNode): THREE.Color {
    if (node.fault === 'open') {
      return this._color.setHex(0xef4444); // Bright Red Open Circuit
    }
    if (node.fault === 'high_r') {
      return this._color.setHex(0xf59e0b); // Amber High Resistance
    }
    if (node.fault === 'rerouted') {
      return this._color.setHex(0x10b981); // Emerald Redundant Lane
    }
    if (node.activePulse > 0.1) {
      return this._color.setRGB(0.2, 0.9, 1.0); // Cyan Active Signal Pulse
    }
    // Nominal Copper / Gold
    if (node.signalType === 'CLK') return this._color.setHex(0x38bdf8);
    if (node.signalType === 'CMD') return this._color.setHex(0xa855f7);
    return this._color.setHex(0xb87333); // Copper
  }

  /**
   * Updates die mesh colors according to calibrated thermal scale.
   */
  private updateDieTemperatures(dies: DieThermalState[]): void {
    if (!this.showHeatmap) {
      // Revert to silicon neutral colors
      for (const item of this.dieMeshes) {
        const mat = item.mesh.material as THREE.MeshStandardMaterial;
        mat.color.setHex(item.dieIndex === 0 ? 0x1e3a5f : 0x2563eb);
      }
      return;
    }

    for (const item of this.dieMeshes) {
      const die = dies[item.dieIndex];
      if (!die) continue;
      const mat = item.mesh.material as THREE.MeshStandardMaterial;
      const col = this.getThermalColor(die.temperatureC);
      mat.color.copy(col);
    }
  }

  /**
   * Calibrated scientific colormap (Celsius to RGB):
   * 20C -> Deep Blue, 45C -> Cyan, 65C -> Green, 85C -> Amber/Yellow, 105C+ -> Crimson
   */
  private getThermalColor(tempC: number): THREE.Color {
    const minT = 20.0;
    const maxT = 105.0;
    const u = Math.max(0, Math.min(1, (tempC - minT) / (maxT - minT)));

    if (u < 0.25) {
      // Blue to Cyan
      const t = u / 0.25;
      return this._color.setRGB(0.1, 0.2 + 0.6 * t, 0.8 + 0.2 * t);
    } else if (u < 0.5) {
      // Cyan to Green
      const t = (u - 0.25) / 0.25;
      return this._color.setRGB(0.1 + 0.1 * t, 0.8, 1.0 - 0.8 * t);
    } else if (u < 0.75) {
      // Green to Yellow
      const t = (u - 0.5) / 0.25;
      return this._color.setRGB(0.2 + 0.8 * t, 0.8 + 0.1 * t, 0.2 - 0.2 * t);
    } else {
      // Yellow to Crimson Red
      const t = (u - 0.75) / 0.25;
      return this._color.setRGB(1.0, 0.9 - 0.8 * t, 0.1 - 0.1 * t);
    }
  }

  /**
   * Updates TSV colors and activity pulses in the instanced mesh.
   */
  private updateTSVVisuals(tsvs: TSVNode[]): void {
    if (!this.tsvInstancedMesh || !this.tsvInstancedMesh.instanceColor) return;

    for (let i = 0; i < tsvs.length; i++) {
      const col = this.getTSVColor(tsvs[i]);
      this.tsvInstancedMesh.setColorAt(i, col);
    }
    this.tsvInstancedMesh.instanceColor.needsUpdate = true;
  }

  /**
   * Animation & Render Loop with smooth exponential damping for exploded view.
   */
  private startRenderLoop(): void {
    let lastTime = performance.now();

    const tick = () => {
      const now = performance.now();
      const delta = (now - lastTime) * 1e-3;
      lastTime = now;

      // Smooth damped interpolation for exploded view
      this.explodedSpacing = THREE.MathUtils.damp(
        this.explodedSpacing,
        this.targetExplodedSpacing,
        6.0,
        delta
      );

      // Apply vertical offsets to dies and bump tiers
      for (const item of this.dieMeshes) {
        const offset = item.dieIndex * this.explodedSpacing * 1.8;
        item.mesh.position.y = item.basePosY + offset;
      }

      for (const bump of this.bumpGroups) {
        const offset = bump.tierIndex * this.explodedSpacing * 1.8;
        bump.group.position.y = bump.basePosY + offset;
      }

      if (this.tsvInstancedMesh) {
        this.tsvInstancedMesh.visible = this.showTSVs;
      }

      this.controls.update();
      this.renderer.render(this.scene, this.camera);

      this.animationFrameId = requestAnimationFrame(tick);
    };

    tick();
  }

  // --- UI Interaction Handlers ---
  public setExplodedView(value: number): void {
    this.targetExplodedSpacing = Math.max(0, Math.min(1.0, value));
  }

  public toggleHeatmap(): void {
    this.showHeatmap = !this.showHeatmap;
    this.updateDieTemperatures(this.simulator.state().dies);
  }

  public toggleTSVs(): void {
    this.showTSVs = !this.showTSVs;
  }

  public toggleMicrobumps(): void {
    this.showMicrobumps = !this.showMicrobumps;
    for (const b of this.bumpGroups) {
      b.group.visible = this.showMicrobumps;
    }
  }

  public toggleCrossSection(): void {
    this.crossSectionCut = !this.crossSectionCut;
    this.buildSemiconductorStack();
  }

  public setCameraPreset(preset: string): void {
    this.activeCameraPreset = preset;

    switch (preset) {
      case 'iso':
        this.camera.position.set(12, 10, 16);
        this.controls.target.set(0, 1.5, 0);
        break;
      case 'front':
        this.camera.position.set(0, 2.5, 18);
        this.controls.target.set(0, 2.5, 0);
        break;
      case 'top':
        this.camera.position.set(0, 22, 0.1);
        this.controls.target.set(0, 0, 0);
        break;
      case 'side':
        this.camera.position.set(18, 2.5, 0);
        this.controls.target.set(0, 2.5, 0);
        break;
    }
  }

  private onWindowResize = (): void => {
    const container = this.containerRef.nativeElement;
    if (!container) return;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private onPointerMove = (event: MouseEvent): void => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.dieMeshes.map((d) => d.mesh));

    if (intersects.length > 0) {
      const topHit = intersects[0].object;
      this.hoveredEntityName = topHit.userData['name'] || '';
    } else {
      this.hoveredEntityName = '';
    }
  };

  private onPointerClick = (event: MouseEvent): void => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.dieMeshes.map((d) => d.mesh));

    if (intersects.length > 0) {
      const hitObj = intersects[0].object;
      const dieIdx = hitObj.userData['dieIndex'];
      if (dieIdx !== undefined) {
        const die = this.simulator.state().dies[dieIdx];
        if (die) {
          this.simulator.selectedEntity.set({
            type: 'die',
            id: dieIdx,
            title: die.name,
            data: {
              name: die.name,
              temperatureC: die.temperatureC,
              peakHotspotC: die.peakHotspotC,
              hotspotCoordinates: `X: ${die.hotspotX.toFixed(2)} mm, Z: ${die.hotspotZ.toFixed(2)} mm`,
              totalPowerW: die.powerWatts.total.toFixed(2),
              backgroundPowerW: die.powerWatts.background.toFixed(2),
              activePowerW: die.powerWatts.active.toFixed(2),
              leakagePowerW: die.powerWatts.leakage.toFixed(2),
            },
          });
        }
      }
    }
  };
}
