import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';
import { SyntheticDataService } from '../../services/synthetic-data';

@Component({
  selector: 'app-gis-map-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- GIS Map Header -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-sky-950 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <mat-icon class="text-xl">map</mat-icon>
          </div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Statewide Railway GIS Engine</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>California State Rail Plan Digital Model</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">SYNTHETIC NETWORK</span>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-[11px] text-zinc-400">CRS: <strong class="text-white">California Teale Albers (EPSG:3310) / WGS84</strong></span>
        </div>
      </div>

      <!-- GIS Vector Map Canvas & Regions -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1 & 2: Statewide Interactive Map View (SVG) -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-emerald-400">explore</mat-icon> STATEWIDE RAILWAY CORRIDOR NETWORK
            </span>
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-zinc-400">Scale: 1:1,000,000</span>
            </div>
          </div>

          <!-- Scaled California Rail Network Map SVG -->
          <div class="w-full h-96 bg-zinc-950 border border-white/10 rounded-lg relative overflow-hidden p-2 flex items-center justify-center">
            <svg viewBox="0 0 500 450" class="w-full h-full">
              <!-- California Coastline / Border Path -->
              <path 
                d="M 120,20 L 260,20 L 260,180 L 400,340 L 420,420 L 300,420 L 260,380 L 190,320 L 130,240 L 100,160 L 90,80 Z" 
                fill="#18222d" 
                stroke="#334155" 
                stroke-width="1.5" />

              <!-- Mountain Ranges / Sierra Nevada Ridge -->
              <path d="M 230,50 Q 250,150 280,240 T 360,340" fill="none" stroke="#2e3846" stroke-dasharray="3" stroke-width="2" />

              <!-- High-Speed Spine (Merced -> Fresno -> Bakersfield) -->
              <path 
                d="M 170,160 L 205,195 L 240,260" 
                fill="none" 
                stroke="#ef4444" 
                stroke-width="4" 
                stroke-linecap="round" />

              <!-- Northern California Network (Sacramento, Oakland, SF, San Jose) -->
              <path d="M 160,100 L 170,160" fill="none" stroke="#38bdf8" stroke-width="2.5" />
              <path d="M 120,130 L 140,165" fill="none" stroke="#38bdf8" stroke-width="2.5" />
              <path d="M 160,100 L 120,130" fill="none" stroke="#38bdf8" stroke-width="2.5" />

              <!-- Southern California Network (LA, Anaheim, San Diego, Palmdale) -->
              <path d="M 240,260 L 275,300 L 290,340" fill="none" stroke="#fbbf24" stroke-width="2.5" stroke-dasharray="4" />
              <path d="M 290,340 L 320,360 L 340,410" fill="none" stroke="#38bdf8" stroke-width="2.5" />

              <!-- Station Nodes -->
              <!-- Sacramento -->
              <circle cx="160" cy="100" r="5" fill="#38bdf8" />
              <text x="170" y="104" fill="#cbd5e1" font-size="9" font-weight="bold">Sacramento</text>

              <!-- SF Bay Area -->
              <circle cx="120" cy="130" r="5" fill="#38bdf8" />
              <text x="75" y="134" fill="#cbd5e1" font-size="9">San Francisco</text>

              <!-- San Jose -->
              <circle cx="140" cy="165" r="5" fill="#38bdf8" />
              <text x="80" y="169" fill="#cbd5e1" font-size="9">San Jose</text>

              <!-- Merced -->
              <circle cx="170" cy="160" r="6" fill="#ef4444" />
              <text x="180" y="164" fill="#f87171" font-size="9" font-weight="bold">Merced (HSR)</text>

              <!-- Fresno -->
              <circle cx="205" cy="195" r="6" fill="#ef4444" />
              <text x="215" y="199" fill="#f87171" font-size="9" font-weight="bold">Fresno (HSR Hub)</text>

              <!-- Bakersfield -->
              <circle cx="240" cy="260" r="6" fill="#ef4444" />
              <text x="250" y="264" fill="#f87171" font-size="9" font-weight="bold">Bakersfield (HSR)</text>

              <!-- Palmdale -->
              <circle cx="275" cy="300" r="5" fill="#fbbf24" />
              <text x="285" y="304" fill="#cbd5e1" font-size="9">Palmdale</text>

              <!-- Los Angeles Union Station -->
              <circle cx="290" cy="340" r="6" fill="#38bdf8" />
              <text x="300" y="344" fill="#cbd5e1" font-size="9" font-weight="bold">Los Angeles</text>

              <!-- San Diego -->
              <circle cx="340" cy="410" r="5" fill="#38bdf8" />
              <text x="350" y="414" fill="#cbd5e1" font-size="9">San Diego</text>
            </svg>

            <!-- Map Legend -->
            <div class="absolute bottom-3 left-3 bg-zinc-900/90 backdrop-blur border border-white/10 p-2.5 rounded-lg text-[10px] space-y-1">
              <div class="flex items-center gap-2"><span class="w-3 h-1 bg-red-500"></span> Central Valley Core HSR (Under Construction)</div>
              <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-sky-400"></span> Existing Intercity & Commuter Corridors</div>
              <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-amber-400 stroke-dasharray"></span> Planned High-Speed Phase 2 Extensions</div>
            </div>
          </div>
        </div>

        <!-- Col 3: California Regions & Corridors -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3 font-mono">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">list_alt</mat-icon> CALIFORNIA REGIONAL CORRIDORS
            </span>
          </div>

          <div class="space-y-3">
            @for (reg of syntheticData.californiaRegions; track reg.name) {
              <div class="p-3 rounded-lg bg-zinc-800/70 border border-white/5 space-y-1.5">
                <div class="font-bold text-white text-xs flex items-center justify-between">
                  <span>{{ reg.name }}</span>
                  <span class="text-[9px] px-1.5 py-0.5 rounded bg-zinc-700 text-zinc-300">{{ reg.nodes.length }} Nodes</span>
                </div>
                <div class="text-[10px] text-zinc-400">
                  @for (cor of reg.corridors; track cor) {
                    <div>• {{ cor }}</div>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class GisMapViewComponent {
  readonly state = inject(CaltrackState);
  readonly syntheticData = inject(SyntheticDataService);
}
