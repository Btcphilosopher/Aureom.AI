import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-reports-export-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- Header Banner -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-blue-950 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <mat-icon class="text-xl">description</mat-icon>
          </div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Engineering Documentation & BIM Exporter</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>BIM IFC 4x3 Infrastructure & Report Generator</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">AUDIT READY</span>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="downloadCSV()"
            class="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/10 font-bold flex items-center gap-1 transition">
            <mat-icon class="text-sm text-emerald-400">download</mat-icon> Export CSV Table
          </button>
          <button 
            (click)="downloadGeoJSON()"
            class="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/10 font-bold flex items-center gap-1 transition">
            <mat-icon class="text-sm text-sky-400">download</mat-icon> Export GeoJSON
          </button>
          <button 
            (click)="downloadIFC()"
            class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1 transition shadow">
            <mat-icon class="text-sm">download</mat-icon> Export IFC 4x3 (BIM)
          </button>
        </div>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1 & 2: Project Design Report Preview -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-5 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <div class="text-[10px] text-zinc-400 uppercase font-bold">STATE OF CALIFORNIA • HIGH-SPEED RAIL AUTHORITY</div>
              <div class="text-base font-bold text-white">PROJECT DESIGN & ENGINEERING CRITERIA REPORT</div>
            </div>
            <div class="text-right text-[11px] text-zinc-400">
              <div>Doc Ref: <strong class="text-zinc-200">CALTRACK-ENG-2026-R04</strong></div>
              <div>Revision: <strong class="text-emerald-400">{{ state.projectVersion() }}</strong></div>
            </div>
          </div>

          <!-- Executive Summary Section -->
          <div class="space-y-2 text-zinc-300 leading-relaxed font-sans text-xs">
            <div class="font-mono text-zinc-100 font-bold uppercase text-[11px]">1. Executive Summary & Corridor Alignment</div>
            <p>
              The Central Valley North-South High-Speed Spine spans 250.0 route-km (500 track-km) from Merced Regional Terminal to Bakersfield Central Station. The alignment is engineered for double-track electrified passenger operations at maximum design speeds up to 350 km/h, utilizing standard 1,435 mm gauge with continuous welded 136 RE rail on prestressed concrete monoblock sleepers.
            </p>
            <p>
              The vertical alignment incorporates a maximum gradient of 1.85% through the Fresno Trench cut-and-cover section, with high-speed crest curves designed with a minimum K-value of 312 m/% to limit vertical centrifugal acceleration to below 0.05g.
            </p>
          </div>

          <!-- Engineering Summary Stats Table -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 font-mono">
            <div class="p-2.5 rounded bg-zinc-950 border border-white/5">
              <div class="text-[10px] text-zinc-400">Route / Track Length:</div>
              <div class="font-bold text-white text-xs">250 km / 500 km</div>
            </div>
            <div class="p-2.5 rounded bg-zinc-950 border border-white/5">
              <div class="text-[10px] text-zinc-400">Civil Structures:</div>
              <div class="font-bold text-white text-xs">47 (41 Brg, 6 Tun)</div>
            </div>
            <div class="p-2.5 rounded bg-zinc-950 border border-white/5">
              <div class="text-[10px] text-zinc-400">Earthworks Cut/Fill:</div>
              <div class="font-bold text-amber-400 text-xs">12.8M m³ (Net +281k)</div>
            </div>
            <div class="p-2.5 rounded bg-zinc-950 border border-white/5">
              <div class="text-[10px] text-zinc-400">CapEx Cost:</div>
              <div class="font-bold text-emerald-400 text-xs">$18.42B USD</div>
            </div>
          </div>

          <!-- Design Checks Provenance Statement -->
          <div class="p-3 rounded-lg bg-zinc-950 border border-white/5 text-[11px] text-zinc-400 space-y-1">
            <div class="font-bold text-zinc-200 flex items-center gap-1">
              <mat-icon class="text-xs text-emerald-400">verified</mat-icon>
              Engineering Standards Traceability Statement
            </div>
            <p>
              Design calculations have been evaluated against California High-Speed Rail Technical Memoranda (TM 2.1.2, TM 2.1.3), AREMA Manual for Railway Engineering (Chapter 5), and Caltrans Highway Design Manual (Chapter 800). 842 checks verified pass, 21 items under peer review.
            </p>
          </div>
        </div>

        <!-- Col 3: BIM / IFC Object Registry & GUID Tracking -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3 font-mono">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">view_in_ar</mat-icon> BIM IFC OBJECTS & GUIDs
            </span>
            <span class="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300">IFC 4x3</span>
          </div>

          <div class="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            @for (bim of state.bimObjects(); track bim.guid) {
              <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 space-y-1 text-[11px]">
                <div class="flex items-center justify-between">
                  <span class="text-[10px] font-bold px-1.5 py-0.2 rounded bg-zinc-700 text-zinc-200">{{ bim.ifcClass }}</span>
                  <span class="text-[9px] font-bold px-1 py-0.2 rounded" [class.bg-emerald-900]="bim.versionChangeStatus === 'UNCHANGED'" [class.text-emerald-300]="bim.versionChangeStatus === 'UNCHANGED'" [class.bg-amber-900]="bim.versionChangeStatus === 'MODIFIED'" [class.text-amber-300]="bim.versionChangeStatus === 'MODIFIED'" [class.bg-sky-900]="bim.versionChangeStatus === 'ADDED'" [class.text-sky-300]="bim.versionChangeStatus === 'ADDED'">
                    {{ bim.versionChangeStatus }}
                  </span>
                </div>
                <div class="font-bold text-white">{{ bim.elementName }}</div>
                <div class="text-[10px] text-zinc-400 font-mono">GUID: {{ bim.guid }}</div>
                <div class="text-[10px] text-zinc-400">Range: {{ bim.chainageRange }} | Material: {{ bim.material }}</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class ReportsExportViewComponent {
  readonly state = inject(CaltrackState);

  downloadCSV() {
    const elems = this.state.alignmentElements();
    let csv = 'ID,Name,Type,StartChainage,EndChainage,Radius_m,AppliedCant_mm,CantDeficiency_mm,DesignSpeed_kmh,Bearing_deg\n';
    elems.forEach(el => {
      csv += `${el.id},"${el.name}",${el.type},${el.startChainage},${el.endChainage},${el.radius},${el.cantMm},${el.cantDeficiencyMm},${el.designSpeedKmh},${el.bearingDeg}\n`;
    });
    this.triggerDownload('caltrack_alignment_elements.csv', csv, 'text/csv');
  }

  downloadGeoJSON() {
    const elems = this.state.alignmentElements();
    const geojson = {
      type: 'FeatureCollection',
      name: 'CALTRACK_Central_Valley_Corridor',
      crs: { type: 'name', properties: { name: 'urn:ogc:def:crs:OGC:1.3:CRS84' } },
      features: elems.map(el => ({
        type: 'Feature',
        properties: {
          id: el.id,
          name: el.name,
          type: el.type,
          startChainage: el.startChainage,
          endChainage: el.endChainage,
          designSpeedKmh: el.designSpeedKmh
        },
        geometry: {
          type: 'LineString',
          coordinates: [
            [-120.478 + (el.startChainage / 250000) * 1.46, 37.306 - (el.startChainage / 250000) * 1.93],
            [-120.478 + (el.endChainage / 250000) * 1.46, 37.306 - (el.endChainage / 250000) * 1.93]
          ]
        }
      }))
    };
    this.triggerDownload('caltrack_corridor.geojson', JSON.stringify(geojson, null, 2), 'application/json');
  }

  downloadIFC() {
    const bimData = {
      project: 'CALTRACK_California_High_Speed_Rail',
      schema: 'IFC4X3_ADD2',
      author: 'CALTRACK Civil Engineering Digital Twin',
      units: 'METRIC_SI',
      objects: this.state.bimObjects(),
      alignment: this.state.alignmentElements()
    };
    this.triggerDownload('caltrack_bim_model_ifc4x3.json', JSON.stringify(bimData, null, 2), 'application/json');
  }

  private triggerDownload(filename: string, content: string, mimeType: string) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
