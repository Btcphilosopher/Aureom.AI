import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  AfterViewInit, 
  ViewChild, 
  inject, 
  signal,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';
import { EngineeringCalculations } from '../../services/engineering-calculations';

@Component({
  selector: 'app-alignment-designer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col lg:flex-row overflow-hidden select-none">
      <!-- Left: Interactive CAD Plan View Canvas -->
      <div class="flex-1 h-full flex flex-col border-r border-white/10 relative">
        <!-- Canvas Toolbar -->
        <div class="h-10 bg-zinc-900 border-b border-white/10 px-4 flex items-center justify-between text-xs font-mono">
          <div class="flex items-center gap-3 text-zinc-300">
            <span class="font-bold text-sky-400 flex items-center gap-1">
              <mat-icon class="text-sm">architecture</mat-icon> HORIZONTAL ALIGNMENT CAD
            </span>
            <span class="text-zinc-500">|</span>
            <span>CRS: EPSG:6420 (CA State Plane Zone IV)</span>
          </div>

          <div class="flex items-center gap-2">
            <button (click)="resetView()" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition">Reset Extents</button>
            <button (click)="toggleGrid()" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition">Grid: {{ showGrid() ? 'ON' : 'OFF' }}</button>
          </div>
        </div>

        <!-- Canvas -->
        <div #cadContainer class="flex-1 w-full h-full relative overflow-hidden bg-zinc-950 cad-grid">
          <canvas 
            #cadCanvas 
            class="w-full h-full cad-crosshair cursor-grab active:cursor-grabbing"
            (mousedown)="onMouseDown($event)"
            (mousemove)="onMouseMove($event)"
            (mouseup)="onMouseUp()"
            (wheel)="onWheel($event)"></canvas>

          <!-- On-Canvas HUD / Legend -->
          <div class="absolute bottom-3 left-3 bg-zinc-900/90 backdrop-blur border border-white/10 p-2.5 rounded-lg text-[11px] font-mono space-y-1 z-10">
            <div class="text-zinc-400 font-bold uppercase text-[10px]">Element Legend</div>
            <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-emerald-400"></span> Tangent Track</div>
            <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-amber-400"></span> Circular Curve (R=5000-8000m)</div>
            <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-purple-400"></span> Spiral Clothoid Transition</div>
            <div class="flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-red-500"></span> Stationing PI Node</div>
          </div>
        </div>
      </div>

      <!-- Right: Alignment Geometry & Curve Recalculator Panel -->
      <div class="w-full lg:w-96 h-full bg-zinc-900/95 border-l border-white/10 p-4 flex flex-col overflow-y-auto text-xs z-10 shadow-2xl font-mono">
        <div class="flex items-center justify-between pb-2 border-b border-white/10 mb-3">
          <span class="font-bold text-zinc-100 flex items-center gap-1.5">
            <mat-icon class="text-sm text-sky-400">tune</mat-icon> GEOMETRIC CALCULATOR
          </span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold border border-sky-500/30">AREMA CH. 5</span>
        </div>

        @if (selectedElem(); as el) {
          <div class="space-y-4">
            <!-- Header Card -->
            <div class="p-3 rounded-lg bg-zinc-800/80 border border-white/5 space-y-1">
              <div class="text-[10px] text-zinc-400 uppercase">{{ el.type }} ELEMENT ({{ el.id }})</div>
              <div class="text-sm font-bold text-white">{{ el.name }}</div>
              <div class="text-sky-400 text-[11px]">
                Stationing: {{ state.formatStationing(el.startChainage) }} → {{ state.formatStationing(el.endChainage) }} ({{ state.formatDistance(el.length) }})
              </div>
            </div>

            <!-- Interactive Parametric Sliders (Live Recalculation) -->
            @if (el.type === 'CIRCULAR_CURVE' || el.type === 'SPIRAL_CLOTHOID') {
              <div class="space-y-3 p-3 rounded-lg bg-zinc-950 border border-white/10">
                <div class="font-bold text-amber-300 flex items-center justify-between">
                  <span>Curve Parameters</span>
                  <span class="text-[10px] text-zinc-500 font-normal">Live Dynamic Recompute</span>
                </div>

                <!-- Radius Slider -->
                <div>
                  <div class="flex justify-between text-zinc-300 mb-1">
                    <span>Curve Radius (R):</span>
                    <span class="font-bold text-white">{{ el.radius }} m</span>
                  </div>
                  <input 
                    type="range" 
                    min="3500" 
                    max="10000" 
                    step="100" 
                    [value]="el.radius" 
                    (input)="onRadiusSliderChange($event, el.id)"
                    class="w-full accent-amber-500 cursor-pointer">
                </div>

                <!-- Applied Cant (Ea) -->
                <div>
                  <div class="flex justify-between text-zinc-300 mb-1">
                    <span>Applied Superelevation (Ea):</span>
                    <span class="font-bold text-amber-400">{{ el.cantMm }} mm</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="160" 
                    step="5" 
                    [value]="el.cantMm" 
                    (input)="onCantSliderChange($event, el.id)"
                    class="w-full accent-amber-500 cursor-pointer">
                </div>

                <!-- Design Speed -->
                <div>
                  <div class="flex justify-between text-zinc-300 mb-1">
                    <span>Target Design Speed (V):</span>
                    <span class="font-bold text-emerald-400">{{ el.designSpeedKmh }} km/h</span>
                  </div>
                  <input 
                    type="range" 
                    min="200" 
                    max="350" 
                    step="10" 
                    [value]="el.designSpeedKmh" 
                    (input)="onSpeedSliderChange($event, el.id)"
                    class="w-full accent-emerald-500 cursor-pointer">
                </div>
              </div>
            }

            <!-- Calculated Engineering Results Breakdown -->
            <div class="space-y-2 p-3 rounded-lg bg-zinc-800/40 border border-white/5">
              <div class="text-[10px] text-zinc-400 uppercase font-bold">Calculation Breakdown</div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Equilibrium Cant (E_eq):</span>
                <span class="font-bold text-white">{{ ((11.8 * el.designSpeedKmh * el.designSpeedKmh) / Math.max(1, el.radius)).toFixed(1) }} mm</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Cant Deficiency (Ed):</span>
                <span class="font-bold" [class.text-emerald-400]="el.cantDeficiencyMm <= 80" [class.text-red-400]="el.cantDeficiencyMm > 80">
                  {{ el.cantDeficiencyMm }} mm (Limit: 80 mm)
                </span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Transition Spiral (Ls):</span>
                <span class="text-sky-300 font-bold">{{ el.transitionSpiralLength }} m</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Rate of Cant Change (da/dt):</span>
                <span class="text-white">{{ el.rateOfCantChangeMmS }} mm/s (Limit: 35 mm/s)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Bearing:</span>
                <span class="text-zinc-300">{{ el.bearingDeg }}°</span>
              </div>
            </div>

            <!-- Provenance / Governing Formula -->
            <div class="p-3 rounded-lg bg-zinc-950 border border-white/10 text-zinc-400 space-y-1 text-[11px]">
              <div class="text-zinc-300 font-bold flex items-center gap-1">
                <mat-icon class="text-xs text-amber-400">functions</mat-icon> Governing Equation
              </div>
              <p class="font-mono text-amber-300">V_max = sqrt((R * (Ea + Ed)) / 11.8)</p>
              <p class="text-[10px] text-zinc-500">Source: CHSR Technical Memorandum TM 2.1.2 & AREMA Ch 5</p>
            </div>
          </div>
        }

        <!-- Alignment Elements Table -->
        <div class="mt-4 pt-3 border-t border-white/10 space-y-2">
          <div class="font-bold text-zinc-300 uppercase text-[10px]">Alignment Elements Sequence</div>
          <div class="space-y-1">
            @for (item of state.alignmentElements(); track item.id) {
              <button 
                (click)="state.selectAlignmentElement(item.id); drawCanvas()"
                [class.bg-sky-950]="state.selectedAlignmentId() === item.id"
                [class.border-sky-500]="state.selectedAlignmentId() === item.id"
                [class.bg-zinc-800]="state.selectedAlignmentId() !== item.id"
                class="w-full text-left p-2 rounded border border-white/5 hover:bg-zinc-700/60 transition flex items-center justify-between cursor-pointer">
                <div>
                  <div class="font-bold text-zinc-200">{{ item.name }}</div>
                  <div class="text-[10px] text-zinc-400">{{ state.formatStationing(item.startChainage) }} | R={{ item.radius > 0 ? item.radius + 'm' : 'Tangent' }}</div>
                </div>
                <span class="text-[10px] font-bold text-emerald-400">{{ item.designSpeedKmh }} km/h</span>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class AlignmentDesignerComponent implements AfterViewInit {
  @ViewChild('cadCanvas', { static: true }) cadCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('cadContainer', { static: true }) cadContainerRef!: ElementRef<HTMLDivElement>;

  readonly state = inject(CaltrackState);
  readonly engCalc = inject(EngineeringCalculations);
  private platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);
  readonly Math = Math;

  readonly showGrid = signal(true);
  readonly selectedElem = this.state.selectedAlignmentElement;

  private ctx!: CanvasRenderingContext2D;
  private panX = 120;
  private panY = 280;
  private scale = 0.00035;
  private isDragging = false;
  private startMouseX = 0;
  private startMouseY = 0;

  ngAfterViewInit() {
    if (!this.isBrowser) return;
    const canvas = this.cadCanvasRef.nativeElement;
    this.ctx = canvas.getContext('2d')!;
    this.resizeCanvas();
    window.addEventListener('resize', () => {
      this.resizeCanvas();
      this.drawCanvas();
    });
    this.drawCanvas();
  }

  resizeCanvas() {
    const container = this.cadContainerRef.nativeElement;
    const canvas = this.cadCanvasRef.nativeElement;
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
  }

  resetView() {
    this.panX = 140;
    this.panY = 260;
    this.scale = 0.00035;
    this.drawCanvas();
  }

  toggleGrid() {
    this.showGrid.update(v => !v);
    this.drawCanvas();
  }

  drawCanvas() {
    const canvas = this.cadCanvasRef.nativeElement;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw Grid Coordinates
    if (this.showGrid()) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      const step = 50;
      for (let x = 0; x < canvas.width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
    }

    // Origin reference
    const originX = 2045000;
    const originY = 650000;

    // Draw Alignment Elements
    const elements = this.state.alignmentElements();
    const selectedId = this.state.selectedAlignmentId();

    elements.forEach(elem => {
      const sx = (elem.startX - originX) * this.scale + this.panX;
      const sy = canvas.height - ((elem.startY - originY) * this.scale + this.panY);
      const ex = (elem.endX - originX) * this.scale + this.panX;
      const ey = canvas.height - ((elem.endY - originY) * this.scale + this.panY);

      ctx.beginPath();
      ctx.lineWidth = elem.id === selectedId ? 5 : 3;

      if (elem.type === 'TANGENT') {
        ctx.strokeStyle = elem.id === selectedId ? '#38bdf8' : '#34d399';
      } else if (elem.type === 'CIRCULAR_CURVE') {
        ctx.strokeStyle = elem.id === selectedId ? '#f59e0b' : '#fbbf24';
      } else {
        ctx.strokeStyle = elem.id === selectedId ? '#c084fc' : '#a855f7';
      }

      ctx.moveTo(sx, sy);
      ctx.lineTo(ex, ey);
      ctx.stroke();

      // Draw Stationing Node
      ctx.fillStyle = elem.id === selectedId ? '#ef4444' : '#64748b';
      ctx.beginPath();
      ctx.arc(sx, sy, elem.id === selectedId ? 6 : 4, 0, Math.PI * 2);
      ctx.fill();

      // Stationing Label
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillText(this.state.formatStationing(elem.startChainage), sx + 8, sy - 4);
    });
  }

  onMouseDown(e: MouseEvent) {
    this.isDragging = true;
    this.startMouseX = e.clientX;
    this.startMouseY = e.clientY;
  }

  onMouseMove(e: MouseEvent) {
    if (!this.isDragging) return;
    const dx = e.clientX - this.startMouseX;
    const dy = e.clientY - this.startMouseY;
    this.startMouseX = e.clientX;
    this.startMouseY = e.clientY;
    this.panX += dx;
    this.panY -= dy;
    this.drawCanvas();
  }

  onMouseUp() {
    this.isDragging = false;
  }

  onWheel(e: WheelEvent) {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.15 : 0.85;
    this.scale = Math.max(0.0001, Math.min(0.005, this.scale * factor));
    this.drawCanvas();
  }

  onRadiusSliderChange(e: Event, id: string) {
    const r = +(e.target as HTMLInputElement).value;
    const el = this.selectedElem();
    if (el) {
      this.state.updateAlignmentCurve(id, r, el.cantMm, el.designSpeedKmh);
      this.drawCanvas();
    }
  }

  onCantSliderChange(e: Event, id: string) {
    const cant = +(e.target as HTMLInputElement).value;
    const el = this.selectedElem();
    if (el) {
      this.state.updateAlignmentCurve(id, el.radius, cant, el.designSpeedKmh);
      this.drawCanvas();
    }
  }

  onSpeedSliderChange(e: Event, id: string) {
    const spd = +(e.target as HTMLInputElement).value;
    const el = this.selectedElem();
    if (el) {
      this.state.updateAlignmentCurve(id, el.radius, el.cantMm, spd);
      this.drawCanvas();
    }
  }
}
