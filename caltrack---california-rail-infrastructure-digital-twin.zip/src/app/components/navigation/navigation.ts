import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState, ActiveTab } from '../../services/caltrack-state';

interface NavItem {
  id: ActiveTab;
  label: string;
  icon: string;
  category: 'CORE' | 'DESIGN' | 'CIVIL' | 'SYSTEMS' | '4D_BUILD' | 'OPS_MAINT' | 'ANALYTICS';
}

@Component({
  selector: 'app-navigation',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <nav class="bg-zinc-900/90 border-b border-white/10 px-2 flex items-center overflow-x-auto scrollbar-none select-none text-xs">
      <div class="flex items-center gap-0.5 py-1.5 min-w-max">
        @for (item of navItems; track item.id) {
          <button
            (click)="state.setActiveTab(item.id)"
            [class.bg-zinc-800]="state.activeTab() === item.id"
            [class.text-white]="state.activeTab() === item.id"
            [class.border-b-2]="state.activeTab() === item.id"
            [class.border-red-500]="state.activeTab() === item.id"
            [class.text-zinc-400]="state.activeTab() !== item.id"
            [class.hover:text-zinc-200]="state.activeTab() !== item.id"
            [class.hover:bg-zinc-800/50]="state.activeTab() !== item.id"
            class="px-2.5 py-1 rounded flex items-center gap-1.5 font-medium transition whitespace-nowrap cursor-pointer">
            <mat-icon class="text-sm opacity-80">{{ item.icon }}</mat-icon>
            <span>{{ item.label }}</span>
          </button>
        }
      </div>
    </nav>
  `
})
export class NavigationComponent {
  readonly state = inject(CaltrackState);

  readonly navItems: NavItem[] = [
    { id: 'DIGITAL_TWIN', label: '3D Digital Twin', icon: 'view_in_ar', category: 'CORE' },
    { id: 'ALIGNMENT', label: 'Alignment (CAD)', icon: 'timeline', category: 'DESIGN' },
    { id: 'TRACK', label: 'Vertical & Cross-Section', icon: 'splitscreen', category: 'DESIGN' },
    { id: 'TERRAIN', label: 'Terrain & Geotech', icon: 'terrain', category: 'CIVIL' },
    { id: 'EARTHWORKS', label: 'Earthworks / Mass-Haul', icon: 'landslide', category: 'CIVIL' },
    { id: 'STRUCTURES', label: 'Structures & Tunnels', icon: 'account_balance', category: 'CIVIL' },
    { id: 'STATIONS', label: 'Stations & Track', icon: 'corporate_fare', category: 'DESIGN' },
    { id: 'TURNOUTS', label: 'Turnouts & Crossovers', icon: 'call_split', category: 'DESIGN' },
    { id: 'SIGNALLING', label: 'Signalling / PTC', icon: 'traffic', category: 'SYSTEMS' },
    { id: 'ELECTRIFICATION', label: 'Electrification (25kV)', icon: 'electric_bolt', category: 'SYSTEMS' },
    { id: 'CONSTRUCTION', label: '4D Construction Sim', icon: 'engineering', category: '4D_BUILD' },
    { id: 'SIMULATION', label: 'Train Dynamics & Capacity', icon: 'speed', category: 'OPS_MAINT' },
    { id: 'INSPECTION', label: 'Track Inspection (EM120)', icon: 'troubleshoot', category: 'OPS_MAINT' },
    { id: 'COST', label: 'Cost & Schedule (CapEx)', icon: 'paid', category: 'ANALYTICS' },
    { id: 'GIS', label: 'California GIS Map', icon: 'map', category: 'CORE' },
    { id: 'PROVENANCE', label: 'Engineering Rules & Audit', icon: 'verified', category: 'ANALYTICS' },
    { id: 'REPORTS', label: 'BIM / IFC & Reports', icon: 'description', category: 'ANALYTICS' }
  ];
}
