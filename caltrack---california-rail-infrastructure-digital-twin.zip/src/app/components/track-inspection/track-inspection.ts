import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-track-inspection',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- Inspection Toolbar & Inject Defect Action Bar -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-sky-950 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <mat-icon class="text-xl">troubleshoot</mat-icon>
          </div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Track Geometry Recording Car</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>EM-120 Virtual Laser Inspection Vehicle</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">FRA CLASS 9 HSR</span>
            </div>
          </div>
        </div>

        <!-- Defect Injection Controls (Prompt Step 9 & 10) -->
        <div class="flex items-center gap-2">
          <button 
            (click)="state.injectTrackDefectAtMP184()"
            class="px-3.5 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold flex items-center gap-1.5 transition shadow-lg shadow-red-900/30 cursor-pointer">
            <mat-icon class="text-sm">error</mat-icon>
            <span>Inject Track Defect at MP 184.2</span>
          </button>
        </div>
      </div>

      <!-- Geometry Strip Charts & Heatmap -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1 & 2: Multi-Channel Geometry Strip Chart (SVG) -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">analytics</mat-icon> MULTI-CHANNEL GEOMETRY RECORDING STRIP CHART
            </span>
            <span class="text-zinc-400 text-[11px]">Chainage: 180+000 → 190+000 (Wasco Sub)</span>
          </div>

          <!-- Strip Charts -->
          <div class="space-y-3 p-3 rounded-lg bg-zinc-950 border border-white/10">
            <!-- Channel 1: Gauge (1435mm) -->
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-zinc-400 font-bold">1. Track Gauge (Nominal 1435.0 mm):</span>
                <span class="text-red-400 font-bold">Peak: 1438.4 mm (+3.4mm at MP 184.2)</span>
              </div>
              <div class="w-full h-10 bg-zinc-900 rounded border border-white/5 relative overflow-hidden flex items-center">
                <!-- Center Nominal line -->
                <div class="w-full h-px bg-white/20 absolute"></div>
                <!-- Warning threshold lines (+/- 2mm) -->
                <div class="w-full h-px bg-amber-500/40 absolute top-2"></div>
                <div class="w-full h-px bg-amber-500/40 absolute bottom-2"></div>
                <!-- Continuous waveform with spike -->
                <svg viewBox="0 0 500 40" class="w-full h-full absolute">
                  <path d="M 0,20 Q 50,19 100,20 T 200,21 T 250,5 T 300,20 T 400,19 T 500,20" fill="none" stroke="#ef4444" stroke-width="2" />
                  <!-- Defect point marker -->
                  <circle cx="250" cy="5" r="4" fill="#ef4444" />
                </svg>
              </div>
            </div>

            <!-- Channel 2: Cross-Level (mm) -->
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-zinc-400 font-bold">2. Cross-Level Deviation (Limit ±2.0 mm):</span>
                <span class="text-amber-400 font-bold">Peak: +2.4 mm</span>
              </div>
              <div class="w-full h-10 bg-zinc-900 rounded border border-white/5 relative overflow-hidden flex items-center">
                <div class="w-full h-px bg-white/20 absolute"></div>
                <svg viewBox="0 0 500 40" class="w-full h-full absolute">
                  <path d="M 0,20 Q 60,21 120,19 T 240,12 T 260,28 T 350,20 T 500,20" fill="none" stroke="#f59e0b" stroke-width="2" />
                </svg>
              </div>
            </div>

            <!-- Channel 3: 3m Twist (mm/m) -->
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-zinc-400 font-bold">3. 3-Meter Base Twist (Limit 2.5 mm/m):</span>
                <span class="text-emerald-400 font-bold">Peak: 1.8 mm/m (PASS)</span>
              </div>
              <div class="w-full h-10 bg-zinc-900 rounded border border-white/5 relative overflow-hidden flex items-center">
                <div class="w-full h-px bg-white/20 absolute"></div>
                <svg viewBox="0 0 500 40" class="w-full h-full absolute">
                  <path d="M 0,20 Q 80,18 160,22 T 250,15 T 380,21 T 500,20" fill="none" stroke="#10b981" stroke-width="2" />
                </svg>
              </div>
            </div>

            <!-- Channel 4: Vertical Profile Top -->
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-zinc-400 font-bold">4. Vertical Profile Top (Limit ±2.0 mm):</span>
                <span class="text-red-400 font-bold">Peak: +3.2 mm</span>
              </div>
              <div class="w-full h-10 bg-zinc-900 rounded border border-white/5 relative overflow-hidden flex items-center">
                <div class="w-full h-px bg-white/20 absolute"></div>
                <svg viewBox="0 0 500 40" class="w-full h-full absolute">
                  <path d="M 0,20 Q 70,22 140,18 T 250,33 T 360,19 T 500,20" fill="none" stroke="#ef4444" stroke-width="2" />
                </svg>
              </div>
            </div>
          </div>

          <!-- Highlight Defect Card at MP 184.2 -->
          <div class="p-4 rounded-xl bg-red-950/40 border border-red-500/50 space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-extrabold text-red-300 text-sm flex items-center gap-1.5">
                <mat-icon class="text-base text-red-400">warning</mat-icon> DEFECT DETECTION: MILEPOST 184.2 (CH 184+200)
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-red-900 text-red-200 font-bold uppercase">Condition: Intervention Required</span>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              <div class="p-2 rounded bg-zinc-900 border border-white/5">
                <div class="text-[10px] text-zinc-400">Gauge Variation:</div>
                <div class="text-sm font-bold text-red-400">+3.4 mm</div>
              </div>
              <div class="p-2 rounded bg-zinc-900 border border-white/5">
                <div class="text-[10px] text-zinc-400">Cross-Level:</div>
                <div class="text-sm font-bold text-amber-400">+2.4 mm</div>
              </div>
              <div class="p-2 rounded bg-zinc-900 border border-white/5">
                <div class="text-[10px] text-zinc-400">Vertical Top:</div>
                <div class="text-sm font-bold text-red-400">+3.2 mm</div>
              </div>
              <div class="p-2 rounded bg-zinc-900 border border-white/5">
                <div class="text-[10px] text-zinc-400">TQI Status:</div>
                <div class="text-sm font-bold text-amber-400">REVIEW</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Col 3: Work Orders & Asset Maintenance Dispatch (Step 10) -->
        <div class="space-y-4">
          <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-white/10">
              <span class="font-bold text-zinc-100 flex items-center gap-1.5">
                <mat-icon class="text-sm text-amber-400">assignment</mat-icon> AUTOMATED WORK ORDERS
              </span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">ASSET MGMT</span>
            </div>

            <div class="space-y-2">
              @for (defect of state.trackDefects(); track defect.id) {
                <div class="p-3 rounded-lg border space-y-2" [class.bg-red-950]="!defect.resolved" [class.border-red-500]="!defect.resolved" [class.bg-zinc-800]="defect.resolved" [class.border-white]="defect.resolved">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-white">{{ defect.milepost }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded font-bold" [class.bg-red-900]="!defect.resolved" [class.text-red-200]="!defect.resolved" [class.bg-emerald-900]="defect.resolved" [class.text-emerald-300]="defect.resolved">
                      {{ defect.resolved ? 'CLOSED / REPAIRED' : defect.severity }}
                    </span>
                  </div>

                  <div class="text-[11px] text-zinc-300">
                    <div>Param: <span class="text-amber-300 font-bold">{{ defect.defectParameter }}</span></div>
                    <div>Deviation: <span class="text-red-300 font-bold">{{ defect.deviationMm > 0 ? '+' : '' }}{{ defect.deviationMm }} mm</span></div>
                    @if (defect.workOrderNumber) {
                      <div class="text-sky-400 font-bold mt-1">Work Order: {{ defect.workOrderNumber }}</div>
                    }
                  </div>

                  <p class="text-[10px] text-zinc-400 italic">{{ defect.remedialAction }}</p>

                  @if (!defect.resolved) {
                    <button 
                      (click)="state.resolveDefect(defect.id)"
                      class="w-full py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1 transition shadow cursor-pointer">
                      <mat-icon class="text-sm">build</mat-icon>
                      <span>Dispatch Gang & Complete Repair</span>
                    </button>
                  }
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TrackInspectionComponent {
  readonly state = inject(CaltrackState);
}
