import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';
import { UserRole } from '../../models/engineering.types';

@Component({
  selector: 'app-header',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-14 bg-zinc-900/95 backdrop-blur border-b border-white/10 flex items-center justify-between px-4 z-50 select-none">
      <!-- Left: Logo & California Infrastructure Branding -->
      <div class="flex items-center gap-3">
        <button 
          type="button"
          class="flex items-center gap-2 cursor-pointer bg-transparent border-none text-left p-0 focus:outline-none" 
          (click)="state.setActiveTab('DIGITAL_TWIN')">
          <div class="w-8 h-8 rounded-lg bg-red-700/20 border border-red-500/40 flex items-center justify-center text-red-400 shadow-sm">
            <mat-icon class="text-xl">alt_route</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-1.5">
              <span class="font-extrabold tracking-wider text-base text-zinc-100 font-mono-num">CALTRACK</span>
              <span class="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">Enterprise</span>
            </div>
            <p class="text-[10px] text-zinc-400 tracking-tight leading-none">California Rail Infrastructure Digital Twin & Civil Simulator</p>
          </div>
        </button>

        <div class="h-6 w-px bg-white/10 mx-1 hidden md:block"></div>

        <!-- Corridor & Version Selector -->
        <div class="hidden lg:flex items-center gap-2">
          <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-800/80 border border-white/5 text-xs text-zinc-300">
            <mat-icon class="text-sm text-sky-400">train</mat-icon>
            <span class="font-medium text-zinc-200">Central Valley Spine (Merced–Fresno–Bakersfield)</span>
            <span class="text-[10px] text-zinc-400 font-mono">250 km</span>
          </div>

          <div class="flex items-center gap-1 bg-zinc-800/80 border border-white/5 rounded-md px-2 py-0.5 text-xs">
            <span class="text-[10px] text-zinc-400 uppercase font-mono">Stage:</span>
            <select 
              [value]="state.projectVersion()"
              (change)="onVersionChange($event)"
              class="bg-transparent text-emerald-400 font-mono text-xs focus:outline-none cursor-pointer">
              <option value="PROJECT v0.1" class="bg-zinc-900 text-zinc-200">PROJECT v0.1 (Feasibility)</option>
              <option value="30% DESIGN (Rev 04)" class="bg-zinc-900 text-zinc-200">30% DESIGN (Preliminary Eng)</option>
              <option value="60% DESIGN" class="bg-zinc-900 text-zinc-200">60% DESIGN (Detailed Civil)</option>
              <option value="90% DESIGN" class="bg-zinc-900 text-zinc-200">90% DESIGN (Pre-Final)</option>
              <option value="ISSUED FOR CONSTRUCTION" class="bg-zinc-900 text-zinc-200">ISSUED FOR CONSTRUCTION (IFC)</option>
              <option value="AS-BUILT DIGITAL TWIN" class="bg-zinc-900 text-zinc-200">AS-BUILT DIGITAL TWIN</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Center: End-to-End Demonstration Steps Controller -->
      <div class="hidden xl:flex items-center gap-1 bg-zinc-950/80 border border-white/10 rounded-lg p-1">
        <span class="text-[10px] font-mono uppercase text-zinc-400 px-2 flex items-center gap-1">
          <mat-icon class="text-xs text-amber-400">play_circle</mat-icon> Tour:
        </span>
        <button 
          (click)="runDemoStep(1)" 
          title="Step 1-3: Corridor & 3D Terrain"
          class="px-2 py-1 text-[11px] rounded font-mono hover:bg-zinc-800 text-zinc-300 hover:text-white transition">
          1. 3D Twin
        </button>
        <button 
          (click)="runDemoStep(4)" 
          title="Step 4: Curve & Alignment CAD"
          class="px-2 py-1 text-[11px] rounded font-mono hover:bg-zinc-800 text-zinc-300 hover:text-white transition">
          2. Alignment
        </button>
        <button 
          (click)="runDemoStep(5)" 
          title="Step 5: Vertical Profile"
          class="px-2 py-1 text-[11px] rounded font-mono hover:bg-zinc-800 text-zinc-300 hover:text-white transition">
          3. Profile
        </button>
        <button 
          (click)="runDemoStep(7)" 
          title="Step 7: 4D Construction Simulator"
          class="px-2 py-1 text-[11px] rounded font-mono hover:bg-zinc-800 text-zinc-300 hover:text-white transition">
          4. 4D Build
        </button>
        <button 
          (click)="runDemoStep(8)" 
          title="Step 8: Train Dynamics Simulation"
          class="px-2 py-1 text-[11px] rounded font-mono hover:bg-zinc-800 text-zinc-300 hover:text-white transition">
          5. Operations
        </button>
        <button 
          (click)="runDemoStep(9)" 
          title="Step 9-10: Inject Defect & Work Order"
          class="px-2 py-1 text-[11px] rounded font-mono bg-red-900/30 hover:bg-red-800/40 text-red-300 border border-red-500/30 transition flex items-center gap-1">
          <mat-icon class="text-xs">warning</mat-icon> 6. Defect / Maint
        </button>
      </div>

      <!-- Right: Engineering Checks Badge, Role, Units, Export -->
      <div class="flex items-center gap-2.5">
        <!-- Engineering Checks Pill -->
        <button 
          (click)="state.setActiveTab('PROVENANCE')"
          title="Click to view 879 transparent engineering calculations"
          class="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-800/90 hover:bg-zinc-800 border border-white/10 text-xs font-mono transition">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span class="text-zinc-400">CHECKS:</span>
          <span class="text-emerald-400 font-bold">842 PASS</span>
          <span class="text-amber-400 font-bold">21 REV</span>
          <span class="text-red-400 font-bold">2 FAIL</span>
        </button>

        <!-- Units Selector -->
        <div class="hidden sm:flex items-center bg-zinc-800 rounded-md border border-white/5 p-0.5 text-[11px] font-mono">
          <button 
            (click)="state.setUnitSystem('METRIC_SI')"
            [class.bg-zinc-700]="state.unitSystem() === 'METRIC_SI'"
            [class.text-white]="state.unitSystem() === 'METRIC_SI'"
            [class.text-zinc-400]="state.unitSystem() !== 'METRIC_SI'"
            class="px-2 py-0.5 rounded transition">
            SI
          </button>
          <button 
            (click)="state.setUnitSystem('US_CUSTOMARY')"
            [class.bg-zinc-700]="state.unitSystem() === 'US_CUSTOMARY'"
            [class.text-white]="state.unitSystem() === 'US_CUSTOMARY'"
            [class.text-zinc-400]="state.unitSystem() !== 'US_CUSTOMARY'"
            class="px-2 py-0.5 rounded transition">
            US
          </button>
          <button 
            (click)="state.setUnitSystem('HYBRID_CA')"
            [class.bg-zinc-700]="state.unitSystem() === 'HYBRID_CA'"
            [class.text-white]="state.unitSystem() === 'HYBRID_CA'"
            [class.text-zinc-400]="state.unitSystem() !== 'HYBRID_CA'"
            class="px-2 py-0.5 rounded transition"
            title="Hybrid California Engineering (km/h + ft/m)">
            CAL
          </button>
        </div>

        <!-- Role Selector -->
        <div class="hidden md:flex items-center gap-1 bg-zinc-800/80 border border-white/5 rounded-md px-2 py-1 text-xs">
          <mat-icon class="text-sm text-zinc-400">badge</mat-icon>
          <select 
            [value]="state.currentRole()"
            (change)="onRoleChange($event)"
            class="bg-transparent text-zinc-200 text-xs focus:outline-none cursor-pointer">
            <option value="PROJECT_DIRECTOR" class="bg-zinc-900 text-zinc-200">Project Director</option>
            <option value="RAIL_ENGINEER" class="bg-zinc-900 text-zinc-200">Rail Engineer (PE)</option>
            <option value="TRACK_ENGINEER" class="bg-zinc-900 text-zinc-200">Track Alignment PE</option>
            <option value="CIVIL_ENGINEER" class="bg-zinc-900 text-zinc-200">Civil & Earthworks PE</option>
            <option value="STRUCTURAL_ENGINEER" class="bg-zinc-900 text-zinc-200">Structural Engineer (SE)</option>
            <option value="GEOTECHNICAL_ENGINEER" class="bg-zinc-900 text-zinc-200">Geotechnical (GE)</option>
            <option value="CONSTRUCTION_MANAGER" class="bg-zinc-900 text-zinc-200">Construction Mgr</option>
            <option value="OPERATIONS" class="bg-zinc-900 text-zinc-200">Rail Operations</option>
            <option value="MAINTENANCE" class="bg-zinc-900 text-zinc-200">Track Maintenance</option>
          </select>
        </div>

        <!-- Quick Export Button -->
        <button 
          (click)="state.setActiveTab('REPORTS')"
          class="px-2.5 py-1 rounded-md bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium flex items-center gap-1 transition shadow-sm">
          <mat-icon class="text-sm">file_download</mat-icon>
          <span class="hidden sm:inline">Export</span>
        </button>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly state = inject(CaltrackState);

  onVersionChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.state.setProjectVersion(val);
  }

  onRoleChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value as UserRole;
    this.state.setRole(val);
  }

  runDemoStep(step: number) {
    switch(step) {
      case 1:
        this.state.setActiveTab('DIGITAL_TWIN');
        this.state.setChainagePointer(19150);
        break;
      case 4:
        this.state.setActiveTab('ALIGNMENT');
        this.state.selectAlignmentElement('ALIGN-003'); // San Joaquin River curve
        break;
      case 5:
        this.state.setActiveTab('TRACK');
        break;
      case 7:
        this.state.setActiveTab('CONSTRUCTION');
        this.state.playConstruction();
        break;
      case 8:
        this.state.setActiveTab('SIMULATION');
        this.state.startTrainSim();
        break;
      case 9:
        this.state.setActiveTab('INSPECTION');
        this.state.injectTrackDefectAtMP184();
        break;
    }
  }
}
