import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-train-simulator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- Operational Console Header -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <!-- Train Info & Launch Button -->
        <div class="flex items-center gap-3">
          <button 
            (click)="state.toggleTrainSimulation()"
            class="w-12 h-12 rounded-xl bg-red-600 hover:bg-red-500 text-white flex items-center justify-center transition shadow-lg">
            <mat-icon class="text-2xl">{{ state.isTrainSimRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>

          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Active Train Dynamic Simulator</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>{{ state.activeTrain().trainName }}</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">ETCS L2 ACTIVE</span>
            </div>
          </div>
        </div>

        <!-- Train Fleet Selector -->
        <div class="flex items-center gap-2 flex-wrap">
          <button 
            (click)="switchTrainType('HIGH_SPEED_EMU')"
            [class.bg-red-900]="selectedTrainType() === 'HIGH_SPEED_EMU'"
            [class.border-red-500]="selectedTrainType() === 'HIGH_SPEED_EMU'"
            [class.bg-zinc-800]="selectedTrainType() !== 'HIGH_SPEED_EMU'"
            class="px-3 py-1.5 rounded-lg border border-white/5 text-zinc-200 font-bold transition">
            HSR EMU (350 km/h)
          </button>
          <button 
            (click)="switchTrainType('COMMUTER_BILEVEL')"
            [class.bg-red-900]="selectedTrainType() === 'COMMUTER_BILEVEL'"
            [class.border-red-500]="selectedTrainType() === 'COMMUTER_BILEVEL'"
            [class.bg-zinc-800]="selectedTrainType() !== 'COMMUTER_BILEVEL'"
            class="px-3 py-1.5 rounded-lg border border-white/5 text-zinc-200 font-bold transition">
            Commuter BiLevel (175 km/h)
          </button>
          <button 
            (click)="switchTrainType('HEAVY_FREIGHT_INTERMODAL')"
            [class.bg-red-900]="selectedTrainType() === 'HEAVY_FREIGHT_INTERMODAL'"
            [class.border-red-500]="selectedTrainType() === 'HEAVY_FREIGHT_INTERMODAL'"
            [class.bg-zinc-800]="selectedTrainType() !== 'HEAVY_FREIGHT_INTERMODAL'"
            class="px-3 py-1.5 rounded-lg border border-white/5 text-zinc-200 font-bold transition">
            Freight Double-Stack (14,000t)
          </button>
        </div>
      </div>

      <!-- Main Telemetry & Physics Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1: Driver Cab Instruments & Telemetry Gauges -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-emerald-400">speed</mat-icon> CAB INSTRUMENT PANEL
            </span>
            <span class="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
              <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span> LIVE TELEMETRY
            </span>
          </div>

          <!-- Giant Speedometer Readout -->
          <div class="p-4 rounded-xl bg-zinc-950 border border-white/10 flex flex-col items-center justify-center text-center space-y-1">
            <div class="text-[11px] text-zinc-400 uppercase tracking-widest">Actual Vehicle Speed</div>
            <div class="text-5xl font-extrabold text-emerald-400 tracking-tight">
              {{ state.formatSpeed(state.activeTrain().currentSpeedKmh) }}
            </div>
            <div class="text-xs text-sky-400 font-bold">
              Target ATP: {{ state.formatSpeed(state.activeTrain().targetSpeedKmh) }}
            </div>
          </div>

          <!-- Telemetry Metrics Rows -->
          <div class="space-y-2 text-zinc-300">
            <div class="flex justify-between py-1.5 px-2 rounded bg-zinc-800/60 border border-white/5">
              <span class="text-zinc-400">Stationing Location:</span>
              <span class="font-bold text-sky-400">{{ state.formatStationing(state.activeTrain().currentChainageM) }} (MP {{ (state.activeTrain().currentChainageM * 0.000621371).toFixed(1) }})</span>
            </div>
            <div class="flex justify-between py-1.5 px-2 rounded bg-zinc-800/60 border border-white/5">
              <span class="text-zinc-400">Traction Power Output:</span>
              <span class="font-bold text-amber-400">{{ state.activeTrain().powerOutputMw }} MW</span>
            </div>
            <div class="flex justify-between py-1.5 px-2 rounded bg-zinc-800/60 border border-white/5">
              <span class="text-zinc-400">Tractive Effort / Force:</span>
              <span class="font-bold text-white">{{ state.activeTrain().tractiveForceKn }} kN</span>
            </div>
            <div class="flex justify-between py-1.5 px-2 rounded bg-zinc-800/60 border border-white/5">
              <span class="text-zinc-400">Current Track Gradient:</span>
              <span class="font-bold" [class.text-amber-400]="state.activeTrain().gradientPct > 0" [class.text-sky-400]="state.activeTrain().gradientPct <= 0">
                {{ state.activeTrain().gradientPct > 0 ? '+' : '' }}{{ state.activeTrain().gradientPct }}%
              </span>
            </div>
            <div class="flex justify-between py-1.5 px-2 rounded bg-zinc-800/60 border border-white/5">
              <span class="text-zinc-400">Cumulative Energy:</span>
              <span class="font-bold text-white">{{ state.activeTrain().energyConsumedKwh }} kWh</span>
            </div>
            <div class="flex justify-between py-1.5 px-2 rounded bg-zinc-800/60 border border-white/5">
              <span class="text-zinc-400">PTC Signal Aspect:</span>
              <span class="text-emerald-400 font-bold flex items-center gap-1">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> CLEAR (GREEN)
              </span>
            </div>
          </div>
        </div>

        <!-- Col 2: Davis Resistance Physics Engine -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4 font-mono">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">functions</mat-icon> DAVIS TRAIN RESISTANCE EQUATION
            </span>
            <span class="text-[10px] px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold">PHYSICS ENGINE</span>
          </div>

          <div class="p-3 rounded-lg bg-zinc-950 border border-white/10 space-y-2 text-zinc-300">
            <div class="text-[10px] text-zinc-400 uppercase font-bold">Total Resistance Formula</div>
            <div class="text-xs text-amber-300 font-bold">R_total = A + B*v + C*v² + F_grade + F_curve</div>
            
            <div class="space-y-1.5 pt-2 text-[11px]">
              <div class="flex justify-between">
                <span class="text-zinc-400">A (Rolling Resistance):</span>
                <span class="font-bold text-white">6.32 kN</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-400">B*v (Flange Friction):</span>
                <span class="font-bold text-white">4.41 kN</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-400">C*v² (Aerodynamic Drag):</span>
                <span class="font-bold text-white">52.80 kN</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-400">F_grade (Grade Resistance):</span>
                <span class="font-bold text-amber-400">+14.75 kN</span>
              </div>
              <div class="flex justify-between border-t border-white/10 pt-1">
                <span class="text-zinc-300 font-bold">Total Drag Force:</span>
                <span class="font-bold text-emerald-400">{{ state.activeTrain().davisTotalResistanceKn }} kN</span>
              </div>
            </div>
          </div>

          <!-- Train Weight & Power Profile Card -->
          <div class="p-3 rounded-lg bg-zinc-800/80 border border-white/5 space-y-1.5">
            <div class="text-[10px] text-zinc-400 uppercase font-bold">Train Mechanical Specs</div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Total Mass:</span>
              <span class="font-bold text-white">{{ state.activeTrain().totalMassTonnes }} tonnes</span>
            </div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Trainset Length:</span>
              <span class="text-white">{{ state.activeTrain().trainLengthM }} m (8-car articulated)</span>
            </div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Max Installed Traction Power:</span>
              <span class="text-amber-400 font-bold">{{ state.activeTrain().maxPowerKw }} kW (11,800 hp)</span>
            </div>
          </div>
        </div>

        <!-- Col 3: Corridor Capacity & Headway Engine -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4 font-mono">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-purple-400">hub</mat-icon> CORRIDOR CAPACITY MODEL
            </span>
            <span class="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">UIC 406</span>
          </div>

          <div class="p-3 rounded-lg bg-zinc-950 border border-white/10 space-y-2">
            <div class="text-[10px] text-zinc-400 uppercase font-bold">Statewide Capacity Evaluation</div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Theoretical Capacity:</span>
              <span class="font-bold text-emerald-400">23 trains / hour</span>
            </div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Simulated Practical Capacity:</span>
              <span class="font-bold text-white">18 trains / hour</span>
            </div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Critical Constraint:</span>
              <span class="text-amber-300 font-bold">Fresno South Junction Throats</span>
            </div>
            <div class="flex justify-between py-1 border-b border-white/5">
              <span class="text-zinc-400">Corridor Peak Utilisation:</span>
              <span class="font-bold text-white">78.2%</span>
            </div>
            <div class="flex justify-between py-1">
              <span class="text-zinc-400">Minimum Safe Headway:</span>
              <span class="text-sky-400 font-bold">152 seconds (2.53 min)</span>
            </div>
          </div>

          <div class="p-3 rounded-lg bg-zinc-800/80 border border-white/5 text-[11px] text-zinc-400 space-y-1">
            <div class="text-zinc-200 font-bold flex items-center gap-1">
              <mat-icon class="text-xs text-amber-400">verified</mat-icon> Compliance Statement
            </div>
            <p>Moving block calculations comply with IEEE 1474 CBTC / AREMA Signal Manual. Tested with mixed high-speed passenger & freight overtaking loops.</p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TrainSimulatorComponent {
  readonly state = inject(CaltrackState);
  readonly selectedTrainType = signal<string>('HIGH_SPEED_EMU');

  switchTrainType(type: 'HIGH_SPEED_EMU' | 'COMMUTER_BILEVEL' | 'HEAVY_FREIGHT_INTERMODAL') {
    this.selectedTrainType.set(type);
    const train = this.state.activeTrain();
    if (type === 'HEAVY_FREIGHT_INTERMODAL') {
      this.state.activeTrain.set({
        ...train,
        trainType: type,
        trainName: 'BNSF Double-Stack Intermodal (4x SD70ACe)',
        trainLengthM: 2200,
        totalMassTonnes: 14200,
        maxPowerKw: 12800,
        currentSpeedKmh: 105,
        targetSpeedKmh: 110,
        davisTotalResistanceKn: 215.0
      });
    } else if (type === 'COMMUTER_BILEVEL') {
      this.state.activeTrain.set({
        ...train,
        trainType: type,
        trainName: 'Caltrans San Joaquins Intercity BiLevel',
        trainLengthM: 210,
        totalMassTonnes: 520,
        maxPowerKw: 4800,
        currentSpeedKmh: 175,
        targetSpeedKmh: 180,
        davisTotalResistanceKn: 48.0
      });
    } else {
      this.state.activeTrain.set({
        ...train,
        trainType: type,
        trainName: 'California High-Speed Trainset Alpha (Avelia Horizon Mod)',
        trainLengthM: 202,
        totalMassTonnes: 430,
        maxPowerKw: 8800,
        currentSpeedKmh: 342.5,
        targetSpeedKmh: 350,
        davisTotalResistanceKn: 68.4
      });
    }
  }
}
