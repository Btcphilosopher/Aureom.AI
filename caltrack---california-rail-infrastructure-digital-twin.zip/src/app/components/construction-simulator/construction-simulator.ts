import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-construction-simulator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- 4D Simulator Top Control Bar -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <!-- Playback Controls & Date -->
        <div class="flex items-center gap-3">
          <button 
            (click)="state.toggleConstructionPlayback()"
            class="w-10 h-10 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center transition shadow-md">
            <mat-icon class="text-xl">{{ state.isConstructionPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>

          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Current 4D Timeline</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>Month {{ state.constructionMonth() }} / 72</span>
              <span class="text-emerald-400 font-extrabold font-mono">({{ getFormattedDate(state.constructionMonth()) }})</span>
            </div>
          </div>
        </div>

        <!-- Interactive Timeline Scrubber Slider -->
        <div class="flex-1 w-full max-w-2xl px-2">
          <div class="flex justify-between text-[10px] text-zinc-400 mb-1">
            <span>2027 (Land & Site)</span>
            <span>2028 (Earthworks)</span>
            <span>2029 (Structures)</span>
            <span>2030 (Track & OCS)</span>
            <span>2031 (Signalling)</span>
            <span>2032 (Testing)</span>
            <span>2033 (Revenue Service)</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="72" 
            step="1"
            [value]="state.constructionMonth()"
            (input)="onMonthChange($event)"
            class="w-full accent-emerald-500 cursor-pointer h-2 bg-zinc-800 rounded-lg">
        </div>

        <!-- Overall Corridor Construction Progress -->
        <div class="flex items-center gap-4 bg-zinc-950 border border-white/5 px-4 py-2 rounded-lg">
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Corridor Completed</div>
            <div class="text-base font-bold text-emerald-400">{{ getCorridorProgress() }}%</div>
          </div>
          <div class="w-16 bg-zinc-800 h-2 rounded-full overflow-hidden">
            <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="getCorridorProgress()"></div>
          </div>
        </div>
      </div>

      <!-- Main 4D Workbench Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1 & 2: WBS Construction Stages & Gantt Progress -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">format_list_bulleted</mat-icon> 4D CONSTRUCTION ACTIVITIES & GANTT SEQUENCE
            </span>
            <span class="text-[10px] px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold">WBS LEVEL 2</span>
          </div>

          <div class="space-y-2 max-h-[480px] overflow-y-auto pr-1">
            @for (stage of state.constructionStages(); track stage.id) {
              <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 space-y-1.5 hover:bg-zinc-800 transition">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-zinc-700 text-zinc-300">{{ stage.wbsCode }}</span>
                    <span class="font-bold text-white">{{ stage.taskName }}</span>
                  </div>
                  <div class="flex items-center gap-2">
                    @if (stage.criticalPath) {
                      <span class="text-[9px] px-1.5 py-0.5 rounded bg-red-900/40 text-red-300 border border-red-500/30">CRITICAL PATH</span>
                    }
                    <span class="font-bold" [class.text-emerald-400]="stage.progressPercent === 100" [class.text-amber-400]="stage.progressPercent > 0 && stage.progressPercent < 100" [class.text-zinc-500]="stage.progressPercent === 0">
                      {{ stage.progressPercent }}%
                    </span>
                  </div>
                </div>

                <!-- Progress Bar -->
                <div class="w-full bg-zinc-950 h-2 rounded-full overflow-hidden">
                  <div 
                    class="h-full rounded-full transition-all duration-300"
                    [class.bg-emerald-500]="stage.progressPercent === 100"
                    [class.bg-amber-500]="stage.progressPercent > 0 && stage.progressPercent < 100"
                    [style.width.%]="stage.progressPercent"></div>
                </div>

                <div class="flex items-center justify-between text-[11px] text-zinc-400 pt-0.5">
                  <span>Planned: Month {{ stage.startMonthOffset }} → {{ stage.startMonthOffset + stage.durationMonths }} ({{ stage.durationMonths }} mo)</span>
                  <span>CapEx: &#36;{{ stage.plannedCostUsdMillions }}M USD</span>
                  <span>Gangs: {{ stage.gangCount }}</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Col 3: Machine Fleet Productivity & Logistics -->
        <div class="space-y-4">
          <!-- Active Heavy Plant Fleet -->
          <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-white/10">
              <span class="font-bold text-zinc-100 flex items-center gap-1.5">
                <mat-icon class="text-sm text-amber-400">precision_manufacturing</mat-icon> MACHINE FLEET PRODUCTIVITY
              </span>
            </div>

            <div class="space-y-2">
              @for (mch of state.machines(); track mch.id) {
                <div class="p-2.5 rounded-lg bg-zinc-800/70 border border-white/5 space-y-1">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-zinc-200">{{ mch.name }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded font-bold" [class.bg-emerald-500/20]="mch.status === 'OPERATING'" [class.text-emerald-300]="mch.status === 'OPERATING'" [class.bg-zinc-700]="mch.status !== 'OPERATING'" [class.text-zinc-300]="mch.status !== 'OPERATING'">
                      {{ mch.status }}
                    </span>
                  </div>
                  <div class="text-[11px] text-sky-400">{{ mch.dailyProductivity }}</div>
                  <div class="flex items-center justify-between text-[10px] text-zinc-400 pt-1">
                    <span>Location: CH {{ state.formatStationing(mch.activeChainageM) }}</span>
                    <span>Util: {{ mch.utilizationPct }}% | Crew: {{ mch.crewRequired }}</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Daily Track Installation Rates & Material Logistics Flow -->
          <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3 font-mono">
            <div class="font-bold text-zinc-200 uppercase text-[10px] pb-1 border-b border-white/10 flex items-center gap-1">
              <mat-icon class="text-sm text-sky-400">local_shipping</mat-icon> MATERIAL LOGISTICS STAGING
            </div>

            <div class="space-y-2 text-[11px] text-zinc-300">
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">136 RE CWR Rail Supply:</span>
                <span class="font-bold text-white">480 km delivered (Stockton Yard)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Concrete Sleepers (Monoblock):</span>
                <span class="font-bold text-white">416,000 units (94% staged)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Granite Ballast (Aromas Quarry):</span>
                <span class="font-bold text-white">1.42M tonnes (62% placed)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">25 kV OCS Copper Contact Wire:</span>
                <span class="font-bold text-white">520 km spooled (Fresno Depot)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Track-Laying Progress Rate:</span>
                <span class="font-bold text-emerald-400">14.4 track-km / week</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ConstructionSimulatorComponent {
  readonly state = inject(CaltrackState);

  getFormattedDate(month: number): string {
    const startYear = 2027;
    const date = new Date(startYear, month, 1);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  }

  getCorridorProgress(): number {
    const stages = this.state.constructionStages();
    const total = stages.reduce((acc, s) => acc + s.progressPercent, 0);
    return Math.round(total / stages.length);
  }

  onMonthChange(e: Event) {
    const val = +(e.target as HTMLInputElement).value;
    this.state.setConstructionMonth(val);
  }
}
