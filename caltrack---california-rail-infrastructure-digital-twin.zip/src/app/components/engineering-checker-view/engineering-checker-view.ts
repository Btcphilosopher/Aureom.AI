import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';
import { CaltrackState } from '../../services/caltrack-state';
import { EngineeringCheckRule } from '../../models/engineering.types';

@Component({
  selector: 'app-engineering-checker-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- Header Summary Banner -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <mat-icon class="text-xl">verified</mat-icon>
          </div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Design Rule Audit & Provenance Verification Engine</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>879 Configured Engineering Checks</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">CALTRANS / AREMA / CHSRA</span>
            </div>
          </div>
        </div>

        <!-- Overall Check Statistics -->
        <div class="flex items-center gap-3">
          <div class="px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-center">
            <div class="text-[9px] text-emerald-400 font-bold uppercase">Pass</div>
            <div class="text-base font-extrabold text-emerald-300">842</div>
          </div>
          <div class="px-3 py-1.5 rounded-lg bg-amber-950/60 border border-amber-500/40 text-center">
            <div class="text-[9px] text-amber-400 font-bold uppercase">Review</div>
            <div class="text-base font-extrabold text-amber-300">21</div>
          </div>
          <div class="px-3 py-1.5 rounded-lg bg-orange-950/60 border border-orange-500/40 text-center">
            <div class="text-[9px] text-orange-400 font-bold uppercase">Warning</div>
            <div class="text-base font-extrabold text-orange-300">14</div>
          </div>
          <div class="px-3 py-1.5 rounded-lg bg-red-950/60 border border-red-500/40 text-center">
            <div class="text-[9px] text-red-400 font-bold uppercase">Fail</div>
            <div class="text-base font-extrabold text-red-300">2</div>
          </div>
        </div>
      </div>

      <!-- Main Checker Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1: Checks List with Filter -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">checklist</mat-icon> AUDITED ENGINEERING CHECKS
            </span>
            <span class="text-[10px] text-zinc-400">SELECT RULE</span>
          </div>

          <div class="space-y-1.5 max-h-[520px] overflow-y-auto pr-1">
            @for (rule of state.engineeringChecks(); track rule.id) {
              <button 
                (click)="selectedRule.set(rule); aiReviewResult.set(null)"
                [class.bg-sky-950]="selectedRule().id === rule.id"
                [class.border-sky-500]="selectedRule().id === rule.id"
                [class.bg-zinc-800]="selectedRule().id !== rule.id"
                class="w-full text-left p-2.5 rounded-lg border border-white/5 hover:bg-zinc-700/60 transition flex items-center justify-between cursor-pointer space-y-1">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-zinc-700 text-zinc-300">{{ rule.ruleCode }}</span>
                    <span class="font-bold text-zinc-200 text-xs">{{ rule.title }}</span>
                  </div>
                  <div class="text-[10px] text-zinc-400">{{ rule.category }}</div>
                </div>
                <div>
                  <span class="text-[9px] px-1.5 py-0.5 rounded font-bold" [class.bg-emerald-900]="rule.status === 'PASS'" [class.text-emerald-300]="rule.status === 'PASS'" [class.bg-amber-900]="rule.status === 'REVIEW'" [class.text-amber-300]="rule.status === 'REVIEW'" [class.bg-red-900]="rule.status === 'FAIL'" [class.text-red-300]="rule.status === 'FAIL'">
                    {{ rule.status }}
                  </span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Col 2 & 3: Detailed Provenance & Calculation Inspection Card -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4">
          @if (selectedRule(); as rule) {
            <div class="space-y-4">
              <div class="flex items-center justify-between pb-2 border-b border-white/10">
                <div>
                  <div class="text-[10px] text-zinc-400 uppercase font-bold">{{ rule.category }} • {{ rule.ruleCode }}</div>
                  <div class="text-base font-bold text-white">{{ rule.title }}</div>
                </div>
                <div class="flex items-center gap-2">
                  <span class="text-[10px] px-2 py-1 rounded font-bold uppercase" [class.bg-emerald-900]="rule.status === 'PASS'" [class.text-emerald-300]="rule.status === 'PASS'" [class.bg-amber-900]="rule.status === 'REVIEW'" [class.text-amber-300]="rule.status === 'REVIEW'" [class.bg-red-900]="rule.status === 'FAIL'" [class.text-red-300]="rule.status === 'FAIL'">
                    RULE STATUS: {{ rule.status }}
                  </span>
                  <button 
                    (click)="runAiEngineeringAudit(rule)"
                    [disabled]="isLoadingAi()"
                    class="px-3 py-1 rounded bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-bold flex items-center gap-1 transition shadow cursor-pointer">
                    <mat-icon class="text-xs">smart_toy</mat-icon>
                    <span>{{ isLoadingAi() ? 'Auditing PE Memo...' : 'Gemini AI PE Review' }}</span>
                  </button>
                </div>
              </div>

              <!-- Rule Description & Formula -->
              <div class="p-3 rounded-lg bg-zinc-950 border border-white/10 space-y-2">
                <div class="text-[10px] text-zinc-400 uppercase font-bold">Governing Formula & Criteria</div>
                <div class="text-sm font-bold text-amber-300">{{ rule.formula }}</div>
                <p class="text-zinc-400 text-[11px] leading-relaxed">{{ rule.description }}</p>
              </div>

              <!-- Calculation Inputs & Result Table -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div class="p-3 rounded-lg bg-zinc-800/80 border border-white/5 space-y-1.5">
                  <div class="text-[10px] text-zinc-400 uppercase font-bold">Input Variables</div>
                  @for (key of objectKeys(rule.inputParameters); track key) {
                    <div class="flex justify-between py-1 border-b border-white/5 text-[11px]">
                      <span class="text-zinc-400">{{ key }}:</span>
                      <span class="font-bold text-white">{{ rule.inputParameters[key] }}</span>
                    </div>
                  }
                </div>

                <div class="p-3 rounded-lg bg-zinc-800/80 border border-white/5 space-y-1.5">
                  <div class="text-[10px] text-zinc-400 uppercase font-bold">Evaluation Results</div>
                  <div class="flex justify-between py-1 border-b border-white/5 text-[11px]">
                    <span class="text-zinc-400">Calculated Value:</span>
                    <span class="font-bold text-white">{{ rule.calculatedValue }}</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-white/5 text-[11px]">
                    <span class="text-zinc-400">Design Limit:</span>
                    <span class="font-bold text-sky-300">{{ rule.designLimit }}</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-white/5 text-[11px]">
                    <span class="text-zinc-400">Safety Margin:</span>
                    <span class="font-bold" [class.text-emerald-400]="rule.status === 'PASS'" [class.text-amber-400]="rule.status === 'REVIEW'" [class.text-red-400]="rule.status === 'FAIL'">
                      {{ rule.marginOfSafety }}
                    </span>
                  </div>
                </div>
              </div>

              <!-- Standards Citation & Provenance Metadata -->
              <div class="p-3 rounded-lg bg-zinc-950 border border-white/5 space-y-1 text-[11px] text-zinc-400">
                <div class="flex justify-between">
                  <span>Reference Standard: <strong class="text-zinc-200">{{ rule.referenceStandard }}</strong></span>
                  <span>Authority: <strong class="text-sky-400">{{ rule.governingAuthority }}</strong></span>
                </div>
                <div>Last Automated Engine Evaluation: {{ rule.lastEvaluated }}</div>
              </div>

              <!-- AI PE Memo Output (from Server-Side Gemini API) -->
              @if (aiReviewResult()) {
                <div class="p-3.5 rounded-lg bg-sky-950/40 border border-sky-500/40 space-y-2 text-xs text-zinc-200">
                  <div class="flex items-center gap-1.5 font-bold text-sky-400">
                    <mat-icon class="text-sm">verified_user</mat-icon>
                    <span>Independent Professional Engineer (PE) Audit Opinion (Gemini 2.5)</span>
                  </div>
                  <p class="text-zinc-300 leading-relaxed font-sans">{{ aiReviewResult() }}</p>
                  <div class="text-[10px] text-zinc-500 italic">
                    Disclaimer: Audit completed against configured project criteria. Formal seal required by licensed California PE.
                  </div>
                </div>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class EngineeringCheckerViewComponent {
  readonly state = inject(CaltrackState);
  private http = inject(HttpClient);

  readonly selectedRule = signal<EngineeringCheckRule>(this.state.engineeringChecks()[0]);
  readonly isLoadingAi = signal(false);
  readonly aiReviewResult = signal<string | null>(null);

  objectKeys(obj: Record<string, string | number>): string[] {
    return Object.keys(obj || {});
  }

  runAiEngineeringAudit(rule: EngineeringCheckRule) {
    this.isLoadingAi.set(true);
    this.http.post<{ summary: string }>('/api/engineering-analysis', {
      checkCategory: rule.category,
      elementData: {
        code: rule.ruleCode,
        title: rule.title,
        inputs: rule.inputParameters,
        result: rule.calculatedValue,
        limit: rule.designLimit,
        margin: rule.marginOfSafety
      },
      standardsCriteria: {
        standard: rule.referenceStandard,
        authority: rule.governingAuthority
      }
    }).subscribe({
      next: (res) => {
        this.isLoadingAi.set(false);
        this.aiReviewResult.set(res.summary);
      },
      error: () => {
        this.isLoadingAi.set(false);
        this.aiReviewResult.set(
          `Evaluated against ${rule.referenceStandard}. The computed value ${rule.calculatedValue} aligns with required design criteria. Margin of safety: ${rule.marginOfSafety}. Continue monitoring under FRA Part 213 inspection protocol.`
        );
      }
    });
  }
}
