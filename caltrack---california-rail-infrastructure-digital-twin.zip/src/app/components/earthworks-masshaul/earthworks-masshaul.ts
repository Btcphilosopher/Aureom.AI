import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-earthworks-masshaul',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- Header Summary Banner -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-amber-950 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <mat-icon class="text-xl">landslide</mat-icon>
          </div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Geotechnical Earthwork Engine</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>Mass-Haul Balance & Cut/Fill Optimization</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">BALANCED NET</span>
            </div>
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div class="p-2.5 rounded-lg bg-zinc-950 border border-white/5">
            <div class="text-[10px] text-zinc-400 uppercase">Total Cut Volume</div>
            <div class="text-base font-bold text-amber-400">5,184,200 m³</div>
          </div>
          <div class="p-2.5 rounded-lg bg-zinc-950 border border-white/5">
            <div class="text-[10px] text-zinc-400 uppercase">Total Fill Embankment</div>
            <div class="text-base font-bold text-sky-400">4,902,800 m³</div>
          </div>
          <div class="p-2.5 rounded-lg bg-zinc-950 border border-white/5">
            <div class="text-[10px] text-zinc-400 uppercase">Net Balance Export</div>
            <div class="text-base font-bold text-emerald-400">+281,400 m³</div>
          </div>
          <div class="p-2.5 rounded-lg bg-zinc-950 border border-white/5">
            <div class="text-[10px] text-zinc-400 uppercase">Est. Haul Cost</div>
            <div class="text-base font-bold text-white">$4.40M USD</div>
          </div>
        </div>
      </div>

      <!-- Mass-Haul Diagram & Station Quantities -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1 & 2: Mass Haul Curve Chart (SVG) -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-amber-400">show_chart</mat-icon> CUMULATIVE MASS-HAUL DIAGRAM (M³·KM)
            </span>
            <span class="text-zinc-400 text-[11px]">Free-Haul: 500m | Economic Limit: 25 km</span>
          </div>

          <!-- Scaled Mass-Haul Diagram (SVG) -->
          <div class="w-full h-72 bg-zinc-950 border border-white/10 rounded-lg relative overflow-hidden p-4">
            <svg viewBox="0 0 600 240" class="w-full h-full">
              <!-- Zero Balance Line (Horizontal) -->
              <line x1="50" y1="120" x2="560" y2="120" stroke="#94a3b8" stroke-dasharray="4" stroke-width="1.5" />
              <text x="565" y="124" fill="#94a3b8" font-size="9">Balance Line (0 m³)</text>

              <!-- Grid axis -->
              <line x1="50" y1="20" x2="50" y2="220" stroke="#334155" stroke-width="1" />
              <text x="10" y="30" fill="#64748b" font-size="8">+2.0M m³</text>
              <text x="10" y="123" fill="#64748b" font-size="8">0</text>
              <text x="10" y="215" fill="#64748b" font-size="8">-2.0M m³</text>

              <!-- Mass Haul Curve -->
              <path 
                d="M 50,120 C 120,40 180,60 220,130 C 270,210 340,200 400,105 C 460,30 510,70 550,110" 
                fill="none" 
                stroke="#f59e0b" 
                stroke-width="3" />

              <!-- Shaded Cut vs Fill Haul Loops -->
              <path 
                d="M 50,120 C 120,40 180,60 220,120 Z" 
                fill="rgba(245, 158, 11, 0.15)" />
              <text x="135" y="85" fill="#fbbf24" font-size="9">Haul Loop 1 (Cut → Fill)</text>

              <path 
                d="M 220,120 C 270,210 340,200 400,120 Z" 
                fill="rgba(2, 132, 199, 0.15)" />
              <text x="285" y="165" fill="#38bdf8" font-size="9">Haul Loop 2 (Borrow)</text>

              <path 
                d="M 400,120 C 460,30 510,70 550,110 L 550,120 Z" 
                fill="rgba(16, 185, 129, 0.15)" />
              <text x="440" y="75" fill="#34d399" font-size="9">Haul Loop 3 (+281k Export)</text>
            </svg>
          </div>

          <!-- Earthwork Borrow / Spoil Sites -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div class="p-3 rounded-lg bg-zinc-800/70 border border-white/5 space-y-1">
              <div class="font-bold text-amber-400 flex items-center gap-1">
                <mat-icon class="text-sm">delete_sweep</mat-icon> Designated Spoil Disposal Site
              </div>
              <div class="text-zinc-200 font-bold">Madera North Environmental Fill Facility</div>
              <div class="text-[11px] text-zinc-400">Chainage: 042+000 (Haul: 14.2 km) | Capacity: 800,000 m³</div>
            </div>

            <div class="p-3 rounded-lg bg-zinc-800/70 border border-white/5 space-y-1">
              <div class="font-bold text-sky-400 flex items-center gap-1">
                <mat-icon class="text-sm">terrain</mat-icon> Approved Granular Borrow Pit
              </div>
              <div class="text-zinc-200 font-bold">Kings River Alluvial Aggregate Pit #4</div>
              <div class="text-[11px] text-zinc-400">Chainage: 095+400 (Haul: 6.8 km) | Soil Class: GW/SW Sand-Gravel</div>
            </div>
          </div>
        </div>

        <!-- Col 3: Station Volumes Table -->
        <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3 font-mono">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">table_rows</mat-icon> STATION VOLUMES
            </span>
            <span class="text-[10px] text-zinc-400">INTERVAL 5 KM</span>
          </div>

          <div class="space-y-1.5 max-h-[460px] overflow-y-auto pr-1">
            @for (st of state.earthworkStations(); track st.chainage) {
              <div class="p-2 rounded bg-zinc-800/70 border border-white/5 flex items-center justify-between text-[11px]">
                <div>
                  <div class="font-bold text-zinc-200">CH {{ state.formatStationing(st.chainage) }}</div>
                  <div class="text-[10px]" [class.text-amber-400]="st.cutOrFill === 'CUT'" [class.text-sky-400]="st.cutOrFill === 'FILL'" [class.text-zinc-400]="st.cutOrFill === 'GRADE'">
                    {{ st.cutOrFill }} (H = {{ st.heightM }}m)
                  </div>
                </div>
                <div class="text-right">
                  <div class="font-bold text-white">{{ (st.massHaulOrdinateM3 / 1000).toFixed(0) }}k m³</div>
                  <div class="text-[10px] text-zinc-400">{{ st.haulDistanceKm }} km haul</div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class EarthworksMasshaulComponent {
  readonly state = inject(CaltrackState);
}
