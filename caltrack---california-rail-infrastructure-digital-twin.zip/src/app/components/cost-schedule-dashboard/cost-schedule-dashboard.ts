import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-cost-schedule-dashboard',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- CapEx Overview Header -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 mb-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <mat-icon class="text-xl">paid</mat-icon>
          </div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">CapEx Cost & Schedule Engine</div>
            <div class="text-base font-bold text-white flex items-center gap-2">
              <span>Total Estimated Construction CapEx: $18.42 Billion USD</span>
              <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">WBS LEVEL 3</span>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-3 text-right">
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Baseline Unit Metric</div>
            <div class="text-sm font-bold text-sky-400">$36.84M / Track-km ($73.68M / Route-km)</div>
          </div>
        </div>
      </div>

      <!-- Cost Breakdown Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Col 1 & 2: WBS Standard Cost Allocation Table -->
        <div class="lg:col-span-2 bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-white/10">
            <span class="font-bold text-zinc-100 flex items-center gap-1.5">
              <mat-icon class="text-sm text-sky-400">pie_chart</mat-icon> WBS CAPITAL COST ALLOCATION BREAKDOWN
            </span>
            <span class="text-[11px] text-zinc-400">Base Year: 2026 USD</span>
          </div>

          <div class="space-y-2">
            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">1.0 Land Acquisition & Real Estate</span>
                <div class="text-[10px] text-zinc-400">Right-of-way corridor parcels & environmental mitigation</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$865M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(4.7%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">2.0 Bulk Earthworks & Drainage</span>
                <div class="text-[10px] text-zinc-400">12.8M m³ cut/fill, mass-haul, box culverts, retention basins</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$1,225M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(6.6%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">3.0 Major Bridges & Elevated Viaducts</span>
                <div class="text-[10px] text-zinc-400">41 viaduct structures, San Joaquin River span, CIDH piles</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$3,310M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(18.0%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">4.0 Underground Tunnels & Fresno Trench</span>
                <div class="text-[10px] text-zinc-400">6 tunnels, EPB TBM boring, cut-and-cover, emergency cross passages</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$1,228M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(6.7%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">5.0 Trackwork & Sub-ballast Roadbed</span>
                <div class="text-[10px] text-zinc-400">500 track-km 136 RE CWR, prestressed concrete sleepers, ballast, turnouts</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$1,265M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(6.9%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">6.0 25 kV AC 60Hz Electrification & OCS</span>
                <div class="text-[10px] text-zinc-400">Traction substations (TSS), autotransformers, catenary masts, contact wire</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$1,140M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(6.2%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">7.0 Signalling, PTC & Fiber Communications</span>
                <div class="text-[10px] text-zinc-400">ETCS Level 2 / CBTC moving block, interlockings, axle counters</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$730M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(4.0%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">8.0 Stations, Platforms & Hub Facilities</span>
                <div class="text-[10px] text-zinc-400">5 passenger terminals (Merced, Madera, Fresno, Kings/Tulare, Bakersfield)</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$880M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(4.8%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-white">9.0 Program Management, Engineering & Permitting</span>
                <div class="text-[10px] text-zinc-400">Preliminary/detailed civil engineering, construction inspection, QA/QC</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-emerald-400">$1,480M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(8.0%)</span>
              </div>
            </div>

            <div class="p-2.5 rounded-lg bg-zinc-800/80 border border-white/5 flex items-center justify-between">
              <div>
                <span class="font-bold text-amber-300">10.0 Project Contingency & Unallocated Risk Reserve</span>
                <div class="text-[10px] text-zinc-400">18.5% probabilistic Monte Carlo risk reserve</div>
              </div>
              <div class="text-right">
                <span class="font-bold text-amber-300">$2,280M</span>
                <span class="text-[10px] text-zinc-400 ml-2">(12.4%)</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Col 3: Critical Path Milestones & Alternatives Comparison -->
        <div class="space-y-4">
          <!-- Critical Path Milestones -->
          <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3 font-mono">
            <div class="flex items-center justify-between pb-2 border-b border-white/10">
              <span class="font-bold text-zinc-100 flex items-center gap-1.5">
                <mat-icon class="text-sm text-red-400">flag</mat-icon> CRITICAL PATH MILESTONES
              </span>
            </div>

            <div class="space-y-2 text-[11px] text-zinc-300">
              <div class="p-2 rounded bg-zinc-800/70 border border-white/5">
                <div class="flex justify-between font-bold">
                  <span class="text-white">Civil Infrastructure Substantial Completion:</span>
                  <span class="text-emerald-400">Q4 2029</span>
                </div>
                <div class="text-[10px] text-zinc-400">Total Float: 0 Days (Critical Path Driver)</div>
              </div>

              <div class="p-2 rounded bg-zinc-800/70 border border-white/5">
                <div class="flex justify-between font-bold">
                  <span class="text-white">Track & OCS Power Energization:</span>
                  <span class="text-emerald-400">Q3 2031</span>
                </div>
                <div class="text-[10px] text-zinc-400">Float: 28 Days</div>
              </div>

              <div class="p-2 rounded bg-zinc-800/70 border border-white/5">
                <div class="flex justify-between font-bold">
                  <span class="text-white">Dynamic 350 km/h Testing & Certification:</span>
                  <span class="text-sky-300">Q2 2032</span>
                </div>
                <div class="text-[10px] text-zinc-400">FRA Track Safety Standards Part 213.343 Subpart G</div>
              </div>

              <div class="p-2 rounded bg-zinc-800/70 border border-white/5">
                <div class="flex justify-between font-bold">
                  <span class="text-white">Revenue Passenger Operations Inauguration:</span>
                  <span class="text-amber-400">Q1 2033</span>
                </div>
                <div class="text-[10px] text-zinc-400">Full 250 km Corridor Operating Service</div>
              </div>
            </div>
          </div>

          <!-- Design Alternatives Comparison -->
          <div class="bg-zinc-900 border border-white/10 rounded-xl p-4 shadow-xl space-y-3 font-mono">
            <div class="font-bold text-zinc-200 uppercase text-[10px] pb-1 border-b border-white/10 flex items-center gap-1">
              <mat-icon class="text-sm text-sky-400">compare</mat-icon> ALIGNMENT ALTERNATIVES MATRIX
            </div>

            <div class="space-y-2 text-[11px]">
              @for (alt of state.designAlternatives(); track alt.id) {
                <div class="p-2.5 rounded-lg border border-white/5 bg-zinc-800/60 space-y-1">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-white">{{ alt.name }}</span>
                    <span class="font-bold text-emerald-400">&#36;{{ alt.estimatedCostBillionUsd }}B</span>
                  </div>
                  <div class="text-[10px] text-zinc-400">
                    Length: {{ alt.routeLengthKm }} km | Transit: {{ alt.transitTimeMinutes }} min | Structures: {{ alt.bridgesCount }} Bridges, {{ alt.tunnelsCount }} Tunnels
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CostScheduleDashboardComponent {
  readonly state = inject(CaltrackState);
}
