import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnDestroy, 
  AfterViewInit, 
  ViewChild, 
  inject, 
  signal,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { CaltrackState } from '../../services/caltrack-state';

export interface ObjectInspectorData {
  category: string;
  name: string;
  chainage: string;
  designSpeed: string;
  trackForm: string;
  railSection: string;
  cant: string;
  cantDeficiency: string;
  seismicPga: string;
  status: string;
}

@Component({
  selector: 'app-digital-twin-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[calc(100vh-7rem)] bg-zinc-950 overflow-hidden flex select-none">
      <!-- 3D WebGL Canvas Container -->
      <div #canvasContainer class="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing">
        <!-- Floating 3D HUD / View Controls -->
        <div class="absolute top-4 left-4 z-20 flex flex-col gap-2">
          <!-- View Modes -->
          <div class="bg-zinc-900/90 backdrop-blur border border-white/10 p-1.5 rounded-lg shadow-xl flex items-center gap-1 text-xs">
            <button 
              (click)="setCameraMode('ORBIT')"
              [class.bg-zinc-700]="cameraMode() === 'ORBIT'"
              [class.text-white]="cameraMode() === 'ORBIT'"
              [class.text-zinc-400]="cameraMode() !== 'ORBIT'"
              class="px-2.5 py-1 rounded flex items-center gap-1 font-mono transition">
              <mat-icon class="text-sm">3d_rotation</mat-icon> Orbit CAD
            </button>
            <button 
              (click)="setCameraMode('CAB')"
              [class.bg-zinc-700]="cameraMode() === 'CAB'"
              [class.text-white]="cameraMode() === 'CAB'"
              [class.text-zinc-400]="cameraMode() !== 'CAB'"
              class="px-2.5 py-1 rounded flex items-center gap-1 font-mono transition">
              <mat-icon class="text-sm">videocam</mat-icon> Driver Cab
            </button>
            <button 
              (click)="setCameraMode('TOP')"
              [class.bg-zinc-700]="cameraMode() === 'TOP'"
              [class.text-white]="cameraMode() === 'TOP'"
              [class.text-zinc-400]="cameraMode() !== 'TOP'"
              class="px-2.5 py-1 rounded flex items-center gap-1 font-mono transition">
              <mat-icon class="text-sm">layers</mat-icon> Plan (Top)
            </button>
          </div>

          <!-- Quick Jump Corridor Stations -->
          <div class="bg-zinc-900/90 backdrop-blur border border-white/10 p-2 rounded-lg shadow-xl text-xs flex items-center gap-1.5 flex-wrap max-w-lg">
            <span class="text-[10px] font-mono text-zinc-400 uppercase">Fly to:</span>
            <button (click)="jumpToLocation(1200)" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-mono text-[11px]">Merced (001+200)</button>
            <button (click)="jumpToLocation(19200)" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-sky-300 font-mono text-[11px]">San Joaquin Viaduct (019+200)</button>
            <button (click)="jumpToLocation(61400)" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-mono text-[11px]">Fresno Trench (061+400)</button>
            <button (click)="jumpToLocation(119800)" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-mono text-[11px]">Kings/Tulare (119+800)</button>
            <button (click)="jumpToLocation(184200)" class="px-2 py-0.5 rounded bg-red-900/40 border border-red-500/40 text-red-300 font-mono text-[11px] flex items-center gap-1">
              <mat-icon class="text-[12px]">warning</mat-icon> MP 184.2 Defect
            </button>
            <button (click)="jumpToLocation(248200)" class="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-mono text-[11px]">Bakersfield (248+200)</button>
          </div>
        </div>

        <!-- Layer Toggles -->
        <div class="absolute top-4 right-4 z-20 bg-zinc-900/90 backdrop-blur border border-white/10 p-3 rounded-lg shadow-xl text-xs w-56 flex flex-col gap-2">
          <div class="flex items-center justify-between font-mono text-zinc-300 pb-1 border-b border-white/10 font-semibold">
            <span>DIGITAL TWIN LAYERS</span>
            <mat-icon class="text-sm text-sky-400">tune</mat-icon>
          </div>
          <label class="flex items-center justify-between text-zinc-300 cursor-pointer hover:text-white">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded bg-emerald-500"></span> 3D Track & Ballast</span>
            <input type="checkbox" [checked]="showTrack()" (change)="toggleLayer('track')" class="accent-emerald-500">
          </label>
          <label class="flex items-center justify-between text-zinc-300 cursor-pointer hover:text-white">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded bg-sky-500"></span> Bridges & Viaducts</span>
            <input type="checkbox" [checked]="showStructures()" (change)="toggleLayer('structures')" class="accent-sky-500">
          </label>
          <label class="flex items-center justify-between text-zinc-300 cursor-pointer hover:text-white">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded bg-amber-500"></span> 25kV Catenary Masts</span>
            <input type="checkbox" [checked]="showCatenary()" (change)="toggleLayer('catenary')" class="accent-amber-500">
          </label>
          <label class="flex items-center justify-between text-zinc-300 cursor-pointer hover:text-white">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded bg-purple-500"></span> Geotech Boreholes</span>
            <input type="checkbox" [checked]="showBoreholes()" (change)="toggleLayer('boreholes')" class="accent-purple-500">
          </label>
          <label class="flex items-center justify-between text-zinc-300 cursor-pointer hover:text-white">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded bg-stone-500"></span> Regional DEM Terrain</span>
            <input type="checkbox" [checked]="showTerrain()" (change)="toggleLayer('terrain')" class="accent-stone-500">
          </label>
          <label class="flex items-center justify-between text-zinc-300 cursor-pointer hover:text-white">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded bg-red-500"></span> Live Train (HST-01)</span>
            <input type="checkbox" [checked]="showTrain()" (change)="toggleLayer('train')" class="accent-red-500">
          </label>
        </div>

        <!-- Real-time Stationing & Speed Overlay -->
        <div class="absolute bottom-4 left-4 z-20 bg-zinc-900/90 backdrop-blur border border-white/10 p-3 rounded-lg shadow-xl text-xs flex items-center gap-6 font-mono">
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Stationing / Chainage</div>
            <div class="text-sm font-bold text-sky-400">{{ state.formatStationing(state.activeChainagePointerM()) }}</div>
          </div>
          <div class="h-6 w-px bg-white/10"></div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Train 01 Speed</div>
            <div class="text-sm font-bold text-emerald-400">{{ state.formatSpeed(state.activeTrain().currentSpeedKmh) }}</div>
          </div>
          <div class="h-6 w-px bg-white/10"></div>
          <div>
            <div class="text-[10px] text-zinc-400 uppercase">Tractive Power</div>
            <div class="text-sm font-bold text-amber-400">{{ state.activeTrain().powerOutputMw }} MW</div>
          </div>
          <div class="h-6 w-px bg-white/10"></div>
          <button 
            (click)="state.toggleTrainSimulation()" 
            class="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/10 flex items-center gap-1 transition">
            <mat-icon class="text-sm text-emerald-400">{{ state.isTrainSimRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ state.isTrainSimRunning() ? 'Pause Train' : 'Launch Train' }}</span>
          </button>
        </div>
      </div>

      <!-- Right Inspection Card / Element Property Inspector -->
      <div class="w-80 h-full bg-zinc-900/95 border-l border-white/10 p-4 flex flex-col overflow-y-auto text-xs z-20 shadow-2xl">
        <div class="flex items-center justify-between pb-2 border-b border-white/10 mb-3 font-mono">
          <span class="font-bold text-zinc-200 flex items-center gap-1.5">
            <mat-icon class="text-sm text-sky-400">info</mat-icon> OBJECT INSPECTOR
          </span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">CALTRACK 3D</span>
        </div>

        @if (selectedObjectInfo(); as info) {
          <div class="space-y-3 font-mono">
            <div class="p-2.5 rounded bg-zinc-800/80 border border-white/5">
              <div class="text-[10px] text-zinc-400 uppercase">{{ info.category }}</div>
              <div class="text-sm font-bold text-white tracking-tight">{{ info.name }}</div>
              <div class="text-[11px] text-sky-400 mt-0.5">Chainage: {{ info.chainage }}</div>
            </div>

            <div class="space-y-1.5 text-zinc-300">
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Design Speed:</span>
                <span class="font-bold text-white">{{ info.designSpeed }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Track Form:</span>
                <span class="text-white">{{ info.trackForm }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Rail Section:</span>
                <span class="text-white">{{ info.railSection }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Applied Cant (Ea):</span>
                <span class="text-amber-300 font-bold">{{ info.cant }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Cant Deficiency (Ed):</span>
                <span class="text-sky-300 font-bold">{{ info.cantDeficiency }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Seismic PGA (g):</span>
                <span class="text-zinc-200">{{ info.seismicPga }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Installation Date:</span>
                <span class="text-zinc-400">Q3 2030 (Planned)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-white/5">
                <span class="text-zinc-400">Engineering Status:</span>
                <span class="text-emerald-400 font-bold">{{ info.status }}</span>
              </div>
            </div>

            <!-- Deep Engineering Provenance citation -->
            <div class="mt-4 p-2.5 rounded bg-zinc-950 border border-white/5 text-[11px] text-zinc-400 space-y-1">
              <div class="text-zinc-300 font-bold flex items-center gap-1">
                <mat-icon class="text-xs text-amber-400">verified</mat-icon>
                Governing Criteria
              </div>
              <p>Caltrans Rail Highway Manual & CHSR TM 2.1.2. Verification completed against 350 km/h kinematic envelope.</p>
            </div>
          </div>
        } @else {
          <div class="flex flex-col items-center justify-center text-center p-6 text-zinc-500 font-mono space-y-2">
            <mat-icon class="text-3xl">touch_app</mat-icon>
            <p>Click on any 3D track section, bridge, catenary mast or borehole to inspect engineering properties.</p>
          </div>
        }
      </div>
    </div>
  `
})
export class DigitalTwinViewerComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  readonly state = inject(CaltrackState);
  private platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);

  // Layer Visibility Signals
  readonly showTrack = signal(true);
  readonly showStructures = signal(true);
  readonly showCatenary = signal(true);
  readonly showBoreholes = signal(true);
  readonly showTerrain = signal(true);
  readonly showTrain = signal(true);
  readonly cameraMode = signal<'ORBIT' | 'CAB' | 'TOP'>('ORBIT');

  // Selected Object Card Info
  readonly selectedObjectInfo = signal<ObjectInspectorData>({
    category: 'High-Speed Railway Corridor Segment',
    name: 'San Joaquin River Viaduct Curve SC-1',
    chainage: '019+150 to 023+800',
    designSpeed: '350 km/h',
    trackForm: 'Ballasted 136 RE on Prestressed Concrete Sleepers',
    railSection: '136 RE (67.4 kg/m) Continuous Welded Rail',
    cant: '120 mm applied superelevation',
    cantDeficiency: '45.4 mm (limit 80 mm)',
    seismicPga: '0.52 g design spectral acceleration',
    status: 'DESIGN VERIFIED (PASS)'
  });

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId: number | null = null;
  private trackGroup = new THREE.Group();
  private structuresGroup = new THREE.Group();
  private catenaryGroup = new THREE.Group();
  private boreholesGroup = new THREE.Group();
  private terrainGroup = new THREE.Group();
  private trainMesh!: THREE.Group;
  private defectMarkerMesh!: THREE.Mesh;

  // Interaction State
  private isMouseDown = false;
  private mouseX = 0;
  private mouseY = 0;
  private cameraDistance = 220;
  private cameraAngleH = 0.8;
  private cameraAngleV = 0.55;
  private cameraTarget = new THREE.Vector3(0, 0, 0);

  ngAfterViewInit() {
    if (!this.isBrowser) return;
    this.initThreeScene();
    this.buildTerrain();
    this.build3DTrackAndStructures();
    this.buildCatenaryMasts();
    this.buildBoreholes();
    this.buildTrain();
    this.buildDefectHotspot();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThreeScene() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x090d13);
    this.scene.fog = new THREE.FogExp2(0x090d13, 0.0018);

    this.camera = new THREE.PerspectiveCamera(50, width / height, 1, 10000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xdde5ed, 0.7);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff8ee, 1.4);
    sunLight.position.set(300, 500, 200);
    sunLight.castShadow = true;
    this.scene.add(sunLight);

    // Groups
    this.scene.add(this.trackGroup);
    this.scene.add(this.structuresGroup);
    this.scene.add(this.catenaryGroup);
    this.scene.add(this.boreholesGroup);
    this.scene.add(this.terrainGroup);

    // Event listeners
    container.addEventListener('mousedown', this.onMouseDown.bind(this));
    window.addEventListener('mousemove', this.onMouseMove.bind(this));
    window.addEventListener('mouseup', this.onMouseUp.bind(this));
    container.addEventListener('wheel', this.onWheel.bind(this), { passive: true });
    window.addEventListener('resize', this.onResize.bind(this));
  }

  private buildTerrain() {
    const terrainGeo = new THREE.PlaneGeometry(3000, 3000, 64, 64);
    terrainGeo.rotateX(-Math.PI / 2);

    const pos = terrainGeo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      // Gentle California valley topography with undulating foothills
      const elev = Math.sin(x * 0.003) * Math.cos(z * 0.002) * 18 + (z * 0.01);
      pos.setY(i, elev - 8);
    }
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0x1a2129,
      roughness: 0.9,
      metalness: 0.1,
      wireframe: false
    });

    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainMesh.receiveShadow = true;
    this.terrainGroup.add(terrainMesh);

    // Add visual CAD grid line
    const grid = new THREE.GridHelper(3000, 60, 0x38bdf8, 0x1e293b);
    grid.position.y = -7.8;
    this.terrainGroup.add(grid);
  }

  private build3DTrackAndStructures() {
    // Generate curved high-speed corridor track bed
    const points: THREE.Vector3[] = [];
    const numPoints = 120;
    for (let i = 0; i < numPoints; i++) {
      const t = i / (numPoints - 1);
      // 3D spline curve simulating Central Valley corridor
      const x = (t - 0.5) * 2200;
      const z = Math.sin(t * Math.PI * 2.2) * 180 + (t - 0.5) * 800;
      const y = Math.sin(t * Math.PI * 3) * 6 + (t * 12);
      points.push(new THREE.Vector3(x, y, z));
    }

    const curve = new THREE.CatmullRomCurve3(points);

    // Ballast Bed Roadbed Mesh
    const ballastShape = new THREE.Shape();
    ballastShape.moveTo(-7.0, -1.8);
    ballastShape.lineTo(7.0, -1.8);
    ballastShape.lineTo(6.0, 0.0);
    ballastShape.lineTo(-6.0, 0.0);
    ballastShape.closePath();

    const ballastExtrudeGeo = new THREE.ExtrudeGeometry(ballastShape, {
      extrudePath: curve,
      steps: 200,
      bevelEnabled: false
    });
    const ballastMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.95 });
    const ballastMesh = new THREE.Mesh(ballastExtrudeGeo, ballastMat);
    this.trackGroup.add(ballastMesh);

    // Double Track Rails (Track 1 & Track 2: standard 1435mm gauge, 5.0m track spacing)
    const offsets = [-2.5 - 0.717, -2.5 + 0.717, 2.5 - 0.717, 2.5 + 0.717];
    const railMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.85, roughness: 0.25 });

    offsets.forEach(off => {
      const railCurvePoints = points.map(p => new THREE.Vector3(p.x, p.y + 0.4, p.z + off));
      const railCurve = new THREE.CatmullRomCurve3(railCurvePoints);
      const railGeo = new THREE.TubeGeometry(railCurve, 180, 0.08, 6, false);
      const railMesh = new THREE.Mesh(railGeo, railMat);
      this.trackGroup.add(railMesh);
    });

    // Concrete Sleepers along the path (Instanced / Sampled)
    const sleeperGeo = new THREE.BoxGeometry(0.3, 0.22, 2.6);
    const sleeperMat = new THREE.MeshStandardMaterial({ color: 0x71717a, roughness: 0.8 });

    for (let i = 0; i < 180; i++) {
      const u = i / 180;
      const pt = curve.getPointAt(u);
      const tangent = curve.getTangentAt(u);

      const sleeper1 = new THREE.Mesh(sleeperGeo, sleeperMat);
      sleeper1.position.set(pt.x, pt.y + 0.12, pt.z - 2.5);
      sleeper1.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), tangent);
      this.trackGroup.add(sleeper1);

      const sleeper2 = new THREE.Mesh(sleeperGeo, sleeperMat);
      sleeper2.position.set(pt.x, pt.y + 0.12, pt.z + 2.5);
      sleeper2.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), tangent);
      this.trackGroup.add(sleeper2);
    }

    // San Joaquin River Viaduct Structure (Piers & Concrete Pergola Deck)
    const viaductPierGeo = new THREE.CylinderGeometry(1.4, 1.8, 22, 12);
    const viaductMat = new THREE.MeshStandardMaterial({ color: 0x52525b, roughness: 0.7 });

    for (let i = 25; i < 45; i += 3) {
      const u = i / 120;
      const pt = curve.getPointAt(u);
      const pier = new THREE.Mesh(viaductPierGeo, viaductMat);
      pier.position.set(pt.x, pt.y - 11, pt.z);
      this.structuresGroup.add(pier);
    }

    // Tunnel Portal at Chainage ~200km
    const portalGeo = new THREE.TorusGeometry(10, 1.6, 8, 24, Math.PI);
    const portalMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.8 });
    const portal = new THREE.Mesh(portalGeo, portalMat);
    const tunnelPt = curve.getPointAt(0.82);
    portal.position.set(tunnelPt.x, tunnelPt.y + 4, tunnelPt.z);
    portal.rotateY(Math.PI / 2);
    this.structuresGroup.add(portal);
  }

  private buildCatenaryMasts() {
    const mastGeo = new THREE.CylinderGeometry(0.12, 0.16, 8.5, 8);
    const armGeo = new THREE.BoxGeometry(0.12, 0.12, 8.2);
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.6, roughness: 0.4 });

    for (let i = 0; i < 40; i++) {
      const u = i / 40;
      const x = (u - 0.5) * 2200;
      const z = Math.sin(u * Math.PI * 2.2) * 180 + (u - 0.5) * 800;
      const y = Math.sin(u * Math.PI * 3) * 6 + (u * 12);

      const mast = new THREE.Mesh(mastGeo, steelMat);
      mast.position.set(x, y + 4.25, z - 4.5);
      this.catenaryGroup.add(mast);

      const arm = new THREE.Mesh(armGeo, steelMat);
      arm.position.set(x, y + 7.8, z);
      this.catenaryGroup.add(arm);
    }
  }

  private buildBoreholes() {
    const boreholes = this.state.geotechnicalBoreholes();
    boreholes.slice(0, 12).forEach((bh, idx) => {
      const u = idx / 12;
      const x = (u - 0.5) * 2200 + bh.offsetM;
      const z = Math.sin(u * Math.PI * 2.2) * 180 + (u - 0.5) * 800 + bh.offsetM;
      const y = Math.sin(u * Math.PI * 3) * 6 + (u * 12);

      // Multi-layer subsurface stratigraphy cylinder
      bh.layers.forEach(layer => {
        const h = (layer.depthEndM - layer.depthStartM) * 0.4;
        const layerGeo = new THREE.CylinderGeometry(0.8, 0.8, h, 8);
        const layerMat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(layer.colorHex),
          roughness: 0.85
        });
        const layerMesh = new THREE.Mesh(layerGeo, layerMat);
        layerMesh.position.set(x, y - (layer.depthStartM * 0.4) - (h / 2) - 1, z);
        this.boreholesGroup.add(layerMesh);
      });
    });
  }

  private buildTrain() {
    this.trainMesh = new THREE.Group();

    // Streamlined High-Speed EMU Body
    const bodyGeo = new THREE.BoxGeometry(24, 3.4, 3.2);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.3, roughness: 0.3 }); // California Red
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 1.7;
    this.trainMesh.add(body);

    // Streamlined Nose Cone
    const noseGeo = new THREE.ConeGeometry(2.2, 7.0, 16);
    noseGeo.rotateZ(-Math.PI / 2);
    const nose = new THREE.Mesh(noseGeo, bodyMat);
    nose.position.set(14.5, 1.7, 0);
    this.trainMesh.add(nose);

    // Windshield
    const glassGeo = new THREE.BoxGeometry(4.0, 1.2, 2.6);
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(13.2, 2.4, 0);
    this.trainMesh.add(glass);

    // Pantograph
    const pantoGeo = new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6);
    const pantoMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.8 });
    const panto = new THREE.Mesh(pantoGeo, pantoMat);
    panto.position.set(-6.0, 4.0, 0);
    panto.rotateZ(Math.PI / 4);
    this.trainMesh.add(panto);

    this.scene.add(this.trainMesh);
  }

  private buildDefectHotspot() {
    // MP 184.2 Warning Pulsating Marker
    const markerGeo = new THREE.OctahedronGeometry(2.5, 0);
    const markerMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xef4444,
      emissiveIntensity: 0.8,
      wireframe: false
    });
    this.defectMarkerMesh = new THREE.Mesh(markerGeo, markerMat);
    this.defectMarkerMesh.position.set(650, 16, 220); // MP 184.2
    this.scene.add(this.defectMarkerMesh);
  }

  setCameraMode(mode: 'ORBIT' | 'CAB' | 'TOP') {
    this.cameraMode.set(mode);
    if (mode === 'TOP') {
      this.cameraDistance = 350;
      this.cameraAngleV = Math.PI / 2 - 0.05;
      this.updateCameraPosition();
    } else if (mode === 'ORBIT') {
      this.cameraDistance = 220;
      this.cameraAngleV = 0.55;
      this.updateCameraPosition();
    }
  }

  jumpToLocation(chainageM: number) {
    this.state.setChainagePointer(chainageM);
    const u = chainageM / 250000;
    const x = (u - 0.5) * 2200;
    const z = Math.sin(u * Math.PI * 2.2) * 180 + (u - 0.5) * 800;
    const y = Math.sin(u * Math.PI * 3) * 6 + (u * 12);

    this.cameraTarget.set(x, y, z);
    this.updateCameraPosition();
  }

  toggleLayer(layer: string) {
    switch (layer) {
      case 'track':
        this.showTrack.update(v => !v);
        this.trackGroup.visible = this.showTrack();
        break;
      case 'structures':
        this.showStructures.update(v => !v);
        this.structuresGroup.visible = this.showStructures();
        break;
      case 'catenary':
        this.showCatenary.update(v => !v);
        this.catenaryGroup.visible = this.showCatenary();
        break;
      case 'boreholes':
        this.showBoreholes.update(v => !v);
        this.boreholesGroup.visible = this.showBoreholes();
        break;
      case 'terrain':
        this.showTerrain.update(v => !v);
        this.terrainGroup.visible = this.showTerrain();
        break;
      case 'train':
        this.showTrain.update(v => !v);
        this.trainMesh.visible = this.showTrain();
        break;
    }
  }

  private animate() {
    this.animFrameId = requestAnimationFrame(() => this.animate());

    // Update Live Train Position along corridor in 3D
    const trainState = this.state.activeTrain();
    const u = (trainState.currentChainageM / 250000) % 1.0;
    const tx = (u - 0.5) * 2200;
    const tz = Math.sin(u * Math.PI * 2.2) * 180 + (u - 0.5) * 800 + 2.5;
    const ty = Math.sin(u * Math.PI * 3) * 6 + (u * 12) + 0.4;

    this.trainMesh.position.set(tx, ty, tz);
    this.trainMesh.rotation.y = Math.cos(u * Math.PI * 2.2) * 0.4;

    // Pulse defect marker
    if (this.defectMarkerMesh) {
      this.defectMarkerMesh.rotation.y += 0.03;
      const s = 1.0 + Math.sin(Date.now() * 0.006) * 0.25;
      this.defectMarkerMesh.scale.set(s, s, s);
    }

    // Cab camera tracking
    if (this.cameraMode() === 'CAB') {
      this.camera.position.set(tx + 12, ty + 3.8, tz);
      this.camera.lookAt(tx + 80, ty + 2.0, tz);
    } else {
      this.camera.lookAt(this.cameraTarget);
    }

    this.renderer.render(this.scene, this.camera);
  }

  // Mouse / Touch Controls
  private onMouseDown(e: MouseEvent) {
    this.isMouseDown = true;
    this.mouseX = e.clientX;
    this.mouseY = e.clientY;
  }

  private onMouseMove(e: MouseEvent) {
    if (!this.isMouseDown || this.cameraMode() === 'CAB') return;
    const dx = e.clientX - this.mouseX;
    const dy = e.clientY - this.mouseY;
    this.mouseX = e.clientX;
    this.mouseY = e.clientY;

    if (e.buttons === 1) {
      // Left click orbit
      this.cameraAngleH -= dx * 0.005;
      this.cameraAngleV = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraAngleV + dy * 0.005));
    } else if (e.buttons === 2) {
      // Right click pan
      this.cameraTarget.x -= dx * 0.5;
      this.cameraTarget.z -= dy * 0.5;
    }
    this.updateCameraPosition();
  }

  private onMouseUp() {
    this.isMouseDown = false;
  }

  private onWheel(e: WheelEvent) {
    if (this.cameraMode() === 'CAB') return;
    this.cameraDistance = Math.max(20, Math.min(1200, this.cameraDistance + e.deltaY * 0.3));
    this.updateCameraPosition();
  }

  private updateCameraPosition() {
    if (this.cameraMode() === 'CAB') return;
    const x = this.cameraTarget.x + this.cameraDistance * Math.sin(this.cameraAngleH) * Math.cos(this.cameraAngleV);
    const y = this.cameraTarget.y + this.cameraDistance * Math.sin(this.cameraAngleV);
    const z = this.cameraTarget.z + this.cameraDistance * Math.cos(this.cameraAngleH) * Math.cos(this.cameraAngleV);
    this.camera.position.set(x, y, z);
  }

  private onResize() {
    const container = this.canvasContainer.nativeElement;
    const w = container.clientWidth;
    const h = container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }
}
