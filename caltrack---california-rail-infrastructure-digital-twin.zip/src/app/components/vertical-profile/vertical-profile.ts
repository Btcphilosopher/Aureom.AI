import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  AfterViewInit, 
  ViewChild, 
  inject, 
  signal,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-vertical-profile',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col lg:flex-row overflow-hidden select-none font-mono">
      <!-- Left: Longitudinal Vertical Profile Canvas -->
      <div class="flex-1 h-full flex flex-col border-r border-white/10">
        <!-- Toolbar -->
        <div class="h-10 bg-zinc-900 border-b border-white/10 px-4 flex items-center justify-between text-xs">
          <div class="flex items-center gap-2 text-zinc-300">
            <mat-icon class="text-sm text-amber-400">show_chart</mat-icon>
            <span class="font-bold text-white">LONGITUDINAL VERTICAL PROFILE</span>
            <span class="text-zinc-500">|</span>
            <span class="text-zinc-400">Datum: NAVD88 Elevation</span>
          </div>
          <div class="text-[11px] text-zinc-400">
            Selected Stationing: <span class="text-sky-400 font-bold">{{ state.formatStationing(selectedChainage()) }}</span>
          </div>
        </div>

        <!-- Profile Canvas -->
        <div #profileContainer class="flex-1 w-full h-full relative overflow-hidden bg-zinc-950 cad-grid">
          <canvas 
            #profileCanvas 
            class="w-full h-full cursor-crosshair"
            (click)="onCanvasClick($event)"></canvas>

          <!-- Profile Legend -->
          <div class="absolute bottom-3 left-3 bg-zinc-900/90 backdrop-blur border border-white/10 p-2.5 rounded-lg text-[11px] space-y-1">
            <div class="text-zinc-400 font-bold uppercase text-[10px]">Profile Layers</div>
            <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-amber-500"></span> Natural Ground Elevation</div>
            <div class="flex items-center gap-2"><span class="w-3 h-1 bg-red-500"></span> Proposed Rail Crown (Top of Rail)</div>
            <div class="flex items-center gap-2"><span class="w-3 h-2 bg-amber-700/30 border border-amber-600/50"></span> Cut Area</div>
            <div class="flex items-center gap-2"><span class="w-3 h-2 bg-sky-700/30 border border-sky-500/50"></span> Fill Embankment</div>
            <div class="flex items-center gap-2"><span class="w-3 h-0.5 bg-sky-400"></span> Bridge Viaduct Deck</div>
          </div>
        </div>
      </div>

      <!-- Right: Parametric Cross-Section Viewer at Selected Chainage -->
      <div class="w-full lg:w-96 h-full bg-zinc-900/95 border-l border-white/10 p-4 flex flex-col overflow-y-auto text-xs z-10 shadow-2xl">
        <div class="flex items-center justify-between pb-2 border-b border-white/10 mb-3">
          <span class="font-bold text-zinc-100 flex items-center gap-1.5">
            <mat-icon class="text-sm text-sky-400">splitscreen</mat-icon> SECTION VIEW (CH {{ state.formatStationing(selectedChainage()) }})
          </span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">1:50 CAD</span>
        </div>

        <!-- Track Form Selector -->
        <div class="flex items-center gap-2 mb-3 bg-zinc-800 p-1 rounded-lg">
          <button 
            (click)="trackForm.set('BALLASTED')" 
            [class.bg-zinc-700]="trackForm() === 'BALLASTED'"
            [class.text-white]="trackForm() === 'BALLASTED'"
            [class.text-zinc-400]="trackForm() !== 'BALLASTED'"
            class="flex-1 py-1 rounded text-center font-bold transition">
            Ballasted Track
          </button>
          <button 
            (click)="trackForm.set('SLAB')" 
            [class.bg-zinc-700]="trackForm() === 'SLAB'"
            [class.text-white]="trackForm() === 'SLAB'"
            [class.text-zinc-400]="trackForm() !== 'SLAB'"
            class="flex-1 py-1 rounded text-center font-bold transition">
            RHEDA 2000 Slab
          </button>
        </div>

        <!-- Scaled Parametric 2D CAD Cross Section Graphic -->
        <div class="w-full h-52 bg-zinc-950 border border-white/10 rounded-lg relative overflow-hidden flex items-center justify-center p-2 mb-3">
          <svg viewBox="0 0 400 240" class="w-full h-full">
            <!-- Ground Base Line -->
            <line x1="20" y1="200" x2="380" y2="200" stroke="#52525b" stroke-dasharray="4" stroke-width="1.5" />
            <text x="25" y="215" fill="#71717a" font-size="9">Natural Subgrade Line</text>

            <!-- Subgrade / Formation Trapezoid -->
            <polygon points="60,200 100,160 300,160 340,200" fill="#3f3f46" stroke="#71717a" stroke-width="1" />
            <text x="175" y="185" fill="#a1a1aa" font-size="9" text-anchor="middle">Formation (13.6m)</text>

            @if (trackForm() === 'BALLASTED') {
              <!-- Sub-ballast -->
              <polygon points="110,160 125,140 275,140 290,160" fill="#27272a" stroke="#52525b" stroke-width="1" />
              <!-- Ballast Layer -->
              <polygon points="130,140 145,115 255,115 270,140" fill="#18181b" stroke="#f59e0b" stroke-width="1.5" />
              <text x="200" y="132" fill="#fbbf24" font-size="9" text-anchor="middle">Granite Ballast (300mm)</text>

              <!-- Track 1 Sleepers & Rails -->
              <rect x="155" y="105" width="38" height="10" fill="#a1a1aa" rx="1" />
              <rect x="160" y="93" width="4" height="12" fill="#e2e8f0" />
              <rect x="184" y="93" width="4" height="12" fill="#e2e8f0" />
              <text x="174" y="88" fill="#38bdf8" font-size="8" text-anchor="middle">Track 1</text>

              <!-- Track 2 Sleepers & Rails -->
              <rect x="207" y="105" width="38" height="10" fill="#a1a1aa" rx="1" />
              <rect x="212" y="93" width="4" height="12" fill="#e2e8f0" />
              <rect x="236" y="93" width="4" height="12" fill="#e2e8f0" />
              <text x="226" y="88" fill="#38bdf8" font-size="8" text-anchor="middle">Track 2</text>
            } @else {
              <!-- Concrete Track Slab Base -->
              <rect x="120" y="130" width="160" height="30" fill="#334155" stroke="#94a3b8" stroke-width="1.5" rx="2" />
              <text x="200" y="148" fill="#cbd5e1" font-size="9" text-anchor="middle">RHEDA Concrete Slab Base</text>

              <!-- Direct Fasteners & Rails -->
              <rect x="155" y="118" width="38" height="12" fill="#64748b" rx="1" />
              <rect x="160" y="104" width="4" height="14" fill="#f8fafc" />
              <rect x="184" y="104" width="4" height="14" fill="#f8fafc" />

              <rect x="207" y="118" width="38" height="12" fill="#64748b" rx="1" />
              <rect x="212" y="104" width="4" height="14" fill="#f8fafc" />
              <rect x="236" y="104" width="4" height="14" fill="#f8fafc" />
            }

            <!-- Catenary Mast Left -->
            <line x1="85" y1="200" x2="85" y2="35" stroke="#94a3b8" stroke-width="2.5" />
            <line x1="85" y1="45" x2="230" y2="45" stroke="#94a3b8" stroke-width="1.5" />
            <!-- Contact Wires (5.3m above rail) -->
            <circle cx="172" cy="55" r="2.5" fill="#f59e0b" />
            <circle cx="224" cy="55" r="2.5" fill="#f59e0b" />
            <text x="90" y="32" fill="#94a3b8" font-size="8">25kV OCS Mast</text>

            <!-- Trapezoidal Drainage Ditches -->
            <polygon points="40,200 50,215 70,215 80,200" fill="#0c4a6e" stroke="#0284c7" stroke-width="1" />
            <polygon points="320,200 330,215 350,215 360,200" fill="#0c4a6e" stroke="#0284c7" stroke-width="1" />
            <text x="55" y="230" fill="#38bdf8" font-size="8" text-anchor="middle">V-Ditch</text>
            <text x="345" y="230" fill="#38bdf8" font-size="8" text-anchor="middle">V-Ditch</text>
          </svg>
        </div>

        <!-- Cross Section Specifications -->
        <div class="space-y-2 p-3 rounded-lg bg-zinc-800/60 border border-white/5">
          <div class="text-[10px] text-zinc-400 uppercase font-bold">Standard Section Parameters</div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Track Gauge:</span>
            <span class="font-bold text-white">1,435.0 mm (Standard)</span>
          </div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Track Center Spacing:</span>
            <span class="font-bold text-white">5,000 mm</span>
          </div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Rail Section:</span>
            <span class="text-sky-300 font-bold">136 RE (67.4 kg/m)</span>
          </div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Fastening:</span>
            <span class="text-white">Pandrol Fastclip FE (Toe load 18 kN)</span>
          </div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Sleeper Spacing:</span>
            <span class="text-white">600 mm center-to-center</span>
          </div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Formation Width:</span>
            <span class="text-white">13.60 m (Double track bed)</span>
          </div>
          <div class="flex justify-between py-1 border-b border-white/5">
            <span class="text-zinc-400">Catenary Contact Height:</span>
            <span class="text-amber-400 font-bold">5.30 m Above Top of Rail</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class VerticalProfileComponent implements AfterViewInit {
  @ViewChild('profileCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('profileContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;

  readonly state = inject(CaltrackState);
  private platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);

  readonly selectedChainage = signal<number>(19150);
  readonly trackForm = signal<'BALLASTED' | 'SLAB'>('BALLASTED');

  private ctx!: CanvasRenderingContext2D;

  ngAfterViewInit() {
    if (!this.isBrowser) return;
    this.ctx = this.canvasRef.nativeElement.getContext('2d')!;
    this.resize();
    window.addEventListener('resize', () => {
      this.resize();
      this.drawProfile();
    });
    this.drawProfile();
  }

  resize() {
    const cont = this.containerRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;
    canvas.width = cont.clientWidth;
    canvas.height = cont.clientHeight;
  }

  drawProfile() {
    const canvas = this.canvasRef.nativeElement;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const padLeft = 70;
    const padRight = 40;
    const padTop = 40;
    const padBottom = 60;
    const graphW = canvas.width - padLeft - padRight;
    const graphH = canvas.height - padTop - padBottom;

    // Draw Grid & Axes (Elevations 30m to 150m, Chainage 0 to 250km)
    const minElev = 30;
    const maxElev = 150;
    const totalDist = 250000;

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#64748b';
    ctx.font = '10px "JetBrains Mono", monospace';

    // Elevation ticks
    for (let elev = minElev; elev <= maxElev; elev += 20) {
      const y = padTop + graphH - ((elev - minElev) / (maxElev - minElev)) * graphH;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(padLeft + graphW, y);
      ctx.stroke();
      ctx.fillText(`${elev} m`, 20, y + 3);
    }

    // Chainage ticks
    for (let ch = 0; ch <= totalDist; ch += 50000) {
      const x = padLeft + (ch / totalDist) * graphW;
      ctx.beginPath();
      ctx.moveTo(x, padTop);
      ctx.lineTo(x, padTop + graphH);
      ctx.stroke();
      ctx.fillText(this.state.formatStationing(ch), x - 20, canvas.height - 25);
    }

    // Generate Ground Profile Path & Rail Crown Path
    const groundPoints: { x: number; y: number }[] = [];
    const railPoints: { x: number; y: number }[] = [];

    for (let i = 0; i <= 250; i++) {
      const ch = i * 1000;
      const x = padLeft + (ch / totalDist) * graphW;

      // Ground elevation model
      const gElev = 52.0 + Math.sin(ch / 18000) * 12.0 + (ch / 1000) * 0.25;
      const gy = padTop + graphH - ((gElev - minElev) / (maxElev - minElev)) * graphH;
      groundPoints.push({ x, y: gy });

      // Rail elevation interpolation
      const rElev = 54.0 + (ch / 1000) * 0.24 + (ch > 58000 && ch < 63000 ? -8 : 0);
      const ry = padTop + graphH - ((rElev - minElev) / (maxElev - minElev)) * graphH;
      railPoints.push({ x, y: ry });
    }

    // Draw Cut / Fill Shading
    for (let i = 0; i < groundPoints.length - 1; i++) {
      const p1 = groundPoints[i];
      const p2 = groundPoints[i + 1];
      const r1 = railPoints[i];
      const r2 = railPoints[i + 1];

      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.lineTo(r2.x, r2.y);
      ctx.lineTo(r1.x, r1.y);
      ctx.closePath();

      if (p1.y < r1.y) {
        // Cut (ground above rail)
        ctx.fillStyle = 'rgba(217, 119, 6, 0.25)';
      } else {
        // Fill (rail above ground)
        ctx.fillStyle = 'rgba(2, 132, 199, 0.25)';
      }
      ctx.fill();
    }

    // Draw Ground Line
    ctx.beginPath();
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.8;
    groundPoints.forEach((pt, i) => {
      if (i === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();

    // Draw Rail Profile Line
    ctx.beginPath();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 3;
    railPoints.forEach((pt, i) => {
      if (i === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();

    // Draw Selected Chainage Indicator Line
    const curCh = this.selectedChainage();
    const curX = padLeft + (curCh / totalDist) * graphW;
    ctx.beginPath();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.moveTo(curX, padTop);
    ctx.lineTo(curX, padTop + graphH);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  onCanvasClick(e: MouseEvent) {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const padLeft = 70;
    const graphW = this.canvasRef.nativeElement.width - 110;
    const clickX = e.clientX - rect.left - padLeft;
    const frac = Math.max(0, Math.min(1, clickX / graphW));
    const ch = Math.round(frac * 250000);
    this.selectedChainage.set(ch);
    this.state.setChainagePointer(ch);
    this.drawProfile();
  }
}
