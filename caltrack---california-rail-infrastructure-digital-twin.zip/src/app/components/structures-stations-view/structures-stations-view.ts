import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from '../../services/caltrack-state';

@Component({
  selector: 'app-structures-stations-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-[calc(100vh-7rem)] bg-zinc-950 flex flex-col p-4 overflow-y-auto select-none font-mono text-xs">
      <!-- Section Tab Switcher -->
      <div class="bg-zinc-900 border border-white/10 rounded-xl p-3 mb-4 shadow-xl flex items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <button 
            (click)="activeSubTab.set('BRIDGES')"
            [class.bg-sky-950]="activeSubTab() === 'BRIDGES'"
            [class.border-sky-500]="activeSubTab() === 'BRIDGES'"
            [class.text-white]="activeSubTab() === 'BRIDGES'"
            [class.bg-zinc-800]="activeSubTab() !== 'BRIDGES'"
            [class.text-zinc-400]="activeSubTab() !== 'BRIDGES'"
            class="px-3 py-1.5 rounded-lg border border-white/5 font-bold flex items-center gap-1.5 transition">
            <mat-icon class="text-sm text-sky-400">account_balance</mat-icon> Bridges & Viaducts (41)
          </button>
          <button 
            (click)="activeSubTab.set('TUNNELS')"
            [class.bg-sky-950]="activeSubTab() === 'TUNNELS'"
            [class.border-sky-500]="activeSubTab() === 'TUNNELS'"
            [class.text-white]="activeSubTab() === 'TUNNELS'"
            [class.bg-zinc-800]="activeSubTab() !== 'TUNNELS'"
            [class.text-zinc-400]="activeSubTab() !== 'TUNNELS'"
            class="px-3 py-1.5 rounded-lg border border-white/5 font-bold flex items-center gap-1.5 transition">
            <mat-icon class="text-sm text-amber-400">nature</mat-icon> Tunnels & Portals (6)
          </button>
          <button 
            (click)="activeSubTab.set('STATIONS')"
            [class.bg-sky-950]="activeSubTab() === 'STATIONS'"
            [class.border-sky-500]="activeSubTab() === 'STATIONS'"
            [class.text-white]="activeSubTab() === 'STATIONS'"
            [class.bg-zinc-800]="activeSubTab() !== 'STATIONS'"
            [class.text-zinc-400]="activeSubTab() !== 'STATIONS'"
            class="px-3 py-1.5 rounded-lg border border-white/5 font-bold flex items-center gap-1.5 transition">
            <mat-icon class="text-sm text-emerald-400">corporate_fare</mat-icon> Stations & Platforms (5)
          </button>
          <button 
            (click)="activeSubTab.set('TURNOUTS')"
            [class.bg-sky-950]="activeSubTab() === 'TURNOUTS'"
            [class.border-sky-500]="activeSubTab() === 'TURNOUTS'"
            [class.text-white]="activeSubTab() === 'TURNOUTS'"
            [class.bg-zinc-800]="activeSubTab() !== 'TURNOUTS'"
            [class.text-zinc-400]="activeSubTab() !== 'TURNOUTS'"
            class="px-3 py-1.5 rounded-lg border border-white/5 font-bold flex items-center gap-1.5 transition">
            <mat-icon class="text-sm text-purple-400">call_split</mat-icon> Turnouts & Crossovers (6)
          </button>
        </div>

        <div class="text-[11px] text-zinc-400 hidden md:block">
          Corridor Assets: <strong class="text-white">47 Structures • 5 Stations</strong>
        </div>
      </div>

      <!-- Main Content Area based on sub-tab -->
      @if (activeSubTab() === 'BRIDGES' || activeSubTab() === 'TUNNELS') {
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (str of state.structures(); track str.id) {
            @if ((activeSubTab() === 'BRIDGES' && str.type === 'BRIDGE_VIADUCT') || (activeSubTab() === 'TUNNELS' && str.type === 'TUNNEL')) {
              <div class="p-4 rounded-xl bg-zinc-900 border border-white/10 space-y-3 shadow-lg hover:border-sky-500/50 transition">
                <div class="flex items-center justify-between pb-2 border-b border-white/10">
                  <div>
                    <span class="text-[10px] text-zinc-400 uppercase">{{ str.type }} • {{ str.id }}</span>
                    <div class="font-bold text-white text-sm">{{ str.name }}</div>
                  </div>
                  <span class="text-[10px] px-2 py-0.5 rounded font-bold bg-emerald-500/20 text-emerald-300">
                    {{ str.status }}
                  </span>
                </div>

                <div class="space-y-1.5 text-zinc-300 text-[11px]">
                  <div class="flex justify-between py-1 border-b border-white/5">
                    <span class="text-zinc-400">Chainage:</span>
                    <span class="font-bold text-sky-400">{{ state.formatStationing(str.startChainage) }} → {{ state.formatStationing(str.endChainage) }} ({{ state.formatDistance(str.lengthM) }})</span>
                  </div>
                  @if (str.deckType) {
                    <div class="flex justify-between py-1 border-b border-white/5">
                      <span class="text-zinc-400">Superstructure:</span>
                      <span class="text-white text-right max-w-[180px] truncate" [title]="str.deckType">{{ str.deckType }}</span>
                    </div>
                  }
                  @if (str.pierCount) {
                    <div class="flex justify-between py-1 border-b border-white/5">
                      <span class="text-zinc-400">Piers / Spans:</span>
                      <span class="font-bold text-white">{{ str.pierCount }} Piers ({{ str.spanCount }} Spans)</span>
                    </div>
                  }
                  @if (str.foundationType) {
                    <div class="flex justify-between py-1 border-b border-white/5">
                      <span class="text-zinc-400">Deep Foundation:</span>
                      <span class="text-zinc-300 text-right max-w-[180px] truncate" [title]="str.foundationType">{{ str.foundationType }}</span>
                    </div>
                  }
                  @if (str.internalDiameterM) {
                    <div class="flex justify-between py-1 border-b border-white/5">
                      <span class="text-zinc-400">Tunnel Diameter:</span>
                      <span class="font-bold text-amber-400">{{ str.internalDiameterM }} m Internal</span>
                    </div>
                  }
                  <div class="flex justify-between py-1 border-b border-white/5">
                    <span class="text-zinc-400">RSI Track Stress:</span>
                    <span class="font-bold text-emerald-400">{{ str.rsiLongitudinalStressMpa }} MPa (Limit: {{ str.allowableRsiStressMpa }} MPa)</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-white/5">
                    <span class="text-zinc-400">Seismic PGA:</span>
                    <span class="font-bold text-amber-400">{{ str.seismicPeakGroundAccG }} g</span>
                  </div>
                  <div class="flex justify-between py-1">
                    <span class="text-zinc-400">Cost Estimate:</span>
                    <span class="font-bold text-white">&#36;{{ str.costEstimateMillionsUsd }}M USD</span>
                  </div>
                </div>
              </div>
            }
          }
        </div>
      } @else if (activeSubTab() === 'STATIONS') {
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (stn of state.stations(); track stn.id) {
            <div class="p-4 rounded-xl bg-zinc-900 border border-white/10 space-y-3 shadow-lg hover:border-emerald-500/50 transition">
              <div class="flex items-center justify-between pb-2 border-b border-white/10">
                <div>
                  <span class="text-[10px] text-zinc-400 uppercase">Code: {{ stn.code }} • {{ stn.id }}</span>
                  <div class="font-bold text-white text-sm">{{ stn.name }}</div>
                </div>
                <span class="text-[10px] px-2 py-0.5 rounded font-bold bg-emerald-500/20 text-emerald-300">
                  {{ stn.status }}
                </span>
              </div>

              <div class="space-y-1.5 text-zinc-300 text-[11px]">
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Chainage:</span>
                  <span class="font-bold text-sky-400">CH {{ state.formatStationing(stn.chainage) }}</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Platforms:</span>
                  <span class="font-bold text-white">{{ stn.platformCount }} Platforms ({{ stn.platformLengthM }}m, 1250mm ATR)</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Passing Loops:</span>
                  <span class="font-bold text-white">{{ stn.passingLoopCount }} Overtake Tracks</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Scheduled Dwell:</span>
                  <span class="font-bold text-amber-400">{{ stn.scheduledDwellSeconds }} seconds</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Boarding Access:</span>
                  <span class="font-bold text-emerald-400">{{ stn.adaAccessibility }}</span>
                </div>
                <div class="flex justify-between py-1">
                  <span class="text-zinc-400">Daily Ridership Est.:</span>
                  <span class="font-bold text-white">{{ stn.projectedDailyBoardings.toLocaleString() }} pax/day</span>
                </div>
              </div>
            </div>
          }
        </div>
      } @else if (activeSubTab() === 'TURNOUTS') {
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (to of state.turnouts(); track to.id) {
            <div class="p-4 rounded-xl bg-zinc-900 border border-white/10 space-y-3 shadow-lg hover:border-purple-500/50 transition">
              <div class="flex items-center justify-between pb-2 border-b border-white/10">
                <div>
                  <span class="text-[10px] text-zinc-400 uppercase">#{{ to.turnoutNumber }} • {{ to.id }}</span>
                  <div class="font-bold text-white text-sm">{{ to.name }}</div>
                </div>
                <span class="text-[10px] px-2 py-0.5 rounded font-bold bg-purple-500/20 text-purple-300">
                  {{ to.turnoutType }}
                </span>
              </div>

              <div class="space-y-1.5 text-zinc-300 text-[11px]">
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Location:</span>
                  <span class="font-bold text-sky-400">CH {{ state.formatStationing(to.chainage) }}</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Diverging Radius:</span>
                  <span class="font-bold text-white">R = {{ to.divergingRadiusM }} m (Frog: {{ to.frogAngleDeg }}°)</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Straight Speed:</span>
                  <span class="font-bold text-emerald-400">{{ to.straightSpeedKmh }} km/h</span>
                </div>
                <div class="flex justify-between py-1 border-b border-white/5">
                  <span class="text-zinc-400">Diverging Speed:</span>
                  <span class="font-bold text-amber-400">{{ to.divergingSpeedKmh }} km/h</span>
                </div>
                <div class="flex justify-between py-1">
                  <span class="text-zinc-400">Point Machine:</span>
                  <span class="text-zinc-300">{{ to.pointMachine }}</span>
                </div>
              </div>
            </div>
          }
        </div>
      }
    </div>
  `
})
export class StructuresStationsViewComponent {
  readonly state = inject(CaltrackState);
  readonly activeSubTab = signal<'BRIDGES' | 'TUNNELS' | 'STATIONS' | 'TURNOUTS'>('BRIDGES');
}
