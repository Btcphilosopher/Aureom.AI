import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CaltrackState } from './services/caltrack-state';
import { HeaderComponent } from './components/header/header';
import { NavigationComponent } from './components/navigation/navigation';
import { DigitalTwinViewerComponent } from './components/digital-twin-viewer/digital-twin-viewer';
import { AlignmentDesignerComponent } from './components/alignment-designer/alignment-designer';
import { VerticalProfileComponent } from './components/vertical-profile/vertical-profile';
import { ConstructionSimulatorComponent } from './components/construction-simulator/construction-simulator';
import { TrainSimulatorComponent } from './components/train-simulator/train-simulator';
import { TrackInspectionComponent } from './components/track-inspection/track-inspection';
import { EarthworksMasshaulComponent } from './components/earthworks-masshaul/earthworks-masshaul';
import { GeotechnicalSeismicViewComponent } from './components/geotechnical-seismic-view/geotechnical-seismic-view';
import { EngineeringCheckerViewComponent } from './components/engineering-checker-view/engineering-checker-view';
import { StructuresStationsViewComponent } from './components/structures-stations-view/structures-stations-view';
import { CostScheduleDashboardComponent } from './components/cost-schedule-dashboard/cost-schedule-dashboard';
import { GisMapViewComponent } from './components/gis-map-view/gis-map-view';
import { ReportsExportViewComponent } from './components/reports-export-view/reports-export-view';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    NavigationComponent,
    DigitalTwinViewerComponent,
    AlignmentDesignerComponent,
    VerticalProfileComponent,
    ConstructionSimulatorComponent,
    TrainSimulatorComponent,
    TrackInspectionComponent,
    EarthworksMasshaulComponent,
    GeotechnicalSeismicViewComponent,
    EngineeringCheckerViewComponent,
    StructuresStationsViewComponent,
    CostScheduleDashboardComponent,
    GisMapViewComponent,
    ReportsExportViewComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly state = inject(CaltrackState);
}
