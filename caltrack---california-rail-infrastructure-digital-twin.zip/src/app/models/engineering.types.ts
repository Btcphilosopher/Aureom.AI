export type UnitSystem = 'METRIC_SI' | 'US_CUSTOMARY' | 'HYBRID_CA';

export type UserRole = 
  | 'PROJECT_DIRECTOR' 
  | 'RAIL_ENGINEER' 
  | 'CIVIL_ENGINEER' 
  | 'TRACK_ENGINEER' 
  | 'STRUCTURAL_ENGINEER' 
  | 'GEOTECHNICAL_ENGINEER' 
  | 'CONSTRUCTION_MANAGER' 
  | 'SURVEYOR' 
  | 'PLANNER' 
  | 'OPERATIONS' 
  | 'MAINTENANCE' 
  | 'ADMIN';

export type ProjectStatus = 
  | 'PRELIMINARY' 
  | 'DESIGN_30' 
  | 'DESIGN_60' 
  | 'DESIGN_90' 
  | 'IFC' 
  | 'AS_BUILT';

export interface AlignmentElement {
  id: string;
  name: string;
  type: 'TANGENT' | 'CIRCULAR_CURVE' | 'SPIRAL_CLOTHOID';
  startChainage: number; // in meters (e.g. 0 = 000+000)
  endChainage: number;
  length: number;
  startX: number; // California State Plane Zone IV Easting (m)
  startY: number; // Northing (m)
  endX: number;
  endY: number;
  radius: number; // meters (0 for tangent)
  deflectionAngleDeg: number;
  bearingDeg: number;
  cantMm: number; // Ea applied superelevation
  cantDeficiencyMm: number; // Ed
  designSpeedKmh: number;
  rateOfCantChangeMmS: number;
  transitionSpiralLength: number; // Ls
}

export interface VerticalPVI {
  id: string;
  chainage: number; // stationing (m)
  elevation: number; // m above NAVD88
  gradeInPct: number;
  gradeOutPct: number;
  curveLength: number; // m
  curveType: 'CREST' | 'SAG' | 'CONSTANT_GRADE';
  kValue: number; // m per %
  allowableSpeedKmh: number;
}

export interface TrackSectionConfig {
  chainage: number;
  trackType: 'BALLASTED' | 'SLAB_RHEDA2000' | 'SLAB_LVT';
  railProfile: '136RE' | '141RE' | 'UIC60';
  fasteningSystem: 'Pandrol Fastclip FE' | 'Vossloh W30' | 'Sonneville LVT';
  sleeperType: 'Prestressed Concrete Monoblock' | 'Bi-Block Concrete' | 'Direct Fastened Plinth';
  sleeperSpacingMm: number;
  ballastDepthMm: number;
  subballastDepthMm: number;
  formationWidthM: number;
  drainageType: 'Trapezoidal V-Ditch' | 'Reinforced Concrete U-Channel' | 'Subsurface Perforated Collector';
  embankmentSlope: string;
}

export interface EarthworkStation {
  chainage: number;
  groundElevation: number;
  formationElevation: number;
  cutOrFill: 'CUT' | 'FILL' | 'GRADE';
  heightM: number;
  cutAreaM2: number;
  fillAreaM2: number;
  incrementalCutM3: number;
  incrementalFillM3: number;
  cumulativeCutM3: number;
  cumulativeFillM3: number;
  massHaulOrdinateM3: number; // Net algebraic sum (cut - fill*shrinkage)
  haulDistanceKm: number;
}

export interface StructureItem {
  id: string;
  name: string;
  type: 'BRIDGE_VIADUCT' | 'TUNNEL' | 'CULVERT' | 'RETAINING_WALL' | 'SPECIAL_AERIAL_CROSSING';
  startChainage: number;
  endChainage: number;
  lengthM: number;
  deckType?: string;
  pierCount?: number;
  spanCount?: number;
  foundationType?: string;
  internalDiameterM?: number;
  tunnelLining?: string;
  loadModelRating?: string;
  seismicPeakGroundAccG: number;
  rsiLongitudinalStressMpa: number; // Rail-Structure Interaction stress
  allowableRsiStressMpa: number;
  status: 'DESIGN_COMPLETE' | 'UNDER_ANALYSIS' | 'UNDER_CONSTRUCTION' | 'COMMISSIONED';
  costEstimateMillionsUsd: number;
}

export interface StationItem {
  id: string;
  name: string;
  chainage: number;
  code: string;
  platformCount: number;
  platformLengthM: number;
  platformHeightMm: number;
  passingLoopCount: number;
  turnbackProvision: boolean;
  scheduledDwellSeconds: number;
  adaAccessibility: 'Full Level-Boarding' | 'High-Block Ramp';
  projectedDailyBoardings: number;
  status: 'DESIGN_VERIFIED' | 'STAGE_2_CONSTRUCTION';
}

export interface TurnoutItem {
  id: string;
  name: string;
  chainage: number;
  turnoutNumber: number; // e.g., 10, 15, 20, 32.7
  turnoutType: 'SIMPLE_TURNOUT' | 'CROSSOVER' | 'DOUBLE_CROSSOVER' | 'SLIP_SWITCH';
  divergingRadiusM: number;
  frogAngleDeg: number;
  switchRailLengthM: number;
  straightSpeedKmh: number;
  divergingSpeedKmh: number;
  pointMachine: 'In-Sleeper Electro-Hydraulic' | 'M23A Mechanical Switch Machine';
  installationTrack: string;
}

export interface GeotechnicalBorehole {
  id: string;
  chainage: number;
  offsetM: number;
  groundElevationM: number;
  waterTableDepthM: number;
  pgaDesignG: number;
  layers: {
    depthStartM: number;
    depthEndM: number;
    stratumName: string;
    soilClass: string;
    sptNValue: number;
    frictionAngleDeg: number;
    cohesionKpa: number;
    densityKnM3: number;
    colorHex: string;
    liquefactionSusceptible: boolean;
  }[];
  liquefactionFactorOfSafety: number;
  bearingCapacityKpa: number;
  geotechStatus: 'PASS' | 'REVIEW' | 'FAIL';
}

export interface SeismicFaultCrossing {
  id: string;
  faultName: string;
  chainage: number;
  faultMechanism: 'Strike-Slip' | 'Normal-Oblique' | 'Reverse Thrust';
  slipRateMmYear: number;
  maxDesignDisplacementM: number;
  articulationJointSpacingM: number;
  monitoringSensorCount: number;
  status: 'SEISMIC_JOINT_DESIGNED' | 'UNDER_PEER_REVIEW';
}

export interface ConstructionStage4D {
  id: string;
  wbsCode: string;
  taskName: string;
  category: 
    | 'LAND_ACQUISITION'
    | 'SITE_CLEARANCE'
    | 'UTILITY_RELOCATION'
    | 'EARTHWORKS'
    | 'DRAINAGE'
    | 'STRUCTURES'
    | 'FORMATION'
    | 'BALLAST_SUBBALLAST'
    | 'SLEEPER_RAIL_LAYING'
    | 'TURNOUTS_SPECIAL'
    | 'ELECTRIFICATION_OCS'
    | 'SIGNALLING_CBTC'
    | 'TESTING_COMMISSIONING';
  startMonthOffset: number; // 0 to 72 months (2027 to 2033)
  durationMonths: number;
  progressPercent: number;
  dependencies: string[];
  assignedMachines: string[];
  plannedCostUsdMillions: number;
  actualCostUsdMillions: number;
  criticalPath: boolean;
  gangCount: number;
}

export interface ConstructionMachine {
  id: string;
  name: string;
  type: string;
  dailyProductivity: string;
  activeChainageM: number;
  status: 'OPERATING' | 'MOBILIZING' | 'SCHEDULED_MAINTENANCE' | 'STANDBY';
  utilizationPct: number;
  powerSource: 'Electric Hybrid' | 'Tier 4 Final Diesel' | 'High-Tension Catenary';
  crewRequired: number;
}

export interface TrainDynamicsState {
  trainId: string;
  trainName: string;
  trainType: 'HIGH_SPEED_EMU' | 'INTERCITY_BI_MODE' | 'COMMUTER_BILEVEL' | 'HEAVY_FREIGHT_INTERMODAL';
  trainLengthM: number;
  totalMassTonnes: number;
  maxPowerKw: number;
  maxTractiveEffortKn: number;
  maxBrakingForceKn: number;
  currentChainageM: number;
  currentSpeedKmh: number;
  targetSpeedKmh: number;
  accelerationMs2: number;
  gradientPct: number;
  curvature1OverM: number;
  tractiveForceKn: number;
  davisTotalResistanceKn: number;
  powerOutputMw: number;
  energyConsumedKwh: number;
  timeElapsedSec: number;
  signalAspect: 'CLEAR_GREEN' | 'ADVANCE_YELLOW' | 'APPROACH_YELLOW' | 'STOP_RED';
  cabAlerts: string[];
}

export interface TrackDefect {
  id: string;
  chainageM: number;
  milepost: string;
  defectParameter: 'GAUGE_VARIATION' | 'CROSS_LEVEL' | 'TWIST_3M' | 'VERTICAL_PROFILE' | 'ALIGNMENT_DEVIATION';
  measuredValueMm: number;
  thresholdLimitMm: number;
  deviationMm: number;
  severity: 'NORMAL_TOLERANCE' | 'MAINTENANCE_ADVISORY' | 'URGENT_INTERVENTION';
  detectedByVehicle: string;
  inspectionTimestamp: string;
  remedialAction: string;
  workOrderNumber?: string;
  resolved: boolean;
}

export interface EngineeringCheckRule {
  id: string;
  category: 
    | 'ALIGNMENT_GEOMETRY' 
    | 'VERTICAL_PROFILE' 
    | 'TRACK_STRUCTURE' 
    | 'BRIDGE_VIADUCT' 
    | 'TUNNEL_AERODYNAMICS' 
    | 'DRAINAGE_HYDROLOGY' 
    | 'GEOTECHNICAL_SEISMIC' 
    | 'CLEARANCE_ENVELOPE' 
    | 'CONSTRUCTION_LOGISTICS' 
    | 'OPERATIONAL_HEADWAY';
  ruleCode: string;
  title: string;
  description: string;
  formula: string;
  inputParameters: Record<string, string | number>;
  calculatedValue: string;
  designLimit: string;
  marginOfSafety: string;
  status: 'PASS' | 'REVIEW' | 'WARNING' | 'FAIL';
  referenceStandard: string;
  governingAuthority: string;
  lastEvaluated: string;
}

export interface BIMObjectInfo {
  guid: string;
  ifcClass: 'IfcRail' | 'IfcTrack' | 'IfcBridge' | 'IfcTunnel' | 'IfcAlignment' | 'IfcSite' | 'IfcGeotechnicalBorehole';
  elementName: string;
  chainageRange: string;
  material: string;
  volumeM3?: number;
  weightTonnes?: number;
  carbonEmbodiedTCo2e?: number;
  versionChangeStatus: 'UNCHANGED' | 'ADDED' | 'MODIFIED' | 'MOVED';
  attributes: Record<string, string | number>;
}

export interface DesignAlternative {
  id: string;
  name: string;
  corridorCode: string;
  description: string;
  routeLengthKm: number;
  curveLengthPct: number;
  maxGradientPct: number;
  bridgesCount: number;
  tunnelsCount: number;
  earthworksCutFillM3: string;
  estimatedCostBillionUsd: number;
  constructionMonths: number;
  transitTimeMinutes: number;
  tractionEnergyMwh: number;
  seismicHazardIndex: 'Low-Medium' | 'Moderate' | 'High (Fault-Adjacent)';
}
