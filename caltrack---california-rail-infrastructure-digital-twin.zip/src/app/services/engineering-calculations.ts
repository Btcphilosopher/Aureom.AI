import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EngineeringCalculations {

  /**
   * Calculate maximum permissible railway curve speed given radius, cant and cant deficiency.
   * Formula: V = sqrt( (R * (Ea + Ed)) / 11.8 )
   * (AREMA Manual for Railway Engineering Ch 5 & CHSR TM 2.1.2)
   */
  calculatePermissibleSpeed(radiusM: number, cantMm: number, cantDeficiencyMm: number): number {
    if (radiusM <= 0) return 350; // Tangent track default limit
    const totalSuperelevation = Math.max(0, cantMm + cantDeficiencyMm);
    const speedKmh = Math.sqrt((radiusM * totalSuperelevation) / 11.8);
    return Math.round(speedKmh * 10) / 10;
  }

  /**
   * Calculate required minimum spiral transition length (Clothoid)
   * Formula: Ls = max( (V * Ea) / 198, (V * Ed) / 198, 0.008 * Ea * V )
   */
  calculateMinimumSpiralLength(speedKmh: number, cantMm: number, cantDeficiencyMm: number): number {
    if (speedKmh <= 0 || cantMm <= 0) return 0;
    const l1 = (speedKmh * cantMm) / 198;
    const l2 = (speedKmh * cantDeficiencyMm) / 198;
    const l3 = 0.008 * cantMm * speedKmh;
    const minLen = Math.max(l1, l2, l3, 60); // 60m standard minimum high speed spiral
    return Math.ceil(minLen);
  }

  /**
   * Calculate rate of cant change (twist gradient over transition)
   * da/dt = (Ea / Ls) * (V / 3.6) (mm/s)
   * Standard limit: <= 50 mm/s for exceptional, <= 35 mm/s desirable
   */
  calculateRateOfCantChange(cantMm: number, spiralLengthM: number, speedKmh: number): number {
    if (spiralLengthM <= 0) return 0;
    const speedMs = speedKmh / 3.6;
    const rateMmS = (cantMm / spiralLengthM) * speedMs;
    return Math.round(rateMmS * 10) / 10;
  }

  /**
   * Davis Train Resistance Equation:
   * R_total = A + B*v + C*v^2 + F_grade + F_curve (kN)
   * Where A = mechanical rolling resistance (kN), B = flange friction (kN/(km/h)), C = aerodynamic drag coefficient
   */
  calculateTrainResistance(
    trainMassTonnes: number,
    speedKmh: number,
    gradePct: number,
    radiusM: number,
    trainType: 'HIGH_SPEED_EMU' | 'INTERCITY_BI_MODE' | 'COMMUTER_BILEVEL' | 'HEAVY_FREIGHT_INTERMODAL'
  ): {
    rollingKn: number;
    flangeKn: number;
    aeroKn: number;
    gradeKn: number;
    curveKn: number;
    totalResistanceKn: number;
  } {
    // Coefficients customized per rolling stock class (Metric SI adjusted)
    let A = 0.0015 * trainMassTonnes * 9.81; // kN
    let B = 0.00003 * trainMassTonnes * 9.81; // kN / (km/h)
    let C = 0.00045; // Aerodynamic drag kN / (km/h)^2 for streamlined HSR nose

    if (trainType === 'HEAVY_FREIGHT_INTERMODAL') {
      A = 0.0022 * trainMassTonnes * 9.81;
      B = 0.00005 * trainMassTonnes * 9.81;
      C = 0.0035; // Bluff body double stack freight
    } else if (trainType === 'COMMUTER_BILEVEL') {
      A = 0.0018 * trainMassTonnes * 9.81;
      B = 0.00004 * trainMassTonnes * 9.81;
      C = 0.00095;
    }

    const rollingKn = A;
    const flangeKn = B * speedKmh;
    const aeroKn = C * Math.pow(speedKmh, 2);
    
    // Grade force: F_g = m * g * sin(theta) ~= m * g * (grade% / 100)
    const gradeKn = (trainMassTonnes * 9.81 * (gradePct / 100));

    // Curvature force: Empirical formula F_c = (700 / R) * m * g / 1000 (kN)
    const curveKn = radiusM > 0 ? (700 / radiusM) * (trainMassTonnes * 9.81 / 1000) : 0;

    const total = rollingKn + flangeKn + aeroKn + gradeKn + curveKn;

    return {
      rollingKn: +rollingKn.toFixed(2),
      flangeKn: +flangeKn.toFixed(2),
      aeroKn: +aeroKn.toFixed(2),
      gradeKn: +gradeKn.toFixed(2),
      curveKn: +curveKn.toFixed(2),
      totalResistanceKn: +total.toFixed(2)
    };
  }

  /**
   * Earthwork trapezoidal cross section cut / fill area
   */
  calculateCrossSectionArea(
    heightM: number, // positive = cut, negative = fill
    formationWidthM = 13.6,
    sideSlopeRatio = 1.5 // 1:1.5 (V:H)
  ): { areaM2: number; topWidthM: number } {
    const absH = Math.abs(heightM);
    const topWidthM = formationWidthM + 2 * (sideSlopeRatio * absH);
    const areaM2 = ((formationWidthM + topWidthM) / 2) * absH;
    return {
      areaM2: +areaM2.toFixed(2),
      topWidthM: +topWidthM.toFixed(2)
    };
  }

  /**
   * Culvert flow using Manning's Equation:
   * Q = (1 / n) * A * R_h^(2/3) * S^(1/2)
   */
  calculateCulvertCapacity(
    pipeDiameterM: number,
    slopeFraction: number,
    manningsN = 0.013 // Smooth concrete pipe
  ): { dischargeM3s: number; velocityMs: number; status: 'ADEQUATE' | 'SURCHARGED' } {
    const radius = pipeDiameterM / 2;
    const area = Math.PI * Math.pow(radius, 2);
    const wettedPerimeter = 2 * Math.PI * radius;
    const hydraulicRadius = area / wettedPerimeter;
    const slope = Math.max(0.001, slopeFraction);
    
    const velocityMs = (1 / manningsN) * Math.pow(hydraulicRadius, 2/3) * Math.sqrt(slope);
    const dischargeM3s = velocityMs * area;

    return {
      dischargeM3s: +dischargeM3s.toFixed(2),
      velocityMs: +velocityMs.toFixed(2),
      status: velocityMs < 4.5 && velocityMs > 0.8 ? 'ADEQUATE' : 'SURCHARGED'
    };
  }

  /**
   * Continuous Welded Rail (CWR) Thermal Stress
   * sigma_thermal = E * alpha * DeltaT (MPa)
   * Where E = 210,000 MPa (Rail steel), alpha = 1.15e-5 / deg C
   */
  calculateCwrThermalStress(railTempC: number, neutralTempC = 38): {
    tempDiffC: number;
    stressMpa: number;
    stressType: 'TENSION' | 'COMPRESSION';
    safetyRatio: number;
  } {
    const deltaT = railTempC - neutralTempC;
    const E = 210000; // MPa
    const alpha = 0.0000115; // 1/deg C
    const stressMpa = Math.abs(E * alpha * deltaT);
    const stressType = deltaT < 0 ? 'TENSION' : 'COMPRESSION';
    const allowableStress = stressType === 'TENSION' ? 72 : 90; // MPa
    const safetyRatio = allowableStress / Math.max(1, stressMpa);

    return {
      tempDiffC: deltaT,
      stressMpa: +stressMpa.toFixed(1),
      stressType,
      safetyRatio: +safetyRatio.toFixed(2)
    };
  }

  /**
   * Soil Liquefaction Triggering Factor of Safety (Seed & Idriss)
   * FS = CRR / CSR
   */
  calculateLiquefactionSafety(
    sptN160: number,
    pgaG: number,
    totalVerticalStressKpa: number,
    effectiveVerticalStressKpa: number,
    earthquakeMw = 7.5
  ): {
    csr: number;
    crr: number;
    fs: number;
    evaluation: 'PASS' | 'REVIEW' | 'FAIL';
  } {
    // Cyclic Stress Ratio
    const rd = 1.0 - 0.00765 * 10; // depth ~ 10m average
    const csr = 0.65 * (pgaG) * (totalVerticalStressKpa / Math.max(1, effectiveVerticalStressKpa)) * rd;
    
    // Cyclic Resistance Ratio approximation based on clean-sand corrected SPT (N1)60
    const crr = 1 / (34 - Math.min(30, sptN160)) + sptN160 / 135 + 50 / Math.pow(10 * sptN160 + 45, 2) - 1 / 200;
    const msf = Math.pow(earthquakeMw / 7.5, -2.56); // Magnitude scaling factor
    const adjustedCrr = Math.max(0.05, crr * msf);

    const fs = adjustedCrr / Math.max(0.01, csr);

    return {
      csr: +csr.toFixed(3),
      crr: +adjustedCrr.toFixed(3),
      fs: +fs.toFixed(2),
      evaluation: fs >= 1.2 ? 'PASS' : fs >= 1.0 ? 'REVIEW' : 'FAIL'
    };
  }
}
