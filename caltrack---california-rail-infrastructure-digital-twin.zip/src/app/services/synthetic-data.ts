import { Injectable } from '@angular/core';
import {
  AlignmentElement,
  VerticalPVI,
  StructureItem,
  StationItem,
  TurnoutItem,
  GeotechnicalBorehole,
  SeismicFaultCrossing,
  ConstructionStage4D,
  ConstructionMachine,
  TrackDefect,
  EngineeringCheckRule,
  BIMObjectInfo,
  DesignAlternative,
  EarthworkStation
} from '../models/engineering.types';

@Injectable({
  providedIn: 'root'
})
export class SyntheticDataService {

  // Statewide Regions & Nodes for GIS Digital Twin
  readonly californiaRegions = [
    {
      name: 'Northern California',
      corridors: ['Capitol Corridor (Sacramento - San Jose)', 'Bay Area Electrification (SF - Gilroy)', 'Roseville Northern Gateway'],
      nodes: [
        { name: 'Sacramento Valley Station', code: 'SAC', lat: 38.584, lon: -121.500, type: 'TERMINAL' },
        { name: 'Oakland Jack London Square', code: 'OKJ', lat: 37.794, lon: -122.273, type: 'INTERMODAL' },
        { name: 'San Francisco Salesforce Transit Center', code: 'SFT', lat: 37.789, lon: -122.397, type: 'TERMINAL' },
        { name: 'San Jose Diridon Station', code: 'SJD', lat: 37.330, lon: -121.903, type: 'HUB' },
        { name: 'Davis Junction', code: 'DAV', lat: 38.543, lon: -121.737, type: 'PASSENGER' },
        { name: 'Martinez Regional', code: 'MTZ', lat: 38.019, lon: -122.138, type: 'PASSENGER' },
        { name: 'Stockton Robert J. Cabral', code: 'SKT', lat: 37.957, lon: -121.285, type: 'INTERCHANGE' }
      ]
    },
    {
      name: 'Central Valley Corridor (Core HSR & Freight)',
      corridors: ['Central Valley North-South High-Speed Spine', 'BNSF San Joaquin Freight Mainline', 'UP Fresno Sub'],
      nodes: [
        { name: 'Merced Regional HSR Terminal', code: 'MCD', lat: 37.306, lon: -120.478, type: 'STATION_HSR' },
        { name: 'Madera Gateway Station', code: 'MAD', lat: 36.980, lon: -120.060, type: 'STATION_HSR' },
        { name: 'Fresno Downtown Station', code: 'FNO', lat: 36.737, lon: -119.787, type: 'STATION_HSR' },
        { name: 'Kings/Tulare Regional Station', code: 'KTR', lat: 36.327, lon: -119.645, type: 'STATION_HSR' },
        { name: 'Bakersfield Central Station', code: 'BFD', lat: 35.373, lon: -119.018, type: 'STATION_HSR' },
        { name: 'Visalia Freight Yard', code: 'VIS', lat: 36.330, lon: -119.292, type: 'YARD' },
        { name: 'Hanford Junction', code: 'HNF', lat: 36.327, lon: -119.645, type: 'JUNCTION' }
      ]
    },
    {
      name: 'Southern California',
      corridors: ['Lossan Coastal Corridor', 'Palmdale - Burbank High-Speed Tunnel', 'Metrolink San Bernardino Line'],
      nodes: [
        { name: 'Los Angeles Union Station', code: 'LAX', lat: 34.056, lon: -118.236, type: 'MAJOR_TERMINAL' },
        { name: 'Anaheim ARTIC Hub', code: 'ANA', lat: 33.803, lon: -117.878, type: 'STATION' },
        { name: 'Palmdale Transportation Center', code: 'PMD', lat: 34.580, lon: -118.116, type: 'HSR_JUNCTION' },
        { name: 'San Bernardino Santa Fe Depot', code: 'SNB', lat: 34.108, lon: -117.311, type: 'HUB' },
        { name: 'Riverside Downtown', code: 'RIV', lat: 33.980, lon: -117.373, type: 'STATION' },
        { name: 'San Diego Santa Fe Depot', code: 'SAN', lat: 32.716, lon: -117.169, type: 'TERMINAL' }
      ]
    },
    {
      name: 'Central Coast',
      corridors: ['Coast Daylight Route', 'Salinas Valley Agricultural Freight Line'],
      nodes: [
        { name: 'Santa Barbara Station', code: 'SBA', lat: 34.414, lon: -119.693, type: 'STATION' },
        { name: 'San Luis Obispo Station', code: 'SLO', lat: 35.276, lon: -120.654, type: 'STATION' },
        { name: 'Salinas Intermodal Hub', code: 'SNS', lat: 36.677, lon: -121.655, type: 'INTERMODAL' },
        { name: 'Monterey Peninsula Connection', code: 'MRY', lat: 36.600, lon: -121.894, type: 'BRANCH' }
      ]
    }
  ];

  // Central Valley Test Corridor Horizontal Alignment (250 km from Merced to Bakersfield)
  getCentralValleyAlignment(): AlignmentElement[] {
    return [
      {
        id: 'ALIGN-001',
        name: 'Merced Northern Approach Tangent',
        type: 'TANGENT',
        startChainage: 0,
        endChainage: 18500,
        length: 18500,
        startX: 2045000,
        startY: 650000,
        endX: 2058000,
        endY: 636800,
        radius: 0,
        deflectionAngleDeg: 0,
        bearingDeg: 142.5,
        cantMm: 0,
        cantDeficiencyMm: 0,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 0,
        transitionSpiralLength: 0
      },
      {
        id: 'ALIGN-002',
        name: 'San Joaquin River Approach Spiral TS-1',
        type: 'SPIRAL_CLOTHOID',
        startChainage: 18500,
        endChainage: 19150,
        length: 650,
        startX: 2058000,
        startY: 636800,
        endX: 2058450,
        endY: 636320,
        radius: 7200,
        deflectionAngleDeg: 2.6,
        bearingDeg: 143.8,
        cantMm: 120,
        cantDeficiencyMm: 45,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 18.0,
        transitionSpiralLength: 650
      },
      {
        id: 'ALIGN-003',
        name: 'San Joaquin River Viaduct Curve SC-1',
        type: 'CIRCULAR_CURVE',
        startChainage: 19150,
        endChainage: 23800,
        length: 4650,
        startX: 2058450,
        startY: 636320,
        endX: 2061800,
        endY: 633100,
        radius: 7200,
        deflectionAngleDeg: 36.9,
        bearingDeg: 161.0,
        cantMm: 120,
        cantDeficiencyMm: 45,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 0,
        transitionSpiralLength: 650
      },
      {
        id: 'ALIGN-004',
        name: 'Madera Southbound Tangent',
        type: 'TANGENT',
        startChainage: 23800,
        endChainage: 58200,
        length: 34400,
        startX: 2061800,
        startY: 633100,
        endX: 2086200,
        endY: 608800,
        radius: 0,
        deflectionAngleDeg: 0,
        bearingDeg: 135.0,
        cantMm: 0,
        cantDeficiencyMm: 0,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 0,
        transitionSpiralLength: 0
      },
      {
        id: 'ALIGN-005',
        name: 'Fresno Trench & Downtown Curve',
        type: 'CIRCULAR_CURVE',
        startChainage: 58200,
        endChainage: 63500,
        length: 5300,
        startX: 2086200,
        startY: 608800,
        endX: 2090100,
        endY: 605100,
        radius: 5500,
        deflectionAngleDeg: 28.4,
        bearingDeg: 148.2,
        cantMm: 145,
        cantDeficiencyMm: 60,
        designSpeedKmh: 310,
        rateOfCantChangeMmS: 24.5,
        transitionSpiralLength: 580
      },
      {
        id: 'ALIGN-006',
        name: 'Kings River High-Speed Tangent',
        type: 'TANGENT',
        startChainage: 63500,
        endChainage: 114000,
        length: 50500,
        startX: 2090100,
        startY: 605100,
        endX: 2125800,
        endY: 569400,
        radius: 0,
        deflectionAngleDeg: 0,
        bearingDeg: 135.0,
        cantMm: 0,
        cantDeficiencyMm: 0,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 0,
        transitionSpiralLength: 0
      },
      {
        id: 'ALIGN-007',
        name: 'Hanford / Kings-Tulare Curve',
        type: 'CIRCULAR_CURVE',
        startChainage: 114000,
        endChainage: 121200,
        length: 7200,
        startX: 2125800,
        startY: 569400,
        endX: 2131000,
        endY: 564200,
        radius: 8000,
        deflectionAngleDeg: 25.8,
        bearingDeg: 145.0,
        cantMm: 110,
        cantDeficiencyMm: 38,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 14.2,
        transitionSpiralLength: 720
      },
      {
        id: 'ALIGN-008',
        name: 'Wasco – Shafter Long Tangent',
        type: 'TANGENT',
        startChainage: 121200,
        endChainage: 198000,
        length: 76800,
        startX: 2131000,
        startY: 564200,
        endX: 2185300,
        endY: 509900,
        radius: 0,
        deflectionAngleDeg: 0,
        bearingDeg: 135.0,
        cantMm: 0,
        cantDeficiencyMm: 0,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 0,
        transitionSpiralLength: 0
      },
      {
        id: 'ALIGN-009',
        name: 'Bakersfield North Gateway Curve',
        type: 'CIRCULAR_CURVE',
        startChainage: 198000,
        endChainage: 206400,
        length: 8400,
        startX: 2185300,
        startY: 509900,
        endX: 2191500,
        endY: 503800,
        radius: 6400,
        deflectionAngleDeg: 37.6,
        bearingDeg: 153.8,
        cantMm: 135,
        cantDeficiencyMm: 50,
        designSpeedKmh: 330,
        rateOfCantChangeMmS: 20.1,
        transitionSpiralLength: 640
      },
      {
        id: 'ALIGN-010',
        name: 'Bakersfield Terminal Approach',
        type: 'TANGENT',
        startChainage: 206400,
        endChainage: 250000,
        length: 43600,
        startX: 2191500,
        startY: 503800,
        endX: 2222300,
        endY: 473000,
        radius: 0,
        deflectionAngleDeg: 0,
        bearingDeg: 135.0,
        cantMm: 0,
        cantDeficiencyMm: 0,
        designSpeedKmh: 350,
        rateOfCantChangeMmS: 0,
        transitionSpiralLength: 0
      }
    ];
  }

  // Vertical Profile PVIs
  getCentralValleyVerticalProfile(): VerticalPVI[] {
    return [
      { id: 'PVI-01', chainage: 0, elevation: 52.0, gradeInPct: 0.0, gradeOutPct: 0.35, curveLength: 0, curveType: 'CONSTANT_GRADE', kValue: 0, allowableSpeedKmh: 350 },
      { id: 'PVI-02', chainage: 19500, elevation: 58.8, gradeInPct: 0.35, gradeOutPct: -0.42, curveLength: 2400, curveType: 'CREST', kValue: 312, allowableSpeedKmh: 350 },
      { id: 'PVI-03', chainage: 42000, elevation: 49.4, gradeInPct: -0.42, gradeOutPct: 0.65, curveLength: 3200, curveType: 'SAG', kValue: 299, allowableSpeedKmh: 350 },
      { id: 'PVI-04', chainage: 59000, elevation: 60.5, gradeInPct: 0.65, gradeOutPct: -1.85, curveLength: 4100, curveType: 'CREST', kValue: 164, allowableSpeedKmh: 310 }, // Fresno Trench descent
      { id: 'PVI-05', chainage: 62500, elevation: 54.0, gradeInPct: -1.85, gradeOutPct: 0.88, curveLength: 3600, curveType: 'SAG', kValue: 132, allowableSpeedKmh: 310 },
      { id: 'PVI-06', chainage: 115000, elevation: 76.5, gradeInPct: 0.88, gradeOutPct: 0.15, curveLength: 2800, curveType: 'CREST', kValue: 384, allowableSpeedKmh: 350 },
      { id: 'PVI-07', chainage: 160000, elevation: 83.3, gradeInPct: 0.15, gradeOutPct: 1.12, curveLength: 3500, curveType: 'SAG', kValue: 361, allowableSpeedKmh: 350 },
      { id: 'PVI-08', chainage: 202000, elevation: 130.4, gradeInPct: 1.12, gradeOutPct: -0.55, curveLength: 4800, curveType: 'CREST', kValue: 287, allowableSpeedKmh: 330 },
      { id: 'PVI-09', chainage: 250000, elevation: 104.0, gradeInPct: -0.55, gradeOutPct: 0.0, curveLength: 2000, curveType: 'SAG', kValue: 364, allowableSpeedKmh: 350 }
    ];
  }

  // Key Structures (47 Total in project - showing representative high-speed bridges & tunnels)
  getStructures(): StructureItem[] {
    return [
      {
        id: 'STR-01',
        name: 'San Joaquin River Viaduct & Pergola',
        type: 'BRIDGE_VIADUCT',
        startChainage: 19100,
        endChainage: 23800,
        lengthM: 4700,
        deckType: 'Post-Tensioned Concrete Box Girder (Cast-in-Place / Segmental)',
        pierCount: 118,
        spanCount: 117,
        foundationType: 'Cast-in-Drilled-Hole (CIDH) Deep Concrete Piles (dia 2.4m)',
        seismicPeakGroundAccG: 0.52,
        rsiLongitudinalStressMpa: 48.2,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 462.5
      },
      {
        id: 'STR-02',
        name: 'Fresno Downtown Trench & Caltrans SR-180 Underpass',
        type: 'TUNNEL',
        startChainage: 58800,
        endChainage: 62400,
        lengthM: 3600,
        internalDiameterM: 14.2,
        tunnelLining: 'Cut-and-Cover Reinforced Slurry Diaphragm Wall with Roof Slab',
        seismicPeakGroundAccG: 0.48,
        rsiLongitudinalStressMpa: 36.4,
        allowableRsiStressMpa: 72.0,
        status: 'UNDER_CONSTRUCTION',
        costEstimateMillionsUsd: 388.0
      },
      {
        id: 'STR-03',
        name: 'Cedar Viaduct High-Speed Arch Span',
        type: 'BRIDGE_VIADUCT',
        startChainage: 64200,
        endChainage: 65300,
        lengthM: 1100,
        deckType: 'Cast-in-Place Cast Arch Tied Superstructure over SR-99',
        pierCount: 26,
        spanCount: 25,
        foundationType: 'CIDH Piles with Precast Seismic Isolators',
        seismicPeakGroundAccG: 0.55,
        rsiLongitudinalStressMpa: 52.1,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 145.0
      },
      {
        id: 'STR-04',
        name: 'Kings River Viaduct & Floodplain Span',
        type: 'BRIDGE_VIADUCT',
        startChainage: 91500,
        endChainage: 94800,
        lengthM: 3300,
        deckType: 'Prestressed Precast Concrete U-Girders',
        pierCount: 82,
        spanCount: 81,
        foundationType: 'Driven Steel H-Piles in Alluvial Gravels',
        seismicPeakGroundAccG: 0.44,
        rsiLongitudinalStressMpa: 41.5,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 310.0
      },
      {
        id: 'STR-05',
        name: 'Cross Creek Viaduct',
        type: 'BRIDGE_VIADUCT',
        startChainage: 112000,
        endChainage: 113400,
        lengthM: 1400,
        deckType: 'Continuous Steel Plate Girder Composite Deck',
        pierCount: 35,
        spanCount: 34,
        foundationType: 'CIDH Piles with Ground Anchor Tiebacks',
        seismicPeakGroundAccG: 0.46,
        rsiLongitudinalStressMpa: 39.8,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 122.0
      },
      {
        id: 'STR-06',
        name: 'Hanford North Viaduct & BNSF Flyover',
        type: 'BRIDGE_VIADUCT',
        startChainage: 118200,
        endChainage: 122500,
        lengthM: 4300,
        deckType: 'Segmental Post-Tensioned Concrete Box Girder with High-Speed Pergola',
        pierCount: 108,
        spanCount: 107,
        foundationType: 'CIDH 3.0m diameter shafts',
        seismicPeakGroundAccG: 0.49,
        rsiLongitudinalStressMpa: 54.0,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 415.0
      },
      {
        id: 'STR-07',
        name: 'Wasco Viaduct & Highway 46 Grade Separation',
        type: 'BRIDGE_VIADUCT',
        startChainage: 168000,
        endChainage: 171800,
        lengthM: 3800,
        deckType: 'Precast Concrete Box Beams with Continuously Reinforced Deck',
        pierCount: 95,
        spanCount: 94,
        foundationType: 'CIDH Deep Piles',
        seismicPeakGroundAccG: 0.58,
        rsiLongitudinalStressMpa: 58.6,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 360.0
      },
      {
        id: 'STR-08',
        name: 'Pacheco Pass Pilot Twin-Bore Exploration Tunnel',
        type: 'TUNNEL',
        startChainage: 198400,
        endChainage: 204200,
        lengthM: 5800,
        internalDiameterM: 8.8,
        tunnelLining: 'Precast Segmental Concrete Rings with Dual Neoprene Waterproof Gaskets',
        seismicPeakGroundAccG: 0.68,
        rsiLongitudinalStressMpa: 28.5,
        allowableRsiStressMpa: 72.0,
        status: 'DESIGN_COMPLETE',
        costEstimateMillionsUsd: 840.0
      }
    ];
  }

  // Stations
  getStations(): StationItem[] {
    return [
      {
        id: 'STN-01',
        name: 'Merced Regional Intermodal Terminal',
        code: 'MCD',
        chainage: 1200,
        platformCount: 4,
        platformLengthM: 450,
        platformHeightMm: 1250,
        passingLoopCount: 2,
        turnbackProvision: true,
        scheduledDwellSeconds: 120,
        adaAccessibility: 'Full Level-Boarding',
        projectedDailyBoardings: 8400,
        status: 'DESIGN_VERIFIED'
      },
      {
        id: 'STN-02',
        name: 'Madera Gateway Station & Feeder Platform',
        code: 'MAD',
        chainage: 38500,
        platformCount: 2,
        platformLengthM: 420,
        platformHeightMm: 1250,
        passingLoopCount: 2,
        turnbackProvision: false,
        scheduledDwellSeconds: 75,
        adaAccessibility: 'Full Level-Boarding',
        projectedDailyBoardings: 4200,
        status: 'DESIGN_VERIFIED'
      },
      {
        id: 'STN-03',
        name: 'Fresno Downtown Station & High-Speed Hub',
        code: 'FNO',
        chainage: 61400,
        platformCount: 4,
        platformLengthM: 450,
        platformHeightMm: 1250,
        passingLoopCount: 2,
        turnbackProvision: true,
        scheduledDwellSeconds: 180,
        adaAccessibility: 'Full Level-Boarding',
        projectedDailyBoardings: 18500,
        status: 'STAGE_2_CONSTRUCTION'
      },
      {
        id: 'STN-04',
        name: 'Kings/Tulare Regional Station (Cross Valley)',
        code: 'KTR',
        chainage: 119800,
        platformCount: 2,
        platformLengthM: 450,
        platformHeightMm: 1250,
        passingLoopCount: 2,
        turnbackProvision: false,
        scheduledDwellSeconds: 90,
        adaAccessibility: 'Full Level-Boarding',
        projectedDailyBoardings: 9100,
        status: 'DESIGN_VERIFIED'
      },
      {
        id: 'STN-05',
        name: 'Bakersfield Central Terminal Station',
        code: 'BFD',
        chainage: 248200,
        platformCount: 6,
        platformLengthM: 450,
        platformHeightMm: 1250,
        passingLoopCount: 4,
        turnbackProvision: true,
        scheduledDwellSeconds: 150,
        adaAccessibility: 'Full Level-Boarding',
        projectedDailyBoardings: 21000,
        status: 'DESIGN_VERIFIED'
      }
    ];
  }

  // Turnouts & Crossovers
  getTurnouts(): TurnoutItem[] {
    return [
      {
        id: 'TO-01',
        name: 'Merced South High-Speed Crossover #32.7',
        chainage: 3400,
        turnoutNumber: 32.7,
        turnoutType: 'CROSSOVER',
        divergingRadiusM: 4000,
        frogAngleDeg: 1.75,
        switchRailLengthM: 42.0,
        straightSpeedKmh: 350,
        divergingSpeedKmh: 220,
        pointMachine: 'In-Sleeper Electro-Hydraulic',
        installationTrack: 'Track 1 to Track 2'
      },
      {
        id: 'TO-02',
        name: 'Madera Passing Loop North Turnout #20',
        chainage: 36800,
        turnoutNumber: 20,
        turnoutType: 'SIMPLE_TURNOUT',
        divergingRadiusM: 1500,
        frogAngleDeg: 2.86,
        switchRailLengthM: 26.5,
        straightSpeedKmh: 350,
        divergingSpeedKmh: 130,
        pointMachine: 'In-Sleeper Electro-Hydraulic',
        installationTrack: 'Mainline Northbound to Loop 1'
      },
      {
        id: 'TO-03',
        name: 'Fresno North Scissors Double Crossover #20',
        chainage: 59500,
        turnoutNumber: 20,
        turnoutType: 'DOUBLE_CROSSOVER',
        divergingRadiusM: 1500,
        frogAngleDeg: 2.86,
        switchRailLengthM: 26.5,
        straightSpeedKmh: 310,
        divergingSpeedKmh: 130,
        pointMachine: 'In-Sleeper Electro-Hydraulic',
        installationTrack: 'Fresno Station Approach Throats'
      },
      {
        id: 'TO-04',
        name: 'Hanford South Junction High-Speed Crossover #32.7',
        chainage: 123400,
        turnoutNumber: 32.7,
        turnoutType: 'CROSSOVER',
        divergingRadiusM: 4000,
        frogAngleDeg: 1.75,
        switchRailLengthM: 42.0,
        straightSpeedKmh: 350,
        divergingSpeedKmh: 220,
        pointMachine: 'In-Sleeper Electro-Hydraulic',
        installationTrack: 'Mainline Track 1 / Track 2'
      },
      {
        id: 'TO-05',
        name: 'Wasco Maintenance Siding Turnout #15',
        chainage: 174200,
        turnoutNumber: 15,
        turnoutType: 'SIMPLE_TURNOUT',
        divergingRadiusM: 800,
        frogAngleDeg: 3.81,
        switchRailLengthM: 19.8,
        straightSpeedKmh: 350,
        divergingSpeedKmh: 80,
        pointMachine: 'M23A Mechanical Switch Machine',
        installationTrack: 'Mainline to Track Maintenance Facility'
      },
      {
        id: 'TO-06',
        name: 'Bakersfield North Yard Ladder Throat #10',
        chainage: 245100,
        turnoutNumber: 10,
        turnoutType: 'SLIP_SWITCH',
        divergingRadiusM: 350,
        frogAngleDeg: 5.72,
        switchRailLengthM: 14.5,
        straightSpeedKmh: 160,
        divergingSpeedKmh: 45,
        pointMachine: 'In-Sleeper Electro-Hydraulic',
        installationTrack: 'Bakersfield Terminal Throat'
      }
    ];
  }

  // Geotechnical Boreholes (50 representative samples across the corridor)
  getGeotechnicalBoreholes(): GeotechnicalBorehole[] {
    const boreholes: GeotechnicalBorehole[] = [];
    const chainageSteps = [
      1200, 8500, 19200, 28400, 38500, 48200, 58900, 61400, 64500, 78000,
      92000, 105000, 114000, 119800, 126000, 138000, 150000, 162000, 170000, 184200,
      198000, 210000, 222000, 235000, 248200
    ];

    chainageSteps.forEach((ch, idx) => {
      const bhNum = (idx + 1).toString().padStart(3, '0');
      const isFaultNear = ch > 180000 && ch < 210000;
      const pga = isFaultNear ? 0.62 : 0.44;
      const waterDepth = 2.8 + (idx % 4) * 1.2;
      const spt = isFaultNear ? 18 : 26 + (idx % 6) * 3;

      boreholes.push({
        id: `BH-${bhNum}`,
        chainage: ch,
        offsetM: idx % 2 === 0 ? 8.5 : -10.2,
        groundElevationM: 52 + (ch / 1000) * 0.22,
        waterTableDepthM: waterDepth,
        pgaDesignG: pga,
        layers: [
          { depthStartM: 0, depthEndM: 2.2, stratumName: 'Engineered Compacted Fill', soilClass: 'CL-ML', sptNValue: 22, frictionAngleDeg: 30, cohesionKpa: 15, densityKnM3: 19.2, colorHex: '#a88d6b', liquefactionSusceptible: false },
          { depthStartM: 2.2, depthEndM: 7.8, stratumName: 'Stiff Silty Clay (Modesto Formation)', soilClass: 'CH', sptNValue: 16, frictionAngleDeg: 22, cohesionKpa: 48, densityKnM3: 18.5, colorHex: '#8b6f4e', liquefactionSusceptible: false },
          { depthStartM: 7.8, depthEndM: 16.5, stratumName: 'Medium Dense to Dense Sand with Silt', soilClass: 'SM', sptNValue: spt, frictionAngleDeg: 34, cohesionKpa: 4, densityKnM3: 20.1, colorHex: '#d4b37f', liquefactionSusceptible: waterDepth < 5.0 && spt < 20 },
          { depthStartM: 16.5, depthEndM: 28.0, stratumName: 'Dense Sandy Gravel with Cobbles (River Alluvium)', soilClass: 'GW', sptNValue: 45, frictionAngleDeg: 40, cohesionKpa: 0, densityKnM3: 21.5, colorHex: '#7a766b', liquefactionSusceptible: false },
          { depthStartM: 28.0, depthEndM: 45.0, stratumName: 'Bedrock Granodiorite / Quartz Diorite', soilClass: 'BR', sptNValue: 100, frictionAngleDeg: 46, cohesionKpa: 250, densityKnM3: 26.0, colorHex: '#4a4e54', liquefactionSusceptible: false }
        ],
        liquefactionFactorOfSafety: isFaultNear && spt < 20 ? 1.08 : 1.65,
        bearingCapacityKpa: 450 + (idx % 5) * 40,
        geotechStatus: isFaultNear && spt < 20 ? 'REVIEW' : 'PASS'
      });
    });

    return boreholes;
  }

  // Seismic Fault Zones in California
  getSeismicFaults(): SeismicFaultCrossing[] {
    return [
      {
        id: 'FLT-01',
        faultName: 'San Andreas Fault Zone (Pacheco Pass / Palmdale Alignment)',
        chainage: 201500,
        faultMechanism: 'Strike-Slip',
        slipRateMmYear: 34.0,
        maxDesignDisplacementM: 4.8,
        articulationJointSpacingM: 15.0,
        monitoringSensorCount: 24,
        status: 'SEISMIC_JOINT_DESIGNED'
      },
      {
        id: 'FLT-02',
        faultName: 'White Wolf Fault (1952 Kern County Rupture Zone)',
        chainage: 232000,
        faultMechanism: 'Reverse Thrust',
        slipRateMmYear: 2.5,
        maxDesignDisplacementM: 2.1,
        articulationJointSpacingM: 20.0,
        monitoringSensorCount: 16,
        status: 'SEISMIC_JOINT_DESIGNED'
      },
      {
        id: 'FLT-03',
        faultName: 'Garlock Fault Zone (Tehachapi Southern Flank)',
        chainage: 246800,
        faultMechanism: 'Strike-Slip',
        slipRateMmYear: 7.0,
        maxDesignDisplacementM: 3.2,
        articulationJointSpacingM: 18.0,
        monitoringSensorCount: 18,
        status: 'UNDER_PEER_REVIEW'
      }
    ];
  }

  // 4D Construction Sequence & Tasks (2027 to 2033)
  getConstructionStages(): ConstructionStage4D[] {
    return [
      {
        id: 'STAGE-01',
        wbsCode: '1.01',
        taskName: 'Right-of-Way Land Acquisition & Parcel Conveyance',
        category: 'LAND_ACQUISITION',
        startMonthOffset: 0,
        durationMonths: 18,
        progressPercent: 100,
        dependencies: [],
        assignedMachines: ['GIS Survey Rover Units (Trimble R12)'],
        plannedCostUsdMillions: 840,
        actualCostUsdMillions: 865,
        criticalPath: true,
        gangCount: 8
      },
      {
        id: 'STAGE-02',
        wbsCode: '1.02',
        taskName: 'Corridor Site Clearance & Environmental Abatement',
        category: 'SITE_CLEARANCE',
        startMonthOffset: 6,
        durationMonths: 14,
        progressPercent: 100,
        dependencies: ['STAGE-01'],
        assignedMachines: ['Cat D8T Bulldozer', 'Cat 336 Excavator Fleet', 'Mulching Units'],
        plannedCostUsdMillions: 210,
        actualCostUsdMillions: 205,
        criticalPath: false,
        gangCount: 14
      },
      {
        id: 'STAGE-03',
        wbsCode: '1.03',
        taskName: 'Major Utility Relocation (PG&E High-Voltage & Kinder Morgan Pipelines)',
        category: 'UTILITY_RELOCATION',
        startMonthOffset: 10,
        durationMonths: 18,
        progressPercent: 95,
        dependencies: ['STAGE-02'],
        assignedMachines: ['Horizontal Directional Drill (HDD)', 'Vacuum Excavators'],
        plannedCostUsdMillions: 480,
        actualCostUsdMillions: 512,
        criticalPath: true,
        gangCount: 18
      },
      {
        id: 'STAGE-04',
        wbsCode: '1.04',
        taskName: 'Bulk Earthworks (Cut 5.18M m³, Fill 4.90M m³ & Embankment Compaction)',
        category: 'EARTHWORKS',
        startMonthOffset: 16,
        durationMonths: 24,
        progressPercent: 88,
        dependencies: ['STAGE-03'],
        assignedMachines: ['Cat 631G Scrapers', 'Komatsu PC800 Excavators', 'Hamm Continuous Compaction Rollers'],
        plannedCostUsdMillions: 920,
        actualCostUsdMillions: 895,
        criticalPath: true,
        gangCount: 32
      },
      {
        id: 'STAGE-05',
        wbsCode: '1.05',
        taskName: 'Corridor Drainage, Box Culverts (1200-3600mm) & Retention Basins',
        category: 'DRAINAGE',
        startMonthOffset: 22,
        durationMonths: 16,
        progressPercent: 78,
        dependencies: ['STAGE-04'],
        assignedMachines: ['Cat 320 Track Excavators', 'Precast Crane Lifters (50t)'],
        plannedCostUsdMillions: 340,
        actualCostUsdMillions: 330,
        criticalPath: false,
        gangCount: 16
      },
      {
        id: 'STAGE-06',
        wbsCode: '1.06',
        taskName: 'Major Structures (San Joaquin River Viaduct, Fresno Trench, Cedar Viaduct)',
        category: 'STRUCTURES',
        startMonthOffset: 20,
        durationMonths: 32,
        progressPercent: 72,
        dependencies: ['STAGE-04'],
        assignedMachines: ['Bauer BG45 CIDH Piling Rigs', 'Comedil Tower Cranes', 'Segmental Launching Gantries'],
        plannedCostUsdMillions: 3250,
        actualCostUsdMillions: 3310,
        criticalPath: true,
        gangCount: 45
      },
      {
        id: 'STAGE-07',
        wbsCode: '1.07',
        taskName: 'Sub-Ballast & Prepared Formation Placement (13.6m width, 98% Proctor)',
        category: 'FORMATION',
        startMonthOffset: 34,
        durationMonths: 16,
        progressPercent: 54,
        dependencies: ['STAGE-06'],
        assignedMachines: ['Vögele Super 2100 Asphalt/Sub-ballast Pavers', 'Dynamic GPS Graders'],
        plannedCostUsdMillions: 410,
        actualCostUsdMillions: 395,
        criticalPath: true,
        gangCount: 12
      },
      {
        id: 'STAGE-08',
        wbsCode: '1.08',
        taskName: 'Bottom Ballast Delivery & Staging (Granite Ballast from Aromas Quarry)',
        category: 'BALLAST_SUBBALLAST',
        startMonthOffset: 40,
        durationMonths: 14,
        progressPercent: 42,
        dependencies: ['STAGE-07'],
        assignedMachines: ['Side-Dump Ballast Train Cars', 'Ballast Regulators USP 5000'],
        plannedCostUsdMillions: 365,
        actualCostUsdMillions: 360,
        criticalPath: false,
        gangCount: 10
      },
      {
        id: 'STAGE-09',
        wbsCode: '1.09',
        taskName: 'Automated Track Laying (Prestressed Concrete Sleepers & 136 RE CWR)',
        category: 'SLEEPER_RAIL_LAYING',
        startMonthOffset: 44,
        durationMonths: 16,
        progressPercent: 35,
        dependencies: ['STAGE-08'],
        assignedMachines: ['Plasser & Theurer SVM1000 Track Laying Machine', 'Mobile Flash-Butt Welder APT1500RA'],
        plannedCostUsdMillions: 880,
        actualCostUsdMillions: 870,
        criticalPath: true,
        gangCount: 20
      },
      {
        id: 'STAGE-10',
        wbsCode: '1.10',
        taskName: 'High-Speed Turnouts (#32.7 & #20) & Crossover Interlocking Installation',
        category: 'TURNOUTS_SPECIAL',
        startMonthOffset: 48,
        durationMonths: 10,
        progressPercent: 20,
        dependencies: ['STAGE-09'],
        assignedMachines: ['Geismar Kirow Switch Crane (150t)', 'Turnout Tamping Machine Unimat 09-4x4/4S'],
        plannedCostUsdMillions: 290,
        actualCostUsdMillions: 285,
        criticalPath: false,
        gangCount: 8
      },
      {
        id: 'STAGE-11',
        wbsCode: '1.11',
        taskName: '25 kV AC 60Hz Overhead Catenary System (OCS Masts, Messenger & Contact Wire)',
        category: 'ELECTRIFICATION_OCS',
        startMonthOffset: 50,
        durationMonths: 14,
        progressPercent: 15,
        dependencies: ['STAGE-09'],
        assignedMachines: ['Catenary Installation Train (Fassetta)', 'Hydraulic Mast Erection Cranes'],
        plannedCostUsdMillions: 1150,
        actualCostUsdMillions: 1140,
        criticalPath: true,
        gangCount: 18
      },
      {
        id: 'STAGE-12',
        wbsCode: '1.12',
        taskName: 'Signalling, Positive Train Control (PTC) / ETCS Level 2 & Fiber Telecoms',
        category: 'SIGNALLING_CBTC',
        startMonthOffset: 54,
        durationMonths: 12,
        progressPercent: 8,
        dependencies: ['STAGE-11'],
        assignedMachines: ['Eurobalise Mounting Units', 'Axle Counter Installation Trucks'],
        plannedCostUsdMillions: 740,
        actualCostUsdMillions: 730,
        criticalPath: true,
        gangCount: 14
      },
      {
        id: 'STAGE-13',
        wbsCode: '1.13',
        taskName: 'Dynamic Testing, Track Geometry Certification (EM120) & System Commissioning',
        category: 'TESTING_COMMISSIONING',
        startMonthOffset: 62,
        durationMonths: 10,
        progressPercent: 0,
        dependencies: ['STAGE-12'],
        assignedMachines: ['TGV/Avelia High-Speed Test Trainset', 'Track Recording Car EM120'],
        plannedCostUsdMillions: 380,
        actualCostUsdMillions: 0,
        criticalPath: true,
        gangCount: 24
      }
    ];
  }

  // Construction Machine Fleet
  getMachines(): ConstructionMachine[] {
    return [
      {
        id: 'MCH-01',
        name: 'Plasser & Theurer SVM 1000 Track Laying Train',
        type: 'TRACK_LAYER',
        dailyProductivity: '2,400 m of continuous track / 10-hr shift',
        activeChainageM: 88400,
        status: 'OPERATING',
        utilizationPct: 92,
        powerSource: 'Electric Hybrid',
        crewRequired: 14
      },
      {
        id: 'MCH-02',
        name: 'Plasser 09-3X Dynamic Continuous Action Tamping Express',
        type: 'DYNAMIC_TAMPER',
        dailyProductivity: '3,200 m track stabilized & aligned / shift',
        activeChainageM: 84200,
        status: 'OPERATING',
        utilizationPct: 88,
        powerSource: 'Tier 4 Final Diesel',
        crewRequired: 6
      },
      {
        id: 'MCH-03',
        name: 'APT 1500 RA Automatic Flash-Butt Welding Unit',
        type: 'FLASH_BUTT_WELDER',
        dailyProductivity: '38 CWR rail welds / shift (tested to EN 14587-2)',
        activeChainageM: 89100,
        status: 'OPERATING',
        utilizationPct: 85,
        powerSource: 'Electric Hybrid',
        crewRequired: 4
      },
      {
        id: 'MCH-04',
        name: 'Bauer BG 45 Premium Line CIDH Deep Piling Rig',
        type: 'PILING_RIG',
        dailyProductivity: '2 shafts (dia 2.4m, depth 36m) / 24-hr day',
        activeChainageM: 119400,
        status: 'OPERATING',
        utilizationPct: 94,
        powerSource: 'Tier 4 Final Diesel',
        crewRequired: 8
      },
      {
        id: 'MCH-05',
        name: 'Herrenknecht EPB Earth Pressure Balance TBM (dia 8.8m)',
        type: 'TBM',
        dailyProductivity: '18.4 m bored & segmental ring lined / day',
        activeChainageM: 201200,
        status: 'OPERATING',
        utilizationPct: 91,
        powerSource: 'High-Tension Catenary',
        crewRequired: 22
      },
      {
        id: 'MCH-06',
        name: 'Kirow Multi-Tasker 1600 Railway Crane (160 tonne)',
        type: 'CRANE',
        dailyProductivity: '1 complete #32.7 turnout panel placed / 4-hr possession',
        activeChainageM: 123400,
        status: 'STANDBY',
        utilizationPct: 68,
        powerSource: 'Tier 4 Final Diesel',
        crewRequired: 7
      }
    ];
  }

  // Synthetic Track Defects (Injectable & Virtual Inspection)
  getTrackDefects(): TrackDefect[] {
    return [
      {
        id: 'DEF-001',
        chainageM: 184200,
        milepost: 'MP 184.2',
        defectParameter: 'GAUGE_VARIATION',
        measuredValueMm: 1436.8,
        thresholdLimitMm: 1435.0,
        deviationMm: +1.8,
        severity: 'MAINTENANCE_ADVISORY',
        detectedByVehicle: 'Virtual Recording Car EM-120 Track Geometry Unit',
        inspectionTimestamp: '2026-09-28 14:22:05 PST',
        remedialAction: 'Schedule gang tamping & fastener torque inspection within 14 days.',
        workOrderNumber: 'WO-2026-0984',
        resolved: false
      },
      {
        id: 'DEF-002',
        chainageM: 184200,
        milepost: 'MP 184.2',
        defectParameter: 'CROSS_LEVEL',
        measuredValueMm: 2.4,
        thresholdLimitMm: 1.5,
        deviationMm: +2.4,
        severity: 'MAINTENANCE_ADVISORY',
        detectedByVehicle: 'Virtual Recording Car EM-120 Inertial Sensor Suite',
        inspectionTimestamp: '2026-09-28 14:22:06 PST',
        remedialAction: 'Automated ballast stone injection / continuous action leveling.',
        workOrderNumber: 'WO-2026-0984',
        resolved: false
      },
      {
        id: 'DEF-003',
        chainageM: 184200,
        milepost: 'MP 184.2',
        defectParameter: 'VERTICAL_PROFILE',
        measuredValueMm: 3.2,
        thresholdLimitMm: 2.0,
        deviationMm: +3.2,
        severity: 'URGENT_INTERVENTION',
        detectedByVehicle: 'Laser Optical Gauge & Accelerometer Pack',
        inspectionTimestamp: '2026-09-28 14:22:07 PST',
        remedialAction: 'Issue temporary speed restriction (TSR 220 km/h) and dispatch maintenance gang.',
        workOrderNumber: 'WO-2026-0985',
        resolved: false
      },
      {
        id: 'DEF-004',
        chainageM: 61850,
        milepost: 'MP 61.8',
        defectParameter: 'TWIST_3M',
        measuredValueMm: 1.4,
        thresholdLimitMm: 2.5,
        deviationMm: -1.1,
        severity: 'NORMAL_TOLERANCE',
        detectedByVehicle: 'Ultrasonic Flaw Detector & Laser Profilometer',
        inspectionTimestamp: '2026-09-25 09:15:30 PST',
        remedialAction: 'Continue scheduled 30-day cyclical geometry recording.',
        resolved: true
      }
    ];
  }

  // Automated Engineering Checks (842 Total, showing detailed audited rules)
  getEngineeringChecks(): EngineeringCheckRule[] {
    return [
      {
        id: 'CHK-001',
        category: 'ALIGNMENT_GEOMETRY',
        ruleCode: 'AL-HSR-01',
        title: 'Horizontal Curve Cant Deficiency Limiting Envelope',
        description: 'Verifies applied superelevation Ea (120mm) and deficiency Ed (45mm) at 350 km/h on R=7200m curve.',
        formula: 'Ed = (11.8 * V^2 / R) - Ea <= 80 mm (CHSR TM 2.1.2)',
        inputParameters: { 'Radius R': '7,200 m', 'Design Speed V': '350 km/h', 'Applied Cant Ea': '120 mm' },
        calculatedValue: 'Ed = 45.4 mm',
        designLimit: '<= 80.0 mm desirable (100 mm absolute)',
        marginOfSafety: '+34.6 mm (43% safety reserve)',
        status: 'PASS',
        referenceStandard: 'California High-Speed Rail TM 2.1.2 / AREMA Ch 5 Table 5-3-1',
        governingAuthority: 'CHSRA Engineering Standards Directorate',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-002',
        category: 'ALIGNMENT_GEOMETRY',
        ruleCode: 'AL-HSR-02',
        title: 'Transition Spiral Clothoid Length Rate of Cant Change',
        description: 'Checks maximum rate of cant change da/dt over 650m spiral transition at 350 km/h.',
        formula: 'da/dt = (Ea / Ls) * (V / 3.6) <= 50 mm/s',
        inputParameters: { 'Ea': '120 mm', 'Ls': '650 m', 'V': '350 km/h' },
        calculatedValue: 'da/dt = 17.95 mm/s',
        designLimit: '<= 35.0 mm/s (desirable)',
        marginOfSafety: '+17.05 mm/s (49% below limit)',
        status: 'PASS',
        referenceStandard: 'TSI High-Speed Infrastructure / Caltrans Design Manual',
        governingAuthority: 'Caltrans Rail Division',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-003',
        category: 'VERTICAL_PROFILE',
        ruleCode: 'VP-HSR-01',
        title: 'Vertical Crest Curve Radius & Vertical Acceleration',
        description: 'Assesses centrifugal vertical acceleration on crest curve K_v=312 at 350 km/h.',
        formula: 'a_v = (V/3.6)^2 / R_v <= 0.05 g (0.49 m/s²)',
        inputParameters: { 'K_v': '312 m/%', 'R_v': '31,200 m', 'Speed V': '350 km/h' },
        calculatedValue: 'a_v = 0.303 m/s² (0.031 g)',
        designLimit: '<= 0.490 m/s² (0.050 g)',
        marginOfSafety: '+0.187 m/s² margin',
        status: 'PASS',
        referenceStandard: 'CHSR TM 2.1.3 Vertical Alignment Design',
        governingAuthority: 'CHSRA Engineering Standards Directorate',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-004',
        category: 'TRACK_STRUCTURE',
        ruleCode: 'TS-CWR-01',
        title: 'Continuous Welded Rail (CWR) Maximum Tensile Stress in Extreme Cold',
        description: 'Checks thermal tensile stress in 136 RE rail steel at winter minimum -5°C against neutral temp 38°C.',
        formula: 'sigma = E * alpha * Delta_T <= 72.0 MPa',
        inputParameters: { 'Delta T': '43.0 °C', 'E': '210,000 MPa', 'alpha': '1.15e-5 /°C' },
        calculatedValue: 'sigma = 103.8 MPa',
        designLimit: '<= 72.0 MPa (Standard unheated track)',
        marginOfSafety: '-31.8 MPa exceedance without rail heating / de-stressing',
        status: 'FAIL',
        referenceStandard: 'AREMA Chapter 4 Rail Metallurgy & CWR Management',
        governingAuthority: 'FRA Track Safety Standards Part 213.343',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-005',
        category: 'BRIDGE_VIADUCT',
        ruleCode: 'BR-RSI-01',
        title: 'San Joaquin River Viaduct Rail-Structure Interaction (RSI) Longitudinal Stress',
        description: 'Calculates combined thermal expansion and train braking deck-rail interaction forces on continuous welded rail.',
        formula: 'sigma_rsi = sigma_thermal_deck + sigma_braking <= 72 MPa',
        inputParameters: { 'Deck Length': '4,700 m', 'Deck Type': 'Prestressed Box', 'Expansion Joint Spacing': '120 m' },
        calculatedValue: 'sigma_rsi = 48.2 MPa',
        designLimit: '<= 72.0 MPa',
        marginOfSafety: '+23.8 MPa reserve',
        status: 'PASS',
        referenceStandard: 'UIC Code 774-3R Track-Bridge Interaction',
        governingAuthority: 'California High-Speed Rail Structures Technical Committee',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-006',
        category: 'GEOTECHNICAL_SEISMIC',
        ruleCode: 'GE-LIQ-01',
        title: 'Soil Liquefaction Triggering Factor of Safety at San Andreas Fault Proximity (BH-021)',
        description: 'Evaluates Factor of Safety against liquefaction in SM saturated sand layer under M7.5 earthquake PGA 0.62g.',
        formula: 'FS = CRR_7.5 * MSF / CSR >= 1.20',
        inputParameters: { 'PGA': '0.62 g', 'Water Table': '3.2 m', 'SPT N1(60)': '18', 'Earthquake Mw': '7.5' },
        calculatedValue: 'FS = 1.08',
        designLimit: '>= 1.20 (CHSRA Seismic Design Criteria)',
        marginOfSafety: '-0.12 (Requires ground improvement / stone columns)',
        status: 'REVIEW',
        referenceStandard: 'California Geological Survey Special Publication 117A',
        governingAuthority: 'Caltrans Geotechnical Services',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-007',
        category: 'DRAINAGE_HYDROLOGY',
        ruleCode: 'DR-CUL-01',
        title: '100-Year Peak Storm Discharge Culvert Capacity (MP 92.4 Kings River Basin)',
        description: 'Checks reinforced concrete box culvert (2400x2400mm) against rational method runoff Q_100.',
        formula: 'Q_capacity = (1/n) * A * R_h^(2/3) * S^(1/2) >= Q_100',
        inputParameters: { 'Culvert Dia': '2.4 m', 'Slope S': '0.008', 'Manning n': '0.013', 'Design Q_100': '14.5 m³/s' },
        calculatedValue: 'Q_cap = 18.2 m³/s',
        designLimit: '>= 14.5 m³/s',
        marginOfSafety: '+3.7 m³/s (25% excess capacity)',
        status: 'PASS',
        referenceStandard: 'Caltrans Highway Design Manual Chapter 800 Drainage',
        governingAuthority: 'Caltrans Office of Hydrology',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-008',
        category: 'CLEARANCE_ENVELOPE',
        ruleCode: 'CL-HSR-01',
        title: 'High-Speed Dynamic Kinematic Gauge Track Center-to-Center Spacing',
        description: 'Verifies 5.0m track center spacing for counter-running 350 km/h trains with aerodynamic buffeting.',
        formula: 'Track_Spacing >= W_train + 2*Roll_kinematic + Air_buffer (5.0m standard)',
        inputParameters: { 'Train Width': '3,400 mm', 'Dynamic Sway': '220 mm', 'Air Buffer': '960 mm' },
        calculatedValue: 'Spacing = 5,000 mm',
        designLimit: '>= 4,500 mm (desirable >= 5,000 mm)',
        marginOfSafety: '+500 mm margin',
        status: 'PASS',
        referenceStandard: 'AREMA Ch 28 Clearances & CHSR TM 1.1.21 Kinematic Envelope',
        governingAuthority: 'FRA Track Safety Standards Part 213 Subpart G',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-009',
        category: 'CONSTRUCTION_LOGISTICS',
        ruleCode: 'CN-HAUL-01',
        title: 'Mass-Haul Balance Economic Overhaul Limit vs Local Borrow Pits',
        description: 'Analyzes haul distance of +281,400 m³ export material from Fresno Trench to Kings River Embankment.',
        formula: 'Haul_Cost = Volume * (Haul_Dist - Free_Haul) * Rate <= Local Borrow Cost',
        inputParameters: { 'Export Volume': '281,400 m³', 'Avg Haul': '18.4 km', 'Unit Haul Rate': '$0.85/m³-km' },
        calculatedValue: 'Haul Cost = $4.40M ($15.64/m³)',
        designLimit: '<= $18.00/m³ (Local borrow benchmark)',
        marginOfSafety: '+$2.36/m³ savings against commercial borrow',
        status: 'PASS',
        referenceStandard: 'Caltrans Construction Manual Chapter 4 Earthwork',
        governingAuthority: 'CHSRA Construction Management Branch',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      },
      {
        id: 'CHK-010',
        category: 'OPERATIONAL_HEADWAY',
        ruleCode: 'OP-SIG-01',
        title: 'ETCS Level 2 / PTC Moving Block Minimum Safe Headway at 350 km/h',
        description: 'Calculates minimum headway interval including safe braking distance (SBD), interlocking release and overlap.',
        formula: 'Headway = (SBD + L_train + Overlap) / (V/3.6) + Interlock_Time <= 180s',
        inputParameters: { 'Speed V': '350 km/h (97.2 m/s)', 'SBD': '5,800 m', 'L_train': '400 m', 'Overlap': '200 m' },
        calculatedValue: 'Headway = 152.0 seconds (2.53 min)',
        designLimit: '<= 180.0 seconds (3 min headway / 20 trains/hr)',
        marginOfSafety: '+28.0 seconds buffer (Capacity: 23 trains/hr theoretical)',
        status: 'PASS',
        referenceStandard: 'IEEE 1474 CBTC Standard / UIC 406 Capacity Calculation',
        governingAuthority: 'Caltrans Rail Operations Group',
        lastEvaluated: '2026-10-01 06:00:00 PST'
      }
    ];
  }

  // Design Alternatives (A, B, C)
  getDesignAlternatives(): DesignAlternative[] {
    return [
      {
        id: 'ALT-A',
        name: 'Option A: Direct Central Valley Spine (Selected Reference)',
        corridorCode: 'CV-DIR-2026',
        description: 'Optimal geometric efficiency along SR-99 corridor, maximize 350 km/h tangents, 47 bridges, 6 tunnels.',
        routeLengthKm: 250.0,
        curveLengthPct: 14.8,
        maxGradientPct: 1.85,
        bridgesCount: 41,
        tunnelsCount: 6,
        earthworksCutFillM3: '12.8M m³ (Balanced: +281k m³ export)',
        estimatedCostBillionUsd: 18.42,
        constructionMonths: 72,
        transitTimeMinutes: 52.5,
        tractionEnergyMwh: 14.8,
        seismicHazardIndex: 'Moderate'
      },
      {
        id: 'ALT-B',
        name: 'Option B: Tehachapi East Foothill Bypass',
        corridorCode: 'CV-TEH-EAST',
        description: 'Bypasses urban Fresno Trench with deep bored tunnels, lower urban property take, higher structural tunneling cost.',
        routeLengthKm: 268.4,
        curveLengthPct: 28.5,
        maxGradientPct: 2.80,
        bridgesCount: 56,
        tunnelsCount: 14,
        earthworksCutFillM3: '19.4M m³ (Net cut: 3.2M m³ export)',
        estimatedCostBillionUsd: 23.80,
        constructionMonths: 88,
        transitTimeMinutes: 59.2,
        tractionEnergyMwh: 18.2,
        seismicHazardIndex: 'High (Fault-Adjacent)'
      },
      {
        id: 'ALT-C',
        name: 'Option C: Shared Freight Co-Location Alignment',
        corridorCode: 'CV-FRT-COLOC',
        description: 'Maximizes use of existing BNSF / UP right-of-way, reduced design speed (250 km/h), minimal tunneling, highest grade-separation count.',
        routeLengthKm: 255.2,
        curveLengthPct: 22.0,
        maxGradientPct: 1.25,
        bridgesCount: 62,
        tunnelsCount: 2,
        earthworksCutFillM3: '8.4M m³ (Net fill import: 1.1M m³)',
        estimatedCostBillionUsd: 15.90,
        constructionMonths: 64,
        transitTimeMinutes: 68.0,
        tractionEnergyMwh: 12.6,
        seismicHazardIndex: 'Low-Medium'
      }
    ];
  }

  // Earthworks Stations for Mass-Haul Calculations
  getEarthworkStations(): EarthworkStation[] {
    const stations: EarthworkStation[] = [];
    let cumCut = 0;
    let cumFill = 0;
    const totalDist = 250000;
    const step = 5000; // every 5 km

    for (let ch = 0; ch <= totalDist; ch += step) {
      // Synthetic ground vs rail profile
      const groundElev = 52.0 + Math.sin(ch / 18000) * 12.0 + (ch / 1000) * 0.25;
      const railElev = 54.0 + (ch / 1000) * 0.24;
      const diff = +(groundElev - railElev).toFixed(2);
      const isCut = diff > 0;
      const height = Math.abs(diff);
      const area = (13.6 + 1.5 * height) * height; // trapezoidal section
      const incVolume = +(area * step).toFixed(0);

      if (isCut) {
        cumCut += incVolume;
      } else {
        cumFill += incVolume;
      }

      const massOrdinate = +(cumCut - cumFill * 0.95).toFixed(0); // 5% shrinkage factor

      stations.push({
        chainage: ch,
        groundElevation: +groundElev.toFixed(2),
        formationElevation: +railElev.toFixed(2),
        cutOrFill: diff > 0.5 ? 'CUT' : diff < -0.5 ? 'FILL' : 'GRADE',
        heightM: height,
        cutAreaM2: isCut ? +area.toFixed(2) : 0,
        fillAreaM2: !isCut ? +area.toFixed(2) : 0,
        incrementalCutM3: isCut ? incVolume : 0,
        incrementalFillM3: !isCut ? incVolume : 0,
        cumulativeCutM3: cumCut,
        cumulativeFillM3: cumFill,
        massHaulOrdinateM3: massOrdinate,
        haulDistanceKm: +(Math.abs(massOrdinate) / 280000).toFixed(1)
      });
    }

    return stations;
  }

  // BIM / IFC Structure Objects
  getBIMObjects(): BIMObjectInfo[] {
    return [
      {
        guid: 'IFC-RAIL-001-A9F2',
        ifcClass: 'IfcRail',
        elementName: '136 RE Continuous Welded Rail (Standard High-Strength Carbon 370HB)',
        chainageRange: '000+000 to 250+000',
        material: 'Arema High-Strength Rail Steel (Grade R350HT)',
        volumeM3: 4320.5,
        weightTonnes: 34100,
        carbonEmbodiedTCo2e: 64790,
        versionChangeStatus: 'UNCHANGED',
        attributes: { standard: 'AREMA Chapter 4', section: '136 RE (67.4 kg/m)', hardness: '370 HB' }
      },
      {
        guid: 'IFC-TRK-002-C4B8',
        ifcClass: 'IfcTrack',
        elementName: 'RHEDA 2000 Ballastless Slab Track Base & Low-Vibration Fasteners',
        chainageRange: '058+800 to 062+400 (Fresno Trench)',
        material: 'C35/45 Self-Compacting Reinforced Concrete',
        volumeM3: 18400,
        weightTonnes: 44160,
        carbonEmbodiedTCo2e: 8832,
        versionChangeStatus: 'MODIFIED',
        attributes: { system: 'RHEDA 2000 HSR', acousticDamping: '-8 dB(A)', designLife: '100 Years' }
      },
      {
        guid: 'IFC-BRG-003-E8D1',
        ifcClass: 'IfcBridge',
        elementName: 'San Joaquin River Viaduct Segmental Superstructure',
        chainageRange: '019+100 to 023+800',
        material: 'High-Performance Post-Tensioned Concrete (C50/60)',
        volumeM3: 98500,
        weightTonnes: 236400,
        carbonEmbodiedTCo2e: 42550,
        versionChangeStatus: 'UNCHANGED',
        attributes: { spans: 117, maxSpanM: 65, deckWidthM: 14.5, designLife: '120 Years' }
      },
      {
        guid: 'IFC-TUN-004-F7A3',
        ifcClass: 'IfcTunnel',
        elementName: 'Pacheco Pass Twin-Bore Exploration Tunnel Precast Rings',
        chainageRange: '198+400 to 204+200',
        material: 'Fiber-Reinforced High-Density Precast Concrete Rings',
        volumeM3: 142000,
        weightTonnes: 340800,
        carbonEmbodiedTCo2e: 68160,
        versionChangeStatus: 'ADDED',
        attributes: { internalDiaM: 8.8, ringWidthM: 1.8, segmentsPerRing: '7+1 Key', waterproofGasket: 'EPDM' }
      },
      {
        guid: 'IFC-ALI-005-B2E6',
        ifcClass: 'IfcAlignment',
        elementName: 'Central Valley 350 km/h Mainline 3D Alignment Geometry',
        chainageRange: '000+000 to 250+000',
        material: 'Mathematical Spatial Vector Corridor',
        versionChangeStatus: 'UNCHANGED',
        attributes: { maxSpeed: '350 km/h', maxCant: '145 mm', maxGrade: '1.85%', crs: 'EPSG:6420 CA Zone IV' }
      }
    ];
  }
}
