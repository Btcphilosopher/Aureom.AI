import { Injectable, signal, computed, inject } from '@angular/core';
import {
  UnitSystem,
  UserRole,
  ProjectStatus,
  AlignmentElement,
  VerticalPVI,
  StructureItem,
  StationItem,
  TurnoutItem,
  GeotechnicalBorehole,
  SeismicFaultCrossing,
  ConstructionStage4D,
  ConstructionMachine,
  TrainDynamicsState,
  TrackDefect,
  EngineeringCheckRule,
  BIMObjectInfo,
  DesignAlternative,
  EarthworkStation
} from '../models/engineering.types';
import { SyntheticDataService } from './synthetic-data';
import { EngineeringCalculations } from './engineering-calculations';

export type ActiveTab = 
  | 'PROJECTS'
  | 'CORRIDORS'
  | 'ALIGNMENT'
  | 'TRACK'
  | 'TERRAIN'
  | 'EARTHWORKS'
  | 'STRUCTURES'
  | 'STATIONS'
  | 'TURNOUTS'
  | 'SIGNALLING'
  | 'ELECTRIFICATION'
  | 'CONSTRUCTION'
  | 'SIMULATION'
  | 'COST'
  | 'SCHEDULE'
  | 'ASSETS'
  | 'INSPECTION'
  | 'GIS'
  | 'DIGITAL_TWIN'
  | 'REPORTS'
  | 'PROVENANCE'
  | 'ADMIN';

@Injectable({
  providedIn: 'root'
})
export class CaltrackState {
  private syntheticData = inject(SyntheticDataService);
  private engCalc = inject(EngineeringCalculations);

  // Global App State Signals
  readonly activeTab = signal<ActiveTab>('DIGITAL_TWIN');
  readonly currentRole = signal<UserRole>('RAIL_ENGINEER');
  readonly projectStatus = signal<ProjectStatus>('DESIGN_30');
  readonly projectVersion = signal<string>('30% DESIGN (Rev 04)');
  readonly unitSystem = signal<UnitSystem>('METRIC_SI');
  readonly isSyntheticNoticeDismissed = signal<boolean>(false);

  // Project Metadata
  readonly projectName = signal<string>('Central Valley North–South High-Speed Corridor');
  readonly routeLengthKm = signal<number>(250.0);
  readonly maxDesignSpeedKmh = signal<number>(350);
  readonly trackGaugeMm = signal<number>(1435.0);
  readonly trackConfiguration = signal<string>('Double Track with High-Speed Pergolas & Overhead 25 kV AC');
  readonly designYear = signal<number>(2055);

  // Domain Datasets (Signals)
  readonly alignmentElements = signal<AlignmentElement[]>(this.syntheticData.getCentralValleyAlignment());
  readonly verticalPvis = signal<VerticalPVI[]>(this.syntheticData.getCentralValleyVerticalProfile());
  readonly structures = signal<StructureItem[]>(this.syntheticData.getStructures());
  readonly stations = signal<StationItem[]>(this.syntheticData.getStations());
  readonly turnouts = signal<TurnoutItem[]>(this.syntheticData.getTurnouts());
  readonly geotechnicalBoreholes = signal<GeotechnicalBorehole[]>(this.syntheticData.getGeotechnicalBoreholes());
  readonly seismicFaults = signal<SeismicFaultCrossing[]>(this.syntheticData.getSeismicFaults());
  readonly constructionStages = signal<ConstructionStage4D[]>(this.syntheticData.getConstructionStages());
  readonly machines = signal<ConstructionMachine[]>(this.syntheticData.getMachines());
  readonly trackDefects = signal<TrackDefect[]>(this.syntheticData.getTrackDefects());
  readonly engineeringChecks = signal<EngineeringCheckRule[]>(this.syntheticData.getEngineeringChecks());
  readonly designAlternatives = signal<DesignAlternative[]>(this.syntheticData.getDesignAlternatives());
  readonly earthworkStations = signal<EarthworkStation[]>(this.syntheticData.getEarthworkStations());
  readonly bimObjects = signal<BIMObjectInfo[]>(this.syntheticData.getBIMObjects());

  // Interactive Selection State
  readonly selectedAlignmentId = signal<string>('ALIGN-003'); // Default San Joaquin River curve
  readonly selectedStructureId = signal<string | null>('STR-01');
  readonly selectedStationId = signal<string | null>('STN-03');
  readonly selectedTurnoutId = signal<string | null>('TO-01');
  readonly selectedBoreholeId = signal<string | null>('BH-020');
  readonly selectedDefectId = signal<string | null>('DEF-001');
  readonly activeChainagePointerM = signal<number>(19150); // 19+150 meters

  // 4D Construction Simulation Control
  readonly constructionMonth = signal<number>(44); // Month 44 in 2030 (Track laying phase)
  readonly isConstructionPlaying = signal<boolean>(false);
  readonly constructionPlaySpeed = signal<number>(1); // 1x, 2x, 5x
  private constructionTimer: ReturnType<typeof setInterval> | null = null;

  // Train Dynamics Simulation State
  readonly activeTrain = signal<TrainDynamicsState>({
    trainId: 'HST-01',
    trainName: 'California High-Speed Trainset Alpha (Avelia Horizon Mod)',
    trainType: 'HIGH_SPEED_EMU',
    trainLengthM: 202,
    totalMassTonnes: 430,
    maxPowerKw: 8800,
    maxTractiveEffortKn: 320,
    maxBrakingForceKn: 340,
    currentChainageM: 19150,
    currentSpeedKmh: 342.5,
    targetSpeedKmh: 350.0,
    accelerationMs2: 0.12,
    gradientPct: 0.35,
    curvature1OverM: 1 / 7200,
    tractiveForceKn: 124.5,
    davisTotalResistanceKn: 68.4,
    powerOutputMw: 6.4,
    energyConsumedKwh: 3420,
    timeElapsedSec: 480,
    signalAspect: 'CLEAR_GREEN',
    cabAlerts: ['Track Cant Deflection Nominal (Ea=120mm)', 'ATP Speed Profile: 350 km/h Authorized']
  });
  readonly isTrainSimRunning = signal<boolean>(false);
  private trainSimTimer: ReturnType<typeof setInterval> | null = null;

  // Computed Properties for Dashboard & Quantities
  readonly checkStats = computed(() => {
    return {
      pass: 842,
      review: 21,
      warning: 14,
      fail: 2,
      total: 879
    };
  });

  readonly selectedAlignmentElement = computed(() => {
    const id = this.selectedAlignmentId();
    return this.alignmentElements().find(el => el.id === id) || this.alignmentElements()[0];
  });

  readonly earthworksSummary = computed(() => {
    return {
      totalCutM3: 5184200,
      totalFillM3: 4902800,
      netExportM3: 281400,
      averageHaulKm: 18.4,
      estimatedHaulCostUsd: 4400000,
      soilBulkingFactor: 1.15
    };
  });

  readonly costBreakdownSummary = computed(() => {
    return {
      landAcquisition: 865,
      earthworksDrainage: 1225,
      structuresViaducts: 3310,
      tunnelsUnderground: 1228,
      stationsTerminals: 880,
      trackSubballast: 1265,
      electrificationOcs: 1140,
      signallingCbtc: 730,
      constructionMgmt: 1480,
      contingency: 2280,
      totalCapExMillions: 18420 // $18.42 Billion
    };
  });

  // Actions
  setActiveTab(tab: ActiveTab) {
    this.activeTab.set(tab);
  }

  setRole(role: UserRole) {
    this.currentRole.set(role);
  }

  setProjectVersion(ver: string) {
    this.projectVersion.set(ver);
  }

  setUnitSystem(unit: UnitSystem) {
    this.unitSystem.set(unit);
  }

  selectAlignmentElement(id: string) {
    this.selectedAlignmentId.set(id);
    const elem = this.alignmentElements().find(e => e.id === id);
    if (elem) {
      this.activeChainagePointerM.set(elem.startChainage);
    }
  }

  setChainagePointer(ch: number) {
    this.activeChainagePointerM.set(Math.max(0, Math.min(250000, ch)));
  }

  // Update alignment curve parameters interactively (demonstrating dynamic recalculation)
  updateAlignmentCurve(id: string, newRadius: number, newCant: number, newSpeed: number) {
    const current = this.alignmentElements();
    const updated = current.map(item => {
      if (item.id === id) {
        const cantDef = Math.round(((11.8 * Math.pow(newSpeed, 2)) / Math.max(1, newRadius)) - newCant);
        const lSpiral = this.engCalc.calculateMinimumSpiralLength(newSpeed, newCant, Math.max(0, cantDef));
        const rateCant = this.engCalc.calculateRateOfCantChange(newCant, Math.max(60, lSpiral), newSpeed);
        return {
          ...item,
          radius: newRadius,
          cantMm: newCant,
          designSpeedKmh: newSpeed,
          cantDeficiencyMm: Math.max(0, cantDef),
          transitionSpiralLength: lSpiral,
          rateOfCantChangeMmS: rateCant
        };
      }
      return item;
    });
    this.alignmentElements.set(updated);
  }

  // 4D Construction Simulation Controls
  toggleConstructionPlayback() {
    if (this.isConstructionPlaying()) {
      this.pauseConstruction();
    } else {
      this.playConstruction();
    }
  }

  playConstruction() {
    this.isConstructionPlaying.set(true);
    if (this.constructionTimer) clearInterval(this.constructionTimer);
    this.constructionTimer = setInterval(() => {
      let nextMonth = this.constructionMonth() + 1;
      if (nextMonth > 72) {
        nextMonth = 0;
      }
      this.constructionMonth.set(nextMonth);
      this.updateStagesForMonth(nextMonth);
    }, 600 / this.constructionPlaySpeed());
  }

  pauseConstruction() {
    this.isConstructionPlaying.set(false);
    if (this.constructionTimer) {
      clearInterval(this.constructionTimer);
      this.constructionTimer = null;
    }
  }

  setConstructionMonth(month: number) {
    this.constructionMonth.set(month);
    this.updateStagesForMonth(month);
  }

  private updateStagesForMonth(month: number) {
    const stages = this.constructionStages().map(s => {
      if (month < s.startMonthOffset) {
        return { ...s, progressPercent: 0 };
      } else if (month >= s.startMonthOffset + s.durationMonths) {
        return { ...s, progressPercent: 100 };
      } else {
        const pct = Math.round(((month - s.startMonthOffset) / s.durationMonths) * 100);
        return { ...s, progressPercent: pct };
      }
    });
    this.constructionStages.set(stages);
  }

  // Train Simulation Controls
  toggleTrainSimulation() {
    if (this.isTrainSimRunning()) {
      this.pauseTrainSim();
    } else {
      this.startTrainSim();
    }
  }

  startTrainSim() {
    this.isTrainSimRunning.set(true);
    if (this.trainSimTimer) clearInterval(this.trainSimTimer);
    this.trainSimTimer = setInterval(() => {
      const train = this.activeTrain();
      // Step simulation by dt = 0.5s
      const speedMs = (train.currentSpeedKmh / 3.6);
      let newDist = train.currentChainageM + speedMs * 1.0;
      if (newDist > 250000) newDist = 0; // loop corridor

      // Check current vertical gradient at this chainage
      const grade = newDist > 58000 && newDist < 63000 ? -1.85 : newDist > 160000 ? 1.12 : 0.35;
      const radius = newDist > 19000 && newDist < 24000 ? 7200 : newDist > 58000 && newDist < 63000 ? 5500 : 0;

      const res = this.engCalc.calculateTrainResistance(
        train.totalMassTonnes,
        train.currentSpeedKmh,
        grade,
        radius,
        train.trainType
      );

      // Simple physics controller
      const targetSpeed = radius > 0 && radius < 6000 ? 310 : 350;
      let newSpeed = train.currentSpeedKmh;
      if (train.currentSpeedKmh < targetSpeed) {
        newSpeed += 0.8;
      } else if (train.currentSpeedKmh > targetSpeed) {
        newSpeed -= 1.2;
      }

      const power = +((res.totalResistanceKn * (newSpeed / 3.6)) / 1000).toFixed(2);
      const incKwh = +((power * 1000 * (1 / 3600))).toFixed(3);

      this.activeTrain.set({
        ...train,
        currentChainageM: Math.round(newDist),
        currentSpeedKmh: +newSpeed.toFixed(1),
        targetSpeedKmh: targetSpeed,
        gradientPct: grade,
        davisTotalResistanceKn: res.totalResistanceKn,
        tractiveForceKn: +(res.totalResistanceKn + (train.totalMassTonnes * 0.15)).toFixed(1),
        powerOutputMw: Math.max(0.5, power),
        energyConsumedKwh: +(train.energyConsumedKwh + incKwh).toFixed(1),
        timeElapsedSec: train.timeElapsedSec + 1
      });

      this.activeChainagePointerM.set(Math.round(newDist));
    }, 100);
  }

  pauseTrainSim() {
    this.isTrainSimRunning.set(false);
    if (this.trainSimTimer) {
      clearInterval(this.trainSimTimer);
      this.trainSimTimer = null;
    }
  }

  // Inject Track Geometry Defect at MP 184.2 (demonstrating Step 9 in prompt)
  injectTrackDefectAtMP184() {
    const defects = this.trackDefects();
    const existing = defects.find(d => d.chainageM === 184200 && d.defectParameter === 'GAUGE_VARIATION');
    if (existing) {
      existing.resolved = false;
      existing.measuredValueMm = 1438.4;
      existing.deviationMm = +3.4;
      existing.severity = 'URGENT_INTERVENTION';
      existing.workOrderNumber = 'WO-2026-CAL-991';
      this.trackDefects.set([...defects]);
    } else {
      const newDefect: TrackDefect = {
        id: `DEF-${Date.now().toString().slice(-4)}`,
        chainageM: 184200,
        milepost: 'MP 184.2 (Wasco Sub)',
        defectParameter: 'GAUGE_VARIATION',
        measuredValueMm: 1438.4,
        thresholdLimitMm: 1435.0,
        deviationMm: +3.4,
        severity: 'URGENT_INTERVENTION',
        detectedByVehicle: 'Laser Optical Track Recording Car EM120',
        inspectionTimestamp: new Date().toLocaleTimeString(),
        remedialAction: 'Issue 80 km/h TSR slow order and dispatch emergency tamping & re-gauging crew.',
        workOrderNumber: 'WO-2026-CAL-991',
        resolved: false
      };
      this.trackDefects.set([newDefect, ...defects]);
    }
    this.activeChainagePointerM.set(184200);
  }

  resolveDefect(id: string) {
    const updated = this.trackDefects().map(d => {
      if (d.id === id) {
        return { ...d, resolved: true, remedialAction: 'Maintenance gang executed dynamic tamping and re-torqued Pandrol Fastclip clips. Geometry restored within class tolerances.' };
      }
      return d;
    });
    this.trackDefects.set(updated);
  }

  // Unit Converter Formatters
  formatDistance(meters: number): string {
    const unit = this.unitSystem();
    if (unit === 'US_CUSTOMARY') {
      const miles = meters * 0.000621371;
      return `${miles.toFixed(2)} mi`;
    }
    const km = meters / 1000;
    return `${km.toFixed(2)} km`;
  }

  formatStationing(meters: number): string {
    const km = Math.floor(meters / 1000);
    const m = Math.floor(meters % 1000);
    return `${km.toString().padStart(3, '0')}+${m.toString().padStart(3, '0')}`;
  }

  formatSpeed(kmh: number): string {
    const unit = this.unitSystem();
    if (unit === 'US_CUSTOMARY') {
      const mph = kmh * 0.621371;
      return `${mph.toFixed(0)} mph`;
    }
    return `${kmh.toFixed(0)} km/h`;
  }

  formatElevation(meters: number): string {
    const unit = this.unitSystem();
    if (unit === 'US_CUSTOMARY') {
      const feet = meters * 3.28084;
      return `${feet.toFixed(1)} ft`;
    }
    return `${meters.toFixed(1)} m`;
  }

  formatVolume(m3: number): string {
    const unit = this.unitSystem();
    if (unit === 'US_CUSTOMARY') {
      const yd3 = m3 * 1.30795;
      return `${(yd3 / 1000000).toFixed(2)}M yd³`;
    }
    return `${(m3 / 1000000).toFixed(2)}M m³`;
  }
}
