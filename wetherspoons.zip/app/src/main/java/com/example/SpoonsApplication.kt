package com.example

import android.app.Application
import androidx.room.Room
import com.example.core.database.DatabaseSeeder
import com.example.core.database.SpoonsDatabase
import com.example.core.repository.CartRepository
import com.example.core.repository.MenuRepository
import com.example.core.repository.OfferRepository
import com.example.core.repository.OrderRepository
import com.example.core.repository.PubRepository
import com.example.core.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SpoonsApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob())

    lateinit var database: SpoonsDatabase
        private set

    lateinit var pubRepository: PubRepository
        private set

    lateinit var menuRepository: MenuRepository
        private set

    lateinit var cartRepository: CartRepository
        private set

    lateinit var orderRepository: OrderRepository
        private set

    lateinit var offerRepository: OfferRepository
        private set

    lateinit var userRepository: UserRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize Room Database
        database = Room.databaseBuilder(
            applicationContext,
            SpoonsDatabase::class.java,
            "spoons_database"
        ).fallbackToDestructiveMigration()
         .build()

        // Initialize Repositories
        pubRepository = PubRepository(database.pubDao())
        menuRepository = MenuRepository(database.menuDao())
        cartRepository = CartRepository(database.cartDao())
        orderRepository = OrderRepository(database.orderDao())
        offerRepository = OfferRepository(database.offerDao())
        userRepository = UserRepository(database.userProfileDao())

        // Seed data asynchronously if empty
        applicationScope.launch {
            seedDatabaseIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        val pubDao = database.pubDao()
        val userProfileDao = database.userProfileDao()
        
        // Check if DB is empty by querying profile
        val profile = userProfileDao.getUserProfileOneShot()
        if (profile == null) {
            // Seed User Profile
            userProfileDao.insertUserProfile(DatabaseSeeder.getMockUserProfile())
            
            // Seed Pubs
            pubDao.insertPubs(DatabaseSeeder.getMockPubs())
            
            // Seed Menu Categories
            database.menuDao().insertCategories(DatabaseSeeder.getMockCategories())
            
            // Seed Menu Items
            database.menuDao().insertMenuItems(DatabaseSeeder.getMockMenuItems())
            
            // Seed Offers
            database.offerDao().insertOffers(DatabaseSeeder.getMockOffers())
        }
    }

    companion object {
        lateinit var instance: SpoonsApplication
            private set
    }
}
