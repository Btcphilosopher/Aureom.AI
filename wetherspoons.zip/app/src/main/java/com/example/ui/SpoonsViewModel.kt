package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.database.DatabaseSeeder
import com.example.core.model.CartItem
import com.example.core.model.MenuCategory
import com.example.core.model.MenuItem
import com.example.core.model.Offer
import com.example.core.model.Order
import com.example.core.model.OrderItem
import com.example.core.model.Pub
import com.example.core.model.UserProfile
import com.example.core.repository.CartRepository
import com.example.core.repository.MenuRepository
import com.example.core.repository.OfferRepository
import com.example.core.repository.OrderRepository
import com.example.core.repository.PubRepository
import com.example.core.repository.UserRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class SpoonsViewModel(
    private val pubRepository: PubRepository,
    private val menuRepository: MenuRepository,
    private val cartRepository: CartRepository,
    private val orderRepository: OrderRepository,
    private val offerRepository: OfferRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    // --- ACCESSIBILITY STATE ---
    private val _isLargeText = MutableStateFlow(false)
    val isLargeText = _isLargeText.asStateFlow()

    private val _isHighContrast = MutableStateFlow(false)
    val isHighContrast = _isHighContrast.asStateFlow()

    fun toggleLargeText() { _isLargeText.value = !_isLargeText.value }
    fun toggleHighContrast() { _isHighContrast.value = !_isHighContrast.value }

    // --- SEARCH / FILTERS STATE ---
    private val _pubSearchQuery = MutableStateFlow("")
    val pubSearchQuery = _pubSearchQuery.asStateFlow()

    private val _globalSearchQuery = MutableStateFlow("")
    val globalSearchQuery = _globalSearchQuery.asStateFlow()

    private val _facilityFilterWifi = MutableStateFlow(false)
    private val _facilityFilterFood = MutableStateFlow(false)
    private val _facilityFilterAle = MutableStateFlow(false)
    private val _facilityFilterAccess = MutableStateFlow(false)
    private val _facilityFilterOutdoor = MutableStateFlow(false)

    val facilityFilterWifi = _facilityFilterWifi.asStateFlow()
    val facilityFilterFood = _facilityFilterFood.asStateFlow()
    val facilityFilterAle = _facilityFilterAle.asStateFlow()
    val facilityFilterAccess = _facilityFilterAccess.asStateFlow()
    val facilityFilterOutdoor = _facilityFilterOutdoor.asStateFlow()

    fun toggleFilterWifi() { _facilityFilterWifi.value = !_facilityFilterWifi.value }
    fun toggleFilterFood() { _facilityFilterFood.value = !_facilityFilterFood.value }
    fun toggleFilterAle() { _facilityFilterAle.value = !_facilityFilterAle.value }
    fun toggleFilterAccess() { _facilityFilterAccess.value = !_facilityFilterAccess.value }
    fun toggleFilterOutdoor() { _facilityFilterOutdoor.value = !_facilityFilterOutdoor.value }

    fun setPubSearchQuery(query: String) { _pubSearchQuery.value = query }
    fun setGlobalSearchQuery(query: String) { _globalSearchQuery.value = query }

    // --- PUBS STATE ---
    val pubsList: StateFlow<List<Pub>> = combine(
        pubRepository.allPubs,
        _pubSearchQuery,
        combine(
            _facilityFilterWifi,
            _facilityFilterFood,
            _facilityFilterAle,
            _facilityFilterAccess,
            _facilityFilterOutdoor
        ) { wifi, food, ale, access, outdoor ->
            listOf(wifi, food, ale, access, outdoor)
        }
    ) { all, query, filters ->
        val wifi = filters[0]
        val food = filters[1]
        val ale = filters[2]
        val access = filters[3]
        val outdoor = filters[4]
        all.filter { pub ->
            (query.isEmpty() || pub.name.contains(query, ignoreCase = true) || pub.town.contains(query, ignoreCase = true)) &&
            (!wifi || pub.hasWifi) &&
            (!food || pub.hasFood) &&
            (!ale || pub.hasRealAle) &&
            (!access || pub.hasAccessibility) &&
            (!outdoor || pub.hasOutdoorArea)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favouritePubs: StateFlow<List<Pub>> = pubRepository.favouritePubs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- SELECTED PUB STATE ---
    private val _selectedPubId = MutableStateFlow<String?>("pub_moon_stars") // Default to Moon & Stars
    val selectedPubId = _selectedPubId.asStateFlow()

    val selectedPub: StateFlow<Pub?> = _selectedPubId.flatMapLatest { id ->
        if (id == null) flowOf(null) else pubRepository.getPubById(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun selectPub(pubId: String) {
        _selectedPubId.value = pubId
    }

    fun togglePubFavourite(pub: Pub) {
        viewModelScope.launch {
            pubRepository.updatePub(pub.copy(isFavourite = !pub.isFavourite))
        }
    }

    // --- MENU STATE ---
    val menuCategories: StateFlow<List<MenuCategory>> = menuRepository.categories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedCategoryId = MutableStateFlow<String?>("cat_breakfast") // Default category
    val selectedCategoryId = _selectedCategoryId.asStateFlow()

    val menuItems: StateFlow<List<MenuItem>> = _selectedCategoryId.flatMapLatest { catId ->
        if (catId == null) flowOf(emptyList()) else menuRepository.getItemsByCategory(catId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectCategory(categoryId: String) {
        _selectedCategoryId.value = categoryId
    }

    // --- CART STATE ---
    private val _currentTableNumber = MutableStateFlow("")
    val currentTableNumber = _currentTableNumber.asStateFlow()

    fun setTableNumber(table: String) {
        _currentTableNumber.value = table
    }

    val cartItems: StateFlow<List<CartItem>> = _selectedPubId.flatMapLatest { pubId ->
        if (pubId == null) flowOf(emptyList()) else cartRepository.getCartItems(pubId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartTotal: StateFlow<Double> = cartItems.combine(flowOf(0.0)) { items, _ ->
        items.sumOf { it.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addToCart(item: MenuItem, quantity: Int, modifiers: String) {
        val pubId = _selectedPubId.value ?: return
        viewModelScope.launch {
            // Check if item already exists with exact same modifiers
            val existing = cartRepository.getCartItemsOneShot(pubId).find { 
                it.menuItemId == item.id && it.selectedModifiers == modifiers 
            }
            if (existing != null) {
                cartRepository.updateCartItem(existing.copy(quantity = existing.quantity + quantity))
            } else {
                cartRepository.insertCartItem(
                    CartItem(
                        pubId = pubId,
                        menuItemId = item.id,
                        name = item.name,
                        price = item.price,
                        quantity = quantity,
                        selectedModifiers = modifiers
                    )
                )
            }
        }
    }

    fun updateCartItemQuantity(cartItem: CartItem, newQty: Int) {
        viewModelScope.launch {
            if (newQty <= 0) {
                cartRepository.deleteCartItem(cartItem.id)
            } else {
                cartRepository.updateCartItem(cartItem.copy(quantity = newQty))
            }
        }
    }

    fun removeFromCart(cartItem: CartItem) {
        viewModelScope.launch {
            cartRepository.deleteCartItem(cartItem.id)
        }
    }

    fun clearCart() {
        val pubId = _selectedPubId.value ?: return
        viewModelScope.launch {
            cartRepository.clearCart(pubId)
        }
    }

    // --- ORDER & PAYMENT STATE ---
    val allOrders: StateFlow<List<Order>> = orderRepository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _lastPlacedOrderId = MutableStateFlow<String?>(null)
    val lastPlacedOrderId = _lastPlacedOrderId.asStateFlow()

    val lastPlacedOrder: StateFlow<Order?> = _lastPlacedOrderId.flatMapLatest { id ->
        if (id == null) flowOf(null) else orderRepository.getOrderById(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val lastPlacedOrderItems: StateFlow<List<OrderItem>> = _lastPlacedOrderId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else orderRepository.getOrderItems(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Simulated sandbox order placement
    fun checkoutAndPay() {
        val pubId = _selectedPubId.value ?: return
        val tableNum = _currentTableNumber.value
        if (tableNum.isEmpty()) return

        viewModelScope.launch {
            val items = cartRepository.getCartItemsOneShot(pubId)
            if (items.isEmpty()) return@launch

            val total = items.sumOf { it.price * it.quantity }
            val orderId = UUID.randomUUID().toString()
            val orderNum = (10000 + (Math.random() * 90000).toInt()).toString()
            val summary = items.joinToString(", ") { "${it.quantity} × ${it.name}" }

            val newOrder = Order(
                id = orderId,
                orderNumber = orderNum,
                pubId = pubId,
                pubName = selectedPub.value?.name ?: "Wetherspoons Venue",
                tableNumber = tableNum,
                totalAmount = total,
                status = "PLACED",
                timestamp = System.currentTimeMillis(),
                itemSummary = summary
            )

            val orderItems = items.map {
                OrderItem(
                    orderId = orderId,
                    menuItemId = it.menuItemId,
                    name = it.name,
                    price = it.price,
                    quantity = it.quantity,
                    selectedModifiers = it.selectedModifiers
                )
            }

            // Insert into local DB
            orderRepository.insertOrder(newOrder, orderItems)
            _lastPlacedOrderId.value = orderId

            // Clear Cart
            cartRepository.clearCart(pubId)

            // Trigger simulated order state changes asynchronously
            simulateOrderProgress(orderId)
        }
    }

    private fun simulateOrderProgress(orderId: String) {
        viewModelScope.launch {
            delay(6000) // 6 seconds in PLACED
            orderRepository.updateOrderStatus(orderId, "ACCEPTED")

            delay(10000) // 10 seconds in ACCEPTED -> PREPARING
            orderRepository.updateOrderStatus(orderId, "PREPARING")

            delay(12000) // 12 seconds in PREPARING -> READY
            orderRepository.updateOrderStatus(orderId, "READY")

            delay(8000) // 8 seconds in READY -> DELIVERED
            orderRepository.updateOrderStatus(orderId, "DELIVERED")
        }
    }

    // Quick Reorder
    fun quickReorder(previousOrder: Order) {
        viewModelScope.launch {
            // Get order items for previous order
            orderRepository.getOrderItems(previousOrder.id).collect { items ->
                if (items.isNotEmpty()) {
                    // Switch pub to previous order pub
                    selectPub(previousOrder.pubId)
                    setTableNumber(previousOrder.tableNumber)

                    // Add items to cart
                    items.forEach { item ->
                        val menuItem = menuRepository.getItemById(item.menuItemId)
                        if (menuItem != null) {
                            addToCart(menuItem, item.quantity, item.selectedModifiers)
                        } else {
                            // Fallback if item deleted, insert custom
                            cartRepository.insertCartItem(
                                CartItem(
                                    pubId = previousOrder.pubId,
                                    menuItemId = item.menuItemId,
                                    name = item.name,
                                    price = item.price,
                                    quantity = item.quantity,
                                    selectedModifiers = item.selectedModifiers
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    // --- OFFERS STATE ---
    val offersList: StateFlow<List<Offer>> = offerRepository.allOffers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- USER PROFILE / LOYALTY ---
    val userProfile: StateFlow<UserProfile?> = userRepository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun addPoints(pts: Int) {
        viewModelScope.launch {
            val current = userRepository.getUserProfileOneShot() ?: return@launch
            userRepository.updateUserProfile(current.copy(points = current.points + pts))
        }
    }

    // --- GLOBAL SEARCH STATE ---
    val globalSearchResults: StateFlow<GlobalSearchData> = combine(
        _globalSearchQuery,
        pubRepository.allPubs,
        menuRepository.categories,
        combine(menuCategories, _globalSearchQuery) { _, q -> 
            if (q.isEmpty()) emptyList() else {
                // Wait, we query all items and filter in memory for global search
                // To keep database calls clean
                emptyList<MenuItem>()
            }
        }
    ) { query, pubs, _, _ ->
        if (query.isEmpty()) {
            GlobalSearchData()
        } else {
            val matchingPubs = pubs.filter {
                it.name.contains(query, ignoreCase = true) || it.town.contains(query, ignoreCase = true)
            }
            // Simple mock filtering for demo global search
            val matchingItems = DatabaseSeeder.getMockMenuItems().filter {
                it.name.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true)
            }
            val matchingOffers = DatabaseSeeder.getMockOffers().filter {
                it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true)
            }
            GlobalSearchData(matchingPubs, matchingItems, matchingOffers)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GlobalSearchData())
}

data class GlobalSearchData(
    val pubs: List<Pub> = emptyList(),
    val menuItems: List<MenuItem> = emptyList(),
    val offers: List<Offer> = emptyList()
)

// Factory to inject repositories
class SpoonsViewModelFactory(
    private val pubRepository: PubRepository,
    private val menuRepository: MenuRepository,
    private val cartRepository: CartRepository,
    private val orderRepository: OrderRepository,
    private val offerRepository: OfferRepository,
    private val userRepository: UserRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SpoonsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SpoonsViewModel(
                pubRepository,
                menuRepository,
                cartRepository,
                orderRepository,
                offerRepository,
                userRepository
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
