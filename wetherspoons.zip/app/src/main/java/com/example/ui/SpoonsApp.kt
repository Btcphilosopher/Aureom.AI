package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.CartItem
import com.example.core.model.MenuItem
import com.example.core.model.Offer
import com.example.core.model.Order
import com.example.core.model.Pub
import com.example.ui.theme.*

// Define Navigation Screens
sealed class SpoonsScreen {
    object Home : SpoonsScreen()
    object PubFinder : SpoonsScreen()
    object PubProfile : SpoonsScreen()
    object Menu : SpoonsScreen()
    object Cart : SpoonsScreen()
    object Checkout : SpoonsScreen()
    object OrderTracking : SpoonsScreen()
    object OrderHistory : SpoonsScreen()
    object OffersLoyalty : SpoonsScreen()
    object Account : SpoonsScreen()
    object GlobalSearch : SpoonsScreen()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpoonsApp(viewModel: SpoonsViewModel) {
    // Collect Accessibility states
    val isLargeText by viewModel.isLargeText.collectAsStateWithLifecycle()
    val isHighContrast by viewModel.isHighContrast.collectAsStateWithLifecycle()

    // Screen navigation backstack
    var currentScreen by remember { mutableStateOf<SpoonsScreen>(SpoonsScreen.Home) }
    val screenBackstack = remember { mutableStateListOf<SpoonsScreen>() }

    fun navigateTo(screen: SpoonsScreen) {
        screenBackstack.add(currentScreen)
        currentScreen = screen
    }

    fun navigateBack() {
        if (screenBackstack.isNotEmpty()) {
            currentScreen = screenBackstack.removeLast()
        } else {
            currentScreen = SpoonsScreen.Home
        }
    }

    // Load states from ViewModel
    val selectedPub by viewModel.selectedPub.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartTotal by viewModel.cartTotal.collectAsStateWithLifecycle()
    val tableNumber by viewModel.currentTableNumber.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    // Override Typography based on accessibility
    val baseTypography = MaterialTheme.typography
    val customTypography = remember(isLargeText) {
        if (isLargeText) {
            baseTypography.copy(
                displayLarge = baseTypography.displayLarge.copy(fontSize = 38.sp),
                headlineMedium = baseTypography.headlineMedium.copy(fontSize = 28.sp),
                titleMedium = baseTypography.titleMedium.copy(fontSize = 20.sp),
                bodyLarge = baseTypography.bodyLarge.copy(fontSize = 20.sp),
                bodyMedium = baseTypography.bodyMedium.copy(fontSize = 18.sp),
                labelLarge = baseTypography.labelLarge.copy(fontSize = 18.sp)
            )
        } else {
            baseTypography
        }
    }

    val customColors = MaterialTheme.colorScheme

    // Layout configuration
    MaterialTheme(
        colorScheme = customColors,
        typography = customTypography
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    modifier = Modifier.drawBehind {
                        val strokeWidth = 1.dp.toPx()
                        val y = size.height - strokeWidth / 2
                        drawLine(
                            color = if (isHighContrast) Color.DarkGray else SpoonsBorder,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = strokeWidth
                        )
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg,
                        titleContentColor = if (isHighContrast) Color.White else SpoonsBlue
                    ),
                    title = {
                        Text(
                            text = "WETHERSPOONS",
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Serif,
                            letterSpacing = 2.sp,
                            modifier = Modifier.testTag("app_title")
                        )
                    },
                    navigationIcon = {
                        if (currentScreen != SpoonsScreen.Home) {
                            IconButton(onClick = { navigateBack() }) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = if (isHighContrast) Color.White else SpoonsBlue
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { navigateTo(SpoonsScreen.GlobalSearch) }) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Global Search",
                                tint = if (isHighContrast) Color.White else SpoonsBlue
                            )
                        }
                        IconButton(onClick = { navigateTo(SpoonsScreen.Cart) }) {
                            BadgedBox(
                                badge = {
                                    if (cartItems.isNotEmpty()) {
                                        Badge(containerColor = SpoonsRust, contentColor = Color.White) {
                                            Text(cartItems.sumOf { it.quantity }.toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = "Cart",
                                    tint = if (isHighContrast) Color.White else SpoonsBlue
                                )
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.drawBehind {
                        val strokeWidth = 1.dp.toPx()
                        drawLine(
                            color = if (isHighContrast) Color.DarkGray else SpoonsBorder,
                            start = Offset(0f, strokeWidth / 2),
                            end = Offset(size.width, strokeWidth / 2),
                            strokeWidth = strokeWidth
                        )
                    },
                    containerColor = if (isHighContrast) Color.Black else SpoonsCardBg,
                    tonalElevation = 0.dp
                ) {
                    val activeColor = if (isHighContrast) Color.White else SpoonsBlue
                    val inactiveColor = if (isHighContrast) Color.Gray else SpoonsSecondaryText
                    val itemColors = NavigationBarItemDefaults.colors(
                        selectedIconColor = activeColor,
                        selectedTextColor = activeColor,
                        unselectedIconColor = inactiveColor,
                        unselectedTextColor = inactiveColor,
                        indicatorColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige
                    )

                    val homeSelected = currentScreen is SpoonsScreen.Home || currentScreen is SpoonsScreen.PubFinder || currentScreen is SpoonsScreen.PubProfile
                    NavigationBarItem(
                        selected = homeSelected,
                        onClick = { currentScreen = SpoonsScreen.Home },
                        icon = { Icon(Icons.Default.Home, "Home", tint = if (homeSelected) activeColor else inactiveColor) },
                        label = { Text("Home", color = if (homeSelected) activeColor else inactiveColor) },
                        colors = itemColors
                    )
                    
                    val menuSelected = currentScreen is SpoonsScreen.Menu
                    NavigationBarItem(
                        selected = menuSelected,
                        onClick = { navigateTo(SpoonsScreen.Menu) },
                        icon = { Icon(Icons.Default.RestaurantMenu, "Menu", tint = if (menuSelected) activeColor else inactiveColor) },
                        label = { Text("Menu", color = if (menuSelected) activeColor else inactiveColor) },
                        colors = itemColors
                    )
                    
                    val offersSelected = currentScreen is SpoonsScreen.OffersLoyalty
                    NavigationBarItem(
                        selected = offersSelected,
                        onClick = { navigateTo(SpoonsScreen.OffersLoyalty) },
                        icon = { Icon(Icons.Default.CardGiftcard, "Rewards", tint = if (offersSelected) activeColor else inactiveColor) },
                        label = { Text("Offers", color = if (offersSelected) activeColor else inactiveColor) },
                        colors = itemColors
                    )
                    
                    val ordersSelected = currentScreen is SpoonsScreen.OrderHistory || currentScreen is SpoonsScreen.OrderTracking
                    NavigationBarItem(
                        selected = ordersSelected,
                        onClick = { navigateTo(SpoonsScreen.OrderHistory) },
                        icon = { Icon(Icons.Default.History, "Orders", tint = if (ordersSelected) activeColor else inactiveColor) },
                        label = { Text("Orders", color = if (ordersSelected) activeColor else inactiveColor) },
                        colors = itemColors
                    )
                    
                    val accountSelected = currentScreen is SpoonsScreen.Account
                    NavigationBarItem(
                        selected = accountSelected,
                        onClick = { navigateTo(SpoonsScreen.Account) },
                        icon = { Icon(Icons.Default.AccountCircle, "Account", tint = if (accountSelected) activeColor else inactiveColor) },
                        label = { Text("Account", color = if (accountSelected) activeColor else inactiveColor) },
                        colors = itemColors
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(if (isHighContrast) Color.Black else SpoonsIvory)
            ) {
                when (currentScreen) {
                    SpoonsScreen.Home -> HomeScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.PubFinder -> PubFinderScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.PubProfile -> PubProfileScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.Menu -> MenuScreen(viewModel, isHighContrast)
                    SpoonsScreen.Cart -> CartScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.Checkout -> CheckoutScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.OrderTracking -> OrderTrackingScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.OrderHistory -> OrderHistoryScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.OffersLoyalty -> OffersLoyaltyScreen(viewModel, isHighContrast)
                    SpoonsScreen.Account -> AccountScreen(viewModel, { navigateTo(it) }, isHighContrast)
                    SpoonsScreen.GlobalSearch -> GlobalSearchScreen(viewModel, { navigateTo(it) }, isHighContrast)
                }
            }
        }
    }
}

// ==================== 1. HOME SCREEN ====================
@Composable
fun MinimalistQuickActionCard(
    emoji: String,
    title: String,
    onClick: () -> Unit,
    isHighContrast: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(110.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
        ),
        border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isHighContrast) Color.DarkGray else SpoonsLightBeige),
                contentAlignment = Alignment.Center
            ) {
                Text(text = emoji, fontSize = 20.sp)
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (isHighContrast) Color.White else SpoonsBlue
            )
        }
    }
}

@Composable
fun HomeScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val selectedPub by viewModel.selectedPub.collectAsStateWithLifecycle()
    val favouritePubs by viewModel.favouritePubs.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Hero Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .then(
                        if (isHighContrast) {
                            Modifier.background(Color.DarkGray)
                        } else {
                            Modifier.background(
                                Brush.verticalGradient(
                                    colors = listOf(SpoonsBlue, SpoonsBlue.copy(alpha = 0.9f))
                                )
                            )
                        }
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.CenterStart)) {
                    Text(
                        text = "WELCOME BACK",
                        color = SpoonsGold,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Great British Pubs,\nSuperb Value.",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = FontFamily.Serif,
                            lineHeight = 32.sp
                        )
                    )
                }
            }
        }

        // Active Selected Pub Info card (Nearby/Current Venue)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "YOUR CURRENT VENUE",
                        fontWeight = FontWeight.Bold,
                        color = SpoonsSecondaryText,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                    )
                    Text(
                        text = "Change",
                        fontWeight = FontWeight.Bold,
                        color = SpoonsGold,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.clickable { onNavigate(SpoonsScreen.PubFinder) }
                    )
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(SpoonsScreen.PubProfile) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                    ),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1.0f)) {
                                Text(
                                    text = selectedPub?.name ?: "No pub selected",
                                    style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif),
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHighContrast) Color.White else SpoonsBlue
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = selectedPub?.town ?: "Tap to search and select a pub",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                                )
                            }
                            
                            // High polish "Open" green dot and distance badge
                            Column(horizontalAlignment = Alignment.End) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isHighContrast) Color.DarkGray else SpoonsGold)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "0.4 mi",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Open indicator
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(if (isHighContrast) Color.DarkGray else SpoonsBlue.copy(alpha = 0.08f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF4ADE80)) // green-400
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "OPEN",
                                    color = if (isHighContrast) Color.White else SpoonsBlue,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Amenities summary
                            Text(
                                text = "WiFi • Food • Outdoor",
                                style = MaterialTheme.typography.labelSmall,
                                color = SpoonsSecondaryText,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onNavigate(SpoonsScreen.Menu) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("start_order_at_table_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isHighContrast) Color.White else SpoonsGold,
                                contentColor = if (isHighContrast) Color.Black else Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("START ORDER AT TABLE", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                        }
                    }
                }
            }
        }

        // Quick Search Action Bar (Minimal Search Input)
        item {
            OutlinedTextField(
                value = "",
                onValueChange = { },
                readOnly = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(SpoonsScreen.PubFinder) },
                enabled = false,
                placeholder = { Text("Search for a pub...", color = SpoonsSecondaryText) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search Icon",
                        tint = SpoonsBlue
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    disabledBorderColor = Color.Transparent,
                    disabledContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                    disabledPlaceholderColor = SpoonsSecondaryText
                ),
                shape = RoundedCornerShape(16.dp)
            )
        }

        // Quick Action Grid (Clean Minimalism grid-cols-2 layout)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "QUICK ACTIONS",
                    fontWeight = FontWeight.Bold,
                    color = SpoonsSecondaryText,
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MinimalistQuickActionCard(
                        emoji = "🍔",
                        title = "View Menu",
                        onClick = { onNavigate(SpoonsScreen.Menu) },
                        isHighContrast = isHighContrast,
                        modifier = Modifier.weight(1f).testTag("quick_order_button")
                    )
                    MinimalistQuickActionCard(
                        emoji = "🎟️",
                        title = "Daily Offers",
                        onClick = { onNavigate(SpoonsScreen.OffersLoyalty) },
                        isHighContrast = isHighContrast,
                        modifier = Modifier.weight(1f)
                    )
                }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MinimalistQuickActionCard(
                        emoji = "📍",
                        title = "Pub Map",
                        onClick = { onNavigate(SpoonsScreen.PubFinder) },
                        isHighContrast = isHighContrast,
                        modifier = Modifier.weight(1f)
                    )
                    MinimalistQuickActionCard(
                        emoji = "⭐",
                        title = "My Rewards",
                        onClick = { onNavigate(SpoonsScreen.Account) },
                        isHighContrast = isHighContrast,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Favourites list
        if (favouritePubs.isNotEmpty()) {
            item {
                Text(
                    text = "FAVOURITE VENUES",
                    fontWeight = FontWeight.Bold,
                    color = SpoonsSecondaryText,
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                )
            }
            items(favouritePubs) { pub ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.selectPub(pub.id)
                            onNavigate(SpoonsScreen.PubProfile)
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                    ),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Star, "Favourite", tint = SpoonsGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                pub.name,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif),
                                color = if (isHighContrast) Color.White else SpoonsBlue
                            )
                            Text(
                                pub.town,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                            )
                        }
                        Icon(Icons.Default.ChevronRight, "View", tint = SpoonsBlue)
                    }
                }
            }
        }
    }
}

// ==================== 2. PUB FINDER & MAP SCREEN ====================
@Composable
fun PubFinderScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val searchQuery by viewModel.pubSearchQuery.collectAsStateWithLifecycle()
    val pubsList by viewModel.pubsList.collectAsStateWithLifecycle()

    val filterWifi by viewModel.facilityFilterWifi.collectAsStateWithLifecycle()
    val filterFood by viewModel.facilityFilterFood.collectAsStateWithLifecycle()
    val filterAle by viewModel.facilityFilterAle.collectAsStateWithLifecycle()
    val filterAccess by viewModel.facilityFilterAccess.collectAsStateWithLifecycle()
    val filterOutdoor by viewModel.facilityFilterOutdoor.collectAsStateWithLifecycle()

    var showMapMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search bar & Mode switcher
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setPubSearchQuery(it) },
                placeholder = { Text("Search by name or city...", color = SpoonsSecondaryText) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("pub_search_input"),
                leadingIcon = { Icon(Icons.Default.Search, "Search", tint = SpoonsBlue) },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    disabledBorderColor = Color.Transparent,
                    focusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                    unfocusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                    focusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate,
                    unfocusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate
                )
            )
            IconButton(
                onClick = { showMapMode = !showMapMode },
                modifier = Modifier
                    .background(
                        if (showMapMode) SpoonsGold else SpoonsBlue,
                        RoundedCornerShape(16.dp)
                    )
                    .size(52.dp)
            ) {
                Icon(
                    imageVector = if (showMapMode) Icons.Default.List else Icons.Default.Map,
                    contentDescription = "Toggle Map",
                    tint = Color.White
                )
            }
        }

        // Filters horizontal row
        val chipColors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = SpoonsBlue,
            selectedLabelColor = Color.White,
            containerColor = SpoonsLightBeige,
            labelColor = SpoonsSecondaryText
        )
        val chipBorder = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = false,
            borderColor = Color.Transparent,
            selectedBorderColor = Color.Transparent
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = filterWifi,
                    onClick = { viewModel.toggleFilterWifi() },
                    label = { Text("Wi-Fi") },
                    colors = chipColors,
                    border = chipBorder
                )
            }
            item {
                FilterChip(
                    selected = filterFood,
                    onClick = { viewModel.toggleFilterFood() },
                    label = { Text("Food") },
                    colors = chipColors,
                    border = chipBorder
                )
            }
            item {
                FilterChip(
                    selected = filterAle,
                    onClick = { viewModel.toggleFilterAle() },
                    label = { Text("Real Ale") },
                    colors = chipColors,
                    border = chipBorder
                )
            }
            item {
                FilterChip(
                    selected = filterAccess,
                    onClick = { viewModel.toggleFilterAccess() },
                    label = { Text("Accessible") },
                    colors = chipColors,
                    border = chipBorder
                )
            }
            item {
                FilterChip(
                    selected = filterOutdoor,
                    onClick = { viewModel.toggleFilterOutdoor() },
                    label = { Text("Beer Garden") },
                    colors = chipColors,
                    border = chipBorder
                )
            }
        }

        if (showMapMode) {
            // Simulated interactive UK Map
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, SpoonsGold, RoundedCornerShape(12.dp))
                    .background(Color(0xFFE3F2FD)) // Beautiful light blue map background
            ) {
                var selectedMapPub by remember { mutableStateOf<Pub?>(null) }
                
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(pubsList) {
                            detectTapGestures { offset ->
                                // Check if tapped close to any pub point
                                val mapWidth = size.width
                                val mapHeight = size.height
                                var tappedPub: Pub? = null
                                pubsList.forEachIndexed { idx, pub ->
                                    val x = (pub.longitude + 3.0) / 4.0 * mapWidth
                                    val y = (1.0 - (pub.latitude - 51.0) / 3.0) * mapHeight
                                    if (Math.abs(offset.x - x) < 40 && Math.abs(offset.y - y) < 40) {
                                        tappedPub = pub
                                    }
                                }
                                selectedMapPub = tappedPub
                            }
                        }
                ) {
                    val mapWidth = size.width
                    val mapHeight = size.height

                    // Draw a subtle outline representing the UK
                    val ukPath = androidx.compose.ui.graphics.Path().apply {
                        moveTo(mapWidth * 0.4f, mapHeight * 0.9f)
                        lineTo(mapWidth * 0.6f, mapHeight * 0.75f)
                        lineTo(mapWidth * 0.8f, mapHeight * 0.6f)
                        lineTo(mapWidth * 0.5f, mapHeight * 0.3f)
                        lineTo(mapWidth * 0.3f, mapHeight * 0.1f)
                        lineTo(mapWidth * 0.2f, mapHeight * 0.4f)
                        close()
                    }
                    drawPath(
                        path = ukPath,
                        color = Color(0xFFC8E6C9),
                        style = androidx.compose.ui.graphics.drawscope.Fill
                    )

                    // Draw pub points
                    pubsList.forEach { pub ->
                        // Simple map projection
                        val x = (((pub.longitude + 3.0) / 4.0) * mapWidth).toFloat()
                        val y = (((1.0 - (pub.latitude - 51.0) / 3.0)) * mapHeight).toFloat()

                        // Accent ring
                        drawCircle(
                            color = SpoonsGold,
                            radius = 16f,
                            center = Offset(x, y)
                        )
                        drawCircle(
                            color = SpoonsBlue,
                            radius = 10f,
                            center = Offset(x, y)
                        )
                    }
                }

                // Interactive Overlay Callout Card
                selectedMapPub?.let { pub ->
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectPub(pub.id)
                                onNavigate(SpoonsScreen.PubProfile)
                            },
                        colors = CardDefaults.cardColors(containerColor = SpoonsBlue),
                        border = BorderStroke(2.dp, SpoonsGold)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    pub.name,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    "0.6 mi",
                                    color = SpoonsGold,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Text(pub.address, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "TAP TO ENTER VENUE",
                                color = SpoonsGold,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                } ?: Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        "Tap markers to view pubs. Coordinates project onto sandbox UK map.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.DarkGray
                    )
                }
            }
        } else {
            // List Mode
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (pubsList.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.SearchOff, "No results", modifier = Modifier.size(64.dp), tint = Color.Gray)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No pubs match your filters.", fontWeight = FontWeight.Bold, color = Color.Gray)
                        }
                    }
                }

                items(pubsList) { pub ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectPub(pub.id)
                                onNavigate(SpoonsScreen.PubProfile)
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                        ),
                        border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        pub.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif),
                                        fontWeight = FontWeight.Bold,
                                        color = if (isHighContrast) Color.White else SpoonsBlue
                                    )
                                    Text(
                                        "${pub.town} • 0.6 miles away",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                                    )
                                }
                                IconButton(onClick = { viewModel.togglePubFavourite(pub) }) {
                                    Icon(
                                        imageVector = if (pub.isFavourite) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Favourite",
                                        tint = SpoonsGold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            // Facility icons row
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (pub.hasWifi) Icon(Icons.Default.Wifi, "Wi-Fi", size = 16.dp, tint = if (isHighContrast) Color.White else SpoonsBlue)
                                if (pub.hasFood) Icon(Icons.Default.Restaurant, "Food", size = 16.dp, tint = if (isHighContrast) Color.White else SpoonsBlue)
                                if (pub.hasRealAle) Icon(Icons.Default.LocalDrink, "Ale", size = 16.dp, tint = if (isHighContrast) Color.White else SpoonsBlue)
                                if (pub.hasAccessibility) Icon(Icons.Default.Accessible, "Access", size = 16.dp, tint = if (isHighContrast) Color.White else SpoonsBlue)
                                if (pub.hasOutdoorArea) Icon(Icons.Default.Deck, "Outdoor", size = 16.dp, tint = if (isHighContrast) Color.White else SpoonsBlue)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Icon(imageVector: androidx.compose.ui.graphics.vector.ImageVector, contentDescription: String, size: androidx.compose.ui.unit.Dp, tint: Color) {
    Icon(imageVector = imageVector, contentDescription = contentDescription, tint = tint, modifier = Modifier.size(size))
}

// ==================== 3. PUB PROFILE SCREEN ====================
@Composable
fun PubProfileScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val pub by viewModel.selectedPub.collectAsStateWithLifecycle()
    val tableNum by viewModel.currentTableNumber.collectAsStateWithLifecycle()

    pub?.let { selectedPub ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Headline Information
            item {
                Column {
                    Text(
                        text = selectedPub.name,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Serif,
                        color = if (isHighContrast) Color.White else SpoonsBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedPub.address,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "OPEN UNTIL 12:00 AM • FOOD SERVED DAILY",
                        color = SpoonsGold,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp)
                    )
                }
            }

            // Table Selection Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                    ),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "YOUR TABLE",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                            fontWeight = FontWeight.Bold,
                            color = SpoonsSecondaryText
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            OutlinedTextField(
                                value = tableNum,
                                onValueChange = { viewModel.setTableNumber(it) },
                                placeholder = { Text("No.") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .width(90.dp)
                                    .testTag("table_number_input"),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                                    unfocusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                                    focusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate,
                                    unfocusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate
                                )
                            )
                            Column {
                                Text(
                                    text = "Enter your table number to start ordering directly to your seat.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isHighContrast) Color.White else SpoonsSecondaryText
                                )
                            }
                        }
                    }
                }
            }

            // Order Food & Drink CTA
            item {
                Button(
                    onClick = { onNavigate(SpoonsScreen.Menu) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("start_order_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                        contentColor = if (isHighContrast) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.RestaurantMenu, "Menu")
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "START ORDER",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }

            // Facilities Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                    ),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "VENUE FACILITIES",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                            fontWeight = FontWeight.Bold,
                            color = SpoonsSecondaryText
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        val facilities = listOf(
                            Pair(Icons.Default.Wifi, "Complimentary High Speed Wi-Fi") to selectedPub.hasWifi,
                            Pair(Icons.Default.Restaurant, "Fresh Food Menu Served Daily") to selectedPub.hasFood,
                            Pair(Icons.Default.LocalDrink, "Rotating Local Real Ales") to selectedPub.hasRealAle,
                            Pair(Icons.Default.Accessible, "Accessible Toilets & Entrance") to selectedPub.hasAccessibility,
                            Pair(Icons.Default.Deck, "Outdoor Seating / Beer Garden") to selectedPub.hasOutdoorArea,
                            Pair(Icons.Default.Lock, "Cashless ordering safe zone") to true
                        )
                        facilities.forEach { (facility, has) ->
                            if (has) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                ) {
                                    Icon(facility.first, facility.second, size = 20.dp, tint = if (isHighContrast) Color.White else SpoonsBlue)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = facility.second,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isHighContrast) Color.White else SpoonsDarkSlate
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Opening hours
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                    ),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "OPENING HOURS",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                            fontWeight = FontWeight.Bold,
                            color = SpoonsSecondaryText
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        val hours = listOf(
                            "Monday" to selectedPub.openingHours,
                            "Tuesday" to selectedPub.openingHours,
                            "Wednesday" to selectedPub.openingHours,
                            "Thursday" to selectedPub.openingHours,
                            "Friday" to selectedPub.openingHours.replace("00:00", "01:00"),
                            "Saturday" to selectedPub.openingHours.replace("00:00", "01:00"),
                            "Sunday" to selectedPub.openingHours
                        )
                        hours.forEach { (day, times) ->
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text(
                                    text = day,
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isHighContrast) Color.White else SpoonsDarkSlate
                                )
                                Text(
                                    text = times,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHighContrast) Color.LightGray else SpoonsDarkSlate
                                )
                            }
                        }
                    }
                }
            }
        }
    } ?: Box(modifier = Modifier.fillMaxSize()) {
        Text("No Pub Selected", modifier = Modifier.align(Alignment.Center))
    }
}

// ==================== 4. MENU SCREEN ====================
@Composable
fun MenuScreen(viewModel: SpoonsViewModel, isHighContrast: Boolean) {
    val categories by viewModel.menuCategories.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryId.collectAsStateWithLifecycle()
    val menuItems by viewModel.menuItems.collectAsStateWithLifecycle()

    var activeDetailItem by remember { mutableStateOf<MenuItem?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        val chipColors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = SpoonsBlue,
            selectedLabelColor = Color.White,
            containerColor = SpoonsLightBeige,
            labelColor = SpoonsSecondaryText
        )
        val chipBorder = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = false,
            borderColor = Color.Transparent,
            selectedBorderColor = Color.Transparent
        )

        // Horizontal Categories Bar
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (isHighContrast) Color.Black else SpoonsIvory)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = cat.id == selectedCategory
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectCategory(cat.id) },
                    label = { Text(cat.name, fontWeight = FontWeight.Bold) },
                    colors = chipColors,
                    border = chipBorder,
                    modifier = Modifier.testTag("category_chip_${cat.id}")
                )
            }
        }

        // Product Listings
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            items(menuItems) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activeDetailItem = item }
                        .testTag("menu_item_card_${item.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isHighContrast) Color.Black else SpoonsCardBg
                    ),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    item.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif),
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHighContrast) Color.White else SpoonsBlue
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    item.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText,
                                    lineHeight = 16.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                "£${String.format("%.2f", item.price)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isHighContrast) Color.White else SpoonsGold
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Dietary badge helper (Styled custom box)
                            if (item.allergens.contains("Gluten", ignoreCase = true)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isHighContrast) Color.DarkGray else SpoonsLightBeige)
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "Gluten Allergy Info",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isHighContrast) Color.White else SpoonsSecondaryText
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            Button(
                                onClick = { activeDetailItem = item },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                                    contentColor = if (isHighContrast) Color.Black else Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.height(38.dp).testTag("add_item_btn_${item.id}")
                            ) {
                                Icon(Icons.Default.Add, "Add", size = 16.dp, tint = if (isHighContrast) Color.Black else Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("SELECT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    // Detail Dialog (Options modal)
    activeDetailItem?.let { item ->
        ProductDetailDialog(
            item = item,
            isHighContrast = isHighContrast,
            onDismiss = { activeDetailItem = null },
            onConfirm = { quantity, selectedMods ->
                viewModel.addToCart(item, quantity, selectedMods)
                activeDetailItem = null
            }
        )
    }
}

// ==================== 5. PRODUCT OPTIONS DIALOG ====================
@Composable
fun ProductDetailDialog(
    item: MenuItem,
    isHighContrast: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int, String) -> Unit
) {
    var quantity by remember { mutableStateOf(1) }
    val modifiersList = remember(item.modifiers) {
        if (item.modifiers.isEmpty()) emptyList() else item.modifiers.split(",").map { it.trim() }
    }
    val selectedModifiers = remember { mutableStateMapOf<String, Boolean>() }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("product_detail_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
            border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .animateContentSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Title and price
                Row {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            item.name,
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif),
                            fontWeight = FontWeight.Bold,
                            color = if (isHighContrast) Color.White else SpoonsBlue
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "£${String.format("%.2f", item.price)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isHighContrast) Color.White else SpoonsGold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = if (isHighContrast) Color.White else SpoonsBlue)
                    }
                }

                // Description
                Text(
                    item.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isHighContrast) Color.LightGray else Color.Gray
                )

                // Modifiers Selection
                if (modifiersList.isNotEmpty()) {
                    Text(
                        "CUSTOMISE OPTIONS",
                        fontWeight = FontWeight.Bold,
                        color = SpoonsSecondaryText,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        modifiersList.forEach { mod ->
                            val isChecked = selectedModifiers[mod] ?: false
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedModifiers[mod] = !isChecked }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { selectedModifiers[mod] = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = SpoonsBlue,
                                        uncheckedColor = SpoonsSecondaryText,
                                        checkmarkColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    mod,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isHighContrast) Color.White else SpoonsDarkSlate
                                )
                            }
                        }
                    }
                }

                // Allergen Information banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SpoonsRust.copy(alpha = 0.08f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "ALLERGEN ALERTS",
                            fontWeight = FontWeight.Bold,
                            color = SpoonsRust,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(
                            text = if (item.allergens.isEmpty()) "No major allergens declared." else "Allergen: ${item.allergens}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SpoonsRust
                        )
                    }
                }

                // Quantity selector & CTA
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = { if (quantity > 1) quantity-- },
                            modifier = Modifier
                                .size(36.dp)
                                .background(if (isHighContrast) Color.DarkGray else SpoonsLightBeige, CircleShape)
                        ) {
                            Icon(Icons.Default.Remove, "Remove", tint = if (isHighContrast) Color.White else SpoonsBlue, size = 16.dp)
                        }
                        Text(
                            quantity.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isHighContrast) Color.White else SpoonsBlue
                        )
                        IconButton(
                            onClick = { quantity++ },
                            modifier = Modifier
                                .size(36.dp)
                                .background(if (isHighContrast) Color.DarkGray else SpoonsLightBeige, CircleShape)
                        ) {
                            Icon(Icons.Default.Add, "Add", tint = if (isHighContrast) Color.White else SpoonsBlue, size = 16.dp)
                        }
                    }

                    Button(
                        onClick = {
                            val mods = selectedModifiers.filter { it.value }.keys.joinToString(", ")
                            onConfirm(quantity, mods)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                            contentColor = if (isHighContrast) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(44.dp).testTag("add_to_order_confirm")
                    ) {
                        Text("ADD TO ORDER", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==================== 6. CART SCREEN ====================
@Composable
fun CartScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val total by viewModel.cartTotal.collectAsStateWithLifecycle()
    val tableNum by viewModel.currentTableNumber.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "YOUR ORDER",
            style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif),
            fontWeight = FontWeight.ExtraBold,
            color = if (isHighContrast) Color.White else SpoonsBlue
        )

        if (cartItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.ShoppingCart, "Empty Cart", modifier = Modifier.size(80.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(16.dp))
                Text("Your order cart is currently empty.", fontWeight = FontWeight.Bold, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onNavigate(SpoonsScreen.Menu) },
                    colors = ButtonDefaults.buttonColors(containerColor = SpoonsGold)
                ) {
                    Text("Explore Menu", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartItems) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                        border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    item.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif),
                                    fontWeight = FontWeight.Bold,
                                    color = if (isHighContrast) Color.White else SpoonsBlue
                                )
                                if (item.selectedModifiers.isNotEmpty()) {
                                    Text(
                                        item.selectedModifiers,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isHighContrast) Color.White else SpoonsGold
                                    )
                                }
                                Text(
                                    "£${String.format("%.2f", item.price)} each",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                                )
                            }
                            // Quantity Controls
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = { viewModel.updateCartItemQuantity(item, item.quantity - 1) },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(if (isHighContrast) Color.DarkGray else SpoonsLightBeige, CircleShape)
                                ) {
                                    Icon(Icons.Default.Remove, "Less", tint = if (isHighContrast) Color.White else SpoonsBlue, size = 14.dp)
                                }
                                Text(
                                    item.quantity.toString(),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isHighContrast) Color.White else SpoonsBlue
                                )
                                IconButton(
                                    onClick = { viewModel.updateCartItemQuantity(item, item.quantity + 1) },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(if (isHighContrast) Color.DarkGray else SpoonsLightBeige, CircleShape)
                                ) {
                                    Icon(Icons.Default.Add, "More", tint = if (isHighContrast) Color.White else SpoonsBlue, size = 14.dp)
                                }
                            }
                        }
                    }
                }
            }

            // Price calculations card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row {
                        Text("Subtotal", modifier = Modifier.weight(1f), color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                        Text("£${String.format("%.2f", total)}", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsBlue)
                    }
                    Row {
                        Text("VAT (Included 20%)", modifier = Modifier.weight(1f), color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                        Text("£${String.format("%.2f", total * 0.2)}", color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = if (isHighContrast) Color.White else SpoonsBorder)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TOTAL AMOUNT", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsBlue)
                        Text("£${String.format("%.2f", total)}", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                    }
                }
            }

            // Checkout CTAs
            Button(
                onClick = { onNavigate(SpoonsScreen.Checkout) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("checkout_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                    contentColor = if (isHighContrast) Color.Black else Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("CHECKOUT", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

// ==================== 7. CHECKOUT SCREEN ====================
@Composable
fun CheckoutScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val total by viewModel.cartTotal.collectAsStateWithLifecycle()
    val tableNum by viewModel.currentTableNumber.collectAsStateWithLifecycle()
    val pub by viewModel.selectedPub.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var showValidationError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "CHECKOUT",
            style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif),
            fontWeight = FontWeight.ExtraBold,
            color = if (isHighContrast) Color.White else SpoonsBlue
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Venue card info
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("DELIVERY LOCATION", style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp), color = SpoonsSecondaryText, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(pub?.name ?: "No pub selected", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(pub?.address ?: "", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                    }
                }
            }

            // Table validation selection
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("CONFIRM YOUR TABLE", style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp), color = SpoonsSecondaryText, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            OutlinedTextField(
                                value = tableNum,
                                onValueChange = { 
                                    viewModel.setTableNumber(it)
                                    showValidationError = false
                                },
                                placeholder = { Text("No.") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.width(90.dp).testTag("checkout_table_input"),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                                    unfocusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                                    focusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate,
                                    unfocusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate
                                )
                            )
                            Text(
                                "Must be a physical table at this pub location to process order.",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                            )
                        }
                        if (showValidationError) {
                            Text(
                                "Error: A valid table number is required before paying.",
                                color = SpoonsRust,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            }

            // Payment options
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("SANDBOX PAYMENT", style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp), color = SpoonsSecondaryText, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CreditCard, "Card", tint = if (isHighContrast) Color.White else SpoonsBlue, size = 32.dp)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Personal Visa Card", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsDarkSlate)
                                Text(userProfile?.preferredPaymentMethodMasked ?: "•••• 4821", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                            }
                            Icon(Icons.Default.CheckCircle, "Active", tint = if (isHighContrast) Color.White else SpoonsBlue)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "This is a simulated secure sandbox order. No actual charges will be processed.",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                        )
                    }
                }
            }
        }

        // Summary checkout bar
        Button(
            onClick = {
                if (tableNum.trim().isEmpty()) {
                    showValidationError = true
                } else {
                    viewModel.checkoutAndPay()
                    // Add some points to the customer for ordering!
                    viewModel.addPoints(50)
                    onNavigate(SpoonsScreen.OrderTracking)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("pay_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                contentColor = if (isHighContrast) Color.Black else Color.White
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("PAY £${String.format("%.2f", total)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
    }
}

// ==================== 8. LIVE ORDER TRACKING ====================
@Composable
fun OrderTrackingScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val currentOrder by viewModel.lastPlacedOrder.collectAsStateWithLifecycle()
    val items by viewModel.lastPlacedOrderItems.collectAsStateWithLifecycle()

    currentOrder?.let { order ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Confirmation Header
            Icon(Icons.Default.CheckCircle, "Success", tint = if (isHighContrast) Color.White else SpoonsBlue, modifier = Modifier.size(72.dp))
            Text(
                "ORDER CONFIRMED",
                style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif),
                fontWeight = FontWeight.ExtraBold,
                color = if (isHighContrast) Color.White else SpoonsBlue
            )
            Text(
                "ORDER #${order.orderNumber} • TABLE ${order.tableNumber}",
                fontWeight = FontWeight.Bold,
                color = if (isHighContrast) Color.White else SpoonsGold,
                style = MaterialTheme.typography.titleMedium
            )

            // Animated live status stepper
            val steps = listOf("PLACED", "ACCEPTED", "PREPARING", "READY", "DELIVERED")
            val currentIdx = steps.indexOf(order.status)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        "LIVE TRACKER (SANDBOX STATUS)",
                        fontWeight = FontWeight.Bold,
                        color = if (isHighContrast) Color.White else SpoonsSecondaryText,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                    )

                    steps.forEachIndexed { idx, stepName ->
                        val isCompleted = idx <= currentIdx
                        val isCurrent = idx == currentIdx

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(
                                        if (isCompleted) SpoonsBlue else if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isCompleted) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Completed",
                                        tint = Color.White,
                                        size = 14.dp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = stepName,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCurrent) SpoonsGold else if (isCompleted) SpoonsBlue else if (isHighContrast) Color.LightGray else SpoonsSecondaryText,
                                style = if (isCurrent) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            // Estimate Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ESTIMATED DELIVERY TIME", color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText, style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (order.status == "DELIVERED") "DELIVERED!" else "10–14 MINUTES",
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Serif),
                        color = if (isHighContrast) Color.White else SpoonsBlue
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Action Row
            Button(
                onClick = { onNavigate(SpoonsScreen.OrderHistory) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("track_to_receipts_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                    contentColor = if (isHighContrast) Color.Black else Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("VIEW DIGITAL RECEIPT", fontWeight = FontWeight.Bold)
            }
        }
    } ?: Box(modifier = Modifier.fillMaxSize()) {
        Text("No active order tracked. Go to History to view past receipts.", modifier = Modifier.align(Alignment.Center).padding(32.dp), textAlign = TextAlign.Center)
    }
}

// ==================== 9. ORDER HISTORY SCREEN ====================
@Composable
fun OrderHistoryScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    var activeReceiptOrder by remember { mutableStateOf<Order?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "MY ORDERS",
            style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif),
            fontWeight = FontWeight.ExtraBold,
            color = if (isHighContrast) Color.White else SpoonsBlue
        )

        if (orders.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.History, "No Orders", modifier = Modifier.size(80.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(16.dp))
                Text("You haven't placed any orders yet.", fontWeight = FontWeight.Bold, color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(orders) { order ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeReceiptOrder = order }
                            .testTag("order_history_card_${order.id}"),
                        colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                        border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(order.pubName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Table ${order.tableNumber} • #${order.orderNumber}", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        order.status,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isHighContrast) Color.White else SpoonsBlue,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                order.itemSummary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isHighContrast) Color.LightGray else SpoonsDarkSlate
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "£${String.format("%.2f", order.totalAmount)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif),
                                    color = if (isHighContrast) Color.White else SpoonsBlue
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                TextButton(onClick = { activeReceiptOrder = order }) {
                                    Text("VIEW RECEIPT", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsBlue)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { viewModel.quickReorder(order) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                                        contentColor = if (isHighContrast) Color.Black else Color.White
                                    ),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                    modifier = Modifier.height(36.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("REORDER", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Receipt details view modal
    activeReceiptOrder?.let { order ->
        DigitalReceiptDialog(
            order = order,
            isHighContrast = isHighContrast,
            onDismiss = { activeReceiptOrder = null }
        )
    }
}

// ==================== 10. DIGITAL RECEIPT DIALOG ====================
@Composable
fun DigitalReceiptDialog(order: Order, isHighContrast: Boolean, onDismiss: () -> Unit) {
    val context = LocalContext.current

    // Share action
    val shareIntent = Intent().apply {
        action = Intent.ACTION_SEND
        type = "text/plain"
        putExtra(
            Intent.EXTRA_TEXT,
            """
                WETHERSPOONS DIGITAL RECEIPT
                Venue: ${order.pubName}
                Order: #${order.orderNumber}
                Table: ${order.tableNumber}
                Items: ${order.itemSummary}
                Total: £${String.format("%.2f", order.totalAmount)}
                Thank you for visiting Wetherspoons.
            """.trimIndent()
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("receipt_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
            border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Receipts Header
                Text(
                    "WETHERSPOONS",
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Serif,
                    fontSize = 20.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    color = if (isHighContrast) Color.White else SpoonsBlue
                )
                Text(
                    "DIGITAL TRANSACTION RECORD",
                    fontFamily = FontFamily.Serif,
                    fontSize = 10.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText,
                    fontWeight = FontWeight.Medium
                )

                HorizontalDivider(color = if (isHighContrast) Color.White else SpoonsBorder)

                // Transaction parameters
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("VENUE: ${order.pubName}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.White else SpoonsDarkSlate)
                    Text("TABLE NO: ${order.tableNumber}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.White else SpoonsDarkSlate)
                    Text("TRANS ID: ${order.id.take(8).uppercase()}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.White else SpoonsDarkSlate)
                    Text("ORDER NO: #${order.orderNumber}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.White else SpoonsDarkSlate)
                    Text("DATE: 18 AUGUST 2026", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.White else SpoonsDarkSlate)
                }

                HorizontalDivider(color = if (isHighContrast) Color.White else SpoonsBorder)

                // Mock list of item receipts
                Text(
                    order.itemSummary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = if (isHighContrast) Color.White else SpoonsDarkSlate
                )

                HorizontalDivider(color = if (isHighContrast) Color.White else SpoonsBorder)

                // Pricing total lines
                Row {
                    Text("VAT (20.00%)", fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), fontSize = 11.sp, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                    Text("£${String.format("%.2f", order.totalAmount * 0.2)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                }
                Row {
                    Text("NET TOTAL", fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), fontSize = 11.sp, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                    Text("£${String.format("%.2f", order.totalAmount * 0.8)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                }
                Row {
                    Text("TOTAL PAID", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 12.sp, color = if (isHighContrast) Color.White else SpoonsBlue)
                    Text("£${String.format("%.2f", order.totalAmount)}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (isHighContrast) Color.White else SpoonsBlue)
                }

                HorizontalDivider(color = if (isHighContrast) Color.White else SpoonsBorder)

                Text(
                    "THANK YOU FOR VISITING.\nSANDBOX TRANSACTION SUMMARY",
                    fontFamily = FontFamily.Serif,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isHighContrast) Color.White else SpoonsBlue
                        ),
                        border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder)
                    ) {
                        Text("CLOSE", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { context.startActivity(Intent.createChooser(shareIntent, "Share Receipt")) },
                        modifier = Modifier.weight(1f).height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isHighContrast) Color.White else SpoonsBlue,
                            contentColor = if (isHighContrast) Color.Black else Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Share, "Share", size = 16.dp, tint = if (isHighContrast) Color.Black else Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SHARE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==================== 11. OFFERS & LOYALTY SCREEN ====================
@Composable
fun OffersLoyaltyScreen(viewModel: SpoonsViewModel, isHighContrast: Boolean) {
    val offers by viewModel.offersList.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Loyalty Tracker header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsBlue),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "SPOONS REWARDS CLUB",
                        color = if (isHighContrast) Color.White else SpoonsGold,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "${profile?.points ?: 2840}",
                        style = MaterialTheme.typography.displayLarge.copy(fontFamily = FontFamily.Serif),
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isHighContrast) Color.White else Color.White
                    )
                    Text(
                        text = "TOTAL REWARDS POINTS",
                        color = if (isHighContrast) Color.LightGray else Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    LinearProgressIndicator(
                        progress = { 0.85f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (isHighContrast) Color.White else SpoonsGold,
                        trackColor = Color.White.copy(alpha = 0.2f),
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "160 points away from your next free pint coupon!",
                        color = if (isHighContrast) Color.LightGray else Color.White,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Available vouchers row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("3", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Active Coupons", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                    border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Gold", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Regular Class", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                    }
                }
            }
        }

        // Active Promotions title
        item {
            Text(
                "ACTIVE PUB COMMERCE OFFERS",
                style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Serif),
                fontWeight = FontWeight.Bold,
                color = if (isHighContrast) Color.White else SpoonsBlue
            )
        }

        // Offer cards
        items(offers) { offer ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                offer.badge,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isHighContrast) Color.White else SpoonsBlue,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            offer.discountDescription,
                            color = SpoonsRust,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        offer.title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif),
                        color = if (isHighContrast) Color.White else SpoonsBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        offer.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                    )
                }
            }
        }
    }
}

// ==================== 12. ACCOUNT SCREEN ====================
@Composable
fun AccountScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isLargeText by viewModel.isLargeText.collectAsStateWithLifecycle()
    val isHighContrastSetting by viewModel.isHighContrast.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User profile info banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, "Profile", tint = if (isHighContrast) Color.White else SpoonsBlue, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            profile?.name ?: "Tom",
                            style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Serif),
                            fontWeight = FontWeight.Bold,
                            color = if (isHighContrast) Color.White else SpoonsBlue
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "${profile?.levelName ?: "Gold Regular"} Member",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isHighContrast) Color.White else SpoonsGold,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Accessibility Settings group
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "ACCESSIBILITY OPTIONS",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                        fontWeight = FontWeight.Bold,
                        color = if (isHighContrast) Color.White else SpoonsSecondaryText
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Large Text switch
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enlarge Text Size", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsBlue)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Increases size for menus and lists", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                        }
                        Switch(
                            checked = isLargeText,
                            onCheckedChange = { viewModel.toggleLargeText() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SpoonsBlue,
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = SpoonsLightBeige
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // High Contrast switch
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("High Contrast Mode", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsBlue)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Enables safe high-contrast palettes", style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                        }
                        Switch(
                            checked = isHighContrastSetting,
                            onCheckedChange = { viewModel.toggleHighContrast() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SpoonsBlue,
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = SpoonsLightBeige
                            )
                        )
                    }
                }
            }
        }

        // App credentials declaration
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "APP INFORMATION",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                        fontWeight = FontWeight.Bold,
                        color = if (isHighContrast) Color.White else SpoonsSecondaryText
                    )
                    Text("Version: 1.0 (PROTOTYPE CONCEPT)", style = MaterialTheme.typography.bodyMedium, color = if (isHighContrast) Color.White else SpoonsBlue, fontWeight = FontWeight.SemiBold)
                    Text(
                        "This concept is developed under mock sandbox policies for demonstration purposes. No real transactional API is currently invoked.",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText
                    )
                }
            }
        }
    }
}

// ==================== 13. GLOBAL SEARCH SCREEN ====================
@Composable
fun GlobalSearchScreen(viewModel: SpoonsViewModel, onNavigate: (SpoonsScreen) -> Unit, isHighContrast: Boolean) {
    val searchQuery by viewModel.globalSearchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.globalSearchResults.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setGlobalSearchQuery(it) },
            placeholder = { Text("Search pubs, food, drinks, ales...") },
            modifier = Modifier.fillMaxWidth().testTag("global_search_input"),
            leadingIcon = { Icon(Icons.Default.Search, "Search", tint = if (isHighContrast) Color.White else SpoonsBlue) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
                focusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                unfocusedContainerColor = if (isHighContrast) Color.DarkGray else SpoonsLightBeige,
                focusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate,
                unfocusedTextColor = if (isHighContrast) Color.White else SpoonsDarkSlate
            )
        )

        if (searchQuery.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Type above to search across Wetherspoons", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsBlue, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif))
                Spacer(modifier = Modifier.height(8.dp))
                Text("Try searching: 'Birmingham', 'Fish', 'Ales' or 'Breakfast'", style = MaterialTheme.typography.bodyMedium, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Matching Pubs section
                if (searchResults.pubs.isNotEmpty()) {
                    item {
                        Text("PUBS", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsSecondaryText, style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp))
                    }
                    items(searchResults.pubs) { pub ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectPub(pub.id)
                                    onNavigate(SpoonsScreen.PubProfile)
                                },
                            colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                            border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Storefront, "Pub", tint = if (isHighContrast) Color.White else SpoonsBlue)
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(pub.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(pub.address, style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                                }
                            }
                        }
                    }
                }

                // Matching Menu Items
                if (searchResults.menuItems.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("MENU ITEMS", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsSecondaryText, style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp))
                    }
                    items(searchResults.menuItems) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectCategory(item.categoryId)
                                    onNavigate(SpoonsScreen.Menu)
                                },
                            colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                            border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Restaurant, "Food", tint = if (isHighContrast) Color.White else SpoonsBlue)
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(item.description, style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText, maxLines = 1)
                                }
                                Text("£${String.format("%.2f", item.price)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                            }
                        }
                    }
                }

                // Matching Offers
                if (searchResults.offers.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("OFFERS & PROMOTIONS", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.White else SpoonsSecondaryText, style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp))
                    }
                    items(searchResults.offers) { offer ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onNavigate(SpoonsScreen.OffersLoyalty) },
                            colors = CardDefaults.cardColors(containerColor = if (isHighContrast) Color.Black else SpoonsCardBg),
                            border = BorderStroke(1.dp, if (isHighContrast) Color.White else SpoonsBorder),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CardGiftcard, "Offer", tint = if (isHighContrast) Color.White else SpoonsBlue)
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(offer.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif), color = if (isHighContrast) Color.White else SpoonsBlue)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(offer.description, style = MaterialTheme.typography.bodySmall, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText)
                                }
                            }
                        }
                    }
                }

                // Empty state if nothing matches query
                if (searchResults.pubs.isEmpty() && searchResults.menuItems.isEmpty() && searchResults.offers.isEmpty()) {
                    item {
                        Column(modifier = Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No match found for '$searchQuery'.", fontWeight = FontWeight.Bold, color = if (isHighContrast) Color.LightGray else SpoonsSecondaryText, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
