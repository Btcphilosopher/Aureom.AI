package com.example.core.repository

import com.example.core.database.CartDao
import com.example.core.database.MenuDao
import com.example.core.database.OfferDao
import com.example.core.database.OrderDao
import com.example.core.database.PubDao
import com.example.core.database.UserProfileDao
import com.example.core.model.CartItem
import com.example.core.model.MenuCategory
import com.example.core.model.MenuItem
import com.example.core.model.Offer
import com.example.core.model.Order
import com.example.core.model.OrderItem
import com.example.core.model.Pub
import com.example.core.model.UserProfile
import kotlinx.coroutines.flow.Flow

class PubRepository(private val pubDao: PubDao) {
    val allPubs: Flow<List<Pub>> = pubDao.getAllPubs()
    val favouritePubs: Flow<List<Pub>> = pubDao.getFavouritePubs()

    fun getPubById(id: String): Flow<Pub?> = pubDao.getPubById(id)
    suspend fun getPubByIdOneShot(id: String): Pub? = pubDao.getPubByIdOneShot(id)
    suspend fun updatePub(pub: Pub) = pubDao.updatePub(pub)
    fun searchPubs(query: String): Flow<List<Pub>> = pubDao.searchPubs(query)
}

class MenuRepository(private val menuDao: MenuDao) {
    val categories: Flow<List<MenuCategory>> = menuDao.getCategories()

    fun getItemsByCategory(categoryId: String): Flow<List<MenuItem>> = menuDao.getItemsByCategory(categoryId)
    suspend fun getItemById(id: String): MenuItem? = menuDao.getItemById(id)
    fun searchMenuItems(query: String): Flow<List<MenuItem>> = menuDao.searchMenuItems(query)
}

class CartRepository(private val cartDao: CartDao) {
    fun getCartItems(pubId: String): Flow<List<CartItem>> = cartDao.getCartItems(pubId)
    suspend fun getCartItemsOneShot(pubId: String): List<CartItem> = cartDao.getCartItemsOneShot(pubId)
    suspend fun insertCartItem(item: CartItem) = cartDao.insertCartItem(item)
    suspend fun updateCartItem(item: CartItem) = cartDao.updateCartItem(item)
    suspend fun deleteCartItem(id: Int) = cartDao.deleteCartItem(id)
    suspend fun clearCart(pubId: String) = cartDao.clearCart(pubId)
}

class OrderRepository(private val orderDao: OrderDao) {
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()

    fun getOrderById(orderId: String): Flow<Order?> = orderDao.getOrderById(orderId)
    suspend fun getOrderByIdOneShot(orderId: String): Order? = orderDao.getOrderByIdOneShot(orderId)
    
    suspend fun insertOrder(order: Order, items: List<OrderItem>) {
        orderDao.insertOrder(order)
        orderDao.insertOrderItems(items)
    }

    suspend fun updateOrderStatus(orderId: String, status: String) = orderDao.updateOrderStatus(orderId, status)
    fun getOrderItems(orderId: String): Flow<List<OrderItem>> = orderDao.getOrderItems(orderId)
}

class OfferRepository(private val offerDao: OfferDao) {
    val allOffers: Flow<List<Offer>> = offerDao.getAllOffers()
}

class UserRepository(private val userProfileDao: UserProfileDao) {
    val userProfile: Flow<UserProfile?> = userProfileDao.getUserProfile()
    suspend fun getUserProfileOneShot(): UserProfile? = userProfileDao.getUserProfileOneShot()
    suspend fun updateUserProfile(profile: UserProfile) = userProfileDao.insertUserProfile(profile)
}
