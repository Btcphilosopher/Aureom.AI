package com.example.core.database

import com.example.core.model.MenuCategory
import com.example.core.model.MenuItem
import com.example.core.model.Offer
import com.example.core.model.Pub
import com.example.core.model.UserProfile

object DatabaseSeeder {

    fun getMockPubs(): List<Pub> = listOf(
        Pub(
            id = "pub_moon_stars",
            name = "The Moon & Stars",
            town = "Birmingham",
            address = "10-14 Broad Street, Birmingham, B1 2DY",
            latitude = 52.4789,
            longitude = -1.9123,
            openingHours = "08:00 - 00:00",
            hasFood = true,
            hasWifi = true,
            hasRealAle = true,
            hasAccessibility = true,
            hasOutdoorArea = true,
            isFavourite = true
        ),
        Pub(
            id = "pub_red_lion",
            name = "The Red Lion",
            town = "Manchester",
            address = "52 Chapel Street, Salford, Manchester, M3 7AA",
            latitude = 53.4839,
            longitude = -2.2534,
            openingHours = "08:00 - 01:00",
            hasFood = true,
            hasWifi = true,
            hasRealAle = true,
            hasAccessibility = true,
            hasOutdoorArea = false,
            isFavourite = false
        ),
        Pub(
            id = "pub_crown",
            name = "The Crown",
            town = "Sheffield",
            address = "10 Albert Avenue, Sheffield, S6 3AL",
            latitude = 53.3811,
            longitude = -1.4701,
            openingHours = "08:00 - 23:00",
            hasFood = true,
            hasWifi = true,
            hasRealAle = true,
            hasAccessibility = true,
            hasOutdoorArea = true,
            isFavourite = false
        ),
        Pub(
            id = "pub_railway_tavern",
            name = "The Railway Tavern",
            town = "Leeds",
            address = "8 Station Parade, Leeds, LS1 5HD",
            latitude = 53.7997,
            longitude = -1.5492,
            openingHours = "07:00 - 00:00",
            hasFood = true,
            hasWifi = true,
            hasRealAle = false,
            hasAccessibility = true,
            hasOutdoorArea = true,
            isFavourite = false
        ),
        Pub(
            id = "pub_kings_arms",
            name = "The King's Arms",
            town = "London",
            address = "142-146 Tooley Street, London, SE1 2TU",
            latitude = 51.5034,
            longitude = -0.0792,
            openingHours = "08:00 - 01:00",
            hasFood = true,
            hasWifi = true,
            hasRealAle = true,
            hasAccessibility = false,
            hasOutdoorArea = true,
            isFavourite = false
        )
    )

    fun getMockCategories(): List<MenuCategory> = listOf(
        MenuCategory("cat_breakfast", "Breakfast", 1),
        MenuCategory("cat_classics", "Pub Classics", 2),
        MenuCategory("cat_burgers", "Burgers & Grills", 3),
        MenuCategory("cat_pizzas", "Fresh Pizzas", 4),
        MenuCategory("cat_real_ales", "Real Ales & Craft Beers", 5),
        MenuCategory("cat_soft_drinks", "Soft Drinks & Coffee", 6),
        MenuCategory("cat_desserts", "Sweet Desserts", 7)
    )

    fun getMockMenuItems(): List<MenuItem> = listOf(
        // Breakfast Category
        MenuItem(
            id = "item_full_english",
            categoryId = "cat_breakfast",
            name = "Traditional Full English Breakfast",
            price = 5.95,
            description = "Fried egg, bacon, sausage, baked beans, two hash browns, slice of toast, butter.",
            isAvailable = true,
            allergens = "Gluten, Eggs, Milk, Sulphur Dioxide",
            modifiers = "Add extra sausage (+£1.20), Add black pudding (+£0.95), Extra hash brown (+£0.75)"
        ),
        MenuItem(
            id = "item_veggie_breakfast",
            categoryId = "cat_breakfast",
            name = "Vegetarian Breakfast",
            price = 5.95,
            description = "Two fried eggs, two Quorn vegan sausages, baked beans, two hash browns, mushroom, tomato, slice of toast.",
            isAvailable = true,
            allergens = "Gluten, Eggs, Milk",
            modifiers = "Add extra Quorn sausage (+£1.20), Extra hash brown (+£0.75)"
        ),
        MenuItem(
            id = "item_breakfast_wrap",
            categoryId = "cat_breakfast",
            name = "Breakfast Wrap",
            price = 4.25,
            description = "Fried egg, bacon, sausage, hash brown, Cheddar cheese in a white warm wrap.",
            isAvailable = true,
            allergens = "Gluten, Eggs, Milk",
            modifiers = "Add brown sauce (+£0.00), Add tomato ketchup (+£0.00)"
        ),

        // Pub Classics Category
        MenuItem(
            id = "item_fish_chips",
            categoryId = "cat_classics",
            name = "Freshly Battered Cod & Chips",
            price = 9.45,
            description = "Cod freshly hand-battered, served with chips, peas (mushy or garden) and tartar sauce.",
            isAvailable = true,
            allergens = "Gluten, Fish, Eggs, Mustard",
            modifiers = "With mushy peas (+£0.00), With garden peas (+£0.00), Add curry sauce (+£1.40)"
        ),
        MenuItem(
            id = "item_tikka_masala",
            categoryId = "cat_classics",
            name = "Chicken Tikka Masala",
            price = 8.95,
            description = "Chicken breast in a mild, creamy tikka masala sauce, served with basmati pilau rice, plain naan bread, poppadums.",
            isAvailable = true,
            allergens = "Gluten, Nuts, Mustard, Milk",
            modifiers = "Add garlic naan (+£0.60), Add mango chutney (+£0.00)"
        ),
        MenuItem(
            id = "item_ham_egg_chips",
            categoryId = "cat_classics",
            name = "Wiltshire Cured Ham, Eggs & Chips",
            price = 7.75,
            description = "Two slices of Wiltshire cured ham, two fried British free-range eggs and a generous portion of chips.",
            isAvailable = true,
            allergens = "Eggs, Gluten",
            modifiers = "Add slice of bread & butter (+£0.80)"
        ),

        // Burgers Category
        MenuItem(
            id = "item_classic_beef_burger",
            categoryId = "cat_burgers",
            name = "Classic 6oz Beef Burger",
            price = 6.95,
            description = "Grilled 100% British beef patty served in a toasted brioche bun with lettuce, tomato, red onion and chips.",
            isAvailable = true,
            allergens = "Gluten, Milk, Sesame",
            modifiers = "Add mature Cheddar cheese (+£1.10), Add maple-cured bacon (+£1.40), Double up patty (+£2.20)"
        ),
        MenuItem(
            id = "item_gourmet_burger",
            categoryId = "cat_burgers",
            name = "Ultimate Gourmet Burger",
            price = 9.85,
            description = "6oz beef patty, maple-cured bacon, Jack Daniel's Tennessee Honey glaze, Cheddar cheese, onion rings, chips.",
            isAvailable = true,
            allergens = "Gluten, Milk, Sesame, Mustard",
            modifiers = "Swap for onion rings only (+£0.00)"
        ),

        // Pizzas Category
        MenuItem(
            id = "item_margherita_pizza",
            categoryId = "cat_pizzas",
            name = "Fresh 11\" Margherita Pizza",
            price = 8.25,
            description = "Freshly rolled sourdough pizza base topped with rich tomato sauce, mozzarella cheese, and fresh basil leaves.",
            isAvailable = true,
            allergens = "Gluten, Milk",
            modifiers = "Add pepperoni (+£1.30), Add sliced mushrooms (+£0.90), Add jalapeños (+£0.70)"
        ),
        MenuItem(
            id = "item_spicy_meat_pizza",
            categoryId = "cat_pizzas",
            name = "Spicy Meat Feast Pizza",
            price = 9.95,
            description = "Sourdough pizza base topped with mozzarella, spicy beef, pepperoni, chicken breast, and sliced red chillies.",
            isAvailable = true,
            allergens = "Gluten, Milk",
            modifiers = "Add extra mozzarella (+£1.20), Extra jalapeños (+£0.70)"
        ),

        // Real Ales & Beers Category
        MenuItem(
            id = "item_abbot_ale",
            categoryId = "cat_real_ales",
            name = "Abbot Ale (Pint)",
            price = 3.20,
            description = "Classic English pale ale. Rich, malty, full-bodied with sweet fruit character and a superb hop balance. 5.0% ABV.",
            isAvailable = true,
            allergens = "Gluten (Barley)",
            modifiers = "Pint (+£0.00), Half Pint (-£1.50)"
        ),
        MenuItem(
            id = "item_punk_ipa",
            categoryId = "cat_real_ales",
            name = "BrewDog Punk IPA (Pint)",
            price = 4.10,
            description = "Light golden IPA with tropical fruit aromas, sharp citrus notes, and a spiky bitter finish. 5.2% ABV.",
            isAvailable = true,
            allergens = "Gluten (Barley)",
            modifiers = "Pint (+£0.00), Half Pint (-£1.95)"
        ),
        MenuItem(
            id = "item_doom_bar",
            categoryId = "cat_real_ales",
            name = "Sharp's Doom Bar (Pint)",
            price = 2.95,
            description = "Balanced English amber ale with succulent dried fruit, roasted malt notes and a dry finish. 4.0% ABV.",
            isAvailable = true,
            allergens = "Gluten (Barley)",
            modifiers = "Pint (+£0.00), Half Pint (-£1.40)"
        ),

        // Soft Drinks Category
        MenuItem(
            id = "item_pepsi_max",
            categoryId = "cat_soft_drinks",
            name = "Pepsi Max (Large)",
            price = 1.95,
            description = "Maximum taste, no sugar. Refreshing, cold draught cola beverage.",
            isAvailable = true,
            allergens = "None",
            modifiers = "Large (+£0.00), Regular (-£0.35), Add fresh lime (+£0.20)"
        ),
        MenuItem(
            id = "item_unlimited_coffee",
            categoryId = "cat_soft_drinks",
            name = "Unlimited Lavazza Coffee",
            price = 1.65,
            description = "Includes unlimited self-service refills from our machine. Select from espresso, latte, cappuccino or hot chocolate.",
            isAvailable = true,
            allergens = "Milk (if added)",
            modifiers = "Use Oat Milk (+£0.00), Plain Black (+£0.00)"
        ),

        // Desserts Category
        MenuItem(
            id = "item_apple_crumble",
            categoryId = "cat_desserts",
            name = "Warm Apple Crumble",
            price = 4.45,
            description = "Sweet British apples baked with a crunchy golden crumble top, served warm with dairy custard or ice cream.",
            isAvailable = true,
            allergens = "Gluten, Milk",
            modifiers = "With custard (+£0.00), With vanilla ice cream (+£0.00)"
        ),
        MenuItem(
            id = "item_fudge_cake",
            categoryId = "cat_desserts",
            name = "Warm Chocolate Fudge Cake",
            price = 4.25,
            description = "Rich, moist double chocolate fudge cake, served warm with vanilla ice cream.",
            isAvailable = true,
            allergens = "Gluten, Milk, Soya",
            modifiers = "With cream (+0.00), With ice cream (+0.00)"
        )
    )

    fun getMockOffers(): List<Offer> = listOf(
        Offer(
            id = "off_meal_deal",
            title = "Club Meal Deals",
            description = "Includes a drink from our selected range! Available on all pub classics and burgers daily.",
            badge = "CLUB DEALS",
            discountDescription = "Save up to £2.50 with an included pint or soft drink."
        ),
        Offer(
            id = "off_breakfast_deal",
            title = "Breakfast & Hot Drink Combo",
            description = "Pair any breakfast item with a hot drink of your choice and enjoy free unlimited hot refills until 12:00 PM.",
            badge = "BREAKFAST",
            discountDescription = "Complimentary hot refills included."
        ),
        Offer(
            id = "off_ales_trio",
            title = "Real Ale Tasting Trio",
            description = "Can't decide? Try any three of our rotating guest real ales in third-of-a-pint glasses.",
            badge = "REAL ALE",
            discountDescription = "Three thirds for the price of a single pint."
        )
    )

    fun getMockUserProfile(): UserProfile = UserProfile()
}
