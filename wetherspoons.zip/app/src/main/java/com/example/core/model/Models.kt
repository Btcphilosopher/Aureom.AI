package com.example.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "pubs")
data class Pub(
    @PrimaryKey val id: String,
    val name: String,
    val town: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val openingHours: String, // e.g. "08:00 - 00:00"
    val hasFood: Boolean = true,
    val hasWifi: Boolean = true,
    val hasRealAle: Boolean = true,
    val hasAccessibility: Boolean = true,
    val hasOutdoorArea: Boolean = true,
    val isFavourite: Boolean = false
) : Serializable

@Entity(tableName = "menu_categories")
data class MenuCategory(
    @PrimaryKey val id: String,
    val name: String,
    val displayOrder: Int
) : Serializable

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey val id: String,
    val categoryId: String,
    val name: String,
    val price: Double,
    val description: String,
    val isAvailable: Boolean = true,
    val allergens: String, // Comma separated list, e.g. "Gluten, Fish"
    val modifiers: String, // Comma separated list, e.g. "Add Mushy Peas (+£1.00), Add Tartar Sauce (+£0.50)"
    val imageUrl: String = ""
) : Serializable

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val pubId: String,
    val menuItemId: String,
    val name: String,
    val price: Double,
    val quantity: Int,
    val selectedModifiers: String // Comma separated list of chosen modifiers
) : Serializable

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String, // Order UUID or local #
    val orderNumber: String, // User-friendly number e.g. "10482"
    val pubId: String,
    val pubName: String,
    val tableNumber: String,
    val totalAmount: Double,
    val status: String, // PLACED, ACCEPTED, PREPARING, READY, DELIVERED
    val timestamp: Long,
    val itemSummary: String // e.g. "1 × Fish & Chips, 1 × Cola"
) : Serializable

@Entity(tableName = "order_items")
data class OrderItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderId: String,
    val menuItemId: String,
    val name: String,
    val price: Double,
    val quantity: Int,
    val selectedModifiers: String
) : Serializable

@Entity(tableName = "offers")
data class Offer(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val badge: String, // e.g. "MEAL DEAL", "BREAKFAST"
    val discountDescription: String
) : Serializable

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: String = "default_user",
    val name: String = "Tom",
    val points: Int = 2840,
    val levelName: String = "Gold Regular",
    val preferredAccessibility: Boolean = false,
    val preferredPaymentMethodMasked: String = "•••• 4821"
) : Serializable
