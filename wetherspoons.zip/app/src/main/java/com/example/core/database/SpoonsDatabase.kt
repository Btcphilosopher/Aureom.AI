package com.example.core.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.core.model.CartItem
import com.example.core.model.MenuCategory
import com.example.core.model.MenuItem
import com.example.core.model.Offer
import com.example.core.model.Order
import com.example.core.model.OrderItem
import com.example.core.model.Pub
import com.example.core.model.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface PubDao {
    @Query("SELECT * FROM pubs")
    fun getAllPubs(): Flow<List<Pub>>

    @Query("SELECT * FROM pubs WHERE id = :id")
    fun getPubById(id: String): Flow<Pub?>

    @Query("SELECT * FROM pubs WHERE id = :id")
    suspend fun getPubByIdOneShot(id: String): Pub?

    @Query("SELECT * FROM pubs WHERE isFavourite = 1")
    fun getFavouritePubs(): Flow<List<Pub>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPubs(pubs: List<Pub>)

    @Update
    suspend fun updatePub(pub: Pub)

    @Query("SELECT * FROM pubs WHERE name LIKE '%' || :query || '%' OR town LIKE '%' || :query || '%'")
    fun searchPubs(query: String): Flow<List<Pub>>
}

@Dao
interface MenuDao {
    @Query("SELECT * FROM menu_categories ORDER BY displayOrder ASC")
    fun getCategories(): Flow<List<MenuCategory>>

    @Query("SELECT * FROM menu_items WHERE categoryId = :categoryId")
    fun getItemsByCategory(categoryId: String): Flow<List<MenuItem>>

    @Query("SELECT * FROM menu_items WHERE id = :id")
    suspend fun getItemById(id: String): MenuItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<MenuCategory>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMenuItems(items: List<MenuItem>)

    @Query("SELECT * FROM menu_items WHERE name LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchMenuItems(query: String): Flow<List<MenuItem>>
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items WHERE pubId = :pubId")
    fun getCartItems(pubId: String): Flow<List<CartItem>>

    @Query("SELECT * FROM cart_items WHERE pubId = :pubId")
    suspend fun getCartItemsOneShot(pubId: String): List<CartItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItem)

    @Update
    suspend fun updateCartItem(item: CartItem)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items WHERE pubId = :pubId")
    suspend fun clearCart(pubId: String)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :orderId")
    fun getOrderById(orderId: String): Flow<Order?>

    @Query("SELECT * FROM orders WHERE id = :orderId")
    suspend fun getOrderByIdOneShot(orderId: String): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Query("UPDATE orders SET status = :status WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItem>)

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItems(orderId: String): Flow<List<OrderItem>>
}

@Dao
interface OfferDao {
    @Query("SELECT * FROM offers")
    fun getAllOffers(): Flow<List<Offer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffers(offers: List<Offer>)
}

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile LIMIT 1")
    suspend fun getUserProfileOneShot(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserProfile(profile: UserProfile)
}

@Database(
    entities = [
        Pub::class,
        MenuCategory::class,
        MenuItem::class,
        CartItem::class,
        Order::class,
        OrderItem::class,
        Offer::class,
        UserProfile::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SpoonsDatabase : RoomDatabase() {
    abstract fun pubDao(): PubDao
    abstract fun menuDao(): MenuDao
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao
    abstract fun offerDao(): OfferDao
    abstract fun userProfileDao(): UserProfileDao
}
