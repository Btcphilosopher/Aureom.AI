# AUREOM COMMONS — Private Library & Peer Publishing

A personal digital library, a private reading room and an independent
publishing tool in one desktop application. It works offline, shares only
what you deliberately share, and lets you distribute signed, versioned
editions directly to readers over a peer-to-peer connection.

```
Library · Reading Room · Collections · Peers · Publish · Transfers · Activity · Settings
```

Three spaces are kept strictly apart:

| Space | Who can see it | How a work gets there |
|---|---|---|
| **Private library** | only you, on your devices | importing a file — and nothing else happens |
| **Shared collections** | people you explicitly invite, after they authenticate | adding a work to a shared collection that has members |
| **Published catalogue** | anyone | Draft → Preview → Rights Review → an explicit *Publish* |

Importing a document never shares, publishes or announces it.

![Library](docs/screenshots/02-library-covers.png)

## Quick start

Requires Python 3.11+ (developed and tested on 3.13, Linux).

```bash
python -m venv .venv
```
```bash
. .venv/bin/activate
```
```bash
pip install -e ".[dev]"
```
```bash
python scripts/demo_three_peers.py
```
```bash
python -m pytest
```
```bash
aureom-commons --profile alice
```

`aureom-commons` opens the desktop application (first run asks for a device
name and an optional library passphrase). `--profile NAME` selects an
isolated installation — its own database, object store, keys and port — so
you can run several side by side on one machine. See
[docs/SETUP.md](docs/SETUP.md) for platform notes and packaging.

## The three-peer demonstration

`scripts/demo_three_peers.py` starts three separate node processes (Alice the
author, Ben the authorised reader with an *encrypted* library, Cara the
untrusted peer) and drives them through their local APIs. Each of its 15
steps asserts what it claims and the script exits non-zero if any fails:
private import → shared collection → invitation and fingerprint check →
authorised download → unauthorised peer refused (anonymous *and* paired) →
interrupted transfer resumes → corrupted chunk rejected → private annotation
→ public edition → verification by another peer → corrected edition → both
editions distinguishable → revocation → the downloaded copy remains.
A walk-through is in [docs/DEMO.md](docs/DEMO.md). Add `--keep --workdir demo`
to keep the three profiles and open them in the desktop app.

## What is in the repository

```
apps/desktop/       PySide6 interface (no business logic)
apps/local_api/     FastAPI loopback API + headless node (`aureom-node`)
apps/rendezvous/    optional rendezvous index + relay (`aureom-rendezvous`)
packages/           domain logic, independent of GUI and transport
  domain/           errors, limits, vocabulary, text hygiene
  storage/          SQLite (plain or encrypted snapshot), content-addressed store, vault, backup, credentials
  readers/          format detection, isolated extraction worker, EPUB reader, HTML/SVG sanitising
  catalogue/        works, editions, files, metadata layers, import pipeline
  search/           FTS5 full-text and metadata search
  annotations/      bookmarks, highlights, notes, progress, re-anchoring across editions
  identity/         device / account / publisher keys, pairing invitations, trusted peers, key rotation
  permissions/      collections, membership, authorisation, exposure preview
  protocol/         manifests, validated wire messages, framing
  transport/        TLS 1.3 pinning, client sessions, server handlers, relay client, LAN discovery, rendezvous client
  transfers/        chunked, resumable, verified downloads
  publishing/       publication workflow and public catalogue
  sync/             version-vector synchronisation and conflict rules
  node/             the `Commons` facade and the asyncio runtime
migrations/         SQL schema migrations
schemas/            JSON Schemas generated from the protocol models
fixtures/           synthetic, CC BY 4.0 demonstration content (regenerate with scripts/make_fixtures.py)
tests/              unit, integration (real TLS over loopback) and end-to-end tests
scripts/            demo, fixtures, schema export, screenshots, packaging
docs/               protocol, threat model, identity & recovery, sync, setup, capability report
```

The Python import name is `aureom` (`aureom.catalogue`, `aureom.apps.desktop`, …);
the mapping from the directories above is in `pyproject.toml`.

## Documentation

- [docs/CAPABILITIES.md](docs/CAPABILITIES.md) — **what works, what is limited, what is deferred** (read this first)
- [docs/PROTOCOL.md](docs/PROTOCOL.md) — peer protocol, manifests, relay and rendezvous; what each party can observe
- [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md) — assets, adversaries, mitigations and residual risks
- [docs/IDENTITY.md](docs/IDENTITY.md) — accounts, devices, publisher keys, pairing, rotation, recovery, device loss
- [docs/SYNC.md](docs/SYNC.md) — synchronisation, conflict rules, what offline peers can know about revocation
- [docs/SETUP.md](docs/SETUP.md) — installation, running, configuration, packaging
- [docs/DEMO.md](docs/DEMO.md) — the demonstration, step by step

## Things this software deliberately does not claim

- A content hash or a valid signature means *these are the bytes a particular
  key approved*. It does not mean a file is safe, lawful or accurate, and the
  interface never shows a bare “verified” label.
- A publisher signature is self-issued. It is not verification of anyone's
  legal identity, and publishing here does not establish copyright ownership.
- Revocation prevents future authorised access. It cannot erase copies that
  were already downloaded, and there is no reliable “view only” for files.
- Withdrawing an edition stops *your* devices distributing it. Copies
  elsewhere may persist.
- NAT traversal is not attempted. Peers need a reachable address or a shared relay.

## Licence

Apache-2.0 for the code. Fixtures are original synthetic content under
CC BY 4.0 (see `fixtures/LICENCE.txt`).
