#!/usr/bin/env python3
"""Generate the demonstration fixtures deterministically.

Everything produced here is original, synthetic content written for this
project and released under CC BY 4.0 (the EPUB, PDF, images and audio) or
marked as a private synthetic manuscript.  No third-party material is used.

    python scripts/make_fixtures.py [output-directory]
"""
from __future__ import annotations

import math
import random
import struct
import sys
import wave
import zipfile
import zlib
from pathlib import Path

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "fixtures"
MIDNIGHT, IVORY, COPPER = (22, 33, 62), (247, 241, 227), (176, 112, 71)

# ---------------------------------------------------------------- imagery
def png(width: int, height: int, pixel) -> bytes:
    rows = bytearray()
    for y in range(height):
        rows.append(0)
        for x in range(width):
            rows.extend(pixel(x, y))

    def chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b""))


def lantern_cover(w: int = 360, h: int = 540) -> bytes:
    cx, cy = w / 2, h * 0.40

    def pixel(x, y):
        d = math.hypot(x - cx, y - cy)
        if 14 <= x < w - 14 and (26 <= y < 30 or h - 30 <= y < h - 26):
            return COPPER
        if d < 46:
            return IVORY
        if d < 52:
            return COPPER
        if d < 150:                       # soft glow around the lantern
            t = (150 - d) / 98 * 0.35
            return tuple(int(m + (i - m) * t) for m, i in zip(MIDNIGHT, IVORY))
        if h * 0.72 <= y < h * 0.72 + 3 and 60 <= x < w - 60:
            return COPPER
        return MIDNIGHT

    return png(w, h, pixel)


def harbour_chart_png(w: int = 480, h: int = 320) -> bytes:
    def pixel(x, y):
        shore = h * 0.55 + 40 * math.sin(x / 55.0) + 12 * math.sin(x / 13.0)
        if y > shore:
            band = int((y - shore) / 14)
            return (228, 220, 200) if band % 2 == 0 else (236, 229, 211)
        if (x % 60 == 0 or y % 60 == 0):
            return (58, 74, 112)
        if abs(math.hypot(x - 330, y - 90) - 34) < 1.2:
            return COPPER
        return (33, 48, 84)

    return png(w, h, pixel)


HARBOUR_SVG = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 320" width="480" height="320">
  <title>Harbour chart (synthetic illustration)</title>
  <rect width="480" height="320" fill="#213054"/>
  <path d="M0 190 C60 150 120 230 180 190 S300 150 360 200 S440 170 480 190 L480 320 L0 320 Z" fill="#ece5d3"/>
  <g stroke="#3a4a70" stroke-width="1" fill="none">
    <path d="M60 0V320M120 0V320M180 0V320M240 0V320M300 0V320M360 0V320M420 0V320"/>
    <path d="M0 60H480M0 120H480M0 180H480"/>
  </g>
  <circle cx="330" cy="90" r="34" fill="none" stroke="#b07047" stroke-width="2"/>
  <path d="M330 56 L336 90 L330 124 L324 90 Z" fill="#b07047"/>
  <text x="24" y="296" font-family="serif" font-size="16" fill="#16213e">Tidewater harbour — soundings in fathoms (invented)</text>
</svg>
"""


def tide_bell_wav(path: Path, seconds: float = 6.0, rate: int = 22050) -> None:
    frames = bytearray()
    for n in range(int(seconds * rate)):
        t = n / rate
        strike = t % 2.0
        env = math.exp(-2.2 * strike)
        sample = env * (0.55 * math.sin(2 * math.pi * 523.25 * t) + 0.3 * math.sin(2 * math.pi * 1046.5 * t + 0.4)
                        + 0.15 * math.sin(2 * math.pi * 1568.0 * t))
        frames += struct.pack("<h", int(max(-1, min(1, sample)) * 26000))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(bytes(frames))


# ------------------------------------------------------------------- epub
CHAPTERS = [
    ("The Lantern Shelf", [
        "Every library begins as a single shelf that someone decided not to give away. Mine stood beside a window "
        "where a paraffin lantern hung, and for years I believed the lantern was there for the books. It was the "
        "other way about: the books were there so that the light had something to fall on.",
        "A private library is not a small public one. It has no duty to be complete, fair, or current. It keeps "
        "the margins you wrote in at nineteen and the pamphlet nobody else thought worth binding. Its catalogue is "
        "an autobiography with the verbs removed.",
        "When you lend from such a shelf you are not circulating stock. You are telling one person, deliberately, "
        "that this is a thing you think they should read. That deliberateness is the whole of the art.",
    ]),
    ("On Lending Deliberately", [
        "There are two ways to share a book. The first is to leave it on a wall in the street; the second is to "
        "put it into a particular pair of hands. Both are generous. Only the second is a conversation.",
        "The reader who receives a book from you by name receives also your judgement that it suits them. If you "
        "are wrong they will forgive you; if you are right they will remember. Neither happens with the wall.",
        "Keep, then, a list of who has what — not from suspicion, but because a loan you have forgotten is a gift "
        "you did not mean to give, and gifts are better meant.",
    ]),
    ("Editions Are Not Copies", [
        "Two copies of one printing are the same book twice. Two editions are two books that happen to share a "
        "name. The corrected edition removes an error and, with it, the evidence that the error was ever believed.",
        "A careful reader therefore cites the edition and not merely the title. A careful publisher numbers each "
        "edition, says plainly what changed, and never quietly replaces the old text beneath the reader's notes.",
        "If your marginal note points at a sentence, and the sentence has moved, an honest system does not pretend "
        "to know where the note now belongs. It asks you.",
    ]),
    ("What a Fingerprint Proves", [
        "A seal pressed into wax tells you that whoever held the ring made the mark. It does not tell you that the "
        "holder is the duke. For that you must have seen the ring on the duke's hand, or trust someone who has.",
        "So with keys. A signature shows that a particular key approved particular bytes. Whose key it is remains a "
        "question about people, to be settled between people — across a table, over a telephone, in a known voice.",
        "Compare the fingerprints aloud. It takes a minute and it is the only minute in the whole ceremony that "
        "involves you.",
    ]),
    ("The Honest Withdrawal", [
        "A publisher may stop selling a book. No publisher has ever been able to walk into every house and take it "
        "back. Anyone who promises otherwise is selling a lock for a door that has already been opened.",
        "To withdraw honestly is to say: I no longer distribute this; here is why; copies already abroad are beyond "
        "my reach. Readers respect the candour more than they would have believed the promise.",
    ]),
    ("Reading Without a Signal", [
        "The best reading happens where the network does not reach: on the ferry, in the hut, in the hour before "
        "the household wakes. A library that needs permission from a distant machine to open a book you already "
        "hold is not a library but a subscription.",
        "Keep the bytes close. Synchronise when it is convenient, not when it is demanded.",
    ]),
    ("A Note on This Edition", [
        "This small book was written as demonstration material for the Aureom Commons project. It is original, "
        "synthetic text and may be shared under the Creative Commons Attribution 4.0 International licence.",
    ]),
]


def xhtml(title: str, body: str) -> str:
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE html>\n'
            '<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="en">'
            f"<head><title>{title}</title></head><body>{body}</body></html>")


def build_epub(path: Path) -> None:
    title = "The Lantern Archive"
    manifest, spine, nav = [], [], []
    files: list[tuple[str, bytes]] = []
    for i, (heading, paragraphs) in enumerate(CHAPTERS, 1):
        name = f"chapter-{i}.xhtml"
        body = f'<h1 id="top">{heading}</h1>' + "".join(f"<p>{p}</p>" for p in paragraphs)
        if i == 3:
            body += '<p><img src="images/harbour.png" alt="A stylised harbour chart"/></p>'
        files.append((f"OEBPS/{name}", xhtml(heading, body).encode()))
        manifest.append(f'<item id="c{i}" href="{name}" media-type="application/xhtml+xml"/>')
        spine.append(f'<itemref idref="c{i}"/>')
        nav.append(f'<li><a href="{name}">{heading}</a></li>')
    nav_doc = xhtml("Contents", f'<nav epub:type="toc"><h1>Contents</h1><ol>{"".join(nav)}</ol></nav>')
    opf = f"""<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="pub-id">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="pub-id">urn:uuid:6f1f0c1e-5b0a-4d0e-9b53-aureomlantern1</dc:identifier>
    <dc:title>{title}</dc:title>
    <dc:creator>Marguerite Ashdown</dc:creator>
    <dc:contributor>Aureom Commons Project</dc:contributor>
    <dc:publisher>Lantern Shelf Editions</dc:publisher>
    <dc:language>en</dc:language>
    <dc:date>2026-03-14</dc:date>
    <dc:subject>libraries</dc:subject>
    <dc:subject>essays</dc:subject>
    <dc:rights>Creative Commons Attribution 4.0 International (CC BY 4.0)</dc:rights>
    <dc:description>Seven short essays on keeping, lending and publishing books. Synthetic demonstration text.</dc:description>
    <meta property="dcterms:modified">2026-03-14T00:00:00Z</meta>
    <meta property="schema:accessMode">textual</meta>
    <meta property="schema:accessibilityFeature">alternativeText</meta>
    <meta name="cover" content="cover-image"/>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="cover-image" href="images/cover.png" media-type="image/png" properties="cover-image"/>
    <item id="harbour" href="images/harbour.png" media-type="image/png"/>
    {"".join(manifest)}
  </manifest>
  <spine>{"".join(spine)}</spine>
</package>
"""
    container = ('<?xml version="1.0"?><container version="1.0" '
                 'xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles>'
                 '<rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>'
                 "</rootfiles></container>")
    with zipfile.ZipFile(path, "w") as z:
        def add(name: str, data: bytes, method=zipfile.ZIP_DEFLATED):
            info = zipfile.ZipInfo(name, date_time=(2026, 3, 14, 0, 0, 0))
            info.compress_type = method
            z.writestr(info, data)

        add("mimetype", b"application/epub+zip", zipfile.ZIP_STORED)
        add("META-INF/container.xml", container.encode())
        add("OEBPS/content.opf", opf.encode())
        add("OEBPS/nav.xhtml", nav_doc.encode())
        add("OEBPS/images/cover.png", lantern_cover())
        add("OEBPS/images/harbour.png", harbour_chart_png(360, 240))
        for name, data in files:
            add(name, data)


# ------------------------------------------------------------- manuscript
PLACES = ["the quay", "the customs shed", "Saltmarsh Lane", "the lower reading room", "the bindery", "Gull Stairs",
          "the chandler's loft", "the lighthouse landing", "the ferry office", "the archive cellar"]
THINGS = ["a ledger of soundings", "the harbourmaster's daybook", "a box of unsorted letters", "the second proof",
          "a water-stained atlas", "the tide tables for the spring", "an index nobody had finished",
          "a pamphlet on knots", "the subscription list", "a parcel of marbled endpapers"]
PEOPLE = ["Ines", "old Farrow", "the binder", "Mr Calloway", "Wren", "the pilot's daughter", "Dr Okafor", "Teodor"]
VERBS = ["carried", "found", "returned", "catalogued", "copied out", "mislaid", "wrapped", "promised me", "repaired"]
WEATHER = ["The fog stayed until noon.", "Rain came in sideways off the bar.", "It was the first clear morning in a week.",
           "The tide was late and so was everyone else.", "Wind from the east, and the shutters complaining.",
           "A still day, the water like poured lead."]
REFLECT = ["I begin to think a catalogue is only a polite way of remembering.",
           "Nobody warns you how much of a book is the paper it happens to be printed on.",
           "We agreed that the index should wait until the letters were in order, and then did not wait.",
           "If the edition is to be trusted it must say what it changed.",
           "I have copied the passage twice and still do not believe it.",
           "You would have laughed; I nearly did."]


def letter(rng: random.Random, number: int) -> str:
    lines = [f"## Letter {number}", "", f"*{rng.choice(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'])}, "
             f"from {rng.choice(PLACES)}*", ""]
    for _ in range(rng.randint(3, 5)):
        sentences = [rng.choice(WEATHER)]
        for _ in range(rng.randint(3, 6)):
            sentences.append(f"{rng.choice(PEOPLE).capitalize()} {rng.choice(VERBS)} {rng.choice(THINGS)} "
                             f"{rng.choice(['from', 'to', 'by way of', 'past'])} {rng.choice(PLACES)}.")
            if rng.random() < 0.45:
                sentences.append(rng.choice(REFLECT))
        lines += [" ".join(sentences), ""]
    lines += [f"— {rng.choice(['Yours in haste', 'Ever', 'With salt on the page', 'Yours'])}, A.", ""]
    return "\n".join(lines)


def manuscript(letters: int, *, front: str, seed: int = 7, corrections: bool = False, private_notes: bool = False) -> str:
    rng = random.Random(seed)
    parts = [front, "", "# Tidewater Letters", "",
             "An epistolary novella. This is synthetic demonstration text generated for the Aureom Commons project.", ""]
    for n in range(1, letters + 1):
        body = letter(rng, n)
        if n == 2 and not corrections:
            body = body.replace("## Letter 2", "## Letter 2\n\nThe harbourmaster recieved the atlas on the forth of March.")
        if n == 2 and corrections:
            body = body.replace("## Letter 2", "## Letter 2\n\nThe harbourmaster received the atlas on the fourth of March.")
        if private_notes and n % 9 == 0:
            body += "\n> [private note to self: check this date against the daybook before anyone sees it]\n"
        parts.append(body)
    return "\n".join(parts)


# -------------------------------------------------------------------- pdf
def build_pdf(path: Path) -> None:
    pages_text = [
        ["Field Notes on Tidal Catalogues", "", "R. Okafor - Working Paper 3 (synthetic)", "",
         "Abstract. We describe a small catalogue of invented tide observations and",
         "the conventions used to record corrections between editions of the tables.",
         "Keywords: tides, catalogues, editions, provenance"],
        ["1. Method", "", "Each sounding is recorded with the edition of the table it was read from.",
         "A corrected table never overwrites the earlier one; both remain citable.",
         "The quince-coloured ledger is the authority where they disagree."],
    ]
    objects: list[bytes] = []

    def add(body: bytes) -> int:
        objects.append(body)
        return len(objects)

    font = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >>")
    page_ids = []
    pages_obj_num = len(pages_text) * 2 + 2
    for lines in pages_text:
        stream = ["BT", "/F1 14 Tf", "72 720 Td", "18 TL"]
        for line in lines:
            safe = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            stream.append(f"({safe}) Tj T*")
        stream.append("ET")
        data = "\n".join(stream).encode()
        content = add(b"<< /Length %d >>\nstream\n" % len(data) + data + b"\nendstream")
        page_ids.append(add(b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 612 792] /Contents %d 0 R "
                            b"/Resources << /Font << /F1 %d 0 R >> >> >>" % (pages_obj_num, content, font)))
    kids = b" ".join(b"%d 0 R" % p for p in page_ids)
    pages = add(b"<< /Type /Pages /Kids [" + kids + b"] /Count %d >>" % len(page_ids))
    assert pages == pages_obj_num
    catalog = add(b"<< /Type /Catalog /Pages %d 0 R >>" % pages)
    info = add(b"<< /Title (Field Notes on Tidal Catalogues) /Author (R. Okafor) "
               b"/Subject (Synthetic working paper, CC BY 4.0) /Keywords (tides, catalogues, editions) >>")
    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = []
    for i, body in enumerate(objects, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + body + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1)
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    out += b"trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (
        len(objects) + 1, catalog, info, xref)
    path.write_bytes(bytes(out))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    build_epub(OUT / "the-lantern-archive.epub")
    private_front = ("---\ntitle: Tidewater Letters (working manuscript)\nauthor: Alice Maren\nlanguage: en\n"
                     "rights: Unpublished draft. All rights reserved by the author.\n---")
    public_front = ("---\ntitle: Tidewater Letters\nsubtitle: An epistolary novella\nauthor: Alice Maren\nlanguage: en\n"
                    "date: 2026-11-02\npublisher: Saltmarsh Press\nlicence: CC BY-NC-SA 4.0\n---")
    (OUT / "tidewater-letters-manuscript.md").write_text(
        manuscript(260, front=private_front, private_notes=True), encoding="utf-8")
    (OUT / "tidewater-letters-first-edition.md").write_text(manuscript(120, front=public_front), encoding="utf-8")
    (OUT / "tidewater-letters-corrected-edition.md").write_text(
        manuscript(120, front=public_front.replace("2026-11-02", "2026-11-20"), corrections=True), encoding="utf-8")
    build_pdf(OUT / "field-notes-on-tidal-catalogues.pdf")
    (OUT / "harbour-chart.svg").write_text(HARBOUR_SVG, encoding="utf-8")
    (OUT / "harbour-chart.png").write_bytes(harbour_chart_png())
    (OUT / "tidewater-cover.png").write_bytes(lantern_cover(300, 450))
    tide_bell_wav(OUT / "tide-bell.wav")
    (OUT / "tide-tables-supplement.txt").write_text(
        "Tide tables supplement (invented values)\n\n" + "\n".join(
            f"Day {d:02d}  high {4.1 + 0.6 * math.sin(d / 4.7):.2f} m  low {0.9 + 0.3 * math.cos(d / 5.1):.2f} m"
            for d in range(1, 31)) + "\n", encoding="utf-8")
    (OUT / "LICENCE.txt").write_text(
        "All files in this directory are original synthetic demonstration content created for the\n"
        "Aureom Commons project by scripts/make_fixtures.py.\n\n"
        "the-lantern-archive.epub, field-notes-on-tidal-catalogues.pdf, harbour-chart.*, tidewater-cover.png,\n"
        "tide-bell.wav and tide-tables-supplement.txt are released under CC BY 4.0\n"
        "(https://creativecommons.org/licenses/by/4.0/).\n\n"
        "tidewater-letters-*.md are fictional manuscripts by the fictional author 'Alice Maren', used to\n"
        "demonstrate private sharing and publishing; they may be reused under CC BY 4.0 as well.\n", encoding="utf-8")
    for p in sorted(OUT.iterdir()):
        print(f"{p.stat().st_size:>9}  {p.name}")


if __name__ == "__main__":
    main()
