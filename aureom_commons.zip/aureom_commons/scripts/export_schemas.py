#!/usr/bin/env python3
"""Write JSON Schemas for every protocol object into ``schemas/``.

The schemas are generated from the Pydantic models the application actually
validates with, so they cannot drift from the implementation.
"""
from __future__ import annotations

import json
from pathlib import Path

from aureom.domain.limits import Limits
from aureom.identity.keys import Endorsement, RotationStatement
from aureom.identity.pairing import PairingInvitation
from aureom.protocol import messages
from aureom.protocol.manifest import FileManifest, PublicationManifest

OUT = Path(__file__).resolve().parent.parent / "schemas"


def main() -> None:
    OUT.mkdir(exist_ok=True)
    models = {"file-manifest": FileManifest, "publication-manifest": PublicationManifest,
              "pairing-invitation": PairingInvitation, "device-endorsement": Endorsement,
              "key-rotation-statement": RotationStatement, "limits": Limits}
    for name, model in models.items():
        (OUT / f"{name}.schema.json").write_text(json.dumps(model.model_json_schema(), indent=2) + "\n")
    bundle = {"$comment": "Peer protocol v1 messages, keyed by their 't' discriminator.",
              "messages": {m.model_fields["t"].default: m.model_json_schema() for m in messages.ALL_MESSAGES}}
    (OUT / "peer-messages.schema.json").write_text(json.dumps(bundle, indent=2) + "\n")
    print(f"wrote {len(models) + 1} schema files to {OUT}")


if __name__ == "__main__":
    main()
