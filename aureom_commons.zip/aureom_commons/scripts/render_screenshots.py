#!/usr/bin/env python3
"""Render the desktop interface off-screen and save a screenshot of every page.

Builds two temporary demonstration profiles (Alice and Ben) from the
fixtures, pairs them, and drives the real widgets — so it doubles as a
smoke test of the interface.

    QT_QPA_PLATFORM=offscreen python scripts/render_screenshots.py [output-dir]
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("AUREOM_DISABLE_KEYRING", "1")

from PySide6.QtWidgets import QApplication  # noqa: E402

from aureom.apps.desktop.main_window import MainWindow  # noqa: E402
from aureom.node import Profile  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
FIX = ROOT / "fixtures"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "docs" / "screenshots"


def build(work: Path):
    alice = Profile.create(work / "alice", device_name="Alice's laptop", account_name="Alice Maren")
    ben = Profile.create(work / "ben", device_name="Ben's reader", account_name="Ben")
    for ctx in (alice, ben):
        ctx.settings.set_limits(chunk_size=16 * 1024)
        ctx.node.start_background()
    results = alice.catalogue.import_paths([FIX / n for n in (
        "the-lantern-archive.epub", "tidewater-letters-manuscript.md", "field-notes-on-tidal-catalogues.pdf",
        "harbour-chart.svg", "harbour-chart.png", "tide-bell.wav", "tidewater-letters-first-edition.md")])
    by_name = {r.name: r.edition_id for r in results}
    epub, manuscript, first = (by_name[n] for n in ("the-lantern-archive.epub", "tidewater-letters-manuscript.md",
                                                   "tidewater-letters-first-edition.md"))
    alice.catalogue.update_user_metadata(epub, {"tags": ["essays", "libraries"]})
    alice.catalogue.update_user_metadata(manuscript, {"tags": ["draft"], "title": "Tidewater Letters — working manuscript"})
    shelf = alice.collections.create("Reference shelf", "Charts and tables", kind="local")
    alice.collections.add_item(shelf["collection_id"], by_name["harbour-chart.png"])
    circle = alice.collections.create("Tidewater reading circle", "Drafts for early readers")
    for eid in (epub, manuscript):
        alice.collections.add_item(circle["collection_id"], eid)
    invitation = alice.node.create_invitation(purpose="collection", collection_id=circle["collection_id"], permissions="contributor")
    ben.node.call(ben.node.accept_invitation(invitation.to_text(), verified=True))
    alice.identity.mark_verified(ben.identity.device_id)
    ben_epub = next(v for v in ben.catalogue.list() if v["format"] == "epub")
    tid = ben.node.download_edition(ben_epub["edition_id"])
    while ben.transfers.get(tid)["state"] not in ("completed", "failed"):
        time.sleep(0.05)
    alice.annotations.create(epub, "highlight", {"section": 3, "quote": "Compare the fingerprints aloud.",
                                                 "label": "What a Fingerprint Proves"})
    alice.annotations.create(epub, "note", {"section": 3, "quote": "A signature shows that a particular key approved particular bytes.",
                                            "label": "What a Fingerprint Proves"}, "Use this in the preface.", "sage")
    alice.annotations.set_progress(epub, {"section": 3, "label": "What a Fingerprint Proves"}, 0.52)
    alice.annotations.set_progress(manuscript, {"section": 0, "label": "Tidewater Letters"}, 0.12)
    imprint = alice.identity.create_publisher("Saltmarsh Press")
    alice.publishing.create_draft(first, publisher_id=imprint["publisher_id"],
                                  package={"edition_label": "First edition", "licence": "CC BY-NC-SA 4.0",
                                           "description": "An epistolary novella. Synthetic demonstration text."})
    return alice, ben, epub


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="aureom-shots-"))
    app = QApplication.instance() or QApplication(sys.argv)
    alice, ben, epub = build(work)
    window = MainWindow(alice)
    window.resize(1440, 900)
    window.show()

    def shot(name: str) -> None:
        for _ in range(6):
            app.processEvents()
            time.sleep(0.03)
        window.grab().save(str(OUT / f"{name}.png"))
        print("saved", name)

    try:
        shot("01-home")
        window.go("Library")
        shot("02-library-covers")
        window.pages["Library"].toggle_view()
        shot("03-library-table")
        window.pages["Library"].toggle_view()
        window.open_reader(epub)
        reader = window.pages["Reading Room"]
        reader.goto(3)
        shot("04-reading-room-epub")
        for v in alice.catalogue.list():
            window.open_reader(v["edition_id"])           # every fixture format opens without error
            app.processEvents()
            if v["format"] == "pdf":
                shot("05-reading-room-pdf")
        window.go("Collections")
        window.pages["Collections"].list.setCurrentRow(1)      # the shared collection
        shot("06-collections")
        window.pages["Collections"].tabs.setCurrentIndex(1)
        shot("07-collection-members")
        window.go("Peers")
        shot("08-peers")
        window.go("Publish")
        shot("09-publish-draft")
        window.go("Transfers")
        shot("10-transfers")
        window.go("Activity")
        shot("11-activity")
        window.go("Settings")
        shot("12-settings")
        window.toggle_theme()
        window.go("Library")
        shot("13-library-dark")
        window.open_reader(epub)
        reader.goto(3)
        shot("14-reading-room-night")
        window.go("Home")
        shot("15-home-dark")
    finally:
        window.close()
        ben.close()
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    main()
