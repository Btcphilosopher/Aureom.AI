#!/usr/bin/env bash
# Build distributable artefacts.
#
#   scripts/package_desktop.sh wheel      -> dist/aureom_commons-*.whl (pure Python)
#   scripts/package_desktop.sh app        -> dist/aureom-commons/ (PyInstaller one-folder desktop bundle)
#
# The PyInstaller build must be run on each target OS (it does not cross-compile).
set -euo pipefail
cd "$(dirname "$0")/.."
case "${1:-wheel}" in
  wheel)
    python -m pip install --quiet build
    python -m build --wheel
    ;;
  app)
    python -m pip install --quiet pyinstaller ".[desktop]"
    cat > build_entry.py <<'PY'
from aureom.apps.desktop.__main__ import main
raise SystemExit(main())
PY
    pyinstaller --noconfirm --windowed --name aureom-commons \
      --collect-data aureom.migrations --collect-submodules aureom \
      --hidden-import aureom.readers.extract_worker build_entry.py
    rm -f build_entry.py
    echo "Built dist/aureom-commons/. The bundle re-enters itself for isolated metadata extraction."
    ;;
  *) echo "usage: $0 [wheel|app]"; exit 2 ;;
esac
