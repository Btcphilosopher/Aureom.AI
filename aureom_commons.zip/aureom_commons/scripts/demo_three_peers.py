#!/usr/bin/env python3
"""Reproducible three-peer demonstration of Aureom Commons.

Starts three isolated installations as separate processes — each with its own
profile folder, database, object store, keys, API port and peer port — and
drives them through their local APIs:

    Alice  author and collection owner
    Ben    authorised reader (his library is encrypted at rest)
    Cara   untrusted peer

Every numbered step asserts what it claims; the script exits non-zero if any
check fails.

    python scripts/demo_three_peers.py [--workdir DIR] [--keep] [--verbose]
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
FIXTURES = ROOT / "fixtures"
FAST_KDF = json.dumps({"name": "scrypt", "n": 2 ** 12, "r": 8, "p": 1})    # demo speed only; real default is 2**16


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class Peer:
    def __init__(self, name: str, workdir: Path, *, passphrase: str | None = None, verbose: bool = False):
        self.name = name
        self.dir = workdir / name.lower()
        self.api_port, self.listen_port = free_port(), free_port()
        env = dict(os.environ, AUREOM_DEMO_FAULTS="1", AUREOM_DISABLE_KEYRING="1")
        cmd = [sys.executable, "-m", "aureom.apps.local_api.node", "--profile-dir", str(self.dir),
               "--device-name", f"{name}'s device", "--account-name", name, "--api-port", str(self.api_port),
               "--listen-port", str(self.listen_port), "--limit", "chunk_size=16384"]
        if passphrase:
            env["AUREOM_DEMO_PASSPHRASE"] = passphrase
            cmd += ["--passphrase-env", "AUREOM_DEMO_PASSPHRASE", "--kdf", FAST_KDF]
        self.proc = subprocess.Popen(cmd, env=env, stdout=None if verbose else subprocess.DEVNULL,
                                     stderr=None if verbose else subprocess.DEVNULL)
        self.http: httpx.Client | None = None

    def wait_ready(self) -> None:
        token_file = self.dir / "api-token"
        for _ in range(200):
            if self.proc.poll() is not None:
                raise SystemExit(f"{self.name}'s node exited early")
            if token_file.exists():
                try:
                    self.http = httpx.Client(base_url=f"http://127.0.0.1:{self.api_port}", timeout=60.0,
                                             headers={"Authorization": f"Bearer {token_file.read_text().strip()}"})
                    self.http.get("/status").raise_for_status()
                    return
                except httpx.HTTPError:
                    pass
            time.sleep(0.1)
        raise SystemExit(f"{self.name}'s node did not start")

    def call(self, method: str, path: str, body: dict | None = None, *, expect: int | None = 200, **params):
        reply = self.http.request(method, path, json=body, params=params or None)
        if expect is not None and reply.status_code != expect:
            raise AssertionError(f"{self.name} {method} {path} -> {reply.status_code} {reply.text[:300]}")
        return reply.json() if expect is not None else reply

    def get(self, path: str, **params):
        return self.call("GET", path, **params)

    def post(self, path: str, body: dict | None = None, **kw):
        return self.call("POST", path, body or {}, **kw)

    def wait_transfer(self, transfer_id: str, until=("completed", "failed", "cancelled"), timeout: float = 90.0) -> dict:
        deadline = time.time() + timeout
        while time.time() < deadline:
            t = self.get(f"/transfers/{transfer_id}")
            if t["state"] in until:
                return t
            time.sleep(0.15)
        raise AssertionError(f"transfer did not reach {until}: {t}")

    def stop(self) -> None:
        if self.http:
            self.http.close()
        self.proc.terminate()
        try:
            self.proc.wait(10)
        except subprocess.TimeoutExpired:
            self.proc.kill()


STEP = 0


def step(title: str) -> None:
    global STEP
    STEP += 1
    print(f"\n{STEP:>2}. {title}")


def ok(message: str) -> None:
    print(f"    ✓ {message}")


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    ok(message)


def publish(peer: Peer, edition_id: str, publisher_id: str, package: dict) -> dict:
    """Draft → Preview → Rights Review → Published, as a person would."""
    draft = peer.post("/publications", {"edition_id": edition_id, "publisher_id": publisher_id, "package": package})
    return finish_publication(peer, draft["publication_id"])


def finish_publication(peer: Peer, pid: str) -> dict:
    preview = peer.post(f"/publications/{pid}/preview")
    public = preview["will_become_public"]
    print(f"      preview — will become public: “{public['metadata']['title']}”, "
          f"{len(public['files'])} file(s), licence {public['metadata']['licence']!r}")
    print(f"      preview — will NOT be published: {', '.join(preview['will_not_be_published'][:3])}, …")
    peer.post(f"/publications/{pid}/rights-review", {"rights_basis": "author", "licence_confirmed": True,
                                                     "no_private_material": True, "understands_permanence": True})
    refused = peer.call("POST", f"/publications/{pid}/publish", {"disclosure_digest": preview["digest"]}, expect=None)
    assert refused.status_code == 422, "publishing without explicit confirmation must be refused"
    return peer.post(f"/publications/{pid}/publish", {"disclosure_digest": preview["digest"], "confirm": True})


def run(workdir: Path, verbose: bool) -> None:
    alice = Peer("Alice", workdir, verbose=verbose)
    ben = Peer("Ben", workdir, passphrase="ben reads by lantern light", verbose=verbose)
    cara = Peer("Cara", workdir, verbose=verbose)
    peers = [alice, ben, cara]
    try:
        for p in peers:
            p.wait_ready()
        ids = {p.name: p.get("/status") for p in peers}
        print("Three isolated installations are running:")
        for p in peers:
            s = ids[p.name]
            print(f"  {p.name:<5} profile={p.dir.name}/  api=:{p.api_port}  peer=:{p.listen_port}  "
                  f"encrypted={s['encrypted']}  network={s['network']['label']}  "
                  f"device={s['identity']['device_id'][:8]}…")
        alice_addr = f"127.0.0.1:{alice.listen_port}"
        alice_dev = ids["Alice"]["identity"]["device_id"]

        step("Alice imports an openly licensed EPUB and a synthetic manuscript")
        results = alice.post("/library/import", {"paths": [str(FIXTURES / "the-lantern-archive.epub"),
                                                           str(FIXTURES / "tidewater-letters-manuscript.md")]})
        check([r["status"] for r in results] == ["imported", "imported"], "both files imported")
        epub = alice.get(f"/editions/{results[0]['edition_id']}")
        manuscript = alice.get(f"/editions/{results[1]['edition_id']}")
        again = alice.post("/library/import", {"paths": [str(FIXTURES / "the-lantern-archive.epub")]})
        check(again[0]["status"] == "duplicate", "re-importing identical bytes is detected by hash, not duplicated")

        step("Both works are private; importing announced nothing")
        check(epub["visibility"] == manuscript["visibility"] == "private", "both show the Private badge")
        seen = cara.post("/public/fetch", {"address": alice_addr})
        check(seen["publications"] == [], "Cara sees an empty public catalogue on Alice's device")
        probe = cara.post("/debug/probe", {"as": "anonymous", "address": alice_addr,
                                           "file_hash": manuscript["content_hash"]})
        check(all(str(v).startswith("refused") for v in probe.values()), "anonymous requests for the file are refused")

        step("Alice creates a shared reading collection")
        col = alice.post("/collections", {"name": "Tidewater reading circle", "description": "Drafts for early readers"})
        cid = col["collection_id"]
        for e in (epub, manuscript):
            alice.post(f"/collections/{cid}/items", {"edition_id": e["edition_id"]})
        invite = alice.post(f"/collections/{cid}/invite", {"permissions": "reader"})
        preview = invite["preview"]
        print(f"      invitation preview — titles: {[t['title'] for t in preview['titles']]}")
        print(f"      invitation preview — permissions: {preview['permissions']}; redistribution: {preview['redistribution']}")
        print(f"      invitation preview — not exposed: {preview['not_exposed'][0]}; {preview['not_exposed'][1]}; …")
        check(preview["redistribution"] is False, "onward redistribution is not granted by default")
        check(alice.get(f"/editions/{manuscript['edition_id']}")["visibility"] == "shared",
              "the works now show the Shared badge (an invitation is open)")

        step("Ben accepts the invitation and verifies Alice's fingerprint")
        shown = ben.post("/pairing/inspect", {"invitation": invite["text"]})
        print(f"      Ben's screen shows fingerprint  {shown['device_fingerprint']}")
        print(f"      Alice reads hers aloud          {ids['Alice']['identity']['device_fingerprint']}")
        check(shown["device_fingerprint"] == ids["Alice"]["identity"]["device_fingerprint"],
              "fingerprints match (compared out of band)")
        accepted = ben.post("/pairing/accept", {"invitation": invite["text"], "verified": True})
        check(accepted["collection_id"] == cid, "Ben joined the collection")
        replay = cara.call("POST", "/pairing/accept", {"invitation": invite["text"]}, expect=None)
        check(replay.status_code == 403 and replay.json()["error"] == "invitation_invalid",
              "the same invitation cannot be replayed by Cara")
        ben_items = {i["title"]: i for i in ben.get(f"/collections/{cid}")["items"]}
        check(all(i["availability"] == "peer" for i in ben_items.values()),
              "Ben sees both titles as “available from an authorised peer”")

        step("Ben downloads an authorised work directly")
        ben_epub = ben_items["The Lantern Archive"]
        t = ben.wait_transfer(ben.post(f"/editions/{ben_epub['edition_id']}/download")["transfer_id"])
        check(t["state"] == "completed", f"EPUB downloaded and verified ({t['size']} bytes, {t['chunks_total']} chunks)")
        check(ben.get("/status")["network"]["mode"] == "direct", "connection status: Direct (TLS 1.3, pinned keys)")
        check(ben.get(f"/editions/{ben_epub['edition_id']}/text")["hash_verified"], "stored copy matches its content hash")

        step("Cara cannot list or download the private collection")
        check(cara.post("/public/fetch", {"address": alice_addr})["publications"] == [],
              "public catalogue still empty: the collection is not discoverable")
        anon = cara.post("/debug/probe", {"as": "anonymous", "address": alice_addr, "collection_id": cid,
                                          "file_hash": manuscript["content_hash"]})
        print(f"      anonymous attempts: {anon}")
        check(all(str(v).startswith("refused") for v in anon.values()),
              "anonymous: collection, manifest and chunk requests all refused — even with the exact ids")
        pairing = alice.post("/pairing/invitations", {"purpose": "pair"})
        cara.post("/pairing/accept", {"invitation": pairing["text"]})
        paired = cara.post("/debug/probe", {"as": "paired", "device_id": alice_dev, "collection_id": cid,
                                            "file_hash": manuscript["content_hash"]})
        print(f"      paired-but-not-a-member attempts: {paired}")
        check(paired.pop("list_shared") == [], "paired, authenticated Cara is told she shares no collections")
        check(all(v == "refused:not_found_or_forbidden" for v in paired.values()),
              "paired Cara: every request refused, indistinguishable from “does not exist”")
        check(paired["get_manifest"] == paired["get_manifest_unknown_hash"],
              "a real hash and a made-up hash get the same answer (no existence oracle)")

        step("A transfer is interrupted and resumes")
        ben.call("PATCH", f"/peers/{alice_dev}", {"bandwidth_kbps": 640})        # slow enough to interrupt
        ben_ms = ben_items["Tidewater Letters (working manuscript)"]
        last = manuscript["size"] // 16384
        alice.post("/debug/corrupt-chunk", {"file_hash": manuscript["content_hash"], "index": last, "times": 1})
        tid = ben.post(f"/editions/{ben_ms['edition_id']}/download")["transfer_id"]
        while (t := ben.get(f"/transfers/{tid}"))["chunks_done"] < 8:
            time.sleep(0.1)
        alice.post("/network/stop")
        check(alice.get("/status")["network"]["mode"] == "offline", "Alice's device goes offline mid-transfer")
        t = ben.wait_transfer(tid, until=("retrying",))
        held = t["chunks_done"]
        check(0 < held < t["chunks_total"], f"Ben's transfer is waiting with {held}/{t['chunks_total']} verified chunks kept")
        alice.post("/network/start")
        ben.call("PATCH", f"/peers/{alice_dev}", {"bandwidth_kbps": 0})
        t = ben.wait_transfer(tid)
        check(t["state"] == "completed", "after Alice returns, the transfer resumes with backoff and completes")
        resumed = [a for a in ben.get("/activity", kind="transfer.")]
        check(t["chunks_total"] > held, "it resumed from the saved chunk map rather than starting again")

        step("A deliberately corrupted chunk was rejected")
        check(t["corrupt_chunks"] == 1, "exactly one chunk failed its hash check and was never written to disk")
        check(any(a["kind"] == "transfer.chunk_rejected" for a in resumed), "the rejection is recorded in Ben's activity")
        text = ben.get(f"/editions/{ben_ms['edition_id']}/text")
        check(text["hash_verified"] and "Tidewater Letters" in text["excerpt"],
              "the completed file matches the manifest hash and opens in the reading room")

        step("Ben adds a private annotation")
        note = ben.post(f"/editions/{ben_epub['edition_id']}/annotations", {
            "kind": "highlight", "body": "Read this aloud at the next circle.",
            "locator": {"section": 3, "quote": "Compare the fingerprints aloud.", "prefix": "people — across a table",
                        "suffix": "It takes a minute"}})
        check(note["private"] and note["shared_in"] == "", "the annotation is private to Ben")
        alice.post(f"/collections/{cid}/refresh", expect=None)
        check(alice.get(f"/collections/{cid}")["shared_annotations"] == [], "nothing about it reached Alice")

        step("Alice publishes a separate public edition")
        first = alice.post("/library/import", {"paths": [str(FIXTURES / "tidewater-letters-first-edition.md")]})[0]
        check(alice.get(f"/editions/{first['edition_id']}")["visibility"] == "private",
              "the public text is a separate edition, and starts private like any import")
        imprint = alice.post("/publishers", {"name": "Saltmarsh Press"})
        published = publish(alice, first["edition_id"], imprint["publisher_id"],
                            {"edition_label": "First edition", "licence": "CC BY-NC-SA 4.0",
                             "description": "An epistolary novella. Synthetic demonstration text."})
        check(published["state"] == "published" and published["manifest"]["signature"] is not None,
              "published with an explicit action; manifest signed by the imprint's self-issued key")
        check(alice.get(f"/editions/{first['edition_id']}")["visibility"] == "public", "that edition shows the Public badge")
        check(alice.get(f"/editions/{manuscript['edition_id']}")["visibility"] == "shared",
              "the working manuscript is still only Shared — publishing one edition exposed nothing else")
        frozen = alice.call("PATCH", f"/publications/{published['publication_id']}", {"package": {"title": "x"}}, expect=None)
        check(frozen.status_code == 409, "the published edition is immutable")

        step("Another peer verifies the manifest and downloads it")
        listing = cara.post("/public/fetch", {"address": alice_addr, "expected_device_id": alice_dev})
        check(len(listing["publications"]) == 1, "Cara finds exactly one public edition (and no private titles)")
        pub = listing["publications"][0]
        for line in pub["check"]["statements"]:
            print(f"      · {line}")
        check(pub["check"]["signature_valid"] and not pub["check"]["key_previously_pinned"],
              "signature valid for the stated key; Cara is told this is not identity verification")
        tids = cara.post("/public/download", {"publication_id": pub["entry"]["publication_id"]})["transfer_ids"]
        check(all(cara.wait_transfer(i)["state"] == "completed" for i in tids), "Cara downloaded and verified the edition")
        cara.post("/public/pin-publisher", {"public_key": published["manifest"]["publisher"]["key"], "name": "Saltmarsh Press"})

        step("Alice releases a corrected edition")
        draft = alice.post(f"/publications/{published['publication_id']}/revise", {
            "path": str(FIXTURES / "tidewater-letters-corrected-edition.md"), "label": "Corrected edition",
            "notes": "Letter 2: corrected two spelling errors (“recieved”, “forth”)."})
        second = finish_publication(alice, draft["publication_id"])
        check(second["manifest"]["previous_manifest_id"] == published["manifest_id"],
              "the new manifest names the edition it corrects")

        step("Both editions remain distinguishable")
        listing = cara.post("/public/fetch", {"address": alice_addr, "expected_device_id": alice_dev})
        entries = sorted((p["entry"] for p in listing["publications"]), key=lambda e: e["edition_number"])
        for e in entries:
            print(f"      edition {e['edition_number']}: “{e['edition_label']}”  manifest {e['manifest_id'][:12]}…  "
                  f"superseded_by={e['superseded_by'][:8] or '-'}")
        check(len(entries) == 2 and entries[0]["manifest_id"] != entries[1]["manifest_id"]
              and entries[0]["superseded_by"] == entries[1]["publication_id"],
              "two immutable editions, the first marked as superseded by the second")
        check(all(p["check"]["key_previously_pinned"] for p in listing["publications"]),
              "both are signed by the publisher key Cara pinned earlier")
        for i in cara.post("/public/download", {"publication_id": entries[1]["publication_id"]})["transfer_ids"]:
            cara.wait_transfer(i)
        mine = [e for e in cara.get("/library", space="public")]
        check(len(mine) == 2 and len({e["work_id"] for e in mine}) == 1 and len({e["content_hash"] for e in mine}) == 2,
              "Cara's library holds both editions of one work, with different content hashes")
        old, new = sorted(mine, key=lambda e: e["edition_number"])
        cara.post(f"/editions/{old['edition_id']}/annotations", {"kind": "highlight", "locator": {
            "quote": "The harbourmaster recieved the atlas on the forth of March."}})
        cara.post(f"/editions/{old['edition_id']}/annotations", {"kind": "note", "body": "Subtitle", "locator": {
            "quote": "An epistolary novella. This is synthetic demonstration text"}})
        report = cara.post("/annotations/migrate", {"from_edition": old["edition_id"], "to_edition": new["edition_id"]})
        check(report["ok"] == 1 and report["needs_review"] == 1,
              "annotations carried to the corrected edition: unchanged passage re-anchored, changed passage flagged for review")

        step("Alice revokes Ben's future collection access")
        extra = alice.post("/library/import", {"paths": [str(FIXTURES / "field-notes-on-tidal-catalogues.pdf")]})[0]
        alice.post(f"/collections/{cid}/items", {"edition_id": extra["edition_id"]})
        refreshed = ben.post(f"/collections/{cid}/refresh")
        pending = next(i for i in refreshed["items"] if i["format"] == "pdf")
        check(pending["availability"] == "peer", "before revocation Ben can see a newly added work he has not downloaded")
        ben_account = ids["Ben"]["identity"]["account_id"]
        revoked = alice.post(f"/collections/{cid}/revoke", {"account_id": ben_account})
        denied = ben.call("POST", f"/collections/{cid}/refresh", expect=None)
        check(denied.status_code == 403 and denied.json()["error"] == "access_revoked",
              "Ben's next request is refused by Alice's device (authoritative membership check)")
        late = ben.call("POST", f"/editions/{pending['edition_id']}/download", expect=None)
        check(late.status_code == 403, "the work he had not downloaded can no longer be fetched")
        check(ben.get(f"/editions/{pending['edition_id']}")["availability"] == "unavailable",
              "it now shows as “currently unavailable”")

        step("The interface explains that Ben's existing copy remains on his device")
        print(f"      Alice is told: “{revoked['notice']}”")
        print(f"      Ben is told:   “{denied.json()['message']}”")
        ben.post("/network/stop")
        offline = ben.get(f"/editions/{ben_ms['edition_id']}/text")
        check(ben.get("/status")["network"]["mode"] == "offline" and offline["hash_verified"]
              and "Tidewater" in offline["excerpt"], "with networking off, Ben still opens the copy he downloaded earlier")
        leaked = [f for f in ben.dir.rglob("*") if f.is_file() and f.stat().st_size < 50_000_000
                  and b"harbourmaster" in f.read_bytes()]
        check(not leaked, "Ben's encrypted library leaves no readable document text on disk (database, index, objects)")

        print(f"\nAll {STEP} demonstration steps passed.")
    finally:
        for p in peers:
            p.stop()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--workdir", help="folder for the three profiles (default: a temporary folder)")
    parser.add_argument("--keep", action="store_true", help="keep the profiles afterwards (open them in the desktop app)")
    parser.add_argument("--verbose", action="store_true", help="show the nodes' own output")
    args = parser.parse_args()
    if not (FIXTURES / "the-lantern-archive.epub").exists():
        subprocess.run([sys.executable, str(ROOT / "scripts" / "make_fixtures.py")], check=True)
    workdir = Path(args.workdir) if args.workdir else Path(tempfile.mkdtemp(prefix="aureom-demo-"))
    workdir.mkdir(parents=True, exist_ok=True)
    try:
        run(workdir, args.verbose)
    except AssertionError as exc:
        print(f"\n    ✗ FAILED: {exc}")
        sys.exit(1)
    finally:
        if args.keep or args.workdir:
            print(f"Profiles kept in {workdir}")
        else:
            shutil.rmtree(workdir, ignore_errors=True)


if __name__ == "__main__":
    main()
