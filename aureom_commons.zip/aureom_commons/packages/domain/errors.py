"""Error types shared by every layer.

Each error carries a stable ``code`` that is safe to send to a peer or show
in the interface.  Messages must never contain document contents, private
titles, invitation secrets or key material.
"""
from __future__ import annotations


class CommonsError(Exception):
    code = "error"

    def __init__(self, message: str = "", *, code: str | None = None):
        super().__init__(message or self.code)
        if code:
            self.code = code


class InvalidInput(CommonsError):
    code = "invalid_input"


class LimitExceeded(CommonsError):
    code = "limit_exceeded"


class NotFound(CommonsError):
    code = "not_found"


class PermissionDenied(CommonsError):
    """Deliberately uninformative: used both for 'forbidden' and for
    'does not exist' so that a peer cannot probe for private identifiers."""

    code = "not_found_or_forbidden"


class LibraryLocked(CommonsError):
    code = "library_locked"


class IntegrityFailure(CommonsError):
    code = "integrity_failure"


class Conflict(CommonsError):
    code = "conflict"


class StateError(CommonsError):
    code = "invalid_state"


class TransportError(CommonsError):
    code = "transport_error"


class ProtocolError(CommonsError):
    code = "protocol_error"


class UnsupportedFormat(CommonsError):
    code = "unsupported_format"


class FeatureUnavailable(CommonsError):
    code = "feature_unavailable"
