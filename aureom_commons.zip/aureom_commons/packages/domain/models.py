"""Core domain vocabulary, independent of storage, GUI and transport."""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .util import clean_text


class Visibility(str, Enum):
    PRIVATE = "private"
    SHARED = "shared"
    PUBLIC = "public"


class Availability(str, Enum):
    LOCAL = "local"            # bytes are on this device
    PEER = "peer"              # an authorised peer can supply them
    UNAVAILABLE = "unavailable"


class Permission(str, Enum):
    VIEW_METADATA = "view_metadata"
    DOWNLOAD = "download"
    ADD_WORKS = "add_works"
    EDIT_METADATA = "edit_metadata"
    MANAGE_MEMBERS = "manage_members"
    SHARE_ANNOTATIONS = "share_annotations"
    REDISTRIBUTE = "redistribute"   # never granted by default


PERMISSION_PRESETS: dict[str, tuple[Permission, ...]] = {
    "catalogue-only": (Permission.VIEW_METADATA,),
    "reader": (Permission.VIEW_METADATA, Permission.DOWNLOAD),
    "contributor": (Permission.VIEW_METADATA, Permission.DOWNLOAD, Permission.ADD_WORKS, Permission.SHARE_ANNOTATIONS),
    "editor": (Permission.VIEW_METADATA, Permission.DOWNLOAD, Permission.ADD_WORKS, Permission.SHARE_ANNOTATIONS,
               Permission.EDIT_METADATA),
    "manager": (Permission.VIEW_METADATA, Permission.DOWNLOAD, Permission.ADD_WORKS, Permission.SHARE_ANNOTATIONS,
                Permission.EDIT_METADATA, Permission.MANAGE_MEMBERS),
}


class PublicationState(str, Enum):
    DRAFT = "draft"
    PREVIEW = "preview"
    RIGHTS_REVIEW = "rights_review"
    PUBLISHED = "published"
    REVISED = "revised"        # superseded by a newer edition; still an immutable public edition
    WITHDRAWN = "withdrawn"


class TransferState(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    RETRYING = "retrying"
    PAUSED = "paused"
    VERIFYING = "verifying"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ConnectionMode(str, Enum):
    OFFLINE = "offline"
    DIRECT = "direct"
    RELAY = "relay"


FORMATS: dict[str, dict[str, Any]] = {
    # format id -> media type, kind, whether the built-in reading room can render it
    "epub": {"media_type": "application/epub+zip", "kind": "book", "readable": True},
    "pdf": {"media_type": "application/pdf", "kind": "document", "readable": True},
    "txt": {"media_type": "text/plain", "kind": "text", "readable": True},
    "md": {"media_type": "text/markdown", "kind": "text", "readable": True},
    "html": {"media_type": "text/html", "kind": "text", "readable": True},
    "png": {"media_type": "image/png", "kind": "image", "readable": True},
    "jpg": {"media_type": "image/jpeg", "kind": "image", "readable": True},
    "gif": {"media_type": "image/gif", "kind": "image", "readable": True},
    "webp": {"media_type": "image/webp", "kind": "image", "readable": True},
    "svg": {"media_type": "image/svg+xml", "kind": "image", "readable": True},
    "wav": {"media_type": "audio/wav", "kind": "audio", "readable": True},
    "mp3": {"media_type": "audio/mpeg", "kind": "audio", "readable": True},
    "flac": {"media_type": "audio/flac", "kind": "audio", "readable": True},
    "ogg": {"media_type": "audio/ogg", "kind": "audio", "readable": True},
    "m4a": {"media_type": "audio/mp4", "kind": "audio", "readable": True},
    "docx": {"media_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
             "kind": "document", "readable": False},
    "odt": {"media_type": "application/vnd.oasis.opendocument.text", "kind": "document", "readable": False},
    "zip": {"media_type": "application/zip", "kind": "archive", "readable": False},
    "bin": {"media_type": "application/octet-stream", "kind": "other", "readable": False},
}


def _clean_list(values: Any, max_items: int = 50, max_chars: int = 300) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str):
        values = [values]
    out: list[str] = []
    for item in list(values)[: max_items * 2]:
        text = clean_text(item, max_chars)
        if text and text not in out:
            out.append(text)
        if len(out) >= max_items:
            break
    return out


class Metadata(BaseModel):
    """Descriptive metadata for one edition.

    Every field is cleaned on construction, so the model can be built
    directly from untrusted input (an extracted document, a peer message).
    """

    model_config = ConfigDict(extra="ignore")

    title: str = ""
    subtitle: str = ""
    authors: list[str] = Field(default_factory=list)
    contributors: list[str] = Field(default_factory=list)
    publisher: str = ""
    language: str = ""
    publication_date: str = ""
    isbn: str = ""
    doi: str = ""
    tags: list[str] = Field(default_factory=list)
    rights: str = ""
    licence: str = ""
    description: str = ""
    accessibility: str = ""

    @field_validator("title", "subtitle", "publisher", "rights", "licence", mode="before")
    @classmethod
    def _line(cls, v: Any) -> str:
        return clean_text(v, 500)

    @field_validator("language", "publication_date", "isbn", "doi", mode="before")
    @classmethod
    def _short(cls, v: Any) -> str:
        return clean_text(v, 80)

    @field_validator("description", "accessibility", mode="before")
    @classmethod
    def _long(cls, v: Any) -> str:
        return clean_text(v, 4000, single_line=False)

    @field_validator("authors", "contributors", "tags", mode="before")
    @classmethod
    def _lists(cls, v: Any) -> list[str]:
        return _clean_list(v)

    def non_empty(self) -> dict[str, Any]:
        return {k: v for k, v in self.model_dump().items() if v not in ("", [], None)}


METADATA_FIELDS = tuple(Metadata.model_fields.keys())
