"""Small pure helpers: identifiers, time, canonical JSON, text hygiene."""
from __future__ import annotations

import base64
import datetime as _dt
import hashlib
import json
import re
import unicodedata
import uuid
from typing import Any

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f​-‏‪-‮⁦-⁩]")
_WS = re.compile(r"\s+")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_ID = re.compile(r"^[A-Za-z0-9_\-]{1,80}$")


def new_id() -> str:
    return uuid.uuid4().hex


def now() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)


def now_iso() -> str:
    return now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def parse_iso(value: str) -> _dt.datetime:
    value = value.replace("Z", "+00:00")
    parsed = _dt.datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return parsed


def canonical_json(obj: Any) -> bytes:
    """Deterministic JSON used for hashing and signing.

    Sorted keys, no insignificant whitespace, UTF-8, no NaN.  Protocol
    objects only contain strings, integers, booleans, nulls, lists and maps,
    so this is unambiguous.
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64d(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def b32id(data: bytes) -> str:
    """Lower-case unpadded base32 of a SHA-256 digest: 52 characters."""
    return base64.b32encode(hashlib.sha256(data).digest()).decode("ascii").rstrip("=").lower()


def is_sha256_hex(value: object) -> bool:
    return isinstance(value, str) and bool(_HEX64.match(value))


def is_safe_id(value: object) -> bool:
    return isinstance(value, str) and bool(_ID.match(value))


def clean_text(value: object, max_chars: int = 2000, *, single_line: bool = True) -> str:
    """Normalise untrusted text: strip control and bidi-override characters,
    collapse whitespace, and cap the length."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFC", str(value))
    text = _CONTROL.sub("", text)
    if single_line:
        text = _WS.sub(" ", text)
    else:
        text = re.sub(r"[ \t\r\f\v]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()
    if len(text) > max_chars:
        text = text[:max_chars].rstrip()
    return text


_RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


def safe_filename(name: object, default: str = "file") -> str:
    """Reduce an untrusted filename to a harmless single path component.

    Removes directory parts, control characters, leading dots and Windows
    reserved names; never returns an empty string or a traversal sequence.
    """
    text = clean_text(name, 4096)          # the extension is kept when the name is shortened below
    text = text.replace("\\", "/").split("/")[-1]
    text = re.sub(r'[<>:"|?*\x00-\x1f]', "_", text)
    text = text.strip(" .")
    if not text or text in {".", ".."}:
        text = default
    stem = text.split(".")[0].lower()
    if stem in _RESERVED:
        text = "_" + text
    if len(text) > 120:
        root, dot, ext = text.rpartition(".")
        if dot and len(ext) <= 10:
            text = root[: 120 - len(ext) - 1] + "." + ext
        else:
            text = text[:120]
    return text


def group4(text: str) -> str:
    return " ".join(text[i : i + 4] for i in range(0, len(text), 4))


def fingerprint_display(identifier: str) -> str:
    """Human-comparable form of a 52-character identifier."""
    return group4(identifier.upper())


def short_id(identifier: str, n: int = 8) -> str:
    return identifier[:n]


def redact(value: str | None, keep: int = 6) -> str:
    """Form of an identifier that is safe for logs."""
    if not value:
        return "-"
    return value[:keep] + "…"
