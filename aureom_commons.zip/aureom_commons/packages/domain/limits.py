"""Configurable resource limits.

Every value here bounds something an untrusted document, manifest or peer
could otherwise make arbitrarily large.  Limits are stored in the profile's
settings and may be tightened or relaxed by the user.
"""
from __future__ import annotations

from pydantic import BaseModel, Field

KIB = 1024
MIB = 1024 * KIB
GIB = 1024 * MIB


class Limits(BaseModel):
    # documents and storage
    max_document_bytes: int = Field(2 * GIB, ge=1)
    max_storage_bytes: int = Field(50 * GIB, ge=1)
    max_import_files_per_batch: int = Field(5000, ge=1)
    max_folder_depth: int = Field(16, ge=1)
    # archives (EPUB and other zip containers)
    max_archive_entries: int = Field(5000, ge=1)
    max_archive_entry_bytes: int = Field(256 * MIB, ge=1)
    max_archive_total_bytes: int = Field(1 * GIB, ge=1)
    max_decompression_ratio: int = Field(200, ge=1)
    # isolated extraction ("preview generation")
    preview_timeout_seconds: float = Field(20.0, gt=0)
    extract_memory_mb: int = Field(1024, ge=64)
    max_text_index_chars: int = Field(5_000_000, ge=0)
    max_metadata_field_chars: int = Field(2000, ge=16)
    max_cover_bytes: int = Field(4 * MIB, ge=0)
    # manifests and transfers
    max_manifest_bytes: int = Field(4 * MIB, ge=1024)
    max_chunks: int = Field(65536, ge=1)
    chunk_size: int = Field(256 * KIB, ge=16 * KIB, le=4 * MIB)
    max_concurrent_transfers: int = Field(3, ge=1)
    max_chunk_retries: int = Field(6, ge=0)
    max_corrupt_chunks_per_source: int = Field(3, ge=1)
    # peers
    max_connections: int = Field(64, ge=1)
    max_requests_per_second: int = Field(200, ge=1)
    search_requests_per_minute: int = Field(30, ge=1)
    catalogue_announcements_per_hour: int = Field(20, ge=1)
    max_remote_catalogue_entries: int = Field(2000, ge=1)
    max_annotation_chars: int = Field(20_000, ge=1)
    default_bandwidth_kbps: int = Field(0, ge=0, description="0 = unlimited")
    invitation_ttl_hours: int = Field(72, ge=1)


DEFAULT_LIMITS = Limits()
