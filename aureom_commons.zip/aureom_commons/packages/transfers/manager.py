"""Chunked, resumable, verified downloads.

Life of a transfer::

    queued → running ⇄ retrying → verifying → completed
                 ↘ paused      ↘ failed / cancelled

* every chunk is hashed and compared with the manifest **before** it is
  written to temporary storage; a mismatching chunk is rejected, counted and
  fetched again (from another source when one exists);
* progress survives pauses, lost connections and application restarts;
* the whole file is hashed again before it is promoted — atomically — into
  the content-addressed store, and only then does the catalogue show it as
  available;
* requests are *pull only*: nothing a peer does can start a transfer here.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import time
from collections import deque
from pathlib import Path
from typing import Any

from ..domain.errors import CommonsError, IntegrityFailure, LimitExceeded, NotFound, PermissionDenied, StateError
from ..domain.models import Metadata, TransferState
from ..domain.util import clean_text, new_id, now_iso, redact
from ..protocol import messages as m
from ..protocol.manifest import FileManifest, parse_file_manifest
from .partfile import PartFile

log = logging.getLogger("aureom.transfers")
ACTIVE = (TransferState.QUEUED.value, TransferState.RUNNING.value, TransferState.RETRYING.value,
          TransferState.VERIFYING.value)
MAX_ROUNDS = 8


class _Stop(Exception):
    def __init__(self, state: TransferState):
        self.state = state


class TransferManager:
    def __init__(self, ctx):
        self.ctx = ctx                              # the Commons service container
        self.db = ctx.db
        self._tasks: dict[str, asyncio.Task] = {}
        self._flags: dict[str, TransferState] = {}
        self._speed: dict[str, tuple[float, int, float]] = {}
        self._sem: asyncio.Semaphore | None = None
        self.loop: asyncio.AbstractEventLoop | None = None

    # ------------------------------------------------------------- queries
    def _dict(self, row) -> dict:
        d = dict(row)
        d.pop("bitmap", None)
        manifest = d.pop("manifest", None)
        d["scope"], d["sources"], d["target"] = json.loads(d["scope"]), json.loads(d["sources"]), json.loads(d["target"])
        d["chunks_total"] = len(json.loads(manifest)["chunks"]) if manifest else 0
        d["chunks_done"] = sum(row["bitmap"]) if row["bitmap"] else 0
        d["progress"] = (d["bytes_done"] / d["size"]) if d["size"] else (1.0 if d["state"] == "completed" else 0.0)
        d["speed_bps"] = round(self._speed.get(d["transfer_id"], (0, 0, 0.0))[2]) if d["state"] == "running" else 0
        return d

    def list(self, active_only: bool = False) -> list[dict]:
        rows = self.db.query("SELECT * FROM transfers ORDER BY created_at DESC LIMIT 500")
        return [self._dict(r) for r in rows if not active_only or r["state"] in ACTIVE + ("paused",)]

    def get(self, transfer_id: str) -> dict:
        row = self.db.one("SELECT * FROM transfers WHERE transfer_id=?", (transfer_id,))
        if row is None:
            raise NotFound("transfer")
        return self._dict(row)

    # ------------------------------------------------------------ commands
    def create(self, *, scope: dict, file_hash: str, sources: list[dict], target: dict, title: str = "",
               manifest: FileManifest | None = None, size: int = 0) -> str:
        """Queue a download.  Safe to call from any thread."""
        limits = self.ctx.settings.limits
        if manifest is not None:
            manifest.check_limits(limits)
            size = manifest.size
        existing = self.db.one("SELECT transfer_id, state FROM transfers WHERE file_hash=? AND scope=? AND state IN "
                               "('queued','running','retrying','paused','verifying')",
                               (file_hash, json.dumps(scope, sort_keys=True)))
        if existing:
            return existing["transfer_id"]
        if self.ctx.store.has(file_hash) and self.ctx.store.verify(file_hash):
            # identical bytes already in the library: nothing to fetch
            tid = self._insert(scope, file_hash, sources, target, title, manifest, size, state="completed")
            self.db.execute("UPDATE transfers SET bytes_done=size WHERE transfer_id=?", (tid,))
            self._place(self.db.one("SELECT * FROM transfers WHERE transfer_id=?", (tid,)), manifest)
            return tid
        tid = self._insert(scope, file_hash, sources, target, title, manifest, size, state="queued")
        self.kick()
        return tid

    def _insert(self, scope, file_hash, sources, target, title, manifest, size, state) -> str:
        tid, ts = new_id(), now_iso()
        self.db.execute(
            "INSERT INTO transfers (transfer_id, scope, file_hash, size, manifest, sources, target, state, title, "
            "created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (tid, json.dumps(scope, sort_keys=True), file_hash, size, manifest.model_dump_json() if manifest else None,
             json.dumps(sources), json.dumps(target), state, clean_text(title, 300), ts, ts))
        self.ctx.events.emit("transfers", transfer_id=tid)
        return tid

    def kick(self) -> None:
        if self.loop is not None and self.loop.is_running():
            self.loop.call_soon_threadsafe(self._schedule)

    def _schedule(self) -> None:
        if self._sem is None:
            self._sem = asyncio.Semaphore(self.ctx.settings.limits.max_concurrent_transfers)
        for row in self.db.query("SELECT transfer_id FROM transfers WHERE state IN ('queued','running','retrying','verifying') "
                                 "ORDER BY created_at"):
            tid = row["transfer_id"]
            if tid not in self._tasks or self._tasks[tid].done():
                self._flags.pop(tid, None)
                self._tasks[tid] = asyncio.create_task(self._guard(tid))

    async def start(self) -> None:
        self.loop = asyncio.get_running_loop()
        self._schedule()

    async def stop(self) -> None:
        for task in list(self._tasks.values()):
            task.cancel()
        await asyncio.gather(*self._tasks.values(), return_exceptions=True)
        self._tasks.clear()

    def pause(self, transfer_id: str) -> None:
        row = self.get(transfer_id)
        if row["state"] not in ACTIVE:
            raise StateError("Only active transfers can be paused.")
        self._flags[transfer_id] = TransferState.PAUSED
        if transfer_id not in self._tasks or self._tasks[transfer_id].done():
            self._set(transfer_id, TransferState.PAUSED)

    def resume(self, transfer_id: str) -> None:
        row = self.get(transfer_id)
        if row["state"] not in ("paused", "failed"):
            raise StateError("Only paused or failed transfers can be resumed.")
        self._flags.pop(transfer_id, None)
        self.db.execute("UPDATE transfers SET state='queued', error='', retries=0, updated_at=? WHERE transfer_id=?",
                        (now_iso(), transfer_id))
        self.ctx.events.emit("transfers", transfer_id=transfer_id)
        self.kick()

    def cancel(self, transfer_id: str) -> None:
        row = self.get(transfer_id)
        if row["state"] in ("completed", "cancelled"):
            return
        self._flags[transfer_id] = TransferState.CANCELLED
        if transfer_id not in self._tasks or self._tasks[transfer_id].done():
            self._finish_cancel(transfer_id)

    def _finish_cancel(self, transfer_id: str) -> None:
        self._part_path(transfer_id).unlink(missing_ok=True)
        self.db.execute("UPDATE transfers SET state='cancelled', bitmap=NULL, bytes_done=0, updated_at=? "
                        "WHERE transfer_id=?", (now_iso(), transfer_id))
        self.ctx.events.emit("transfers", transfer_id=transfer_id)

    # ------------------------------------------------------------ internals
    def _part_path(self, transfer_id: str) -> Path:
        return self.ctx.store.tmp / "transfers" / f"{transfer_id}.part"

    def _set(self, transfer_id: str, state: TransferState, error: str = "") -> None:
        self.db.execute("UPDATE transfers SET state=?, error=?, updated_at=? WHERE transfer_id=?",
                        (state.value, error[:300], now_iso(), transfer_id))
        self.ctx.events.emit("transfers", transfer_id=transfer_id)

    def _check_flag(self, transfer_id: str) -> None:
        flag = self._flags.get(transfer_id)
        if flag is not None:
            raise _Stop(flag)

    async def _guard(self, transfer_id: str) -> None:
        assert self._sem is not None
        try:
            async with self._sem:
                await self._run(transfer_id)
        except _Stop as stop:
            if stop.state is TransferState.CANCELLED:
                self._finish_cancel(transfer_id)
            else:
                self._set(transfer_id, stop.state)
        except asyncio.CancelledError:
            raise
        except PermissionDenied:
            self._set(transfer_id, TransferState.FAILED,
                      "The source refused the request. You are not authorised, or access has been revoked.")
        except CommonsError as exc:
            self._set(transfer_id, TransferState.FAILED, str(exc) or exc.code)
        except Exception:
            log.exception("transfer %s crashed", redact(transfer_id))
            self._set(transfer_id, TransferState.FAILED, "Unexpected error; see the application log.")

    async def _open(self, source: dict, scope: dict):
        if scope["kind"] == "public":
            return await self.ctx.node.connect_public(source.get("address", ""), source.get("device_id") or None)
        return await self.ctx.node.connect_peer(source["device_id"])

    async def _run(self, transfer_id: str) -> None:
        row = self.db.one("SELECT * FROM transfers WHERE transfer_id=?", (transfer_id,))
        scope, sources = json.loads(row["scope"]), json.loads(row["sources"])
        limits = self.ctx.settings.limits
        if not sources:
            raise StateError("No source is known for this file.")
        known_version = int(scope.get("known_version") or 0)
        wire_scope = m.Scope(kind=scope["kind"], id=scope.get("id") or "-")
        self._set(transfer_id, TransferState.RUNNING)

        # 1. manifest (validated and size-limited before anything else happens)
        if row["manifest"] is None:
            manifest = await self._fetch_manifest(transfer_id, sources, scope, wire_scope, row["file_hash"], known_version)
            self.db.execute("UPDATE transfers SET manifest=?, size=? WHERE transfer_id=?",
                            (manifest.model_dump_json(), manifest.size, transfer_id))
        else:
            manifest = parse_file_manifest(json.loads(row["manifest"]), limits, expected_hash=row["file_hash"])
        bitmap = bytearray(row["bitmap"]) if row["bitmap"] and len(row["bitmap"]) == len(manifest.chunks) \
            else bytearray(len(manifest.chunks))
        if not any(bitmap):
            self.ctx.store.check_quota(manifest.size)       # refuse before filling the disk
        part = PartFile(self._part_path(transfer_id), manifest, self.ctx.master_key, transfer_id)
        state = {"bytes": sum(c.size for c in manifest.chunks if bitmap[c.index]), "corrupt": row["corrupt_chunks"],
                 "last_save": time.monotonic(), "denied": 0, "dropped": 0}

        def save(force: bool = False) -> None:
            if force or time.monotonic() - state["last_save"] > 0.5:
                state["last_save"] = time.monotonic()
                self.db.execute("UPDATE transfers SET bitmap=?, bytes_done=?, corrupt_chunks=?, updated_at=? "
                                "WHERE transfer_id=?", (bytes(bitmap), state["bytes"], state["corrupt"], now_iso(), transfer_id))
                self.ctx.events.emit("transfers", transfer_id=transfer_id)

        # 2. chunks, with per-source workers and round-level backoff
        rounds = row["retries"]
        for verify_round in range(3):
            while not all(bitmap):
                pending = deque(i for i, done in enumerate(bitmap) if not done)
                state["denied"] = state["dropped"] = 0
                try:
                    results = await asyncio.gather(
                        *(self._worker(transfer_id, src, scope, wire_scope, manifest, part, bitmap, pending, state, save,
                                       known_version) for src in sources[:4]), return_exceptions=True)
                finally:
                    save(force=True)
                for result in results:
                    if isinstance(result, (_Stop, asyncio.CancelledError)):
                        raise result
                if all(bitmap):
                    break
                if state["denied"] >= len(sources[:4]):
                    raise PermissionDenied()
                if state["denied"] + state["dropped"] >= len(sources[:4]):
                    # waiting will not help: this is bad data, not a lost connection
                    raise IntegrityFailure("Every available source sent data that failed verification. Nothing was "
                                           "added to your library; the verified part of the download is kept.")
                rounds += 1
                if rounds > MAX_ROUNDS:
                    raise CommonsError("The source could not be reached after several attempts. The partial download "
                                       "is kept; resume when the peer is online.", code="unreachable")
                delay = min(30.0, 0.5 * 2 ** rounds) * (0.75 + random.random() / 2)
                self.db.execute("UPDATE transfers SET retries=? WHERE transfer_id=?", (rounds, transfer_id))
                self._set(transfer_id, TransferState.RETRYING, f"Connection lost; retrying in {delay:.0f}s "
                                                               f"(attempt {rounds} of {MAX_ROUNDS}).")
                waited = 0.0
                while waited < delay:
                    self._check_flag(transfer_id)
                    await asyncio.sleep(0.2)
                    waited += 0.2
                self._set(transfer_id, TransferState.RUNNING)

            # 3. whole-file verification, then atomic promotion
            self._check_flag(transfer_id)
            self._set(transfer_id, TransferState.VERIFYING)
            digest = hashlib.sha256()
            bad = []
            for chunk in manifest.chunks:
                try:
                    data = part.read_chunk(chunk.index)
                except IntegrityFailure:
                    data = b""
                digest.update(data)
                if hashlib.sha256(data).hexdigest() != chunk.sha256:
                    bad.append(chunk.index)
                if chunk.index % 16 == 0:
                    await asyncio.sleep(0)
            if not bad and digest.hexdigest() == manifest.file_hash:
                break
            if not bad:
                # every chunk matches the manifest yet the file hash does not: the manifest itself is wrong
                part.delete()
                self.db.execute("UPDATE transfers SET bitmap=NULL, bytes_done=0 WHERE transfer_id=?", (transfer_id,))
                raise IntegrityFailure("The completed file does not match its content hash. The download was discarded.")
            for index in bad:                        # damaged temporary data: fetch those chunks again
                bitmap[index] = 0
                state["bytes"] -= manifest.chunks[index].size
            self._set(transfer_id, TransferState.RUNNING)
        else:
            raise IntegrityFailure("The download could not be verified after repeated attempts.")

        await asyncio.to_thread(self.ctx.store.ingest_blocks, part.iter_chunks(), expected_hash=manifest.file_hash,
                                max_bytes=limits.max_document_bytes)
        part.delete()
        row = self.db.one("SELECT * FROM transfers WHERE transfer_id=?", (transfer_id,))
        await asyncio.to_thread(self._place, row, manifest)
        self.db.execute("UPDATE transfers SET state='completed', bytes_done=size, error='', bitmap=NULL, updated_at=? "
                        "WHERE transfer_id=?", (now_iso(), transfer_id))
        self.ctx.activity.log("transfer.completed", "A download finished and was verified against its manifest "
                              "(every chunk and the whole file).", transfer_id=transfer_id,
                              corrupt_chunks_rejected=state["corrupt"])
        self.ctx.events.emit("transfers", transfer_id=transfer_id)
        self.ctx.events.emit("library")

    async def _fetch_manifest(self, transfer_id, sources, scope, wire_scope, file_hash, known_version) -> FileManifest:
        limits = self.ctx.settings.limits
        last: Exception | None = None
        for attempt in range(MAX_ROUNDS):
            for source in sources:
                self._check_flag(transfer_id)
                try:
                    async with await self._open(source, scope) as session:
                        data = await session.request(m.GetManifest(scope=wire_scope, file_hash=file_hash,
                                                                   known_version=known_version))
                    return parse_file_manifest(data.get("manifest"), limits, expected_hash=file_hash)
                except (PermissionDenied, LimitExceeded, IntegrityFailure):
                    raise
                except CommonsError as exc:
                    last = exc
            delay = min(30.0, 0.5 * 2 ** attempt)
            self._set(transfer_id, TransferState.RETRYING, f"Could not reach the source; retrying in {delay:.0f}s.")
            waited = 0.0
            while waited < delay:
                self._check_flag(transfer_id)
                await asyncio.sleep(0.2)
                waited += 0.2
        raise last or CommonsError("no source reachable", code="unreachable")

    async def _worker(self, transfer_id, source, scope, wire_scope, manifest, part, bitmap, pending, state, save,
                      known_version) -> None:
        limits = self.ctx.settings.limits
        bucket = self.ctx.node.download_bucket(source.get("device_id") or source.get("address", ""))
        failures = corrupt = 0
        bad: dict[int, int] = {}          # how often each chunk arrived damaged from this source
        session = None
        try:
            while pending:
                self._check_flag(transfer_id)
                index = pending.popleft()
                chunk = manifest.chunks[index]
                try:
                    if session is None:
                        session = await self._open(source, scope)
                    data = await session.get_chunk(m.GetChunk(scope=wire_scope, file_hash=manifest.file_hash, index=index,
                                                              chunk_size=manifest.chunk_size, known_version=known_version))
                except PermissionDenied:
                    pending.appendleft(index)
                    state["denied"] += 1
                    return
                except CommonsError:
                    pending.appendleft(index)
                    if session is not None:
                        await session.close()
                        session = None
                    failures += 1
                    if failures > limits.max_chunk_retries or failures >= 3:
                        return                       # give the round-level backoff a turn
                    await asyncio.sleep(min(5.0, 0.2 * 2 ** failures) * (0.75 + random.random() / 2))
                    continue
                if len(data) != chunk.size or hashlib.sha256(data).hexdigest() != chunk.sha256:
                    # integrity failure: never written to disk
                    pending.append(index)
                    corrupt += 1
                    state["corrupt"] += 1
                    self.ctx.activity.log("transfer.chunk_rejected",
                                          f"Chunk {index} failed its hash check and was rejected.",
                                          transfer_id=transfer_id, peer=source.get("device_id", ""))
                    save(force=True)
                    bad[index] = bad.get(index, 0) + 1
                    # drop a source that keeps sending the same chunk damaged, or is damaged throughout
                    if bad[index] >= limits.max_corrupt_chunks_per_source or \
                            corrupt >= max(8, 4 * limits.max_corrupt_chunks_per_source):
                        self.ctx.activity.log("transfer.source_dropped",
                                              "A source was dropped after repeatedly sending corrupt data.",
                                              transfer_id=transfer_id, peer=source.get("device_id", ""))
                        state["dropped"] += 1
                        return
                    continue
                failures = 0
                await bucket.consume(len(data))
                if bitmap[index]:
                    continue
                part.write_chunk(index, data)
                bitmap[index] = 1
                state["bytes"] += chunk.size
                t0, b0, _ = self._speed.get(transfer_id, (time.monotonic(), state["bytes"] - chunk.size, 0.0))
                elapsed = time.monotonic() - t0
                if elapsed >= 1.0:
                    self._speed[transfer_id] = (time.monotonic(), state["bytes"], (state["bytes"] - b0) / elapsed)
                elif transfer_id not in self._speed:
                    self._speed[transfer_id] = (t0, b0, 0.0)
                save()
        finally:
            if session is not None:
                await session.close()

    # ----------------------------------------------------------- placement
    def _place(self, row, manifest: FileManifest | None) -> None:
        """Make a verified file visible in the catalogue."""
        target = json.loads(row["target"])
        cat, db = self.ctx.catalogue, self.db
        file_hash = row["file_hash"]
        kind = target.get("kind")
        edition_id = target.get("edition_id") or (manifest.edition_id if manifest else "")
        if kind == "public":
            pub = self.ctx.publishing.remote_manifest(target["publication_id"])[0]
            if not db.one("SELECT 1 FROM editions WHERE edition_id=?", (pub.edition_id,)):
                work = db.one("SELECT origin FROM works WHERE work_id=?", (pub.work_id,))
                meta = Metadata(title=pub.title, subtitle=pub.subtitle, description=pub.description,
                                authors=[c.name for c in pub.contributors if c.role == "author"],
                                contributors=[c.name for c in pub.contributors if c.role != "author"],
                                publisher=pub.publisher.name if pub.publisher else "", language=pub.language,
                                publication_date=pub.publication_date, isbn=pub.isbn, doi=pub.doi,
                                licence=pub.licence, rights=pub.rights_statement, accessibility=pub.accessibility)
                primary = pub.files[0]
                cat.register_edition(
                    content_hash=primary.file_hash, size=primary.size, filename=primary.filename, fmt=primary.format,
                    metadata=meta, metadata_source="remote", edition_id=pub.edition_id,
                    work_id=pub.work_id if (work is None or work["origin"] == "public") else None,
                    label=pub.edition_label, relation=pub.relation, revision_notes=pub.revision_notes,
                    previous_edition_id=pub.previous_edition_id if db.one(
                        "SELECT 1 FROM editions WHERE edition_id=? AND work_id=?", (pub.previous_edition_id, pub.work_id)) else None,
                    origin="public", origin_ref=pub.publication_id, available=False, edition_number=pub.edition_number,
                    import_source=f"public:{pub.publication_id}")
            edition_id = pub.edition_id
            if pub.cover and file_hash == pub.cover.file_hash:
                if not db.one("SELECT 1 FROM files WHERE edition_id=? AND role='cover'", (edition_id,)):
                    db.execute("INSERT INTO files (file_id, edition_id, role, content_hash, size, format, media_type, "
                               "filename, storage, imported_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                               (new_id(), edition_id, "cover", file_hash, pub.cover.size, pub.cover.format,
                                pub.cover.media_type, "cover", "managed", now_iso()))
                return
            for extra in pub.files[1:]:
                if extra.file_hash == file_hash and not db.one(
                        "SELECT 1 FROM files WHERE edition_id=? AND content_hash=?", (edition_id, file_hash)):
                    db.execute("INSERT INTO files (file_id, edition_id, role, content_hash, size, format, media_type, "
                               "filename, storage, import_source, imported_at, available) VALUES (?,?,?,?,?,?,?,?,?,?,?,1)",
                               (new_id(), edition_id, "supplementary", file_hash, extra.size, extra.format,
                                extra.media_type, extra.filename, "managed", f"public:{pub.publication_id}", now_iso()))
        db.execute("UPDATE files SET available=1, storage='managed' WHERE edition_id=? AND content_hash=?",
                   (edition_id, file_hash))
        if kind == "proposal":
            db.execute("UPDATE collection_items SET state='active' WHERE collection_id=? AND edition_id=?",
                       (target.get("collection_id"), edition_id))
        # index the text now that the bytes are here (isolated extraction, as for any import)
        try:
            file = cat.primary_file(edition_id)
            if file["content_hash"] == file_hash:
                from ..readers.extract import extract

                path = self.ctx.store.materialise(file_hash, file["filename"])
                extraction = extract(path, self.ctx.settings.limits)
                if extraction.cover and not db.one("SELECT 1 FROM files WHERE edition_id=? AND role='cover'", (edition_id,)):
                    cover_hash, cover_size = self.ctx.store.ingest_bytes(extraction.cover)
                    db.execute("INSERT INTO files (file_id, edition_id, role, content_hash, size, format, media_type, "
                               "filename, storage, imported_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                               (new_id(), edition_id, "cover", cover_hash, cover_size, "png", extraction.cover_media_type,
                                "cover", "managed", now_iso()))
                cat.reindex(edition_id, body=extraction.text)
                self.ctx.store.discard_view(path)
        except CommonsError:
            pass
        cat.on_change("edition", edition_id)


__all__ = ["TransferManager", "Any"]
