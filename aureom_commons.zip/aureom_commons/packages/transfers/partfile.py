"""Temporary storage for an in-progress download.

Chunks are written only *after* their hash has been verified.  In an
encrypted library the partial file is encrypted too (per-chunk AEAD), so a
half-finished download never leaves readable document text in the temporary
directory.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterator

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

from ..domain.errors import IntegrityFailure
from ..protocol.manifest import FileManifest
from ..storage.crypto import subkey

TAG = 16


class PartFile:
    def __init__(self, path: Path, manifest: FileManifest, key: bytes | None = None, transfer_id: str = ""):
        self.path, self.manifest = Path(path), manifest
        self._aead = ChaCha20Poly1305(subkey(key, "transfer-part", transfer_id.encode())) if key else None
        self._slot = manifest.chunk_size + (TAG if self._aead else 0)
        self._aad = manifest.file_hash.encode()
        if not self.path.exists():
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT, 0o600)
            os.close(fd)

    def write_chunk(self, index: int, data: bytes) -> None:
        blob = self._aead.encrypt(index.to_bytes(12, "big"), data, self._aad) if self._aead else data
        with open(self.path, "r+b") as fh:
            fh.seek(index * self._slot)
            fh.write(blob)

    def read_chunk(self, index: int) -> bytes:
        size = self.manifest.chunks[index].size
        with open(self.path, "rb") as fh:
            fh.seek(index * self._slot)
            blob = fh.read(size + (TAG if self._aead else 0))
        if not self._aead:
            return blob
        try:
            return self._aead.decrypt(index.to_bytes(12, "big"), blob, self._aad)
        except InvalidTag as exc:
            raise IntegrityFailure("temporary download data failed authentication") from exc

    def iter_chunks(self) -> Iterator[bytes]:
        for chunk in self.manifest.chunks:
            yield self.read_chunk(chunk.index)

    def flush(self) -> None:
        with open(self.path, "rb") as fh:
            os.fsync(fh.fileno())

    def delete(self) -> None:
        try:
            os.unlink(self.path)
        except OSError:
            pass
