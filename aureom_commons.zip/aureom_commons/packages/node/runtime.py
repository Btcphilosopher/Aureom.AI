"""Networking runtime: the asyncio side of an installation.

Staged design (see docs/PROTOCOL.md):

1. explicit peer addresses and direct, mutually-authenticated connections;
2. opt-in local-network discovery (address hints only);
3. optional rendezvous and relay for peers that cannot connect directly.

NAT traversal is *not* attempted.  A peer is reachable when it has an address
the other side can connect to, or when both use the same relay.
"""
from __future__ import annotations

import asyncio
import concurrent.futures
import json
import logging
import socket
import threading
from typing import Any, Coroutine

from ..domain.errors import (CommonsError, FeatureUnavailable, InvalidInput, NotFound, PermissionDenied, StateError,
                             TransportError)
from ..domain.models import ConnectionMode, Permission
from ..domain.util import b64d, b64e, clean_text, now_iso
from ..identity.pairing import CollectionOffer, PairingInvitation, parse_invitation
from ..permissions.collections import SHARED_METADATA_FIELDS
from ..protocol import messages as m
from ..transport import session as transport
from ..transport.discovery import LanDiscovery
from ..transport.ratelimit import BucketRegistry
from ..transport.relay import RelayAgent
from ..transport.server import PeerServer
from ..transport.tls import secure_transport_available

log = logging.getLogger("aureom.node")


class Node:
    def __init__(self, ctx):
        self.ctx = ctx
        self.loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self.server: PeerServer | None = None
        self.relay_agent: RelayAgent | None = None
        self.discovery: LanDiscovery | None = None
        self._upload, self._download = BucketRegistry(), BucketRegistry()
        self._last_path = ""
        self._periodic: asyncio.Task | None = None
        self.started = False
        from ..transport.rendezvous import RendezvousClient

        self.rendezvous = RendezvousClient(ctx)
        ctx.identity.on_trust_change = self._trust_changed

    # =========================================================== lifecycle
    def start_background(self) -> None:
        """Run the node on its own thread (used by the desktop application)."""
        if self._thread is not None:
            return
        ready = threading.Event()

        def run() -> None:
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.loop.create_task(self._boot(ready))
            self.loop.run_forever()
            self.loop.close()

        self._thread = threading.Thread(target=run, name="aureom-node", daemon=True)
        self._thread.start()
        ready.wait(15)

    async def _boot(self, ready: threading.Event) -> None:
        try:
            await self.start()
        except Exception:
            log.exception("node failed to start")
        finally:
            ready.set()

    async def start(self) -> None:
        self.loop = asyncio.get_running_loop()
        self.started = True
        self.ctx.identity.expire_rotation_if_due()       # retire an old device key after the grace period
        await self.ctx.transfers.start()
        if self.ctx.settings.get("network_enabled"):
            try:
                await self.start_network()
            except CommonsError as exc:
                self.ctx.activity.log("network.unavailable", str(exc))
        interval = float(self.ctx.settings.get("auto_refresh_seconds") or 0)
        if interval > 0:
            self._periodic = asyncio.create_task(self._periodic_refresh(interval))

    async def stop(self) -> None:
        if self._periodic:
            self._periodic.cancel()
        await self.ctx.transfers.stop()
        await self.stop_network()
        self.started = False

    def shutdown(self) -> None:
        if self.loop is None or not self.started:
            return
        if self._thread is not None:
            try:
                asyncio.run_coroutine_threadsafe(self.stop(), self.loop).result(10)
            except Exception:
                pass
            self.loop.call_soon_threadsafe(self.loop.stop)
            self._thread.join(5)
            self._thread = None

    def submit(self, coro: Coroutine) -> concurrent.futures.Future:
        if self.loop is None:
            coro.close()
            raise StateError("The network runtime is not running.")
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def call(self, coro: Coroutine, timeout: float = 60.0) -> Any:
        """Run a coroutine on the node loop from another thread and wait."""
        return self.submit(coro).result(timeout)

    # ============================================================= network
    async def start_network(self) -> None:
        ok, why = secure_transport_available()
        if not ok:
            raise FeatureUnavailable(why)
        if self.server is not None and self.server.listening:
            return
        settings = self.ctx.settings
        self.server = self.server or PeerServer(self.ctx)
        self.server.refresh_trust()
        port = await self.server.start(settings.get("listen_host"), int(settings.get("listen_port") or 0))
        if not settings.get("listen_port"):
            settings.set("listen_port", port)          # keep the same port across restarts
        relay = settings.get("relay_address")
        if relay:
            self.relay_agent = RelayAgent(relay, self.ctx.identity.device, self.server.relay_port,
                                          lambda _connected: self.ctx.events.emit("network"))
            self.relay_agent.start()
        if settings.get("lan_discovery"):
            try:
                self.discovery = LanDiscovery(
                    self.ctx.identity.device_id, port,
                    self.ctx.identity.device_name if settings.get("lan_announce_name") else "",
                    group=settings.get("_lan_group") or "239.255.42.99", port=int(settings.get("_lan_port") or 47474),
                    interval=float(settings.get("_lan_interval") or 10.0),
                    on_update=lambda: self.ctx.events.emit("network"))
                await self.discovery.start()
            except OSError:
                self.discovery = None
                self.ctx.activity.log("network.discovery_unavailable",
                                      "Local-network discovery could not start on this network.")
        if self.rendezvous.url:
            async def register() -> None:
                try:
                    await asyncio.to_thread(self.rendezvous.register)
                except CommonsError as exc:
                    log.info("rendezvous registration failed: %s", exc.code)

            asyncio.create_task(register())
        self.ctx.events.emit("network")

    async def stop_network(self) -> None:
        if self.discovery:
            await self.discovery.stop()
            self.discovery = None
        if self.relay_agent:
            await self.relay_agent.stop()
            self.relay_agent = None
        if self.server:
            await self.server.stop()
        self.ctx.events.emit("network")

    def _trust_changed(self) -> None:
        if self.server is not None:
            self.server.refresh_trust()

    def advertised_addresses(self) -> list[str]:
        configured = [a for a in self.ctx.settings.get("advertise_addresses") or [] if a]
        if configured:
            return configured
        if not self.server or not self.server.listening:
            return []
        host = self.ctx.settings.get("listen_host")
        if host in ("0.0.0.0", "::", ""):
            host = "127.0.0.1"
            try:
                probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                probe.connect(("192.0.2.1", 9))       # no packet is sent; this only asks the OS for a route
                host = probe.getsockname()[0]
                probe.close()
            except OSError:
                pass
        return [f"{host}:{self.server.port}"]

    def status(self) -> dict:
        ok, why = secure_transport_available()
        listening = bool(self.server and self.server.listening)
        relay_cfg = self.ctx.settings.get("relay_address") or ""
        relay_up = bool(self.relay_agent and self.relay_agent.connected)
        inbound = dict(self.server.active_peers) if self.server else {}
        if not listening:
            mode = ConnectionMode.OFFLINE
        elif "relay" in inbound.values() or self._last_path == "relay" or (relay_up and not self.advertised_addresses()):
            mode = ConnectionMode.RELAY
        else:
            mode = ConnectionMode.DIRECT
        addresses = self.advertised_addresses()
        if not ok:
            label, detail = "Offline", why
        elif mode is ConnectionMode.OFFLINE:
            label = "Offline"
            detail = ("Networking is switched off. Your library, reading room and search work as usual; sharing and "
                      "downloads resume when you go online.")
        elif mode is ConnectionMode.RELAY:
            label = "Relay"
            detail = (f"Using relay {relay_cfg}. Content stays end-to-end encrypted; the relay can see which devices "
                      "connect, when, and how much data moves.")
        else:
            label = "Direct"
            detail = f"Listening on {', '.join(addresses) or 'this device'}; connections go straight to peers over TLS 1.3."
            if relay_up:
                detail += f" Also registered with relay {relay_cfg} for peers that cannot connect directly."
        return {"mode": mode.value, "label": label, "detail": detail, "enabled": bool(self.ctx.settings.get("network_enabled")),
                "listening": listening, "addresses": addresses, "port": self.server.port if listening else 0,
                "relay_configured": relay_cfg, "relay_connected": relay_up, "connected_peers": len(inbound),
                "lan_discovery": self.discovery is not None, "secure_transport": ok, "secure_transport_note": why}

    def discovered(self) -> list[dict]:
        if not self.discovery:
            return []
        known = {p["device_id"]: p for p in self.ctx.identity.peers()}
        out = []
        for d in self.discovery.devices():
            peer = known.get(d["device_id"])
            out.append(d | {"paired": bool(peer and peer["state"] == "trusted"),
                            "note": "Seen on the local network. Unverified: anyone on the network can send this beacon."})
        return out

    def upload_bucket(self, key: str):
        return self._upload.get(key, self._rate_for(key))

    def download_bucket(self, key: str):
        return self._download.get(key, self._rate_for(key))

    def _rate_for(self, device_id: str) -> float:
        row = self.ctx.identity.peer_row(device_id) if device_id else None
        kbps = (row["bandwidth_kbps"] if row and row["bandwidth_kbps"] else self.ctx.settings.limits.default_bandwidth_kbps)
        return kbps * 1000 / 8

    # ========================================================== connecting
    async def connect_peer(self, device_id: str) -> transport.PeerSession:
        """Open an authenticated session with a trusted peer: direct first,
        then through a relay if one is configured for it."""
        ident_svc = self.ctx.identity
        row = ident_svc.peer_row(device_id)
        if row is None or row["state"] != "trusted":
            raise PermissionDenied("That device is not in your trusted list.", code="not_trusted")
        if not self.ctx.settings.get("network_enabled"):
            raise TransportError("Networking is switched off.", code="offline")
        identity = ident_svc.identity_for_peer(device_id)
        kwargs = dict(expected_device_id=device_id, identity=identity, device_name=ident_svc.device_name,
                      endorsement=ident_svc.endorsement(identity), max_json=self.ctx.settings.limits.max_manifest_bytes + 65536)
        addresses = list(json.loads(row["addresses"]))
        if self.discovery and device_id in self.discovery.seen:
            addresses.insert(0, self.discovery.seen[device_id]["address"])     # a hint; still verified by pin
        last: Exception = TransportError("No address is known for that device.", code="unreachable")
        session = None
        for address in addresses:
            try:
                session = await transport.connect(address, **kwargs)
                break
            except TransportError as exc:
                last = exc
                if exc.code in ("fingerprint_mismatch", "not_trusted_by_peer"):
                    raise
        if session is None and self.rendezvous.url:
            # opt-in: ask the rendezvous service where this contact is now (the answer is only a hint)
            try:
                for address in await asyncio.to_thread(self.rendezvous.lookup, device_id):
                    if address in addresses:
                        continue
                    try:
                        session = await transport.connect(address, **kwargs)
                        ident_svc.update_peer(device_id, addresses=[address] + addresses)
                        break
                    except TransportError as exc:
                        last = exc
            except CommonsError:
                pass
        if session is None:
            relay = row["relay"] or self.ctx.settings.get("relay_address")
            if not relay:
                raise last
            session = await transport.connect_via_relay(relay, **kwargs)
        self._last_path = session.path
        ident_svc.touch_peer(device_id, session.path)
        try:
            if session.ack.rotation is not None and session.ack.rotation.old_device_id == device_id:
                ident_svc.apply_peer_rotation(session.ack.rotation)        # the peer moved to a new key
            if identity is not ident_svc.device:
                statement = ident_svc.pending_rotation()
                if statement is not None:
                    await session.request(m.KeyRotation(statement=statement))
                    ident_svc.peer_acknowledged_rotation(device_id)
        except CommonsError:
            log.info("key rotation exchange with %s did not complete", device_id[:6])
        return session

    async def connect_public(self, address: str, expected_device_id: str | None = None) -> transport.PeerSession:
        """Anonymous session for public catalogues: we present no identity."""
        if not self.ctx.settings.get("network_enabled"):
            raise TransportError("Networking is switched off.", code="offline")
        return await transport.connect(address, expected_device_id=expected_device_id, identity=None,
                                       max_json=self.ctx.settings.limits.max_manifest_bytes + 65536)

    # ============================================================== pairing
    def create_invitation(self, *, purpose: str = "pair", collection_id: str | None = None, permissions=None,
                          ttl_hours: float | None = None) -> PairingInvitation:
        addresses = self.advertised_addresses()
        relay = self.ctx.settings.get("relay_address") or ""
        if not addresses and not relay:
            raise StateError("Go online first: an invitation must contain an address where this device can be reached.")
        offer, perms = None, None
        if purpose == "collection":
            from ..permissions.collections import normalise_permissions

            col = self.ctx.collections.get(collection_id or "")
            if not col["is_owner"] or col["kind"] != "shared":
                raise StateError("Only the owner of a shared collection can invite people to it.")
            perms = normalise_permissions(permissions or "reader")
            offer = CollectionOffer(collection_id=col["collection_id"], name=col["name"], permissions=perms,
                                    item_count=col["item_count"])
        elif purpose not in ("pair", "link-device"):
            raise InvalidInput("unknown invitation purpose")
        return self.ctx.identity.create_invitation(addresses=addresses, relay=relay, purpose=purpose,
                                                   ttl_hours=ttl_hours, collection=offer, permissions=perms)

    def inspect_invitation(self, text: str | bytes) -> dict:
        """What an invitation says, for the user to check *before* accepting."""
        from ..domain.util import fingerprint_display

        inv = parse_invitation(text)
        return {
            "purpose": inv.purpose, "device_name": inv.display_name, "device_id": inv.device_id,
            "device_fingerprint": fingerprint_display(inv.device_id),
            "account_fingerprint": fingerprint_display(inv.account_id), "addresses": inv.addresses, "relay": inv.relay,
            "expires_at": inv.expires_at, "collection": inv.collection.model_dump() if inv.collection else None,
            "already_trusted": bool((row := self.ctx.identity.peer_row(inv.device_id)) and row["state"] == "trusted"),
            "notices": [
                "The device name is chosen by its owner and proves nothing. Compare the fingerprint above with the "
                "sender over a channel you trust (in person, by phone) before relying on this pairing.",
                "Accepting sends this device's name, fingerprint and reachable address to the inviter.",
            ] + (["Linking makes this device part of the inviter's account: it will receive the account key and "
                  "synchronise their catalogue, annotations and collections."] if inv.purpose == "link-device" else []),
        }

    async def accept_invitation(self, text: str | bytes, *, verified: bool = False) -> dict:
        ident = self.ctx.identity
        inv = parse_invitation(text)
        cert = b64d(inv.device_cert)
        existed = ident.peer_row(inv.device_id)
        ident.upsert_peer(cert_der=cert, device_name=inv.device_name, endorsement=inv.endorsement, state="trusted",
                          addresses=inv.addresses, relay=inv.relay, paired_via=inv.invitation_id,
                          is_own_device=inv.purpose == "link-device")
        request = m.PairRequest(token=inv.token, device_cert=b64e(ident.device.cert_der), device_name=ident.device_name,
                                endorsement=ident.endorsement(), addresses=self.advertised_addresses(),
                                relay=self.ctx.settings.get("relay_address") or "")
        try:
            session = None
            last: Exception = TransportError("The invitation contains no reachable address.", code="unreachable")
            for address in inv.addresses:
                try:
                    session = await transport.connect(address, expected_device_id=inv.device_id, identity=None)
                    break
                except TransportError as exc:
                    last = exc
            if session is None and inv.relay:
                session = await transport.connect_via_relay(inv.relay, expected_device_id=inv.device_id,
                                                            identity=ident.device, anonymous=True)
            if session is None:
                raise last
            async with session:
                await session.request(request)
            # second step over mutual TLS proves we hold the key we just registered
            async with await self.connect_peer(inv.device_id) as session:
                data = await session.request(m.PairConfirm(token=inv.token))
        except BaseException:
            if existed is None:
                self.ctx.db.execute("DELETE FROM peers WHERE device_id=?", (inv.device_id,))
                ident.on_trust_change()
            raise
        result: dict[str, Any] = {"device_id": inv.device_id, "device_name": inv.display_name, "purpose": inv.purpose}
        if verified:
            ident.mark_verified(inv.device_id)
        if inv.purpose == "link-device" and data.get("account_secret"):
            ident.adopt_account(b64d(data["account_secret"]))
            if data.get("account_name"):
                self.ctx.settings.set("account_name", clean_text(data["account_name"], 80))
            self.ctx.db.execute("UPDATE peers SET is_own_device=1 WHERE device_id=?", (inv.device_id,))
            result["linked"] = True
        if inv.purpose == "collection" and inv.collection and data.get("collection_id") == inv.collection.collection_id:
            self.ctx.collections.store_offer(inv.device_id, {
                "collection_id": inv.collection.collection_id, "name": inv.collection.name,
                "owner_account": inv.account_id, "owner_name": inv.display_name,
                "permissions": inv.collection.permissions, "status": "active"})
            try:
                await self.refresh_collection(inv.collection.collection_id)
            except CommonsError:
                pass
            result["collection_id"] = inv.collection.collection_id
        self.ctx.activity.log("peer.paired", "Paired with a device using an invitation." +
                              ("" if verified else " Its fingerprint has not been verified yet."), peer=inv.device_id)
        self.ctx.events.emit("peers")
        self.ctx.events.emit("collections")
        return result

    async def announce_rotation(self) -> dict:
        """Tell every trusted peer about this device's new key."""
        ident = self.ctx.identity
        told, failed = 0, 0
        if ident.previous_device is None:
            return {"told": 0, "pending": 0}
        for row in self.ctx.db.query("SELECT device_id FROM peers WHERE state='trusted' AND knows_our_key=?",
                                     (ident.previous_device.device_id,)):
            try:
                async with await self.connect_peer(row["device_id"]):
                    told += 1
            except CommonsError:
                failed += 1
        if self.server:
            self.server.refresh_trust()
        return {"told": told, "pending": failed}

    # ========================================================== collections
    async def refresh_shared(self) -> list[dict]:
        """Ask each trusted peer which of their collections we have been
        invited to or belong to."""
        found = []
        for peer in self.ctx.identity.peers():
            if peer["state"] != "trusted" or peer["is_own_device"]:
                continue
            try:
                async with await self.connect_peer(peer["device_id"]) as session:
                    data = await session.request(m.ListShared())
            except CommonsError:
                continue
            listed = set()
            for offer in (data.get("collections") or [])[:200]:
                if not isinstance(offer, dict):
                    continue
                try:
                    self.ctx.collections.store_offer(peer["device_id"], offer)
                    listed.add(offer["collection_id"])
                    found.append(offer | {"owner_device": peer["device_id"]})
                except (CommonsError, KeyError):
                    continue
            # collections this peer used to share with us but no longer lists: access has ended
            for row in self.ctx.db.query("SELECT collection_id FROM collections WHERE is_owner=0 AND owner_device=? "
                                         "AND deleted=0 AND access_state IN ('active','invited')", (peer["device_id"],)):
                if row["collection_id"] not in listed:
                    self.ctx.collections.mark_replica_state(row["collection_id"], "revoked")
        self.ctx.events.emit("collections")
        return found

    def _replica(self, collection_id: str):
        row = self.ctx.db.one("SELECT * FROM collections WHERE collection_id=? AND is_owner=0 AND deleted=0", (collection_id,))
        if row is None:
            raise NotFound("collection")
        return row

    async def respond_invitation(self, collection_id: str, accept: bool) -> dict:
        row = self._replica(collection_id)
        async with await self.connect_peer(row["owner_device"]) as session:
            await session.request(m.InvitationResponse(collection_id=collection_id, accept=accept))
        if not accept:
            self.ctx.db.execute("UPDATE collections SET deleted=1 WHERE collection_id=?", (collection_id,))
            self.ctx.events.emit("collections")
            return {"collection_id": collection_id, "accepted": False}
        self.ctx.collections.mark_replica_state(collection_id, "active")
        return await self.refresh_collection(collection_id)

    async def refresh_collection(self, collection_id: str) -> dict:
        """Fetch the owner's current view.  A refusal from the owner is
        authoritative (access ended); an unreachable owner tells us nothing."""
        row = self._replica(collection_id)
        try:
            async with await self.connect_peer(row["owner_device"]) as session:
                data = await session.request(m.GetCollection(collection_id=collection_id,
                                                             known_version=row["permission_version"]))
        except PermissionDenied as exc:
            if exc.code in ("not_trusted", "stale_authority"):
                raise
            self.ctx.collections.mark_replica_state(collection_id, "revoked")
            self.ctx.events.emit("collections")
            raise PermissionDenied("The owner's device reports that you no longer have access to this collection. "
                                   "Works you already downloaded remain in your library.", code="access_revoked") from None
        result = self.ctx.collections.store_replica(row["owner_device"], data["collection"])
        self.ctx.events.emit("collections")
        self.ctx.events.emit("library")
        return result

    def download_edition(self, edition_id: str) -> str:
        """Queue a download of an edition we are authorised to fetch."""
        ctx = self.ctx
        ed = ctx.catalogue.edition_row(edition_id)
        file = ctx.catalogue.primary_file(edition_id)
        if file["available"]:
            raise StateError("This edition is already on this device.")
        meta = ctx.catalogue.effective_metadata(edition_id)
        if ed["origin"] == "shared":
            col = self._replica(ed["origin_ref"])
            if col["access_state"] != "active":
                raise PermissionDenied("Your access to this collection has ended; this work can no longer be "
                                       "downloaded from its owner.", code="access_revoked")
            if Permission.DOWNLOAD.value not in json.loads(col["my_permissions"]) or not file["content_hash"]:
                raise PermissionDenied("You can see this collection's catalogue but were not given permission to "
                                       "download its files.", code="no_download_permission")
            return ctx.transfers.create(
                scope={"kind": "collection", "id": col["collection_id"], "known_version": col["permission_version"]},
                file_hash=file["content_hash"], sources=[{"device_id": col["owner_device"]}],
                target={"kind": "collection", "collection_id": col["collection_id"], "edition_id": edition_id},
                title=meta.title, size=file["size"])
        if ed["origin"] == "public":
            return self.download_publication(ed["origin_ref"])[0]
        own = [p for p in ctx.identity.peers() if p["is_own_device"] and p["state"] == "trusted"]
        if not own:
            raise StateError("No device is known that holds this file.")
        return ctx.transfers.create(scope={"kind": "device", "id": "-"}, file_hash=file["content_hash"],
                                    sources=[{"device_id": p["device_id"]} for p in own],
                                    target={"kind": "device", "edition_id": edition_id}, title=meta.title, size=file["size"])

    async def propose_item(self, collection_id: str, edition_id: str) -> dict:
        ctx = self.ctx
        col = self._replica(collection_id)
        if Permission.ADD_WORKS.value not in json.loads(col["my_permissions"]):
            raise PermissionDenied("You do not have permission to add works to this collection.", code="no_permission")
        ed = ctx.catalogue.edition_row(edition_id)
        if ed["origin"] == "shared":
            raise PermissionDenied("Works shared with you privately cannot be passed on to another collection.",
                                   code="no_redistribution")
        file = ctx.catalogue.primary_file(edition_id)
        if not file["available"]:
            raise StateError("The file is not on this device.")
        meta = ctx.catalogue.effective_metadata(edition_id).model_dump(include=set(SHARED_METADATA_FIELDS))
        async with await self.connect_peer(col["owner_device"]) as session:
            data = await session.request(m.Propose(
                collection_id=collection_id, op="add_item", known_version=col["permission_version"],
                payload={"edition_id": edition_id, "metadata": meta,
                         "file": {"file_hash": file["content_hash"], "size": file["size"], "format": file["format"],
                                  "filename": file["filename"]}}))
        ctx.db.execute("INSERT INTO collection_items (collection_id, edition_id, added_by, added_at, state) "
                       "VALUES (?,?,?,?, 'proposed') ON CONFLICT(collection_id, edition_id) DO UPDATE SET state='proposed'",
                       (collection_id, edition_id, ctx.identity.account_id, now_iso()))
        ctx.events.emit("collections")
        return data

    def accept_proposal(self, collection_id: str, edition_id: str) -> str:
        """Owner side: agree to fetch a proposed work from the member who offered it."""
        ctx = self.ctx
        item = ctx.db.one("SELECT * FROM collection_items WHERE collection_id=? AND edition_id=? AND state='proposed'",
                          (collection_id, edition_id))
        if item is None:
            raise NotFound("proposal")
        devices = ctx.identity.devices_of_account(item["added_by"])
        if not devices:
            raise StateError("None of the proposer's devices is in your trusted list.")
        file = ctx.catalogue.primary_file(edition_id)
        return ctx.transfers.create(
            scope={"kind": "collection", "id": collection_id}, file_hash=file["content_hash"],
            sources=[{"device_id": d["device_id"]} for d in devices],
            target={"kind": "proposal", "collection_id": collection_id, "edition_id": edition_id},
            title=ctx.catalogue.effective_metadata(edition_id).title, size=file["size"])

    def reject_proposal(self, collection_id: str, edition_id: str) -> None:
        with self.ctx.db.tx() as c:
            if c.execute("DELETE FROM collection_items WHERE collection_id=? AND edition_id=? AND state='proposed'",
                         (collection_id, edition_id)).rowcount:
                c.execute("UPDATE editions SET deleted=1 WHERE edition_id=?", (edition_id,))
                self.ctx.search.remove(edition_id)
        self.ctx.events.emit("collections")

    async def propose_collection_update(self, collection_id: str, *, name: str | None = None,
                                        description: str | None = None) -> dict:
        col = self._replica(collection_id)
        async with await self.connect_peer(col["owner_device"]) as session:
            data = await session.request(m.Propose(
                collection_id=collection_id, op="update_collection", base=col["updated_at"],
                known_version=col["permission_version"],
                payload={k: v for k, v in (("name", name), ("description", description)) if v is not None}))
        await self.refresh_collection(collection_id)
        return data

    async def share_annotation(self, annotation_id: str, collection_id: str) -> dict:
        """Explicitly share one annotation in a collection ('' un-shares it)."""
        ctx = self.ctx
        current = ctx.annotations.get(annotation_id)
        target = collection_id or current["shared_in"]
        row = ctx.db.one("SELECT * FROM collections WHERE collection_id=? AND deleted=0", (target,))
        if row is None:
            raise NotFound("collection")
        if not row["is_owner"]:
            if Permission.SHARE_ANNOTATIONS.value not in json.loads(row["my_permissions"]):
                raise PermissionDenied("You do not have permission to share annotations in this collection.",
                                       code="no_permission")
            payload = {"annotation_id": annotation_id, "edition_id": current["edition_id"], "kind": current["kind"],
                       "locator": current["locator"], "body": current["body"], "colour": current["colour"],
                       "content_hash": current["content_hash"]}
            async with await self.connect_peer(row["owner_device"]) as session:
                await session.request(m.Propose(collection_id=target, known_version=row["permission_version"],
                                                op="share_annotation" if collection_id else "unshare_annotation",
                                                payload=payload))
        return ctx.annotations.set_shared(annotation_id, collection_id)

    # ====================================================== public catalogue
    async def fetch_public_catalogue(self, address: str, query: str = "", expected_device_id: str | None = None) -> dict:
        """Read a peer's public catalogue anonymously and check every manifest."""
        ctx = self.ctx
        results = []
        async with await self.connect_public(address, expected_device_id) as session:
            data = await session.request(m.PublicCatalogue(query=query, limit=100))
            for entry in (data.get("entries") or [])[:100]:
                if not isinstance(entry, dict) or not isinstance(entry.get("publication_id"), str):
                    continue
                try:
                    detail = await session.request(m.GetPublication(publication_id=entry["publication_id"]))
                    results.append(ctx.publishing.record_remote(session.device_id, address, detail.get("manifest")))
                except CommonsError as exc:
                    results.append({"entry": {"publication_id": entry["publication_id"],
                                              "title": clean_text(entry.get("title"), 200)},
                                    "rejected": exc.code})
            device_id = session.device_id
        for item in results:                      # now that every manifest is recorded, link the editions
            if "check" in item:
                item["entry"]["superseded_by"] = ctx.publishing.remote_superseded_by(
                    item["entry"]["publication_id"], item["check"]["key_id"], device_id)
        ctx.db.execute("INSERT INTO public_sources (address, device_id, added_at, last_fetch) VALUES (?,?,?,?) "
                       "ON CONFLICT(address) DO UPDATE SET device_id=excluded.device_id, last_fetch=excluded.last_fetch",
                       (address, device_id, now_iso(), now_iso()))
        ctx.events.emit("public")
        from ..domain.util import fingerprint_display

        return {"address": address, "device_id": device_id, "device_fingerprint": fingerprint_display(device_id),
                "endpoint_note": ("The endpoint's key matched the fingerprint you expected." if expected_device_id else
                                  "You did not supply a fingerprint for this address, so the endpoint itself is "
                                  "unauthenticated. Integrity rests on the manifest hashes and any publisher signature."),
                "publications": results}

    def download_publication(self, publication_id: str, source_device: str | None = None) -> list[str]:
        manifest, sources = self.ctx.publishing.remote_manifest(publication_id, source_device)
        ids = []
        for file in manifest.files + ([manifest.cover] if manifest.cover else []):
            ids.append(self.ctx.transfers.create(
                scope={"kind": "public", "id": publication_id}, file_hash=file.file_hash, sources=sources,
                target={"kind": "public", "publication_id": publication_id}, manifest=file,
                title=manifest.title + (" (cover)" if file.role == "cover" else "")))
        return ids

    # ================================================================= sync
    async def sync_with(self, device_id: str) -> dict:
        """Two-way metadata synchronisation with another of your own devices."""
        row = self.ctx.identity.peer_row(device_id)
        if row is None or not row["is_own_device"] or row["state"] != "trusted":
            raise PermissionDenied("Synchronisation only runs between devices linked to your own account.",
                                   code="not_own_device")
        sync = self.ctx.sync
        started = now_iso()
        async with await self.connect_peer(device_id) as session:
            digest = (await session.request(m.SyncDigest())).get("digest") or []
            need, push = sync.plan(digest)
            stats = {"applied": 0, "merged": 0, "conflicts": 0, "ignored": 0, "sent": 0}
            for i in range(0, len(need), 200):
                records = (await session.request(m.SyncFetch(keys=need[i:i + 200]))).get("records") or []
                for key, value in sync.apply(records, device_id).items():
                    stats[key] = stats.get(key, 0) + value
            # merged records, and records created while merging, go back so both sides converge
            push = sorted(set(sync.plan(digest)[1]) | set(push) | set(need))
            conflicts = sync.export_conflicts(started)
            for i in range(0, max(len(push), 1), 200):
                records = sync.export(push[i:i + 200])
                if records or conflicts:
                    await session.request(m.SyncPush(records=records, conflicts=conflicts))
                    stats["sent"] += len(records)
                    conflicts = []
        self.ctx.activity.log("sync.completed", "Synchronised catalogue records, collections, reading progress and "
                              "annotations with one of your devices.", peer=device_id, **stats)
        self.ctx.events.emit("library")
        self.ctx.events.emit("collections")
        return stats

    async def sync_all(self) -> dict:
        totals: dict[str, int] = {}
        for peer in self.ctx.identity.peers():
            if peer["is_own_device"] and peer["state"] == "trusted":
                try:
                    for key, value in (await self.sync_with(peer["device_id"])).items():
                        totals[key] = totals.get(key, 0) + value
                except CommonsError:
                    totals["unreachable"] = totals.get("unreachable", 0) + 1
        return totals

    async def _periodic_refresh(self, interval: float) -> None:
        while True:
            await asyncio.sleep(interval)
            try:
                await self.refresh_shared()
                for row in self.ctx.db.query("SELECT collection_id FROM collections WHERE is_owner=0 AND deleted=0 "
                                             "AND access_state='active'"):
                    try:
                        await self.refresh_collection(row["collection_id"])
                    except CommonsError:
                        pass
                await self.sync_all()
            except Exception:
                log.exception("periodic refresh failed")
