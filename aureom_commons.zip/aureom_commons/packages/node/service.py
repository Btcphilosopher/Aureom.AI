"""The application core: one object that owns a profile's services.

``Commons`` is what the desktop interface, the local API, the demonstration
script and the tests all talk to.  It contains no GUI and no transport code;
networking lives in :mod:`aureom.node.runtime`.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import sqlite3
from collections import OrderedDict
from pathlib import Path
from typing import Any

from ..annotations.service import Annotations
from ..catalogue.service import Catalogue
from ..domain.errors import InvalidInput, LibraryLocked, NotFound, StateError
from ..domain.util import new_id, now_iso
from ..identity.service import IdentityService
from ..permissions.collections import Collections
from ..protocol.manifest import FileManifest, build_file_manifest
from ..publishing.service import Publishing
from ..search.index import SearchService
from ..storage.backup import export_backup, restore_backup
from ..storage.credentials import open_secret_store
from ..storage.crypto import DEFAULT_KDF, Vault, encrypt_bytes
from ..storage.db import Database
from ..storage.objects import ObjectReader, ObjectStore
from ..storage.settings import Activity, EventBus, Settings
from ..sync.engine import SyncEngine
from ..transfers.manager import TransferManager

log = logging.getLogger("aureom")

DEVICE_LOSS_GUIDANCE = [
    "If the library on the lost device was encrypted and locked, its catalogue, search index, annotations, covers "
    "and managed files are unreadable without your passphrase. Files you imported “by reference” were never "
    "encrypted by Aureom Commons.",
    "If the library was not encrypted, assume whoever holds the device can read everything in it and can act as "
    "that device.",
    "On another device (or after restoring a backup), remove the lost device from every trusted-peer list, and ask "
    "the people you share with to remove it from theirs. Until they do, the lost device can still authenticate to them.",
    "Revoke and re-invite: for sensitive collections, remove your own account's membership grants tied to the lost "
    "device and pair again with a new device key.",
    "If the lost device held a publisher signing key, tell your readers through another channel that editions "
    "signed after the loss should not be trusted, and publish future editions under a new key.",
    "Restore your most recent encrypted backup onto a replacement device. A backup that includes identity keys "
    "restores the same device identity — do that only if the lost device is truly gone.",
]


def profiles_root() -> Path:
    """Where named profiles live (override with ``AUREOM_HOME``)."""
    if os.environ.get("AUREOM_HOME"):
        return Path(os.environ["AUREOM_HOME"])
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", Path.home())) / "AureomCommons" / "profiles"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "aureom-commons" / "profiles"


def setup_logging(path: Path | None = None, level: int = logging.INFO) -> None:
    """Diagnostic log.  By convention nothing in the codebase passes titles,
    document text, invitation tokens or key material to ``logging`` — only
    event kinds and truncated identifiers."""
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if path is not None:
        handler = logging.FileHandler(path, encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        handlers.append(handler)
    logging.basicConfig(level=level, handlers=handlers, format="%(asctime)s %(levelname)s %(name)s %(message)s",
                        force=True)


class Profile:
    """On-disk layout of one installation (database, object store, keys)."""

    META = "profile.json"

    @staticmethod
    def info(path: str | os.PathLike) -> dict | None:
        try:
            return json.loads((Path(path) / Profile.META).read_text())
        except (FileNotFoundError, ValueError):
            return None

    @staticmethod
    def create(path: str | os.PathLike, *, device_name: str, account_name: str = "", passphrase: str | None = None,
               kdf: dict | None = None, settings: dict | None = None) -> "Commons":
        root = Path(path)
        if Profile.info(root) is not None:
            raise StateError("A profile already exists in that folder.")
        root.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(root, 0o700)
        except OSError:
            pass
        meta = {"profile_id": new_id(), "encrypted": bool(passphrase), "created_at": now_iso(), "format": 1}
        key = Vault(root / "vault.json").create(passphrase, kdf or DEFAULT_KDF) if passphrase else None
        (root / Profile.META).write_text(json.dumps(meta, indent=2))
        ctx = Commons(root, meta, key)
        ctx.settings.set("device_name", device_name)
        ctx.settings.set("account_name", account_name)
        for k, v in (settings or {}).items():
            ctx.settings.set(k, v)
        return ctx

    @staticmethod
    def open(path: str | os.PathLike, passphrase: str | None = None) -> "Commons":
        root = Path(path)
        meta = Profile.info(root)
        if meta is None:
            raise NotFound("No Aureom Commons profile was found in that folder.")
        key = None
        if meta.get("encrypted"):
            if not passphrase:
                raise LibraryLocked("This library is encrypted. Enter the passphrase to unlock it.")
            key = Vault(root / "vault.json").unlock(passphrase)
        return Commons(root, meta, key)


class Commons:
    def __init__(self, root: Path, meta: dict, master_key: bytes | None):
        self.path = root
        self.meta = meta
        self.master_key = master_key
        self.events = EventBus()
        self.db = Database(root / "catalogue.db", master_key).open()
        self.settings = Settings(self.db)
        self.activity = Activity(self.db, self.events)
        limits = self.settings.limits
        self.store = ObjectStore(root, master_key, max_bytes=limits.max_storage_bytes)
        self.secrets = open_secret_store(root, meta["profile_id"], self.db)
        self.identity = IdentityService(self.db, self.secrets, self.settings, self.activity)
        self.search = SearchService(self.db)
        self.catalogue = Catalogue(self.db, self.store, self.settings, self.search)
        self.catalogue.device_id = self.identity.device_id
        self.collections = Collections(self.db, self.identity, self.catalogue, self.activity)
        self.annotations = Annotations(self.db, self.catalogue, lambda: self.identity.account_id,
                                       lambda: self.identity.device_id, self.text_of, limits.max_annotation_chars)
        self.publishing = Publishing(self.db, self.catalogue, self.identity, self.activity, self.settings,
                                     lambda file, edition_id: self.manifest_for(file))
        self.sync = SyncEngine(self.db, self.catalogue, self.collections, self.identity.device_id,
                               lambda: self.identity.account_id)
        for service in (self.catalogue, self.collections, self.annotations):
            service.on_change = self._changed
        self.transfers = TransferManager(self)
        self._manifests: OrderedDict[tuple, FileManifest] = OrderedDict()
        from .runtime import Node

        self.node = Node(self)
        self.closed = False

    # ---------------------------------------------------------------- glue
    def _changed(self, kind: str, record_id: str) -> None:
        self.sync.touch(kind, record_id)
        self.events.emit({"edition": "library", "metadata": "library", "annotation": "annotations",
                          "progress": "progress", "collection": "collections", "member": "collections"}.get(kind, kind),
                         record_id=record_id)

    def open_content_by_hash(self, content_hash: str) -> ObjectReader:
        if self.store.has(content_hash):
            return self.store.open(content_hash)
        row = self.db.one("SELECT * FROM files WHERE content_hash=? AND storage='referenced' AND available=1", (content_hash,))
        if row is None:
            raise NotFound("object")
        return self.catalogue.open_content(dict(row))

    def manifest_for(self, file: dict) -> FileManifest:
        chunk_size = self.settings.limits.chunk_size
        key = (file["content_hash"], chunk_size, file["edition_id"], file["role"])
        cached = self._manifests.get(key)
        if cached is not None:
            self._manifests.move_to_end(key)
            return cached
        with self.open_content_by_hash(file["content_hash"]) as reader:
            manifest = build_file_manifest(reader.iter_blocks(), chunk_size=chunk_size, fmt=file["format"],
                                           media_type=file["media_type"], filename=file["filename"],
                                           edition_id=file["edition_id"], role=file["role"])
        if manifest.file_hash != file["content_hash"]:
            raise StateError("A stored file no longer matches its recorded hash; it will not be served.")
        self._manifests[key] = manifest
        while len(self._manifests) > 256:
            self._manifests.popitem(last=False)
        return manifest

    def text_of(self, edition_id: str) -> str:
        text = self.search.body_text(edition_id)
        if text:
            return text
        try:
            file = self.catalogue.primary_file(edition_id)
            path = self.catalogue.content_path(file)
        except NotFound:
            return ""
        from ..readers.extract import extract

        try:
            return extract(path, self.settings.limits).text
        finally:
            self.store.discard_view(path)

    # ------------------------------------------------------------- overview
    def status(self) -> dict:
        net = self.node.status()
        return {
            "profile": str(self.path), "encrypted": self.store.encrypted,
            "identity": self.identity.describe(), "network": net,
            "library": {"editions": self.db.scalar("SELECT COUNT(*) FROM editions WHERE deleted=0", (), 0),
                        "storage_bytes": self.store.usage_bytes(),
                        "storage_limit": self.settings.limits.max_storage_bytes},
        }

    def home(self) -> dict:
        return {
            "recent_reading": self.catalogue.recent_reading(6),
            "collections": self.collections.list()[:8],
            "incoming_invitations": self.collections.incoming_invitations(),
            "transfers": self.transfers.list(active_only=True)[:8],
            "publication_drafts": self.publishing.drafts()[:8],
            "pending_proposals": self.pending_proposals(),
            "review": {"annotations": len(self.annotations.review_queue()), "conflicts": len(self.sync.conflicts())},
            "network": self.node.status(),
        }

    def pending_proposals(self) -> list[dict]:
        rows = self.db.query(
            "SELECT ci.collection_id, ci.edition_id, ci.added_by, c.name FROM collection_items ci JOIN collections c "
            "ON c.collection_id=ci.collection_id WHERE ci.state='proposed' AND c.is_owner=1 AND c.deleted=0")
        out = []
        for r in rows:
            try:
                view = self.catalogue.edition_view(r["edition_id"])
            except NotFound:
                continue
            out.append({"collection_id": r["collection_id"], "collection_name": r["name"], "edition_id": r["edition_id"],
                        "title": view["title"], "size": view["size"], "format": view["format"],
                        "proposed_by": self.identity.account_display_name(r["added_by"]), "account_id": r["added_by"]})
        return out

    def protection_report(self) -> dict:
        """State plainly what is and is not protected at rest."""
        enc = self.store.encrypted
        referenced = self.db.scalar("SELECT COUNT(*) FROM files WHERE storage='referenced'", (), 0)
        return {
            "encrypted_library": enc,
            "protected_when_locked": ([
                "catalogue database (titles, metadata, collections, membership, activity journal)",
                "full-text search index", "annotations, bookmarks and reading progress",
                "covers and managed document files", "partial downloads", "device, account and publisher keys",
            ] if enc else []),
            "not_protected": (
                ["files imported “by reference” — they stay ordinary files where you keep them"] if referenced or enc else []
            ) + ([] if enc else [
                "everything in this profile is stored unencrypted; it relies on your operating-system account and "
                "disk encryption"]) + (
                ["temporary decrypted copies made while a PDF, audio file or external application has a document "
                 "open (kept in a private folder and removed when the library locks)",
                 "anything visible in memory while the library is unlocked",
                 "the fact that a profile exists, its size, and the number and size of stored objects"] if enc else []),
            "referenced_files": referenced,
            "key_storage": self.secrets.backend, "key_storage_note": self.secrets.description,
            "device_loss_guidance": DEVICE_LOSS_GUIDANCE,
        }

    # -------------------------------------------------------------- backup
    def _secret_names(self) -> list[str]:
        names = ["device", "account", "device-previous"]
        names += [f"publisher:{r['publisher_id']}" for r in self.db.query(
            "SELECT publisher_id FROM publisher_identities WHERE has_secret=1")]
        return names

    def export_backup(self, dest: str | os.PathLike, passphrase: str, *, include_identity: bool = True,
                      kdf: dict | None = None) -> dict:
        snapshot = self.db.snapshot_bytes()
        conn = sqlite3.connect(":memory:")
        conn.deserialize(snapshot)
        conn.execute("DELETE FROM secrets")          # keys travel only in the explicit secrets member
        conn.execute("DELETE FROM transfers WHERE state != 'completed'")
        conn.commit()
        conn.execute("VACUUM")
        snapshot = conn.serialize()
        conn.close()
        secrets = None
        if include_identity:
            secrets = {n: v for n in self._secret_names() if (v := self.secrets.get(n)) is not None}
        manifest = export_backup(
            Path(dest), passphrase, db_snapshot=snapshot, store=self.store, object_hashes=self._backup_hashes(),
            secrets=secrets, profile_info={"profile_id": self.meta["profile_id"], "device_id": self.identity.device_id},
            referenced=self.catalogue.referenced_paths(), kdf=kdf)
        self.activity.log("backup.exported", "An encrypted backup was exported.", objects=manifest["objects"],
                          includes_identity_keys=include_identity)
        return manifest

    def _backup_hashes(self) -> list[str]:
        rows = self.db.query("SELECT DISTINCT content_hash FROM files WHERE storage='managed'")
        return [r[0] for r in rows if self.store.has(r[0])]

    @staticmethod
    def restore_backup(src: str | os.PathLike, backup_passphrase: str, new_profile: str | os.PathLike, *,
                       passphrase: str | None = None, kdf: dict | None = None) -> "Commons":
        """Restore into a new, empty profile folder (optionally encrypted
        with a new library passphrase)."""
        root = Path(new_profile)
        if root.exists() and any(root.iterdir()):
            raise StateError("Choose an empty folder to restore into.")
        root.mkdir(parents=True, exist_ok=True)
        key = Vault(root / "vault.json").create(passphrase, kdf or DEFAULT_KDF) if passphrase else None
        store = ObjectStore(root, key)
        held: dict[str, Any] = {"secrets": {}}

        def on_catalogue(data: bytes) -> None:
            probe = sqlite3.connect(":memory:")
            try:
                probe.deserialize(data)
                probe.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()
            except sqlite3.Error as exc:
                raise InvalidInput("the backup's catalogue is not a valid database") from exc
            finally:
                probe.close()
            if key:
                (root / "catalogue.db.enc").write_bytes(encrypt_bytes(key, data))
            else:
                (root / "catalogue.db").write_bytes(data)

        def on_object(content_hash: str, fh) -> None:
            def blocks():
                while True:
                    data = fh.read(1024 * 1024)
                    if not data:
                        return
                    yield data

            store.ingest_blocks(blocks(), expected_hash=content_hash)     # every object is re-verified

        try:
            manifest = restore_backup(Path(src), backup_passphrase, on_catalogue=on_catalogue,
                                      on_secrets=lambda s: held["secrets"].update(s), on_object=on_object,
                                      max_object_bytes=64 * 1024 ** 3)
        except BaseException:
            shutil.rmtree(root, ignore_errors=True)
            raise
        meta = {"profile_id": new_id(), "encrypted": bool(passphrase), "created_at": now_iso(), "format": 1,
                "restored_from_backup": manifest.get("created_at", "")}
        (root / Profile.META).write_text(json.dumps(meta, indent=2))
        # place the keys before the services start, so no fresh identity is generated by mistake
        db = Database(root / "catalogue.db", key).open()
        secrets = open_secret_store(root, meta["profile_id"], db)
        for name, value in held["secrets"].items():
            secrets.set(name, value)
        db.close()
        ctx = Commons(root, meta, key)
        ctx.db.execute("UPDATE files SET available=0 WHERE storage='managed' AND content_hash NOT IN (SELECT '')")
        with ctx.db.deferred():
            for row in ctx.db.query("SELECT file_id, content_hash FROM files WHERE storage='managed'"):
                if ctx.store.has(row["content_hash"]):
                    ctx.db.execute("UPDATE files SET available=1 WHERE file_id=?", (row["file_id"],))
        ctx.activity.log("backup.restored", "This library was restored from an encrypted backup.",
                         identity_restored=bool(held["secrets"]))
        return ctx

    # ---------------------------------------------------------------- close
    def close(self) -> None:
        """Lock the library: stop networking, wipe temporary plaintext, drop keys."""
        if self.closed:
            return
        self.closed = True
        try:
            self.node.shutdown()
        finally:
            self.store.wipe_views()
            self.db.close()
            self.master_key = None

    lock = close
