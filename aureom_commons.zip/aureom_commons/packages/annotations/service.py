"""Bookmarks, highlights, notes and reading progress.

Annotations never touch the original file.  Each one is anchored to a
specific edition *and* the exact content hash it was made against, using a
quote-plus-context locator (in the spirit of the W3C Web Annotation text
selectors).  They are private unless the user explicitly shares one in a
collection.

When a new edition changes the text, :meth:`Annotations.migrate` copies
annotations forward and classifies every match:

* ``ok``            the quoted passage was found unambiguously;
* ``needs_review``  found, but ambiguously or only approximately;
* ``orphaned``      not found — kept for the reader to re-place or discard.

Nothing is silently dropped, and the originals stay on the old edition.
"""
from __future__ import annotations

import difflib
import hashlib
import json
from typing import Any, Callable

from ..domain.errors import InvalidInput, NotFound, PermissionDenied
from ..domain.util import clean_text, new_id, now_iso
from ..storage.db import Database

KINDS = ("bookmark", "highlight", "note")
COLOURS = ("copper", "gold", "sage", "sky", "rose")


def norm(text: str) -> str:
    return " ".join((text or "").split())


def clean_locator(locator: Any) -> dict:
    if not isinstance(locator, dict):
        raise InvalidInput("locator must be an object")
    out: dict[str, Any] = {}
    for key in ("section", "page", "start", "end"):
        if locator.get(key) is not None:
            out[key] = max(0, int(locator[key]))
    for key in ("time", "fraction"):
        if locator.get(key) is not None:
            out[key] = max(0.0, float(locator[key]))
    for key, cap in (("quote", 2000), ("prefix", 120), ("suffix", 120), ("label", 200)):
        if locator.get(key):
            out[key] = clean_text(locator[key], cap)
    return out


def locate(quote: str, prefix: str, suffix: str, text: str, hint_fraction: float | None = None) -> dict:
    """Find ``quote`` in ``text`` (both whitespace-normalised).

    Returns ``{"status", "start", "end", "quote", "note"}``."""
    q = norm(quote)
    if not q:
        return {"status": "needs_review", "start": None, "end": None, "quote": "",
                "note": "This annotation marks a position rather than a passage; check it still points where you meant."}
    positions = []
    at = text.find(q)
    while at != -1 and len(positions) < 50:
        positions.append(at)
        at = text.find(q, at + 1)
    if len(positions) == 1:
        if len(q) >= 12:
            return {"status": "ok", "start": positions[0], "end": positions[0] + len(q), "quote": q, "note": ""}
        p, s = norm(prefix), norm(suffix)
        before = text[max(0, positions[0] - len(p) - 2): positions[0]]
        after = text[positions[0] + len(q): positions[0] + len(q) + len(s) + 2]
        if (p and p in before) or (s and s in after):
            return {"status": "ok", "start": positions[0], "end": positions[0] + len(q), "quote": q, "note": ""}
        return {"status": "needs_review", "start": positions[0], "end": positions[0] + len(q), "quote": q,
                "note": "A short passage matched once, but the surrounding text is different."}
    if len(positions) > 1:
        p, s = norm(prefix), norm(suffix)
        exact = [pos for pos in positions
                 if (not p or text[max(0, pos - len(p) - 1): pos].rstrip().endswith(p))
                 and (not s or text[pos + len(q): pos + len(q) + len(s) + 1].lstrip().startswith(s))]
        if len(exact) == 1 and (p or s):
            return {"status": "ok", "start": exact[0], "end": exact[0] + len(q), "quote": q, "note": ""}
        target = (hint_fraction or 0.0) * len(text)
        best = min(positions, key=lambda pos: abs(pos - target))
        return {"status": "needs_review", "start": best, "end": best + len(q), "quote": q,
                "note": f"The passage appears {len(positions)} times in this edition; the nearest occurrence was chosen."}
    # no exact match: look for a nearby passage that shares a run of words
    words = q.split()
    best: tuple[float, int, int] | None = None
    for size in (6, 4, 3):
        if len(words) < size:
            continue
        for i in range(0, len(words) - size + 1, max(1, size // 2)):
            shingle = " ".join(words[i: i + size])
            pos = text.find(shingle)
            if pos == -1:
                continue
            lead = len(" ".join(words[:i])) + (1 if i else 0)
            start = max(0, pos - lead - 20)
            window = text[start: start + len(q) + 40]
            matcher = difflib.SequenceMatcher(None, window, q, autojunk=False)
            ratio = matcher.ratio()
            blocks = [b for b in matcher.get_matching_blocks() if b.size]
            if blocks and (best is None or ratio > best[0]):
                best = (ratio, start + blocks[0].a, start + blocks[-1].a + blocks[-1].size)
        if best and best[0] >= 0.6:
            break
    if best and best[0] >= 0.55:
        return {"status": "needs_review", "start": best[1], "end": best[2], "quote": text[best[1]: best[2]],
                "note": f"The text changed in this edition (about {round(best[0] * 100)}% similar). "
                        "Check that the annotation still refers to this passage."}
    return {"status": "orphaned", "start": None, "end": None, "quote": q,
            "note": "The annotated passage was not found in this edition."}


class Annotations:
    def __init__(self, db: Database, catalogue, account_id: Callable[[], str], device_id: Callable[[], str],
                 text_of: Callable[[str], str], max_chars: int = 20000):
        self.db, self.catalogue = db, catalogue
        self._account_id, self._device_id, self._text_of = account_id, device_id, text_of
        self.max_chars = max_chars
        self.on_change: Callable[[str, str], None] = lambda kind, record_id: None

    # ---------------------------------------------------------------- CRUD
    def _dict(self, row) -> dict:
        d = dict(row)
        d["locator"] = json.loads(d["locator"])
        d["mine"] = d["author_account"] == ""
        d["private"] = d["shared_in"] == ""
        return d

    def get(self, annotation_id: str) -> dict:
        row = self.db.one("SELECT * FROM annotations WHERE annotation_id=? AND deleted=0", (annotation_id,))
        if row is None:
            raise NotFound("annotation")
        return self._dict(row)

    def list(self, edition_id: str, *, include_shared: bool = True) -> list[dict]:
        sql = "SELECT * FROM annotations WHERE edition_id=? AND deleted=0"
        if not include_shared:
            sql += " AND author_account=''"
        rows = self.db.query(sql + " ORDER BY created_at", (edition_id,))
        return sorted((self._dict(r) for r in rows),
                      key=lambda a: (a["locator"].get("section", 0), a["locator"].get("page", 0),
                                     a["locator"].get("start", 0), a["locator"].get("time", 0)))

    def create(self, edition_id: str, kind: str, locator: dict, body: str = "", colour: str = "copper") -> dict:
        if kind not in KINDS:
            raise InvalidInput("unknown annotation kind")
        file = self.catalogue.primary_file(edition_id)
        aid, ts = new_id(), now_iso()
        self.db.execute(
            "INSERT INTO annotations (annotation_id, edition_id, content_hash, kind, locator, body, colour, created_at, "
            "updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (aid, edition_id, file["content_hash"], kind, json.dumps(clean_locator(locator)),
             clean_text(body, self.max_chars, single_line=False), colour if colour in COLOURS else "copper", ts, ts))
        self.on_change("annotation", aid)
        return self.get(aid)

    def update(self, annotation_id: str, *, body: str | None = None, colour: str | None = None,
               locator: dict | None = None, status: str | None = None) -> dict:
        current = self.get(annotation_id)
        if not current["mine"]:
            raise PermissionDenied("Annotations shared by other people cannot be edited.", code="not_yours")
        sets, params = ["updated_at=?"], [now_iso()]
        if body is not None:
            sets.append("body=?")
            params.append(clean_text(body, self.max_chars, single_line=False))
        if colour in COLOURS:
            sets.append("colour=?")
            params.append(colour)
        if locator is not None:
            sets.append("locator=?")
            params.append(json.dumps(clean_locator(locator)))
        if status in ("ok", "needs_review", "orphaned"):
            sets.append("status=?")
            params.append(status)
            if status == "ok":
                sets.append("review_note=''")
        self.db.execute(f"UPDATE annotations SET {', '.join(sets)} WHERE annotation_id=?", (*params, annotation_id))
        self.on_change("annotation", annotation_id)
        return self.get(annotation_id)

    def delete(self, annotation_id: str) -> None:
        current = self.get(annotation_id)
        if not current["mine"]:
            raise PermissionDenied("Annotations shared by other people cannot be deleted here.", code="not_yours")
        self.db.execute("UPDATE annotations SET deleted=1, updated_at=? WHERE annotation_id=?", (now_iso(), annotation_id))
        self.on_change("annotation", annotation_id)

    def set_shared(self, annotation_id: str, collection_id: str) -> dict:
        """Mark one of my annotations as shared in a collection ('' = private again).
        Delivery to the collection owner is handled by the network layer."""
        current = self.get(annotation_id)
        if not current["mine"]:
            raise PermissionDenied("Only your own annotations can be shared.", code="not_yours")
        if collection_id and not self.db.one(
                "SELECT 1 FROM collection_items WHERE collection_id=? AND edition_id=? AND state='active'",
                (collection_id, current["edition_id"])):
            raise InvalidInput("That work is not part of the chosen collection.")
        self.db.execute("UPDATE annotations SET shared_in=?, updated_at=? WHERE annotation_id=?",
                        (collection_id, now_iso(), annotation_id))
        self.on_change("annotation", annotation_id)
        return self.get(annotation_id)

    # ------------------------------------------------------------ progress
    def set_progress(self, edition_id: str, locator: dict, fraction: float) -> None:
        self.catalogue.edition_row(edition_id)
        fraction = min(1.0, max(0.0, float(fraction)))
        self.db.execute(
            "INSERT INTO reading_progress (edition_id, device_id, locator, fraction, updated_at) VALUES (?,?,?,?,?) "
            "ON CONFLICT(edition_id, device_id) DO UPDATE SET locator=excluded.locator, fraction=excluded.fraction, "
            "updated_at=excluded.updated_at",
            (edition_id, self._device_id(), json.dumps(clean_locator(locator)), fraction, now_iso()))
        self.on_change("progress", f"{edition_id}:{self._device_id()}")

    def progress(self, edition_id: str) -> dict:
        """Each device records its own position, so nothing is overwritten.
        ``current`` is the most recent; ``devices`` lists them all so the
        reader can jump to where another device left off."""
        rows = [dict(r) | {"locator": json.loads(r["locator"])} for r in self.db.query(
            "SELECT * FROM reading_progress WHERE edition_id=? ORDER BY updated_at DESC", (edition_id,))]
        mine = next((r for r in rows if r["device_id"] == self._device_id()), None)
        return {"current": rows[0] if rows else None, "this_device": mine, "devices": rows,
                "furthest": max((r["fraction"] for r in rows), default=0.0)}

    # ----------------------------------------------------------- migration
    def migrate(self, old_edition_id: str, new_edition_id: str) -> dict:
        new_file = self.catalogue.primary_file(new_edition_id)
        text = norm(self._text_of(new_edition_id))
        old_len = max(1, len(norm(self._text_of(old_edition_id))))
        report = {"ok": 0, "needs_review": 0, "orphaned": 0, "skipped": 0}
        with self.db.deferred():
            for a in self.list(old_edition_id, include_shared=False):
                derived = hashlib.sha256(f"{a['annotation_id']}>{new_edition_id}".encode()).hexdigest()[:32]
                if self.db.one("SELECT 1 FROM annotations WHERE annotation_id=?", (derived,)):
                    report["skipped"] += 1
                    continue
                loc = dict(a["locator"])
                if "page" in loc and not loc.get("quote"):
                    result = {"status": "needs_review", "start": None, "end": None, "quote": "",
                              "note": "Page numbers may have shifted in this edition."}
                elif "time" in loc and not loc.get("quote"):
                    result = {"status": "needs_review", "start": None, "end": None, "quote": "",
                              "note": "Timings may differ in this edition."}
                else:
                    hint = (loc.get("start", 0) / old_len) if loc.get("start") is not None else loc.get("fraction")
                    result = locate(loc.get("quote", ""), loc.get("prefix", ""), loc.get("suffix", ""), text, hint)
                if result["start"] is not None:
                    loc.update(start=result["start"], end=result["end"], quote=result["quote"],
                               prefix=text[max(0, result["start"] - 40): result["start"]],
                               suffix=text[result["end"]: result["end"] + 40])
                    loc.pop("section", None)     # offsets are now relative to the whole new text
                    loc["fraction"] = result["start"] / max(1, len(text))
                ts = now_iso()
                self.db.execute(
                    "INSERT INTO annotations (annotation_id, edition_id, content_hash, kind, locator, body, colour, "
                    "status, migrated_from, review_note, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (derived, new_edition_id, new_file["content_hash"], a["kind"], json.dumps(loc), a["body"],
                     a["colour"], result["status"], a["annotation_id"], result["note"], a["created_at"], ts))
                self.on_change("annotation", derived)
                report[result["status"]] += 1
        return report

    def review_queue(self) -> list[dict]:
        return [self._dict(r) for r in self.db.query(
            "SELECT * FROM annotations WHERE deleted=0 AND author_account='' AND status != 'ok' ORDER BY updated_at DESC")]
