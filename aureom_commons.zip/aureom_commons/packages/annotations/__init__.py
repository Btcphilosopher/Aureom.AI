from .service import Annotations  # noqa: F401
