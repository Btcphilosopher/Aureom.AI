"""Collections, membership and authorisation.

The owner's installation is the **authority** for a shared collection.
Every request from a peer is checked against the owner's *current*
membership table — never against anything the requester presents — so an
old copy of a membership record cannot restore a revoked permission.

``permission_version`` increases on every membership change.  Requests carry
the highest version the requester has seen; an owner device that has fallen
behind (for example an owner's second device that was offline during a
revocation) refuses to serve until it has synchronised.
"""
from __future__ import annotations

import json
from typing import Any, Callable

from ..domain.errors import Conflict, InvalidInput, NotFound, PermissionDenied, StateError
from ..domain.models import PERMISSION_PRESETS, Metadata, Permission
from ..domain.util import clean_text, is_safe_id, new_id, now_iso
from ..identity.service import IdentityService
from ..storage.db import Database
from ..storage.settings import Activity

# Descriptive fields a collection exposes to members who may view its
# catalogue.  Personal tags, import sources, reading progress, private
# annotations and membership of other collections are never included.
SHARED_METADATA_FIELDS = ("title", "subtitle", "authors", "contributors", "publisher", "language",
                          "publication_date", "isbn", "doi", "rights", "licence", "description", "accessibility")

REVOCATION_NOTICE = (
    "Revoking access stops this person's devices from listing the collection or downloading from your devices "
    "from now on. It cannot erase copies they have already downloaded, and it cannot reach a device that is offline."
)


def normalise_permissions(values) -> list[str]:
    if isinstance(values, str):
        values = PERMISSION_PRESETS.get(values) or [values]
    out: list[str] = []
    for v in values or []:
        try:
            p = Permission(v.value if isinstance(v, Permission) else v)
        except ValueError:
            raise InvalidInput(f"unknown permission: {v}") from None
        if p.value not in out:
            out.append(p.value)
    if out and Permission.VIEW_METADATA.value not in out:
        out.insert(0, Permission.VIEW_METADATA.value)     # every other permission implies seeing the catalogue
    return out


class Collections:
    def __init__(self, db: Database, identity: IdentityService, catalogue, activity: Activity):
        self.db, self.identity, self.catalogue, self.activity = db, identity, catalogue, activity
        self.on_change: Callable[[str, str], None] = lambda kind, record_id: None

    # ============================================================== basics
    def _row(self, collection_id: str, *, owner: bool | None = None):
        row = self.db.one("SELECT * FROM collections WHERE collection_id=? AND deleted=0", (collection_id,))
        if row is None:
            raise NotFound("collection")
        if owner is True and not row["is_owner"]:
            raise StateError("Only the collection's owner can do this on their own device.")
        return row

    def create(self, name: str, description: str = "", kind: str = "shared") -> dict:
        name = clean_text(name, 120)
        if not name:
            raise InvalidInput("A collection needs a name.")
        if kind not in ("local", "shared"):
            raise InvalidInput("unknown collection kind")
        cid, ts = new_id(), now_iso()
        self.db.execute("INSERT INTO collections (collection_id, name, description, kind, owner_account, is_owner, "
                        "owner_name, created_at, updated_at) VALUES (?,?,?,?,?,1,?,?,?)",
                        (cid, name, clean_text(description, 2000, single_line=False), kind, self.identity.account_id,
                         self.identity.account_display_name(self.identity.account_id), ts, ts))
        self.on_change("collection", cid)
        return self.get(cid)

    def update(self, collection_id: str, *, name: str | None = None, description: str | None = None,
               base_updated_at: str | None = None, actor: str = "") -> dict:
        row = self._row(collection_id, owner=True)
        if base_updated_at and base_updated_at != row["updated_at"]:
            raise Conflict("The collection was changed since you last loaded it.")
        new_name = clean_text(name, 120) if name is not None else row["name"]
        if not new_name:
            raise InvalidInput("A collection needs a name.")
        new_desc = clean_text(description, 2000, single_line=False) if description is not None else row["description"]
        self.db.execute("UPDATE collections SET name=?, description=?, updated_at=? WHERE collection_id=?",
                        (new_name, new_desc, now_iso(), collection_id))
        self.on_change("collection", collection_id)
        return self.get(collection_id)

    def delete(self, collection_id: str) -> None:
        """Delete a collection.  Members lose future access (same limits as
        revocation); works stay in the owner's library."""
        row = self._row(collection_id)
        with self.db.tx() as c:
            c.execute("UPDATE collections SET deleted=1, updated_at=?, permission_version=permission_version+1 "
                      "WHERE collection_id=?", (now_iso(), collection_id))
            if row["is_owner"]:
                c.execute("UPDATE collection_members SET status='revoked', revoked_at=? WHERE collection_id=? "
                          "AND status IN ('invited','active')", (now_iso(), collection_id))
                c.execute("UPDATE pairing_invitations SET state='cancelled' WHERE collection_id=? AND state='open'",
                          (collection_id,))
        self.activity.log("collection.deleted", "A collection was deleted.", collection_id=collection_id)
        self.on_change("collection", collection_id)

    def add_item(self, collection_id: str, edition_id: str, *, added_by: str = "", state: str = "active") -> None:
        row = self._row(collection_id, owner=True)
        ed = self.catalogue.edition_row(edition_id)
        if row["kind"] == "shared" and ed["origin"] == "shared" and ed["origin_ref"] != collection_id:
            src = self.db.one("SELECT my_permissions FROM collections WHERE collection_id=?", (ed["origin_ref"],))
            if not src or Permission.REDISTRIBUTE.value not in json.loads(src["my_permissions"]):
                raise PermissionDenied(
                    "This work was shared with you without permission to redistribute it, so it cannot be added to "
                    "a collection you share with others.", code="no_redistribution")
        self.db.execute("INSERT INTO collection_items (collection_id, edition_id, added_by, added_at, state) "
                        "VALUES (?,?,?,?,?) ON CONFLICT(collection_id, edition_id) DO UPDATE SET state=excluded.state",
                        (collection_id, edition_id, added_by or self.identity.account_id, now_iso(), state))
        self.db.execute("UPDATE collections SET updated_at=? WHERE collection_id=?", (now_iso(), collection_id))
        self.on_change("collection", collection_id)

    def remove_item(self, collection_id: str, edition_id: str) -> None:
        self._row(collection_id, owner=True)
        self.db.execute("UPDATE collection_items SET state='removed' WHERE collection_id=? AND edition_id=?",
                        (collection_id, edition_id))
        self.db.execute("UPDATE collections SET updated_at=? WHERE collection_id=?", (now_iso(), collection_id))
        self.on_change("collection", collection_id)

    def item_ids(self, collection_id: str, states: tuple[str, ...] = ("active",)) -> list[str]:
        marks = ",".join("?" * len(states))
        return [r[0] for r in self.db.query(
            f"SELECT ci.edition_id FROM collection_items ci JOIN editions e ON e.edition_id=ci.edition_id "
            f"WHERE ci.collection_id=? AND ci.state IN ({marks}) AND e.deleted=0 ORDER BY ci.added_at",
            (collection_id, *states))]

    def members(self, collection_id: str) -> list[dict]:
        out = []
        for r in self.db.query("SELECT * FROM collection_members WHERE collection_id=? ORDER BY invited_at", (collection_id,)):
            d = dict(r)
            d["permissions"] = json.loads(d["permissions"])
            d["display_name"] = d["display_name"] or self.identity.account_display_name(d["account_id"])
            out.append(d)
        return out

    def summary(self, row) -> dict:
        d = dict(row)
        d["my_permissions"] = json.loads(d["my_permissions"])
        d["item_count"] = self.db.scalar(
            "SELECT COUNT(*) FROM collection_items ci JOIN editions e ON e.edition_id=ci.edition_id "
            "WHERE ci.collection_id=? AND ci.state='active' AND e.deleted=0", (d["collection_id"],), 0)
        d["member_count"] = self.db.scalar("SELECT COUNT(*) FROM collection_members WHERE collection_id=? "
                                           "AND status IN ('invited','active')", (d["collection_id"],), 0)
        d["visibility"] = "private" if d["kind"] == "local" or (d["is_owner"] and not d["member_count"] and not self.db.one(
            "SELECT 1 FROM pairing_invitations WHERE collection_id=? AND state='open'", (d["collection_id"],))) else "shared"
        return d

    def list(self) -> list[dict]:
        return [self.summary(r) for r in self.db.query("SELECT * FROM collections WHERE deleted=0 ORDER BY created_at")]

    def get(self, collection_id: str) -> dict:
        d = self.summary(self._row(collection_id))
        d["items"] = []
        for eid in self.item_ids(collection_id, ("active", "proposed")):
            view = self.catalogue.edition_view(eid)
            view["item_state"] = self.db.scalar("SELECT state FROM collection_items WHERE collection_id=? AND edition_id=?",
                                                (collection_id, eid))
            d["items"].append(view)
        d["members"] = self.members(collection_id)
        d["shared_annotations"] = [dict(r) for r in self.db.query(
            "SELECT annotation_id, edition_id, kind, locator, body, author_account, author_name, updated_at "
            "FROM annotations WHERE shared_in=? AND deleted=0 ORDER BY updated_at", (collection_id,))]
        return d

    def incoming_invitations(self) -> list[dict]:
        return [self.summary(r) for r in self.db.query(
            "SELECT * FROM collections WHERE deleted=0 AND is_owner=0 AND access_state='invited' ORDER BY created_at")]

    # ========================================================== membership
    def exposure_preview(self, collection_id: str, permissions) -> dict:
        """Exactly what an invitation with these permissions would expose."""
        perms = normalise_permissions(permissions)
        row = self._row(collection_id, owner=True)
        items = []
        for eid in self.item_ids(collection_id):
            view = self.catalogue.edition_view(eid)
            items.append({"title": view["title"], "authors": view["metadata"]["authors"], "format": view["format"],
                          "filename": view["filename"], "size": view["size"],
                          "downloadable": Permission.DOWNLOAD.value in perms})
        annotations = self.db.scalar("SELECT COUNT(*) FROM annotations WHERE shared_in=? AND deleted=0", (collection_id,), 0)
        return {
            "collection": {"name": row["name"], "description": row["description"]},
            "permissions": perms,
            "titles": items,
            "files_downloadable": Permission.DOWNLOAD.value in perms,
            "metadata_fields": list(SHARED_METADATA_FIELDS),
            "shared_annotations": annotations,
            "not_exposed": ["your private annotations and reading progress", "personal tags", "import sources and file paths",
                            "other collections and the rest of your library", "the list of other members"
                            if Permission.MANAGE_MEMBERS.value not in perms else "nothing further"],
            "identity_exposed": ["your device name and device fingerprint", "your account fingerprint",
                                 "the network address your device is reached at"],
            "redistribution": Permission.REDISTRIBUTE.value in perms,
            "notices": [
                "Anyone who can download a file can keep and copy it. There is no reliable 'view only' for files.",
                REVOCATION_NOTICE,
            ],
        }

    def _bump(self, c, collection_id: str) -> int:
        c.execute("UPDATE collections SET permission_version=permission_version+1, updated_at=? WHERE collection_id=?",
                  (now_iso(), collection_id))
        return c.execute("SELECT permission_version FROM collections WHERE collection_id=?", (collection_id,)).fetchone()[0]

    def invite_account(self, collection_id: str, account_id: str, permissions="reader", *, display_name: str = "",
                       status: str = "invited") -> dict:
        row = self._row(collection_id, owner=True)
        if row["kind"] != "shared":
            raise StateError("Private shelves cannot be shared. Create a shared collection instead.")
        if row["access_state"] == "suspended":
            raise StateError("Sharing for this collection is suspended until a synchronisation conflict is reviewed.")
        if account_id == self.identity.account_id:
            raise InvalidInput("You already own this collection.")
        if self.identity.is_blocked(None, account_id):
            raise PermissionDenied("this account is blocked", code="blocked")
        perms = normalise_permissions(permissions)
        if not perms:
            raise InvalidInput("Choose at least one permission.")
        with self.db.tx() as c:
            version = self._bump(c, collection_id)
            c.execute(
                "INSERT INTO collection_members (collection_id, account_id, display_name, permissions, status, "
                "permission_version, invited_at, joined_at) VALUES (?,?,?,?,?,?,?,?) "
                "ON CONFLICT(collection_id, account_id) DO UPDATE SET permissions=excluded.permissions, "
                "status=excluded.status, permission_version=excluded.permission_version, invited_at=excluded.invited_at, "
                "revoked_at=NULL, joined_at=excluded.joined_at",
                (collection_id, account_id, clean_text(display_name, 80), json.dumps(perms), status, version, now_iso(),
                 now_iso() if status == "active" else None))
        self.activity.log("collection.invited", "Invited an account to a shared collection.",
                          collection_id=collection_id, permissions=perms)
        self.on_change("member", f"{collection_id}:{account_id}")
        return {"collection_id": collection_id, "account_id": account_id, "permissions": perms, "status": status}

    def respond_to_invitation(self, collection_id: str, account_id: str, accept: bool) -> None:
        """Owner side: the invited account accepted or declined."""
        with self.db.tx() as c:
            row = c.execute("SELECT status FROM collection_members WHERE collection_id=? AND account_id=?",
                            (collection_id, account_id)).fetchone()
            if row is None or row["status"] not in ("invited", "active"):
                raise PermissionDenied()
            c.execute("UPDATE collection_members SET status=?, joined_at=? WHERE collection_id=? AND account_id=?",
                      ("active" if accept else "declined", now_iso() if accept else None, collection_id, account_id))
            self._bump(c, collection_id)
        self.activity.log("collection.invitation_" + ("accepted" if accept else "declined"),
                          "A collection invitation was " + ("accepted." if accept else "declined."),
                          collection_id=collection_id)
        self.on_change("member", f"{collection_id}:{account_id}")

    def set_permissions(self, collection_id: str, account_id: str, permissions, *, actor: str = "") -> None:
        self._row(collection_id, owner=True)
        perms = normalise_permissions(permissions)
        with self.db.tx() as c:
            version = self._bump(c, collection_id)
            if c.execute("UPDATE collection_members SET permissions=?, permission_version=? WHERE collection_id=? "
                         "AND account_id=? AND status IN ('invited','active')",
                         (json.dumps(perms), version, collection_id, account_id)).rowcount == 0:
                raise NotFound("member")
        self.activity.log("collection.permissions_changed", "A member's permissions were changed.",
                          collection_id=collection_id, permissions=perms)
        self.on_change("member", f"{collection_id}:{account_id}")

    def revoke(self, collection_id: str, account_id: str) -> dict:
        self._row(collection_id, owner=True)
        with self.db.tx() as c:
            version = self._bump(c, collection_id)
            if c.execute("UPDATE collection_members SET status='revoked', revoked_at=?, permission_version=? "
                         "WHERE collection_id=? AND account_id=?", (now_iso(), version, collection_id, account_id)).rowcount == 0:
                raise NotFound("member")
        self.activity.log("collection.revoked", "A member's access to a shared collection was revoked. "
                          "Copies they already downloaded remain on their devices.", collection_id=collection_id)
        self.on_change("member", f"{collection_id}:{account_id}")
        return {"collection_id": collection_id, "account_id": account_id, "status": "revoked",
                "permission_version": version, "notice": REVOCATION_NOTICE}

    # ======================================================= authorisation
    def permissions_of(self, collection_id: str, account_id: str | None, *, include_invited: bool = False) -> set[str]:
        """Authoritative lookup on the owner's device.  Returns an empty set
        for unknown collections, non-members, revoked members and replicas."""
        if not account_id or not is_safe_id(collection_id):
            return set()
        row = self.db.one("SELECT * FROM collections WHERE collection_id=? AND deleted=0 AND is_owner=1 AND kind='shared'",
                          (collection_id,))
        if row is None or row["access_state"] == "suspended":
            return set()
        if account_id == row["owner_account"]:
            return {p.value for p in Permission}
        states = ("active", "invited") if include_invited else ("active",)
        member = self.db.one("SELECT permissions, status FROM collection_members WHERE collection_id=? AND account_id=?",
                             (collection_id, account_id))
        if member is None or member["status"] not in states:
            return set()
        return set(json.loads(member["permissions"]))

    def require(self, collection_id: str, account_id: str | None, permission: Permission,
                known_version: int = 0) -> None:
        if permission.value not in self.permissions_of(collection_id, account_id):
            raise PermissionDenied()
        version = self.db.scalar("SELECT permission_version FROM collections WHERE collection_id=?", (collection_id,), 0)
        if known_version > version:
            # The requester has seen a newer membership state than this device has.
            raise PermissionDenied("this device's membership records are out of date", code="stale_authority")

    def shared_with(self, account_id: str | None) -> list[dict]:
        if not account_id:
            return []
        out = []
        for r in self.db.query(
                "SELECT c.*, m.permissions AS mperms, m.status AS mstatus FROM collections c JOIN collection_members m "
                "ON m.collection_id=c.collection_id WHERE m.account_id=? AND m.status IN ('invited','active') "
                "AND c.deleted=0 AND c.is_owner=1 AND c.kind='shared' AND c.access_state!='suspended'", (account_id,)):
            out.append({"collection_id": r["collection_id"], "name": r["name"], "description": r["description"],
                        "owner_account": r["owner_account"], "owner_name": r["owner_name"],
                        "permissions": json.loads(r["mperms"]), "status": r["mstatus"],
                        "permission_version": r["permission_version"],
                        "item_count": len(self.item_ids(r["collection_id"]))})
        return out

    def authorise_file(self, account_id: str | None, collection_id: str, file_hash: str, known_version: int = 0) -> dict:
        """Return the file row if (and only if) the account may download it
        through this collection.  Every failure looks identical to the caller."""
        row = self.db.one("SELECT * FROM collections WHERE collection_id=? AND deleted=0", (collection_id,)) \
            if is_safe_id(collection_id) else None
        if row is None:
            raise PermissionDenied()
        if row["is_owner"]:
            self.require(collection_id, account_id, Permission.DOWNLOAD, known_version)
            states = ("active",)
        else:
            # Replica: only the owner may fetch files this device proposed to the collection.
            if account_id != row["owner_account"]:
                raise PermissionDenied()
            states = ("proposed", "active")
        marks = ",".join("?" * len(states))
        file = self.db.one(
            f"SELECT f.* FROM files f JOIN collection_items ci ON ci.edition_id=f.edition_id "
            f"JOIN editions e ON e.edition_id=f.edition_id WHERE ci.collection_id=? AND ci.state IN ({marks}) "
            f"AND f.content_hash=? AND f.available=1 AND e.deleted=0"
            + ("" if row["is_owner"] else " AND ci.added_by=?"),
            (collection_id, *states, file_hash) + (() if row["is_owner"] else (self.identity.account_id,)))
        if file is None:
            raise PermissionDenied()
        return dict(file)

    def payload_for(self, collection_id: str, account_id: str | None, known_version: int = 0) -> dict:
        """The view of a collection a given member is entitled to."""
        self.require(collection_id, account_id, Permission.VIEW_METADATA, known_version)
        perms = self.permissions_of(collection_id, account_id)
        row = self._row(collection_id)
        can_download = Permission.DOWNLOAD.value in perms
        items = []
        for eid in self.item_ids(collection_id):
            ed = self.catalogue.edition_row(eid)
            meta = self.catalogue.effective_metadata(eid).model_dump(include=set(SHARED_METADATA_FIELDS))
            item: dict[str, Any] = {
                "edition_id": eid, "work_id": ed["work_id"], "edition_number": ed["edition_number"],
                "label": ed["label"], "relation": ed["relation"], "previous_edition_id": ed["previous_edition_id"],
                "metadata": meta, "files": [],
            }
            for f in self.catalogue.files(eid):
                if f["role"] == "cover" or not f["available"]:
                    continue
                entry = {"role": f["role"], "format": f["format"], "media_type": f["media_type"],
                         "filename": f["filename"], "size": f["size"]}
                if can_download:
                    entry["file_hash"] = f["content_hash"]     # content identifiers stay behind authorisation
                item["files"].append(entry)
            items.append(item)
        payload: dict[str, Any] = {
            "collection_id": collection_id, "name": row["name"], "description": row["description"],
            "owner_account": row["owner_account"], "owner_name": row["owner_name"],
            "permission_version": row["permission_version"], "your_permissions": sorted(perms),
            "updated_at": row["updated_at"], "items": items, "members": [], "annotations": [],
        }
        if Permission.MANAGE_MEMBERS.value in perms:
            payload["members"] = [{"account_id": m["account_id"], "display_name": m["display_name"],
                                   "permissions": m["permissions"], "status": m["status"]}
                                  for m in self.members(collection_id)]
        for r in self.db.query("SELECT annotation_id, edition_id, content_hash, kind, locator, body, colour, "
                               "author_account, author_name, updated_at FROM annotations WHERE shared_in=? AND deleted=0",
                               (collection_id,)):
            a = dict(r)
            a["locator"] = json.loads(a["locator"])
            a["author_account"] = a["author_account"] or self.identity.account_id
            a["author_name"] = a["author_name"] or row["owner_name"]
            if not can_download:
                a["content_hash"] = ""
            payload["annotations"].append(a)
        return payload

    # ============================================================= replicas
    def store_offer(self, owner_device: str, offer: dict) -> None:
        """Member side: remember an invitation we have not answered yet."""
        cid = offer["collection_id"]
        if not is_safe_id(cid):
            raise InvalidInput("bad collection id")
        existing = self.db.one("SELECT is_owner, access_state FROM collections WHERE collection_id=?", (cid,))
        if existing and existing["is_owner"]:
            return
        ts = now_iso()
        state = "active" if offer.get("status") == "active" else "invited"
        self.db.execute(
            "INSERT INTO collections (collection_id, name, description, kind, owner_account, is_owner, owner_device, "
            "owner_name, permission_version, my_permissions, access_state, access_checked_at, created_at, updated_at) "
            "VALUES (?,?,?,'shared',?,0,?,?,?,?,?,?,?,?) ON CONFLICT(collection_id) DO UPDATE SET name=excluded.name, "
            "description=excluded.description, owner_device=excluded.owner_device, owner_name=excluded.owner_name, "
            "permission_version=excluded.permission_version, my_permissions=excluded.my_permissions, "
            "access_state=excluded.access_state, access_checked_at=excluded.access_checked_at, deleted=0, "
            "updated_at=excluded.updated_at",
            (cid, clean_text(offer.get("name"), 120) or "Shared collection",
             clean_text(offer.get("description"), 2000, single_line=False), clean_text(offer.get("owner_account"), 64),
             owner_device, clean_text(offer.get("owner_name"), 80), int(offer.get("permission_version") or 0),
             json.dumps(normalise_permissions(offer.get("permissions") or [])), state, ts, ts,
             clean_text(offer.get("updated_at"), 40) or ts))       # the owner's revision marker, used as edit base

    def store_replica(self, owner_device: str, payload: dict) -> dict:
        """Member side: record what the owner says the collection contains.
        All of it is untrusted input and is cleaned on the way in."""
        cid = payload["collection_id"]
        self.store_offer(owner_device, {**payload, "permissions": payload.get("your_permissions"), "status": "active"})
        seen: set[str] = set()
        with self.db.deferred():
            for item in (payload.get("items") or [])[:5000]:
                eid, wid = item.get("edition_id"), item.get("work_id")
                if not (is_safe_id(eid) and is_safe_id(wid)):
                    continue
                files = [f for f in item.get("files") or [] if isinstance(f, dict)]
                primary = next((f for f in files if f.get("role") == "primary"), None)
                if primary is None:
                    continue
                existing = self.db.one("SELECT e.edition_id, w.origin, w.origin_ref FROM editions e JOIN works w "
                                       "ON w.work_id=e.work_id WHERE e.edition_id=?", (eid,))
                meta = Metadata.model_validate(item.get("metadata") or {})
                if existing is None:
                    work = self.db.one("SELECT origin, origin_ref FROM works WHERE work_id=?", (wid,))
                    if work is not None and (work["origin"], work["origin_ref"]) != ("shared", cid):
                        wid = None       # never graft remote editions onto one of our own works
                    from ..readers.detect import media_type as _mt
                    from ..domain.models import FORMATS

                    fmt = primary.get("format") if primary.get("format") in FORMATS else "bin"
                    self.catalogue.register_edition(
                        content_hash=primary.get("file_hash") or "", size=int(primary.get("size") or 0),
                        filename=primary.get("filename") or "file", fmt=fmt, metadata=meta, metadata_source="remote",
                        work_id=wid, edition_id=eid, label=item.get("label") or "", relation=item.get("relation") or "",
                        origin="shared", origin_ref=cid, available=False,
                        edition_number=int(item.get("edition_number") or 1), import_source=f"collection:{cid}")
                elif (existing["origin"], existing["origin_ref"]) == ("shared", cid):
                    with self.db.tx() as c:
                        c.execute("INSERT INTO edition_metadata (edition_id, source, data, updated_at) VALUES (?,?,?,?) "
                                  "ON CONFLICT(edition_id, source) DO UPDATE SET data=excluded.data, "
                                  "updated_at=excluded.updated_at", (eid, "remote", meta.model_dump_json(), now_iso()))
                        if primary.get("file_hash"):
                            c.execute("UPDATE files SET content_hash=?, size=? WHERE edition_id=? AND role='primary' "
                                      "AND available=0", (primary["file_hash"], int(primary.get("size") or 0), eid))
                        c.execute("UPDATE editions SET deleted=0 WHERE edition_id=?", (eid,))
                        self.catalogue.reindex(eid)
                else:
                    mine = self.db.one("SELECT 1 FROM collection_items WHERE collection_id=? AND edition_id=? "
                                       "AND added_by=?", (cid, eid, self.identity.account_id))
                    if not mine:
                        continue         # identifier clash with a local edition: ignore the remote entry
                seen.add(eid)
                self.db.execute("INSERT INTO collection_items (collection_id, edition_id, added_by, added_at, state) "
                                "VALUES (?,?,?,?, 'active') ON CONFLICT(collection_id, edition_id) DO UPDATE SET "
                                "state='active'", (cid, eid, clean_text(item.get("added_by"), 64), now_iso()))
            # items that disappeared from the collection
            for r in self.db.query("SELECT edition_id FROM collection_items WHERE collection_id=? AND state='active'", (cid,)):
                if r["edition_id"] not in seen:
                    self.db.execute("UPDATE collection_items SET state='removed' WHERE collection_id=? AND edition_id=?",
                                    (cid, r["edition_id"]))
                    self.db.execute("UPDATE editions SET deleted=1 WHERE edition_id=? AND NOT EXISTS (SELECT 1 FROM files "
                                    "WHERE files.edition_id=editions.edition_id AND available=1)", (r["edition_id"],))
            # shared annotations from other members
            keep: set[str] = set()
            for a in (payload.get("annotations") or [])[:5000]:
                if not is_safe_id(a.get("annotation_id")) or a.get("author_account") == self.identity.account_id:
                    continue
                if a.get("edition_id") not in seen or a.get("kind") not in ("bookmark", "highlight", "note"):
                    continue
                keep.add(a["annotation_id"])
                ts = now_iso()
                self.db.execute(
                    "INSERT INTO annotations (annotation_id, edition_id, content_hash, kind, locator, body, colour, "
                    "shared_in, author_account, author_name, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(annotation_id) DO UPDATE SET locator=excluded.locator, body=excluded.body, "
                    "updated_at=excluded.updated_at, deleted=0 WHERE annotations.author_account != ''",
                    (a["annotation_id"], a["edition_id"], clean_text(a.get("content_hash"), 64), a["kind"],
                     json.dumps(a.get("locator") if isinstance(a.get("locator"), dict) else {})[:4000],
                     clean_text(a.get("body"), 20000, single_line=False), clean_text(a.get("colour"), 20) or "copper",
                     cid, clean_text(a.get("author_account"), 64) or "unknown", clean_text(a.get("author_name"), 80), ts, ts))
            for r in self.db.query("SELECT annotation_id FROM annotations WHERE shared_in=? AND author_account != ''", (cid,)):
                if r["annotation_id"] not in keep:
                    self.db.execute("UPDATE annotations SET deleted=1 WHERE annotation_id=?", (r["annotation_id"],))
        return self.get(cid)

    def mark_replica_state(self, collection_id: str, state: str) -> None:
        self.db.execute("UPDATE collections SET access_state=?, access_checked_at=? WHERE collection_id=? AND is_owner=0",
                        (state, now_iso(), collection_id))
        if state == "revoked":
            self.activity.log("collection.access_revoked",
                              "The owner reports that your access to a shared collection has ended. Works you already "
                              "downloaded remain in your library; nothing further can be downloaded.",
                              collection_id=collection_id)

    def leave(self, collection_id: str) -> None:
        row = self._row(collection_id)
        if row["is_owner"]:
            raise StateError("Owners delete a collection rather than leaving it.")
        self.db.execute("UPDATE collections SET deleted=1, access_state='revoked' WHERE collection_id=?", (collection_id,))
