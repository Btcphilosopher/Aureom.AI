"""At-rest protection primitives.

Nothing here is novel cryptography.  The module composes primitives from the
``cryptography`` package in standard ways:

* scrypt turns a passphrase into a key-encryption key (KEK);
* the KEK wraps a random 256-bit library master key with ChaCha20-Poly1305;
* HKDF-SHA256 derives independent sub-keys for each purpose;
* large payloads use the STREAM construction (Hoang, Reyhanitabar, Rogaway,
  Vizár 2015) — the same chunked-AEAD layout used by age and Tink: a fresh
  per-file key, a counter nonce and a last-chunk flag, which gives
  authenticated random access and detects truncation and reordering.
"""
from __future__ import annotations

import hmac
import json
import os
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Iterator

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from ..domain.errors import IntegrityFailure, InvalidInput, StateError
from ..domain.util import b64d, b64e

MAGIC = b"AUREOMS1"
HEADER = struct.Struct(">8s16sI")   # magic, salt, chunk size
TAG = 16
STREAM_CHUNK = 64 * 1024

# scrypt cost: 2**16 * 8 * 128 bytes = 64 MiB of memory per derivation.
DEFAULT_KDF = {"name": "scrypt", "n": 2 ** 16, "r": 8, "p": 1}


def derive_passphrase_key(passphrase: str, salt: bytes, params: dict) -> bytes:
    if params.get("name") != "scrypt":
        raise InvalidInput("unsupported key-derivation function")
    if not passphrase:
        raise InvalidInput("a passphrase is required")
    kdf = Scrypt(salt=salt, length=32, n=int(params["n"]), r=int(params["r"]), p=int(params["p"]))
    return kdf.derive(passphrase.encode("utf-8"))


def subkey(master: bytes, label: str, salt: bytes | None = None) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=b"aureom:" + label.encode()).derive(master)


def keyed_name(key: bytes, value: str) -> str:
    return hmac.new(key, value.encode(), "sha256").hexdigest()


def seal(key: bytes, plaintext: bytes, aad: bytes = b"") -> bytes:
    nonce = os.urandom(12)
    return nonce + ChaCha20Poly1305(key).encrypt(nonce, plaintext, aad)


def unseal(key: bytes, blob: bytes, aad: bytes = b"") -> bytes:
    try:
        return ChaCha20Poly1305(key).decrypt(blob[:12], blob[12:], aad)
    except InvalidTag as exc:
        raise IntegrityFailure("authentication failed") from exc


# --------------------------------------------------------------------- vault
@dataclass
class Vault:
    """The wrapped library master key, stored as ``vault.json``."""

    path: Path

    def exists(self) -> bool:
        return self.path.exists()

    def create(self, passphrase: str, kdf: dict | None = None) -> bytes:
        if self.exists():
            raise StateError("vault already exists")
        if len(passphrase) < 8:
            raise InvalidInput("the passphrase must be at least 8 characters")
        master = os.urandom(32)
        self._write(master, passphrase, kdf or DEFAULT_KDF)
        return master

    def _write(self, master: bytes, passphrase: str, kdf: dict) -> None:
        salt = os.urandom(16)
        kek = derive_passphrase_key(passphrase, salt, kdf)
        doc = {"version": 1, "kdf": kdf, "salt": b64e(salt),
               "wrapped_key": b64e(seal(kek, master, b"aureom-vault-v1"))}
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(doc, indent=2))
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    def unlock(self, passphrase: str) -> bytes:
        doc = json.loads(self.path.read_text())
        kek = derive_passphrase_key(passphrase, b64d(doc["salt"]), doc["kdf"])
        try:
            return unseal(kek, b64d(doc["wrapped_key"]), b"aureom-vault-v1")
        except IntegrityFailure:
            raise InvalidInput("incorrect passphrase", code="bad_passphrase") from None

    def change_passphrase(self, old: str, new: str) -> None:
        doc = json.loads(self.path.read_text())
        master = self.unlock(old)
        if len(new) < 8:
            raise InvalidInput("the passphrase must be at least 8 characters")
        self._write(master, new, doc["kdf"])


# -------------------------------------------------------------------- stream
def _nonce(index: int, final: bool) -> bytes:
    return index.to_bytes(11, "big") + (b"\x01" if final else b"\x00")


class StreamEncryptor:
    """Write-once encrypting sink.  Call :meth:`write` then :meth:`close`."""

    def __init__(self, key: bytes, sink: BinaryIO, chunk_size: int = STREAM_CHUNK):
        salt = os.urandom(16)
        self._header = HEADER.pack(MAGIC, salt, chunk_size)
        self._aead = ChaCha20Poly1305(subkey(key, "stream-v1", salt))
        self._sink = sink
        self._cs = chunk_size
        self._buf = bytearray()
        self._index = 0
        self._closed = False
        sink.write(self._header)

    def write(self, data: bytes) -> int:
        self._buf += data
        # keep at least one byte buffered so the final chunk can be flagged
        while len(self._buf) > self._cs:
            chunk = bytes(self._buf[: self._cs])
            del self._buf[: self._cs]
            self._sink.write(self._aead.encrypt(_nonce(self._index, False), chunk, self._header))
            self._index += 1
        return len(data)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._sink.write(self._aead.encrypt(_nonce(self._index, True), bytes(self._buf), self._header))
        self._buf.clear()


class StreamDecryptor:
    """Random-access authenticated reader over an encrypted stream."""

    def __init__(self, key: bytes, source: BinaryIO, total_len: int):
        self._src = source
        header = source.read(HEADER.size)
        if len(header) != HEADER.size:
            raise IntegrityFailure("truncated encrypted object")
        magic, salt, cs = HEADER.unpack(header)
        if magic != MAGIC or not (1024 <= cs <= 16 * 1024 * 1024):
            raise IntegrityFailure("not an Aureom encrypted object")
        self._header = header
        self._cs = cs
        self._aead = ChaCha20Poly1305(subkey(key, "stream-v1", salt))
        body = total_len - HEADER.size
        if body < TAG:
            raise IntegrityFailure("truncated encrypted object")
        self._chunks = max(1, -(-body // (cs + TAG)))
        self.size = body - TAG * self._chunks
        if self.size < 0:
            raise IntegrityFailure("truncated encrypted object")

    def _chunk(self, index: int) -> bytes:
        if index < 0 or index >= self._chunks:
            return b""
        self._src.seek(HEADER.size + index * (self._cs + TAG))
        blob = self._src.read(self._cs + TAG)
        try:
            return self._aead.decrypt(_nonce(index, index == self._chunks - 1), blob, self._header)
        except InvalidTag as exc:
            raise IntegrityFailure("encrypted object failed authentication") from exc

    def read_range(self, offset: int, length: int) -> bytes:
        if offset < 0 or length < 0:
            raise InvalidInput("bad range")
        end = min(self.size, offset + length)
        out = bytearray()
        pos = offset
        while pos < end:
            index, inner = divmod(pos, self._cs)
            chunk = self._chunk(index)
            piece = chunk[inner : inner + (end - pos)]
            if not piece:
                break
            out += piece
            pos += len(piece)
        return bytes(out)

    def iter_plaintext(self) -> Iterator[bytes]:
        for index in range(self._chunks):
            yield self._chunk(index)


def encrypt_bytes(key: bytes, data: bytes) -> bytes:
    import io

    sink = io.BytesIO()
    enc = StreamEncryptor(key, sink)
    enc.write(data)
    enc.close()
    return sink.getvalue()


def decrypt_bytes(key: bytes, blob: bytes) -> bytes:
    import io

    dec = StreamDecryptor(key, io.BytesIO(blob), len(blob))
    return b"".join(dec.iter_plaintext())
