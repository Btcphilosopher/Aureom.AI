"""Encrypted backup export and restoration.

A backup is a tar stream (catalogue snapshot, managed objects, and —
optionally — identity keys) encrypted with a key derived from a *backup*
passphrase, independent of the library passphrase.  Referenced (unmanaged)
files are not included; the manifest lists them so the user knows.
"""
from __future__ import annotations

import io
import json
import os
import struct
import tarfile
from pathlib import Path
from typing import BinaryIO

from ..domain.errors import IntegrityFailure, InvalidInput, LimitExceeded
from ..domain.util import is_sha256_hex, now_iso
from .crypto import DEFAULT_KDF, StreamDecryptor, StreamEncryptor, derive_passphrase_key

BACKUP_MAGIC = b"AUREOMBK1\n"


class _Writer(io.RawIOBase):
    def __init__(self, enc: StreamEncryptor):
        self._enc = enc

    def writable(self) -> bool:
        return True

    def write(self, data) -> int:  # type: ignore[override]
        return self._enc.write(bytes(data))


class _Reader(io.RawIOBase):
    def __init__(self, dec: StreamDecryptor):
        self._it = dec.iter_plaintext()
        self._buf = b""

    def readable(self) -> bool:
        return True

    def readinto(self, target) -> int:  # type: ignore[override]
        while not self._buf:
            try:
                self._buf = next(self._it)
            except StopIteration:
                return 0
        n = min(len(target), len(self._buf))
        target[:n] = self._buf[:n]
        self._buf = self._buf[n:]
        return n


def _add_bytes(tar: tarfile.TarFile, name: str, data: bytes) -> None:
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o600
    tar.addfile(info, io.BytesIO(data))


def export_backup(dest: Path, passphrase: str, *, db_snapshot: bytes, store, object_hashes: list[str],
                  secrets: dict[str, bytes] | None, profile_info: dict, referenced: list[str],
                  kdf: dict | None = None) -> dict:
    if len(passphrase) < 8:
        raise InvalidInput("the backup passphrase must be at least 8 characters")
    kdf = kdf or DEFAULT_KDF
    salt = os.urandom(16)
    key = derive_passphrase_key(passphrase, salt, kdf)
    header = json.dumps({"version": 1, "kdf": kdf, "salt": salt.hex()}).encode()
    manifest = {
        "format": "aureom-commons-backup", "version": 1, "created_at": now_iso(),
        "profile": profile_info, "objects": len(object_hashes),
        "includes_identity_keys": secrets is not None,
        "referenced_files_not_included": referenced,
    }
    tmp = dest.with_name(dest.name + ".part")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as out:
        out.write(BACKUP_MAGIC + struct.pack(">I", len(header)) + header)
        enc = StreamEncryptor(key, out)
        buffered = io.BufferedWriter(_Writer(enc), 1024 * 1024)
        with tarfile.open(fileobj=buffered, mode="w|") as tar:
            _add_bytes(tar, "manifest.json", json.dumps(manifest, indent=2).encode())
            _add_bytes(tar, "catalogue.sqlite", db_snapshot)
            if secrets is not None:
                _add_bytes(tar, "secrets.json", json.dumps({k: v.hex() for k, v in secrets.items()}).encode())
            for content_hash in object_hashes:
                with store.open(content_hash) as reader:
                    info = tarfile.TarInfo(f"objects/{content_hash}")
                    info.size = reader.size
                    info.mode = 0o600
                    tar.addfile(info, io.BufferedReader(_BlockReader(reader), 1024 * 1024))
        buffered.flush()            # tarfile does not flush the stream it was given
        buffered.detach()
        enc.close()
        out.flush()
        os.fsync(out.fileno())
    os.replace(tmp, dest)
    return manifest


class _BlockReader(io.RawIOBase):
    def __init__(self, reader):
        self._it = reader.iter_blocks()
        self._buf = b""

    def readable(self) -> bool:
        return True

    def readinto(self, target) -> int:  # type: ignore[override]
        while not self._buf:
            try:
                self._buf = next(self._it)
            except StopIteration:
                return 0
        n = min(len(target), len(self._buf))
        target[:n] = self._buf[:n]
        self._buf = self._buf[n:]
        return n


def _open_backup(src: BinaryIO, total: int, passphrase: str) -> tarfile.TarFile:
    magic = src.read(len(BACKUP_MAGIC))
    if magic != BACKUP_MAGIC:
        raise InvalidInput("this file is not an Aureom Commons backup")
    (hlen,) = struct.unpack(">I", src.read(4))
    if hlen > 4096:
        raise InvalidInput("corrupt backup header")
    header = json.loads(src.read(hlen))
    key = derive_passphrase_key(passphrase, bytes.fromhex(header["salt"]), header["kdf"])
    offset = len(BACKUP_MAGIC) + 4 + hlen
    body = _Slice(src, offset)
    try:
        dec = StreamDecryptor(key, body, total - offset)
        first = dec.read_range(0, 1)  # authenticates the first chunk => passphrase check
        del first
    except IntegrityFailure:
        raise InvalidInput("incorrect backup passphrase or damaged backup", code="bad_passphrase") from None
    return tarfile.open(fileobj=io.BufferedReader(_Reader(dec), 1024 * 1024), mode="r|")


class _Slice:
    """Presents ``fh`` from ``offset`` onward as a file starting at zero."""

    def __init__(self, fh: BinaryIO, offset: int):
        self._fh, self._off = fh, offset
        fh.seek(offset)

    def read(self, n: int = -1) -> bytes:
        return self._fh.read(n)

    def seek(self, pos: int, whence: int = 0) -> int:
        return self._fh.seek(pos + self._off, whence) - self._off


def restore_backup(src_path: Path, passphrase: str, *, on_catalogue, on_secrets, on_object,
                   max_object_bytes: int) -> dict:
    """Stream a backup back in.  Callbacks receive validated members only;
    member names are checked against a strict allow-list, so a crafted
    archive cannot write outside the new profile."""
    manifest: dict = {}
    total = os.path.getsize(src_path)
    with open(src_path, "rb") as src:
        tar = _open_backup(src, total, passphrase)
        try:
            for member in tar:
                if not member.isfile():
                    raise IntegrityFailure("unexpected entry type in backup")
                fh = tar.extractfile(member)
                assert fh is not None
                name = member.name
                if name == "manifest.json":
                    manifest = json.loads(fh.read(1024 * 1024))
                elif name == "catalogue.sqlite":
                    on_catalogue(fh.read())
                elif name == "secrets.json":
                    on_secrets({k: bytes.fromhex(v) for k, v in json.loads(fh.read(4 * 1024 * 1024)).items()})
                elif name.startswith("objects/") and is_sha256_hex(name[8:]):
                    if member.size > max_object_bytes:
                        raise LimitExceeded("backup object exceeds the document size limit")
                    on_object(name[8:], fh)
                else:
                    raise IntegrityFailure("unexpected entry name in backup")
        except IntegrityFailure:
            raise
        except tarfile.TarError as exc:
            raise IntegrityFailure("backup archive is damaged") from exc
    return manifest
