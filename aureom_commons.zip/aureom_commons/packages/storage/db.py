"""SQLite catalogue database.

Two persistence modes share one interface:

* **plain** — an ordinary SQLite file in WAL mode;
* **encrypted** — the database lives only in process memory while the
  library is unlocked.  Every committed transaction is serialised,
  encrypted with the library key (chunked AEAD) and atomically written to
  ``catalogue.db.enc``.  No plaintext database, journal or FTS index is ever
  written to disk in this mode, which is what lets the application honestly
  describe the *search index* as protected when the library is locked.

A single connection guarded by a re-entrant lock is shared by the GUI thread,
the asyncio networking thread and the local API.
"""
from __future__ import annotations

import os
import sqlite3
import threading
from contextlib import contextmanager
from importlib import resources
from pathlib import Path
from typing import Any, Iterable, Iterator

from ..domain.errors import IntegrityFailure, LibraryLocked
from .crypto import decrypt_bytes, encrypt_bytes


def _migration_files() -> list[tuple[str, str]]:
    root = resources.files("aureom.migrations")
    items = [(p.name, p.read_text(encoding="utf-8")) for p in root.iterdir() if p.name.endswith(".sql")]
    return sorted(items)


class Database:
    def __init__(self, path: Path, key: bytes | None = None):
        self.path = Path(path)
        self.key = key
        self.encrypted = key is not None
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.RLock()
        self._defer = 0
        self._dirty = False

    # ------------------------------------------------------------ lifecycle
    @property
    def enc_path(self) -> Path:
        return self.path.with_name(self.path.name + ".enc")

    def open(self) -> "Database":
        with self._lock:
            if self.encrypted:
                conn = sqlite3.connect(":memory:", check_same_thread=False, isolation_level=None)
                if self.enc_path.exists():
                    try:
                        conn.deserialize(decrypt_bytes(self.key, self.enc_path.read_bytes()))
                    except IntegrityFailure:
                        conn.close()
                        raise
            else:
                conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys=ON")
            self._conn = conn
            self.migrate()
            return self

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                self.flush(force=True)
                self._conn.close()
                self._conn = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise LibraryLocked("the library is locked")
        return self._conn

    def migrate(self) -> None:
        with self.tx() as c:
            c.execute("CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)")
        applied = {r["name"] for r in self.query("SELECT name FROM schema_migrations")}
        for name, sql in _migration_files():
            if name in applied:
                continue
            with self._lock:
                self.conn.executescript("BEGIN;\n" + sql + "\nCOMMIT;")
                self.conn.execute(
                    "INSERT INTO schema_migrations (name, applied_at) VALUES (?, datetime('now'))", (name,))
                self._dirty = True
        self.flush()

    # ------------------------------------------------------------- queries
    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        """A write transaction.  Nested use joins the outer transaction."""
        with self._lock:
            conn = self.conn
            outer = conn.in_transaction
            if not outer:
                conn.execute("BEGIN IMMEDIATE")
            try:
                yield conn
            except BaseException:
                if not outer:
                    conn.execute("ROLLBACK")
                raise
            else:
                if not outer:
                    conn.execute("COMMIT")
                    self._dirty = True
                    if not self._defer:
                        self.flush()

    def execute(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self.tx() as c:
            return c.execute(sql, tuple(params))

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self.conn.execute(sql, tuple(params)).fetchall()

    def one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        with self._lock:
            return self.conn.execute(sql, tuple(params)).fetchone()

    def scalar(self, sql: str, params: Iterable[Any] = (), default: Any = None) -> Any:
        row = self.one(sql, params)
        return default if row is None else row[0]

    # ---------------------------------------------------------- persistence
    @contextmanager
    def deferred(self) -> Iterator[None]:
        """Batch several commits into one encrypted snapshot."""
        with self._lock:
            self._defer += 1
        try:
            yield
        finally:
            with self._lock:
                self._defer -= 1
                if not self._defer:
                    self.flush()

    def flush(self, force: bool = False) -> None:
        with self._lock:
            if not self.encrypted or self._conn is None or not (self._dirty or force):
                return
            blob = encrypt_bytes(self.key, self._conn.serialize())
            tmp = self.enc_path.with_suffix(".tmp")
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as fh:
                fh.write(blob)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.enc_path)
            self._dirty = False

    def snapshot_bytes(self) -> bytes:
        """A consistent plaintext copy of the database (for backups)."""
        with self._lock:
            if self.encrypted:
                return self.conn.serialize()
            dest = sqlite3.connect(":memory:")
            self.conn.backup(dest)
            data = bytearray(dest.serialize())
            dest.close()
            # The file is in WAL mode; a snapshot must be a self-contained
            # rollback-journal database (header bytes 18/19: 2 = WAL, 1 = legacy).
            data[18] = data[19] = 1
            return bytes(data)
