"""Per-profile settings and the activity journal (both live in the catalogue
database, so they are protected whenever the library is encrypted)."""
from __future__ import annotations

import json
import logging
import threading
from typing import Any, Callable

from ..domain.limits import Limits
from ..domain.util import now_iso
from .db import Database

log = logging.getLogger("aureom")

DEFAULTS: dict[str, Any] = {
    "device_name": "My device",
    "account_name": "",
    "listen_host": "127.0.0.1",        # first release: explicit addresses; loopback unless the user changes it
    "listen_port": 0,
    "advertise_addresses": [],
    "network_enabled": True,
    "lan_discovery": False,            # opt-in
    "lan_announce_name": False,
    "rendezvous_url": "",              # opt-in
    "rendezvous_announce": False,      # opt-in public catalogue announcements
    "relay_address": "",               # opt-in "host:port"
    "serve_public_catalogue": True,
    "accept_proposals": "ask",         # ask | never
    "index_default": "full",           # full | metadata | none
    "import_mode": "managed",          # managed | referenced
    "theme": "light",
    "text_scale": 100,
    "auto_refresh_seconds": 0,
    "limits": {},
}


class Settings:
    def __init__(self, db: Database):
        self.db = db

    def get(self, key: str, default: Any = None) -> Any:
        row = self.db.one("SELECT value FROM settings WHERE key=?", (key,))
        if row is None:
            return DEFAULTS.get(key, default) if default is None else default
        return json.loads(row["value"])

    def set(self, key: str, value: Any) -> None:
        self.db.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, json.dumps(value)))

    def all(self) -> dict[str, Any]:
        data = dict(DEFAULTS)
        for row in self.db.query("SELECT key, value FROM settings"):
            if not row["key"].startswith("_"):
                data[row["key"]] = json.loads(row["value"])
        return data

    @property
    def limits(self) -> Limits:
        return Limits.model_validate(self.get("limits") or {})

    def set_limits(self, **changes: Any) -> Limits:
        current = self.get("limits") or {}
        current.update(changes)
        limits = Limits.model_validate(current)       # validates before saving
        self.set("limits", current)
        return limits


class EventBus:
    """Tiny thread-safe publish/subscribe used to refresh the interface."""

    def __init__(self) -> None:
        self._subs: list[Callable[[str, dict], None]] = []
        self._lock = threading.Lock()

    def subscribe(self, fn: Callable[[str, dict], None]) -> None:
        with self._lock:
            self._subs.append(fn)

    def emit(self, topic: str, **data: Any) -> None:
        with self._lock:
            subs = list(self._subs)
        for fn in subs:
            try:
                fn(topic, data)
            except Exception:       # a broken listener must not break the service
                log.exception("event listener failed")


class Activity:
    """User-visible journal.  Stored in the database (protected with it).

    The separate Python log (stderr/file) only ever receives the ``kind`` and
    redacted identifiers — never titles, document text, tokens or keys."""

    def __init__(self, db: Database, events: EventBus):
        self.db = db
        self.events = events

    def log(self, kind: str, summary: str, *, peer: str = "", **detail: Any) -> None:
        try:
            self.db.execute("INSERT INTO activity (ts, kind, summary, detail, peer) VALUES (?,?,?,?,?)",
                            (now_iso(), kind, summary[:500], json.dumps(detail, default=str)[:4000], peer))
        except Exception:
            log.warning("activity journal unavailable for %s", kind)
        log.info("activity kind=%s peer=%s", kind, (peer[:6] + "…") if peer else "-")
        self.events.emit("activity", kind=kind)

    def recent(self, limit: int = 200, kind_prefix: str = "") -> list[dict]:
        rows = self.db.query("SELECT * FROM activity WHERE kind LIKE ? ORDER BY id DESC LIMIT ?",
                             (kind_prefix + "%", limit))
        return [dict(r) | {"detail": json.loads(r["detail"])} for r in rows]
