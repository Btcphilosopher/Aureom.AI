"""Where private keys and tokens are kept.

Order of preference:

1. **Encrypted library** — secrets live in the (encrypted) catalogue
   database and are therefore protected by the library passphrase.
2. **OS credential store** via ``keyring`` (Keychain, Credential Manager,
   Secret Service) when a real backend is available.
3. **Owner-only file** (mode 0600) as a last resort.  The interface says so
   plainly; this protects against other OS users, not against someone with
   access to the account or the disk.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from ..domain.util import b64d, b64e
from .db import Database


class SecretStore:
    backend = "none"
    description = ""

    def get(self, name: str) -> bytes | None:  # pragma: no cover - interface
        raise NotImplementedError

    def set(self, name: str, value: bytes) -> None:  # pragma: no cover - interface
        raise NotImplementedError

    def delete(self, name: str) -> None:  # pragma: no cover - interface
        raise NotImplementedError


class DatabaseSecretStore(SecretStore):
    backend = "encrypted-library"
    description = "Stored inside the encrypted library, protected by your passphrase."

    def __init__(self, db: Database):
        self.db = db

    def get(self, name: str) -> bytes | None:
        row = self.db.one("SELECT value FROM secrets WHERE name=?", (name,))
        return bytes(row["value"]) if row else None

    def set(self, name: str, value: bytes) -> None:
        self.db.execute("INSERT INTO secrets (name, value) VALUES (?, ?) "
                        "ON CONFLICT(name) DO UPDATE SET value=excluded.value", (name, value))

    def delete(self, name: str) -> None:
        self.db.execute("DELETE FROM secrets WHERE name=?", (name,))


class KeyringSecretStore(SecretStore):
    backend = "os-keyring"

    def __init__(self, service: str, keyring_module):
        self.service = service
        self._kr = keyring_module
        self.description = f"Stored in the operating system credential store ({type(keyring_module.get_keyring()).__name__})."

    def get(self, name: str) -> bytes | None:
        value = self._kr.get_password(self.service, name)
        return b64d(value) if value else None

    def set(self, name: str, value: bytes) -> None:
        self._kr.set_password(self.service, name, b64e(value))

    def delete(self, name: str) -> None:
        try:
            self._kr.delete_password(self.service, name)
        except Exception:
            pass


class FileSecretStore(SecretStore):
    backend = "owner-only-file"
    description = ("No OS credential store is available, so keys are kept in a file readable only by your "
                   "OS account. Enable the encrypted library to protect them with a passphrase.")

    def __init__(self, path: Path):
        self.path = path

    def _load(self) -> dict[str, str]:
        try:
            return json.loads(self.path.read_text())
        except FileNotFoundError:
            return {}

    def _save(self, data: dict[str, str]) -> None:
        tmp = self.path.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            json.dump(data, fh)
        os.replace(tmp, self.path)

    def get(self, name: str) -> bytes | None:
        value = self._load().get(name)
        return b64d(value) if value else None

    def set(self, name: str, value: bytes) -> None:
        data = self._load()
        data[name] = b64e(value)
        self._save(data)

    def delete(self, name: str) -> None:
        data = self._load()
        if data.pop(name, None) is not None:
            self._save(data)


def _usable_keyring():
    if os.environ.get("AUREOM_DISABLE_KEYRING"):
        return None
    try:
        import keyring
        from keyring.backends import fail

        backend = keyring.get_keyring()
        if isinstance(backend, fail.Keyring):
            return None
        name = type(backend).__module__
        if "null" in name or "chainer" in name and not getattr(backend, "backends", None):
            return None
        if getattr(backend, "priority", 1) <= 0:
            return None
        return keyring
    except Exception:
        return None


def open_secret_store(profile_dir: Path, profile_id: str, db: Database) -> SecretStore:
    if db.encrypted:
        return DatabaseSecretStore(db)
    kr = _usable_keyring()
    if kr is not None:
        try:
            store = KeyringSecretStore(f"aureom-commons:{profile_id}", kr)
            store.set("__probe__", b"1")
            store.delete("__probe__")
            return store
        except Exception:
            pass
    return FileSecretStore(profile_dir / "secrets.json")
