"""Content-addressed object store for managed files.

Objects are addressed by the SHA-256 of their plaintext.  In an encrypted
library the bytes on disk are a chunked-AEAD stream and the *file name* is a
keyed HMAC of the hash, so someone holding the disk cannot test whether a
known public file is present.

Writes always go to a temporary file inside the store and are promoted with
an atomic rename once the content hash has been verified.
"""
from __future__ import annotations

import hashlib
import os
import secrets
import shutil
from pathlib import Path
from typing import BinaryIO, Iterator

from ..domain.errors import IntegrityFailure, LimitExceeded, NotFound
from ..domain.util import is_sha256_hex, safe_filename
from .crypto import StreamDecryptor, StreamEncryptor, keyed_name, subkey

BLOCK = 1024 * 1024


def _private_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass
    return path


class ObjectReader:
    """Uniform random-access reader over plain and encrypted objects."""

    def __init__(self, fh: BinaryIO, size: int, decryptor: StreamDecryptor | None = None):
        self._fh = fh
        self._dec = decryptor
        self.size = decryptor.size if decryptor else size

    def read_range(self, offset: int, length: int) -> bytes:
        if self._dec:
            return self._dec.read_range(offset, length)
        self._fh.seek(offset)
        return self._fh.read(max(0, min(length, self.size - offset)))

    def iter_blocks(self, block: int = BLOCK) -> Iterator[bytes]:
        if self._dec:
            yield from self._dec.iter_plaintext()
            return
        self._fh.seek(0)
        while True:
            data = self._fh.read(block)
            if not data:
                return
            yield data

    def read_all(self) -> bytes:
        return b"".join(self.iter_blocks())

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> "ObjectReader":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


class ObjectStore:
    def __init__(self, root: Path, key: bytes | None = None, max_bytes: int | None = None):
        self.root = Path(root)
        self.encrypted = key is not None
        self._obj_key = subkey(key, "objects") if key else None
        self._name_key = subkey(key, "object-names") if key else None
        self.max_bytes = max_bytes
        self.objects = _private_dir(self.root / "objects")
        self.tmp = _private_dir(self.root / "tmp")
        self.views = _private_dir(self.tmp / "views")
        _private_dir(self.tmp / "ingest")

    # ------------------------------------------------------------- layout
    def _path(self, content_hash: str) -> Path:
        if not is_sha256_hex(content_hash):
            raise NotFound("object")
        name = keyed_name(self._name_key, content_hash) + ".enc" if self.encrypted else content_hash
        return self.objects / name[:2] / name

    def has(self, content_hash: str) -> bool:
        return is_sha256_hex(content_hash) and self._path(content_hash).exists()

    def size(self, content_hash: str) -> int:
        with self.open(content_hash) as reader:
            return reader.size

    def usage_bytes(self) -> int:
        total = 0
        for base, _dirs, files in os.walk(self.objects):
            for name in files:
                try:
                    total += os.path.getsize(os.path.join(base, name))
                except OSError:
                    pass
        return total

    def check_quota(self, incoming: int) -> None:
        if self.max_bytes is not None and self.usage_bytes() + incoming > self.max_bytes:
            raise LimitExceeded("the managed library's storage limit would be exceeded", code="storage_limit")
        free = shutil.disk_usage(self.root).free
        if incoming + 64 * 1024 * 1024 > free:
            raise LimitExceeded("not enough free disk space", code="disk_full")

    # -------------------------------------------------------------- reading
    def open(self, content_hash: str) -> ObjectReader:
        path = self._path(content_hash)
        try:
            fh = open(path, "rb")
        except FileNotFoundError:
            raise NotFound("object") from None
        total = os.fstat(fh.fileno()).st_size
        if self.encrypted:
            try:
                return ObjectReader(fh, 0, StreamDecryptor(self._obj_key, fh, total))
            except Exception:
                fh.close()
                raise
        return ObjectReader(fh, total)

    def read_all(self, content_hash: str) -> bytes:
        with self.open(content_hash) as reader:
            return reader.read_all()

    def verify(self, content_hash: str) -> bool:
        digest = hashlib.sha256()
        try:
            with self.open(content_hash) as reader:
                for block in reader.iter_blocks():
                    digest.update(block)
        except (NotFound, IntegrityFailure):
            return False
        return digest.hexdigest() == content_hash

    # -------------------------------------------------------------- writing
    def _new_tmp(self) -> Path:
        return self.tmp / "ingest" / (secrets.token_hex(12) + ".tmp")

    def ingest_blocks(self, blocks: Iterator[bytes], *, expected_hash: str | None = None,
                      max_bytes: int | None = None) -> tuple[str, int]:
        """Stream ``blocks`` into the store.  Returns ``(sha256, size)``.

        The object only becomes visible after the whole stream has been
        hashed (and, if ``expected_hash`` is given, verified)."""
        tmp = self._new_tmp()
        digest = hashlib.sha256()
        size = 0
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "wb") as fh:
                sink = StreamEncryptor(self._obj_key, fh) if self.encrypted else None
                for block in blocks:
                    size += len(block)
                    if max_bytes is not None and size > max_bytes:
                        raise LimitExceeded("file exceeds the configured document size limit", code="document_too_large")
                    digest.update(block)
                    (sink or fh).write(block)
                if sink:
                    sink.close()
                fh.flush()
                os.fsync(fh.fileno())
            content_hash = digest.hexdigest()
            if expected_hash is not None and content_hash != expected_hash:
                raise IntegrityFailure("content hash does not match the manifest")
            dest = self._path(content_hash)
            if dest.exists():
                os.unlink(tmp)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                os.replace(tmp, dest)       # atomic promotion
            return content_hash, size
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def ingest_file(self, src: Path, *, max_bytes: int | None = None, expected_hash: str | None = None) -> tuple[str, int]:
        def blocks() -> Iterator[bytes]:
            with open(src, "rb") as fh:
                while True:
                    data = fh.read(BLOCK)
                    if not data:
                        return
                    yield data

        return self.ingest_blocks(blocks(), max_bytes=max_bytes, expected_hash=expected_hash)

    def ingest_bytes(self, data: bytes) -> tuple[str, int]:
        return self.ingest_blocks(iter([data]))

    def delete(self, content_hash: str) -> None:
        try:
            os.unlink(self._path(content_hash))
        except (FileNotFoundError, NotFound):
            pass

    # ------------------------------------------------- export / temp views
    def export_to(self, content_hash: str, dest: Path) -> None:
        tmp = dest.with_name(dest.name + ".part")
        with self.open(content_hash) as reader, open(tmp, "wb") as out:
            for block in reader.iter_blocks():
                out.write(block)
        os.replace(tmp, dest)

    def materialise(self, content_hash: str, filename: str = "file") -> Path:
        """Return a filesystem path a viewer component can open.

        Plain store: the object itself.  Encrypted store: a decrypted copy in
        a private (0700) temporary directory, removed by :meth:`wipe_views`
        when the library locks or the application exits."""
        if not self.encrypted:
            path = self._path(content_hash)
            if not path.exists():
                raise NotFound("object")
            return path
        folder = _private_dir(self.views / secrets.token_hex(8))
        dest = folder / safe_filename(filename)
        fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with self.open(content_hash) as reader, os.fdopen(fd, "wb") as out:
            for block in reader.iter_blocks():
                out.write(block)
        return dest

    def discard_view(self, path: Path) -> None:
        """Remove one temporary decrypted copy (no-op for the plain store)."""
        if self.encrypted and self.views in Path(path).parents:
            shutil.rmtree(Path(path).parent, ignore_errors=True)

    def wipe_views(self) -> None:
        for child in list(self.views.iterdir()) if self.views.exists() else []:
            for base, _dirs, files in os.walk(child):
                for name in files:
                    path = os.path.join(base, name)
                    try:   # best-effort overwrite; not a guarantee on SSDs or journalling filesystems
                        size = os.path.getsize(path)
                        with open(path, "r+b") as fh:
                            fh.write(b"\0" * min(size, 8 * BLOCK))
                    except OSError:
                        pass
            shutil.rmtree(child, ignore_errors=True)
