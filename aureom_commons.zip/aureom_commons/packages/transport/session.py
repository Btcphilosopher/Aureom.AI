"""Client side of the peer protocol."""
from __future__ import annotations

import asyncio
from typing import Any

from pydantic import BaseModel

from ..domain.errors import CommonsError, PermissionDenied, ProtocolError, TransportError
from ..identity.keys import DeviceIdentity, Endorsement
from ..protocol import messages as m
from ..protocol.framing import BINARY, FrameStream
from .tls import PUBLIC_SNI, client_context, verify_peer

_CONTEXTS: dict[str, Any] = {}


def _context_for(identity: DeviceIdentity | None):
    key = identity.device_id if identity else ""
    if key not in _CONTEXTS:
        _CONTEXTS[key] = client_context(identity)
    return _CONTEXTS[key]


def split_address(address: str) -> tuple[str, int]:
    host, sep, port = address.rpartition(":")
    if not sep or not port.isdigit() or not host:
        raise TransportError("addresses must look like host:port", code="bad_address")
    return host.strip("[]"), int(port)


REMOTE_MESSAGES = {
    "invitation_invalid": "The invitation is invalid, has expired, or has already been used. Ask for a new one.",
    "rate_limited": "The peer is limiting requests. Try again shortly.",
    "stale_authority": "The peer's device has out-of-date membership records and will not serve until it synchronises.",
    "blocked": "The peer has blocked this device or account.",
    "proposals_disabled": "The collection's owner is not accepting additions.",
    "version_mismatch": "The peer speaks an incompatible protocol version.",
    "conflict": "The collection was changed by someone else first. Refresh and try again.",
}


def raise_remote(err: m.Error) -> None:
    if err.code == PermissionDenied.code:
        raise PermissionDenied("The peer refused: the item does not exist or you are not authorised.")
    message = REMOTE_MESSAGES.get(err.code) or err.message or err.code
    if err.code in ("invitation_invalid", "stale_authority", "blocked", "proposals_disabled"):
        raise PermissionDenied(message, code=err.code)
    raise CommonsError(message, code=err.code)


class PeerSession:
    def __init__(self, frames: FrameStream, device_id: str, ack: m.HelloAck, path: str, address: str):
        self.frames = frames
        self.device_id = device_id            # cryptographically verified
        self.ack = ack
        self.path = path                      # "direct" | "relay"
        self.address = address
        self._lock = asyncio.Lock()

    @property
    def peer_state(self) -> str:
        return self.ack.peer_state

    async def request(self, message: BaseModel, timeout: float = 30.0) -> dict[str, Any]:
        async with self._lock:
            await self.frames.send_json(message)
            reply = m.parse_response(await self.frames.recv_json(timeout))
        if isinstance(reply, m.Error):
            raise_remote(reply)
        if not isinstance(reply, m.Ok):
            raise ProtocolError("unexpected reply", code="bad_message")
        return reply.data

    async def get_chunk(self, message: m.GetChunk, timeout: float = 60.0) -> bytes:
        async with self._lock:
            await self.frames.send_json(message)
            reply = m.parse_response(await self.frames.recv_json(timeout))
            if isinstance(reply, m.Error):
                raise_remote(reply)
            if not isinstance(reply, m.ChunkHeader) or reply.index != message.index or reply.size > message.chunk_size:
                raise ProtocolError("unexpected chunk reply", code="bad_message")
            kind, payload = await self.frames.recv(timeout)
        if kind != BINARY or len(payload) != reply.size:
            raise ProtocolError("chunk frame does not match its header", code="bad_message")
        return payload

    async def close(self) -> None:
        await self.frames.close()

    async def __aenter__(self) -> "PeerSession":
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()


async def _handshake(reader, writer, *, expected_device_id: str | None, identity: DeviceIdentity | None,
                     device_name: str, endorsement: Endorsement | None, path: str, address: str,
                     max_json: int) -> PeerSession:
    frames = FrameStream(reader, writer, max_json=max_json)
    try:
        device_id = verify_peer(writer.get_extra_info("ssl_object"), expected_device_id)
        await frames.send_json(m.Hello(device_name=device_name if identity else "",
                                       endorsement=endorsement if identity else None))
        try:
            reply = m.parse_response(await frames.recv_json(10))
        except TransportError as exc:
            if identity is not None and exc.code == "connection_lost":
                raise TransportError("The peer closed the connection during authentication. It does not (or no "
                                     "longer) trust this device's key — pair again, or ask them to check their "
                                     "trusted-device list.", code="not_trusted_by_peer") from None
            raise
        if isinstance(reply, m.Error):
            raise_remote(reply)
        if not isinstance(reply, m.HelloAck):
            raise ProtocolError("unexpected reply to hello", code="bad_message")
        return PeerSession(frames, device_id, reply, path, address)
    except BaseException:
        await frames.close()
        raise


async def connect(address: str, *, expected_device_id: str | None, identity: DeviceIdentity | None,
                  device_name: str = "", endorsement: Endorsement | None = None, timeout: float = 6.0,
                  max_json: int = 8 * 1024 * 1024) -> PeerSession:
    """Open a direct, mutually-authenticated (or anonymous) session."""
    host, port = split_address(address)
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port, ssl=_context_for(identity),
                                    server_hostname=expected_device_id or PUBLIC_SNI), timeout)
    except (OSError, asyncio.TimeoutError) as exc:
        raise TransportError(f"could not reach {host}:{port}", code="unreachable") from exc
    return await _handshake(reader, writer, expected_device_id=expected_device_id, identity=identity,
                            device_name=device_name, endorsement=endorsement, path="direct", address=address,
                            max_json=max_json)


async def connect_via_relay(relay_address: str, *, expected_device_id: str, identity: DeviceIdentity,
                            device_name: str = "", endorsement: Endorsement | None = None, timeout: float = 15.0,
                            max_json: int = 8 * 1024 * 1024, anonymous: bool = False) -> PeerSession:
    """Reach a peer through a relay.  The relay only joins two byte streams;
    the same pinned TLS 1.3 session runs end to end *inside* that stream, so
    the relay cannot read or alter the protocol or any document content."""
    from .relay import relay_dial

    reader, writer = await relay_dial(relay_address, identity, expected_device_id, timeout)
    try:
        # ``identity`` authenticates us to the relay; inside the tunnel we may still be anonymous
        tls_identity = None if anonymous else identity
        await asyncio.wait_for(
            writer.start_tls(_context_for(tls_identity), server_hostname=expected_device_id), timeout)
    except (OSError, asyncio.TimeoutError) as exc:
        writer.close()
        raise TransportError("TLS through the relay failed", code="unreachable") from exc
    return await _handshake(reader, writer, expected_device_id=expected_device_id, identity=tls_identity,
                            device_name=device_name, endorsement=endorsement, path="relay", address=relay_address,
                            max_json=max_json)
