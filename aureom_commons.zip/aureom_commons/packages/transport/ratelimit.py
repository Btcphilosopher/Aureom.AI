"""Token buckets for bandwidth limits and request-rate limits."""
from __future__ import annotations

import asyncio
import time


class TokenBucket:
    def __init__(self, rate: float, burst: float | None = None):
        self.rate = float(rate)                 # tokens per second; 0 = unlimited
        self.burst = float(burst if burst is not None else max(rate, 1.0))
        self._tokens = self.burst
        self._stamp = time.monotonic()

    def _refill(self) -> None:
        now = time.monotonic()
        self._tokens = min(self.burst, self._tokens + (now - self._stamp) * self.rate)
        self._stamp = now

    def allow(self, cost: float = 1.0) -> bool:
        """Non-blocking check used for request limits."""
        if self.rate <= 0:
            return True
        self._refill()
        if self._tokens >= cost:
            self._tokens -= cost
            return True
        return False

    async def consume(self, cost: float) -> None:
        """Blocking throttle used for bandwidth limits (cost in bytes)."""
        if self.rate <= 0:
            return
        while cost > 0:
            self._refill()
            take = min(cost, self.burst)
            if self._tokens >= take:
                self._tokens -= take
                cost -= take
            else:
                await asyncio.sleep(min(1.0, (take - self._tokens) / self.rate))


class BucketRegistry:
    """One bucket per key (a peer's device id), created on demand."""

    def __init__(self) -> None:
        self._buckets: dict[str, tuple[float, TokenBucket]] = {}

    def get(self, key: str, rate: float, burst: float | None = None) -> TokenBucket:
        entry = self._buckets.get(key)
        if entry is None or entry[0] != rate:
            entry = (rate, TokenBucket(rate, burst))
            self._buckets[key] = entry
        return entry[1]
