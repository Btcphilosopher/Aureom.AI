"""Client side of the optional relay.

Control messages to the relay are newline-delimited JSON over TCP.  They are
authenticated (a device signs the relay's nonce) but not encrypted: the relay
and anyone on the path can see *which device ids* talk, when, and how much.
They cannot see or change what is said — that travels inside end-to-end TLS.
"""
from __future__ import annotations

import asyncio
import json
import logging

from ..domain.errors import TransportError
from ..domain.util import b64d, b64e, canonical_json
from ..identity.keys import DeviceIdentity
from .session import split_address

log = logging.getLogger("aureom.relay")
MAX_LINE = 4096


async def send_line(writer: asyncio.StreamWriter, obj: dict) -> None:
    writer.write(json.dumps(obj, separators=(",", ":")).encode() + b"\n")
    await writer.drain()


async def read_line(reader: asyncio.StreamReader, timeout: float = 15.0) -> dict:
    try:
        line = await asyncio.wait_for(reader.readline(), timeout)
    except (asyncio.TimeoutError, ValueError, ConnectionError, OSError) as exc:
        raise TransportError("relay did not answer", code="relay_unreachable") from exc
    if not line or len(line) > MAX_LINE:
        raise TransportError("relay closed the connection", code="relay_unreachable")
    try:
        doc = json.loads(line)
    except ValueError as exc:
        raise TransportError("relay sent an invalid reply", code="relay_error") from exc
    if not isinstance(doc, dict):
        raise TransportError("relay sent an invalid reply", code="relay_error")
    return doc


def auth_payload(nonce: str, role: str, device_id: str, target: str) -> bytes:
    return canonical_json({"nonce": nonce, "role": role, "device_id": device_id, "target": target})


async def _authenticate(reader, writer, identity: DeviceIdentity, role: str, target: str = "") -> None:
    await send_line(writer, {"op": "hello", "role": role, "device_id": identity.device_id,
                             "public_key": b64e(identity.public_raw), "target": target})
    challenge = await read_line(reader)
    nonce = challenge.get("challenge")
    if not isinstance(nonce, str) or len(b64d(nonce)) < 16:
        raise TransportError("relay refused the connection", code=str(challenge.get("error") or "relay_error")[:40])
    signature = identity.sign("relay-auth", auth_payload(nonce, role, identity.device_id, target))
    await send_line(writer, {"signature": b64e(signature)})
    reply = await read_line(reader)
    if not reply.get("ok"):
        raise TransportError("relay refused the connection", code=str(reply.get("error") or "relay_error")[:40])


async def relay_dial(relay_address: str, identity: DeviceIdentity, target: str, timeout: float = 15.0):
    host, port = split_address(relay_address)
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port, limit=MAX_LINE * 4), 6.0)
    except (OSError, asyncio.TimeoutError) as exc:
        raise TransportError("could not reach the relay", code="relay_unreachable") from exc
    try:
        await _authenticate(reader, writer, identity, "dial", target)
        joined = await read_line(reader, timeout)
        if not joined.get("connected"):
            raise TransportError("the peer is not reachable through this relay",
                                 code=str(joined.get("error") or "peer_offline")[:40])
        return reader, writer
    except BaseException:
        writer.close()
        raise


async def _pipe(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        while True:
            data = await reader.read(65536)
            if not data:
                break
            writer.write(data)
            await writer.drain()
    except (ConnectionError, OSError):
        pass
    finally:
        try:
            writer.close()
        except Exception:
            pass


class RelayAgent:
    """Keeps this device registered with a relay and bridges incoming relay
    sessions to the local TLS listener (which performs the real, end-to-end
    authentication).  The agent itself never sees plaintext."""

    def __init__(self, relay_address: str, identity: DeviceIdentity, local_port: int, on_state):
        self.relay_address, self.identity, self.local_port = relay_address, identity, local_port
        self.on_state = on_state
        self.connected = False
        self._task: asyncio.Task | None = None
        self._bridges: set[asyncio.Task] = set()

    def start(self) -> None:
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        for task in [self._task, *self._bridges]:
            if task:
                task.cancel()
        self._set(False)

    def _set(self, value: bool) -> None:
        if self.connected != value:
            self.connected = value
            self.on_state(value)

    async def _run(self) -> None:
        delay = 1.0
        while True:
            writer = None
            try:
                host, port = split_address(self.relay_address)
                reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port, limit=MAX_LINE * 4), 6.0)
                await _authenticate(reader, writer, self.identity, "listen")
                self._set(True)
                delay = 1.0
                while True:
                    try:
                        event = await read_line(reader, 25.0)
                    except TransportError as exc:
                        if exc.code == "relay_unreachable" and not reader.at_eof():
                            await send_line(writer, {"op": "ping"})
                            continue
                        raise
                    if event.get("event") == "incoming" and isinstance(event.get("session"), str):
                        task = asyncio.create_task(self._bridge(event["session"]))
                        self._bridges.add(task)
                        task.add_done_callback(self._bridges.discard)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.info("relay connection ended: %s", getattr(exc, "code", type(exc).__name__))
            finally:
                self._set(False)
                if writer:
                    writer.close()
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60.0)

    async def _bridge(self, session: str) -> None:
        host, port = split_address(self.relay_address)
        try:
            r_reader, r_writer = await asyncio.wait_for(asyncio.open_connection(host, port), 6.0)
            await send_line(r_writer, {"op": "hello", "role": "accept", "session": session})
            reply = await read_line(r_reader)
            if not reply.get("ok"):
                r_writer.close()
                return
            l_reader, l_writer = await asyncio.open_connection("127.0.0.1", self.local_port)
        except (OSError, asyncio.TimeoutError, TransportError):
            return
        await asyncio.gather(_pipe(r_reader, l_writer), _pipe(l_reader, r_writer), return_exceptions=True)
