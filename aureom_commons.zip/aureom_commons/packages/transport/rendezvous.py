"""Client for the optional rendezvous service (strictly opt-in).

The rendezvous service helps in two ways and is trusted with very little:

* **address lookup** — a device may register where it can currently be
  reached, visible only to the device ids it lists as contacts.  A wrong or
  malicious answer can only make a connection fail: the peer's key is still
  pinned.
* **public catalogue index** — publishers may announce *published*
  editions.  Private collections, titles and hashes are never sent.

Every request is signed by the device key; the service checks freshness and
rejects replays.  See docs/PROTOCOL.md §8 for what the operator can observe.
"""
from __future__ import annotations

import json
import secrets
import time
from typing import Any

import httpx

from ..domain.errors import CommonsError, FeatureUnavailable, StateError, TransportError
from ..domain.util import b64e, canonical_json, clean_text
from ..identity.keys import DeviceIdentity


def signed_envelope(identity: DeviceIdentity, path: str, body: dict) -> dict:
    stamp, nonce = int(time.time()), secrets.token_hex(16)
    payload = canonical_json({"path": path, "timestamp": stamp, "nonce": nonce, "body": body})
    return {"device_id": identity.device_id, "public_key": b64e(identity.public_raw), "timestamp": stamp,
            "nonce": nonce, "body": body, "signature": b64e(identity.sign("rendezvous-request", payload))}


class RendezvousClient:
    def __init__(self, ctx):
        self.ctx = ctx

    @property
    def url(self) -> str:
        return (self.ctx.settings.get("rendezvous_url") or "").rstrip("/")

    def _require(self) -> str:
        if not self.url:
            raise FeatureUnavailable("No rendezvous service is configured. This feature is optional and off by default.")
        if not self.ctx.settings.get("network_enabled"):
            raise TransportError("Networking is switched off.", code="offline")
        return self.url

    def _post(self, path: str, body: dict) -> Any:
        url = self._require()
        try:
            reply = httpx.post(url + path, json=signed_envelope(self.ctx.identity.device, path, body), timeout=10.0)
        except httpx.HTTPError as exc:
            raise TransportError("The rendezvous service could not be reached.", code="rendezvous_unreachable") from exc
        if reply.status_code >= 400:
            try:
                detail = reply.json().get("detail", "")
            except ValueError:
                detail = ""
            raise CommonsError(clean_text(detail, 200) or f"rendezvous refused the request ({reply.status_code})",
                               code="rendezvous_refused")
        return reply.json()

    # ------------------------------------------------------------ presence
    def register(self) -> dict:
        contacts = [p["device_id"] for p in self.ctx.identity.peers() if p["state"] == "trusted"]
        return self._post("/v1/register", {"addresses": self.ctx.node.advertised_addresses(),
                                           "relay": self.ctx.settings.get("relay_address") or "", "contacts": contacts})

    def lookup(self, device_id: str) -> list[str]:
        data = self._post("/v1/lookup", {"target": device_id})
        return [clean_text(a, 255) for a in data.get("addresses", [])][:8]

    # ----------------------------------------------------------- catalogue
    def announce(self, publication_id: str) -> dict:
        pub = self.ctx.publishing.get(publication_id)
        if pub["state"] not in ("published", "revised"):
            raise StateError("Only published editions can be announced.")
        addresses = self.ctx.node.advertised_addresses()
        result = self._post("/v1/catalogue/announce", {"manifest": pub["manifest"],
                                                       "address": addresses[0] if addresses else ""})
        self.ctx.activity.log("publication.announced", "A published edition was announced to the rendezvous catalogue.",
                              publication_id=publication_id)
        return result

    def announce_safely(self, publication_id: str) -> dict:
        if not self.url:
            return {"announced": False, "reason": "no rendezvous service configured"}
        try:
            return self.announce(publication_id) | {"announced": True}
        except CommonsError as exc:
            return {"announced": False, "reason": str(exc)}

    def withdraw_safely(self, publication_id: str) -> dict:
        if not self.url:
            return {"withdrawn_from_index": False, "reason": "no rendezvous service configured"}
        try:
            return self._post("/v1/catalogue/withdraw", {"publication_id": publication_id}) | {"withdrawn_from_index": True}
        except CommonsError as exc:
            return {"withdrawn_from_index": False, "reason": str(exc)}

    def search(self, query: str = "") -> dict:
        """Search the public index, then verify every returned manifest locally."""
        url = self._require()
        try:
            reply = httpx.get(url + "/v1/catalogue/search", params={"q": query, "limit": 50}, timeout=10.0)
            reply.raise_for_status()
            entries = reply.json().get("entries", [])
        except (httpx.HTTPError, ValueError) as exc:
            raise TransportError("The rendezvous service could not be reached.", code="rendezvous_unreachable") from exc
        results = []
        for entry in entries[:50]:
            try:
                results.append(self.ctx.publishing.record_remote(
                    clean_text(entry.get("device_id"), 64), clean_text(entry.get("address"), 255), entry.get("manifest")))
            except CommonsError as exc:
                results.append({"rejected": exc.code})
        self.ctx.events.emit("public")
        return {"index": url, "publications": results,
                "note": "Index entries are hints from an operator you chose. Each manifest was checked locally; files "
                        "are downloaded from the announcing peer and verified against the manifest."}

    def report(self, publication_id: str, reason: str) -> dict:
        return self._post("/v1/reports", {"publication_id": publication_id, "reason": clean_text(reason, 1000)})


__all__ = ["RendezvousClient", "signed_envelope", "json"]
