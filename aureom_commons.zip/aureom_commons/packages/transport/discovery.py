"""Opt-in local-network discovery.

When enabled, the device sends a small UDP multicast beacon and listens for
others.  A beacon contains a device id and a port — and the device name only
if the user also opted into that.  Beacons are unauthenticated hints:

* a discovered device is **not** trusted and cannot do anything a stranger
  could not already do;
* for devices that are already paired, a beacon may suggest a new address,
  but the connection is still verified against the pinned key, so a forged
  beacon can at worst cause a failed connection attempt.

Never used unless ``lan_discovery`` is switched on.  Private collection
names, titles and hashes are never broadcast.
"""
from __future__ import annotations

import asyncio
import json
import socket
import struct
import time

GROUP, PORT = "239.255.42.99", 47474
MAX_BEACON = 512
MAX_SEEN = 200


class _Protocol(asyncio.DatagramProtocol):
    def __init__(self, owner: "LanDiscovery"):
        self.owner = owner

    def datagram_received(self, data: bytes, addr) -> None:
        self.owner._received(data, addr)


class LanDiscovery:
    def __init__(self, device_id: str, listen_port: int, name: str = "", *, group: str = GROUP, port: int = PORT,
                 interval: float = 10.0, on_update=None):
        self.device_id, self.listen_port, self.name = device_id, listen_port, name
        self.group, self.port, self.interval = group, port, interval
        self.seen: dict[str, dict] = {}
        self.on_update = on_update or (lambda: None)
        self._transport = None
        self._task: asyncio.Task | None = None

    async def start(self) -> None:
        loop = asyncio.get_running_loop()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        sock.bind(("", self.port))
        try:
            mreq = struct.pack("4s4s", socket.inet_aton(self.group), socket.inet_aton("0.0.0.0"))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)      # never leaves the local segment
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
        except OSError:
            pass                           # e.g. unicast test addresses
        sock.setblocking(False)
        self._transport, _ = await loop.create_datagram_endpoint(lambda: _Protocol(self), sock=sock)
        self._task = asyncio.create_task(self._announce())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
        if self._transport:
            self._transport.close()
        self.seen.clear()

    def beacon(self) -> bytes:
        doc = {"app": "aureom-commons", "v": 1, "device_id": self.device_id, "port": self.listen_port}
        if self.name:
            doc["name"] = self.name[:60]
        return json.dumps(doc, separators=(",", ":")).encode()

    async def _announce(self) -> None:
        while True:
            try:
                self._transport.sendto(self.beacon(), (self.group, self.port))
            except OSError:
                pass
            await asyncio.sleep(self.interval)

    def _received(self, data: bytes, addr) -> None:
        if len(data) > MAX_BEACON:
            return
        try:
            doc = json.loads(data)
            device_id, port = doc["device_id"], int(doc["port"])
            if doc.get("app") != "aureom-commons" or doc.get("v") != 1:
                return
            if not (isinstance(device_id, str) and len(device_id) == 52 and device_id.isalnum() and 0 < port < 65536):
                return
        except (ValueError, KeyError, TypeError):
            return
        if device_id == self.device_id:
            return
        if device_id not in self.seen and len(self.seen) >= MAX_SEEN:
            return
        from ..domain.util import clean_text

        self.seen[device_id] = {"device_id": device_id, "address": f"{addr[0]}:{port}",
                                "name": clean_text(doc.get("name"), 60), "seen_at": time.time()}
        self.on_update()

    def devices(self) -> list[dict]:
        cutoff = time.time() - 4 * self.interval
        return [d for d in self.seen.values() if d["seen_at"] >= cutoff]
