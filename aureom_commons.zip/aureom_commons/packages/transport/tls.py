"""TLS 1.3 contexts with public-key pinning.

The handshake is OpenSSL's TLS 1.3 via the standard library — nothing here
implements or modifies a cryptographic handshake.  What this module adds is
*trust policy*:

* every device presents a self-signed Ed25519 certificate;
* a **client** accepts the server only if the certificate's public key
  hashes to the device id it intended to reach (pinning; no CA, no names);
* a **server** asks for a client certificate and lets OpenSSL verify it
  against a trust store containing exactly the certificates of paired
  devices.  Unknown certificates fail the handshake; clients that present no
  certificate are *anonymous* and can reach only public endpoints.

TLS proves possession of the private key on both sides.  It does not prove
who a key belongs to — that is what out-of-band fingerprint comparison is for.
"""
from __future__ import annotations

import os
import secrets
import shutil
import ssl
import tempfile
from pathlib import Path
from typing import Callable

from cryptography import x509
from cryptography.hazmat.primitives import serialization

from ..domain.errors import FeatureUnavailable, TransportError
from ..identity.keys import DeviceIdentity, device_id_from_cert

PUBLIC_SNI = "public.aureom.invalid"


def secure_transport_available() -> tuple[bool, str]:
    """Private sharing requires TLS 1.3 with Ed25519 certificates."""
    if not getattr(ssl, "HAS_TLSv1_3", False):
        return False, "This Python/OpenSSL build has no TLS 1.3 support, so peer networking is disabled."
    return True, ""


def _load_identity(ctx: ssl.SSLContext, identity: DeviceIdentity) -> None:
    # ``ssl`` can only load keys from files.  The key is written encrypted
    # under a random one-time password to a private directory and removed
    # as soon as OpenSSL has read it.
    folder = Path(tempfile.mkdtemp(prefix="aureom-tls-"))
    try:
        os.chmod(folder, 0o700)
        password = secrets.token_bytes(32).hex().encode()
        cert, key = folder / "cert.pem", folder / "key.pem"
        cert.write_bytes(identity.cert_pem())
        fd = os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(identity.key_pem_encrypted(password))
        ctx.load_cert_chain(str(cert), str(key), password=password)
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def _base(protocol: int) -> ssl.SSLContext:
    ok, why = secure_transport_available()
    if not ok:
        raise FeatureUnavailable(why)
    ctx = ssl.SSLContext(protocol)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.options |= ssl.OP_NO_COMPRESSION
    return ctx


def client_context(identity: DeviceIdentity | None) -> ssl.SSLContext:
    ctx = _base(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE      # trust is established by pinning in verify_peer(), not by a CA
    if identity is not None:
        _load_identity(ctx, identity)
    return ctx


def server_context(identity: DeviceIdentity, trusted_certs: list[bytes]) -> ssl.SSLContext:
    ctx = _base(ssl.PROTOCOL_TLS_SERVER)
    _load_identity(ctx, identity)
    ctx.verify_mode = ssl.CERT_OPTIONAL
    for der in trusted_certs:
        try:
            pem = x509.load_der_x509_certificate(der).public_bytes(serialization.Encoding.PEM).decode()
            ctx.load_verify_locations(cadata=pem)
        except (ValueError, ssl.SSLError):
            continue
    return ctx


class ServerTLS:
    """Holds one context per local identity (two during a key-rotation grace
    period) and swaps them atomically when the trusted-peer list changes."""

    def __init__(self, identities: Callable[[], list[DeviceIdentity]], trusted: Callable[[], list[bytes]]):
        self._identities, self._trusted = identities, trusted
        self._contexts: dict[str, ssl.SSLContext] = {}
        self._default: ssl.SSLContext | None = None
        self.entry = _base(ssl.PROTOCOL_TLS_SERVER)
        # The SNI callback swaps in a per-identity context, but OpenSSL keeps the
        # *verify mode* of the context the connection started with, so the entry
        # context must itself request (optional) client certificates.
        self.entry.verify_mode = ssl.CERT_OPTIONAL
        self.refresh()
        _load_identity(self.entry, self._identities()[0])
        self.entry.sni_callback = self._select

    def refresh(self) -> None:
        trusted = self._trusted()
        contexts = {ident.device_id: server_context(ident, trusted) for ident in self._identities()}
        self._contexts, self._default = contexts, next(iter(contexts.values()))

    def _select(self, sslobj: ssl.SSLObject, server_name: str | None, _ctx: ssl.SSLContext) -> None:
        sslobj.context = self._contexts.get((server_name or "").split(".")[0], self._default)
        return None

    def identity_used(self, sslobj: ssl.SSLObject) -> str:
        for device_id, ctx in self._contexts.items():
            if sslobj.context is ctx:
                return device_id
        return next(iter(self._contexts))


def verify_peer(sslobj: ssl.SSLObject | None, expected_device_id: str | None) -> str:
    """Return the peer's device id, enforcing the pin when one is expected."""
    if sslobj is None or sslobj.version() != "TLSv1.3":
        raise TransportError("the connection is not protected by TLS 1.3", code="insecure_transport")
    der = sslobj.getpeercert(binary_form=True)
    if not der:
        raise TransportError("the peer presented no certificate", code="no_certificate")
    try:
        device_id = device_id_from_cert(der)
    except Exception as exc:
        raise TransportError("the peer presented an unusable certificate", code="bad_certificate") from exc
    if expected_device_id is not None and device_id != expected_device_id:
        raise TransportError("the peer's key does not match the fingerprint you paired with",
                             code="fingerprint_mismatch")
    return device_id
