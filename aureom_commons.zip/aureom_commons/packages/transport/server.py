"""The listening side of the peer protocol.

Authorisation happens here, on every request, against this installation's
current records.  The order is always:

1. who is asking?  (TLS client certificate → device id → paired? blocked?)
2. may they do this?  (collection membership / public catalogue / own device)
3. only then touch metadata or bytes.

Failures in step 2 are reported with one indistinguishable error so that a
peer cannot learn whether a private collection, edition or file hash exists.
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass

from ..domain.errors import (CommonsError, Conflict, InvalidInput, PermissionDenied, ProtocolError, StateError,
                             TransportError)
from ..domain.models import FORMATS, Metadata, Permission
from ..domain.util import b64d, b64e, clean_text, is_safe_id, now_iso, redact
from ..identity.keys import device_id_from_cert
from ..protocol import messages as m
from ..protocol.framing import FrameStream
from .ratelimit import TokenBucket
from .tls import ServerTLS

log = logging.getLogger("aureom.server")
ANONYMOUS_OK = (m.Ping, m.PairRequest, m.PublicCatalogue, m.GetPublication)
IDLE_TIMEOUT = 120.0


@dataclass
class PeerContext:
    device_id: str | None = None
    account_id: str | None = None
    state: str = "anonymous"          # anonymous | pending | trusted
    is_own_device: bool = False
    via_relay: bool = False
    address: str = ""

    @property
    def trusted(self) -> bool:
        return self.state == "trusted"


class PeerServer:
    def __init__(self, ctx):
        self.ctx = ctx
        self.tls = ServerTLS(ctx.identity.identities, ctx.identity.trust_material)
        self._servers: list[asyncio.AbstractServer] = []
        self._connections: set[asyncio.Task] = set()
        self._readers: dict = {}
        self._pair_bucket = TokenBucket(0.2, 10)          # global brake on invitation-token guessing
        self.port = 0
        self.relay_port = 0
        self.active_peers: dict[str, str] = {}            # device id -> path of live inbound sessions
        self.faults: dict[tuple[str, int], int] = {}      # test/demo fault injection: corrupt these chunks N times

    # ----------------------------------------------------------- lifecycle
    async def start(self, host: str, port: int) -> int:
        server = await asyncio.start_server(lambda r, w: self._accept(r, w, False), host, port, ssl=self.tls.entry,
                                            ssl_handshake_timeout=10)
        self.port = server.sockets[0].getsockname()[1]
        # loopback-only listener used by the relay agent; same TLS, same checks
        relay = await asyncio.start_server(lambda r, w: self._accept(r, w, True), "127.0.0.1", 0, ssl=self.tls.entry,
                                           ssl_handshake_timeout=10)
        self.relay_port = relay.sockets[0].getsockname()[1]
        self._servers = [server, relay]
        return self.port

    async def stop(self) -> None:
        for server in self._servers:
            server.close()
        for task in list(self._connections):
            task.cancel()
        await asyncio.gather(*self._connections, return_exceptions=True)
        for server in self._servers:
            try:
                await asyncio.wait_for(server.wait_closed(), 2)
            except Exception:
                pass
        self._servers = []
        self.active_peers.clear()

    @property
    def listening(self) -> bool:
        return bool(self._servers)

    def refresh_trust(self) -> None:
        self.tls.refresh()

    # ---------------------------------------------------------- connection
    async def _accept(self, reader, writer, via_relay: bool) -> None:
        task = asyncio.current_task()
        self._connections.add(task)
        try:
            await self._serve(reader, writer, via_relay)
        finally:
            self._connections.discard(task)

    async def _serve(self, reader, writer, via_relay: bool) -> None:
        limits = self.ctx.settings.limits
        frames = FrameStream(reader, writer)
        peer = PeerContext(via_relay=via_relay)
        readers: dict[str, object] = {}
        try:
            if len(self._connections) > limits.max_connections:
                return
            sslobj = writer.get_extra_info("ssl_object")
            peername = writer.get_extra_info("peername") or ("", 0)
            peer.address = "relay" if via_relay else str(peername[0])
            der = sslobj.getpeercert(binary_form=True) if sslobj else None
            if der:
                peer.device_id = device_id_from_cert(der)
                row = self.ctx.identity.peer_row(peer.device_id)
                if row is None or row["state"] not in ("trusted", "pending"):
                    return                                   # removed or blocked since the trust store was built
                peer.state, peer.account_id = row["state"], row["account_id"] or None
                peer.is_own_device = bool(row["is_own_device"]) and row["state"] == "trusted"
                if self.ctx.identity.is_blocked(peer.device_id, peer.account_id):
                    return
            hello = m.parse_hello(await frames.recv_json(10))
            version = m.negotiate(hello.versions)
            rotation = None
            used = self.tls.identity_used(sslobj)
            if used != self.ctx.identity.device_id and peer.trusted:
                rotation = self.ctx.identity.pending_rotation()      # tell the peer about our new key
            await frames.send_json(m.HelloAck(version=version, device_name=self.ctx.identity.device_name,
                                              endorsement=self.ctx.identity.endorsement() if peer.device_id else None,
                                              peer_state=peer.state, rotation=rotation))
            if peer.trusted:
                self.ctx.identity.touch_peer(peer.device_id, "relay" if via_relay else "direct")
                self.active_peers[peer.device_id] = "relay" if via_relay else "direct"
                self.ctx.events.emit("network")
            requests = TokenBucket(limits.max_requests_per_second, limits.max_requests_per_second * 2)
            searches = TokenBucket(limits.search_requests_per_minute / 60.0, limits.search_requests_per_minute)
            while True:
                request = m.parse_request(await frames.recv_json(IDLE_TIMEOUT))
                if not requests.allow():
                    await frames.send_json(m.Error(code="rate_limited", message="too many requests"))
                    continue
                try:
                    await self._dispatch(request, peer, frames, readers, searches)
                except PermissionDenied as exc:
                    await frames.send_json(m.Error(code=exc.code, message=""))
                except (InvalidInput, StateError, Conflict, ProtocolError) as exc:
                    await frames.send_json(m.Error(code=exc.code, message=clean_text(str(exc), 200)))
                except CommonsError as exc:
                    await frames.send_json(m.Error(code=exc.code, message=""))
        except (TransportError, ProtocolError, asyncio.IncompleteReadError, ConnectionError):
            pass
        except asyncio.CancelledError:
            pass
        except Exception:
            log.exception("connection handler failed for %s", redact(peer.device_id))
        finally:
            for r in readers.values():
                try:
                    r.close()
                except Exception:
                    pass
            if peer.device_id and self.active_peers.pop(peer.device_id, None):
                self.ctx.events.emit("network")
            await frames.close()

    # ------------------------------------------------------------ dispatch
    async def _dispatch(self, req, peer: PeerContext, frames: FrameStream, readers: dict, searches: TokenBucket) -> None:
        ctx = self.ctx
        public_scope = isinstance(req, (m.GetManifest, m.GetChunk)) and req.scope.kind == "public"
        if not peer.trusted and not isinstance(req, ANONYMOUS_OK) and not public_scope:
            if not (peer.state == "pending" and isinstance(req, m.PairConfirm)):
                raise PermissionDenied()

        if isinstance(req, m.Ping):
            await frames.send_json(m.Ok())

        elif isinstance(req, m.PairRequest):
            if not self._pair_bucket.allow():
                raise PermissionDenied("too many pairing attempts", code="rate_limited")
            cert = b64d(req.device_cert)
            device_id = device_id_from_cert(cert)
            if not req.endorsement.is_valid_for(device_id):
                raise InvalidInput("invalid account endorsement", code="bad_signature")
            if ctx.identity.is_blocked(device_id, req.endorsement.account_id):
                raise PermissionDenied()
            invitation = ctx.identity.redeem_invitation(req.token, device_id)       # one-time; raises if replayed
            ctx.identity.upsert_peer(cert_der=cert, device_name=req.device_name, endorsement=req.endorsement,
                                     state="pending", addresses=[clean_text(a, 255) for a in req.addresses],
                                     relay=clean_text(req.relay, 255), paired_via=invitation["invitation_id"],
                                     is_own_device=False)
            await frames.send_json(m.Ok(data={"purpose": invitation["purpose"],
                                              "device_name": ctx.identity.device_name}))

        elif isinstance(req, m.PairConfirm):
            # Reached only over mutually-authenticated TLS: the client has proved
            # possession of the key it registered in pair_request.
            invitation = ctx.identity.confirm_invitation(req.token, peer.device_id)
            data: dict = {"purpose": invitation["purpose"]}
            own = invitation["purpose"] == "link-device"
            with ctx.db.tx() as c:
                c.execute("UPDATE peers SET state='trusted', is_own_device=? WHERE device_id=?", (int(own), peer.device_id))
                if own:
                    c.execute("UPDATE peers SET account_id=?, account_key=? WHERE device_id=?",
                              (ctx.identity.account_id, ctx.identity.account.public_raw, peer.device_id))
            peer.state = "trusted"
            if own:
                data["account_secret"] = b64e(ctx.identity.export_account_secret())
                data["account_name"] = ctx.settings.get("account_name") or ""
            elif invitation["purpose"] == "collection" and invitation["collection_id"]:
                try:
                    ctx.collections.invite_account(invitation["collection_id"], peer.account_id,
                                                   json.loads(invitation["permissions"]), status="active",
                                                   display_name=ctx.identity.account_display_name(peer.account_id))
                    data["collection_id"] = invitation["collection_id"]
                except CommonsError:
                    pass
            ctx.activity.log("peer.paired", "A device completed pairing using one of your invitations. Compare "
                             "fingerprints with its owner before sharing anything sensitive.", peer=peer.device_id)
            ctx.identity.on_trust_change()
            ctx.events.emit("peers")
            await frames.send_json(m.Ok(data=data))

        elif isinstance(req, m.ListShared):
            await frames.send_json(m.Ok(data={"collections": ctx.collections.shared_with(peer.account_id)}))

        elif isinstance(req, m.InvitationResponse):
            ctx.collections.respond_to_invitation(req.collection_id, peer.account_id, req.accept)
            ctx.events.emit("collections")
            await frames.send_json(m.Ok())

        elif isinstance(req, m.GetCollection):
            payload = ctx.collections.payload_for(req.collection_id, peer.account_id, req.known_version)
            await frames.send_json(m.Ok(data={"collection": payload}))

        elif isinstance(req, m.GetManifest):
            manifest = self._authorise(req.scope, req.file_hash, peer, req.known_version)
            await frames.send_json(m.Ok(data={"manifest": manifest.model_dump(mode="json")}))

        elif isinstance(req, m.GetChunk):
            manifest = self._authorise(req.scope, req.file_hash, peer, req.known_version)   # re-checked per chunk
            if req.chunk_size != manifest.chunk_size or req.index >= len(manifest.chunks):
                raise InvalidInput("no such chunk")
            reader = readers.get(req.file_hash)
            if reader is None:
                if len(readers) >= 4:
                    readers.pop(next(iter(readers))).close()
                reader = readers[req.file_hash] = ctx.open_content_by_hash(req.file_hash)
            data = reader.read_range(req.index * manifest.chunk_size, manifest.chunks[req.index].size)
            key = (req.file_hash, req.index)
            if self.faults.get(key):
                self.faults[key] -= 1
                data = bytes([data[0] ^ 0xFF]) + data[1:] if data else data
            await ctx.node.upload_bucket(peer.device_id or peer.address).consume(len(data))
            await frames.send_json(m.ChunkHeader(index=req.index, size=len(data)))
            await frames.send_binary(data)

        elif isinstance(req, m.PublicCatalogue):
            if not ctx.settings.get("serve_public_catalogue"):
                raise PermissionDenied()
            if not searches.allow():
                raise PermissionDenied("search rate limit reached", code="rate_limited")
            await frames.send_json(m.Ok(data={"entries": ctx.publishing.public_entries(req.query, req.offset, req.limit)}))

        elif isinstance(req, m.GetPublication):
            if not ctx.settings.get("serve_public_catalogue"):
                raise PermissionDenied()
            await frames.send_json(m.Ok(data={"manifest": ctx.publishing.public_manifest(req.publication_id)}))

        elif isinstance(req, m.Propose):
            await frames.send_json(m.Ok(data=self._propose(req, peer)))

        elif isinstance(req, (m.SyncDigest, m.SyncFetch, m.SyncPush)):
            if not peer.is_own_device:
                raise PermissionDenied()
            if isinstance(req, m.SyncDigest):
                await frames.send_json(m.Ok(data={"digest": ctx.sync.digest()}))
            elif isinstance(req, m.SyncFetch):
                await frames.send_json(m.Ok(data={"records": ctx.sync.export([tuple(k) for k in req.keys])}))
            else:
                stats = ctx.sync.apply(req.records, peer.device_id)
                ctx.sync.import_conflicts(req.conflicts, peer.device_id)
                ctx.events.emit("library")
                await frames.send_json(m.Ok(data={"stats": stats}))

        elif isinstance(req, m.KeyRotation):
            if req.statement.old_device_id != peer.device_id:
                raise PermissionDenied()
            new_id = ctx.identity.apply_peer_rotation(req.statement)
            await frames.send_json(m.Ok(data={"device_id": new_id}))

    # --------------------------------------------------------- authorising
    def _authorise(self, scope: m.Scope, file_hash: str, peer: PeerContext, known_version: int):
        ctx = self.ctx
        if scope.kind == "public":
            if not ctx.settings.get("serve_public_catalogue"):
                raise PermissionDenied()
            return ctx.publishing.public_file(file_hash)
        if not peer.trusted:
            raise PermissionDenied()
        if scope.kind == "collection":
            file = ctx.collections.authorise_file(peer.account_id, scope.id, file_hash, known_version)
        else:  # "device": a person's own linked devices replicate anything on request
            if not peer.is_own_device:
                raise PermissionDenied()
            row = ctx.db.one("SELECT f.* FROM files f JOIN editions e ON e.edition_id=f.edition_id "
                             "WHERE f.content_hash=? AND f.available=1 AND e.deleted=0", (file_hash,))
            if row is None:
                raise PermissionDenied()
            file = dict(row)
        return ctx.manifest_for(file)

    # ----------------------------------------------------------- proposals
    def _propose(self, req: m.Propose, peer: PeerContext) -> dict:
        ctx, cid, account = self.ctx, req.collection_id, peer.account_id
        col = ctx.collections
        payload = req.payload
        if req.op == "add_item":
            col.require(cid, account, Permission.ADD_WORKS, req.known_version)
            if ctx.settings.get("accept_proposals") == "never":
                raise PermissionDenied("the owner is not accepting additions", code="proposals_disabled")
            eid, file = payload.get("edition_id"), payload.get("file") or {}
            if not is_safe_id(eid) or not isinstance(file, dict) or ctx.db.one("SELECT 1 FROM editions WHERE edition_id=?", (eid,)):
                raise InvalidInput("the proposed edition cannot be accepted")
            pending = ctx.db.scalar("SELECT COUNT(*) FROM collection_items WHERE collection_id=? AND state='proposed'", (cid,), 0)
            if pending >= 50:
                raise PermissionDenied("too many pending proposals", code="rate_limited")
            from ..domain.util import is_sha256_hex

            if not is_sha256_hex(file.get("file_hash")) or int(file.get("size") or 0) > ctx.settings.limits.max_document_bytes:
                raise InvalidInput("the proposed file cannot be accepted")
            ctx.catalogue.register_edition(
                content_hash=file["file_hash"], size=int(file.get("size") or 0), filename=file.get("filename") or "file",
                fmt=file.get("format") if file.get("format") in FORMATS else "bin",
                metadata=Metadata.model_validate(payload.get("metadata") or {}), metadata_source="remote",
                edition_id=eid, origin="shared", origin_ref=cid, available=False,
                import_source=f"proposed-by:{account}")
            col.add_item(cid, eid, added_by=account, state="proposed")
            ctx.db.execute("UPDATE works SET origin_ref=? WHERE work_id=(SELECT work_id FROM editions WHERE edition_id=?)",
                           (f"{cid}", eid))
            ctx.activity.log("collection.proposal", "A member proposed adding a work to one of your collections. "
                             "Nothing is downloaded unless you accept.", peer=peer.device_id, collection_id=cid)
            ctx.events.emit("collections")
            return {"state": "proposed"}
        if req.op == "update_collection":
            col.require(cid, account, Permission.EDIT_METADATA, req.known_version)
            updated = col.update(cid, name=payload.get("name"), description=payload.get("description"),
                                 base_updated_at=req.base or None)
            ctx.events.emit("collections")
            return {"updated_at": updated["updated_at"]}
        if req.op in ("share_annotation", "unshare_annotation"):
            col.require(cid, account, Permission.SHARE_ANNOTATIONS, req.known_version)
            aid = payload.get("annotation_id")
            if not is_safe_id(aid):
                raise InvalidInput("bad annotation")
            existing = ctx.db.one("SELECT author_account FROM annotations WHERE annotation_id=?", (aid,))
            if existing is not None and existing["author_account"] != account:
                raise PermissionDenied()
            if req.op == "unshare_annotation":
                ctx.db.execute("UPDATE annotations SET deleted=1, updated_at=? WHERE annotation_id=? AND author_account=?",
                               (now_iso(), aid, account))
                return {}
            if payload.get("kind") not in ("bookmark", "highlight", "note") or not ctx.db.one(
                    "SELECT 1 FROM collection_items WHERE collection_id=? AND edition_id=? AND state='active'",
                    (cid, payload.get("edition_id"))):
                raise InvalidInput("bad annotation")
            from ..annotations.service import clean_locator

            ts = now_iso()
            ctx.db.execute(
                "INSERT INTO annotations (annotation_id, edition_id, content_hash, kind, locator, body, colour, shared_in, "
                "author_account, author_name, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(annotation_id) DO UPDATE SET locator=excluded.locator, body=excluded.body, "
                "updated_at=excluded.updated_at, deleted=0",
                (aid, payload["edition_id"], clean_text(payload.get("content_hash"), 64), payload["kind"],
                 json.dumps(clean_locator(payload.get("locator") or {})),
                 clean_text(payload.get("body"), ctx.settings.limits.max_annotation_chars, single_line=False),
                 clean_text(payload.get("colour"), 20) or "copper", cid, account,
                 ctx.identity.account_display_name(account), ts, ts))
            ctx.events.emit("collections")
            return {}
        if req.op in ("set_member", "revoke_member"):
            col.require(cid, account, Permission.MANAGE_MEMBERS, req.known_version)
            target = payload.get("account_id")
            owner = ctx.db.scalar("SELECT owner_account FROM collections WHERE collection_id=?", (cid,))
            if not is_safe_id(target) or target in (owner, account):
                raise PermissionDenied()
            if req.op == "revoke_member":
                col.revoke(cid, target)
            else:
                from ..permissions.collections import normalise_permissions

                wanted = set(normalise_permissions(payload.get("permissions") or []))
                if not wanted <= col.permissions_of(cid, account):       # managers cannot grant more than they hold
                    raise PermissionDenied()
                if not ctx.identity.devices_of_account(target):
                    raise InvalidInput("the owner has not paired with that account")
                col.invite_account(cid, target, sorted(wanted))
            ctx.events.emit("collections")
            return {}
        raise InvalidInput("unknown operation")
