"""The private catalogue: works, editions, files and their metadata.

Rules enforced here:

* importing never shares, publishes or announces anything;
* identical bytes are detected by content hash and never duplicated;
* different files are *never* merged because their titles match — a new
  import is always a new work unless the user explicitly attaches it to an
  existing work as a new edition;
* imported metadata, peer-supplied metadata and user corrections are stored
  separately; corrections survive re-extraction.
"""
from __future__ import annotations

import hashlib
import json
import os
import stat
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from ..domain.errors import InvalidInput, LimitExceeded, NotFound, StateError
from ..domain.models import METADATA_FIELDS, Availability, Metadata, Visibility
from ..domain.util import clean_text, new_id, now_iso, safe_filename
from ..readers import detect
from ..readers.extract import Extraction, extract
from ..search.index import SearchService
from ..storage.db import Database
from ..storage.objects import ObjectStore
from ..storage.settings import Settings


@dataclass
class ImportResult:
    name: str
    status: str                 # imported | duplicate | failed
    message: str = ""
    edition_id: str = ""
    work_id: str = ""
    content_hash: str = ""
    warnings: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return asdict(self)


def hash_file(path: Path) -> tuple[str, int]:
    digest, size = hashlib.sha256(), 0
    with open(path, "rb") as fh:
        while True:
            block = fh.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
            size += len(block)
    return digest.hexdigest(), size


class Catalogue:
    def __init__(self, db: Database, store: ObjectStore, settings: Settings, search: SearchService):
        self.db, self.store, self.settings, self.search = db, store, settings, search
        self.on_change: Callable[[str, str], None] = lambda kind, record_id: None
        self.device_id = ""

    # ============================================================== import
    def expand_paths(self, paths: Iterable[str | os.PathLike]) -> tuple[list[Path], list[ImportResult]]:
        """Flatten dropped files and folders into a list of candidate files.
        Symbolic links inside folders, hidden files and special files are skipped."""
        limits = self.settings.limits
        files: list[Path] = []
        problems: list[ImportResult] = []
        for raw in paths:
            path = Path(raw)
            try:
                st = path.stat()
            except OSError:
                problems.append(ImportResult(path.name, "failed", "The file could not be found or opened."))
                continue
            if stat.S_ISDIR(st.st_mode):
                base_depth = len(path.resolve().parts)
                for root, dirs, names in os.walk(path, followlinks=False):
                    depth = len(Path(root).resolve().parts) - base_depth
                    dirs[:] = sorted(d for d in dirs if not d.startswith(".")) if depth < limits.max_folder_depth else []
                    for name in sorted(names):
                        candidate = Path(root) / name
                        if name.startswith(".") or candidate.is_symlink():
                            continue
                        files.append(candidate)
            else:
                files.append(path)
        if len(files) > limits.max_import_files_per_batch:
            problems.append(ImportResult("", "failed",
                                         f"Only the first {limits.max_import_files_per_batch} files were imported "
                                         "(batch limit)."))
            files = files[: limits.max_import_files_per_batch]
        return files, problems

    def import_paths(self, paths: Iterable[str | os.PathLike], *, mode: str | None = None,
                     progress: Callable[[int, int, str], None] | None = None) -> list[ImportResult]:
        files, results = self.expand_paths(paths)
        with self.db.deferred():
            for i, path in enumerate(files):
                if progress:
                    progress(i, len(files), path.name)
                results.append(self.import_file(path, mode=mode))
        return results

    def import_file(self, path: str | os.PathLike, *, mode: str | None = None, work_id: str | None = None,
                    label: str = "", relation: str = "", previous_edition_id: str | None = None,
                    revision_notes: str = "", source: str = "") -> ImportResult:
        """Import one file.  Never raises for a bad file — the failure is
        reported in the result so a batch can continue."""
        path = Path(path)
        name = safe_filename(path.name)
        try:
            return self._import_file(path, name, mode or self.settings.get("import_mode"), work_id, label, relation,
                                     previous_edition_id, revision_notes, source)
        except (InvalidInput, LimitExceeded, NotFound, StateError) as exc:
            return ImportResult(name, "failed", str(exc))
        except OSError as exc:
            return ImportResult(name, "failed", f"The file could not be read ({exc.strerror or type(exc).__name__}).")

    def _import_file(self, path: Path, name: str, mode: str, work_id: str | None, label: str, relation: str,
                     previous_edition_id: str | None, revision_notes: str, source: str) -> ImportResult:
        limits = self.settings.limits
        if mode not in ("managed", "referenced"):
            raise InvalidInput("unknown import mode")
        st = os.stat(path)
        if not stat.S_ISREG(st.st_mode):
            raise InvalidInput("Only regular files can be imported.")
        if st.st_size == 0:
            raise InvalidInput("The file is empty.")
        if st.st_size > limits.max_document_bytes:
            raise LimitExceeded("The file is larger than the configured document size limit.")
        # 1-3: hash (and store, for managed imports) in a single pass
        if mode == "managed":
            self.store.check_quota(st.st_size)
            content_hash, size = self.store.ingest_file(path, max_bytes=limits.max_document_bytes)
        else:
            content_hash, size = hash_file(path)
        existing = self.db.one(
            "SELECT f.edition_id, e.work_id FROM files f JOIN editions e ON e.edition_id=f.edition_id "
            "WHERE f.content_hash=? AND f.role != 'cover' AND e.deleted=0 AND f.available=1 LIMIT 1", (content_hash,))
        if existing:
            return ImportResult(name, "duplicate", "An identical file is already in your library.",
                                existing["edition_id"], existing["work_id"], content_hash)
        # 4: isolated extraction (untrusted output)
        extraction = extract(path, limits)
        edition_id = self.register_edition(
            content_hash=content_hash, size=size, filename=name, fmt=extraction.format, extraction=extraction,
            storage=mode, ref_path=str(path.resolve()) if mode == "referenced" else None,
            import_source=source or f"file:{name}", work_id=work_id, label=label, relation=relation,
            previous_edition_id=previous_edition_id, revision_notes=revision_notes)
        row = self.db.one("SELECT work_id FROM editions WHERE edition_id=?", (edition_id,))
        return ImportResult(name, "imported", "", edition_id, row["work_id"], content_hash, extraction.warnings)

    def register_edition(self, *, content_hash: str, size: int, filename: str, fmt: str,
                         extraction: Extraction | None = None, metadata: Metadata | None = None,
                         metadata_source: str = "imported", storage: str = "managed", ref_path: str | None = None,
                         import_source: str = "", work_id: str | None = None, edition_id: str | None = None,
                         label: str = "", relation: str = "", previous_edition_id: str | None = None,
                         revision_notes: str = "", origin: str = "local", origin_ref: str = "",
                         available: bool = True, edition_number: int | None = None) -> str:
        """Create the catalogue rows for one edition.  Used by imports, by
        completed transfers and by collection/device synchronisation."""
        meta = metadata or (extraction.metadata if extraction else Metadata())
        ts = now_iso()
        edition_id = edition_id or new_id()
        with self.db.tx() as c:
            if work_id is None:
                work_id = new_id()
            if not c.execute("SELECT 1 FROM works WHERE work_id=?", (work_id,)).fetchone():
                c.execute("INSERT INTO works (work_id, created_at, origin, origin_ref) VALUES (?,?,?,?)",
                          (work_id, ts, origin, origin_ref))
            if previous_edition_id and not c.execute(
                    "SELECT 1 FROM editions WHERE edition_id=? AND work_id=?", (previous_edition_id, work_id)).fetchone():
                raise InvalidInput("the previous edition does not belong to this work")
            if edition_number is None:
                edition_number = 1 + (c.execute("SELECT COALESCE(MAX(edition_number), 0) FROM editions WHERE work_id=?",
                                                (work_id,)).fetchone()[0])
            index_mode = self.settings.get("index_default")
            c.execute("INSERT INTO editions (edition_id, work_id, edition_number, label, previous_edition_id, relation, "
                      "revision_notes, index_mode, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                      (edition_id, work_id, edition_number, clean_text(label, 120), previous_edition_id,
                       clean_text(relation, 40), clean_text(revision_notes, 2000, single_line=False), index_mode, ts))
            c.execute("INSERT INTO files (file_id, edition_id, role, content_hash, size, format, media_type, filename, "
                      "storage, ref_path, import_source, imported_at, available) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (new_id(), edition_id, "primary", content_hash, size, fmt, detect.media_type(fmt),
                       safe_filename(filename), storage, ref_path, clean_text(import_source, 300), ts, int(available)))
            c.execute("INSERT INTO edition_metadata (edition_id, source, data, updated_at) VALUES (?,?,?,?)",
                      (edition_id, metadata_source, meta.model_dump_json(), ts))
            if extraction and extraction.cover:
                cover_hash, cover_size = self.store.ingest_bytes(extraction.cover)
                c.execute("INSERT INTO files (file_id, edition_id, role, content_hash, size, format, media_type, "
                          "filename, storage, imported_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                          (new_id(), edition_id, "cover", cover_hash, cover_size,
                           detect.sniff(extraction.cover[:64]), extraction.cover_media_type, "cover", "managed", ts))
            self.search.index_edition(edition_id, work_id, meta, fmt, body=extraction.text if extraction else "",
                                      index_mode=index_mode)
        self.on_change("edition", edition_id)
        return edition_id

    def attach_file(self, edition_id: str, path: str | os.PathLike, role: str = "supplementary") -> dict:
        """Add a supplementary file (data set, illustration, audio…) to an edition."""
        path = Path(path)
        limits = self.settings.limits
        if not path.is_file():
            raise InvalidInput("Only regular files can be attached.")
        if path.stat().st_size > limits.max_document_bytes:
            raise LimitExceeded("The file is larger than the configured document size limit.")
        self.edition_row(edition_id)
        self.store.check_quota(path.stat().st_size)
        content_hash, size = self.store.ingest_file(path, max_bytes=limits.max_document_bytes)
        with open(path, "rb") as fh:
            fmt = detect.sniff(fh.read(8192), path.name)
        file_id = new_id()
        self.db.execute("INSERT INTO files (file_id, edition_id, role, content_hash, size, format, media_type, filename, "
                        "storage, import_source, imported_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (file_id, edition_id, role if role in ("supplementary", "cover") else "supplementary",
                         content_hash, size, fmt, detect.media_type(fmt), safe_filename(path.name), "managed",
                         f"file:{safe_filename(path.name)}", now_iso()))
        return {"file_id": file_id, "content_hash": content_hash, "size": size, "format": fmt}

    # ============================================================= reading
    def edition_row(self, edition_id: str):
        row = self.db.one("SELECT e.*, w.origin, w.origin_ref FROM editions e JOIN works w ON w.work_id=e.work_id "
                          "WHERE e.edition_id=? AND e.deleted=0", (edition_id,))
        if row is None:
            raise NotFound("edition")
        return row

    def files(self, edition_id: str, role: str | None = None) -> list[dict]:
        sql = "SELECT * FROM files WHERE edition_id=?" + (" AND role=?" if role else "") + " ORDER BY role, imported_at"
        return [dict(r) for r in self.db.query(sql, (edition_id, role) if role else (edition_id,))]

    def primary_file(self, edition_id: str) -> dict:
        files = self.files(edition_id, "primary")
        if not files:
            raise NotFound("file")
        return files[0]

    def metadata_layers(self, edition_id: str) -> dict[str, dict]:
        layers = {"imported": {}, "remote": {}, "user": {}}
        for row in self.db.query("SELECT source, data FROM edition_metadata WHERE edition_id=?", (edition_id,)):
            layers[row["source"]] = json.loads(row["data"])
        return layers

    def effective_metadata(self, edition_id: str) -> Metadata:
        layers = self.metadata_layers(edition_id)
        merged: dict[str, Any] = dict(Metadata(**layers["imported"]).model_dump())
        for name in ("remote", "user"):
            for key, value in layers[name].items():
                if key in METADATA_FIELDS:
                    merged[key] = value
        return Metadata(**merged)

    def update_user_metadata(self, edition_id: str, changes: dict[str, Any]) -> Metadata:
        """Record user corrections.  A value of ``None`` removes the
        correction for that field (the imported value shows again)."""
        self.edition_row(edition_id)
        unknown = set(changes) - set(METADATA_FIELDS)
        if unknown:
            raise InvalidInput(f"unknown metadata field: {sorted(unknown)[0]}")
        with self.db.tx() as c:
            cur = c.execute("SELECT data, fvv FROM edition_metadata WHERE edition_id=? AND source='user'",
                            (edition_id,)).fetchone()
            data = json.loads(cur["data"]) if cur else {}
            fvv = json.loads(cur["fvv"]) if cur else {}
            cleaned = Metadata(**{k: v for k, v in changes.items() if v is not None}).model_dump()
            for key, value in changes.items():
                if value is None:
                    data.pop(key, None)
                else:
                    data[key] = cleaned[key]
                vv = fvv.setdefault(key, {})
                vv[self.device_id or "local"] = vv.get(self.device_id or "local", 0) + 1
            c.execute("INSERT INTO edition_metadata (edition_id, source, data, fvv, updated_at) VALUES (?,?,?,?,?) "
                      "ON CONFLICT(edition_id, source) DO UPDATE SET data=excluded.data, fvv=excluded.fvv, "
                      "updated_at=excluded.updated_at", (edition_id, "user", json.dumps(data), json.dumps(fvv), now_iso()))
            self.reindex(edition_id)
        self.on_change("metadata", edition_id)
        return self.effective_metadata(edition_id)

    def reindex(self, edition_id: str, body: str | None = None) -> None:
        row = self.edition_row(edition_id)
        fmt = self.db.scalar("SELECT format FROM files WHERE edition_id=? AND role='primary'", (edition_id,), "bin")
        self.search.index_edition(edition_id, row["work_id"], self.effective_metadata(edition_id), fmt, body=body,
                                  index_mode=row["index_mode"])

    def set_index_mode(self, edition_id: str, mode: str) -> None:
        if mode not in ("full", "metadata", "none"):
            raise InvalidInput("unknown index mode")
        self.edition_row(edition_id)
        with self.db.tx() as c:
            c.execute("UPDATE editions SET index_mode=? WHERE edition_id=?", (mode, edition_id))
            body = None
            if mode != "full":
                body = ""                      # drop any indexed document text immediately
            self.reindex(edition_id, body=body)

    # --------------------------------------------------------- derived view
    def visibility(self, edition_id: str, origin: str = "local") -> Visibility:
        if origin == "public" or self.db.one(
                "SELECT 1 FROM publications WHERE edition_id=? AND state IN ('published','revised')", (edition_id,)):
            return Visibility.PUBLIC
        # "Shared" means someone else has been given access: the edition is in a
        # shared collection that has an invited/active member or an open invitation.
        if origin == "shared" or self.db.one(
                "SELECT 1 FROM collection_items ci JOIN collections c ON c.collection_id=ci.collection_id "
                "WHERE ci.edition_id=? AND ci.state='active' AND c.kind='shared' AND c.deleted=0 AND ("
                " EXISTS (SELECT 1 FROM collection_members m WHERE m.collection_id=c.collection_id "
                "         AND m.status IN ('invited','active'))"
                " OR EXISTS (SELECT 1 FROM pairing_invitations p WHERE p.collection_id=c.collection_id "
                "         AND p.state='open'))", (edition_id,)):
            return Visibility.SHARED
        return Visibility.PRIVATE

    def availability(self, edition_id: str, file: dict, origin: str, origin_ref: str) -> Availability:
        if file["available"]:
            if file["storage"] == "referenced" and not (file["ref_path"] and os.path.exists(file["ref_path"])):
                return Availability.UNAVAILABLE
            return Availability.LOCAL
        if origin == "shared":
            state = self.db.scalar("SELECT access_state FROM collections WHERE collection_id=? AND deleted=0",
                                   (origin_ref,), "")
            return Availability.PEER if state == "active" else Availability.UNAVAILABLE
        if origin == "public":
            return Availability.PEER if self.db.one("SELECT 1 FROM remote_publications WHERE publication_id=?",
                                                    (origin_ref,)) else Availability.UNAVAILABLE
        own = self.db.one("SELECT 1 FROM peers WHERE is_own_device=1 AND state='trusted'")
        return Availability.PEER if own else Availability.UNAVAILABLE

    def edition_view(self, edition_id: str) -> dict:
        row = self.edition_row(edition_id)
        file = self.primary_file(edition_id)
        meta = self.effective_metadata(edition_id)
        collections = [r["collection_id"] for r in self.db.query(
            "SELECT ci.collection_id FROM collection_items ci JOIN collections c ON c.collection_id=ci.collection_id "
            "WHERE ci.edition_id=? AND ci.state!='removed' AND c.deleted=0", (edition_id,))]
        progress = self.db.one("SELECT fraction, updated_at FROM reading_progress WHERE edition_id=? "
                               "ORDER BY updated_at DESC LIMIT 1", (edition_id,))
        return {
            "edition_id": edition_id, "work_id": row["work_id"], "edition_number": row["edition_number"],
            "label": row["label"], "relation": row["relation"], "previous_edition_id": row["previous_edition_id"],
            "revision_notes": row["revision_notes"], "index_mode": row["index_mode"], "created_at": row["created_at"],
            "origin": row["origin"], "origin_ref": row["origin_ref"],
            "metadata": meta.model_dump(), "title": meta.title or "Untitled",
            "format": file["format"], "media_type": file["media_type"], "size": file["size"],
            "content_hash": file["content_hash"], "filename": file["filename"], "storage": file["storage"],
            "import_source": file["import_source"],
            "readable": detect.is_readable(file["format"]), "kind": detect.kind_of(file["format"]),
            "visibility": self.visibility(edition_id, row["origin"]).value,
            "availability": self.availability(edition_id, file, row["origin"], row["origin_ref"]).value,
            "collections": collections,
            "has_cover": bool(self.db.one("SELECT 1 FROM files WHERE edition_id=? AND role='cover'", (edition_id,))),
            "progress": progress["fraction"] if progress else 0.0,
            "last_read": progress["updated_at"] if progress else "",
            "edition_count": self.db.scalar("SELECT COUNT(*) FROM editions WHERE work_id=? AND deleted=0",
                                            (row["work_id"],), 1),
        }

    def list(self, text: str = "", *, space: str = "", collection_id: str = "", availability: str = "",
             limit: int = 500, **filters: str) -> list[dict]:
        """Search the catalogue.  ``space`` is private | shared | public."""
        out = []
        for hit in self.search.candidates(text, limit=2000, **filters):
            try:
                view = self.edition_view(hit["edition_id"])
            except NotFound:
                continue
            if space and view["visibility"] != space:
                continue
            if collection_id and collection_id not in view["collections"]:
                continue
            if availability and view["availability"] != availability:
                continue
            view["snippet"] = hit["snippet"]
            out.append(view)
            if len(out) >= limit:
                break
        return out

    def editions_of_work(self, work_id: str) -> list[dict]:
        rows = self.db.query("SELECT edition_id FROM editions WHERE work_id=? AND deleted=0 ORDER BY edition_number",
                             (work_id,))
        return [self.edition_view(r["edition_id"]) for r in rows]

    def recent_reading(self, limit: int = 8) -> list[dict]:
        rows = self.db.query("SELECT edition_id, MAX(updated_at) AS ts FROM reading_progress GROUP BY edition_id "
                             "ORDER BY ts DESC LIMIT ?", (limit * 2,))
        out = []
        for r in rows:
            try:
                out.append(self.edition_view(r["edition_id"]))
            except NotFound:
                continue
        return out[:limit]

    # ------------------------------------------------------------- content
    def open_content(self, file: dict):
        """Return a random-access reader for a file's bytes (works offline)."""
        if not file["available"]:
            raise NotFound("The file has not been downloaded to this device.")
        if file["storage"] == "referenced":
            path = Path(file["ref_path"] or "")
            if not path.is_file():
                raise NotFound("The referenced original is missing or has moved.")
            from ..storage.objects import ObjectReader

            return ObjectReader(open(path, "rb"), path.stat().st_size)
        return self.store.open(file["content_hash"])

    def read_bytes(self, file: dict, max_bytes: int = 256 * 1024 * 1024) -> bytes:
        with self.open_content(file) as reader:
            if reader.size > max_bytes:
                raise LimitExceeded("file too large to load into memory")
            return reader.read_all()

    def content_path(self, file: dict) -> Path:
        """A path for components that need one (PDF, audio, external open)."""
        if not file["available"]:
            raise NotFound("The file has not been downloaded to this device.")
        if file["storage"] == "referenced":
            path = Path(file["ref_path"] or "")
            if not path.is_file():
                raise NotFound("The referenced original is missing or has moved.")
            return path
        return self.store.materialise(file["content_hash"], file["filename"])

    def verify_file(self, file: dict) -> bool:
        if file["storage"] == "referenced":
            try:
                return hash_file(Path(file["ref_path"]))[0] == file["content_hash"]
            except OSError:
                return False
        return self.store.verify(file["content_hash"])

    def cover_bytes(self, edition_id: str) -> bytes | None:
        row = self.db.one("SELECT content_hash FROM files WHERE edition_id=? AND role='cover'", (edition_id,))
        if not row or not self.store.has(row["content_hash"]):
            return None
        return self.store.read_all(row["content_hash"])

    def export_file(self, edition_id: str, dest: str | os.PathLike) -> Path:
        file = self.primary_file(edition_id)
        dest = Path(dest)
        if dest.is_dir():
            dest = dest / file["filename"]
        with self.open_content(file) as reader, open(dest, "wb") as out:
            for block in reader.iter_blocks():
                out.write(block)
        return dest

    # ------------------------------------------------------------- removal
    def remove_edition(self, edition_id: str) -> None:
        """Remove an edition from the catalogue and delete managed bytes that
        no other edition uses.  Published editions must be withdrawn first."""
        self.edition_row(edition_id)
        if self.db.one("SELECT 1 FROM publications WHERE edition_id=? AND state IN ('published','revised')", (edition_id,)):
            raise StateError("Withdraw the publication before removing this edition from your library.")
        with self.db.tx() as c:
            hashes = [r["content_hash"] for r in c.execute(
                "SELECT content_hash FROM files WHERE edition_id=? AND storage='managed'", (edition_id,))]
            c.execute("UPDATE editions SET deleted=1 WHERE edition_id=?", (edition_id,))
            c.execute("UPDATE files SET available=0 WHERE edition_id=?", (edition_id,))
            c.execute("UPDATE collection_items SET state='removed' WHERE edition_id=?", (edition_id,))
            c.execute("DELETE FROM publications WHERE edition_id=? AND state IN ('draft','preview','rights_review')",
                      (edition_id,))
            self.search.remove(edition_id)
            for content_hash in hashes:
                still_used = c.execute(
                    "SELECT 1 FROM files f JOIN editions e ON e.edition_id=f.edition_id "
                    "WHERE f.content_hash=? AND e.deleted=0 AND f.available=1", (content_hash,)).fetchone()
                if not still_used:
                    self.store.delete(content_hash)
        self.on_change("edition", edition_id)

    def managed_hashes(self) -> list[str]:
        rows = self.db.query("SELECT DISTINCT f.content_hash FROM files f JOIN editions e ON e.edition_id=f.edition_id "
                             "WHERE f.storage='managed' AND f.available=1 AND e.deleted=0")
        return [r[0] for r in rows if self.store.has(r[0])]

    def referenced_paths(self) -> list[str]:
        return [r[0] for r in self.db.query("SELECT ref_path FROM files WHERE storage='referenced' AND ref_path IS NOT NULL")]
