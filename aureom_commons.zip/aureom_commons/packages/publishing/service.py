"""Publishing workflow:  Draft → Preview → Rights Review → Published → Revised | Withdrawn.

* Nothing becomes public without :meth:`Publishing.publish`, which requires
  the digest of the disclosure preview the user was shown.
* A published edition is frozen: its manifest can never change (also
  enforced by database triggers).  A correction is a *new edition* linked to
  the previous one; both remain distinguishable.
* Withdrawal removes the edition from this publisher's catalogue and stops
  this installation serving it.  Copies already distributed are out of reach.
* A publisher signature is self-issued.  Publishing through this
  application does not establish, register or prove copyright ownership.
"""
from __future__ import annotations

import json
import os
from typing import Any, Callable

from ..domain.errors import InvalidInput, NotFound, PermissionDenied, StateError
from ..domain.models import Permission
from ..domain.util import canonical_json, clean_text, fingerprint_display, is_safe_id, new_id, now_iso, sha256_hex
from ..identity.service import IdentityService
from ..protocol.manifest import (Contributor, FileManifest, PublicationManifest, check_publication, parse_publication)
from ..storage.db import Database
from ..storage.settings import Activity, Settings

PRE_PUBLICATION = ("draft", "preview", "rights_review")
LIVE = ("published", "revised")

PUBLISH_NOTICES = [
    "Publishing is a deliberate, public act. Anyone who can reach your device, or a catalogue you announce to, can "
    "list and download this edition.",
    "A published edition is immutable. To correct it you release a new edition; the earlier one stays identifiable.",
    "You can withdraw an edition later, which stops your devices distributing it, but copies people already "
    "downloaded will persist.",
    "Publishing through Aureom Commons does not establish or prove copyright ownership.",
    "A publisher signature is self-issued: it shows which key approved the manifest, not who you legally are.",
]
WITHDRAWAL_NOTICE = (
    "This edition has been removed from your public catalogue and your devices no longer distribute it. Copies "
    "that were already downloaded — and any mirrors run by other people — may persist and are outside your control."
)
RIGHTS_BASES = ("author", "licensed", "public-domain", "open-licence")
PACKAGE_FIELDS = ("title", "subtitle", "description", "contributors", "language", "publication_date", "isbn", "doi",
                  "subjects", "licence", "rights_statement", "accessibility", "edition_label", "revision_notes",
                  "relation", "file_ids", "cover_file_id")


class Publishing:
    def __init__(self, db: Database, catalogue, identity: IdentityService, activity: Activity, settings: Settings,
                 build_manifest: Callable[[dict, str], FileManifest]):
        self.db, self.catalogue, self.identity, self.activity, self.settings = db, catalogue, identity, activity, settings
        self._build_manifest = build_manifest

    # --------------------------------------------------------------- views
    def _row(self, publication_id: str):
        row = self.db.one("SELECT * FROM publications WHERE publication_id=?", (publication_id,))
        if row is None:
            raise NotFound("publication")
        return row

    def _dict(self, row) -> dict:
        d = dict(row)
        d["package"] = json.loads(d["package"])
        d["rights_review"] = json.loads(d["rights_review"])
        d["manifest"] = json.loads(d["manifest"]) if d["manifest"] else None
        d["title"] = d["package"].get("title") or "Untitled"
        d["edition_label"] = d["package"].get("edition_label", "")
        d["immutable"] = d["state"] not in PRE_PUBLICATION
        return d

    def get(self, publication_id: str) -> dict:
        return self._dict(self._row(publication_id))

    def list(self, states: tuple[str, ...] | None = None) -> list[dict]:
        rows = self.db.query("SELECT * FROM publications ORDER BY created_at DESC")
        return [self._dict(r) for r in rows if states is None or r["state"] in states]

    def drafts(self) -> list[dict]:
        return self.list(PRE_PUBLICATION)

    # --------------------------------------------------------------- draft
    def create_draft(self, edition_id: str, *, publisher_id: str = "", previous_publication_id: str | None = None,
                     package: dict | None = None) -> dict:
        ed = self.catalogue.edition_row(edition_id)
        if ed["origin"] == "shared":
            src = self.db.one("SELECT my_permissions FROM collections WHERE collection_id=?", (ed["origin_ref"],))
            if not src or Permission.REDISTRIBUTE.value not in json.loads(src["my_permissions"]):
                raise PermissionDenied("This work was shared with you privately, without permission to redistribute "
                                       "it. It cannot be published from your library.", code="no_redistribution")
        if ed["origin"] == "public":
            raise StateError("This is someone else's published edition. You can mirror it, but not republish it "
                             "as your own.")
        if self.db.one("SELECT 1 FROM publications WHERE edition_id=? AND state != 'withdrawn'", (edition_id,)):
            raise StateError("This edition already has a publication record.")
        meta = self.catalogue.effective_metadata(edition_id)
        files = self.catalogue.files(edition_id)
        cover = next((f for f in files if f["role"] == "cover"), None)
        pkg: dict[str, Any] = {
            "title": meta.title, "subtitle": meta.subtitle, "description": meta.description,
            "contributors": [{"name": a, "role": "author"} for a in meta.authors]
                            + [{"name": c, "role": "contributor"} for c in meta.contributors],
            "language": meta.language, "publication_date": meta.publication_date, "isbn": meta.isbn, "doi": meta.doi,
            "subjects": [],                       # personal tags are never copied into a publication automatically
            "licence": meta.licence, "rights_statement": meta.rights, "accessibility": meta.accessibility,
            "edition_label": ed["label"] or f"Edition {ed['edition_number']}", "revision_notes": ed["revision_notes"],
            "relation": ed["relation"],
            "file_ids": [f["file_id"] for f in files if f["role"] == "primary"],
            "cover_file_id": cover["file_id"] if cover else "",
        }
        if package:
            pkg.update({k: v for k, v in package.items() if k in PACKAGE_FIELDS})
        pid, ts = new_id(), now_iso()
        self.db.execute(
            "INSERT INTO publications (publication_id, work_id, edition_id, state, package, publisher_id, "
            "previous_publication_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (pid, ed["work_id"], edition_id, "draft", json.dumps(pkg), publisher_id, previous_publication_id, ts, ts))
        self.update_draft(pid, {})
        return self.get(pid)

    def update_draft(self, publication_id: str, changes: dict, *, publisher_id: str | None = None) -> dict:
        row = self._row(publication_id)
        if row["state"] not in PRE_PUBLICATION:
            raise StateError("Published editions are immutable. Create a new edition to make changes.")
        pkg = json.loads(row["package"])
        unknown = set(changes) - set(PACKAGE_FIELDS)
        if unknown:
            raise InvalidInput(f"unknown package field: {sorted(unknown)[0]}")
        pkg.update(changes)
        clean: dict[str, Any] = {
            "title": clean_text(pkg.get("title"), 500), "subtitle": clean_text(pkg.get("subtitle"), 500),
            "description": clean_text(pkg.get("description"), 4000, single_line=False),
            "contributors": [{"name": clean_text(c.get("name"), 300), "role": clean_text(c.get("role"), 60) or "author"}
                             for c in (pkg.get("contributors") or [])[:100] if isinstance(c, dict) and c.get("name")],
            "language": clean_text(pkg.get("language"), 80), "publication_date": clean_text(pkg.get("publication_date"), 80),
            "isbn": clean_text(pkg.get("isbn"), 80), "doi": clean_text(pkg.get("doi"), 80),
            "subjects": [clean_text(s, 80) for s in (pkg.get("subjects") or [])[:50] if clean_text(s, 80)],
            "licence": clean_text(pkg.get("licence"), 500),
            "rights_statement": clean_text(pkg.get("rights_statement"), 2000, single_line=False),
            "accessibility": clean_text(pkg.get("accessibility"), 4000, single_line=False),
            "edition_label": clean_text(pkg.get("edition_label"), 120),
            "revision_notes": clean_text(pkg.get("revision_notes"), 4000, single_line=False),
            "relation": clean_text(pkg.get("relation"), 40),
            "file_ids": [f for f in (pkg.get("file_ids") or []) if is_safe_id(f)][:64],
            "cover_file_id": pkg.get("cover_file_id") if is_safe_id(pkg.get("cover_file_id")) else "",
        }
        valid_ids = {f["file_id"] for f in self.catalogue.files(row["edition_id"])}
        clean["file_ids"] = [f for f in clean["file_ids"] if f in valid_ids]
        if clean["cover_file_id"] not in valid_ids:
            clean["cover_file_id"] = ""
        if publisher_id is not None and publisher_id:
            self.identity.publisher_key(publisher_id)      # must be one of our own signing keys
        # any edit sends the workflow back to Draft: the preview and review must be repeated
        state = "draft" if (changes or publisher_id is not None) else row["state"]
        self.db.execute("UPDATE publications SET package=?, publisher_id=COALESCE(?, publisher_id), state=?, "
                        "rights_review=CASE WHEN ?='draft' THEN '{}' ELSE rights_review END, updated_at=? "
                        "WHERE publication_id=?",
                        (json.dumps(clean), publisher_id, state, state, now_iso(), publication_id))
        return self.get(publication_id)

    def discard_draft(self, publication_id: str) -> None:
        row = self._row(publication_id)
        if row["state"] not in PRE_PUBLICATION:
            raise StateError("Published editions cannot be deleted; withdraw them instead.")
        self.db.execute("DELETE FROM publications WHERE publication_id=?", (publication_id,))

    # ------------------------------------------------------------- preview
    def _selected_files(self, row, pkg: dict) -> tuple[list[dict], dict | None]:
        by_id = {f["file_id"]: f for f in self.catalogue.files(row["edition_id"])}
        files = [by_id[i] for i in pkg["file_ids"] if i in by_id]
        return files, by_id.get(pkg.get("cover_file_id") or "")

    def disclosure(self, publication_id: str) -> dict:
        """Exactly what publishing would make public (and what it would not)."""
        row = self._row(publication_id)
        pkg = json.loads(row["package"])
        ed = self.catalogue.edition_row(row["edition_id"])
        files, cover = self._selected_files(row, pkg)
        publisher = self.identity.publisher(row["publisher_id"]) if row["publisher_id"] else None
        previous = self.get(row["previous_publication_id"]) if row["previous_publication_id"] else None
        public = {
            "metadata": {k: pkg[k] for k in ("title", "subtitle", "description", "contributors", "language",
                                             "publication_date", "isbn", "doi", "subjects", "licence",
                                             "rights_statement", "accessibility")},
            "edition": {"edition_id": row["edition_id"], "work_id": row["work_id"], "number": ed["edition_number"],
                        "label": pkg["edition_label"], "relation": pkg["relation"],
                        "revision_notes": pkg["revision_notes"],
                        "previous_edition_id": previous["edition_id"] if previous else None},
            "files": [{"filename": f["filename"], "role": f["role"], "format": f["format"], "size": f["size"],
                       "sha256": f["content_hash"]} for f in files],
            "cover": {"size": cover["size"], "sha256": cover["content_hash"]} if cover else None,
            "publisher": {"name": publisher["name"], "key_fingerprint": publisher["fingerprint"],
                          "note": "self-declared name; self-issued key"} if publisher else None,
        }
        problems = []
        if not pkg["title"]:
            problems.append("A title is required.")
        if not files:
            problems.append("Select at least one file to publish.")
        if not pkg["licence"]:
            problems.append("State a licence or rights statement (for example “All rights reserved” or “CC BY 4.0”).")
        if any(not f["available"] for f in files):
            problems.append("One of the selected files is not on this device.")
        return {
            "publication_id": publication_id, "state": row["state"],
            "will_become_public": public,
            "also_visible_to_downloaders": ["this device's network address and device fingerprint"],
            "will_not_be_published": ["your annotations, highlights and notes", "your reading progress",
                                      "your personal tags and collections", "who you share privately with",
                                      "the original import path and source", "other editions and drafts of this work"],
            "signed": publisher is not None,
            "notices": PUBLISH_NOTICES,
            "problems": problems,
            "digest": sha256_hex(canonical_json(public)),
        }

    def enter_preview(self, publication_id: str) -> dict:
        row = self._row(publication_id)
        if row["state"] not in PRE_PUBLICATION:
            raise StateError("Only drafts can be previewed for publication.")
        disclosure = self.disclosure(publication_id)
        if disclosure["problems"]:
            raise InvalidInput(disclosure["problems"][0])
        self.db.execute("UPDATE publications SET state='preview', updated_at=? WHERE publication_id=?",
                        (now_iso(), publication_id))
        disclosure["state"] = "preview"
        return disclosure

    def submit_rights_review(self, publication_id: str, answers: dict) -> dict:
        row = self._row(publication_id)
        if row["state"] != "preview":
            raise StateError("Preview the publication before the rights review.")
        basis = answers.get("rights_basis")
        if basis not in RIGHTS_BASES:
            raise InvalidInput("Say on what basis you may publish this work.")
        for key, message in (("licence_confirmed", "Confirm the licence or rights statement."),
                             ("no_private_material", "Confirm the files contain nothing you mean to keep private."),
                             ("understands_permanence", "Confirm you understand that distributed copies persist.")):
            if answers.get(key) is not True:
                raise InvalidInput(message)
        review = {"rights_basis": basis, "note": clean_text(answers.get("note"), 1000, single_line=False),
                  "licence_confirmed": True, "no_private_material": True, "understands_permanence": True,
                  "reviewed_at": now_iso(),
                  "disclaimer": "Self-declared by the publisher. Not verified by anyone."}
        self.db.execute("UPDATE publications SET state='rights_review', rights_review=?, updated_at=? "
                        "WHERE publication_id=?", (json.dumps(review), now_iso(), publication_id))
        return self.get(publication_id)

    # ------------------------------------------------------------- publish
    def publish(self, publication_id: str, *, disclosure_digest: str, confirm: bool = False) -> dict:
        """The explicit publishing action."""
        row = self._row(publication_id)
        if row["state"] != "rights_review":
            raise StateError("Complete the preview and the rights review before publishing.")
        if confirm is not True:
            raise InvalidInput("Publishing requires explicit confirmation.")
        disclosure = self.disclosure(publication_id)
        if disclosure["problems"]:
            raise InvalidInput(disclosure["problems"][0])
        if disclosure_digest != disclosure["digest"]:
            raise StateError("The publication changed after you previewed it. Review the preview again.",
                             code="preview_out_of_date")
        pkg = json.loads(row["package"])
        ed = self.catalogue.edition_row(row["edition_id"])
        files, cover = self._selected_files(row, pkg)
        previous = self._row(row["previous_publication_id"]) if row["previous_publication_id"] else None
        if previous is not None and previous["state"] not in LIVE:
            previous = None
        manifest = PublicationManifest(
            publication_id=publication_id, work_id=row["work_id"], edition_id=row["edition_id"],
            edition_number=ed["edition_number"], edition_label=pkg["edition_label"],
            previous_edition_id=previous["edition_id"] if previous else None,
            previous_publication_id=previous["publication_id"] if previous else None,
            previous_manifest_id=previous["manifest_id"] if previous else None,
            relation=pkg["relation"] if previous else "", revision_notes=pkg["revision_notes"],
            title=pkg["title"], subtitle=pkg["subtitle"], description=pkg["description"],
            contributors=[Contributor(**c) for c in pkg["contributors"]], language=pkg["language"],
            publication_date=pkg["publication_date"], isbn=pkg["isbn"], doi=pkg["doi"], subjects=pkg["subjects"],
            licence=pkg["licence"], rights_statement=pkg["rights_statement"], accessibility=pkg["accessibility"],
            cover=self._build_manifest(cover, row["edition_id"]) if cover else None,
            files=[self._build_manifest(f, row["edition_id"]) for f in files],
            published_at=now_iso(),
        )
        if row["publisher_id"]:
            publisher = self.identity.publisher(row["publisher_id"])
            manifest.sign_with(self.identity.publisher_key(row["publisher_id"]), publisher["name"])
        with self.db.tx() as c:
            c.execute("UPDATE publications SET state='published', manifest=?, manifest_id=?, published_at=?, "
                      "updated_at=? WHERE publication_id=? AND state='rights_review'",
                      (manifest.model_dump_json(), manifest.manifest_id, manifest.published_at, now_iso(), publication_id))
            if previous is not None:
                c.execute("UPDATE publications SET state='revised', superseded_by=?, updated_at=? "
                          "WHERE publication_id=? AND state='published'",
                          (publication_id, now_iso(), previous["publication_id"]))
        self.activity.log("publication.published", "An edition was published.", publication_id=publication_id,
                          manifest_id=manifest.manifest_id, signed=bool(row["publisher_id"]))
        return self.get(publication_id)

    def create_revision(self, publication_id: str, new_file: str | os.PathLike, *, label: str, notes: str,
                        relation: str = "correction-of") -> dict:
        """Start a new edition of a published work.  The file is imported as a
        new, distinct edition linked to the previous one; a new draft is
        created.  The earlier edition is untouched."""
        prev = self._row(publication_id)
        if prev["state"] != "published":
            raise StateError("Only the current published edition can be revised.")
        if not clean_text(notes, 4000):
            raise InvalidInput("Describe what changed in this edition.")
        result = self.catalogue.import_file(new_file, work_id=prev["work_id"], label=label, relation=relation,
                                            previous_edition_id=prev["edition_id"], revision_notes=notes)
        if result.status == "duplicate":
            raise InvalidInput("That file is identical to an edition already in your library. A new edition needs "
                               "different content.")
        if result.status != "imported":
            raise InvalidInput(result.message or "The new edition could not be imported.")
        old_pkg = json.loads(prev["package"])
        carry = {k: old_pkg[k] for k in ("description", "contributors", "subjects", "licence", "rights_statement",
                                         "accessibility", "language", "isbn", "doi", "title", "subtitle")}
        carry.update(edition_label=label, revision_notes=notes, relation=relation)
        draft = self.create_draft(result.edition_id, publisher_id=prev["publisher_id"],
                                  previous_publication_id=publication_id, package=carry)
        self.db.execute("UPDATE publications SET announce=? WHERE publication_id=?", (prev["announce"], draft["publication_id"]))
        return self.get(draft["publication_id"])

    def withdraw(self, publication_id: str, note: str = "") -> dict:
        row = self._row(publication_id)
        if row["state"] not in LIVE:
            raise StateError("Only published editions can be withdrawn.")
        self.db.execute("UPDATE publications SET state='withdrawn', withdrawn_at=?, withdrawal_note=?, updated_at=? "
                        "WHERE publication_id=?", (now_iso(), clean_text(note, 1000, single_line=False), now_iso(),
                                                    publication_id))
        self.activity.log("publication.withdrawn", "An edition was withdrawn from the public catalogue. "
                          "Previously distributed copies may persist.", publication_id=publication_id)
        return self.get(publication_id) | {"notice": WITHDRAWAL_NOTICE}

    def set_announce(self, publication_id: str, announce: bool) -> None:
        self._row(publication_id)
        self.db.execute("UPDATE publications SET announce=? WHERE publication_id=?", (int(bool(announce)), publication_id))

    # ------------------------------------------------------------- serving
    def _mirrors(self) -> list[str]:
        return list(self.settings.get("_mirrors") or [])

    def _live_manifests(self) -> list[tuple[dict, str]]:
        out = [(json.loads(r["manifest"]), r["superseded_by"] or "") for r in self.db.query(
            "SELECT manifest, superseded_by FROM publications WHERE state IN ('published','revised') "
            "ORDER BY published_at DESC")]
        for pid in self._mirrors():
            row = self.db.one("SELECT manifest FROM remote_publications WHERE publication_id=? AND signature_ok=1 LIMIT 1", (pid,))
            if row:
                out.append((json.loads(row["manifest"]), ""))
        return out

    @staticmethod
    def entry(manifest: dict, superseded_by: str = "") -> dict:
        return {
            "publication_id": manifest["publication_id"], "manifest_id": sha256_hex(canonical_json(
                {k: v for k, v in manifest.items() if k != "signature"})),
            "work_id": manifest["work_id"], "edition_id": manifest["edition_id"],
            "edition_number": manifest["edition_number"], "edition_label": manifest.get("edition_label", ""),
            "previous_publication_id": manifest.get("previous_publication_id"), "superseded_by": superseded_by,
            "title": manifest["title"], "subtitle": manifest.get("subtitle", ""),
            "authors": [c["name"] for c in manifest.get("contributors", []) if c.get("role") == "author"],
            "language": manifest.get("language", ""), "licence": manifest.get("licence", ""),
            "published_at": manifest.get("published_at", ""),
            "publisher": {"name": manifest["publisher"]["name"], "key_id": manifest["publisher"]["key_id"]}
            if manifest.get("publisher") else None,
            "signed": bool(manifest.get("signature")),
            "size": sum(f["size"] for f in manifest.get("files", [])),
            "formats": sorted({f["format"] for f in manifest.get("files", [])}),
        }

    def public_entries(self, query: str = "", offset: int = 0, limit: int = 50) -> list[dict]:
        words = [w.lower() for w in clean_text(query, 200).split()][:8]
        out = []
        for manifest, superseded in self._live_manifests():
            entry = self.entry(manifest, superseded)
            hay = " ".join([entry["title"], entry["subtitle"], " ".join(entry["authors"]),
                            manifest.get("description", ""), " ".join(manifest.get("subjects", []))]).lower()
            if all(w in hay for w in words):
                out.append(entry)
        return out[offset: offset + limit]

    def public_manifest(self, publication_id: str) -> dict:
        for manifest, _ in self._live_manifests():
            if manifest["publication_id"] == publication_id:
                return manifest
        raise PermissionDenied()

    def public_file(self, file_hash: str) -> FileManifest:
        """Authorise a public download: the hash must belong to a live
        (published, not withdrawn) edition, or to a mirrored publication."""
        for manifest, _ in self._live_manifests():
            for f in ([manifest["cover"]] if manifest.get("cover") else []) + manifest["files"]:
                if f["file_hash"] == file_hash:
                    return FileManifest.model_validate(f)
        raise PermissionDenied()

    # ----------------------------------------------- other people's works
    def record_remote(self, source_device: str, source_address: str, doc: dict) -> dict:
        """Validate and remember a publication manifest fetched from a peer.
        Returns a precise report of what was checked."""
        manifest = parse_publication(doc, self.settings.limits)
        pinned = self.identity.publisher_pin(manifest.publisher.key_id) if manifest.publisher else None
        report = check_publication(manifest, pinned=pinned)
        if report.signed and not report.signature_valid:
            self.activity.log("publication.bad_signature", "A publication manifest with an invalid signature was rejected.",
                              peer=source_device)
            raise PermissionDenied("The manifest's signature is invalid; it was rejected.", code="bad_signature")
        count = self.db.scalar("SELECT COUNT(*) FROM remote_publications WHERE source_device=?", (source_device,), 0)
        if count >= self.settings.limits.max_remote_catalogue_entries:
            raise InvalidInput("catalogue entry limit reached for this source", code="limit_exceeded")
        entry = self.entry(manifest.model_dump(mode="json"))
        self.db.execute(
            "INSERT INTO remote_publications (publication_id, source_device, source_address, manifest, manifest_id, "
            "signature_ok, publisher_id, title, authors, language, fetched_at) VALUES (?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(publication_id, source_device) DO UPDATE SET source_address=excluded.source_address, "
            "manifest=excluded.manifest, manifest_id=excluded.manifest_id, signature_ok=excluded.signature_ok, "
            "fetched_at=excluded.fetched_at",
            (manifest.publication_id, source_device, source_address, manifest.model_dump_json(), manifest.manifest_id,
             int(report.signature_valid), report.key_id, manifest.title, "; ".join(entry["authors"]),
             manifest.language, now_iso()))
        return {"entry": entry, "check": report.model_dump(),
                "publisher_fingerprint": fingerprint_display(report.key_id) if report.key_id else ""}

    def remote_superseded_by(self, publication_id: str, publisher_id: str, source_device: str) -> str:
        """A remote edition counts as superseded only by a later manifest from
        the *same publisher key* (or, if unsigned, the same source device) —
        nobody else can declare someone's edition obsolete."""
        row = self.db.one(
            "SELECT publication_id FROM remote_publications WHERE json_extract(manifest, '$.previous_publication_id')=? "
            "AND ((publisher_id != '' AND publisher_id=?) OR (publisher_id='' AND source_device=?)) LIMIT 1",
            (publication_id, publisher_id, source_device))
        return row["publication_id"] if row else ""

    def remote_list(self, query: str = "") -> list[dict]:
        words = [w.lower() for w in clean_text(query, 200).split()][:8]
        out = []
        for r in self.db.query("SELECT * FROM remote_publications ORDER BY fetched_at DESC"):
            manifest = json.loads(r["manifest"])
            entry = self.entry(manifest)
            hay = f"{entry['title']} {' '.join(entry['authors'])} {manifest.get('description', '')}".lower()
            if not all(w in hay for w in words):
                continue
            local = self.db.one("SELECT f.available FROM files f JOIN editions e ON e.edition_id=f.edition_id "
                                "WHERE f.content_hash=? AND e.deleted=0 AND f.available=1",
                                (manifest["files"][0]["file_hash"],))
            entry.update(superseded_by=self.remote_superseded_by(r["publication_id"], r["publisher_id"], r["source_device"]),
                         source_device=r["source_device"], source_address=r["source_address"],
                         signature_ok=bool(r["signature_ok"]), fetched_at=r["fetched_at"],
                         availability="local" if local else "peer", mirrored=r["publication_id"] in self._mirrors())
            out.append(entry)
        return out

    def remote_manifest(self, publication_id: str, source_device: str | None = None) -> tuple[PublicationManifest, list[dict]]:
        rows = self.db.query("SELECT * FROM remote_publications WHERE publication_id=?", (publication_id,))
        if not rows:
            raise NotFound("publication")
        chosen = next((r for r in rows if r["source_device"] == source_device), rows[0])
        manifest = PublicationManifest.model_validate_json(chosen["manifest"])
        sources = [{"device_id": r["source_device"], "address": r["source_address"]} for r in rows
                   if r["manifest_id"] == chosen["manifest_id"]]
        return manifest, sources

    def set_mirror(self, publication_id: str, enabled: bool) -> None:
        """Opt in (or out) of re-serving someone else's signed publication."""
        mirrors = set(self._mirrors())
        if enabled:
            row = self.db.one("SELECT signature_ok FROM remote_publications WHERE publication_id=?", (publication_id,))
            if row is None:
                raise NotFound("publication")
            if not row["signature_ok"]:
                raise StateError("Only publications with a valid publisher signature can be mirrored.")
            mirrors.add(publication_id)
        else:
            mirrors.discard(publication_id)
        self.settings.set("_mirrors", sorted(mirrors))
