"""Length-prefixed framing over an (already TLS-protected) byte stream.

    frame := length:u32-be  kind:u8  payload[length-1]

``kind`` 1 is a UTF-8 JSON message, ``kind`` 2 is an opaque binary chunk.
Lengths are checked against hard caps *before* any payload is read, so a
peer cannot make us allocate more than the cap by lying about a length.
"""
from __future__ import annotations

import asyncio
import struct

from pydantic import BaseModel

from ..domain.errors import ProtocolError, TransportError

JSON, BINARY = 1, 2
MAX_JSON = 1024 * 1024
MAX_BINARY = 4 * 1024 * 1024
_HEADER = struct.Struct(">IB")


class FrameStream:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, *, max_json: int = MAX_JSON,
                 max_binary: int = MAX_BINARY):
        self.reader, self.writer = reader, writer
        self.max_json, self.max_binary = max_json, max_binary
        self.bytes_in = 0
        self.bytes_out = 0

    async def send_json(self, message: BaseModel) -> None:
        await self._send(JSON, message.model_dump_json().encode())

    async def send_binary(self, data: bytes) -> None:
        await self._send(BINARY, data)

    async def _send(self, kind: int, payload: bytes) -> None:
        try:
            self.writer.write(_HEADER.pack(len(payload) + 1, kind) + payload)
            await self.writer.drain()
            self.bytes_out += len(payload) + 5
        except (ConnectionError, OSError, asyncio.IncompleteReadError) as exc:
            raise TransportError("connection lost", code="connection_lost") from exc

    async def recv(self, timeout: float | None = 30.0) -> tuple[int, bytes]:
        try:
            header = await asyncio.wait_for(self.reader.readexactly(_HEADER.size), timeout)
            length, kind = _HEADER.unpack(header)
            cap = self.max_json if kind == JSON else self.max_binary if kind == BINARY else 0
            if length < 1 or length - 1 > cap:
                raise ProtocolError("frame exceeds the size limit", code="frame_too_large")
            payload = await asyncio.wait_for(self.reader.readexactly(length - 1), timeout)
        except asyncio.TimeoutError as exc:
            raise TransportError("peer timed out", code="timeout") from exc
        except (asyncio.IncompleteReadError, ConnectionError, OSError) as exc:
            raise TransportError("connection closed", code="connection_lost") from exc
        self.bytes_in += length + 4
        return kind, payload

    async def recv_json(self, timeout: float | None = 30.0) -> bytes:
        kind, payload = await self.recv(timeout)
        if kind != JSON:
            raise ProtocolError("expected a JSON frame", code="bad_message")
        return payload

    async def close(self) -> None:
        try:
            self.writer.close()
            await asyncio.wait_for(self.writer.wait_closed(), 2)
        except Exception:
            pass
