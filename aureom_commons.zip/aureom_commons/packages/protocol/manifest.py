"""Versioned transfer and publication manifests.

A *file manifest* describes one file as an ordered list of hashed chunks.
A *publication manifest* describes a published edition (metadata, files,
relationship to the previous edition) and may carry a publisher signature.

A manifest hash or signature is evidence that bytes match what a particular
key approved.  It is **not** evidence that a file is safe to open, lawful to
hold, accurate, or that the signer is who they say they are.
"""
from __future__ import annotations

import hashlib
from typing import Iterable, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..domain.errors import IntegrityFailure, InvalidInput, LimitExceeded, ProtocolError
from ..domain.limits import Limits
from ..domain.util import b64d, b64e, canonical_json, clean_text, is_safe_id, is_sha256_hex, safe_filename, sha256_hex
from ..identity.keys import PublisherIdentity, key_id, verify

MANIFEST_VERSION = 1
PROTOCOL_VERSION = 1
SUPPORTED_PROTOCOLS = (1,)
MIN_CHUNK, MAX_CHUNK = 16 * 1024, 4 * 1024 * 1024


class ChunkRef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    index: int = Field(ge=0)
    size: int = Field(ge=0, le=MAX_CHUNK)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class FileManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    manifest_version: Literal[1] = 1
    protocol_min: int = Field(default=PROTOCOL_VERSION, ge=1)
    file_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    size: int = Field(ge=0)
    chunk_size: int = Field(ge=MIN_CHUNK, le=MAX_CHUNK)
    chunks: list[ChunkRef]
    format: str = Field(max_length=16)
    media_type: str = Field(max_length=120)
    filename: str = Field(max_length=255)
    edition_id: str = Field(max_length=80)
    role: str = Field(default="primary", max_length=20)

    @model_validator(mode="after")
    def _consistent(self) -> "FileManifest":
        expected = max(1, -(-self.size // self.chunk_size)) if self.size else 1
        if len(self.chunks) != expected:
            raise ValueError("chunk count does not match the file size")
        total = 0
        for i, chunk in enumerate(self.chunks):
            if chunk.index != i:
                raise ValueError("chunk indexes must be contiguous")
            if i < len(self.chunks) - 1 and chunk.size != self.chunk_size:
                raise ValueError("only the final chunk may be short")
            total += chunk.size
        if total != self.size:
            raise ValueError("chunk sizes do not add up to the file size")
        if not is_safe_id(self.edition_id):
            raise ValueError("bad edition identifier")
        self.filename = safe_filename(self.filename)       # never trust a peer-supplied name
        return self

    def check_limits(self, limits: Limits) -> None:
        if self.protocol_min not in SUPPORTED_PROTOCOLS and self.protocol_min > max(SUPPORTED_PROTOCOLS):
            raise ProtocolError("this manifest requires a newer protocol version", code="protocol_too_new")
        if len(self.chunks) > limits.max_chunks:
            raise LimitExceeded("manifest has too many chunks", code="too_many_chunks")
        if self.size > limits.max_document_bytes:
            raise LimitExceeded("file exceeds the configured document size limit", code="document_too_large")


def build_file_manifest(blocks: Iterable[bytes], *, chunk_size: int, fmt: str, media_type: str, filename: str,
                        edition_id: str, role: str = "primary") -> FileManifest:
    whole = hashlib.sha256()
    chunks: list[ChunkRef] = []
    buf = bytearray()
    size = 0

    def emit(data: bytes) -> None:
        chunks.append(ChunkRef(index=len(chunks), size=len(data), sha256=sha256_hex(data)))

    for block in blocks:
        whole.update(block)
        size += len(block)
        buf += block
        while len(buf) >= chunk_size:
            emit(bytes(buf[:chunk_size]))
            del buf[:chunk_size]
    if buf or not chunks:
        emit(bytes(buf))
    return FileManifest(file_hash=whole.hexdigest(), size=size, chunk_size=chunk_size, chunks=chunks, format=fmt,
                        media_type=media_type, filename=filename, edition_id=edition_id, role=role)


def parse_file_manifest(doc: object, limits: Limits, *, expected_hash: str | None = None) -> FileManifest:
    """Validate an untrusted manifest received from a peer."""
    if len(canonical_json(doc)) > limits.max_manifest_bytes:
        raise LimitExceeded("manifest exceeds the configured size limit", code="manifest_too_large")
    try:
        manifest = FileManifest.model_validate(doc)
    except Exception as exc:
        raise ProtocolError("malformed manifest", code="bad_manifest") from exc
    manifest.check_limits(limits)
    if expected_hash is not None and manifest.file_hash != expected_hash:
        raise IntegrityFailure("manifest describes a different file than the one requested")
    return manifest


# ------------------------------------------------------------ publications
class Contributor(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(max_length=300)
    role: str = Field(default="author", max_length=60)


class PublisherRef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(max_length=120)        # self-asserted
    key: str = Field(max_length=64)          # Ed25519 public key, base64url
    key_id: str = Field(max_length=64)


class ManifestSignature(BaseModel):
    model_config = ConfigDict(extra="forbid")
    alg: Literal["ed25519"] = "ed25519"
    key_id: str = Field(max_length=64)
    value: str = Field(max_length=128)


class PublicationManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    manifest_version: Literal[1] = 1
    protocol_min: int = Field(default=PROTOCOL_VERSION, ge=1)
    publication_id: str = Field(max_length=80)
    work_id: str = Field(max_length=80)
    edition_id: str = Field(max_length=80)
    edition_number: int = Field(ge=1)
    edition_label: str = Field(default="", max_length=120)
    previous_edition_id: str | None = Field(default=None, max_length=80)
    previous_publication_id: str | None = Field(default=None, max_length=80)
    previous_manifest_id: str | None = Field(default=None, max_length=64)
    relation: str = Field(default="", max_length=40)
    revision_notes: str = Field(default="", max_length=4000)
    title: str = Field(max_length=500)
    subtitle: str = Field(default="", max_length=500)
    description: str = Field(default="", max_length=4000)
    contributors: list[Contributor] = Field(default_factory=list, max_length=100)
    language: str = Field(default="", max_length=80)
    publication_date: str = Field(default="", max_length=80)
    isbn: str = Field(default="", max_length=80)
    doi: str = Field(default="", max_length=80)
    subjects: list[str] = Field(default_factory=list, max_length=50)
    licence: str = Field(max_length=500)
    rights_statement: str = Field(default="", max_length=2000)
    accessibility: str = Field(default="", max_length=4000)
    cover: FileManifest | None = None
    files: list[FileManifest] = Field(min_length=1, max_length=64)
    published_at: str = Field(max_length=40)
    publisher: PublisherRef | None = None
    signature: ManifestSignature | None = None

    @model_validator(mode="after")
    def _ids(self) -> "PublicationManifest":
        for value in (self.publication_id, self.work_id, self.edition_id):
            if not is_safe_id(value):
                raise ValueError("bad identifier")
        return self

    def signing_payload(self) -> bytes:
        return canonical_json(self.model_dump(exclude={"signature"}))

    @property
    def manifest_id(self) -> str:
        """Hash of everything except the signature: identifies this exact edition."""
        return sha256_hex(self.signing_payload())

    def sign_with(self, publisher: PublisherIdentity, name: str) -> "PublicationManifest":
        self.publisher = PublisherRef(name=clean_text(name, 120), key=b64e(publisher.public_raw), key_id=publisher.id)
        self.signature = None
        self.signature = ManifestSignature(
            key_id=publisher.id, value=b64e(publisher.sign("publication-manifest", self.signing_payload())))
        return self

    def all_files(self) -> list[FileManifest]:
        return ([self.cover] if self.cover else []) + list(self.files)


class SignatureReport(BaseModel):
    """Precisely what was (and was not) checked about a publication manifest."""

    signed: bool
    signature_valid: bool
    key_id: str = ""
    publisher_name: str = ""
    key_previously_pinned: bool = False
    statements: list[str] = Field(default_factory=list)


def check_publication(manifest: PublicationManifest, *, pinned: dict | None = None) -> SignatureReport:
    statements = ["The manifest is well-formed and lists a SHA-256 hash for every file and chunk."]
    if manifest.signature is None or manifest.publisher is None:
        statements.append("The manifest is not signed. Nothing links it to any publisher key.")
        return SignatureReport(signed=False, signature_valid=False, statements=statements)
    try:
        raw = b64d(manifest.publisher.key)
        ok = (key_id(raw) == manifest.publisher.key_id == manifest.signature.key_id
              and verify(raw, "publication-manifest", manifest.signing_payload(), b64d(manifest.signature.value)))
    except Exception:
        ok = False
    report = SignatureReport(signed=True, signature_valid=ok, key_id=manifest.publisher.key_id,
                             publisher_name=clean_text(manifest.publisher.name, 120),
                             key_previously_pinned=bool(pinned))
    if not ok:
        statements.append("The signature does NOT match the manifest. Treat this publication as tampered with.")
    else:
        statements.append("The signature matches: the holder of the publisher key " +
                          manifest.publisher.key_id[:8].upper() + "… approved exactly this manifest.")
        statements.append("The publisher name is self-declared. A valid signature does not prove who holds the key, "
                          "their legal identity, or any right to publish the work.")
        if pinned:
            statements.append("This is the same key you previously recorded for “" + str(pinned.get("name", "")) + "”.")
        else:
            statements.append("You have not seen this publisher key before. Compare its fingerprint with the publisher "
                              "through another channel before relying on it.")
    statements.append("File contents are checked against these hashes during download. Matching hashes show the bytes "
                      "are the ones described — not that they are safe, lawful or accurate.")
    report.statements = statements
    return report


def parse_publication(doc: object, limits: Limits) -> PublicationManifest:
    if len(canonical_json(doc)) > limits.max_manifest_bytes:
        raise LimitExceeded("manifest exceeds the configured size limit", code="manifest_too_large")
    try:
        manifest = PublicationManifest.model_validate(doc)
    except Exception as exc:
        raise ProtocolError("malformed publication manifest", code="bad_manifest") from exc
    for f in manifest.all_files():
        f.check_limits(limits)
    return manifest


__all__ = ["ChunkRef", "FileManifest", "PublicationManifest", "SignatureReport", "build_file_manifest",
           "check_publication", "parse_file_manifest", "parse_publication", "InvalidInput"]
