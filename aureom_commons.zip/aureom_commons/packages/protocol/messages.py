"""Peer protocol messages (version 1).

Every message is a JSON object with a ``t`` discriminator, validated with
Pydantic before any handler sees it.  Unknown fields are rejected.  See
docs/PROTOCOL.md for the narrative specification.
"""
from __future__ import annotations

from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

from ..domain.errors import ProtocolError
from ..identity.keys import Endorsement, RotationStatement
from .manifest import PROTOCOL_VERSION, SUPPORTED_PROTOCOLS

Id = Annotated[str, Field(pattern=r"^[A-Za-z0-9_\-]{1,80}$")]
Hash = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]


class _Msg(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Scope(_Msg):
    """The authority under which a file is requested."""

    kind: Literal["collection", "public", "device"]
    id: Id = "-"


class Hello(_Msg):
    t: Literal["hello"] = "hello"
    versions: list[int] = Field(default_factory=lambda: list(SUPPORTED_PROTOCOLS), max_length=16)
    device_name: str = Field(default="", max_length=120)       # a label, not an identity
    endorsement: Endorsement | None = None
    agent: str = Field(default="aureom-commons/0.1", max_length=60)


class HelloAck(_Msg):
    t: Literal["hello_ack"] = "hello_ack"
    version: int = PROTOCOL_VERSION
    device_name: str = Field(default="", max_length=120)
    endorsement: Endorsement | None = None
    peer_state: Literal["trusted", "pending", "anonymous"] = "anonymous"
    rotation: RotationStatement | None = None


class Ok(_Msg):
    t: Literal["ok"] = "ok"
    data: dict[str, Any] = Field(default_factory=dict)


class Error(_Msg):
    t: Literal["error"] = "error"
    code: str = Field(max_length=60)
    message: str = Field(default="", max_length=300)


class ChunkHeader(_Msg):
    t: Literal["chunk"] = "chunk"
    index: int
    size: int


# ---------------------------------------------------------------- requests
class Ping(_Msg):
    t: Literal["ping"] = "ping"


class PairRequest(_Msg):
    t: Literal["pair_request"] = "pair_request"
    token: str = Field(max_length=128)
    device_cert: str = Field(max_length=4096)
    device_name: str = Field(default="", max_length=120)
    endorsement: Endorsement
    addresses: list[str] = Field(default_factory=list, max_length=8)
    relay: str = Field(default="", max_length=255)


class PairConfirm(_Msg):
    t: Literal["pair_confirm"] = "pair_confirm"
    token: str = Field(max_length=128)


class ListShared(_Msg):
    t: Literal["list_shared"] = "list_shared"


class InvitationResponse(_Msg):
    t: Literal["invitation_response"] = "invitation_response"
    collection_id: Id
    accept: bool


class GetCollection(_Msg):
    t: Literal["get_collection"] = "get_collection"
    collection_id: Id
    known_version: int = Field(default=0, ge=0)


class GetManifest(_Msg):
    t: Literal["get_manifest"] = "get_manifest"
    scope: Scope
    file_hash: Hash
    known_version: int = Field(default=0, ge=0)


class GetChunk(_Msg):
    t: Literal["get_chunk"] = "get_chunk"
    scope: Scope
    file_hash: Hash
    index: int = Field(ge=0)
    chunk_size: int = Field(ge=16 * 1024, le=4 * 1024 * 1024)
    known_version: int = Field(default=0, ge=0)


class PublicCatalogue(_Msg):
    t: Literal["public_catalogue"] = "public_catalogue"
    query: str = Field(default="", max_length=200)
    offset: int = Field(default=0, ge=0)
    limit: int = Field(default=50, ge=1, le=100)


class GetPublication(_Msg):
    t: Literal["get_publication"] = "get_publication"
    publication_id: Id


class Propose(_Msg):
    """A member asks the owner to change a collection."""

    t: Literal["propose"] = "propose"
    collection_id: Id
    op: Literal["add_item", "update_collection", "share_annotation", "unshare_annotation", "set_member", "revoke_member"]
    payload: dict[str, Any] = Field(default_factory=dict)
    base: str = Field(default="", max_length=64)       # the 'updated_at' the proposer last saw
    known_version: int = Field(default=0, ge=0)


class SyncDigest(_Msg):
    t: Literal["sync_digest"] = "sync_digest"


class SyncFetch(_Msg):
    t: Literal["sync_fetch"] = "sync_fetch"
    keys: list[tuple[str, str]] = Field(max_length=2000)


class SyncPush(_Msg):
    t: Literal["sync_push"] = "sync_push"
    records: list[dict[str, Any]] = Field(max_length=500)
    conflicts: list[dict[str, Any]] = Field(default_factory=list, max_length=200)   # so both devices can review them


class KeyRotation(_Msg):
    t: Literal["key_rotation"] = "key_rotation"
    statement: RotationStatement


Request = Annotated[
    Union[Ping, PairRequest, PairConfirm, ListShared, InvitationResponse, GetCollection, GetManifest, GetChunk,
          PublicCatalogue, GetPublication, Propose, SyncDigest, SyncFetch, SyncPush, KeyRotation],
    Field(discriminator="t"),
]
Response = Annotated[Union[Ok, Error, ChunkHeader, HelloAck], Field(discriminator="t")]

_REQUEST = TypeAdapter(Request)
_RESPONSE = TypeAdapter(Response)


def parse_request(raw: bytes):
    try:
        return _REQUEST.validate_json(raw)
    except Exception as exc:
        raise ProtocolError("malformed request", code="bad_message") from exc


def parse_response(raw: bytes):
    try:
        return _RESPONSE.validate_json(raw)
    except Exception as exc:
        raise ProtocolError("malformed response", code="bad_message") from exc


def parse_hello(raw: bytes) -> Hello:
    try:
        return Hello.model_validate_json(raw)
    except Exception as exc:
        raise ProtocolError("malformed hello", code="bad_message") from exc


def negotiate(versions: list[int]) -> int:
    common = sorted(set(versions) & set(SUPPORTED_PROTOCOLS))
    if not common:
        raise ProtocolError("no common protocol version", code="version_mismatch")
    return common[-1]


ALL_MESSAGES = [Hello, HelloAck, Ok, Error, ChunkHeader, Ping, PairRequest, PairConfirm, ListShared,
                InvitationResponse, GetCollection, GetManifest, GetChunk, PublicCatalogue, GetPublication, Propose,
                SyncDigest, SyncFetch, SyncPush, KeyRotation]
