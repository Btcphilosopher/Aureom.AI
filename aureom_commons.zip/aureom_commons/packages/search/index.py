"""Local full-text and metadata search (SQLite FTS5).

The index lives in the catalogue database.  In an encrypted library that
database is itself encrypted at rest, so no searchable text is left readable
when the library is locked.  Per-edition ``index_mode`` controls what is
indexed for sensitive documents: ``full`` (metadata + text), ``metadata``
(no document text) or ``none``.
"""
from __future__ import annotations

import re

from ..domain.models import Metadata
from ..domain.util import now_iso
from ..storage.db import Database

_TOKEN = re.compile(r"[\w][\w'’\-]*", re.UNICODE)
_FIELDS = {"title", "subtitle", "authors", "tags", "description", "body"}


def fts_query(text: str, field: str | None = None) -> str:
    """Turn free user text into a safe FTS5 expression (every token quoted,
    prefix-matched, AND-ed).  User input can never inject FTS operators."""
    tokens = _TOKEN.findall(text or "")[:16]
    if not tokens:
        return ""
    expr = " ".join('"' + t.replace('"', "") + '"*' for t in tokens)
    if field in _FIELDS:
        return f"{field} : ({expr})"
    return expr


class SearchService:
    def __init__(self, db: Database):
        self.db = db

    def index_edition(self, edition_id: str, work_id: str, meta: Metadata, fmt: str, *, body: str | None,
                      index_mode: str = "full") -> None:
        with self.db.tx() as c:
            old = c.execute("SELECT body FROM search_index WHERE edition_id=?", (edition_id,)).fetchone()
            if body is None:
                body = old["body"] if old else ""
            c.execute("DELETE FROM search_index WHERE edition_id=?", (edition_id,))
            c.execute(
                "INSERT INTO edition_index (edition_id, work_id, title, subtitle, authors, publisher, language, "
                "publication_date, format, tags, rights, licence, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(edition_id) DO UPDATE SET title=excluded.title, subtitle=excluded.subtitle, "
                "authors=excluded.authors, publisher=excluded.publisher, language=excluded.language, "
                "publication_date=excluded.publication_date, format=excluded.format, tags=excluded.tags, "
                "rights=excluded.rights, licence=excluded.licence, updated_at=excluded.updated_at",
                (edition_id, work_id, meta.title, meta.subtitle, "; ".join(meta.authors), meta.publisher,
                 meta.language, meta.publication_date, fmt, "; ".join(meta.tags), meta.rights, meta.licence, now_iso()))
            if index_mode == "none":
                return
            c.execute(
                "INSERT INTO search_index (edition_id, title, subtitle, authors, tags, description, body) "
                "VALUES (?,?,?,?,?,?,?)",
                (edition_id, meta.title, meta.subtitle, " ; ".join(meta.authors + meta.contributors),
                 " ; ".join(meta.tags), meta.description, body if index_mode == "full" else ""))

    def remove(self, edition_id: str) -> None:
        with self.db.tx() as c:
            c.execute("DELETE FROM search_index WHERE edition_id=?", (edition_id,))
            c.execute("DELETE FROM edition_index WHERE edition_id=?", (edition_id,))

    def body_text(self, edition_id: str) -> str:
        return self.db.scalar("SELECT body FROM search_index WHERE edition_id=?", (edition_id,), "") or ""

    def candidates(self, text: str = "", *, title: str = "", author: str = "", language: str = "", fmt: str = "",
                   tag: str = "", rights: str = "", date_from: str = "", date_to: str = "",
                   limit: int = 500) -> list[dict]:
        """Edition ids matching the textual and column filters, best first.
        Space, collection and availability filters are applied by the caller,
        which knows the user's permissions."""
        where, params = ["e.deleted = 0"], []
        match_parts = [p for p in (fts_query(text), fts_query(title, "title"), fts_query(author, "authors"),
                                   fts_query(tag, "tags")) if p]
        sql = ("SELECT i.edition_id, {snippet} AS snippet, {rank} AS rank FROM edition_index i "
               "JOIN editions e ON e.edition_id = i.edition_id {join} WHERE {where} ORDER BY {order} LIMIT ?")
        if match_parts:
            join = "JOIN search_index s ON s.edition_id = i.edition_id"
            where.append("search_index MATCH ?")
            params.append(" AND ".join(f"({p})" for p in match_parts))
            snippet = "snippet(search_index, 6, '[', ']', ' … ', 14)"
            rank, order = "bm25(search_index, 0, 8.0, 4.0, 6.0, 3.0, 2.0, 1.0)", "rank"
        else:
            join, snippet, rank, order = "", "''", "0", "i.title COLLATE NOCASE"
        if language:
            where.append("i.language LIKE ?")
            params.append(language + "%")
        if fmt:
            where.append("i.format = ?")
            params.append(fmt)
        if rights:
            where.append("(i.rights LIKE ? OR i.licence LIKE ?)")
            params += [f"%{rights}%", f"%{rights}%"]
        if date_from:
            where.append("i.publication_date >= ?")
            params.append(date_from)
        if date_to:
            where.append("i.publication_date != '' AND i.publication_date <= ?")
            params.append(date_to + "￿")
        params.append(limit)
        rows = self.db.query(sql.format(snippet=snippet, rank=rank, join=join, where=" AND ".join(where), order=order),
                             params)
        return [dict(r) for r in rows]

    def facets(self) -> dict[str, list[str]]:
        langs = [r[0] for r in self.db.query("SELECT DISTINCT language FROM edition_index WHERE language != '' ORDER BY 1")]
        fmts = [r[0] for r in self.db.query("SELECT DISTINCT format FROM edition_index ORDER BY 1")]
        tags: set[str] = set()
        for r in self.db.query("SELECT tags FROM edition_index WHERE tags != ''"):
            tags.update(t.strip() for t in r[0].split(";") if t.strip())
        return {"languages": langs, "formats": fmts, "tags": sorted(tags, key=str.lower)}
