"""AUREOM COMMONS — private library and peer publishing."""
__version__ = "0.1.0"

