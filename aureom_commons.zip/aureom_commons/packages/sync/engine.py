"""Metadata synchronisation between one person's own linked devices.

*Only metadata* moves here: catalogue records, user corrections, owned
collections, membership, reading progress and annotations.  File bytes are
replicated separately (and only on request) by the transfer engine.

Every record has a stable identifier and a **version vector**
(``{device_id: counter}``).  Comparing two vectors tells us whether one side
has seen the other's change (no conflict) or the edits were concurrent
(a conflict).  Concurrent edits are never silently discarded:

===================  =======================================================
metadata             merged field by field; a field changed on both devices
                     keeps the later value *and* records the other for review
annotation           edit vs edit → both kept (the loser becomes a marked
                     copy); delete vs edit → the edit survives, flagged
reading progress     one row per device, so devices never overwrite each other
membership           revocation dominates; concurrent permission changes
                     resolve to the intersection (least privilege); flagged
collection           edits merge; delete vs edit → the collection is kept but
                     sharing is *suspended* until the owner decides
edition records      immutable; delete vs any concurrent change → kept, flagged
===================  =======================================================

Merges are deterministic and symmetric, so two devices that exchange the same
pair of records converge on the same result.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from ..domain.models import METADATA_FIELDS, Metadata
from ..domain.util import clean_text, is_safe_id, new_id, now_iso
from ..storage.db import Database

KINDS = ("edition", "metadata", "annotation", "progress", "collection", "member")
VV = dict[str, int]


def compare(a: VV, b: VV) -> str:
    """Return 'equal', 'newer' (a dominates), 'older' (b dominates) or 'concurrent'."""
    a_ahead = any(a.get(k, 0) > b.get(k, 0) for k in a)
    b_ahead = any(b.get(k, 0) > a.get(k, 0) for k in b)
    if a_ahead and b_ahead:
        return "concurrent"
    return "newer" if a_ahead else "older" if b_ahead else "equal"


def merge_vv(a: VV, b: VV) -> VV:
    return {k: max(a.get(k, 0), b.get(k, 0)) for k in set(a) | set(b)}


def _clean_vv(value: Any) -> VV:
    if not isinstance(value, dict) or len(value) > 64:
        return {}
    return {str(k)[:64]: int(v) for k, v in value.items() if isinstance(v, int) and 0 <= v < 2 ** 53}


class SyncEngine:
    def __init__(self, db: Database, catalogue, collections, device_id: str, account_id):
        self.db, self.catalogue, self.collections = db, catalogue, collections
        self.device_id = device_id
        self._account_id = account_id
        self._applying = False

    # ------------------------------------------------------------ tracking
    def touch(self, kind: str, record_id: str) -> None:
        """Called by the services after every local change."""
        if self._applying or kind not in KINDS:
            return
        if kind == "collection" and not self.db.one(
                "SELECT 1 FROM collections WHERE collection_id=? AND is_owner=1", (record_id,)):
            return                    # other people's collections are refreshed from their owner, not synced
        with self.db.tx() as c:
            row = c.execute("SELECT vv FROM sync_state WHERE kind=? AND record_id=?", (kind, record_id)).fetchone()
            vv = json.loads(row["vv"]) if row else {}
            vv[self.device_id] = vv.get(self.device_id, 0) + 1
            self._save_state(kind, record_id, vv)

    def _save_state(self, kind: str, record_id: str, vv: VV, updated_by: str | None = None, ts: str | None = None) -> None:
        self.db.execute(
            "INSERT INTO sync_state (kind, record_id, vv, deleted, updated_at, updated_by) VALUES (?,?,?,0,?,?) "
            "ON CONFLICT(kind, record_id) DO UPDATE SET vv=excluded.vv, updated_at=excluded.updated_at, "
            "updated_by=excluded.updated_by",
            (kind, record_id, json.dumps(vv, sort_keys=True), ts or now_iso(), updated_by or self.device_id))

    def digest(self) -> list[list]:
        return [[r["kind"], r["record_id"], json.loads(r["vv"])] for r in self.db.query(
            "SELECT kind, record_id, vv FROM sync_state ORDER BY kind, record_id")]

    def plan(self, remote_digest: list) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
        """Given the other device's digest: what to fetch and what to push."""
        local = {(k, i): vv for k, i, vv in self.digest()}
        need, push = [], []
        seen = set()
        for entry in remote_digest[:200000]:
            try:
                kind, rid, vv = entry[0], entry[1], _clean_vv(entry[2])
            except (IndexError, TypeError):
                continue
            if kind not in KINDS or not isinstance(rid, str):
                continue
            seen.add((kind, rid))
            relation = compare(local.get((kind, rid), {}), vv)
            if relation in ("older", "concurrent"):
                need.append((kind, rid))
            if relation in ("newer", "concurrent"):
                push.append((kind, rid))
        push += [key for key in local if key not in seen]
        return need, push

    # -------------------------------------------------------------- export
    def export(self, keys: list[tuple[str, str]]) -> list[dict]:
        out = []
        for kind, rid in keys[:2000]:
            state = self.db.one("SELECT * FROM sync_state WHERE kind=? AND record_id=?", (kind, rid))
            if state is None:
                continue
            payload = self._export(kind, rid)
            if payload is None:
                continue
            out.append({"kind": kind, "id": rid, "vv": json.loads(state["vv"]), "updated_at": state["updated_at"],
                        "updated_by": state["updated_by"], "payload": payload})
        return out

    def _export(self, kind: str, rid: str) -> dict | None:
        db = self.db
        if kind == "edition":
            ed = db.one("SELECT e.*, w.origin, w.origin_ref FROM editions e JOIN works w ON w.work_id=e.work_id "
                        "WHERE e.edition_id=?", (rid,))
            if ed is None:
                return None
            imported = db.scalar("SELECT data FROM edition_metadata WHERE edition_id=? AND source IN ('imported','remote') "
                                 "ORDER BY source LIMIT 1", (rid,), "{}")
            return {"work_id": ed["work_id"], "edition_number": ed["edition_number"], "label": ed["label"],
                    "relation": ed["relation"], "previous_edition_id": ed["previous_edition_id"],
                    "revision_notes": ed["revision_notes"], "deleted": bool(ed["deleted"]), "origin": ed["origin"],
                    "origin_ref": ed["origin_ref"], "imported": json.loads(imported),
                    "files": [{"role": f["role"], "content_hash": f["content_hash"], "size": f["size"],
                               "format": f["format"], "media_type": f["media_type"], "filename": f["filename"]}
                              for f in db.query("SELECT * FROM files WHERE edition_id=? AND role!='cover'", (rid,))]}
        if kind == "metadata":
            row = db.one("SELECT data, fvv FROM edition_metadata WHERE edition_id=? AND source='user'", (rid,))
            return {"data": json.loads(row["data"]), "fvv": json.loads(row["fvv"])} if row else {"data": {}, "fvv": {}}
        if kind == "annotation":
            row = db.one("SELECT * FROM annotations WHERE annotation_id=? AND author_account=''", (rid,))
            if row is None:
                return None
            d = dict(row)
            d["locator"] = json.loads(d["locator"])
            d["deleted"] = bool(d["deleted"])
            return d
        if kind == "progress":
            edition_id, _, device = rid.partition(":")
            row = db.one("SELECT * FROM reading_progress WHERE edition_id=? AND device_id=?", (edition_id, device))
            return (dict(row) | {"locator": json.loads(row["locator"])}) if row else None
        if kind == "collection":
            row = db.one("SELECT * FROM collections WHERE collection_id=? AND is_owner=1", (rid,))
            if row is None:
                return None
            return {"name": row["name"], "description": row["description"], "kind": row["kind"],
                    "owner_account": row["owner_account"], "owner_name": row["owner_name"],
                    "permission_version": row["permission_version"], "deleted": bool(row["deleted"]),
                    "access_state": row["access_state"], "created_at": row["created_at"], "updated_at": row["updated_at"],
                    "items": [dict(i) for i in db.query(
                        "SELECT edition_id, added_by, added_at, state FROM collection_items WHERE collection_id=?", (rid,))]}
        if kind == "member":
            cid, _, account = rid.partition(":")
            row = db.one("SELECT * FROM collection_members WHERE collection_id=? AND account_id=?", (cid, account))
            return (dict(row) | {"permissions": json.loads(row["permissions"])}) if row else None
        return None

    # --------------------------------------------------------------- apply
    def apply(self, records: list[dict], from_device: str) -> dict:
        """Merge records received from another of this account's devices."""
        stats = {"applied": 0, "merged": 0, "conflicts": 0, "ignored": 0}
        order = {k: i for i, k in enumerate(KINDS)}
        self._applying = True
        try:
            with self.db.deferred():
                for rec in sorted(records[:2000], key=lambda r: order.get(r.get("kind"), 99)):
                    try:
                        outcome = self._apply_one(rec, from_device)
                    except (KeyError, TypeError, ValueError):
                        outcome = "ignored"
                    stats[outcome] = stats.get(outcome, 0) + 1
        finally:
            self._applying = False
        return stats

    def _conflict(self, kind: str, rid: str, rule: str, local: Any, remote: Any, device: str, field: str = "") -> None:
        cid = hashlib.sha256(json.dumps([kind, rid, rule, field, local, remote], sort_keys=True, default=str)
                             .encode()).hexdigest()[:32]
        self.db.execute(
            "INSERT OR IGNORE INTO sync_conflicts (conflict_id, kind, record_id, field, rule, local_value, remote_value, "
            "remote_device, detected_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (cid, kind, rid, field, rule, json.dumps(local, default=str), json.dumps(remote, default=str), device, now_iso()))

    def _apply_one(self, rec: dict, from_device: str) -> str:
        kind, rid, payload = rec["kind"], rec["id"], rec["payload"]
        if kind not in KINDS or not isinstance(rid, str) or len(rid) > 200 or not isinstance(payload, dict):
            return "ignored"
        remote_vv = _clean_vv(rec.get("vv"))
        state = self.db.one("SELECT * FROM sync_state WHERE kind=? AND record_id=?", (kind, rid))
        local_vv = json.loads(state["vv"]) if state else {}
        relation = compare(local_vv, remote_vv) if state else "older"
        if relation in ("equal", "newer"):
            return "ignored"
        remote_ts = clean_text(rec.get("updated_at"), 40)
        remote_by = clean_text(rec.get("updated_by"), 64) or from_device
        if relation == "older":
            self._write(kind, rid, payload)
            self._save_state(kind, rid, remote_vv, remote_by, remote_ts)
            return "applied"
        # concurrent
        local_payload = self._export(kind, rid) or {}
        remote_wins = (remote_ts, remote_by) > (state["updated_at"], state["updated_by"])
        merged, conflicts = self._merge(kind, rid, local_payload, payload, remote_wins, from_device)
        self._write(kind, rid, merged)
        self._save_state(kind, rid, merge_vv(local_vv, remote_vv), remote_by if remote_wins else state["updated_by"],
                         max(remote_ts, state["updated_at"]))
        return "conflicts" if conflicts else "merged"

    # --------------------------------------------------------------- merge
    def _merge(self, kind: str, rid: str, local: dict, remote: dict, remote_wins: bool, device: str) -> tuple[dict, int]:
        conflicts = 0
        if kind == "metadata":
            data, fvv = dict(local.get("data", {})), dict(local.get("fvv", {}))
            for field in set(local.get("fvv", {})) | set(remote.get("fvv", {})):
                lv, rv = local.get("fvv", {}).get(field, {}), _clean_vv(remote.get("fvv", {}).get(field, {}))
                rel = compare(lv, rv)
                lval, rval = local.get("data", {}).get(field), remote.get("data", {}).get(field)
                take_remote = rel == "older"
                if rel == "concurrent" and lval != rval:
                    conflicts += 1
                    self._conflict(kind, rid, "concurrent-metadata-edit", lval, rval, device, field)
                    take_remote = remote_wins
                if take_remote:
                    if rval is None:
                        data.pop(field, None)
                    else:
                        data[field] = rval
                fvv[field] = merge_vv(lv, rv)
            return {"data": data, "fvv": fvv}, conflicts
        if kind == "annotation":
            l_del, r_del = bool(local.get("deleted")), bool(remote.get("deleted"))
            if l_del != r_del:
                survivor = dict(remote if l_del else local)
                survivor.update(deleted=False, status="needs_review",
                                review_note="This annotation was deleted on one device and edited on another. "
                                            "The edited version was kept.")
                self._conflict(kind, rid, "annotation-delete-vs-edit", local.get("body"), remote.get("body"), device)
                return survivor, 1
            if l_del and r_del:
                return local, 0
            same = all(local.get(k) == remote.get(k) for k in ("body", "locator", "colour", "shared_in", "kind"))
            if same:
                return local, 0
            winner, loser = (remote, local) if remote_wins else (local, remote)
            copy_id = hashlib.sha256(json.dumps([rid, loser.get("body"), loser.get("locator")], sort_keys=True)
                                     .encode()).hexdigest()[:32]
            copy = dict(loser)
            copy.update(annotation_id=copy_id, status="needs_review", migrated_from=rid, deleted=False, shared_in="",
                        review_note="Conflicting edit made on another device at the same time. Both versions were kept.")
            self._write("annotation", copy_id, copy)
            self._save_state("annotation", copy_id, {self.device_id: 1})     # the kept copy is a record in its own right
            self._conflict(kind, rid, "concurrent-annotation-edit", local.get("body"), remote.get("body"), device)
            return dict(winner), 1
        if kind == "member":
            l_rev, r_rev = local.get("status") == "revoked", remote.get("status") == "revoked"
            merged = dict(remote if remote_wins else local)
            lp, rp = set(local.get("permissions") or []), set(remote.get("permissions") or [])
            if l_rev or r_rev:
                merged.update(status="revoked", revoked_at=local.get("revoked_at") or remote.get("revoked_at") or now_iso())
                if l_rev != r_rev:
                    conflicts += 1
                    self._conflict(kind, rid, "revocation-dominates", local.get("status"), remote.get("status"), device)
            elif lp != rp:
                merged["permissions"] = sorted(lp & rp)
                conflicts += 1
                self._conflict(kind, rid, "concurrent-permission-change", sorted(lp), sorted(rp), device)
            merged["permission_version"] = max(int(local.get("permission_version") or 0),
                                               int(remote.get("permission_version") or 0)) + 1
            return merged, conflicts
        if kind == "collection":
            merged = dict(remote if remote_wins else local)
            for field in ("name", "description"):
                if local.get(field) != remote.get(field):
                    conflicts += 1
                    self._conflict(kind, rid, "concurrent-collection-edit", local.get(field), remote.get(field), device, field)
            items = {i["edition_id"]: dict(i) for i in remote.get("items") or [] if isinstance(i, dict) and i.get("edition_id")}
            for i in local.get("items") or []:
                other = items.get(i["edition_id"])
                if other is None or (other.get("state") == "removed" and i.get("state") != "removed"):
                    items[i["edition_id"]] = dict(i)        # an item kept anywhere stays
            merged["items"] = list(items.values())
            merged["permission_version"] = max(int(local.get("permission_version") or 0),
                                               int(remote.get("permission_version") or 0)) + 1
            if bool(local.get("deleted")) != bool(remote.get("deleted")):
                conflicts += 1
                merged.update(deleted=False, access_state="suspended")
                self._conflict(kind, rid, "collection-delete-vs-edit", {"deleted": bool(local.get("deleted"))},
                               {"deleted": bool(remote.get("deleted"))}, device)
            elif "suspended" in (local.get("access_state"), remote.get("access_state")):
                merged["access_state"] = "suspended"
            return merged, conflicts
        if kind == "edition":
            merged = dict(local or remote)
            if bool(local.get("deleted")) != bool(remote.get("deleted")):
                conflicts += 1
                merged["deleted"] = False
                self._conflict(kind, rid, "edition-delete-vs-change", {"deleted": bool(local.get("deleted"))},
                               {"deleted": bool(remote.get("deleted"))}, device)
            return merged, conflicts
        return dict(remote if remote_wins else local), 0          # progress: single writer per record

    # --------------------------------------------------------------- write
    def _write(self, kind: str, rid: str, p: dict) -> None:
        db, ts = self.db, now_iso()
        if kind == "edition":
            if not is_safe_id(rid) or not is_safe_id(p.get("work_id")):
                return
            existing = db.one("SELECT edition_id FROM editions WHERE edition_id=?", (rid,))
            files = [f for f in p.get("files") or [] if isinstance(f, dict)]
            primary = next((f for f in files if f.get("role") == "primary"), None)
            if existing is None:
                if primary is None or p.get("deleted"):
                    return
                from ..domain.models import FORMATS

                self.catalogue.register_edition(
                    content_hash=str(primary.get("content_hash"))[:64], size=int(primary.get("size") or 0),
                    filename=primary.get("filename") or "file",
                    fmt=primary.get("format") if primary.get("format") in FORMATS else "bin",
                    metadata=Metadata.model_validate(p.get("imported") or {}), work_id=p["work_id"], edition_id=rid,
                    label=p.get("label") or "", relation=p.get("relation") or "",
                    previous_edition_id=p.get("previous_edition_id") if db.one(
                        "SELECT 1 FROM editions WHERE edition_id=?", (p.get("previous_edition_id"),)) else None,
                    revision_notes=p.get("revision_notes") or "", origin=p.get("origin") if p.get("origin") in
                    ("local", "shared", "public") else "local", origin_ref=clean_text(p.get("origin_ref"), 80),
                    available=False, edition_number=int(p.get("edition_number") or 1), import_source="sync:own-device")
                # bytes already here? (e.g. the same file was imported on both devices)
                if self.catalogue.store.has(str(primary.get("content_hash"))):
                    db.execute("UPDATE files SET available=1 WHERE edition_id=? AND role='primary'", (rid,))
            else:
                db.execute("UPDATE editions SET deleted=? WHERE edition_id=?", (int(bool(p.get("deleted"))), rid))
                if p.get("deleted"):
                    self.catalogue.search.remove(rid)
                else:
                    self.catalogue.reindex(rid)
        elif kind == "metadata":
            if not db.one("SELECT 1 FROM editions WHERE edition_id=?", (rid,)):
                return
            data = {k: v for k, v in (p.get("data") or {}).items() if k in METADATA_FIELDS}
            clean = Metadata(**data).model_dump()
            data = {k: clean[k] for k in data}
            db.execute("INSERT INTO edition_metadata (edition_id, source, data, fvv, updated_at) VALUES (?,?,?,?,?) "
                       "ON CONFLICT(edition_id, source) DO UPDATE SET data=excluded.data, fvv=excluded.fvv, "
                       "updated_at=excluded.updated_at",
                       (rid, "user", json.dumps(data), json.dumps({k: _clean_vv(v) for k, v in (p.get("fvv") or {}).items()
                                                                   if k in METADATA_FIELDS}), ts))
            if db.one("SELECT 1 FROM editions WHERE edition_id=? AND deleted=0", (rid,)):
                self.catalogue.reindex(rid)
        elif kind == "annotation":
            if not is_safe_id(rid) or p.get("kind") not in ("bookmark", "highlight", "note"):
                return
            db.execute(
                "INSERT INTO annotations (annotation_id, edition_id, content_hash, kind, locator, body, colour, status, "
                "migrated_from, review_note, shared_in, created_at, updated_at, deleted) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(annotation_id) DO UPDATE SET locator=excluded.locator, body=excluded.body, "
                "colour=excluded.colour, status=excluded.status, review_note=excluded.review_note, "
                "shared_in=excluded.shared_in, updated_at=excluded.updated_at, deleted=excluded.deleted",
                (rid, clean_text(p.get("edition_id"), 80), clean_text(p.get("content_hash"), 64), p["kind"],
                 json.dumps(p.get("locator") if isinstance(p.get("locator"), dict) else {})[:4000],
                 clean_text(p.get("body"), 20000, single_line=False), clean_text(p.get("colour"), 20) or "copper",
                 p.get("status") if p.get("status") in ("ok", "needs_review", "orphaned") else "ok",
                 clean_text(p.get("migrated_from"), 80), clean_text(p.get("review_note"), 500),
                 clean_text(p.get("shared_in"), 80), clean_text(p.get("created_at"), 40) or ts,
                 clean_text(p.get("updated_at"), 40) or ts, int(bool(p.get("deleted")))))
        elif kind == "progress":
            edition_id, _, device = rid.partition(":")
            if device == self.device_id:
                return                          # nobody else may write this device's position
            db.execute(
                "INSERT INTO reading_progress (edition_id, device_id, locator, fraction, updated_at) VALUES (?,?,?,?,?) "
                "ON CONFLICT(edition_id, device_id) DO UPDATE SET locator=excluded.locator, fraction=excluded.fraction, "
                "updated_at=excluded.updated_at",
                (edition_id, device, json.dumps(p.get("locator") if isinstance(p.get("locator"), dict) else {})[:2000],
                 min(1.0, max(0.0, float(p.get("fraction") or 0))), clean_text(p.get("updated_at"), 40) or ts))
        elif kind == "collection":
            if not is_safe_id(rid) or p.get("owner_account") != self._account_id():
                return
            db.execute(
                "INSERT INTO collections (collection_id, name, description, kind, owner_account, is_owner, owner_name, "
                "permission_version, access_state, created_at, updated_at, deleted) VALUES (?,?,?,?,?,1,?,?,?,?,?,?) "
                "ON CONFLICT(collection_id) DO UPDATE SET name=excluded.name, description=excluded.description, "
                "permission_version=MAX(collections.permission_version, excluded.permission_version), "
                "access_state=excluded.access_state, updated_at=excluded.updated_at, deleted=excluded.deleted",
                (rid, clean_text(p.get("name"), 120) or "Collection", clean_text(p.get("description"), 2000, single_line=False),
                 p.get("kind") if p.get("kind") in ("local", "shared") else "shared", p["owner_account"],
                 clean_text(p.get("owner_name"), 80), int(p.get("permission_version") or 1),
                 p.get("access_state") if p.get("access_state") in ("active", "suspended") else "active",
                 clean_text(p.get("created_at"), 40) or ts, clean_text(p.get("updated_at"), 40) or ts,
                 int(bool(p.get("deleted")))))
            for item in (p.get("items") or [])[:5000]:
                if isinstance(item, dict) and is_safe_id(item.get("edition_id")):
                    db.execute("INSERT INTO collection_items (collection_id, edition_id, added_by, added_at, state) "
                               "VALUES (?,?,?,?,?) ON CONFLICT(collection_id, edition_id) DO UPDATE SET state=excluded.state",
                               (rid, item["edition_id"], clean_text(item.get("added_by"), 64),
                                clean_text(item.get("added_at"), 40) or ts,
                                item.get("state") if item.get("state") in ("active", "proposed", "removed") else "active"))
        elif kind == "member":
            cid, _, account = rid.partition(":")
            if not db.one("SELECT 1 FROM collections WHERE collection_id=? AND is_owner=1", (cid,)):
                return
            from ..permissions.collections import normalise_permissions

            status = p.get("status") if p.get("status") in ("invited", "active", "revoked", "declined") else "revoked"
            version = int(p.get("permission_version") or 1)
            db.execute(
                "INSERT INTO collection_members (collection_id, account_id, display_name, permissions, status, "
                "permission_version, invited_at, joined_at, revoked_at) VALUES (?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(collection_id, account_id) DO UPDATE SET display_name=excluded.display_name, "
                "permissions=excluded.permissions, status=excluded.status, permission_version=excluded.permission_version, "
                "joined_at=excluded.joined_at, revoked_at=excluded.revoked_at",
                (cid, account, clean_text(p.get("display_name"), 80), json.dumps(normalise_permissions(p.get("permissions") or [])),
                 status, version, clean_text(p.get("invited_at"), 40) or ts, p.get("joined_at"), p.get("revoked_at")))
            db.execute("UPDATE collections SET permission_version=MAX(permission_version, ?) WHERE collection_id=?",
                       (version, cid))

    # ----------------------------------------------------------- conflicts
    def export_conflicts(self, since: str) -> list[dict]:
        return [dict(r) for r in self.db.query(
            "SELECT conflict_id, kind, record_id, field, rule, local_value, remote_value FROM sync_conflicts "
            "WHERE detected_at >= ? AND resolved_at IS NULL LIMIT 200", (since,))]

    def import_conflicts(self, conflicts: list[dict], from_device: str) -> None:
        """The device that detected a conflict tells the other one, so the
        competing value can be reviewed on either device."""
        for c in conflicts[:200]:
            if not isinstance(c, dict) or c.get("kind") not in KINDS or not is_safe_id(c.get("conflict_id")):
                continue
            self.db.execute(
                "INSERT OR IGNORE INTO sync_conflicts (conflict_id, kind, record_id, field, rule, local_value, "
                "remote_value, remote_device, detected_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (c["conflict_id"], c["kind"], clean_text(c.get("record_id"), 200), clean_text(c.get("field"), 60),
                 clean_text(c.get("rule"), 60), clean_text(c.get("remote_value"), 4000, single_line=False),
                 clean_text(c.get("local_value"), 4000, single_line=False), from_device, now_iso()))

    def conflicts(self, include_resolved: bool = False) -> list[dict]:
        rows = self.db.query("SELECT * FROM sync_conflicts" + ("" if include_resolved else " WHERE resolved_at IS NULL")
                             + " ORDER BY detected_at DESC")
        out = []
        for r in rows:
            d = dict(r)
            d["local_value"] = json.loads(d["local_value"]) if d["local_value"] else None
            d["remote_value"] = json.loads(d["remote_value"]) if d["remote_value"] else None
            out.append(d)
        return out

    def resolve(self, conflict_id: str, choice: str) -> None:
        """``choice``: keep_current | use_other | delete | restore."""
        row = self.db.one("SELECT * FROM sync_conflicts WHERE conflict_id=?", (conflict_id,))
        if row is None:
            return
        kind, rid = row["kind"], row["record_id"]
        other = json.loads(row["remote_value"]) if row["remote_value"] else None
        mine = json.loads(row["local_value"]) if row["local_value"] else None
        if kind == "metadata" and choice == "use_other":
            current = self.catalogue.effective_metadata(rid).model_dump().get(row["field"])
            self.catalogue.update_user_metadata(rid, {row["field"]: mine if current == other else other})
        elif kind == "collection" and row["rule"] == "collection-delete-vs-edit":
            if choice == "delete":
                self.collections.delete(rid)
            else:
                self.db.execute("UPDATE collections SET access_state='active', updated_at=? WHERE collection_id=?",
                                (now_iso(), rid))
                self.touch("collection", rid)
        elif kind == "collection" and choice == "use_other" and row["field"] in ("name", "description"):
            current = self.db.scalar(f"SELECT {row['field']} FROM collections WHERE collection_id=?", (rid,))
            self.collections.update(rid, **{row["field"]: mine if current == other else other})
        self.db.execute("UPDATE sync_conflicts SET resolved_at=?, resolution=? WHERE conflict_id=?",
                        (now_iso(), choice, conflict_id))


__all__ = ["SyncEngine", "compare", "merge_vv", "new_id"]
