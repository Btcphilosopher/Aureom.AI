"""Cryptographic identities.

Four things are kept deliberately separate:

* **Device identity** — an Ed25519 key and a self-signed X.509 certificate
  used for mutually-authenticated TLS.  The *device id* is a hash of the
  public key, so it cannot be chosen or spoofed; a device *name* is only a
  label.
* **Account identity** — an Ed25519 key representing one person's
  application account.  It endorses that person's devices.  Collection
  permissions are granted to accounts.
* **Publisher identity** — an independent Ed25519 key used only to sign
  publication manifests.  It is self-issued: a valid signature shows that
  the holder of that key signed those bytes, and nothing about who the
  holder legally is.
* **Permissions** — recorded by collection owners against account ids
  (see ``aureom.permissions``); never derived from names.
"""
from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.x509.oid import NameOID
from pydantic import BaseModel, ConfigDict

from ..domain.errors import IntegrityFailure, InvalidInput
from ..domain.util import b32id, b64d, b64e, canonical_json, now_iso

_DOMAIN = b"aureom-commons/v1/"


def _raw_public(key: Ed25519PublicKey) -> bytes:
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def _raw_private(key: Ed25519PrivateKey) -> bytes:
    return key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())


def sign(key: Ed25519PrivateKey, purpose: str, payload: bytes) -> bytes:
    """Ed25519 signature with a purpose prefix (domain separation), so a
    signature made for one kind of statement can never be replayed as another."""
    return key.sign(_DOMAIN + purpose.encode() + b"\n" + payload)


def verify(public_key_raw: bytes, purpose: str, payload: bytes, signature: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(public_key_raw).verify(signature, _DOMAIN + purpose.encode() + b"\n" + payload)
        return True
    except (InvalidSignature, ValueError):
        return False


def key_id(public_key_raw: bytes) -> str:
    return b32id(public_key_raw)


def cert_public_key_raw(cert_der: bytes) -> bytes:
    try:
        cert = x509.load_der_x509_certificate(cert_der)
    except ValueError as exc:
        raise InvalidInput("malformed device certificate") from exc
    key = cert.public_key()
    if not isinstance(key, Ed25519PublicKey):
        raise InvalidInput("device certificates must use Ed25519")
    return _raw_public(key)


def device_id_from_cert(cert_der: bytes) -> str:
    """The device id is the fingerprint of the certificate's public key."""
    return key_id(cert_public_key_raw(cert_der))


@dataclass
class DeviceIdentity:
    private_key: Ed25519PrivateKey
    cert_der: bytes

    @property
    def device_id(self) -> str:
        return device_id_from_cert(self.cert_der)

    @property
    def public_raw(self) -> bytes:
        return _raw_public(self.private_key.public_key())

    @classmethod
    def generate(cls) -> "DeviceIdentity":
        key = Ed25519PrivateKey.generate()
        # The subject must be unique per key: OpenSSL finds trust anchors by
        # subject name, so two pinned devices must never share one.
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, key_id(_raw_public(key.public_key())))])
        start = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1)
        cert = (
            x509.CertificateBuilder()
            .subject_name(name).issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(start)
            .not_valid_after(start + dt.timedelta(days=365 * 30))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .sign(key, None)
        )
        return cls(key, cert.public_bytes(serialization.Encoding.DER))

    def to_secret(self) -> bytes:
        return json.dumps({"key": b64e(_raw_private(self.private_key)), "cert": b64e(self.cert_der)}).encode()

    @classmethod
    def from_secret(cls, blob: bytes) -> "DeviceIdentity":
        doc = json.loads(blob)
        return cls(Ed25519PrivateKey.from_private_bytes(b64d(doc["key"])), b64d(doc["cert"]))

    def cert_pem(self) -> bytes:
        return x509.load_der_x509_certificate(self.cert_der).public_bytes(serialization.Encoding.PEM)

    def key_pem_encrypted(self, password: bytes) -> bytes:
        return self.private_key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
            serialization.BestAvailableEncryption(password))

    def sign(self, purpose: str, payload: bytes) -> bytes:
        return sign(self.private_key, purpose, payload)


class Endorsement(BaseModel):
    """An account's statement that a device belongs to it."""

    model_config = ConfigDict(extra="forbid")
    account_id: str
    account_key: str
    device_id: str
    issued_at: str
    signature: str

    def _payload(self) -> bytes:
        return canonical_json({"account_id": self.account_id, "device_id": self.device_id, "issued_at": self.issued_at})

    def is_valid_for(self, device_id: str) -> bool:
        try:
            raw = b64d(self.account_key)
            return (self.device_id == device_id and key_id(raw) == self.account_id
                    and verify(raw, "device-endorsement", self._payload(), b64d(self.signature)))
        except Exception:
            return False


@dataclass
class SigningIdentity:
    """Shared shape of account and publisher keys."""

    private_key: Ed25519PrivateKey

    @classmethod
    def generate(cls):
        return cls(Ed25519PrivateKey.generate())

    @property
    def public_raw(self) -> bytes:
        return _raw_public(self.private_key.public_key())

    @property
    def id(self) -> str:
        return key_id(self.public_raw)

    def to_secret(self) -> bytes:
        return _raw_private(self.private_key)

    @classmethod
    def from_secret(cls, blob: bytes):
        return cls(Ed25519PrivateKey.from_private_bytes(blob))

    def sign(self, purpose: str, payload: bytes) -> bytes:
        return sign(self.private_key, purpose, payload)


class AccountIdentity(SigningIdentity):
    def endorse(self, device_id: str) -> Endorsement:
        e = Endorsement(account_id=self.id, account_key=b64e(self.public_raw), device_id=device_id,
                        issued_at=now_iso(), signature="")
        e.signature = b64e(self.sign("device-endorsement", e._payload()))
        return e


class PublisherIdentity(SigningIdentity):
    pass


class RotationStatement(BaseModel):
    """Signed by the *old* device key: 'my new key is …'."""

    model_config = ConfigDict(extra="forbid")
    old_device_id: str
    new_device_id: str
    new_cert: str
    issued_at: str
    signature: str = ""
    endorsement: Endorsement | None = None

    def _payload(self) -> bytes:
        return canonical_json({"old": self.old_device_id, "new": self.new_device_id,
                               "cert": self.new_cert, "issued_at": self.issued_at})

    @classmethod
    def create(cls, old: DeviceIdentity, new: DeviceIdentity, account: AccountIdentity | None) -> "RotationStatement":
        st = cls(old_device_id=old.device_id, new_device_id=new.device_id, new_cert=b64e(new.cert_der),
                 issued_at=now_iso(), endorsement=account.endorse(new.device_id) if account else None)
        st.signature = b64e(old.sign("device-key-rotation", st._payload()))
        return st

    def verify_against(self, old_cert_der: bytes) -> bytes:
        """Return the new certificate if the statement is authentic."""
        new_cert = b64d(self.new_cert)
        if device_id_from_cert(old_cert_der) != self.old_device_id or device_id_from_cert(new_cert) != self.new_device_id:
            raise IntegrityFailure("rotation statement does not match the pinned key")
        if not verify(cert_public_key_raw(old_cert_der), "device-key-rotation", self._payload(), b64d(self.signature)):
            raise IntegrityFailure("rotation statement signature is invalid")
        if self.endorsement is not None and not self.endorsement.is_valid_for(self.new_device_id):
            raise IntegrityFailure("rotation endorsement is invalid")
        return new_cert
