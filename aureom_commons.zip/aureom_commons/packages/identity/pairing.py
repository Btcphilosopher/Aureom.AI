"""Pairing invitations (file, text or QR code).

An invitation is a *one-time, expiring* capability to introduce a device to
the inviter.  It is not a bearer link to content: redeeming it only records
the redeemer's public key (and, for collection invitations, grants that key's
account the stated permissions).  Every later request must be authenticated
with the corresponding private key.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import zlib
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ..domain.errors import InvalidInput
from ..domain.util import b64d, b64e, canonical_json, clean_text, now, parse_iso
from .keys import DeviceIdentity, Endorsement, cert_public_key_raw, device_id_from_cert, verify

TEXT_PREFIX = "aureom-invite:"
MAX_INVITATION_BYTES = 16 * 1024


class CollectionOffer(BaseModel):
    """What a collection invitation would expose, as stated by the inviter."""

    model_config = ConfigDict(extra="forbid")
    collection_id: str
    name: str = Field(max_length=200)
    permissions: list[str] = Field(default_factory=list, max_length=16)
    item_count: int = 0


class PairingInvitation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["aureom-pairing-invitation"] = "aureom-pairing-invitation"
    v: Literal[1] = 1
    invitation_id: str = Field(max_length=64)
    purpose: Literal["pair", "link-device", "collection"] = "pair"
    device_id: str = Field(max_length=64)
    device_cert: str = Field(max_length=4096)
    device_name: str = Field(default="", max_length=120)
    endorsement: Endorsement
    addresses: list[str] = Field(default_factory=list, max_length=8)
    relay: str = Field(default="", max_length=255)
    token: str = Field(max_length=128)
    expires_at: str
    collection: CollectionOffer | None = None
    signature: str = ""

    # ------------------------------------------------------------ signing
    def _payload(self) -> bytes:
        return canonical_json(self.model_dump(exclude={"signature"}))

    def sign_with(self, device: DeviceIdentity) -> "PairingInvitation":
        self.signature = b64e(device.sign("pairing-invitation", self._payload()))
        return self

    def check(self) -> None:
        """Validate internal consistency.  This proves the invitation was
        made by the holder of the stated device key — it says nothing about
        who that is.  The human still has to compare fingerprints."""
        cert = b64d(self.device_cert)
        if device_id_from_cert(cert) != self.device_id:
            raise InvalidInput("invitation device id does not match its certificate")
        if not verify(cert_public_key_raw(cert), "pairing-invitation", self._payload(), b64d(self.signature)):
            raise InvalidInput("invitation signature is invalid", code="bad_signature")
        if not self.endorsement.is_valid_for(self.device_id):
            raise InvalidInput("invitation account endorsement is invalid", code="bad_signature")
        if parse_iso(self.expires_at) <= now():
            raise InvalidInput("this invitation has expired", code="invitation_expired")

    @property
    def account_id(self) -> str:
        return self.endorsement.account_id

    @property
    def display_name(self) -> str:
        return clean_text(self.device_name, 80) or "Unnamed device"

    # ----------------------------------------------------------- encoding
    def to_json(self) -> str:
        return json.dumps(self.model_dump(), indent=2)

    def to_text(self) -> str:
        """Compact single-line form suitable for a QR code or a chat message."""
        return TEXT_PREFIX + b64e(zlib.compress(canonical_json(self.model_dump()), 9))


def parse_invitation(data: str | bytes) -> PairingInvitation:
    if isinstance(data, bytes):
        if len(data) > MAX_INVITATION_BYTES:
            raise InvalidInput("invitation is too large")
        try:
            data = data.decode("utf-8")
        except UnicodeDecodeError:
            raise InvalidInput("invitation is not valid text") from None
    text = data.strip()
    if len(text) > MAX_INVITATION_BYTES:
        raise InvalidInput("invitation is too large")
    try:
        if text.startswith(TEXT_PREFIX):
            decomp = zlib.decompressobj()
            raw = decomp.decompress(b64d(text[len(TEXT_PREFIX):]), MAX_INVITATION_BYTES)
            if decomp.unconsumed_tail:
                raise InvalidInput("invitation is too large")
            doc = json.loads(raw)
        else:
            doc = json.loads(text)
        invitation = PairingInvitation.model_validate(doc)
    except InvalidInput:
        raise
    except (ValueError, ValidationError, zlib.error):
        raise InvalidInput("this is not a valid Aureom Commons invitation") from None
    invitation.check()
    return invitation


def new_token() -> str:
    return secrets.token_urlsafe(32)


def token_hash(token: str) -> str:
    return hashlib.sha256(b"aureom-invite-token\n" + token.encode()).hexdigest()


def token_matches(token: str, stored_hash: str) -> bool:
    return hmac.compare_digest(token_hash(token), stored_hash)
