"""Device/account/publisher key management, the trusted-peer list and
pairing invitations."""
from __future__ import annotations

import json
from typing import Any

from ..domain.errors import InvalidInput, NotFound, PermissionDenied, StateError
from ..domain.util import b64d, b64e, clean_text, fingerprint_display, new_id, now, now_iso, parse_iso
from ..storage.credentials import SecretStore
from ..storage.db import Database
from ..storage.settings import Activity, Settings
from .keys import (AccountIdentity, DeviceIdentity, Endorsement, PublisherIdentity, RotationStatement,
                   cert_public_key_raw, device_id_from_cert, key_id)
from .pairing import CollectionOffer, PairingInvitation, new_token, token_hash, token_matches

ROTATION_GRACE_DAYS = 30


class IdentityService:
    def __init__(self, db: Database, secrets: SecretStore, settings: Settings, activity: Activity):
        self.db, self.secrets, self.settings, self.activity = db, secrets, settings, activity
        self.device: DeviceIdentity
        self.previous_device: DeviceIdentity | None = None
        self.account: AccountIdentity
        self._endorsements: dict[str, Endorsement] = {}
        self.on_trust_change = lambda: None
        self._load()

    # ---------------------------------------------------------------- keys
    def _load(self) -> None:
        blob = self.secrets.get("device")
        if blob is None:
            self.device = DeviceIdentity.generate()
            self.secrets.set("device", self.device.to_secret())
        else:
            self.device = DeviceIdentity.from_secret(blob)
        prev = self.secrets.get("device-previous")
        self.previous_device = DeviceIdentity.from_secret(prev) if prev else None
        acct = self.secrets.get("account")
        if acct is None:
            self.account = AccountIdentity.generate()
            self.secrets.set("account", self.account.to_secret())
        else:
            self.account = AccountIdentity.from_secret(acct)

    @property
    def device_id(self) -> str:
        return self.device.device_id

    @property
    def account_id(self) -> str:
        return self.account.id

    @property
    def device_name(self) -> str:
        return clean_text(self.settings.get("device_name"), 80)

    def endorsement(self, device: DeviceIdentity | None = None) -> Endorsement:
        device = device or self.device
        if device.device_id not in self._endorsements:
            self._endorsements[device.device_id] = self.account.endorse(device.device_id)
        return self._endorsements[device.device_id]

    def describe(self) -> dict[str, Any]:
        return {
            "device_id": self.device_id, "device_fingerprint": fingerprint_display(self.device_id),
            "device_name": self.device_name,
            "account_id": self.account_id, "account_fingerprint": fingerprint_display(self.account_id),
            "account_name": self.settings.get("account_name") or "",
            "secret_storage": self.secrets.backend, "secret_storage_note": self.secrets.description,
            "rotation_pending": self.previous_device is not None,
        }

    def identity_for_peer(self, peer_device_id: str | None) -> DeviceIdentity:
        """During a key-rotation grace period, keep using the old key with
        peers that have not yet learned the new one."""
        if self.previous_device and peer_device_id:
            row = self.db.one("SELECT knows_our_key FROM peers WHERE device_id=?", (peer_device_id,))
            if row and row["knows_our_key"] == self.previous_device.device_id:
                return self.previous_device
        return self.device

    def identities(self) -> list[DeviceIdentity]:
        return [self.device] + ([self.previous_device] if self.previous_device else [])

    # ------------------------------------------------------------ rotation
    def rotate_device_key(self) -> RotationStatement:
        """Generate a new device key.  The old key signs a statement naming
        the new one; trusted peers accept it over an authenticated channel.
        Peers that never see the statement within the grace period must pair
        again (see docs/IDENTITY.md)."""
        if self.previous_device is not None:
            raise StateError("A key rotation is already in progress.")
        old, new = self.device, DeviceIdentity.generate()
        statement = RotationStatement.create(old, new, self.account)
        with self.db.tx() as c:
            self.secrets.set("device-previous", old.to_secret())
            self.secrets.set("device", new.to_secret())
            self.settings.set("_rotation", {"statement": statement.model_dump(), "started_at": now_iso()})
            c.execute("UPDATE peers SET knows_our_key=? WHERE state='trusted'", (old.device_id,))
        self.previous_device, self.device = old, new
        self.activity.log("identity.rotated", "This device's key was rotated. Trusted peers will be told on next contact.")
        self.on_trust_change()
        return statement

    def pending_rotation(self) -> RotationStatement | None:
        doc = self.settings.get("_rotation")
        return RotationStatement.model_validate(doc["statement"]) if doc else None

    def peer_acknowledged_rotation(self, peer_device_id: str) -> None:
        self.db.execute("UPDATE peers SET knows_our_key=? WHERE device_id=?", (self.device_id, peer_device_id))
        remaining = self.db.scalar("SELECT COUNT(*) FROM peers WHERE state='trusted' AND knows_our_key=?",
                                   (self.previous_device.device_id if self.previous_device else "",), 0)
        if not remaining:
            self.finish_rotation()

    def finish_rotation(self) -> None:
        """Retire the old key (all peers updated, or the grace period ended)."""
        if self.previous_device is None:
            return
        self.secrets.delete("device-previous")
        self.settings.set("_rotation", None)
        self.previous_device = None
        self.on_trust_change()

    def expire_rotation_if_due(self) -> None:
        doc = self.settings.get("_rotation")
        if doc and (now() - parse_iso(doc["started_at"])).days >= ROTATION_GRACE_DAYS:
            self.finish_rotation()

    def apply_peer_rotation(self, statement: RotationStatement) -> str:
        """A trusted peer told us (authenticated with its old key) that it has
        a new key.  Verify the old key's signature, then re-pin."""
        row = self.db.one("SELECT * FROM peers WHERE device_id=?", (statement.old_device_id,))
        if row is None or row["state"] != "trusted":
            raise PermissionDenied()
        new_cert = statement.verify_against(bytes(row["cert_der"]))
        if statement.endorsement and row["account_id"] and statement.endorsement.account_id != row["account_id"]:
            raise PermissionDenied()
        with self.db.tx() as c:
            c.execute("DELETE FROM peers WHERE device_id=?", (statement.new_device_id,))
            c.execute("UPDATE peers SET device_id=?, cert_der=?, rotated_from=?, verified=verified WHERE device_id=?",
                      (statement.new_device_id, new_cert, statement.old_device_id, statement.old_device_id))
            c.execute("UPDATE collections SET owner_device=? WHERE owner_device=?",
                      (statement.new_device_id, statement.old_device_id))
        self.activity.log("peer.rotated", "A trusted peer rotated its device key; the new key was accepted because "
                          "the previous key signed it.", peer=statement.new_device_id)
        self.on_trust_change()
        return statement.new_device_id

    # --------------------------------------------------------- invitations
    def create_invitation(self, *, addresses: list[str], relay: str = "", purpose: str = "pair",
                          ttl_hours: float | None = None, collection: CollectionOffer | None = None,
                          permissions: list[str] | None = None) -> PairingInvitation:
        import datetime as dt

        ttl = ttl_hours if ttl_hours is not None else self.settings.limits.invitation_ttl_hours
        token = new_token()
        invitation = PairingInvitation(
            invitation_id=new_id(), purpose=purpose, device_id=self.device_id, device_cert=b64e(self.device.cert_der),
            device_name=self.device_name, endorsement=self.endorsement(), addresses=addresses[:8], relay=relay,
            token=token, expires_at=(now() + dt.timedelta(hours=ttl)).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            collection=collection,
        ).sign_with(self.device)
        self.db.execute(
            "INSERT INTO pairing_invitations (invitation_id, token_hash, purpose, collection_id, permissions, "
            "expires_at, created_at) VALUES (?,?,?,?,?,?,?)",
            (invitation.invitation_id, token_hash(token), purpose, collection.collection_id if collection else None,
             json.dumps(permissions or []), invitation.expires_at, now_iso()))
        self.activity.log("invitation.created", f"Created a {purpose} invitation (expires {invitation.expires_at[:16]}Z).",
                          invitation_id=invitation.invitation_id)
        return invitation

    def redeem_invitation(self, token: str, device_id: str) -> dict:
        """Atomically consume a one-time token.  Expired, cancelled, unknown
        and already-used tokens are all refused with the same error."""
        with self.db.tx() as c:
            for row in c.execute("SELECT * FROM pairing_invitations WHERE state='open'").fetchall():
                if token_matches(token, row["token_hash"]):
                    if parse_iso(row["expires_at"]) <= now():
                        break
                    c.execute("UPDATE pairing_invitations SET state='redeemed', used_at=?, used_by=? "
                              "WHERE invitation_id=? AND state='open'", (now_iso(), device_id, row["invitation_id"]))
                    return dict(row)
        raise PermissionDenied("invitation is invalid, expired or already used", code="invitation_invalid")

    def confirm_invitation(self, token: str, device_id: str) -> dict:
        with self.db.tx() as c:
            for row in c.execute("SELECT * FROM pairing_invitations WHERE state='redeemed' AND used_by=?",
                                 (device_id,)).fetchall():
                if token_matches(token, row["token_hash"]):
                    c.execute("UPDATE pairing_invitations SET state='confirmed' WHERE invitation_id=?",
                              (row["invitation_id"],))
                    return dict(row)
        raise PermissionDenied("invitation is invalid, expired or already used", code="invitation_invalid")

    def invitations(self) -> list[dict]:
        rows = self.db.query("SELECT invitation_id, purpose, collection_id, expires_at, created_at, state, used_at, "
                             "used_by FROM pairing_invitations ORDER BY created_at DESC LIMIT 100")
        out = []
        for r in rows:
            d = dict(r)
            if d["state"] == "open" and parse_iso(d["expires_at"]) <= now():
                d["state"] = "expired"
            out.append(d)
        return out

    def cancel_invitation(self, invitation_id: str) -> None:
        self.db.execute("UPDATE pairing_invitations SET state='cancelled' WHERE invitation_id=? AND state='open'",
                        (invitation_id,))

    # --------------------------------------------------------------- peers
    def upsert_peer(self, *, cert_der: bytes, device_name: str, endorsement: Endorsement | None, state: str,
                    addresses: list[str] | None = None, relay: str = "", paired_via: str = "",
                    is_own_device: bool = False) -> str:
        device_id = device_id_from_cert(cert_der)
        if device_id in (self.device_id, self.previous_device.device_id if self.previous_device else ""):
            raise InvalidInput("A device cannot pair with itself.")
        account_id, account_key = "", None
        if endorsement is not None:
            if not endorsement.is_valid_for(device_id):
                raise InvalidInput("The peer's account endorsement is invalid.", code="bad_signature")
            account_id, account_key = endorsement.account_id, b64d(endorsement.account_key)
        if self.is_blocked(device_id, account_id):
            raise PermissionDenied("this peer is blocked", code="blocked")
        with self.db.tx() as c:
            old = c.execute("SELECT state FROM peers WHERE device_id=?", (device_id,)).fetchone()
            if old and old["state"] == "trusted" and state == "pending":
                state = "trusted"
            c.execute(
                "INSERT INTO peers (device_id, cert_der, device_name, account_id, account_key, state, addresses, relay, "
                "paired_at, paired_via, is_own_device, knows_our_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(device_id) DO UPDATE SET cert_der=excluded.cert_der, device_name=excluded.device_name, "
                "account_id=excluded.account_id, account_key=excluded.account_key, state=excluded.state, "
                "addresses=CASE WHEN excluded.addresses='[]' THEN peers.addresses ELSE excluded.addresses END, "
                "relay=CASE WHEN excluded.relay='' THEN peers.relay ELSE excluded.relay END, "
                "paired_at=excluded.paired_at, paired_via=excluded.paired_via, is_own_device=excluded.is_own_device",
                (device_id, cert_der, clean_text(device_name, 80), account_id, account_key, state,
                 json.dumps(addresses or []), relay, now_iso(), paired_via, int(is_own_device), self.device_id))
        self.on_trust_change()
        return device_id

    def _peer_dict(self, row) -> dict:
        d = dict(row)
        d.pop("cert_der", None)
        d.pop("account_key", None)
        d["addresses"] = json.loads(d["addresses"])
        d["fingerprint"] = fingerprint_display(d["device_id"])
        d["account_fingerprint"] = fingerprint_display(d["account_id"]) if d["account_id"] else ""
        d["display_name"] = d["local_alias"] or d["device_name"] or "Unnamed device"
        return d

    def peers(self, include_removed: bool = False) -> list[dict]:
        sql = "SELECT * FROM peers" + ("" if include_removed else " WHERE state != 'removed'") + " ORDER BY paired_at"
        return [self._peer_dict(r) for r in self.db.query(sql)]

    def peer(self, device_id: str) -> dict:
        row = self.db.one("SELECT * FROM peers WHERE device_id=?", (device_id,))
        if row is None:
            raise NotFound("peer")
        return self._peer_dict(row)

    def peer_row(self, device_id: str):
        return self.db.one("SELECT * FROM peers WHERE device_id=?", (device_id,))

    def devices_of_account(self, account_id: str) -> list[dict]:
        return [self._peer_dict(r) for r in self.db.query(
            "SELECT * FROM peers WHERE account_id=? AND state='trusted' ORDER BY last_seen DESC", (account_id,))]

    def account_display_name(self, account_id: str) -> str:
        if account_id == self.account_id:
            return self.settings.get("account_name") or self.device_name
        devices = self.devices_of_account(account_id)
        return devices[0]["display_name"] if devices else "Unknown account"

    def trust_material(self) -> list[bytes]:
        """Certificates the TLS listener will accept for client authentication."""
        return [bytes(r["cert_der"]) for r in self.db.query("SELECT cert_der FROM peers WHERE state IN ('trusted','pending')")]

    def set_peer_state(self, device_id: str, state: str) -> None:
        if state not in ("trusted", "removed", "blocked"):
            raise InvalidInput("unknown peer state")
        if self.db.execute("UPDATE peers SET state=? WHERE device_id=?", (state, device_id)).rowcount == 0:
            raise NotFound("peer")
        self.activity.log(f"peer.{state}", {"trusted": "A device was marked as trusted.",
                                            "removed": "A device was removed from the trusted list.",
                                            "blocked": "A device was blocked."}[state], peer=device_id)
        self.on_trust_change()

    def mark_verified(self, device_id: str, verified: bool = True) -> None:
        """Record that the user compared fingerprints through another channel."""
        if self.db.execute("UPDATE peers SET verified=?, verified_at=? WHERE device_id=?",
                           (int(verified), now_iso() if verified else None, device_id)).rowcount == 0:
            raise NotFound("peer")
        self.activity.log("peer.verified" if verified else "peer.unverified",
                          "Fingerprint marked as verified out of band." if verified else "Fingerprint verification cleared.",
                          peer=device_id)

    def update_peer(self, device_id: str, *, alias: str | None = None, addresses: list[str] | None = None,
                    bandwidth_kbps: int | None = None, relay: str | None = None) -> None:
        with self.db.tx() as c:
            if alias is not None:
                c.execute("UPDATE peers SET local_alias=? WHERE device_id=?", (clean_text(alias, 80), device_id))
            if addresses is not None:
                c.execute("UPDATE peers SET addresses=? WHERE device_id=?",
                          (json.dumps([clean_text(a, 255) for a in addresses][:8]), device_id))
            if bandwidth_kbps is not None:
                c.execute("UPDATE peers SET bandwidth_kbps=? WHERE device_id=?", (max(0, int(bandwidth_kbps)), device_id))
            if relay is not None:
                c.execute("UPDATE peers SET relay=? WHERE device_id=?", (clean_text(relay, 255), device_id))

    def touch_peer(self, device_id: str, path: str, address: str = "") -> None:
        self.db.execute("UPDATE peers SET last_seen=?, last_path=? WHERE device_id=?", (now_iso(), path, device_id))

    def block_account(self, account_id: str, note: str = "") -> None:
        with self.db.tx() as c:
            c.execute("INSERT OR REPLACE INTO blocked_accounts (account_id, blocked_at, note) VALUES (?,?,?)",
                      (account_id, now_iso(), clean_text(note, 200)))
            c.execute("UPDATE peers SET state='blocked' WHERE account_id=?", (account_id,))
        self.on_trust_change()

    def is_blocked(self, device_id: str | None, account_id: str | None) -> bool:
        if device_id and self.db.one("SELECT 1 FROM peers WHERE device_id=? AND state='blocked'", (device_id,)):
            return True
        return bool(account_id and self.db.one("SELECT 1 FROM blocked_accounts WHERE account_id=?", (account_id,)))

    # ------------------------------------------------- account/device link
    def export_account_secret(self) -> bytes:
        return self.account.to_secret()

    def adopt_account(self, secret: bytes) -> None:
        """Become a device of an existing account (device linking)."""
        self.account = AccountIdentity.from_secret(secret)
        self.secrets.set("account", secret)
        self._endorsements.clear()
        self.activity.log("identity.linked", "This device was linked to an existing account.")

    # ---------------------------------------------------------- publishers
    def create_publisher(self, name: str) -> dict:
        name = clean_text(name, 120)
        if not name:
            raise InvalidInput("A publisher imprint needs a name.")
        ident = PublisherIdentity.generate()
        self.secrets.set(f"publisher:{ident.id}", ident.to_secret())
        self.db.execute("INSERT INTO publisher_identities (publisher_id, name, public_key, created_at) VALUES (?,?,?,?)",
                        (ident.id, name, ident.public_raw, now_iso()))
        self.activity.log("publisher.created", "Created a publisher signing identity.", publisher_id=ident.id)
        return self.publisher(ident.id)

    def publisher(self, publisher_id: str) -> dict:
        row = self.db.one("SELECT * FROM publisher_identities WHERE publisher_id=?", (publisher_id,))
        if row is None:
            raise NotFound("publisher identity")
        d = dict(row)
        d["public_key"] = b64e(bytes(d["public_key"]))
        d["fingerprint"] = fingerprint_display(d["publisher_id"])
        return d

    def publishers(self, own_only: bool = True) -> list[dict]:
        rows = self.db.query("SELECT publisher_id FROM publisher_identities" +
                             (" WHERE has_secret=1" if own_only else "") + " ORDER BY created_at")
        return [self.publisher(r["publisher_id"]) for r in rows]

    def publisher_key(self, publisher_id: str) -> PublisherIdentity:
        blob = self.secrets.get(f"publisher:{publisher_id}")
        if blob is None:
            raise NotFound("publisher signing key")
        return PublisherIdentity.from_secret(blob)

    def pin_publisher(self, public_key_b64: str, name: str) -> str:
        """Remember someone else's publisher key (trust on first use, or after
        the user compared its fingerprint)."""
        raw = b64d(public_key_b64)
        pid = key_id(raw)
        self.db.execute("INSERT INTO publisher_identities (publisher_id, name, public_key, created_at, has_secret, "
                        "pinned_at) VALUES (?,?,?,?,0,?) ON CONFLICT(publisher_id) DO NOTHING",
                        (pid, clean_text(name, 120), raw, now_iso(), now_iso()))
        return pid

    def publisher_pin(self, publisher_id: str) -> dict | None:
        row = self.db.one("SELECT publisher_id, name, has_secret, pinned_at FROM publisher_identities WHERE publisher_id=?",
                          (publisher_id,))
        return dict(row) if row else None


__all__ = ["IdentityService", "cert_public_key_raw"]
