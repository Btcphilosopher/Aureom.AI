"""Parent side of the isolated extraction worker."""
from __future__ import annotations

import base64
import json
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from ..domain.limits import Limits
from ..domain.models import FORMATS, Metadata
from ..domain.util import clean_text
from .detect import sniff


@dataclass
class Extraction:
    format: str
    metadata: Metadata
    text: str = ""
    cover: bytes | None = None
    cover_media_type: str = ""
    warnings: list[str] = field(default_factory=list)
    sections: int = 0
    failed: str = ""          # non-empty when the worker failed; import still proceeds with basic metadata


def _fallback(path: Path, reason: str) -> Extraction:
    with open(path, "rb") as fh:
        head = fh.read(8192)
    fmt = sniff(head, path.name)
    title = " ".join(path.stem.replace("_", " ").replace("-", " ").split())
    return Extraction(format=fmt, metadata=Metadata(title=title), failed=reason,
                      warnings=[f"metadata extraction did not complete ({reason}); basic details were recorded"])


def extract(path: Path, limits: Limits) -> Extraction:
    """Run the worker with a wall-clock timeout and an output cap, then
    validate everything it returned."""
    max_out = 6 * limits.max_text_index_chars + 2 * limits.max_cover_bytes + 1024 * 1024
    path = Path(path).resolve()
    if getattr(sys, "frozen", False):       # packaged application: re-enter our own executable as the worker
        cmd = [sys.executable, "--aureom-extract-worker", str(path), limits.model_dump_json()]
    else:
        cmd = [sys.executable, "-I", "-m", "aureom.readers.extract_worker", str(path), limits.model_dump_json()]
    env = {k: v for k, v in os.environ.items() if k in ("PATH", "SYSTEMROOT", "LANG", "LC_ALL", "TMPDIR", "TEMP")}
    try:
        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                env=env, cwd=tempfile.gettempdir())
    except OSError:
        return _fallback(path, "worker could not start")
    try:
        raw, _ = proc.communicate(timeout=limits.preview_timeout_seconds)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.communicate()
        return _fallback(path, "time limit exceeded")
    if len(raw) > max_out:
        return _fallback(path, "output limit exceeded")
    try:
        doc = json.loads(raw)
        if not isinstance(doc, dict):
            raise ValueError
    except ValueError:
        return _fallback(path, "worker stopped unexpectedly (resource limit or malformed file)")
    if doc.get("error"):
        fb = _fallback(path, clean_text(doc["error"], 160))
        return fb
    fmt = doc.get("format") if doc.get("format") in FORMATS else "bin"
    meta_in = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    try:
        metadata = Metadata.model_validate(meta_in)
    except Exception:
        metadata = Metadata(title=clean_text(meta_in.get("title", ""), 500))
    text = doc.get("text") if isinstance(doc.get("text"), str) else ""
    text = clean_text(text, limits.max_text_index_chars, single_line=False)
    cover = None
    cover_type = ""
    if isinstance(doc.get("cover"), str) and limits.max_cover_bytes:
        try:
            blob = base64.b64decode(doc["cover"], validate=True)
            kind = sniff(blob[:64])
            if len(blob) <= limits.max_cover_bytes and kind in ("png", "jpg", "gif", "webp"):
                cover, cover_type = blob, FORMATS[kind]["media_type"]
        except Exception:
            cover = None
    warnings = [clean_text(w, 200) for w in doc.get("warnings", []) if isinstance(w, str)][:10]
    return Extraction(format=fmt, metadata=metadata, text=text, cover=cover, cover_media_type=cover_type,
                      warnings=warnings, sections=int(doc.get("sections") or 0))
