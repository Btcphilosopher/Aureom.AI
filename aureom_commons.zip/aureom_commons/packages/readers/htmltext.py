"""HTML → plain text and HTML/SVG/Markdown sanitisation.

Rendered documents are untrusted.  Scripts, styles, forms, embeds and event
handlers are removed; remote resources are never referenced; images may only
point at resources inside the same container (``aureom-res:`` URLs that the
reader resolves itself); links are rewritten so the reader can ask before
following anything external.
"""
from __future__ import annotations

import html
import re
from html.parser import HTMLParser
from typing import Callable
from urllib.parse import quote, unquote, urlsplit

import nh3

_BLOCK = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "blockquote", "section", "article",
          "pre", "hr", "dt", "dd", "figcaption", "table", "ul", "ol", "title"}
_SKIP = {"script", "style", "template", "noscript", "svg", "math", "head"}


class _TextExtractor(HTMLParser):
    def __init__(self, limit: int):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.size = 0
        self.limit = limit
        self._skip = 0
        self.title = ""
        self._in_title = False
        self._heading: list[str] | None = None
        self.first_heading = ""

    def handle_starttag(self, tag, attrs):
        if tag in _SKIP and tag != "head":
            self._skip += 1
        if tag == "title":
            self._in_title = True
        if tag in ("h1", "h2") and not self.first_heading:
            self._heading = []
        if tag in _BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in _SKIP and tag != "head" and self._skip:
            self._skip -= 1
        if tag == "title":
            self._in_title = False
        if tag in ("h1", "h2") and self._heading is not None:
            self.first_heading = " ".join("".join(self._heading).split())
            self._heading = None
        if tag in _BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
            return
        if self._skip or self.size >= self.limit:
            return
        if self._heading is not None:
            self._heading.append(data)
        self.parts.append(data)
        self.size += len(data)


def html_to_text(markup: str, limit: int = 5_000_000) -> tuple[str, str]:
    """Return ``(text, title_or_first_heading)``."""
    parser = _TextExtractor(limit)
    try:
        parser.feed(markup)
        parser.close()
    except Exception:
        pass
    text = "".join(parser.parts)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r" ?\n ?", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return text[:limit], " ".join((parser.first_heading or parser.title).split())


ALLOWED_TAGS = {
    "p", "div", "span", "br", "hr", "h1", "h2", "h3", "h4", "h5", "h6", "em", "strong", "b", "i", "u", "s",
    "sub", "sup", "small", "blockquote", "q", "cite", "abbr", "pre", "code", "kbd", "samp", "var",
    "ul", "ol", "li", "dl", "dt", "dd", "table", "thead", "tbody", "tfoot", "tr", "td", "th", "caption",
    "a", "img", "figure", "figcaption", "section", "article", "aside", "header", "footer", "center",
}
ALLOWED_ATTRIBUTES = {
    "*": {"id", "lang", "dir", "title"},
    "a": {"href", "name"},
    "img": {"src", "alt", "width", "height"},
    "td": {"colspan", "rowspan", "align"},
    "th": {"colspan", "rowspan", "align"},
    "ol": {"start", "type"},
    "p": {"align"}, "div": {"align"}, "h1": {"align"}, "h2": {"align"}, "h3": {"align"},
}
INTERNAL_LINK = "aureom-doc"
RESOURCE = "aureom-res"
EXTERNAL_LINK = "aureom-ext"


def sanitize_html(markup: str, *, base: str = "", resolve: Callable[[str, str], str | None] | None = None) -> str:
    """Return inert HTML.

    ``resolve(base, href)`` maps a relative reference to a member path inside
    the same container (or ``None``).  With no resolver every image is
    dropped and every relative link becomes inert.
    """

    def attribute_filter(tag: str, attr: str, value: str) -> str | None:
        if attr not in ("href", "src"):
            return value
        value = value.strip()
        parts = urlsplit(value)
        if tag == "img":
            if parts.scheme or parts.netloc or value.startswith("//"):
                return None                          # no remote, data: or file: images
            target = resolve(base, value) if resolve else None
            return f"{RESOURCE}:{quote(target)}" if target else None
        if tag == "a":
            if value.startswith("#"):
                return value
            if parts.scheme in ("http", "https", "mailto"):
                return f"{EXTERNAL_LINK}:{quote(value, safe='')}"
            if parts.scheme or parts.netloc:
                return None
            target = resolve(base, value) if resolve else None
            if not target:
                return None
            frag = "#" + quote(parts.fragment) if parts.fragment else ""
            return f"{INTERNAL_LINK}:{quote(target)}{frag}"
        return None

    return nh3.clean(
        markup,
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRIBUTES,
        attribute_filter=attribute_filter,
        url_schemes={"http", "https", "mailto", INTERNAL_LINK, RESOURCE, EXTERNAL_LINK},
        clean_content_tags={"script", "style", "template", "noscript", "iframe", "object", "embed", "form", "title"},
        strip_comments=True,
        link_rel=None,
    )


def parse_internal_url(url: str) -> tuple[str, str, str]:
    """Split one of our rewritten URLs into ``(scheme, target, fragment)``."""
    scheme, _, rest = url.partition(":")
    target, _, fragment = rest.partition("#")
    return scheme, unquote(target), unquote(fragment)


def text_to_html(text: str) -> str:
    paragraphs = re.split(r"\n\s*\n", text.replace("\r\n", "\n"))
    return "\n".join("<p>" + html.escape(p).replace("\n", "<br>") + "</p>" for p in paragraphs if p.strip())


def markdown_to_html(text: str) -> str:
    from markdown_it import MarkdownIt

    md = MarkdownIt("commonmark", {"html": False, "linkify": False}).enable("table")
    return sanitize_html(md.render(text))


_SVG_DROP = {"script", "foreignobject", "iframe", "audio", "video", "animate", "set", "animatemotion",
             "animatetransform", "handler", "listener"}


def sanitize_svg(data: bytes, max_bytes: int = 8 * 1024 * 1024) -> bytes:
    """Strip active and external content from an SVG before rendering it."""
    import defusedxml.ElementTree as ET
    from xml.etree import ElementTree as StdET

    if len(data) > max_bytes:
        raise ValueError("SVG too large")
    root = ET.fromstring(data)

    def local(name: str) -> str:
        return name.rsplit("}", 1)[-1].lower()

    def scrub(node) -> None:
        for child in list(node):
            if not isinstance(child.tag, str) or local(child.tag) in _SVG_DROP:
                node.remove(child)
                continue
            for attr in list(child.attrib):
                name = local(attr)
                value = child.attrib[attr].strip()
                if name.startswith("on"):
                    del child.attrib[attr]
                elif name == "href" and not value.startswith("#"):
                    del child.attrib[attr]           # no external or embedded references
                elif name == "style" and ("url(" in value.lower() or "@import" in value.lower()):
                    del child.attrib[attr]
            if local(child.tag) == "style":
                if "@import" in (child.text or "").lower() or "url(" in (child.text or "").lower():
                    node.remove(child)
                    continue
            scrub(child)

    for attr in list(root.attrib):
        if local(attr).startswith("on"):
            del root.attrib[attr]
    scrub(root)
    StdET.register_namespace("", "http://www.w3.org/2000/svg")
    return StdET.tostring(root, encoding="utf-8")
