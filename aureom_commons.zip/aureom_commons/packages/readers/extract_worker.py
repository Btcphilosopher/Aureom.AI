"""Isolated metadata/text extraction worker.

Run as ``python -I -m aureom.readers.extract_worker <path> <limits-json>``.
It is a separate, short-lived process with CPU-time, address-space,
file-size and file-descriptor limits (POSIX) and a wall-clock timeout
enforced by the parent.  It reads one file and prints one JSON document.
Whatever it prints is treated as untrusted by the parent.

This is process isolation with resource limits — not a full sandbox.  It has
no network or filesystem namespace restrictions; see docs/THREAT_MODEL.md.
"""
from __future__ import annotations

import base64
import json
import os
import sys


def _apply_limits(memory_mb: int, cpu_seconds: int) -> None:
    try:
        import resource
    except ImportError:          # Windows: the parent's timeout is the only bound
        return
    for name, value in (("RLIMIT_CPU", cpu_seconds), ("RLIMIT_AS", memory_mb * 1024 * 1024),
                        ("RLIMIT_FSIZE", 0), ("RLIMIT_NOFILE", 64), ("RLIMIT_CORE", 0)):
        try:
            limit = getattr(resource, name)
            _soft, hard = resource.getrlimit(limit)
            if hard != resource.RLIM_INFINITY:
                value = min(value, hard)
            resource.setrlimit(limit, (value, hard))
        except (ValueError, OSError, AttributeError):
            pass


def _title_from_name(path: str) -> str:
    stem = os.path.basename(path).rsplit(".", 1)[0]
    return " ".join(stem.replace("_", " ").replace("-", " ").split())


def extract(path: str, limits_json: str) -> dict:
    from ..domain.limits import Limits
    from .detect import sniff

    limits = Limits.model_validate_json(limits_json)
    max_chars = limits.max_text_index_chars
    with open(path, "rb") as fh:
        head = fh.read(8192)
    fmt = sniff(head, path)
    out: dict = {"format": fmt, "metadata": {}, "text": "", "warnings": [], "sections": 0}

    if fmt == "zip":
        from .safezip import SafeZip

        z = SafeZip(path, limits)
        names = set(z.names())
        mimetype = z.read("mimetype", 128).strip() if "mimetype" in names else b""
        z.close()
        if mimetype == b"application/epub+zip" or "META-INF/container.xml" in names:
            fmt = "epub"
        elif "word/document.xml" in names:
            fmt = "docx"
        elif mimetype == b"application/vnd.oasis.opendocument.text":
            fmt = "odt"
        out["format"] = fmt

    if fmt == "epub":
        from .epub import EpubBook
        from .htmltext import html_to_text

        book = EpubBook.open(path, limits)
        out["metadata"] = book.metadata
        parts, size = [], 0
        for index in range(len(book.spine)):
            if size >= max_chars:
                out["warnings"].append("text index truncated")
                break
            text, _ = html_to_text(book.document(index), max_chars - size)
            parts.append(text)
            size += len(text)
        out["text"] = "\n\n".join(parts)
        out["sections"] = len(book.spine)
        cover = book.cover(limits.max_cover_bytes)
        if cover:
            out["cover"] = base64.b64encode(cover[0]).decode()
            out["cover_media_type"] = cover[1]
        book.close()
    elif fmt == "pdf":
        from pypdf import PdfReader

        reader = PdfReader(path, strict=False)
        if reader.is_encrypted:
            out["warnings"].append("PDF is encrypted; no text was indexed")
        else:
            info = reader.metadata or {}
            out["metadata"] = {
                "title": str(info.get("/Title") or ""), "authors": [str(info["/Author"])] if info.get("/Author") else [],
                "description": str(info.get("/Subject") or ""),
                "tags": [t.strip() for t in str(info.get("/Keywords") or "").replace(";", ",").split(",") if t.strip()],
            }
            parts, size = [], 0
            out["sections"] = len(reader.pages)
            for page in reader.pages:
                if size >= max_chars:
                    out["warnings"].append("text index truncated")
                    break
                try:
                    text = page.extract_text() or ""
                except Exception:
                    text = ""
                parts.append(text[: max_chars - size])
                size += len(parts[-1])
            out["text"] = "\n\n".join(parts)
    elif fmt in ("txt", "md", "html"):
        with open(path, "rb") as fh:
            raw = fh.read(max(4 * max_chars, 65536))
        from .epub import decode

        text = decode(raw)
        title = ""
        if fmt == "html":
            from .htmltext import html_to_text

            text, title = html_to_text(text, max_chars)
        else:
            for line in text.splitlines()[:40]:
                stripped = line.strip()
                if fmt == "md" and stripped.startswith("#"):
                    title = stripped.lstrip("#").strip()
                    break
                if fmt == "txt" and stripped:
                    title = stripped if len(stripped) <= 120 else ""
                    break
            meta = {}
            if text.startswith("---\n"):     # simple front matter: "key: value" lines only
                block, sep, _rest = text[4:].partition("\n---")
                if sep:
                    for line in block.splitlines()[:40]:
                        key, colon, value = line.partition(":")
                        if colon and key.strip().lower() in ("title", "author", "language", "licence", "license",
                                                              "date", "publisher", "subtitle", "rights"):
                            meta[key.strip().lower()] = value.strip().strip("\"'")
            if meta:
                title = meta.get("title", title)
                out["metadata"].update({
                    "subtitle": meta.get("subtitle", ""), "authors": [meta["author"]] if meta.get("author") else [],
                    "language": meta.get("language", ""), "licence": meta.get("licence") or meta.get("license", ""),
                    "publication_date": meta.get("date", ""), "publisher": meta.get("publisher", ""),
                    "rights": meta.get("rights", ""),
                })
        out["metadata"]["title"] = title
        out["text"] = text[:max_chars]
        out["sections"] = 1
    elif fmt == "wav":
        import wave

        try:
            with wave.open(path, "rb") as w:
                out["duration_seconds"] = round(w.getnframes() / float(w.getframerate() or 1), 2)
        except Exception:
            out["warnings"].append("could not read audio header")

    if not out["metadata"].get("title"):
        out["metadata"]["title"] = _title_from_name(path)
        out["title_from_filename"] = True
    return out


def main() -> None:
    if len(sys.argv) != 3:
        sys.exit(2)
    path, limits_json = sys.argv[1], sys.argv[2]
    try:
        spec = json.loads(limits_json)
        _apply_limits(int(spec.get("extract_memory_mb", 1024)), int(float(spec.get("preview_timeout_seconds", 20))) + 1)
        result = extract(path, limits_json)
    except MemoryError:
        result = {"error": "memory limit exceeded"}
    except Exception as exc:  # the parent only needs a category, not a traceback
        result = {"error": f"{type(exc).__name__}: {str(exc)[:200]}", "code": getattr(exc, "code", "extract_failed")}
    sys.stdout.write(json.dumps(result))


if __name__ == "__main__":
    main()
