"""Defensive reading of zip containers (EPUB, DOCX…).

Archives are never extracted to disk.  Members are read into memory through
size-capped reads, after the archive directory has been checked against
entry-count, per-entry, total-size and compression-ratio limits.
"""
from __future__ import annotations

import os
import posixpath
import zipfile
from typing import BinaryIO

from ..domain.errors import InvalidInput, LimitExceeded
from ..domain.limits import Limits


def normalise_member(name: str) -> str:
    """Resolve an archive-internal path; reject anything that escapes it."""
    name = name.replace("\\", "/")
    if name.startswith("/") or "\x00" in name or (len(name) > 1 and name[1] == ":"):
        raise InvalidInput("unsafe path inside archive", code="unsafe_path")
    norm = posixpath.normpath(name)
    if norm == ".." or norm.startswith("../"):
        raise InvalidInput("unsafe path inside archive", code="unsafe_path")
    return "" if norm == "." else norm


def resolve_href(base: str, href: str) -> str:
    href = href.split("#", 1)[0].split("?", 1)[0]
    from urllib.parse import unquote

    return normalise_member(posixpath.join(posixpath.dirname(base), unquote(href)))


class SafeZip:
    def __init__(self, source: str | os.PathLike | BinaryIO, limits: Limits):
        self.limits = limits
        try:
            self._zf = zipfile.ZipFile(source)
        except (zipfile.BadZipFile, OSError, ValueError) as exc:
            raise InvalidInput("not a readable zip container") from exc
        infos = self._zf.infolist()
        if len(infos) > limits.max_archive_entries:
            raise LimitExceeded("archive has too many entries", code="archive_entries")
        total = 0
        compressed = 0
        self._members: dict[str, zipfile.ZipInfo] = {}
        for info in infos:
            if info.flag_bits & 0x1:
                raise InvalidInput("encrypted archives are not supported")
            if info.file_size > limits.max_archive_entry_bytes:
                raise LimitExceeded("archive entry too large", code="archive_entry_size")
            total += info.file_size
            compressed += max(info.compress_size, 1)
            try:
                self._members[normalise_member(info.filename)] = info
            except InvalidInput:
                continue     # unsafe names are simply unreachable
        if total > limits.max_archive_total_bytes:
            raise LimitExceeded("archive expands beyond the configured limit", code="archive_total_size")
        if total > 1024 * 1024 and total / compressed > limits.max_decompression_ratio:
            raise LimitExceeded("archive compression ratio is suspicious", code="decompression_ratio")
        self._read_total = 0

    def names(self) -> list[str]:
        return list(self._members)

    def has(self, name: str) -> bool:
        return name in self._members

    def read(self, name: str, max_bytes: int | None = None) -> bytes:
        info = self._members.get(name)
        if info is None:
            raise InvalidInput("missing archive member")
        cap = min(max_bytes or self.limits.max_archive_entry_bytes, self.limits.max_archive_entry_bytes)
        with self._zf.open(info) as fh:
            data = fh.read(cap + 1)        # headers can lie; never trust file_size
        if len(data) > cap:
            raise LimitExceeded("archive entry larger than declared", code="archive_entry_size")
        self._read_total += len(data)
        if self._read_total > 4 * self.limits.max_archive_total_bytes:
            raise LimitExceeded("too much data read from archive", code="archive_total_size")
        return data

    def close(self) -> None:
        self._zf.close()
