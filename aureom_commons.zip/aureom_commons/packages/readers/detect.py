"""Format detection from file signatures (never from the name alone)."""
from __future__ import annotations

from ..domain.models import FORMATS

_EXT_ALIASES = {"markdown": "md", "jpeg": "jpg", "htm": "html", "xhtml": "html", "text": "txt", "oga": "ogg",
                "wave": "wav"}


def extension_of(name: str) -> str:
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return _EXT_ALIASES.get(ext, ext)


def looks_like_text(head: bytes) -> bool:
    if not head:
        return True
    if b"\x00" in head:
        return False
    try:
        head.decode("utf-8")
        return True
    except UnicodeDecodeError as exc:
        # a multi-byte sequence may be cut at the end of the sample
        return exc.start >= len(head) - 4


def sniff(head: bytes, name: str = "") -> str:
    """Return a format id from the first bytes of a file.

    Zip containers are reported as ``zip``; telling EPUB from DOCX needs the
    archive directory, which is only read inside the isolated worker."""
    ext = extension_of(name)
    if head.startswith(b"%PDF-"):
        return "pdf"
    if head.startswith(b"PK\x03\x04") or head.startswith(b"PK\x05\x06"):
        return "zip"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
        return "wav"
    if head.startswith(b"fLaC"):
        return "flac"
    if head.startswith(b"OggS"):
        return "ogg"
    if head[4:8] == b"ftyp":
        return "m4a" if ext in ("m4a", "m4b", "mp4") else "bin"
    if head.startswith(b"ID3") or (len(head) > 1 and head[0] == 0xFF and head[1] & 0xE0 == 0xE0 and ext == "mp3"):
        return "mp3"
    if looks_like_text(head):
        lowered = head[:2048].lstrip(b"\xef\xbb\xbf \t\r\n").lower()
        if lowered.startswith(b"<svg") or (lowered.startswith(b"<?xml") and b"<svg" in head[:4096].lower()):
            return "svg"
        if lowered.startswith(b"<!doctype html") or lowered.startswith(b"<html"):
            return "html"
        if ext == "md":
            return "md"
        return "txt"
    return "bin"


def media_type(fmt: str) -> str:
    return FORMATS.get(fmt, FORMATS["bin"])["media_type"]


def is_readable(fmt: str) -> bool:
    return bool(FORMATS.get(fmt, FORMATS["bin"])["readable"])


def kind_of(fmt: str) -> str:
    return FORMATS.get(fmt, FORMATS["bin"])["kind"]
