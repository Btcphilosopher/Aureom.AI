"""Minimal, defensive EPUB 2/3 reader: metadata, spine, contents, resources."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import BinaryIO

import defusedxml.ElementTree as ET

from ..domain.errors import InvalidInput
from ..domain.limits import DEFAULT_LIMITS, Limits
from .htmltext import html_to_text
from .safezip import SafeZip, resolve_href

_MAX_XML = 8 * 1024 * 1024
_MAX_DOC = 16 * 1024 * 1024


def _local(tag: object) -> str:
    return tag.rsplit("}", 1)[-1].lower() if isinstance(tag, str) else ""


def decode(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16", "cp1252"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


@dataclass
class SpineItem:
    href: str
    media_type: str
    label: str = ""


@dataclass
class TocEntry:
    label: str
    href: str
    fragment: str = ""
    depth: int = 0


class _NavParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.entries: list[tuple[str, str, int]] = []
        self._in_toc = 0
        self._depth = 0
        self._href: str | None = None
        self._text: list[str] = []
        self._saw_toc = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "nav":
            kind = (a.get("epub:type") or a.get("role") or "")
            if "toc" in kind and not self._saw_toc:
                self._in_toc = 1
                self._saw_toc = True
        elif self._in_toc and tag == "ol":
            self._depth += 1
        elif self._in_toc and tag == "a" and a.get("href"):
            self._href = a["href"]
            self._text = []

    def handle_endtag(self, tag):
        if tag == "nav" and self._in_toc:
            self._in_toc = 0
        elif self._in_toc and tag == "ol":
            self._depth -= 1
        elif self._in_toc and tag == "a" and self._href is not None:
            self.entries.append((" ".join("".join(self._text).split()), self._href, max(0, self._depth - 1)))
            self._href = None

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)


@dataclass
class EpubBook:
    metadata: dict = field(default_factory=dict)
    spine: list[SpineItem] = field(default_factory=list)
    toc: list[TocEntry] = field(default_factory=list)
    cover_href: str = ""
    cover_media_type: str = ""
    manifest: dict[str, tuple[str, str]] = field(default_factory=dict)   # id -> (href, media type)
    _zip: SafeZip | None = None

    @classmethod
    def open(cls, source: str | os.PathLike | BinaryIO, limits: Limits = DEFAULT_LIMITS) -> "EpubBook":
        z = SafeZip(source, limits)
        book = cls(_zip=z)
        try:
            if z.has("mimetype") and z.read("mimetype", 64).strip() != b"application/epub+zip":
                raise InvalidInput("not an EPUB container")
            container = ET.fromstring(z.read("META-INF/container.xml", _MAX_XML))
            rootfile = next((el.attrib.get("full-path", "") for el in container.iter() if _local(el.tag) == "rootfile"), "")
            if not rootfile:
                raise InvalidInput("EPUB has no package document")
            opf_path = resolve_href("", rootfile)
            opf = ET.fromstring(z.read(opf_path, _MAX_XML))
        except InvalidInput:
            z.close()
            raise
        except Exception as exc:
            z.close()
            raise InvalidInput("EPUB package is malformed") from exc
        book._parse_opf(opf, opf_path)
        return book

    # ------------------------------------------------------------- parsing
    def _parse_opf(self, opf, opf_path: str) -> None:
        meta: dict[str, list[str]] = {}
        cover_id = ""
        nav_href = ncx_id = ""
        for el in opf.iter():
            name = _local(el.tag)
            text = (el.text or "").strip()
            if name in ("title", "creator", "contributor", "publisher", "language", "date", "identifier",
                        "rights", "description", "subject") and text:
                meta.setdefault(name, []).append(text)
            elif name == "meta":
                if el.attrib.get("name") == "cover":
                    cover_id = el.attrib.get("content", "")
                prop = el.attrib.get("property", "")
                if prop.startswith("schema:access") and text:
                    meta.setdefault("accessibility", []).append(f"{prop.split(':', 1)[1]}: {text}")
            elif name == "item":
                try:
                    href = resolve_href(opf_path, el.attrib.get("href", ""))
                except InvalidInput:
                    continue
                item_id = el.attrib.get("id", "")
                self.manifest[item_id] = (href, el.attrib.get("media-type", ""))
                props = el.attrib.get("properties", "").split()
                if "nav" in props:
                    nav_href = href
                if "cover-image" in props:
                    cover_id = item_id
            elif name == "spine":
                ncx_id = el.attrib.get("toc", "")
                for ref in el:
                    if _local(ref.tag) == "itemref":
                        item = self.manifest.get(ref.attrib.get("idref", ""))
                        if item and ("html" in item[1] or item[0].lower().endswith((".xhtml", ".html", ".htm"))):
                            self.spine.append(SpineItem(item[0], item[1]))
        ids = meta.get("identifier", [])
        isbn = next((re.sub(r"^(urn:)?isbn:", "", i, flags=re.I) for i in ids
                     if "isbn" in i.lower() or re.fullmatch(r"97[89][\d-]{10,14}", i)), "")
        doi = next((re.sub(r"^(urn:)?doi:", "", i, flags=re.I) for i in ids if "doi" in i.lower() or i.startswith("10.")), "")
        self.metadata = {
            "title": (meta.get("title") or [""])[0], "authors": meta.get("creator", []),
            "contributors": meta.get("contributor", []), "publisher": (meta.get("publisher") or [""])[0],
            "language": (meta.get("language") or [""])[0], "publication_date": (meta.get("date") or [""])[0],
            "isbn": isbn, "doi": doi, "rights": (meta.get("rights") or [""])[0],
            "description": html_to_text((meta.get("description") or [""])[0], 4000)[0],
            "tags": meta.get("subject", []), "accessibility": "; ".join(meta.get("accessibility", [])),
        }
        cover = self.manifest.get(cover_id)
        if cover and cover[1].startswith("image/"):
            self.cover_href, self.cover_media_type = cover
        self._parse_toc(nav_href, self.manifest.get(ncx_id, ("", ""))[0])

    def _parse_toc(self, nav_href: str, ncx_href: str) -> None:
        z = self._zip
        assert z is not None
        try:
            if nav_href and z.has(nav_href):
                parser = _NavParser()
                parser.feed(decode(z.read(nav_href, _MAX_XML)))
                for label, href, depth in parser.entries[:2000]:
                    try:
                        self.toc.append(TocEntry(label or "Untitled", resolve_href(nav_href, href),
                                                 href.partition("#")[2], depth))
                    except InvalidInput:
                        continue
            elif ncx_href and z.has(ncx_href):
                ncx = ET.fromstring(z.read(ncx_href, _MAX_XML))

                def walk(node, depth):
                    for child in node:
                        if _local(child.tag) != "navpoint":
                            continue
                        label = next((" ".join("".join(t.itertext()).split()) for t in child.iter() if _local(t.tag) == "text"), "")
                        src = next((c.attrib.get("src", "") for c in child if _local(c.tag) == "content"), "")
                        if src and len(self.toc) < 2000:
                            try:
                                self.toc.append(TocEntry(label or "Untitled", resolve_href(ncx_href, src),
                                                         src.partition("#")[2], depth))
                            except InvalidInput:
                                pass
                        walk(child, depth + 1)

                for el in ncx.iter():
                    if _local(el.tag) == "navmap":
                        walk(el, 0)
        except Exception:
            self.toc = []
        labels = {t.href: t.label for t in reversed(self.toc)}
        for i, item in enumerate(self.spine):
            item.label = labels.get(item.href, f"Section {i + 1}")
        if not self.toc:
            self.toc = [TocEntry(item.label, item.href) for item in self.spine]

    # -------------------------------------------------------------- access
    def read(self, href: str, max_bytes: int = _MAX_DOC) -> bytes:
        assert self._zip is not None
        return self._zip.read(href, max_bytes)

    def has(self, href: str) -> bool:
        return self._zip is not None and self._zip.has(href)

    def document(self, index: int) -> str:
        return decode(self.read(self.spine[index].href))

    def resolve(self, base: str, href: str) -> str | None:
        try:
            target = resolve_href(base, href)
        except InvalidInput:
            return None
        return target if self.has(target) else None

    def cover(self, max_bytes: int) -> tuple[bytes, str] | None:
        if not self.cover_href or not self.has(self.cover_href):
            return None
        try:
            return self.read(self.cover_href, max_bytes), self.cover_media_type
        except Exception:
            return None

    def close(self) -> None:
        if self._zip:
            self._zip.close()
            self._zip = None
