-- AUREOM COMMONS catalogue schema, version 1.
-- One database per installation (profile).  Nothing in this file is shared
-- with peers verbatim; protocol objects are built from it on demand.

CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE secrets (name TEXT PRIMARY KEY, value BLOB NOT NULL);  -- used only when the library is encrypted

-- ------------------------------------------------------------- catalogue
CREATE TABLE works (
    work_id     TEXT PRIMARY KEY,
    created_at  TEXT NOT NULL,
    origin      TEXT NOT NULL DEFAULT 'local',   -- local | shared | public
    origin_ref  TEXT NOT NULL DEFAULT '',        -- collection_id or publication_id the copy came from
    deleted     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE editions (
    edition_id          TEXT PRIMARY KEY,
    work_id             TEXT NOT NULL REFERENCES works(work_id),
    edition_number      INTEGER NOT NULL DEFAULT 1,
    label               TEXT NOT NULL DEFAULT '',
    previous_edition_id TEXT,
    relation            TEXT NOT NULL DEFAULT '',   -- revision-of | correction-of | translation-of
    revision_notes      TEXT NOT NULL DEFAULT '',
    index_mode          TEXT NOT NULL DEFAULT 'full' CHECK (index_mode IN ('full','metadata','none')),
    created_at          TEXT NOT NULL,
    deleted             INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX editions_work ON editions(work_id);

CREATE TABLE files (
    file_id       TEXT PRIMARY KEY,
    edition_id    TEXT NOT NULL REFERENCES editions(edition_id),
    role          TEXT NOT NULL DEFAULT 'primary',  -- primary | supplementary | cover
    content_hash  TEXT NOT NULL,
    size          INTEGER NOT NULL,
    format        TEXT NOT NULL,
    media_type    TEXT NOT NULL,
    filename      TEXT NOT NULL,
    storage       TEXT NOT NULL DEFAULT 'managed' CHECK (storage IN ('managed','referenced')),
    ref_path      TEXT,
    import_source TEXT NOT NULL DEFAULT '',
    imported_at   TEXT NOT NULL,
    available     INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX files_hash ON files(content_hash);
CREATE INDEX files_edition ON files(edition_id);

-- Imported metadata, user corrections and metadata received from a peer are
-- kept in separate rows; the effective view overlays user > remote > imported.
CREATE TABLE edition_metadata (
    edition_id TEXT NOT NULL REFERENCES editions(edition_id),
    source     TEXT NOT NULL CHECK (source IN ('imported','remote','user')),
    data       TEXT NOT NULL DEFAULT '{}',
    fvv        TEXT NOT NULL DEFAULT '{}',   -- per-field version vectors (user rows)
    updated_at TEXT NOT NULL,
    PRIMARY KEY (edition_id, source)
);

CREATE TABLE edition_index (
    edition_id       TEXT PRIMARY KEY REFERENCES editions(edition_id),
    work_id          TEXT NOT NULL,
    title            TEXT NOT NULL DEFAULT '',
    subtitle         TEXT NOT NULL DEFAULT '',
    authors          TEXT NOT NULL DEFAULT '',
    publisher        TEXT NOT NULL DEFAULT '',
    language         TEXT NOT NULL DEFAULT '',
    publication_date TEXT NOT NULL DEFAULT '',
    format           TEXT NOT NULL DEFAULT '',
    tags             TEXT NOT NULL DEFAULT '',
    rights           TEXT NOT NULL DEFAULT '',
    licence          TEXT NOT NULL DEFAULT '',
    updated_at       TEXT NOT NULL
);

CREATE VIRTUAL TABLE search_index USING fts5(
    edition_id UNINDEXED, title, subtitle, authors, tags, description, body,
    tokenize = 'unicode61 remove_diacritics 2'
);

-- ----------------------------------------------------------- collections
CREATE TABLE collections (
    collection_id      TEXT PRIMARY KEY,
    name               TEXT NOT NULL,
    description        TEXT NOT NULL DEFAULT '',
    kind               TEXT NOT NULL DEFAULT 'shared' CHECK (kind IN ('local','shared')),
    owner_account      TEXT NOT NULL,
    is_owner           INTEGER NOT NULL DEFAULT 1,
    owner_device       TEXT NOT NULL DEFAULT '',     -- device we reach the owner through (replicas)
    owner_name         TEXT NOT NULL DEFAULT '',
    permission_version INTEGER NOT NULL DEFAULT 1,
    my_permissions     TEXT NOT NULL DEFAULT '[]',   -- replicas: what the owner last told us
    access_state       TEXT NOT NULL DEFAULT 'active', -- active | invited | revoked | suspended
    access_checked_at  TEXT NOT NULL DEFAULT '',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL,
    deleted            INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE collection_items (
    collection_id TEXT NOT NULL REFERENCES collections(collection_id),
    edition_id    TEXT NOT NULL,
    added_by      TEXT NOT NULL DEFAULT '',
    added_at      TEXT NOT NULL,
    state         TEXT NOT NULL DEFAULT 'active',   -- active | proposed | removed
    PRIMARY KEY (collection_id, edition_id)
);

CREATE TABLE collection_members (
    collection_id      TEXT NOT NULL REFERENCES collections(collection_id),
    account_id         TEXT NOT NULL,
    display_name       TEXT NOT NULL DEFAULT '',
    permissions        TEXT NOT NULL DEFAULT '[]',
    status             TEXT NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','active','revoked','declined')),
    permission_version INTEGER NOT NULL DEFAULT 1,
    invited_at         TEXT NOT NULL,
    joined_at          TEXT,
    revoked_at         TEXT,
    PRIMARY KEY (collection_id, account_id)
);

-- --------------------------------------------------------------- identity
CREATE TABLE peers (
    device_id      TEXT PRIMARY KEY,
    cert_der       BLOB NOT NULL,
    device_name    TEXT NOT NULL DEFAULT '',   -- self-asserted by the peer; not proof of identity
    local_alias    TEXT NOT NULL DEFAULT '',   -- name chosen by this user
    account_id     TEXT NOT NULL DEFAULT '',
    account_key    BLOB,
    state          TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','trusted','removed','blocked')),
    verified       INTEGER NOT NULL DEFAULT 0, -- fingerprint compared out of band
    verified_at    TEXT,
    is_own_device  INTEGER NOT NULL DEFAULT 0,
    addresses      TEXT NOT NULL DEFAULT '[]',
    relay          TEXT NOT NULL DEFAULT '',
    last_seen      TEXT,
    last_path      TEXT NOT NULL DEFAULT '',
    bandwidth_kbps INTEGER NOT NULL DEFAULT 0,
    paired_at      TEXT,
    paired_via     TEXT NOT NULL DEFAULT '',
    rotated_from   TEXT NOT NULL DEFAULT '',
    knows_our_key  TEXT NOT NULL DEFAULT ''    -- which of our device ids this peer has pinned
);

CREATE TABLE blocked_accounts (account_id TEXT PRIMARY KEY, blocked_at TEXT NOT NULL, note TEXT NOT NULL DEFAULT '');

CREATE TABLE pairing_invitations (
    invitation_id TEXT PRIMARY KEY,
    token_hash    TEXT NOT NULL,
    purpose       TEXT NOT NULL,              -- pair | link-device | collection
    collection_id TEXT,
    permissions   TEXT NOT NULL DEFAULT '[]',
    expires_at    TEXT NOT NULL,
    created_at    TEXT NOT NULL,
    state         TEXT NOT NULL DEFAULT 'open' CHECK (state IN ('open','redeemed','confirmed','cancelled')),
    used_at       TEXT,
    used_by       TEXT
);

CREATE TABLE publisher_identities (
    publisher_id TEXT PRIMARY KEY,            -- fingerprint of the signing key
    name         TEXT NOT NULL,
    public_key   BLOB NOT NULL,
    created_at   TEXT NOT NULL,
    has_secret   INTEGER NOT NULL DEFAULT 1,  -- 0 = someone else's key we have pinned
    pinned_at    TEXT,
    note         TEXT NOT NULL DEFAULT ''
);

-- ------------------------------------------------------------ annotations
CREATE TABLE annotations (
    annotation_id  TEXT PRIMARY KEY,
    edition_id     TEXT NOT NULL,
    content_hash   TEXT NOT NULL,             -- the exact file the locator refers to
    kind           TEXT NOT NULL CHECK (kind IN ('bookmark','highlight','note')),
    locator        TEXT NOT NULL DEFAULT '{}',
    body           TEXT NOT NULL DEFAULT '',
    colour         TEXT NOT NULL DEFAULT 'copper',
    status         TEXT NOT NULL DEFAULT 'ok' CHECK (status IN ('ok','needs_review','orphaned')),
    migrated_from  TEXT NOT NULL DEFAULT '',
    review_note    TEXT NOT NULL DEFAULT '',
    shared_in      TEXT NOT NULL DEFAULT '',  -- collection id when explicitly shared; '' = private
    author_account TEXT NOT NULL DEFAULT '',  -- '' = mine; otherwise received through a collection
    author_name    TEXT NOT NULL DEFAULT '',
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL,
    deleted        INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX annotations_edition ON annotations(edition_id);

CREATE TABLE reading_progress (
    edition_id TEXT NOT NULL,
    device_id  TEXT NOT NULL,
    locator    TEXT NOT NULL DEFAULT '{}',
    fraction   REAL NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (edition_id, device_id)
);

-- ------------------------------------------------------------- publishing
CREATE TABLE publications (
    publication_id          TEXT PRIMARY KEY,
    work_id                 TEXT NOT NULL,
    edition_id              TEXT NOT NULL,
    state                   TEXT NOT NULL DEFAULT 'draft'
        CHECK (state IN ('draft','preview','rights_review','published','revised','withdrawn')),
    package                 TEXT NOT NULL DEFAULT '{}',
    rights_review           TEXT NOT NULL DEFAULT '{}',
    publisher_id            TEXT NOT NULL DEFAULT '',
    manifest                TEXT,
    manifest_id             TEXT,
    previous_publication_id TEXT,
    superseded_by           TEXT,
    announce                INTEGER NOT NULL DEFAULT 0,
    published_at            TEXT,
    withdrawn_at            TEXT,
    withdrawal_note         TEXT NOT NULL DEFAULT '',
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);

-- Published editions are immutable: the frozen manifest can never change.
CREATE TRIGGER publications_immutable_manifest
BEFORE UPDATE OF manifest, manifest_id, edition_id, work_id, publisher_id, package ON publications
WHEN OLD.state IN ('published','revised','withdrawn')
BEGIN
    SELECT RAISE(ABORT, 'published editions are immutable');
END;

CREATE TRIGGER publications_no_delete
BEFORE DELETE ON publications
WHEN OLD.state IN ('published','revised','withdrawn')
BEGIN
    SELECT RAISE(ABORT, 'published editions are immutable');
END;

-- Public catalogue entries learned from other peers (never private data).
CREATE TABLE remote_publications (
    publication_id TEXT NOT NULL,
    source_device  TEXT NOT NULL,
    source_address TEXT NOT NULL DEFAULT '',
    manifest       TEXT NOT NULL,
    manifest_id    TEXT NOT NULL,
    signature_ok   INTEGER NOT NULL DEFAULT 0,
    publisher_id   TEXT NOT NULL DEFAULT '',
    title          TEXT NOT NULL DEFAULT '',
    authors        TEXT NOT NULL DEFAULT '',
    language       TEXT NOT NULL DEFAULT '',
    fetched_at     TEXT NOT NULL,
    PRIMARY KEY (publication_id, source_device)
);

CREATE TABLE public_sources (
    address    TEXT PRIMARY KEY,
    device_id  TEXT NOT NULL DEFAULT '',
    label      TEXT NOT NULL DEFAULT '',
    added_at   TEXT NOT NULL,
    last_fetch TEXT
);

-- -------------------------------------------------------------- transfers
CREATE TABLE transfers (
    transfer_id  TEXT PRIMARY KEY,
    scope        TEXT NOT NULL,              -- JSON: {kind, id}
    file_hash    TEXT NOT NULL,
    size         INTEGER NOT NULL DEFAULT 0,
    manifest     TEXT,
    sources      TEXT NOT NULL DEFAULT '[]', -- JSON list of {device_id, address}
    target       TEXT NOT NULL DEFAULT '{}', -- JSON: catalogue placement after completion
    state        TEXT NOT NULL DEFAULT 'queued',
    bytes_done   INTEGER NOT NULL DEFAULT 0,
    bitmap       BLOB,
    corrupt_chunks INTEGER NOT NULL DEFAULT 0,
    retries      INTEGER NOT NULL DEFAULT 0,
    error        TEXT NOT NULL DEFAULT '',
    title        TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);

-- ------------------------------------------------------------------- sync
CREATE TABLE sync_state (
    kind       TEXT NOT NULL,
    record_id  TEXT NOT NULL,
    vv         TEXT NOT NULL DEFAULT '{}',
    deleted    INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    updated_by TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (kind, record_id)
);

CREATE TABLE sync_conflicts (
    conflict_id TEXT PRIMARY KEY,
    kind        TEXT NOT NULL,
    record_id   TEXT NOT NULL,
    field       TEXT NOT NULL DEFAULT '',
    rule        TEXT NOT NULL DEFAULT '',
    local_value TEXT,
    remote_value TEXT,
    remote_device TEXT NOT NULL DEFAULT '',
    detected_at TEXT NOT NULL,
    resolved_at TEXT,
    resolution  TEXT NOT NULL DEFAULT ''
);

-- --------------------------------------------------------------- activity
CREATE TABLE activity (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      TEXT NOT NULL,
    kind    TEXT NOT NULL,
    summary TEXT NOT NULL,
    detail  TEXT NOT NULL DEFAULT '{}',
    peer    TEXT NOT NULL DEFAULT ''
);
