# Synchronisation and conflicts

## What synchronises, and between whom

Metadata synchronisation runs **only between devices linked to the same
account** (docs/IDENTITY.md). It covers:

| Record kind | Identifier | Contents |
|---|---|---|
| `edition` | edition id | catalogue record: work, edition number/label/relation, file descriptions (hash, size, format), imported metadata |
| `metadata` | edition id | the user's corrections, with a version vector **per field** |
| `annotation` | annotation id | bookmark / highlight / note, including its shared-in-collection flag |
| `progress` | edition id + device id | that device's reading position |
| `collection` | collection id | collections you own: name, description, items, permission version |
| `member` | collection id + account id | permissions and status of one member |

Collections owned by *other* people are not synchronised between your
devices; each device asks the owner directly.

**File bytes never travel with metadata.** After a sync, an edition the other
device holds appears as “available from an authorised peer”; fetching it is a
separate, explicit transfer (scope `device`), verified like any other.

## Mechanism

Every record has a **version vector** `{device_id: counter}`; a device
increments its own counter when it changes the record. Comparing vectors
gives exactly one of: equal, newer, older, **concurrent**. Exchange:

1. A asks B for its digest `[(kind, id, vector)]`.
2. A fetches records that are newer or concurrent on B and merges them.
3. A pushes records that are newer on A, plus every merged record and the
   conflicts it recorded, so both devices converge and both can review.

Merges are deterministic and symmetric (the provisional winner of a
concurrent edit is the later `(timestamp, device id)`), so repeated or
crossed syncs settle on the same state.

## Conflict rules

Nothing concurrent is silently discarded. Detected conflicts are listed in
*Activity → Conflicts* on both devices with both values.

| Case | Rule |
|---|---|
| **Concurrent metadata edits, different fields** | merged; no conflict |
| **Concurrent metadata edits, same field** | both devices converge on the later edit; the other value is kept in a conflict record and can be chosen instead (“use the other value”) |
| **Annotation edited on both devices** | the later edit keeps the annotation's id; the other version is kept as a separate annotation marked *needs review* |
| **Annotation deleted on one device, edited on another** | the edit survives, marked *needs review* with an explanation |
| **Reading progress** | one record per device, so devices never overwrite each other; the reader shows the most recent position and offers the others |
| **Membership: revocation vs any concurrent change** | **revocation dominates** — the member stays revoked on both devices; re-granting needs a new, explicit grant |
| **Membership: concurrent permission changes** | the **intersection** (least privilege) applies; recorded for review |
| **Collection deleted on one device, changed on another** | the collection is kept but its sharing is **suspended** (members are refused) until the owner chooses delete or restore |
| **Collection name/description edited on both** | later edit applies; the other is kept in a conflict record |
| **Edition record deleted vs changed** | kept, recorded for review |

Collection items merge as a union: an item kept on either device stays.

## Revocation, old records, and what offline devices can know

* A collection's **owner device is the authority**. Requests are checked
  against its current membership table; nothing the requester presents is
  believed. Holding an old copy of a membership record, a collection payload
  or a manifest does not restore access.
* Between the owner's own devices, a stale “active” record loses to the
  revocation because the revocation's version vector dominates it; replaying
  the old record is ignored (`test_revocation_dominates_and_old_records_cannot_restore_access`).
* `permission_version` rises with every membership change. A member's
  requests include the highest version they have seen; an owner device that
  is behind answers `stale_authority` rather than serve.

Limits that follow from being peer-to-peer:

* An owner's **second device that has been offline since before a
  revocation** does not know about it. Until it synchronises, it would still
  serve the revoked member — unless that member has seen a newer
  `permission_version` (then it refuses), or it is simply not reachable.
  Synchronise your devices after revoking.
* A **member's device that is offline** keeps showing the collection as it
  last saw it. It learns of a revocation the next time it contacts the owner
  (the collection then shows “access ended”). The interface displays when
  access was last confirmed.
* **Revocation never reaches into another device.** Files already downloaded
  stay where they are, readable, and outside your control.
