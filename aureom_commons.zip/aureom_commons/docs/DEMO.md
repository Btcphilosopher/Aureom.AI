# The three-peer demonstration

```bash
python scripts/demo_three_peers.py --keep --workdir demo
```

The script launches three `aureom-node` processes. Each has its own profile
folder (database, object store, keys), its own loopback API port and its own
peer port. Ben's library is created with a passphrase, so his catalogue and
files are encrypted at rest. The script then talks to each node only through
its local API — the same facade the desktop application uses.

| # | Step | What is asserted |
|---|---|---|
| 1 | Alice imports an EPUB and a manuscript | both imported; re-importing identical bytes is reported as a duplicate |
| 2 | Both are private | Private badge; Cara's view of Alice's public catalogue is empty; anonymous requests for the file hash are refused |
| 3 | Alice creates a shared collection | the invitation's exposure preview lists titles, permissions and what is not exposed; redistribution is off |
| 4 | Ben accepts and verifies the fingerprint | fingerprint on Ben's screen equals Alice's; Cara replaying the invitation is refused |
| 5 | Ben downloads directly | transfer completes; status is *Direct*; stored bytes match the hash |
| 6 | Cara cannot list or download | anonymous and paired-but-not-a-member: every request refused with the same answer as for invented ids |
| 7 | Interrupted transfer resumes | Alice goes offline mid-transfer; Ben keeps verified chunks, retries with backoff, completes |
| 8 | Corrupted chunk rejected | one deliberately damaged chunk is counted, never written, fetched again |
| 9 | Ben's private annotation | stored only on Ben's device; nothing reaches Alice |
| 10 | Alice publishes a separate public edition | workflow enforced; publishing without confirmation refused; only that edition becomes Public; it is immutable |
| 11 | Another peer verifies and downloads | Cara sees exactly what was checked about the signature, then downloads |
| 12 | Corrected edition | new manifest names the edition it corrects |
| 13 | Both editions distinguishable | two manifests, first marked superseded; Cara holds both; her annotations are re-anchored (one flagged for review) |
| 14 | Alice revokes Ben | Ben's next request is refused; a work he had not downloaded becomes unavailable |
| 15 | Existing copy remains | both sides are told so; Ben, offline, still opens his copy; his encrypted profile contains no readable text |

The damaged chunk in step 8 comes from a development-only fault hook
(`POST /debug/corrupt-chunk`) that exists only when a node is started with
`AUREOM_DEMO_FAULTS=1`. The same environment variable enables
`/debug/probe`, which the script uses to make Cara's raw protocol requests.

## Looking at the result in the desktop application

```bash
aureom-commons --profile-dir demo/alice
```
```bash
aureom-commons --profile-dir demo/cara
```

Ben's library is encrypted; its passphrase in the demo is
`ben reads by lantern light`.

To regenerate the screenshots in `docs/screenshots/` (also a smoke test of
every page):

```bash
QT_QPA_PLATFORM=offscreen python scripts/render_screenshots.py
```
