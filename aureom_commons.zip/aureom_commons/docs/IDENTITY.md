# Identities, pairing, rotation and recovery

## Four separate things

| Identity | Key | What it is for | What it is not |
|---|---|---|---|
| **Device** | Ed25519 + self-signed certificate | authenticating one installation to peers over TLS | a statement about who owns the device |
| **Account** | Ed25519 | representing one person across their devices; collection permissions are granted to account ids; it endorses each device | a login, a username, or a legal identity |
| **Publisher (imprint)** | Ed25519, one per imprint | signing publication manifests | independent verification of the publisher's identity or rights |
| **Permissions** | — (records held by the collection owner) | what each account may do in each collection | derived from names, or from anything the requester presents |

Identifiers are fingerprints of public keys, shown in groups of four for
comparison. **Display names are labels** chosen by each device's owner; the
interface marks them “self-declared” and never authorises by name. A peer is
“verified” only when *you* record that you compared its fingerprint through
another channel — the application cannot do that for you.

## Where keys are stored

1. Encrypted library → inside the encrypted catalogue (protected by the library passphrase).
2. Otherwise the OS credential store through `keyring` (Keychain, Credential Manager, Secret Service) when a real backend exists.
3. Otherwise an owner-only file (`secrets.json`, mode 0600). The Peers and Settings pages say which is in use.

## Pairing

1. A creates a one-time invitation (file, text or QR) and sends it to B.
2. B opens it; the application shows A's fingerprint and what the invitation
   does *before* anything is sent.
3. B accepts. B's device pins A's key from the invitation, redeems the token,
   then proves possession of its own key over mutual TLS.
4. A and B compare fingerprints by voice or in person and each marks the
   other as verified.

Skipping step 4 leaves you trusting whoever delivered the invitation. The
peer list shows “not verified” until you do it.

Scanning a QR code with a camera is not built in. The application displays
QR codes, accepts the invitation as text or file, and can decode a QR *image
file* when the optional `qrscan` extra is installed.

## Linking your own devices

A `link-device` invitation makes the redeeming device part of your account:
after `pair_confirm` succeeds over mutual TLS, your device sends it the
account private key, and the two devices mark each other as “own”. Linked
devices can synchronise metadata (docs/SYNC.md) and fetch any of your files
from each other.

Consequence, stated plainly: every linked device holds the account key. A
compromised linked device can act as you towards collection owners.

## Removing and blocking devices

* **Remove** — the device is dropped from your trusted list and the TLS trust
  store immediately; it can no longer authenticate to you. It can pair again
  with a new invitation.
* **Block** — as remove, and it (or its whole account) is refused if it tries
  to pair again.
* Removing one of *your own* devices stops it synchronising with this device.
  It does not take the account key back from it — see “Lost device”.

Neither action affects copies the device already holds.

## Rotating a device key

*Peers → This device → Rotate device key.*

1. A new key and certificate are generated; the old key signs a
   `RotationStatement {old_device_id, new_device_id, new_cert, issued_at}`
   and the account key endorses the new device.
2. For 30 days the device keeps both keys. To each trusted peer it connects
   with the old key and sends `key_rotation`; a peer that dials the old
   identity receives the statement in `hello_ack`.
3. A peer accepts the new key only if the statement is signed by the key it
   had pinned and the account matches. It then re-pins; “verified” status is
   carried over because the old key vouched for the new one.
4. When every trusted peer has acknowledged, or after 30 days, the old key is
   destroyed.

Peers that were not reached in time must pair again. Your fingerprint
changes, so anyone who wants independent assurance should re-verify it.

Rotation is for hygiene and for moving off a key you still control. It does
not help if the old key was stolen: the thief can sign a rotation statement too.

## Recovery behaviour

| Situation | What happens | What to do |
|---|---|---|
| Forgotten **library passphrase** | the library cannot be opened; there is no reset | restore an encrypted backup whose backup passphrase you remember |
| Forgotten **backup passphrase** | that backup is unreadable | make a new backup while you can still open the library |
| **Device key lost** (disk failure, no backup with identity) | the device gets a new identity on reinstall | pair again with everyone; ask peers to remove the old device |
| **Device stolen or compromised** | until peers remove it, it can still authenticate to them as that device | from another device or a restored backup: remove/block the lost device everywhere, ask peers to do the same, re-create sensitive collections' grants, rotate keys on remaining devices |
| **Account key compromised** | there is no in-band account-key rotation in this release | create a new profile (new account), re-pair, have collection owners revoke the old account and invite the new one |
| **Publisher key lost** | you cannot sign further editions with it | create a new imprint and tell readers through another channel; earlier editions stay valid |
| **Publisher key stolen** | someone else can sign as that key | announce the compromise out of band; readers should unpin the key; publish under a new key |

## Backups and identity

An encrypted backup may include identity keys (default) or exclude them.

* **Included** — restoring recreates the same device, account and imprints.
  Do this only when the original device is gone; two live devices with one
  device identity confuse peers.
* **Excluded** — restoring yields a new device with your library, annotations
  and collections but no trust relationships; pair again.

Restoration always goes into a new, empty folder and re-verifies every file
against its content hash.

## Device-loss guidance

The same list is shown in *Settings → Protection*:

1. If the lost device's library was encrypted and locked, its catalogue,
   index, annotations, covers, managed files and keys are unreadable without
   the passphrase. Files imported “by reference” were never encrypted by
   Aureom Commons.
2. If it was not encrypted, assume the holder can read everything and act as that device.
3. Remove the lost device from every trusted list you control and ask the
   people you share with to remove it.
4. For sensitive collections, revoke and re-invite.
5. If it held a publisher key, tell readers out of band and move to a new key.
6. Restore your latest backup onto a replacement.
