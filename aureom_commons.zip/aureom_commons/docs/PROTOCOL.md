# Aureom Commons peer protocol — version 1

Status: implemented as described. Machine-readable schemas for every object
are in `schemas/` (generated from the validating models by
`scripts/export_schemas.py`).

## 1. Staged networking design

| Stage | Status | What it does |
|---|---|---|
| 1. Explicit addresses, direct connections | implemented, default | a peer is reached at a `host:port` carried in an invitation or typed by the user |
| 2. Local-network discovery | implemented, **opt-in** | UDP multicast beacons give address *hints* for devices on the same network segment |
| 3. Rendezvous and relay | implemented, **opt-in**, optional service | address lookup for contacts, an index of *published* editions, and a byte relay for peers without a direct route |

There is no hole punching, UPnP or other NAT traversal. Two devices can
connect when one has an address the other can reach, or when both use the
same relay. The interface always shows the current mode: **Offline**,
**Direct** or **Relay**.

## 2. Transport security

The handshake is TLS 1.3 as implemented by OpenSSL through Python's `ssl`
module. Aureom Commons does not implement or modify a cryptographic
handshake; it supplies trust policy:

* Every device has an Ed25519 key and a self-signed X.509 certificate whose
  subject is the device id. The **device id** is the lower-case, unpadded
  base32 SHA-256 of the raw public key (52 characters).
* **Client side (pinning).** The client disables CA validation and, after the
  handshake, requires that the certificate's public key hashes to the device
  id it meant to reach (`fingerprint_mismatch` otherwise). TLS itself proves
  the server holds the private key.
* **Server side.** The listener requests a client certificate
  (`CERT_OPTIONAL`) and OpenSSL validates it against a trust store that
  contains exactly the certificates of paired devices. An unknown certificate
  fails the handshake. A client that presents no certificate is
  **anonymous** and can reach only public endpoints and `pair_request`.
  After the handshake the server re-checks the device against its database
  (removed or blocked devices are dropped) on every connection.
* The client sends the expected device id as SNI. During a key-rotation
  grace period the server holds two identities and selects by SNI.
* If TLS 1.3 is unavailable in the Python/OpenSSL build, networking is
  disabled and the status detail says why. There is no weaker fallback.

Device names travel in `hello` but are labels only; nothing is authorised by name.

## 3. Framing

```
frame   := length:u32 (big endian)  kind:u8  payload[length-1]
kind 1  := UTF-8 JSON message
kind 2  := opaque binary (one chunk)
```

Length caps are checked before any payload is read: JSON ≤ 1 MiB on the
server (clients accept up to the manifest limit + 64 KiB), binary ≤ 4 MiB.
A connection that sends an oversized or malformed frame is closed.

## 4. Session

1. Client → `hello {versions, device_name, endorsement?}`
2. Server → `hello_ack {version, device_name, endorsement?, peer_state, rotation?}`
   where `peer_state` is `anonymous`, `pending` (invitation redeemed, not yet
   confirmed) or `trusted`. No common version → `error version_mismatch`.
3. Requests, one at a time: `{ "t": "<type>", … }` → `ok {data}` | `error {code, message}`;
   `get_chunk` → `chunk {index, size}` followed by one binary frame.

Every message is validated against a Pydantic model with unknown fields
forbidden. Per-connection request rate, idle timeout (120 s) and a global
connection cap apply.

### Requests

| `t` | Who may send | Purpose |
|---|---|---|
| `ping` | anyone | liveness |
| `pair_request` | anyone (rate-limited) | redeem a one-time invitation token, registering the sender's certificate as *pending* |
| `pair_confirm` | the pending device, over mutual TLS | prove possession of the registered key; becomes *trusted*; may carry a collection grant or (device linking) the account key |
| `list_shared` | trusted | collections the requester's account is invited to or a member of |
| `invitation_response` | trusted, invited | accept or decline |
| `get_collection` | member with `view_metadata` | the member's view of a collection |
| `get_manifest` | per scope (below) | file manifest |
| `get_chunk` | per scope, **re-authorised on every chunk** | one chunk |
| `public_catalogue`, `get_publication` | anyone, if the node serves its public catalogue | published editions and their signed manifests |
| `propose` | member with the matching permission | `add_item`, `update_collection`, `share_annotation`, `unshare_annotation`, `set_member`, `revoke_member` |
| `sync_digest`, `sync_fetch`, `sync_push` | the user's own linked devices only | metadata synchronisation (docs/SYNC.md) |
| `key_rotation` | trusted, authenticated with the *old* key | announce a new device key |

### Scopes

`get_manifest`/`get_chunk` name the authority under which a file is requested:

* `collection:<id>` — on the owner's device: requester's account must be an
  *active* member with `download`, and the hash must belong to an active item
  of that collection. On a member's device: only the collection's owner, and
  only for files that member proposed.
* `public` — the hash must belong to a published, not-withdrawn edition (or
  an explicitly mirrored one).
* `device` — the requester must be one of the user's own linked devices.

### Errors and the “no oracle” rule

Any authorisation failure for private data returns
`error {code: "not_found_or_forbidden", message: ""}` — identical whether the
collection, edition or hash does not exist or the requester lacks permission.
`tests/end_to_end/test_unauthorised_peer.py` asserts that real and invented
identifiers produce byte-identical answers. Other codes: `invitation_invalid`,
`rate_limited`, `stale_authority`, `conflict`, `bad_message`,
`frame_too_large`, `version_mismatch`, `proposals_disabled`, `blocked`.

### Permission versions

Each collection has a `permission_version` that increases on every membership
change. Requests carry the highest version the requester has seen
(`known_version`). If that is higher than the serving device's own version,
the device is behind (for example an owner's second device that missed a
revocation) and answers `stale_authority` instead of serving.

## 5. Manifests

Canonical form for hashing and signing: JSON with sorted keys, no
insignificant whitespace, UTF-8, integers only (`domain.util.canonical_json`).

### File manifest (`schemas/file-manifest.schema.json`)

```json
{
  "manifest_version": 1, "protocol_min": 1,
  "file_hash": "<sha256 of the whole file>", "size": 513005,
  "chunk_size": 262144,
  "chunks": [{"index": 0, "size": 262144, "sha256": "…"}, …],
  "format": "epub", "media_type": "application/epub+zip",
  "filename": "the-lantern-archive.epub",
  "edition_id": "<edition identifier>", "role": "primary"
}
```

Validation on receipt, before any chunk is requested: total serialized size
≤ `max_manifest_bytes`; chunk count ≤ `max_chunks`; `16 KiB ≤ chunk_size ≤ 4 MiB`;
indexes contiguous; only the last chunk may be short; chunk sizes sum to
`size`; `size` ≤ `max_document_bytes`; `file_hash` equals the hash that was
requested; `protocol_min` supported. The filename is reduced to a safe single
path component and is never used to choose a storage location.

### Publication manifest (`schemas/publication-manifest.schema.json`)

Carries the publication/work/edition identifiers, edition number and label,
`previous_edition_id` / `previous_publication_id` / `previous_manifest_id`
and `relation` for revisions, revision notes, descriptive metadata,
contributors, licence and rights statement, accessibility information, an
optional cover manifest, one or more file manifests, `published_at`, and
optionally `publisher {name, key, key_id}` plus
`signature {alg: "ed25519", key_id, value}`.

* **Manifest id** = SHA-256 of the canonical manifest without `signature`.
  It identifies one immutable edition.
* **Signature** = Ed25519 over `"aureom-commons/v1/publication-manifest\n"`
  followed by the same canonical bytes.
* A receiver reports precisely what it checked (`SignatureReport.statements`):
  well-formedness, whether the signature matches the stated key, that the
  name is self-declared, whether the key was previously pinned, and that
  hashes are evidence of matching bytes only. An invalid signature causes the
  manifest to be rejected; an unsigned manifest is accepted and labelled unsigned.

All signatures in the system are Ed25519 with a purpose prefix
(`device-endorsement`, `pairing-invitation`, `device-key-rotation`,
`publication-manifest`, `relay-auth`, `rendezvous-request`), so a signature
made for one purpose cannot be replayed as another.

## 6. Transfers

1. Obtain and validate the manifest (public downloads take it from the signed
   publication manifest).
2. Check the storage quota and free disk space.
3. Fetch chunks (one worker per source, up to four sources). **Each chunk is
   hashed and compared with the manifest before it is written** to temporary
   storage; a mismatch is rejected, counted and re-queued. A source that
   sends the same chunk damaged three times, or is damaged throughout, is
   dropped; if every source is dropped the transfer fails without waiting.
4. Progress (a per-chunk bitmap) is persisted, so pause, lost connections and
   application restarts resume rather than restart. Connection failures retry
   with exponential backoff and jitter (up to 8 rounds, then the transfer
   waits for a manual resume).
5. When every chunk is present the whole file is hashed again, then streamed
   into the content-addressed store and promoted with an atomic rename. Only
   then does the catalogue show it as available and index its text.

Temporary partial files live in the profile's private `tmp/transfers/`
directory; in an encrypted library they are encrypted per chunk. Transfers
are pull-only: no request a peer can send causes this device to fetch or
store a file. Per-peer bandwidth limits apply to both serving and downloading.

## 7. Pairing invitations (`schemas/pairing-invitation.schema.json`)

An invitation (file `*.aureom-invite`, compact text `aureom-invite:…`, or the
same text as a QR code) contains the inviter's device certificate and id,
account endorsement, addresses, optional relay, a 256-bit one-time token, an
expiry, a purpose (`pair`, `link-device`, `collection`) and — for collection
invitations — the collection name, permissions and item count. It is signed
by the inviter's device key.

Redemption: the joiner pins the inviter's key from the invitation, connects
anonymously, sends `pair_request` (token + its own certificate), then
reconnects with mutual TLS and sends `pair_confirm`. The token is consumed
atomically on first use; expired, cancelled, unknown and reused tokens all
yield `invitation_invalid`. An invitation is therefore not a bearer link to
content: after redemption every request is authenticated by the redeemer's
private key, and access can be revoked.

The signature shows the invitation was made by the holder of that device key.
Who that is must be established by comparing fingerprints out of band.

## 8. What each party can observe

| Observer | Can see | Cannot see |
|---|---|---|
| Network eavesdropper (direct mode) | both IP addresses and ports, timing, traffic volume, the SNI value (the server's device id), that TLS 1.3 is in use | messages, metadata, manifests, file contents; the client certificate (encrypted in TLS 1.3) |
| A paired peer that is not a member | your device name, device and account fingerprints, your address; your public catalogue if you serve one | private collections: names, titles, hashes, members — including whether a guessed id exists |
| A collection member | the collection's name and description, titles and the shared metadata fields, file hashes if they may download, annotations explicitly shared there, the member list only with `manage_members` | personal tags, import sources, private annotations, reading progress, other collections, the rest of the library |
| LAN (discovery on) | a beacon with device id and port — and device name only if separately enabled | anything else; beacons never contain titles, collection names or hashes |
| **Relay** | device ids of both ends, their IP addresses, time, duration and byte counts of each session; relay control messages are authenticated but not encrypted | everything inside the session: it carries the same end-to-end pinned TLS 1.3 stream, so the relay sees only ciphertext and cannot alter it undetected |
| **Rendezvous** | device ids, registered addresses and contact lists (kept for 1 hour); announced *published* manifests and the announcing address; reports; request timing and IPs | private collections, private titles and hashes, file contents — none are ever sent to it |

### Local-network discovery (opt-in)

UDP multicast `239.255.42.99:47474`, TTL 1, one JSON datagram ≤ 512 bytes:
`{"app":"aureom-commons","v":1,"device_id":…,"port":…[,"name":…]}`. Received
beacons are validated, capped (200 devices) and shown as *unverified*. A
beacon grants nothing; for an already-paired device it may supply an address
to try, and the connection is still pinned to that device's key.

### Relay (opt-in)

Newline-delimited JSON control messages over TCP, then a raw byte splice:

```
→ {"op":"hello","role":"listen"|"dial","device_id":…,"public_key":…,"target":…}
← {"challenge": "<nonce>"}
→ {"signature": Ed25519("relay-auth", canonical{nonce, role, device_id, target})}
← {"ok": true}
listen:  ← {"event":"incoming","session":"<id>"}   then a second connection  → {"op":"hello","role":"accept","session":"<id>"}
dial:    ← {"connected": true}   then both ends run pinned TLS 1.3 through the spliced stream
```

The listening device bridges the relayed stream to its own TLS listener on
loopback, so exactly the same authentication and authorisation code handles
relayed and direct sessions. `tests/integration/test_rendezvous_relay.py`
captures everything the relay forwards and asserts that no plaintext, hash,
collection id or protocol field appears in it.

### Rendezvous (opt-in)

HTTP+JSON. Mutating requests are wrapped in a signed envelope
`{device_id, public_key, timestamp, nonce, body, signature}`; the service
checks the key matches the device id, the signature covers the request path,
the timestamp is within 120 s and the nonce is unused. Endpoints:
`/v1/register`, `/v1/lookup` (answered only for devices the target listed as
contacts), `/v1/catalogue/announce|withdraw|search`, `/v1/reports`, and
operator-only `/v1/admin/reports|delist`. Delisting affects this index only.
The transport to the rendezvous service is whatever URL you configure — use
`https://` in deployment; the reference service itself speaks plain HTTP and
is meant to sit behind a TLS terminator.
