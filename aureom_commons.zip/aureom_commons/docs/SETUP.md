# Setup, configuration and packaging

## Requirements

* Python 3.11 or newer with SQLite ≥ 3.38 (FTS5, JSON functions and
  serialise support — standard in current CPython builds).
* TLS 1.3 in the Python `ssl` module (OpenSSL 1.1.1+).
* For the desktop interface: PySide6 6.7+ (`pip install ".[desktop]"`).
  On minimal Linux systems Qt also needs `libegl1`, `libgl1`,
  `libxkbcommon0`, `libfontconfig1` and `libdbus-1-3`.

Dependency versions verified during development (Linux, CPython 3.13):
PySide6 6.12, FastAPI 0.165, uvicorn 0.54, Pydantic 2.13, cryptography 50,
nh3 0.3.8, pypdf 6.17, defusedxml 0.7.1, markdown-it-py 4.3, segno 1.6,
keyring 25.7, httpx 0.28. A second run in a clean virtual environment resolved
newer releases (Pydantic 2.14, pypdf 7.1, cryptography 50.0.2) and passed the
same suite. The TLS behaviour the design relies on
(client-certificate handling with an SNI-selected context, public-key
pinning, TLS 1.3 only) is covered by the integration tests rather than
assumed.

## Install

```bash
python -m venv .venv
```
```bash
. .venv/bin/activate
```
```bash
pip install -e ".[dev]"
```

Extras: `desktop` (PySide6), `qrscan` (decode a QR image file), `dev`
(pytest + PySide6). The core, the headless node and the rendezvous service
work without PySide6.

## Run

| Command | What it starts |
|---|---|
| `aureom-commons [--profile NAME \| --profile-dir PATH]` | the desktop application |
| `aureom-node --profile-dir PATH --api-port 8700 [--listen-port N]` | a headless installation with the local API |
| `aureom-rendezvous --port 8800 --relay-port 8801 --db FILE` | the optional rendezvous index and relay |
| `python scripts/demo_three_peers.py` | the reproducible three-peer demonstration |
| `python -m pytest` | the test suite (about 1–2 minutes) |

Profiles live under `~/.local/share/aureom-commons/profiles/` (Linux),
`%APPDATA%\AureomCommons\profiles\` (Windows) or wherever `AUREOM_HOME`
points. Each profile is a complete, isolated installation:

```
<profile>/
  profile.json            id and whether the library is encrypted
  vault.json              wrapped library key (encrypted libraries only)
  catalogue.db            SQLite catalogue        — or catalogue.db.enc when encrypted
  objects/ab/<name>       content-addressed files — encrypted, with keyed names, when encrypted
  tmp/                    private (0700): partial downloads, temporary views
  secrets.json            keys, only if neither encryption nor an OS keyring is available
  api-token, api.json     loopback API credential (headless node only)
```

### Local API

`aureom-node` serves FastAPI on `127.0.0.1` only. Every request needs
`Authorization: Bearer <contents of api-token>`. Interactive documentation is
at `/docs`. The API is a thin layer over the same facade the desktop uses;
`apps/local_api/app.py` is the reference for endpoints.

```bash
curl -s -H "Authorization: Bearer $(cat alice/api-token)" http://127.0.0.1:8700/status
```

The desktop application does not open this API; use the headless node for automation.

### Configuration

Settings are stored in the profile database (so they are protected with an
encrypted library). Change them in *Settings*, with
`aureom-node --set KEY=JSON --limit NAME=JSON`, or `PATCH /settings` and
`PATCH /settings/limits`. `config/example-settings.json` lists every key with
its default. Optional features and their switches:

| Feature | Setting | Default |
|---|---|---|
| Networking at all | `network_enabled` (also the status button) | on, loopback only |
| Reachable from other machines | `listen_host` = `0.0.0.0`, `advertise_addresses` | off (`127.0.0.1`) |
| Local-network discovery | `lan_discovery`, `lan_announce_name` | off |
| Relay | `relay_address` | off |
| Rendezvous / public index | `rendezvous_url` | off |
| Serve your published editions to direct visitors | `serve_public_catalogue` | on (nothing is served until you publish) |
| Accept proposals from collection members | `accept_proposals` (`ask` / `never`) | ask |
| Full-text indexing of new imports | `index_default` (`full` / `metadata` / `none`) | full |

To share between two machines: set `listen_host` to `0.0.0.0` on at least one
of them, open the chosen port in its firewall, and put an address the other
can reach in `advertise_addresses` (for example `192.168.1.20:47001` or a
forwarded public address). There is no automatic NAT traversal.

### Environment variables

| Variable | Effect |
|---|---|
| `AUREOM_HOME` | where named profiles are stored |
| `AUREOM_DISABLE_KEYRING=1` | never use the OS credential store (used by tests and the demo) |
| `AUREOM_DEMO_FAULTS=1` | enables the development-only `/debug/*` endpoints on `aureom-node` |
| `AUREOM_OPERATOR_TOKEN` | operator token for the rendezvous service's moderation endpoints |

## Running the optional service

```bash
AUREOM_OPERATOR_TOKEN=change-me aureom-rendezvous --host 0.0.0.0 --port 8800 --relay-port 8801 --db rendezvous.sqlite
```

Put the HTTP port behind a TLS-terminating reverse proxy and give clients the
`https://` URL. The relay port carries end-to-end encrypted sessions and can
be exposed directly. Read docs/PROTOCOL.md §8 for what an operator can see.

## Packaging

```bash
scripts/package_desktop.sh wheel
```
builds `dist/aureom_commons-0.1.0-py3-none-any.whl` (pure Python; SQL
migrations included as package data).

```bash
scripts/package_desktop.sh app
```
builds a PyInstaller one-folder desktop bundle in `dist/aureom-commons/`.
Run it on each target operating system. The bundle re-enters its own
executable for the isolated extraction worker. PyInstaller packaging was
scripted but **not exercised** as part of this delivery (see
docs/CAPABILITIES.md); the wheel build and editable install were.

## Regenerating generated material

| Command | Output |
|---|---|
| `python scripts/make_fixtures.py` | `fixtures/` (deterministic) |
| `python scripts/export_schemas.py` | `schemas/*.json` |
| `QT_QPA_PLATFORM=offscreen python scripts/render_screenshots.py` | `docs/screenshots/*.png` |
