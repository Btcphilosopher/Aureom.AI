# Capability and limitations report

Version 0.1.0. This report is meant to be read sceptically: it separates what
is implemented **and exercised by automated tests**, what is implemented but
only lightly exercised, and what is deferred. Nothing listed as implemented is
an interface placeholder.

Verification performed for this delivery (Linux, CPython 3.13, PySide6 6.12):

* `python -m pytest` — 114 tests: unit, integration over real TLS 1.3 on
  loopback, and end-to-end (the three-process demonstration, an
  unauthorised-peer proof, and the desktop interface driven off-screen).
* `python scripts/demo_three_peers.py` — all 15 steps.
* `scripts/render_screenshots.py` — every page rendered off-screen, both themes.
* Wheel build (`python -m build --wheel`) and editable install.

Not performed: any run on Windows or macOS; any run with a physical display,
audio device or OS keyring; the PyInstaller bundle; an independent security review.

## Implemented and tested

| Area (spec §) | What works |
|---|---|
| Three spaces (1) | Private / Shared / Public are derived from facts (membership, publication state), shown as badges everywhere; importing never shares or announces |
| Interface (2) | PySide6 application with the eight navigation pages plus Home; midnight/ivory/copper theme, light and dark; serif titles, sans controls; cover grid and catalogue table; drag-and-drop import; keyboard shortcuts (Ctrl+1…8, Ctrl+H/F/I, Ctrl+±/0); scalable text; accessible names and tooltips on controls; connection status always visible (Offline / Direct / Relay) |
| Architecture (3) | PySide6 GUI, FastAPI local API and rendezvous, asyncio networking, SQLite + FTS5, content-addressed store, Pydantic-validated protocol, `cryptography`/OpenSSL for all cryptography, pytest. Domain packages import neither Qt nor the transport |
| Import (4) | validation and limits → signature-based format detection → SHA-256 → metadata/text extraction in an isolated, resource-limited subprocess → managed copy or reference → private catalogue; per-file failure reporting; all listed metadata fields; imported vs user-corrected metadata stored separately; hash deduplication; same-title files never merged; explicit editions with relationships |
| Reading (5) | EPUB (contents, chapter navigation, reflow), plain text, Markdown, HTML, PDF (QtPdf: pages, zoom, search), PNG/JPEG/GIF/WebP/SVG, audio (QtMultimedia); bookmarks, highlights, notes, per-device reading progress; in-document find; full-text search for EPUB/PDF/text/Markdown/HTML; sanitised HTML and SVG, no scripts, no remote resources, links confirmed; annotations stored apart and anchored to edition + content hash; re-anchoring to a new edition with ok / needs-review / orphaned; unsupported formats stated honestly with a confirmed external-open action |
| Identities (6) | separate device, account and publisher keys; invitation file / text / QR display; fingerprint display and explicit “verified” marking; trusted list; removal and blocking; device-key rotation with signed statement and grace period; recovery behaviour documented (docs/IDENTITY.md) |
| Networking (7) | stage 1 direct connections; stage 2 opt-in LAN discovery; stage 3 opt-in rendezvous and relay with end-to-end TLS through the relay; mutual authentication; permission checks before any metadata or bytes; networking disabled with an explanation if TLS 1.3 is unavailable |
| Transfers (8) | versioned manifests (file hash, chunk hashes and sizes, size, format, edition id, protocol version, optional publisher signature at publication level); chunked download; pause/resume; resume after disconnect and after restart; backoff; per-peer bandwidth limits; cancel; per-chunk and whole-file verification; private temporary storage (encrypted in encrypted libraries); atomic promotion; multi-source retrieval for public works; private hashes only behind authorisation |
| Private sharing (9) | collections with six permissions plus an off-by-default redistribution flag; exposure preview before inviting; one-time expiring invitations (no bearer links); authenticated downloads; proposals that wait for the owner; explicit annotation sharing; accurate revocation wording |
| Publishing (10) | Draft → Preview → Rights Review → Published → Revised / Withdrawn enforced in code; disclosure preview bound to the publish action by digest; package fields as specified; signed manifests; immutability (also SQL triggers); corrections as linked new editions; withdrawal stops serving |
| Search & discovery (11) | local FTS + metadata filters; results respect spaces; local / authorised-peer / unavailable shown; public discovery only via opt-in announcements; signature reports state exactly what was checked and never say “verified” |
| Sync (12) | version-vector sync of catalogue records, corrections, annotations, progress, owned collections and membership between linked devices; all listed conflict rules; file replication separate; old records cannot restore revoked access; `stale_authority` |
| Protection (13) | optional encrypted library covering catalogue, FTS index, annotations, covers, managed files, partial downloads and keys (verified byte-for-byte on disk); protected temporary views; per-document index modes; encrypted backup and tested restoration (plain↔encrypted); device-loss guidance; log hygiene |
| Abuse controls (14) | limits for document size, manifest size, chunk count, concurrent transfers, storage, decompression ratio and entries, extraction time and memory, search requests, announcements, connections, request rate; defences for traversal, hostile filenames, archive bombs, malformed messages, replayed invitations, disk exhaustion; blocking; pull-only transfers; reporting to the index operator; moderation confined to the public index |
| Demo & tests (16, 17) | three isolated profiles/processes; every item in §17 has tests, including the unauthorised-peer end-to-end proof |

## Implemented, with limits you should know

* **Extraction isolation is process-level**, with rlimits and a timeout on
  POSIX. It is not a filesystem/network sandbox, and on Windows only the
  timeout applies.
* **EPUB rendering** uses Qt's rich-text engine: reflowable text, headings,
  lists, tables and embedded images render; publisher CSS, fixed-layout
  EPUBs, MathML, audio/video overlays and embedded fonts do not. This is the
  price of having no script engine in the reader.
* **PDF annotations** are page bookmarks and page notes. Text highlights
  inside PDFs are not provided. PDF text selection for quoting is not provided.
* **Audio** depends on the system's multimedia backend. The player opened the
  fixture in the headless test environment but no sound device was available,
  so audible playback is unverified here.
* **Search filters in the interface** cover space, format, language, tag,
  collection, availability and author; rights and publication-date filters
  exist in the catalogue API (`/library?rights=&date_from=&date_to=`) but
  have no dedicated control in the Library toolbar.
* **OS credential storage** uses `keyring` when a real backend is present.
  No backend exists in the test environment, so only the fallbacks
  (encrypted library; owner-only file) were exercised.
* **QR codes** are displayed for every invitation. Decoding a QR *image file*
  needs the optional `qrscan` extra and was not covered by automated tests.
  Camera scanning is not provided.
* **Encrypted catalogue performance.** The database lives in memory while
  unlocked and the whole snapshot is re-encrypted on each committed write —
  measured at about 0.3 s per write for a 60 MB catalogue. Fine for personal
  libraries; a very large full-text index will make writes sluggish. The
  plain mode has no such cost.
* **Library passphrase** cannot be changed from the interface (the function
  exists in `storage.crypto.Vault`); to move between encrypted and
  unencrypted, export a backup and restore it into a new folder.
* **Key rotation** covers device keys. Account keys cannot be rotated in
  band; publisher keys are replaced by creating a new imprint.
* **Private collections are served by their owner's devices only.** Members
  do not re-serve to each other (they serve only works they themselves
  proposed, and only to the owner).
* **Revocation and offline devices** behave as described in docs/SYNC.md: an
  owner's stale second device may serve until it syncs; nothing can recall
  downloaded copies.
* **Relay control messages** are authenticated but unencrypted; the
  reference rendezvous service speaks plain HTTP and expects a TLS
  terminator in front of it.
* **Accessibility**: labels, tooltips, focus rings, keyboard navigation and
  text scaling are implemented; no screen-reader testing was done.
* **The desktop application does not open the local API**; use `aureom-node`
  for automation against a profile (not both at once on the same profile).
* **One process per profile.** There is no lock file; opening the same
  profile twice concurrently is unsupported.

## Deferred (not implemented)

* NAT traversal of any kind (hole punching, UPnP, TURN-style fallbacks beyond the simple relay).
* Camera-based QR scanning; a mobile companion.
* Swarm-style distribution of private collections among members.
* Account-key rotation and recovery; multi-party or hardware-backed keys.
* Third-party or web-of-trust identity verification for publishers (by design
  the application only reports self-issued signatures as such).
* A full sandbox (seccomp/namespaces/AppContainer) for document processing.
* Transparent database encryption without the in-memory snapshot (e.g. SQLCipher).
* Tested installers for Windows/macOS/Linux; the PyInstaller recipe in
  `scripts/package_desktop.sh` is provided but unexercised.
* DOCX/ODT/other office formats in the reading room (they import, are
  catalogued and can be shared, and are shown as unsupported for reading).

## Known rough edges

* Fingerprints are long (52 base32 characters). They are shown in groups of
  four; a shorter comparison code is not offered.
* The Activity journal grows without pruning.
* Completed-transfer rows are kept indefinitely.
* The diagnostic log deliberately omits titles, which makes some support
  questions harder to answer from the log alone.
