# Threat model

Scope: one user's installation(s) of Aureom Commons, the peers they pair
with, and the optional rendezvous/relay service. This document says what the
design defends, how, and what it does not defend. It has not been
independently audited.

## Assets

1. Contents of private and shared documents.
2. Private metadata: titles, collection names, membership, annotations,
   reading progress, tags, import sources, file hashes of private works.
3. Integrity of the library (no silent substitution or corruption).
4. Integrity and attribution of published editions.
5. Keys: device, account, publisher, library master key.
6. Availability of the local library (it must keep working offline).

## Trust assumptions

* The user's OS account, Python runtime and the libraries in `pyproject.toml`
  (notably OpenSSL via `ssl`, and `cryptography`) are trusted.
* A paired peer is trusted **only** with what it is authorised to receive.
* Documents, manifests, metadata, invitations, beacons and every protocol
  message are untrusted input, whoever sent them.
* The rendezvous/relay operator is untrusted for confidentiality and
  integrity, and semi-trusted for availability.

## Adversaries and what happens

### A. Network attacker (passive or active, any path including a relay)

| Attack | Outcome |
|---|---|
| Read traffic | TLS 1.3; sees addresses, timing, sizes and the server's device id (SNI) |
| Impersonate a paired peer | fails: the client pins the peer's public key; the server only accepts certificates of paired devices |
| Man-in-the-middle at pairing | prevented **only if** the two people compare fingerprints out of band; otherwise whoever controlled the invitation's delivery could have substituted their own. The interface says “not verified” until the user confirms |
| Downgrade | none available: TLS 1.3 minimum, no alternative transport |
| Tamper with a relayed stream | detected by TLS; the relay can only drop or delay |
| Replay an invitation | token is single-use and expiring; replays get `invitation_invalid` |
| Replay a rendezvous request | signed envelope with timestamp window and nonce cache |

### B. Unauthorised peer (anonymous, or paired but not a member)

| Attack | Outcome |
|---|---|
| List private collections | `list_shared` returns only collections the requester's *account* belongs to; anonymous callers are refused |
| Fetch a private manifest/chunk knowing the hash and collection id | refused; authorisation is checked on every request against the owner's current membership table |
| Probe whether an id or hash exists | every refusal is the identical `not_found_or_forbidden`, same size, for real and invented ids |
| Abuse the `public` or `device` scope to reach private files | `public` serves only hashes in live published manifests; `device` requires the user's own linked device |
| Push content / start transfers on the victim | impossible: transfers are pull-only; proposals to a collection store metadata only until the owner accepts, are capped at 50 pending, and can be disabled |
| Flood requests / searches / pairing guesses | per-connection request bucket, search bucket, global pairing bucket, connection cap, idle timeout, frame caps |

### C. Malicious authorised member

| Attack | Outcome |
|---|---|
| Keep, copy or redistribute what they downloaded | **not preventable.** The interface says so at invitation and revocation. `redistribute` is an honest-client policy flag (default off): this application refuses to re-share or publish privately shared works without it |
| Escalate permissions | `set_member` cannot grant more than the manager holds, cannot target the owner or the caller |
| Resurrect access after revocation with an old record | the owner's table is authoritative; version vectors make a stale membership record lose to the revocation; `known_version` makes a stale owner device refuse |
| Overwrite the collection | `update_collection` carries the revision the member last saw; a stale base is a `conflict` |
| Poison other members | shared metadata is cleaned on receipt; identifiers are validated; a remote edition can never be grafted onto a local work or overwrite a local edition |

### D. Malicious serving peer / publisher

| Attack | Outcome |
|---|---|
| Send corrupt or substituted chunks | each chunk verified before it is written; whole file verified before promotion; persistent offenders dropped |
| Oversized or inconsistent manifest (memory/disk exhaustion) | size, chunk-count, chunk-size, sum and document-size checks before any chunk is fetched; quota and free-space check |
| Manifest for a different file | must match the requested hash |
| Malicious filename / path traversal | filenames are reduced to one safe component and never used as storage paths; objects are stored by hash |
| Forged or altered publication | invalid signature → rejected; unsigned → labelled unsigned; nobody but the same publisher key can mark an edition “superseded” |
| Claim to be a well-known publisher | the name is shown as self-declared; first sight of a key says so; pinning shows continuity only |

### E. Malicious document

| Attack | Outcome |
|---|---|
| Zip bomb / huge archive / millions of entries | entry-count, per-entry, total-size and ratio limits; capped reads that distrust header sizes; nothing extracted to disk |
| Parser exploit / hang during import | metadata and text extraction run in a separate short-lived process with CPU, address-space, file-size and descriptor limits (POSIX) and a wall-clock timeout; output is size-capped and validated; failure degrades to basic details |
| XML entity expansion | `defusedxml` |
| Script, remote resource or tracking pixel in EPUB/HTML/Markdown | HTML sanitised with `nh3` (allow-list); rendered in `QTextBrowser`, which has no script engine; the view loads only images from inside the same book; external links require confirmation |
| Active SVG | scripts, `foreignObject`, event handlers and external references stripped before rendering |
| Active PDF content | pages are rendered by QtPdf; the application never executes embedded scripts or launches attachments. Opening externally is an explicit, confirmed action |
| Hostile metadata (control characters, bidi overrides, megabyte titles) | every text field cleaned and capped on the way in |

### F. Someone with the disk (lost device, backup medium, another OS user)

| Situation | Outcome |
|---|---|
| Encrypted library, locked | catalogue, FTS index, annotations, covers, managed files, partial downloads and keys are ciphertext (ChaCha20-Poly1305; scrypt-derived key). Object file names are keyed HMACs, so known-file presence cannot be tested. Tested byte-for-byte in `test_protection_and_backup.py` |
| Encrypted library, unlocked and running | plaintext exists in process memory; a PDF/audio/external viewer needs a temporary decrypted copy in a 0700 directory, removed on lock (best-effort overwrite) |
| Unencrypted library | everything is readable by anyone with access to the profile folder; the interface states this |
| Referenced (unmanaged) imports | ordinary files; never protected; reported separately |
| Backup file | encrypted with its own passphrase; tampering and wrong passphrase detected; member names allow-listed on restore |
| Logs | the diagnostic log gets event kinds and truncated ids only; titles, text, tokens and keys are never passed to it. The Activity journal is inside the database |

### G. Rendezvous / relay operator

Can observe the metadata listed in docs/PROTOCOL.md §8, deny service, delist
public entries, and return wrong lookup answers (which only cause failed
connections, because keys are pinned). Cannot read or alter relayed content,
never receives private-collection data, and has no influence on private
libraries or direct sharing.

## Residual risks and non-goals

* **No protection against a compromised endpoint.** Malware in the user's
  session can read an unlocked library and use its keys.
* **Traffic analysis.** Sizes, timing and peers' IP addresses are visible.
  There is no anonymity layer; peers learn each other's addresses.
* **The extraction worker is not a full sandbox.** It limits resources and
  isolates crashes; it does not confine filesystem or network access
  (no seccomp/namespaces), and on Windows only the timeout applies.
* **Fingerprint verification is a human step** that the software can prompt
  for but not enforce.
* **Account key on every linked device**; no in-band account-key rotation.
* **Relay control channel** is authenticated but unencrypted.
* **Denial of service** by a peer you have paired with is limited, not eliminated.
* **Deleted data.** Removing a work deletes the managed object file; secure
  erasure from SSDs/journalling filesystems is not guaranteed.
* **Legal and content questions** (is a file lawful, accurate, safe to open,
  correctly licensed) are outside what any hash or signature here can answer.
