"""Headless node: one profile, the peer listener and the local API.

    aureom-node --profile-dir ./alice --device-name "Alice's laptop" --api-port 8701 --listen-port 47001
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
from pathlib import Path

import uvicorn

from aureom.domain.errors import CommonsError
from aureom.node import Profile, profiles_root, setup_logging

from .app import create_app


def api_token(profile_dir: Path) -> str:
    """Loopback API credential, stored owner-only beside the profile."""
    path = profile_dir / "api-token"
    if path.exists():
        return path.read_text().strip()
    token = secrets.token_urlsafe(32)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(token)
    return token


def open_or_create(args) -> "object":
    root = Path(args.profile_dir) if args.profile_dir else profiles_root() / args.profile
    passphrase = os.environ.get(args.passphrase_env) if args.passphrase_env else None
    if Profile.info(root) is None:
        kdf = json.loads(args.kdf) if args.kdf else None
        ctx = Profile.create(root, device_name=args.device_name or root.name, account_name=args.account_name or "",
                             passphrase=passphrase, kdf=kdf)
    else:
        ctx = Profile.open(root, passphrase)
    if args.listen_port is not None:
        ctx.settings.set("listen_port", args.listen_port)
    if args.listen_host:
        ctx.settings.set("listen_host", args.listen_host)
    for item in args.set or []:
        key, _, value = item.partition("=")
        ctx.settings.set(key, json.loads(value))
    if args.limit:
        ctx.settings.set_limits(**{k: json.loads(v) for k, _, v in (i.partition("=") for i in args.limit)})
    return ctx


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="aureom-node", description=__doc__.splitlines()[0])
    parser.add_argument("--profile", default="default", help="named profile under the profiles folder")
    parser.add_argument("--profile-dir", help="explicit profile folder (overrides --profile)")
    parser.add_argument("--device-name")
    parser.add_argument("--account-name")
    parser.add_argument("--passphrase-env", help="environment variable holding the library passphrase")
    parser.add_argument("--kdf", help="JSON key-derivation parameters (testing only)")
    parser.add_argument("--api-port", type=int, default=8700)
    parser.add_argument("--listen-host")
    parser.add_argument("--listen-port", type=int)
    parser.add_argument("--set", action="append", metavar="KEY=JSON", help="set a profile setting")
    parser.add_argument("--limit", action="append", metavar="NAME=JSON", help="set a resource limit")
    parser.add_argument("--log-level", default="warning")
    args = parser.parse_args(argv)
    try:
        ctx = open_or_create(args)
    except CommonsError as exc:
        sys.exit(f"aureom-node: {exc}")
    setup_logging(ctx.path / "node.log")
    token = api_token(ctx.path)
    (ctx.path / "api.json").write_text(json.dumps({"url": f"http://127.0.0.1:{args.api_port}", "pid": os.getpid()}))
    try:
        uvicorn.run(create_app(ctx, token), host="127.0.0.1", port=args.api_port, log_level=args.log_level,
                    access_log=False)
    finally:
        ctx.close()


if __name__ == "__main__":
    main()
