"""Local application API (FastAPI).

A loopback-only HTTP interface to one running installation, for automation,
scripting and the three-peer demonstration.  It exposes the same ``Commons``
facade the desktop interface uses — there is no separate business logic here.

Security model: bound to 127.0.0.1, every request needs the bearer token
stored (mode 0600) in the profile directory.  It is not meant to be exposed
to a network.
"""
from __future__ import annotations

import asyncio
import hmac
import os
from typing import Any

from fastapi import Body, Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse

from aureom import __version__
from aureom.domain.errors import (CommonsError, Conflict, InvalidInput, LibraryLocked, LimitExceeded, NotFound,
                                  PermissionDenied, StateError, TransportError)
from aureom.domain.util import is_sha256_hex

STATUS = [(NotFound, 404), (PermissionDenied, 403), (InvalidInput, 422), (LimitExceeded, 413), (Conflict, 409),
          (StateError, 409), (LibraryLocked, 423), (TransportError, 502)]
Json = dict[str, Any]


def create_app(ctx, token: str, *, manage_node: bool = True) -> FastAPI:
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        if manage_node:
            await ctx.node.start()
        yield
        if manage_node:
            await ctx.node.stop()

    def auth(authorization: str = Header(default="")) -> None:
        if not hmac.compare_digest(authorization, f"Bearer {token}"):
            raise HTTPException(401, "missing or invalid API token")

    app = FastAPI(title="Aureom Commons local API", version=__version__, lifespan=lifespan,
                  dependencies=[Depends(auth)])
    node = ctx.node

    @app.exception_handler(CommonsError)
    async def on_error(_request: Request, exc: CommonsError):
        status = next((code for cls, code in STATUS if isinstance(exc, cls)), 400)
        return JSONResponse({"error": exc.code, "message": str(exc)}, status_code=status)

    # ------------------------------------------------------------ overview
    @app.get("/status")
    def status() -> Json:
        return ctx.status()

    @app.get("/home")
    def home() -> Json:
        return ctx.home()

    @app.get("/activity")
    def activity(limit: int = 100, kind: str = "") -> list[Json]:
        return ctx.activity.recent(min(limit, 500), kind)

    @app.get("/settings")
    def settings() -> Json:
        return ctx.settings.all() | {"limits": ctx.settings.limits.model_dump()}

    @app.patch("/settings")
    def update_settings(changes: Json = Body(...)) -> Json:
        allowed = set(ctx.settings.all()) - {"limits"}
        for key, value in changes.items():
            if key not in allowed:
                raise InvalidInput(f"unknown setting: {key}")
            ctx.settings.set(key, value)
        return settings()

    @app.patch("/settings/limits")
    def update_limits(changes: Json = Body(...)) -> Json:
        try:
            return ctx.settings.set_limits(**changes).model_dump()
        except ValueError as exc:
            raise InvalidInput(str(exc)[:300]) from None

    @app.get("/protection")
    def protection() -> Json:
        return ctx.protection_report()

    # ------------------------------------------------------------- library
    @app.post("/library/import")
    async def import_paths(body: Json = Body(...)) -> list[Json]:
        results = await asyncio.to_thread(ctx.catalogue.import_paths, body.get("paths") or [], mode=body.get("mode"))
        return [r.as_dict() for r in results]

    @app.get("/library")
    def library(q: str = "", space: str = "", collection_id: str = "", availability: str = "", author: str = "",
                title: str = "", language: str = "", format: str = "", tag: str = "", rights: str = "",
                date_from: str = "", date_to: str = "", limit: int = 200) -> list[Json]:
        return ctx.catalogue.list(q, space=space, collection_id=collection_id, availability=availability,
                                  author=author, title=title, language=language, fmt=format, tag=tag, rights=rights,
                                  date_from=date_from, date_to=date_to, limit=min(limit, 1000))

    @app.get("/editions/{edition_id}")
    def edition(edition_id: str) -> Json:
        view = ctx.catalogue.edition_view(edition_id)
        view["metadata_layers"] = ctx.catalogue.metadata_layers(edition_id)
        view["editions"] = [{k: e[k] for k in ("edition_id", "edition_number", "label", "relation", "content_hash",
                                               "visibility", "availability")}
                            for e in ctx.catalogue.editions_of_work(view["work_id"])]
        return view

    @app.patch("/editions/{edition_id}/metadata")
    def edit_metadata(edition_id: str, changes: Json = Body(...)) -> Json:
        return ctx.catalogue.update_user_metadata(edition_id, changes).model_dump()

    @app.post("/editions/{edition_id}/index-mode")
    def index_mode(edition_id: str, body: Json = Body(...)) -> Json:
        ctx.catalogue.set_index_mode(edition_id, body.get("mode", ""))
        return {"index_mode": body.get("mode")}

    @app.get("/editions/{edition_id}/text")
    def text(edition_id: str, max_chars: int = 2000) -> Json:
        """Read the locally stored bytes (works offline) and return a text excerpt."""
        file = ctx.catalogue.primary_file(edition_id)
        verified = ctx.catalogue.verify_file(file) if file["available"] else False
        return {"available": bool(file["available"]), "hash_verified": verified,
                "excerpt": ctx.text_of(edition_id)[: min(max_chars, 20000)] if file["available"] else ""}

    @app.post("/editions/{edition_id}/download")
    def download(edition_id: str) -> Json:
        return {"transfer_id": node.download_edition(edition_id)}

    @app.post("/editions/{edition_id}/editions")
    async def add_edition(edition_id: str, body: Json = Body(...)) -> Json:
        work_id = ctx.catalogue.edition_row(edition_id)["work_id"]
        result = await asyncio.to_thread(
            ctx.catalogue.import_file, body["path"], work_id=work_id, label=body.get("label", ""),
            relation=body.get("relation", "revision-of"), previous_edition_id=edition_id,
            revision_notes=body.get("notes", ""))
        return result.as_dict()

    @app.delete("/editions/{edition_id}")
    def remove(edition_id: str) -> Json:
        ctx.catalogue.remove_edition(edition_id)
        return {}

    # --------------------------------------------------------- annotations
    @app.get("/editions/{edition_id}/annotations")
    def annotations(edition_id: str) -> list[Json]:
        return ctx.annotations.list(edition_id)

    @app.post("/editions/{edition_id}/annotations")
    def annotate(edition_id: str, body: Json = Body(...)) -> Json:
        return ctx.annotations.create(edition_id, body.get("kind", "note"), body.get("locator") or {},
                                      body.get("body", ""), body.get("colour", "copper"))

    @app.post("/editions/{edition_id}/progress")
    def progress(edition_id: str, body: Json = Body(...)) -> Json:
        ctx.annotations.set_progress(edition_id, body.get("locator") or {}, body.get("fraction", 0))
        return ctx.annotations.progress(edition_id)

    @app.post("/annotations/{annotation_id}/share")
    async def share_annotation(annotation_id: str, body: Json = Body(...)) -> Json:
        return await node.share_annotation(annotation_id, body.get("collection_id", ""))

    @app.post("/annotations/migrate")
    def migrate(body: Json = Body(...)) -> Json:
        return ctx.annotations.migrate(body["from_edition"], body["to_edition"])

    @app.get("/annotations/review")
    def review() -> list[Json]:
        return ctx.annotations.review_queue()

    # --------------------------------------------------------- collections
    @app.get("/collections")
    def collections() -> list[Json]:
        return ctx.collections.list()

    @app.post("/collections")
    def create_collection(body: Json = Body(...)) -> Json:
        return ctx.collections.create(body.get("name", ""), body.get("description", ""), body.get("kind", "shared"))

    @app.get("/collections/{cid}")
    def collection(cid: str) -> Json:
        return ctx.collections.get(cid)

    @app.post("/collections/{cid}/items")
    def add_item(cid: str, body: Json = Body(...)) -> Json:
        ctx.collections.add_item(cid, body["edition_id"])
        return {}

    @app.post("/collections/{cid}/preview")
    def exposure(cid: str, body: Json = Body(default={})) -> Json:
        return ctx.collections.exposure_preview(cid, body.get("permissions") or "reader")

    @app.post("/collections/{cid}/invite")
    def invite(cid: str, body: Json = Body(default={})) -> Json:
        """Invite a known account, or (without ``account_id``) create a
        one-time invitation file for someone not yet paired."""
        perms = body.get("permissions") or "reader"
        if body.get("account_id"):
            return ctx.collections.invite_account(cid, body["account_id"], perms)
        inv = node.create_invitation(purpose="collection", collection_id=cid, permissions=perms,
                                     ttl_hours=body.get("ttl_hours"))
        return {"invitation": inv.to_json(), "text": inv.to_text(), "expires_at": inv.expires_at,
                "preview": ctx.collections.exposure_preview(cid, perms)}

    @app.post("/collections/{cid}/revoke")
    def revoke(cid: str, body: Json = Body(...)) -> Json:
        return ctx.collections.revoke(cid, body["account_id"])

    @app.post("/collections/{cid}/permissions")
    def permissions(cid: str, body: Json = Body(...)) -> Json:
        ctx.collections.set_permissions(cid, body["account_id"], body["permissions"])
        return {}

    @app.delete("/collections/{cid}")
    def delete_collection(cid: str) -> Json:
        ctx.collections.delete(cid)
        return {}

    @app.post("/collections/{cid}/refresh")
    async def refresh(cid: str) -> Json:
        return await node.refresh_collection(cid)

    @app.post("/collections/{cid}/respond")
    async def respond(cid: str, body: Json = Body(...)) -> Json:
        return await node.respond_invitation(cid, bool(body.get("accept")))

    @app.post("/collections/{cid}/propose")
    async def propose(cid: str, body: Json = Body(...)) -> Json:
        return await node.propose_item(cid, body["edition_id"])

    @app.post("/collections/{cid}/proposals/{edition_id}")
    def decide_proposal(cid: str, edition_id: str, body: Json = Body(...)) -> Json:
        if body.get("accept"):
            return {"transfer_id": node.accept_proposal(cid, edition_id)}
        node.reject_proposal(cid, edition_id)
        return {}

    @app.post("/shared/refresh")
    async def refresh_shared() -> list[Json]:
        return await node.refresh_shared()

    # --------------------------------------------------------------- peers
    @app.get("/peers")
    def peers() -> list[Json]:
        return ctx.identity.peers()

    @app.post("/pairing/invitations")
    def new_invitation(body: Json = Body(default={})) -> Json:
        inv = node.create_invitation(purpose=body.get("purpose", "pair"), ttl_hours=body.get("ttl_hours"))
        return {"invitation": inv.to_json(), "text": inv.to_text(), "expires_at": inv.expires_at}

    @app.post("/pairing/inspect")
    def inspect(body: Json = Body(...)) -> Json:
        return node.inspect_invitation(body["invitation"])

    @app.post("/pairing/accept")
    async def accept(body: Json = Body(...)) -> Json:
        return await node.accept_invitation(body["invitation"], verified=bool(body.get("verified")))

    @app.post("/peers/{device_id}/verify")
    def verify(device_id: str, body: Json = Body(default={})) -> Json:
        ctx.identity.mark_verified(device_id, body.get("verified", True))
        return ctx.identity.peer(device_id)

    @app.post("/peers/{device_id}/state")
    def peer_state(device_id: str, body: Json = Body(...)) -> Json:
        ctx.identity.set_peer_state(device_id, body["state"])
        return ctx.identity.peer(device_id)

    @app.patch("/peers/{device_id}")
    def update_peer(device_id: str, body: Json = Body(...)) -> Json:
        ctx.identity.update_peer(device_id, alias=body.get("alias"), addresses=body.get("addresses"),
                                 bandwidth_kbps=body.get("bandwidth_kbps"), relay=body.get("relay"))
        return ctx.identity.peer(device_id)

    @app.post("/identity/rotate")
    async def rotate() -> Json:
        ctx.identity.rotate_device_key()
        return ctx.identity.describe() | await node.announce_rotation()

    @app.post("/sync/{device_id}")
    async def sync(device_id: str) -> Json:
        return await node.sync_with(device_id)

    @app.get("/sync/conflicts")
    def conflicts() -> list[Json]:
        return ctx.sync.conflicts()

    @app.post("/sync/conflicts/{conflict_id}")
    def resolve(conflict_id: str, body: Json = Body(...)) -> Json:
        ctx.sync.resolve(conflict_id, body.get("choice", "keep_current"))
        return {}

    # ------------------------------------------------------------- network
    @app.post("/network/start")
    async def net_start() -> Json:
        ctx.settings.set("network_enabled", True)
        await node.start_network()
        ctx.transfers.kick()
        return node.status()

    @app.post("/network/stop")
    async def net_stop() -> Json:
        ctx.settings.set("network_enabled", False)
        await node.stop_network()
        return node.status()

    @app.get("/network/discovered")
    def discovered() -> list[Json]:
        return node.discovered()

    # ----------------------------------------------------------- transfers
    @app.get("/transfers")
    def transfers() -> list[Json]:
        return ctx.transfers.list()

    @app.get("/transfers/{tid}")
    def transfer(tid: str) -> Json:
        return ctx.transfers.get(tid)

    @app.post("/transfers/{tid}/{action}")
    def transfer_action(tid: str, action: str) -> Json:
        if action not in ("pause", "resume", "cancel"):
            raise InvalidInput("unknown action")
        getattr(ctx.transfers, action)(tid)
        return ctx.transfers.get(tid)

    # ---------------------------------------------------------- publishing
    @app.get("/publishers")
    def publishers() -> list[Json]:
        return ctx.identity.publishers()

    @app.post("/publishers")
    def create_publisher(body: Json = Body(...)) -> Json:
        return ctx.identity.create_publisher(body.get("name", ""))

    @app.get("/publications")
    def publications() -> list[Json]:
        return ctx.publishing.list()

    @app.post("/publications")
    def create_draft(body: Json = Body(...)) -> Json:
        return ctx.publishing.create_draft(body["edition_id"], publisher_id=body.get("publisher_id", ""),
                                           package=body.get("package"))

    @app.get("/publications/{pid}")
    def publication(pid: str) -> Json:
        return ctx.publishing.get(pid)

    @app.patch("/publications/{pid}")
    def update_draft(pid: str, body: Json = Body(...)) -> Json:
        return ctx.publishing.update_draft(pid, body.get("package") or {}, publisher_id=body.get("publisher_id"))

    @app.post("/publications/{pid}/preview")
    def preview(pid: str) -> Json:
        return ctx.publishing.enter_preview(pid)

    @app.post("/publications/{pid}/rights-review")
    def rights(pid: str, body: Json = Body(...)) -> Json:
        return ctx.publishing.submit_rights_review(pid, body)

    @app.post("/publications/{pid}/publish")
    async def publish(pid: str, body: Json = Body(...)) -> Json:
        result = await asyncio.to_thread(ctx.publishing.publish, pid, disclosure_digest=body.get("disclosure_digest", ""),
                                         confirm=body.get("confirm") is True)
        if result.get("announce"):
            result["announcement"] = await asyncio.to_thread(node.rendezvous.announce_safely, pid)
        return result

    @app.post("/publications/{pid}/revise")
    async def revise(pid: str, body: Json = Body(...)) -> Json:
        return await asyncio.to_thread(ctx.publishing.create_revision, pid, body["path"], label=body.get("label", ""),
                                       notes=body.get("notes", ""), relation=body.get("relation", "correction-of"))

    @app.post("/publications/{pid}/withdraw")
    async def withdraw(pid: str, body: Json = Body(default={})) -> Json:
        result = ctx.publishing.withdraw(pid, body.get("note", ""))
        result["announcement"] = await asyncio.to_thread(node.rendezvous.withdraw_safely, pid)
        return result

    @app.post("/publications/{pid}/announce")
    async def announce(pid: str, body: Json = Body(default={})) -> Json:
        ctx.publishing.set_announce(pid, body.get("announce", True))
        if body.get("announce", True):
            return await asyncio.to_thread(node.rendezvous.announce, pid)
        return await asyncio.to_thread(node.rendezvous.withdraw_safely, pid)

    # ------------------------------------------------------ public catalogue
    @app.post("/public/fetch")
    async def public_fetch(body: Json = Body(...)) -> Json:
        return await node.fetch_public_catalogue(body["address"], body.get("query", ""), body.get("expected_device_id"))

    @app.get("/public/remote")
    def public_remote(q: str = "") -> list[Json]:
        return ctx.publishing.remote_list(q)

    @app.post("/public/download")
    def public_download(body: Json = Body(...)) -> Json:
        return {"transfer_ids": node.download_publication(body["publication_id"], body.get("source_device"))}

    @app.post("/public/mirror")
    def mirror(body: Json = Body(...)) -> Json:
        ctx.publishing.set_mirror(body["publication_id"], bool(body.get("enabled", True)))
        return {}

    @app.post("/public/pin-publisher")
    def pin(body: Json = Body(...)) -> Json:
        return {"publisher_id": ctx.identity.pin_publisher(body["public_key"], body.get("name", ""))}

    @app.post("/public/search-index")
    async def search_index(body: Json = Body(default={})) -> Json:
        return await asyncio.to_thread(node.rendezvous.search, body.get("query", ""))

    @app.post("/public/report")
    async def report(body: Json = Body(...)) -> Json:
        return await asyncio.to_thread(node.rendezvous.report, body["publication_id"], body.get("reason", ""))

    # -------------------------------------------------------------- backup
    @app.post("/backup/export")
    async def backup(body: Json = Body(...)) -> Json:
        return await asyncio.to_thread(ctx.export_backup, body["dest"], body["passphrase"],
                                       include_identity=body.get("include_identity", True), kdf=body.get("kdf"))

    # ------------------------------------------------- demo fault injection
    if os.environ.get("AUREOM_DEMO_FAULTS") == "1":
        @app.post("/debug/corrupt-chunk")
        def corrupt(body: Json = Body(...)) -> Json:
            """Development aid: make this node serve a damaged chunk N times,
            to demonstrate that receivers reject it.  Disabled unless
            AUREOM_DEMO_FAULTS=1 is set in the node's environment."""
            if not is_sha256_hex(body.get("file_hash")) or node.server is None:
                raise InvalidInput("bad request")
            node.server.faults[(body["file_hash"], int(body.get("index", 0)))] = int(body.get("times", 1))
            return {"armed": True}

        @app.post("/debug/probe")
        async def probe(body: Json = Body(...)) -> Json:
            """Development aid: try to reach private data on another node and
            report how each attempt was answered.  ``as`` is "anonymous" (no
            client certificate) or "paired" (this node's device key)."""
            from aureom.protocol import messages as m

            cid, fh = body.get("collection_id") or "0" * 32, body.get("file_hash") or "0" * 64
            scope = m.Scope(kind="collection", id=cid)
            attempts = [("list_shared", m.ListShared()), ("get_collection", m.GetCollection(collection_id=cid)),
                        ("get_manifest", m.GetManifest(scope=scope, file_hash=fh)),
                        ("get_manifest_public_scope", m.GetManifest(scope=m.Scope(kind="public"), file_hash=fh)),
                        ("get_manifest_device_scope", m.GetManifest(scope=m.Scope(kind="device"), file_hash=fh)),
                        ("get_manifest_unknown_hash", m.GetManifest(scope=scope, file_hash="f" * 64)),
                        ("get_chunk", m.GetChunk(scope=scope, file_hash=fh, index=0, chunk_size=16384))]
            out: Json = {}
            for name, message in attempts:
                try:
                    session = await (node.connect_peer(body["device_id"]) if body.get("as") == "paired"
                                     else node.connect_public(body["address"], body.get("device_id")))
                    async with session:
                        if isinstance(message, m.GetChunk):
                            await session.get_chunk(message)
                            out[name] = "ALLOWED"
                        else:
                            data = await session.request(message)
                            out[name] = "ALLOWED" if name != "list_shared" else data.get("collections")
                except CommonsError as exc:
                    out[name] = f"refused:{exc.code}"
            return out

    return app
