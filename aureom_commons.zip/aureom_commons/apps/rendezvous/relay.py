"""Optional relay: joins two authenticated TCP connections byte for byte.

The relay never terminates the peers' TLS session, holds no content keys and
stores nothing.  It learns: both device ids, their IP addresses, the time,
duration and volume of each session.  It can refuse or cut a session; it
cannot read or modify one undetected.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
import time
from dataclasses import dataclass, field

from aureom.domain.util import b64d, b64e
from aureom.identity.keys import key_id, verify
from aureom.transport.relay import MAX_LINE, auth_payload

log = logging.getLogger("aureom.relay-service")


@dataclass
class _Pending:
    dialer_reader: asyncio.StreamReader
    dialer_writer: asyncio.StreamWriter
    joined: asyncio.Event = field(default_factory=asyncio.Event)
    accept: tuple | None = None


class RelayService:
    def __init__(self, *, max_sessions_per_device: int = 8, max_session_bytes: int = 8 * 1024 ** 3,
                 idle_timeout: float = 300.0, record: bytearray | None = None):
        self.listeners: dict[str, asyncio.StreamWriter] = {}
        self.pending: dict[str, _Pending] = {}
        self.sessions: dict[str, int] = {}
        self.max_sessions, self.max_bytes, self.idle = max_sessions_per_device, max_session_bytes, idle_timeout
        self.record = record                    # tests: capture what a relay operator could see
        self.stats = {"sessions": 0, "bytes": 0}
        self._server: asyncio.AbstractServer | None = None
        self.port = 0

    async def start(self, host: str = "127.0.0.1", port: int = 0) -> int:
        self._server = await asyncio.start_server(self._handle, host, port, limit=MAX_LINE * 4)
        self.port = self._server.sockets[0].getsockname()[1]
        return self.port

    async def stop(self) -> None:
        if self._server:
            self._server.close()
        for writer in list(self.listeners.values()):
            writer.close()

    @staticmethod
    async def _line(reader: asyncio.StreamReader, timeout: float = 15.0) -> dict:
        line = await asyncio.wait_for(reader.readline(), timeout)
        if not line or len(line) > MAX_LINE:
            raise ConnectionError("closed")
        doc = json.loads(line)
        if not isinstance(doc, dict):
            raise ValueError("bad message")
        return doc

    @staticmethod
    async def _send(writer: asyncio.StreamWriter, obj: dict) -> None:
        writer.write(json.dumps(obj, separators=(",", ":")).encode() + b"\n")
        await writer.drain()

    async def _authenticate(self, reader, writer, hello: dict) -> str:
        device_id, role, target = str(hello.get("device_id")), str(hello.get("role")), str(hello.get("target") or "")
        public = b64d(str(hello.get("public_key")))
        if key_id(public) != device_id:
            await self._send(writer, {"ok": False, "error": "bad_identity"})
            raise PermissionError
        nonce = b64e(os.urandom(24))
        await self._send(writer, {"challenge": nonce})
        reply = await self._line(reader)
        if not verify(public, "relay-auth", auth_payload(nonce, role, device_id, target), b64d(str(reply.get("signature")))):
            await self._send(writer, {"ok": False, "error": "bad_signature"})
            raise PermissionError
        return device_id

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            hello = await self._line(reader)
            role = hello.get("role")
            if role == "listen":
                device_id = await self._authenticate(reader, writer, hello)
                old = self.listeners.pop(device_id, None)
                if old:
                    old.close()
                self.listeners[device_id] = writer
                await self._send(writer, {"ok": True})
                try:
                    while True:
                        message = await self._line(reader, self.idle)
                        if message.get("op") == "ping":
                            await self._send(writer, {"event": "pong"})
                finally:
                    if self.listeners.get(device_id) is writer:
                        del self.listeners[device_id]
            elif role == "dial":
                device_id = await self._authenticate(reader, writer, hello)
                await self._send(writer, {"ok": True})
                target = str(hello.get("target"))
                listener = self.listeners.get(target)
                if listener is None:
                    await self._send(writer, {"connected": False, "error": "peer_offline"})
                    return
                if self.sessions.get(device_id, 0) >= self.max_sessions:
                    await self._send(writer, {"connected": False, "error": "rate_limited"})
                    return
                session = secrets.token_urlsafe(24)
                pending = self.pending[session] = _Pending(reader, writer)
                try:
                    await self._send(listener, {"event": "incoming", "session": session, "from": device_id})
                    await asyncio.wait_for(pending.joined.wait(), 10.0)
                except (asyncio.TimeoutError, ConnectionError, OSError):
                    await self._send(writer, {"connected": False, "error": "peer_offline"})
                    return
                finally:
                    self.pending.pop(session, None)
                a_reader, a_writer = pending.accept
                await self._send(writer, {"connected": True})
                self.sessions[device_id] = self.sessions.get(device_id, 0) + 1
                self.stats["sessions"] += 1
                try:
                    await asyncio.gather(self._splice(reader, a_writer), self._splice(a_reader, writer))
                finally:
                    self.sessions[device_id] -= 1
            elif role == "accept":
                pending = self.pending.get(str(hello.get("session")))
                if pending is None or pending.accept is not None:
                    await self._send(writer, {"ok": False, "error": "unknown_session"})
                    return
                done = asyncio.Event()
                pending.accept = (reader, _Closing(writer, done))
                await self._send(writer, {"ok": True})
                pending.joined.set()
                await done.wait()               # keep this handler alive while the splice runs
                return
        except (PermissionError, ValueError, ConnectionError, asyncio.TimeoutError, asyncio.IncompleteReadError, OSError):
            pass
        finally:
            try:
                writer.close()
            except Exception:
                pass

    async def _splice(self, reader: asyncio.StreamReader, writer) -> None:
        moved, started = 0, time.monotonic()
        try:
            while moved < self.max_bytes:
                data = await asyncio.wait_for(reader.read(65536), self.idle)
                if not data:
                    break
                moved += len(data)
                self.stats["bytes"] += len(data)
                if self.record is not None and len(self.record) < 64 * 1024 * 1024:
                    self.record += data
                writer.write(data)
                await writer.drain()
        except (asyncio.TimeoutError, ConnectionError, OSError):
            pass
        finally:
            writer.close()
            log.info("relay stream closed bytes=%d seconds=%.1f", moved, time.monotonic() - started)


class _Closing:
    """Writer wrapper that signals when the splice has finished with it."""

    def __init__(self, writer: asyncio.StreamWriter, done: asyncio.Event):
        self._writer, self._done = writer, done

    def write(self, data: bytes) -> None:
        self._writer.write(data)

    async def drain(self) -> None:
        await self._writer.drain()

    def close(self) -> None:
        self._writer.close()
        self._done.set()
