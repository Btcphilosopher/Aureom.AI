"""Run the optional rendezvous + relay service.

    aureom-rendezvous --port 8800 --relay-port 8801 --db rendezvous.sqlite
"""
from __future__ import annotations

import argparse
import os

import uvicorn

from .app import create_app
from .relay import RelayService


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="aureom-rendezvous", description=__doc__.splitlines()[0])
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8800)
    parser.add_argument("--relay-port", type=int, default=8801, help="0 disables nothing; use --no-relay to disable")
    parser.add_argument("--no-relay", action="store_true")
    parser.add_argument("--db", default="rendezvous.sqlite")
    parser.add_argument("--operator-token-env", default="AUREOM_OPERATOR_TOKEN")
    parser.add_argument("--log-level", default="info")
    args = parser.parse_args(argv)
    app = create_app(args.db, operator_token=os.environ.get(args.operator_token_env, ""),
                     relay=None if args.no_relay else RelayService(), relay_host=args.host, relay_port=args.relay_port)
    uvicorn.run(app, host=args.host, port=args.port, log_level=args.log_level)


if __name__ == "__main__":
    main()
