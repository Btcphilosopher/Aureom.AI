"""Optional rendezvous service: address lookup for contacts and an opt-in
index of *published* editions, with operator moderation.

It never receives private-collection data.  Moderation here only affects
what this index lists; it has no effect on anyone's private library or on
direct peer-to-peer sharing.
"""
from __future__ import annotations

import hmac
import json
import sqlite3
import threading
import time
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Body, FastAPI, Header, HTTPException, Request

from aureom import __version__
from aureom.domain.limits import Limits
from aureom.domain.util import b64d, canonical_json, clean_text, is_safe_id
from aureom.identity.keys import key_id, verify
from aureom.protocol.manifest import check_publication, parse_publication
from aureom.search.index import fts_query

from .relay import RelayService

SCHEMA = """
CREATE TABLE IF NOT EXISTS presence (device_id TEXT PRIMARY KEY, addresses TEXT, relay TEXT, contacts TEXT, expires REAL);
CREATE TABLE IF NOT EXISTS entries (publication_id TEXT, device_id TEXT, address TEXT, manifest TEXT, manifest_id TEXT,
    signed INTEGER, announced_at REAL, delisted INTEGER DEFAULT 0, delist_note TEXT DEFAULT '',
    PRIMARY KEY (publication_id, device_id));
CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts USING fts5(publication_id UNINDEXED, device_id UNINDEXED, title, authors, description);
CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY AUTOINCREMENT, publication_id TEXT, reporter TEXT, reason TEXT,
    created_at REAL, state TEXT DEFAULT 'open');
"""
PRESENCE_TTL = 3600.0
MAX_SKEW = 120.0


def create_app(db_path: str = ":memory:", *, operator_token: str = "", relay: RelayService | None = None,
               relay_host: str = "127.0.0.1", relay_port: int = 0, limits: Limits | None = None) -> FastAPI:
    limits = limits or Limits()
    db = sqlite3.connect(db_path, check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    lock = threading.Lock()
    nonces: dict[str, float] = {}
    rate: dict[tuple[str, str], list[float]] = {}

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if relay is not None:
            app.state.relay_port = await relay.start(relay_host, relay_port)
        yield
        if relay is not None:
            await relay.stop()

    app = FastAPI(title="Aureom Commons rendezvous", version=__version__, lifespan=lifespan)
    app.state.relay_port = 0

    def limited(key: tuple[str, str], per_hour: int) -> None:
        now = time.time()
        hits = [t for t in rate.get(key, []) if now - t < 3600]
        if len(hits) >= per_hour:
            raise HTTPException(429, "rate limit reached")
        hits.append(now)
        rate[key] = hits

    def authenticated(path: str, envelope: dict) -> tuple[str, dict]:
        """Verify a signed, fresh, non-replayed request.  Returns (device_id, body)."""
        try:
            device_id, public = str(envelope["device_id"]), b64d(str(envelope["public_key"]))
            stamp, nonce, body = int(envelope["timestamp"]), str(envelope["nonce"]), envelope["body"]
            signature = b64d(str(envelope["signature"]))
        except (KeyError, ValueError, TypeError):
            raise HTTPException(400, "malformed request") from None
        if not isinstance(body, dict) or key_id(public) != device_id or len(nonce) > 64:
            raise HTTPException(400, "malformed request")
        if abs(time.time() - stamp) > MAX_SKEW:
            raise HTTPException(401, "request is not fresh")
        payload = canonical_json({"path": path, "timestamp": stamp, "nonce": nonce, "body": body})
        if not verify(public, "rendezvous-request", payload, signature):
            raise HTTPException(401, "bad signature")
        now = time.time()
        for old in [n for n, t in nonces.items() if now - t > 2 * MAX_SKEW]:
            del nonces[old]
        if (device_id + nonce) in nonces:
            raise HTTPException(401, "replayed request")
        nonces[device_id + nonce] = now
        return device_id, body

    def operator(token: str) -> None:
        if not operator_token or not hmac.compare_digest(token, operator_token):
            raise HTTPException(403, "operator token required")

    @app.get("/v1/info")
    def info() -> dict:
        return {"service": "aureom-commons-rendezvous", "version": __version__, "relay_port": app.state.relay_port,
                "stores": ["device ids, addresses and contact lists (1 hour)", "announced publication manifests",
                           "content reports"],
                "never_receives": ["private collections", "private titles or hashes", "file contents"]}

    @app.post("/v1/register")
    def register(envelope: dict = Body(...)) -> dict:
        device_id, body = authenticated("/v1/register", envelope)
        limited((device_id, "register"), 120)
        addresses = [clean_text(a, 255) for a in (body.get("addresses") or [])][:8]
        contacts = [c for c in (body.get("contacts") or []) if is_safe_id(c)][:500]
        with lock:
            db.execute("INSERT OR REPLACE INTO presence VALUES (?,?,?,?,?)",
                       (device_id, json.dumps(addresses), clean_text(body.get("relay"), 255), json.dumps(contacts),
                        time.time() + PRESENCE_TTL))
            db.commit()
        return {"registered": True, "ttl": PRESENCE_TTL}

    @app.post("/v1/lookup")
    def lookup(envelope: dict = Body(...)) -> dict:
        device_id, body = authenticated("/v1/lookup", envelope)
        limited((device_id, "lookup"), 600)
        with lock:
            row = db.execute("SELECT * FROM presence WHERE device_id=? AND expires>?",
                             (str(body.get("target")), time.time())).fetchone()
        # only devices the target listed as contacts may learn its address
        if row is None or device_id not in json.loads(row["contacts"]):
            raise HTTPException(404, "not found")
        return {"addresses": json.loads(row["addresses"]), "relay": row["relay"]}

    @app.post("/v1/catalogue/announce")
    def announce(envelope: dict = Body(...)) -> dict:
        device_id, body = authenticated("/v1/catalogue/announce", envelope)
        limited((device_id, "announce"), limits.catalogue_announcements_per_hour)
        try:
            manifest = parse_publication(body.get("manifest"), limits)
        except Exception:
            raise HTTPException(422, "invalid publication manifest") from None
        check = check_publication(manifest)
        if check.signed and not check.signature_valid:
            raise HTTPException(422, "manifest signature is invalid")
        with lock:
            prior = db.execute("SELECT delisted FROM entries WHERE publication_id=? AND delisted=1",
                               (manifest.publication_id,)).fetchone()
            if prior:
                raise HTTPException(403, "this publication has been delisted by the operator")
            db.execute("INSERT OR REPLACE INTO entries (publication_id, device_id, address, manifest, manifest_id, signed, "
                       "announced_at) VALUES (?,?,?,?,?,?,?)",
                       (manifest.publication_id, device_id, clean_text(body.get("address"), 255),
                        manifest.model_dump_json(), manifest.manifest_id, int(check.signature_valid), time.time()))
            db.execute("DELETE FROM entries_fts WHERE publication_id=? AND device_id=?", (manifest.publication_id, device_id))
            db.execute("INSERT INTO entries_fts VALUES (?,?,?,?,?)",
                       (manifest.publication_id, device_id, manifest.title,
                        " ; ".join(c.name for c in manifest.contributors), manifest.description))
            db.commit()
        return {"listed": True, "manifest_id": manifest.manifest_id,
                "note": "Listing means the manifest was well-formed" +
                        (" and its self-issued signature matched." if check.signature_valid else " (unsigned).") +
                        " The operator has not reviewed the work or the publisher's identity."}

    @app.post("/v1/catalogue/withdraw")
    def withdraw(envelope: dict = Body(...)) -> dict:
        device_id, body = authenticated("/v1/catalogue/withdraw", envelope)
        pid = str(body.get("publication_id"))
        with lock:
            db.execute("DELETE FROM entries WHERE publication_id=? AND device_id=? AND delisted=0", (pid, device_id))
            db.execute("DELETE FROM entries_fts WHERE publication_id=? AND device_id=?", (pid, device_id))
            db.commit()
        return {"removed": True}

    @app.get("/v1/catalogue/search")
    def search(request: Request, q: str = "", limit: int = 50) -> dict:
        limited((request.client.host if request.client else "?", "search"), limits.search_requests_per_minute * 60)
        expr = fts_query(q)
        with lock:
            if expr:
                rows = db.execute("SELECT e.* FROM entries_fts f JOIN entries e ON e.publication_id=f.publication_id "
                                  "AND e.device_id=f.device_id WHERE entries_fts MATCH ? AND e.delisted=0 LIMIT ?",
                                  (expr, min(limit, 100))).fetchall()
            else:
                rows = db.execute("SELECT * FROM entries WHERE delisted=0 ORDER BY announced_at DESC LIMIT ?",
                                  (min(limit, 100),)).fetchall()
        return {"entries": [{"publication_id": r["publication_id"], "device_id": r["device_id"], "address": r["address"],
                             "manifest": json.loads(r["manifest"]), "signed": bool(r["signed"])} for r in rows]}

    @app.post("/v1/reports")
    def report(envelope: dict = Body(...)) -> dict:
        device_id, body = authenticated("/v1/reports", envelope)
        limited((device_id, "report"), 30)
        with lock:
            db.execute("INSERT INTO reports (publication_id, reporter, reason, created_at) VALUES (?,?,?,?)",
                       (clean_text(body.get("publication_id"), 80), device_id,
                        clean_text(body.get("reason"), 1000, single_line=False), time.time()))
            db.commit()
        return {"received": True, "note": "Reports go to this catalogue's operator. They affect only this index."}

    @app.get("/v1/admin/reports")
    def reports(x_operator_token: str = Header(default="")) -> list[dict[str, Any]]:
        operator(x_operator_token)
        with lock:
            return [dict(r) for r in db.execute("SELECT * FROM reports ORDER BY id DESC LIMIT 500")]

    @app.post("/v1/admin/delist")
    def delist(body: dict = Body(...), x_operator_token: str = Header(default="")) -> dict:
        operator(x_operator_token)
        pid, flag = str(body.get("publication_id")), 1 if body.get("delisted", True) else 0
        with lock:
            db.execute("UPDATE entries SET delisted=?, delist_note=? WHERE publication_id=?",
                       (flag, clean_text(body.get("note"), 500), pid))
            db.execute("UPDATE reports SET state='reviewed' WHERE publication_id=?", (pid,))
            db.commit()
        return {"publication_id": pid, "delisted": bool(flag)}

    return app
