"""Home and Library pages."""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (QComboBox, QFileDialog, QGridLayout, QLabel, QLineEdit, QListView, QListWidget,
                               QListWidgetItem, QMessageBox, QProgressBar, QScrollArea, QSplitter, QStackedWidget,
                               QTextBrowser, QToolButton, QVBoxLayout, QWidget)

from aureom.domain.models import METADATA_FIELDS

from . import theme
from .widgets import (Page, badge_html, button, card, cover_pixmap, esc, fill_table, form_dialog, human_size, label,
                      make_table, row, selected_payload, short_time)

LIST_FIELDS = ("authors", "contributors", "tags")
FIELD_LABELS = {"title": "Title", "subtitle": "Subtitle", "authors": "Authors", "contributors": "Contributors",
                "publisher": "Publisher", "language": "Language", "publication_date": "Publication date",
                "isbn": "ISBN", "doi": "DOI", "tags": "Tags", "rights": "Rights", "licence": "Licence",
                "description": "Description", "accessibility": "Accessibility"}


def clear_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
        elif item.layout():
            clear_layout(item.layout())


class HomePage(Page):
    topics = ("library", "collections", "transfers", "progress", "peers")

    def __init__(self, window) -> None:
        super().__init__(window)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QWidget()
        inner.setObjectName("page")
        self.grid = QGridLayout(inner)
        self.grid.setContentsMargins(0, 0, 8, 0)
        self.grid.setSpacing(16)
        scroll.setWidget(inner)
        self.body.addWidget(scroll)

    def tick(self) -> None:
        if self.ctx.transfers.list(active_only=True):
            self.refresh()

    def refresh(self) -> None:
        clear_layout(self.grid)
        home = self.ctx.home()
        w = self.window_

        # recent reading
        shelf = QListWidget()
        shelf.setViewMode(QListView.ViewMode.IconMode)
        shelf.setFlow(QListView.Flow.LeftToRight)
        shelf.setWrapping(False)
        shelf.setIconSize(QSize(104, 154))
        shelf.setFixedHeight(226)
        shelf.setSpacing(10)
        shelf.setMovement(QListView.Movement.Static)
        shelf.setAccessibleName("Recent reading")
        for view in home["recent_reading"]:
            item = QListWidgetItem(QIcon(cover_pixmap(view, self.ctx.catalogue.cover_bytes(view["edition_id"]),
                                                      QSize(104, 154))), f"{view['title'][:22]}\n{round(view['progress'] * 100)}% read")
            item.setData(Qt.ItemDataRole.UserRole, view["edition_id"])
            item.setToolTip(view["title"])
            shelf.addItem(item)
        shelf.itemActivated.connect(lambda it: w.open_reader(it.data(Qt.ItemDataRole.UserRole)))
        shelf.itemDoubleClicked.connect(lambda it: w.open_reader(it.data(Qt.ItemDataRole.UserRole)))
        if home["recent_reading"]:
            self.grid.addWidget(card(shelf, title="Continue reading"), 0, 0, 1, 2)
        else:
            empty = label("Nothing open yet. Drag files or folders onto this window to import them into your "
                          "private library, or open the Library to begin. Imported works stay private until you "
                          "choose to share or publish them.", "muted", wrap=True)
            self.grid.addWidget(card(empty, row(button("Import files…", w.pages["Library"].choose_import, kind="primary"),
                                                button("Open Library", lambda: w.go("Library"))),
                                     title="Continue reading"), 0, 0, 1, 2)

        # collections
        items = []
        for c in home["collections"]:
            who = "" if c["is_owner"] else f" · from {esc(c['owner_name'] or 'a peer')}"
            state = "" if c["access_state"] == "active" else f" · <i>{esc(c['access_state'])}</i>"
            items.append(f"<p>{badge_html(c['visibility'])}&nbsp; <b>{esc(c['name'])}</b><br>"
                         f"<span style='color:gray'>{c['item_count']} work(s) · {c['member_count']} member(s){who}{state}</span></p>")
        col = QLabel("".join(items) or "<i>No collections yet.</i>")
        col.setWordWrap(True)
        self.grid.addWidget(card(col, None, row(button("Open Collections", lambda: w.go("Collections"), kind="link")),
                                 title="Collections"), 1, 0)

        # invitations + attention
        inv_layout = QVBoxLayout()
        for inv in home["incoming_invitations"]:
            inv_layout.addWidget(label(f"<b>{esc(inv['name'])}</b> — from {esc(inv['owner_name'] or 'a peer')} "
                                       f"({', '.join(inv['my_permissions'])})", wrap=True))
        for p in home["pending_proposals"]:
            inv_layout.addWidget(label(f"{esc(p['proposed_by'])} proposes adding <b>{esc(p['title'])}</b> to "
                                       f"{esc(p['collection_name'])}", wrap=True))
        if home["review"]["annotations"]:
            inv_layout.addWidget(label(f"{home['review']['annotations']} annotation(s) need review after an edition change."))
        if home["review"]["conflicts"]:
            inv_layout.addWidget(label(f"{home['review']['conflicts']} synchronisation conflict(s) to review."))
        if not inv_layout.count():
            inv_layout.addWidget(label("<i>No invitations or reviews waiting.</i>"))
        self.grid.addWidget(card(inv_layout, None, row(button("Review in Collections", lambda: w.go("Collections"), kind="link"),
                                                       button("Activity", lambda: w.go("Activity"), kind="link")),
                                 title="Incoming invitations"), 1, 1)

        # transfers
        t_layout = QVBoxLayout()
        for t in home["transfers"]:
            bar = QProgressBar()
            bar.setValue(round(t["progress"] * 100))
            bar.setFormat(f"{t['state']} · %p%")
            bar.setAccessibleName(f"Transfer of {t['title']}")
            t_layout.addWidget(label(esc(t["title"] or "Untitled")))
            t_layout.addWidget(bar)
        if not home["transfers"]:
            net = home["network"]
            t_layout.addWidget(label(f"<i>No active transfers.</i><br><span style='color:gray'>{esc(net['label'])}: "
                                     f"{esc(net['detail'])}</span>", wrap=True))
        self.grid.addWidget(card(t_layout, None, row(button("Open Transfers", lambda: w.go("Transfers"), kind="link")),
                                 title="Transfer status"), 2, 0)

        # drafts
        drafts = "".join(f"<p><b>{esc(d['title'])}</b> — {esc(d['edition_label'])}<br><span style='color:gray'>"
                         f"{esc(d['state'].replace('_', ' '))} · not public</span></p>" for d in home["publication_drafts"])
        dl = QLabel(drafts or "<i>No publication drafts.</i><br><span style='color:gray'>Nothing is published until "
                              "you complete the preview, the rights review and an explicit publish action.</span>")
        dl.setWordWrap(True)
        self.grid.addWidget(card(dl, None, row(button("Open Publish", lambda: w.go("Publish"), kind="link")),
                                 title="Publication drafts"), 2, 1)
        self.grid.setRowStretch(3, 1)
        self.grid.setColumnStretch(0, 1)
        self.grid.setColumnStretch(1, 1)


class LibraryPage(Page):
    topics = ("library", "collections", "transfers")

    def __init__(self, window) -> None:
        super().__init__(window)
        self.query = ""
        self.selected: str | None = None
        self.filters: dict[str, QComboBox] = {}
        bar = row(button("Import…", self.choose_import, kind="primary", tip="Import files or a folder (Ctrl+I). "
                         "You can also drag them onto the window."), stretch=False)
        for key, text in (("space", "Space"), ("fmt", "Format"), ("language", "Language"), ("tag", "Tag"),
                          ("collection_id", "Collection"), ("availability", "Availability")):
            combo = QComboBox()
            combo.setAccessibleName(f"Filter by {text.lower()}")
            combo.setMinimumWidth(104)
            combo.currentIndexChanged.connect(lambda _i: self.reload())
            self.filters[key] = combo
            bar.addWidget(combo)
        self.author = QLineEdit()
        self.author.setPlaceholderText("Author…")
        self.author.setAccessibleName("Filter by author")
        self.author.setFixedWidth(120)
        self.author.returnPressed.connect(self.reload)
        bar.addWidget(self.author)
        bar.addStretch(1)
        self.view_btn = button("Table view", self.toggle_view, tip="Switch between the cover grid and the catalogue table")
        bar.addWidget(self.view_btn)
        self.body.addLayout(bar)
        self.summary = label("", "muted")
        self.body.addWidget(self.summary)

        split = QSplitter()
        self.views = QStackedWidget()
        self.grid = QListWidget()
        self.grid.setViewMode(QListView.ViewMode.IconMode)
        self.grid.setIconSize(QSize(150, 222))
        self.grid.setGridSize(QSize(182, 286))
        self.grid.setResizeMode(QListView.ResizeMode.Adjust)
        self.grid.setMovement(QListView.Movement.Static)
        self.grid.setWordWrap(True)
        self.grid.setAccessibleName("Library cover grid")
        self.grid.currentItemChanged.connect(lambda cur, _p: self.select(cur.data(Qt.ItemDataRole.UserRole) if cur else None))
        self.grid.itemActivated.connect(lambda it: self.read(it.data(Qt.ItemDataRole.UserRole)))
        self.table = make_table(["Title", "Author", "Format", "Language", "Date", "Visibility", "Availability", "Size"])
        self.table.setAccessibleName("Library catalogue table")
        self.table.itemSelectionChanged.connect(lambda: self.select(selected_payload(self.table)))
        self.table.itemActivated.connect(lambda _it: self.read(selected_payload(self.table)))
        self.views.addWidget(self.grid)
        self.views.addWidget(self.table)
        split.addWidget(self.views)

        panel = QWidget()
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(14, 0, 0, 0)
        self.detail = QTextBrowser()
        self.detail.setOpenLinks(False)
        self.detail.setAccessibleName("Details of the selected work")
        pl.addWidget(self.detail, 1)
        self.actions = QGridLayout()
        self.actions.setSpacing(6)
        self.buttons = {}
        specs = [("read", "Read", self.read, "primary"), ("download", "Download", self.download, ""),
                 ("edit", "Edit details…", self.edit_metadata, ""), ("collect", "Add to collection…", self.add_to_collection, ""),
                 ("publish", "Publish…", self.publish, ""), ("edition", "Add new edition…", self.add_edition, ""),
                 ("attach", "Attach file…", self.attach, ""), ("export", "Export copy…", self.export, ""),
                 ("index", "Indexing…", self.set_index_mode, ""), ("remove", "Remove", self.remove, "danger")]
        for i, (key, text, slot, kind) in enumerate(specs):
            btn = button(text, lambda s=slot: self.window_.safe(s), kind=kind)
            self.buttons[key] = btn
            self.actions.addWidget(btn, i // 2, i % 2)
        pl.addLayout(self.actions)
        split.addWidget(panel)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        split.setSizes([760, 420])
        self.body.addWidget(split, 1)

    # ---------------------------------------------------------------- data
    def set_query(self, text: str) -> None:
        self.query = text

    def toggle_view(self) -> None:
        self.views.setCurrentIndex(1 - self.views.currentIndex())
        self.view_btn.setText("Cover view" if self.views.currentIndex() else "Table view")

    def _fill_filters(self) -> None:
        facets = self.ctx.search.facets()
        options = {
            "space": [("", "All spaces"), ("private", "Private"), ("shared", "Shared"), ("public", "Public")],
            "fmt": [("", "All formats")] + [(f, f.upper()) for f in facets["formats"]],
            "language": [("", "All languages")] + [(lang, lang) for lang in facets["languages"]],
            "tag": [("", "All tags")] + [(t, t) for t in facets["tags"]],
            "collection_id": [("", "All collections")] + [(c["collection_id"], c["name"]) for c in self.ctx.collections.list()],
            "availability": [("", "Any availability"), ("local", "On this device"), ("peer", "From authorised peer"),
                             ("unavailable", "Unavailable")],
        }
        for key, combo in self.filters.items():
            current = combo.currentData()
            combo.blockSignals(True)
            combo.clear()
            for value, text in options[key]:
                combo.addItem(text, value)
            combo.setCurrentIndex(max(0, combo.findData(current)))
            combo.blockSignals(False)

    def refresh(self) -> None:
        self._fill_filters()
        self.reload()

    def reload(self) -> None:
        f = {k: (c.currentData() or "") for k, c in self.filters.items()}
        views = self.ctx.catalogue.list(self.query, space=f["space"], collection_id=f["collection_id"],
                                        availability=f["availability"], fmt=f["fmt"], language=f["language"], tag=f["tag"],
                                        author=self.author.text())
        self.summary.setText((f"Search results for “{self.query}” — " if self.query else "") +
                             f"{len(views)} edition(s). Private works are visible only on this device.")
        self.grid.blockSignals(True)
        self.grid.clear()
        for v in views:
            authors = ", ".join(v["metadata"]["authors"][:2])
            item = QListWidgetItem(QIcon(cover_pixmap(v, self.ctx.catalogue.cover_bytes(v["edition_id"]) if v["has_cover"] else None)),
                                   v["title"][:44] + (f"\n{authors[:30]}" if authors else ""))
            item.setData(Qt.ItemDataRole.UserRole, v["edition_id"])
            item.setToolTip(f"{v['title']}\n{theme.BADGES[v['visibility']][2]} · {theme.AVAILABILITY[v['availability']]}"
                            + (f"\n…{v['snippet']}…" if v.get("snippet") else ""))
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
            self.grid.addItem(item)
            if v["edition_id"] == self.selected:
                self.grid.setCurrentItem(item)
        self.grid.blockSignals(False)
        self.table.blockSignals(True)
        fill_table(self.table, ((v["edition_id"], [
            v["title"] + (f" — {v['label']}" if v["label"] else ""), "; ".join(v["metadata"]["authors"]),
            v["format"].upper(), v["metadata"]["language"], v["metadata"]["publication_date"][:10],
            theme.BADGES[v["visibility"]][2], theme.AVAILABILITY[v["availability"]], human_size(v["size"])]) for v in views))
        self.table.blockSignals(False)
        ids = {v["edition_id"] for v in views}
        if self.selected not in ids:
            self.selected = views[0]["edition_id"] if views else None
        self.show_detail()

    def select(self, edition_id: str | None) -> None:
        if edition_id and edition_id != self.selected:
            self.selected = edition_id
            self.show_detail()

    def show_detail(self) -> None:
        for b in self.buttons.values():
            b.setEnabled(self.selected is not None)
        if not self.selected:
            self.detail.setHtml("<p><i>Select a work to see its details, or drop files here to import them.</i></p>")
            return
        v = self.ctx.catalogue.edition_view(self.selected)
        layers = self.ctx.catalogue.metadata_layers(self.selected)
        m = v["metadata"]
        serif = theme.serif_family()
        rows = []
        for key in METADATA_FIELDS:
            value = m[key]
            if not value:
                continue
            shown = "; ".join(value) if isinstance(value, list) else str(value)
            note = ""
            if key in layers["user"]:
                original = layers["imported"].get(key) or layers["remote"].get(key) or ""
                original = "; ".join(original) if isinstance(original, list) else original
                note = f"<br><span style='color:gray'>your correction — imported value: {esc(original) or '(none)'}</span>"
            rows.append(f"<tr><td style='color:gray' valign='top'>{FIELD_LABELS[key]}</td><td>{esc(shown)}{note}</td></tr>")
        editions = "".join(
            f"<tr><td>{'▸' if e['edition_id'] == v['edition_id'] else ''} Edition {e['edition_number']}</td>"
            f"<td>{esc(e['label'] or '—')}{' · ' + esc(e['relation']) if e['relation'] else ''}</td>"
            f"<td><code>{e['content_hash'][:10]}…</code></td><td>{badge_html(e['visibility'])}</td></tr>"
            for e in self.ctx.catalogue.editions_of_work(v["work_id"]))
        storage = ("Managed copy" + (" (encrypted at rest)" if self.ctx.store.encrypted else "")
                   if v["storage"] == "managed" else "Referenced original — an ordinary file, not protected by this library")
        self.detail.setHtml(
            f"<div style='font-family:\"{serif}\"; font-size:17pt'>{esc(v['title'])}</div>"
            + (f"<div style='font-family:\"{serif}\"; font-style:italic; color:gray'>{esc(m['subtitle'])}</div>" if m["subtitle"] else "")
            + f"<p>{esc(', '.join(m['authors']))}</p>"
            f"<p>{badge_html(v['visibility'])}&nbsp;&nbsp;{theme.AVAILABILITY[v['availability']]}"
            f"{' · ' + str(round(v['progress'] * 100)) + '% read' if v['progress'] else ''}</p>"
            f"<table cellpadding='3'>{''.join(rows)}"
            f"<tr><td style='color:gray'>File</td><td>{esc(v['filename'])} · {v['format'].upper()} · {human_size(v['size'])}</td></tr>"
            f"<tr><td style='color:gray'>Content hash</td><td><code>{v['content_hash'][:32]}…</code><br>"
            f"<span style='color:gray'>identifies these exact bytes; says nothing about safety or accuracy</span></td></tr>"
            f"<tr><td style='color:gray'>Storage</td><td>{storage}</td></tr>"
            f"<tr><td style='color:gray'>Imported from</td><td>{esc(v['import_source'])} · {short_time(v['created_at'])}</td></tr>"
            f"<tr><td style='color:gray'>Search index</td><td>{ {'full': 'title, details and full text', 'metadata': 'title and details only', 'none': 'not indexed'}[v['index_mode']] }</td></tr>"
            f"</table><p style='color:gray'><b>EDITIONS OF THIS WORK</b></p><table cellpadding='3'>{editions}</table>"
            + (f"<p style='color:gray'>{esc(v['revision_notes'])}</p>" if v["revision_notes"] else ""))
        local = v["availability"] == "local"
        self.buttons["read"].setEnabled(local)
        self.buttons["download"].setEnabled(v["availability"] == "peer")
        self.buttons["export"].setEnabled(local)
        self.buttons["publish"].setEnabled(local and v["origin"] == "local")

    # ------------------------------------------------------------- actions
    def choose_import(self) -> None:
        choice = form_dialog(self, "Import into your private library", [
            ("what", "Import", "choice", "files", [("files", "Files…"), ("folder", "A folder…")]),
            ("mode", "Storage", "choice", self.ctx.settings.get("import_mode"),
             [("managed", "Copy into the managed library" + (" (encrypted)" if self.ctx.store.encrypted else "")),
              ("referenced", "Reference the original where it is (not protected or backed up)")]),
        ], intro="Imported works are private. Importing never shares, publishes or announces anything to peers.",
            ok_text="Choose…")
        if not choice:
            return
        if choice["what"] == "folder":
            folder = QFileDialog.getExistingDirectory(self, "Import a folder")
            paths = [folder] if folder else []
        else:
            paths, _ = QFileDialog.getOpenFileNames(self, "Import files")
        if paths:
            self.window_.import_paths(paths, choice["mode"])

    def read(self, edition_id: str | None = None) -> None:
        if edition_id or self.selected:
            self.window_.open_reader(edition_id or self.selected)

    def download(self) -> None:
        self.ctx.node.download_edition(self.selected)
        self.window_.toast("Download queued. Every chunk and the whole file are verified before it appears as available.")
        self.window_.go("Transfers")

    def edit_metadata(self) -> None:
        eid = self.selected
        current = self.ctx.catalogue.effective_metadata(eid).model_dump()
        layers = self.ctx.catalogue.metadata_layers(eid)
        base = {**layers["imported"], **layers["remote"]}
        fields = [(k, FIELD_LABELS[k], "multiline" if k == "description" else "text",
                   "; ".join(current[k]) if k in LIST_FIELDS else current[k]) for k in METADATA_FIELDS]
        answers = form_dialog(self, "Edit details", fields, ok_text="Save corrections",
                              intro="Your corrections are stored separately from the metadata extracted from the file "
                                    "(which is kept, and treated as untrusted). Clear a field to return to the imported value.")
        if answers is None:
            return
        changes = {}
        for key, value in answers.items():
            new = [p.strip() for p in value.replace(",", ";").split(";") if p.strip()] if key in LIST_FIELDS else value
            original = base.get(key) or ([] if key in LIST_FIELDS else "")
            if new == current[key]:
                continue
            changes[key] = None if (new == original or not new) else new
        if changes:
            self.ctx.catalogue.update_user_metadata(eid, changes)
            self.reload()

    def add_to_collection(self) -> None:
        mine = [c for c in self.ctx.collections.list() if c["is_owner"]]
        if not mine:
            self.window_.toast("Create a collection first (Collections page).")
            return
        answer = form_dialog(self, "Add to collection", [
            ("cid", "Collection", "choice", mine[0]["collection_id"],
             [(c["collection_id"], f"{c['name']} — {'private shelf' if c['kind'] == 'local' else 'shared: ' + str(c['member_count']) + ' member(s)'}")
              for c in mine])],
            intro="Adding a work to a shared collection makes its title, details and (for members allowed to download) "
                  "its file available to that collection's members. Private shelves are only for your own organisation.",
            ok_text="Add")
        if answer:
            self.ctx.collections.add_item(answer["cid"], self.selected)
            self.reload()

    def publish(self) -> None:
        self.window_.pages["Publish"].start_draft(self.selected)

    def add_edition(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose the file for the new edition")
        if not path:
            return
        answers = form_dialog(self, "Add a new edition", [
            ("label", "Edition label", "text", "Revised edition"),
            ("relation", "Relationship", "choice", "revision-of",
             [("revision-of", "Revision of the selected edition"), ("correction-of", "Correction of the selected edition"),
              ("translation-of", "Translation of the selected edition")]),
            ("notes", "What changed", "multiline", "")],
            intro="The file is added as a separate edition of the same work. The existing edition, its annotations "
                  "and its content hash are left untouched.", ok_text="Add edition")
        if not answers:
            return
        ed = self.ctx.catalogue.edition_row(self.selected)
        result = self.ctx.catalogue.import_file(path, work_id=ed["work_id"], label=answers["label"],
                                                relation=answers["relation"], previous_edition_id=self.selected,
                                                revision_notes=answers["notes"])
        if result.status != "imported":
            self.window_.toast(result.message or "The edition could not be added.", error=True)
            return
        report = self.ctx.annotations.migrate(self.selected, result.edition_id)
        self.window_.toast(f"New edition added. Annotations carried over: {report['ok']} placed, "
                           f"{report['needs_review']} need review, {report['orphaned']} not found.")
        self.selected = result.edition_id
        self.refresh()

    def attach(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Attach a supplementary file")
        if path:
            self.ctx.catalogue.attach_file(self.selected, path)
            self.window_.toast("Supplementary file attached to this edition.")

    def export(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Export a copy to…")
        if folder:
            dest = self.ctx.catalogue.export_file(self.selected, folder)
            self.window_.toast(f"An ordinary, unprotected copy was written to {dest}.")

    def set_index_mode(self) -> None:
        v = self.ctx.catalogue.edition_view(self.selected)
        answer = form_dialog(self, "Search indexing for this document", [
            ("mode", "Index", "choice", v["index_mode"],
             [("full", "Title, details and full text"), ("metadata", "Title and details only (no document text)"),
              ("none", "Do not index this document at all")])],
            intro="For sensitive documents you can keep their text — or everything about them — out of the search "
                  "index. " + ("In this encrypted library the index is encrypted at rest either way."
                               if self.ctx.store.encrypted else
                               "This library is not encrypted, so indexed text is readable by anyone with access to the profile folder."))
        if answer:
            self.ctx.catalogue.set_index_mode(self.selected, answer["mode"])
            self.show_detail()

    def remove(self) -> None:
        v = self.ctx.catalogue.edition_view(self.selected)
        if QMessageBox.question(self, "Remove from library",
                                f"Remove “{v['title']}” from your library?\n\nThe managed copy on this device is deleted. "
                                "Copies held by people you shared it with are not affected.") == QMessageBox.StandardButton.Yes:
            self.ctx.catalogue.remove_edition(self.selected)
            self.selected = None
            self.refresh()
