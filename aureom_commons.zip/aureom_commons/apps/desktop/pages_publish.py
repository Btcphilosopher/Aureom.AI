"""Publish, Transfers and Activity pages."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFileDialog, QListWidget, QListWidgetItem, QProgressBar, QSplitter, QTabWidget,
                               QTextBrowser, QVBoxLayout, QWidget)

from aureom.domain.util import fingerprint_display
from aureom.publishing.service import PUBLISH_NOTICES, RIGHTS_BASES, WITHDRAWAL_NOTICE

from . import theme
from .widgets import (Page, bullet_list, button, esc, fill_table, form_dialog, human_size, label, make_table, notice,
                      review_dialog, row, selected_payload, short_time)

STEPS = [("draft", "Draft"), ("preview", "Preview"), ("rights_review", "Rights review"), ("published", "Published")]
STATE_TEXT = {"draft": "Draft — not public", "preview": "Previewed — not public", "rights_review": "Rights reviewed — not public",
              "published": "Published", "revised": "Published · superseded by a newer edition", "withdrawn": "Withdrawn"}
BASIS_TEXT = {"author": "I am the author / rights holder", "licensed": "I hold a licence that permits this",
              "public-domain": "The work is in the public domain", "open-licence": "The work is under an open licence that permits this"}


def disclosure_html(d: dict) -> str:
    pub = d["will_become_public"]
    meta = "".join(f"<tr><td style='color:gray' valign='top'>{esc(k.replace('_', ' '))}</td><td>"
                   f"{esc('; '.join(c['name'] + ' (' + c['role'] + ')' for c in v) if k == 'contributors' else '; '.join(v) if isinstance(v, list) else v)}"
                   f"</td></tr>" for k, v in pub["metadata"].items() if v)
    files = "".join(f"<li>{esc(f['filename'])} · {f['format'].upper()} · {human_size(f['size'])} · sha256 <code>{f['sha256'][:20]}…</code></li>"
                    for f in pub["files"])
    ed = pub["edition"]
    publisher = (f"<p>Signed as <b>{esc(pub['publisher']['name'])}</b> — key <code>{pub['publisher']['key_fingerprint'][:24]}…</code> "
                 f"({esc(pub['publisher']['note'])})</p>" if pub["publisher"] else
                 "<p>Unsigned: nothing will link this edition to a publisher key.</p>")
    problems = f"<h3 style='color:#a4443a'>To fix first</h3>{bullet_list(d['problems'])}" if d["problems"] else ""
    return (f"<h2>This will become public</h2>{problems}<table cellpadding='4'>{meta}</table>"
            f"<p><b>Edition:</b> {esc(ed['label'])} (number {ed['number']})"
            + (f" — {esc(ed['relation'])} the previous edition. Notes: {esc(ed['revision_notes'])}" if ed["previous_edition_id"] else "")
            + f"</p><h3>Files</h3><ul>{files}</ul>"
            + ("<p>A cover image is included.</p>" if pub["cover"] else "") + publisher
            + f"<h3>Also visible to anyone who downloads</h3>{bullet_list(d['also_visible_to_downloaders'])}"
            f"<h3>Will NOT be published</h3>{bullet_list(d['will_not_be_published'])}"
            f"<h3>Before you continue</h3>{bullet_list(d['notices'])}")


class PublishPage(Page):
    topics = ("library",)

    def __init__(self, window) -> None:
        super().__init__(window)
        self.pid: str | None = None
        g = lambda fn: (lambda: self.window_.safe(fn))  # noqa: E731
        self.body.addWidget(notice("Nothing here is public until you press Publish at the end of the workflow. "
                                   "Publishing does not establish copyright ownership, and a publisher signature is "
                                   "self-issued: it identifies a key, not a person."))
        split = QSplitter()
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 12, 0)
        ll.addWidget(label("PUBLICATIONS", "h3"))
        self.list = QListWidget()
        self.list.setAccessibleName("Publications and drafts")
        self.list.currentItemChanged.connect(lambda cur, _p: self._select(cur.data(Qt.ItemDataRole.UserRole) if cur else None))
        ll.addWidget(self.list, 1)
        ll.addWidget(label("PUBLISHER IDENTITIES (SELF-ISSUED)", "h3"))
        self.imprints = QListWidget()
        self.imprints.setAccessibleName("Publisher signing identities")
        self.imprints.setMaximumHeight(110)
        ll.addWidget(self.imprints)
        ll.addLayout(row(button("New draft…", g(self.start_draft), kind="primary"),
                         button("New publisher identity…", g(self.new_imprint))))
        split.addWidget(left)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(12, 0, 0, 0)
        self.stepper = label("")
        self.stepper.setTextFormat(Qt.TextFormat.RichText)
        rl.addWidget(self.stepper)
        self.detail = QTextBrowser()
        self.detail.setAccessibleName("Publication details")
        rl.addWidget(self.detail, 1)
        self.btn = {}
        bar = row()
        for key, text, slot, kind in (("edit", "Edit package…", self.edit, ""), ("preview", "Preview…", self.preview, "primary"),
                                      ("rights", "Rights review…", self.rights, "primary"),
                                      ("publish", "Publish…", self.publish, "primary"),
                                      ("revise", "New edition…", self.revise, ""), ("announce", "Announce…", self.announce, ""),
                                      ("withdraw", "Withdraw…", self.withdraw, "danger"), ("discard", "Discard draft", self.discard, "danger")):
            self.btn[key] = button(text, g(slot), kind=kind)
            bar.insertWidget(bar.count() - 1, self.btn[key])
        rl.addLayout(bar)
        split.addWidget(right)
        split.setSizes([340, 840])
        self.body.addWidget(split, 1)

    def refresh(self) -> None:
        pubs = self.ctx.publishing.list()
        self.list.blockSignals(True)
        self.list.clear()
        for p in pubs:
            item = QListWidgetItem(f"{p['title']}\n{p['edition_label']} · {STATE_TEXT[p['state']]}")
            item.setData(Qt.ItemDataRole.UserRole, p["publication_id"])
            self.list.addItem(item)
            if p["publication_id"] == self.pid:
                self.list.setCurrentItem(item)
        self.list.blockSignals(False)
        if self.pid not in {p["publication_id"] for p in pubs}:
            self.pid = pubs[0]["publication_id"] if pubs else None
            if pubs:
                self.list.setCurrentRow(0)
        self.imprints.clear()
        for i in self.ctx.identity.publishers():
            self.imprints.addItem(f"{i['name']} — key {i['fingerprint'][:19]}…")
        self.show_publication()

    def _select(self, pid: str | None) -> None:
        self.pid = pid
        self.window_.safe(self.show_publication)

    def show_publication(self) -> None:
        for b in self.btn.values():
            b.setVisible(False)
        if not self.pid:
            self.stepper.setText("")
            self.detail.setHtml("<p><i>No publications yet.</i></p><p>Choose a work in your Library and press "
                                "<b>Publish…</b>, or press <b>New draft…</b>. The workflow is:</p>"
                                "<p><b>Draft → Preview → Rights review → Published → Revised or Withdrawn</b></p>"
                                + bullet_list(PUBLISH_NOTICES))
            return
        p = self.ctx.publishing.get(self.pid)
        order = [s for s, _ in STEPS]
        at = order.index(p["state"]) if p["state"] in order else len(order) - 1
        accent = theme.COPPER
        chips = []
        for i, (_state, text) in enumerate(STEPS):
            style = (f"color:{accent}; font-weight:700" if i == at else "color:gray" if i > at else "")
            chips.append(f"<span style='{style}'>{'●' if i <= at else '○'} {text}</span>")
        tail = {"revised": " &nbsp;→&nbsp; <b>Revised</b> (a newer edition exists)", "withdrawn": " &nbsp;→&nbsp; <b>Withdrawn</b>"}.get(p["state"], "")
        self.stepper.setText(" &nbsp;→&nbsp; ".join(chips) + tail)
        if p["immutable"]:
            m = p["manifest"]
            sig = (f"Signed by the self-issued publisher key <code>{fingerprint_display(m['publisher']['key_id'])[:29]}…</code> "
                   f"under the name “{esc(m['publisher']['name'])}”." if m.get("signature") else "Unsigned.")
            html = (f"<h2 style='font-family:\"{theme.serif_family()}\"; font-weight:normal'>{esc(m['title'])}</h2>"
                    f"<p><b>{esc(m['edition_label'])}</b> · edition {m['edition_number']} · {STATE_TEXT[p['state']]}</p>"
                    f"<p>Published {short_time(p['published_at'])} · licence: {esc(m['licence'])}</p>"
                    f"<p>Manifest id <code>{p['manifest_id'][:32]}…</code><br>{sig}</p>"
                    + (f"<p>Corrects edition <code>{m['previous_edition_id'][:12]}…</code>: {esc(m['revision_notes'])}</p>"
                       if m.get("previous_edition_id") else "")
                    + "<ul>" + "".join(f"<li>{esc(f['filename'])} · {human_size(f['size'])} · {len(f['chunks'])} chunk(s) · "
                                       f"<code>{f['file_hash'][:20]}…</code></li>" for f in m["files"]) + "</ul>"
                    "<p style='color:gray'>This edition is immutable. To correct it, release a new edition; both stay "
                    "identifiable.</p>"
                    + (f"<p><b>Withdrawn {short_time(p['withdrawn_at'])}.</b> {esc(WITHDRAWAL_NOTICE)}</p>" if p["state"] == "withdrawn" else ""))
            self.detail.setHtml(html)
        else:
            self.detail.setHtml(disclosure_html(self.ctx.publishing.disclosure(self.pid)))
        state = p["state"]
        show = {"edit": not p["immutable"], "discard": not p["immutable"], "preview": state == "draft",
                "rights": state == "preview", "publish": state == "rights_review", "revise": state == "published",
                "announce": state in ("published", "revised"), "withdraw": state in ("published", "revised")}
        for key, visible in show.items():
            self.btn[key].setVisible(visible)

    # ------------------------------------------------------------- actions
    def new_imprint(self) -> None:
        a = form_dialog(self, "New publisher identity", [("name", "Imprint name", "text", "")],
                        intro="This creates a new signing key on this device. The name is self-declared and the key is "
                              "self-issued: readers can tell that later editions come from the same key, not who you "
                              "are. Include it in your encrypted backups — a lost key cannot be recovered.", ok_text="Create key")
        if a:
            self.ctx.identity.create_publisher(a["name"])
            self.refresh()

    def start_draft(self, edition_id: str | None = None) -> None:
        if not edition_id:
            options = [(v["edition_id"], f"{v['title']} — {v['label'] or 'edition ' + str(v['edition_number'])}")
                       for v in self.ctx.catalogue.list() if v["origin"] == "local" and v["availability"] == "local"]
            if not options:
                self.window_.toast("Import a work into your library first.")
                return
            a = form_dialog(self, "New publication draft", [("eid", "Edition to publish", "choice", options[0][0], options)],
                            intro="A draft is private. It becomes public only after the preview, the rights review and "
                                  "an explicit publish action.", ok_text="Create draft")
            if not a:
                return
            edition_id = a["eid"]
        imprints = self.ctx.identity.publishers()
        draft = self.ctx.publishing.create_draft(edition_id, publisher_id=imprints[0]["publisher_id"] if imprints else "")
        self.pid = draft["publication_id"]
        self.window_.go("Publish")

    def edit(self) -> None:
        p = self.ctx.publishing.get(self.pid)
        pkg = p["package"]
        imprints = [("", "Unsigned")] + [(i["publisher_id"], i["name"]) for i in self.ctx.identity.publishers()]
        a = form_dialog(self, "Publication package", [
            ("title", "Title", "text", pkg["title"]), ("subtitle", "Subtitle", "text", pkg["subtitle"]),
            ("contributors", "Contributors (Name [role]; …)", "text",
             "; ".join(f"{c['name']} [{c['role']}]" for c in pkg["contributors"])),
            ("description", "Description", "multiline", pkg["description"]),
            ("language", "Language", "text", pkg["language"]), ("publication_date", "Publication date", "text", pkg["publication_date"]),
            ("subjects", "Subjects (separate with ;)", "text", "; ".join(pkg["subjects"])),
            ("licence", "Licence", "text", pkg["licence"]),
            ("rights_statement", "Rights statement", "text", pkg["rights_statement"]),
            ("accessibility", "Accessibility information", "text", pkg["accessibility"]),
            ("edition_label", "Edition label", "text", pkg["edition_label"]),
            ("revision_notes", "Revision notes", "multiline", pkg["revision_notes"]),
            ("publisher", "Sign as", "choice", p["publisher_id"], imprints)],
            intro="Editing returns the workflow to Draft: the preview and rights review are repeated so that what you "
                  "approve is exactly what is published.", ok_text="Save draft")
        if not a:
            return
        contributors = []
        for part in a.pop("contributors").split(";"):
            name, _, role = part.strip().partition("[")
            if name.strip():
                contributors.append({"name": name.strip(), "role": role.strip(" ]") or "author"})
        publisher = a.pop("publisher")
        a["subjects"] = [s.strip() for s in a["subjects"].split(";") if s.strip()]
        self.ctx.publishing.update_draft(self.pid, a | {"contributors": contributors}, publisher_id=publisher or "")
        if not publisher:
            self.ctx.db.execute("UPDATE publications SET publisher_id='' WHERE publication_id=?", (self.pid,))
        self.refresh()

    def preview(self) -> None:
        d = self.ctx.publishing.disclosure(self.pid)
        if d["problems"]:
            self.window_.toast(d["problems"][0], error=True)
            return
        if review_dialog(self, "Preview — exactly what will become public", disclosure_html(d),
                         ok_text="This is what I want to publish", confirm="I have read the preview"):
            self.ctx.publishing.enter_preview(self.pid)
            self.refresh()

    def rights(self) -> None:
        a = form_dialog(self, "Rights review", [
            ("rights_basis", "On what basis may you publish this?", "choice", "author", [(b, BASIS_TEXT[b]) for b in RIGHTS_BASES]),
            ("note", "Notes (optional, kept privately)", "multiline", ""),
            ("licence_confirmed", "The licence / rights statement in the package is the one I intend", "check", False),
            ("no_private_material", "The files contain nothing I mean to keep private", "check", False),
            ("understands_permanence", "I understand distributed copies persist even if I withdraw the edition", "check", False)],
            intro="This is your own declaration. Aureom Commons does not verify it, and publishing here does not "
                  "establish or prove copyright ownership.", ok_text="Complete review")
        if a:
            self.ctx.publishing.submit_rights_review(self.pid, a)
            self.refresh()

    def publish(self) -> None:
        d = self.ctx.publishing.disclosure(self.pid)
        title = d["will_become_public"]["metadata"]["title"]
        if not review_dialog(self, "Publish this edition", disclosure_html(d), ok_text="Publish now",
                             confirm=f"Yes — make “{title}” public. I understand this cannot be undone."):
            return
        self.window_.run_blocking(
            lambda: self.ctx.publishing.publish(self.pid, disclosure_digest=d["digest"], confirm=True),
            lambda p: (self.ctx.events.emit("library"), self.refresh(), self.window_.toast(
                "Published. The edition is now in your public catalogue and is immutable.")))

    def revise(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose the file for the new edition")
        if not path:
            return
        a = form_dialog(self, "New edition", [
            ("label", "Edition label", "text", "Corrected edition"),
            ("relation", "Relationship", "choice", "correction-of", [("correction-of", "Correction of the published edition"),
                                                                     ("revision-of", "Revision of the published edition")]),
            ("notes", "What changed (published with the edition)", "multiline", "")],
            intro="The published edition is not altered. The new file becomes a separate edition with its own hashes "
                  "and manifest, linked to the one it replaces. It starts as a private draft.", ok_text="Create draft")
        if a:
            draft = self.ctx.publishing.create_revision(self.pid, path, label=a["label"], notes=a["notes"], relation=a["relation"])
            self.pid = draft["publication_id"]
            self.refresh()

    def announce(self) -> None:
        if not self.ctx.node.rendezvous.url:
            self.window_.toast("No rendezvous catalogue is configured (Settings → Network). Your edition is still "
                               "available to anyone who connects to your device directly.")
            return
        if review_dialog(self, "Announce to the public index",
                         f"<h3>Announce this edition?</h3><p>The signed manifest and your device's address are sent to "
                         f"<b>{esc(self.ctx.node.rendezvous.url)}</b>, whose operator can list, delist and log it. "
                         "Only this published edition is sent — never private collections, titles or hashes.</p>",
                         ok_text="Announce", height=300):
            self.ctx.publishing.set_announce(self.pid, True)
            self.window_.run_blocking(lambda: self.ctx.node.rendezvous.announce(self.pid),
                                      lambda r: self.window_.toast(r.get("note", "Announced.")))

    def withdraw(self) -> None:
        if review_dialog(self, "Withdraw this edition", f"<h3>Withdraw from your public catalogue?</h3><p>{esc(WITHDRAWAL_NOTICE)}</p>",
                         ok_text="Withdraw edition", danger=True, height=300):
            self.ctx.publishing.withdraw(self.pid)
            self.window_.run_blocking(lambda: self.ctx.node.rendezvous.withdraw_safely(self.pid))
            self.ctx.events.emit("library")
            self.refresh()
            self.window_.toast(WITHDRAWAL_NOTICE)

    def discard(self) -> None:
        self.ctx.publishing.discard_draft(self.pid)
        self.pid = None
        self.refresh()


class TransfersPage(Page):
    topics = ("transfers",)

    def __init__(self, window) -> None:
        super().__init__(window)
        self.body.addWidget(notice("Downloads are chunked. Each chunk is checked against the manifest before it is kept, "
                                   "and the whole file is checked again before it joins your library. A matching hash "
                                   "shows the bytes are the ones described — not that the file is safe or accurate."))
        self.table = make_table(["Title", "Progress", "State", "Speed", "Chunks", "Rejected", "Source", "Detail"])
        self.table.setAccessibleName("Transfers")
        self.body.addWidget(self.table, 1)
        g = lambda fn: (lambda: self.window_.safe(fn))  # noqa: E731
        self.body.addLayout(row(button("Pause", g(lambda: self.act("pause"))), button("Resume", g(lambda: self.act("resume"))),
                                button("Cancel", g(lambda: self.act("cancel")), kind="danger")))

    def tick(self) -> None:
        self.refresh()

    def refresh(self) -> None:
        rows = []
        for t in self.ctx.transfers.list():
            bar = QProgressBar()
            bar.setValue(round(t["progress"] * 100))
            bar.setAccessibleName(f"Progress of {t['title']}")
            source = ("public catalogue" if t["scope"]["kind"] == "public" else "your own device"
                      if t["scope"]["kind"] == "device" else "collection owner")
            rows.append((t["transfer_id"], [t["title"] or "Untitled", bar, t["state"],
                                            f"{human_size(t['speed_bps'])}/s" if t["speed_bps"] else "",
                                            f"{t['chunks_done']}/{t['chunks_total']}" if t["chunks_total"] else "—",
                                            t["corrupt_chunks"] or "", source, t["error"]]))
        fill_table(self.table, rows)

    def act(self, action: str) -> None:
        tid = selected_payload(self.table)
        if not tid:
            self.window_.toast("Select a transfer first.")
            return
        getattr(self.ctx.transfers, action)(tid)
        self.refresh()


class ActivityPage(Page):
    topics = ("activity", "annotations")

    def __init__(self, window) -> None:
        super().__init__(window)
        tabs = QTabWidget()
        g = lambda fn: (lambda: self.window_.safe(fn))  # noqa: E731
        self.journal = make_table(["When", "Event", "What happened", "Peer"], stretch=2)
        self.journal.setAccessibleName("Activity journal")
        tabs.addTab(self.journal, "Journal")
        conflicts = QWidget()
        cl = QVBoxLayout(conflicts)
        cl.addWidget(notice("When two of your devices change the same thing while out of contact, neither change is "
                            "discarded. The value in use is shown first; the other is kept here until you decide."))
        self.conflicts = make_table(["Detected", "Kind", "Rule", "Field", "This device had", "Other device had"], stretch=4)
        self.conflicts.setAccessibleName("Synchronisation conflicts")
        cl.addWidget(self.conflicts, 1)
        cl.addLayout(row(button("Keep the current value", g(lambda: self.resolve("keep_current"))),
                         button("Use the other value", g(lambda: self.resolve("use_other"))),
                         button("Confirm deletion", g(lambda: self.resolve("delete")), kind="danger")))
        tabs.addTab(conflicts, "Conflicts")
        reviews = QWidget()
        rl = QVBoxLayout(reviews)
        rl.addWidget(notice("Annotations carried to a new edition whose text changed. Check each one still refers to "
                            "the passage you meant; nothing is discarded automatically."))
        self.reviews = make_table(["Work", "Kind", "Status", "Passage", "Why"], stretch=3)
        self.reviews.setAccessibleName("Annotations needing review")
        rl.addWidget(self.reviews, 1)
        rl.addLayout(row(button("Open in Reading Room", g(self.open_review)), button("Mark as correct", g(self.accept_review)),
                         button("Delete annotation", g(self.delete_review), kind="danger")))
        tabs.addTab(reviews, "Annotation reviews")
        self.body.addWidget(tabs)

    def refresh(self) -> None:
        fill_table(self.journal, ((a["id"], [short_time(a["ts"]), a["kind"], a["summary"], a["peer"][:8]])
                                  for a in self.ctx.activity.recent(300)))
        fill_table(self.conflicts, ((c["conflict_id"], [short_time(c["detected_at"]), c["kind"], c["rule"], c["field"],
                                                        str(c["local_value"]), str(c["remote_value"])])
                                    for c in self.ctx.sync.conflicts()))
        rows = []
        for a in self.ctx.annotations.review_queue():
            try:
                title = self.ctx.catalogue.edition_view(a["edition_id"])["title"]
            except Exception:
                title = "(removed work)"
            rows.append((a["annotation_id"], [title, a["kind"], a["status"].replace("_", " "),
                                              a["locator"].get("quote", "")[:120], a["review_note"]]))
        fill_table(self.reviews, rows)

    def resolve(self, choice: str) -> None:
        cid = selected_payload(self.conflicts)
        if cid:
            self.ctx.sync.resolve(cid, choice)
            self.refresh()

    def open_review(self) -> None:
        aid = selected_payload(self.reviews)
        if aid:
            a = self.ctx.annotations.get(aid)
            self.window_.open_reader(a["edition_id"])
            self.window_.pages["Reading Room"].jump_to(aid)

    def accept_review(self) -> None:
        aid = selected_payload(self.reviews)
        if aid:
            self.ctx.annotations.update(aid, status="ok")
            self.refresh()

    def delete_review(self) -> None:
        aid = selected_payload(self.reviews)
        if aid:
            self.ctx.annotations.delete(aid)
            self.refresh()
