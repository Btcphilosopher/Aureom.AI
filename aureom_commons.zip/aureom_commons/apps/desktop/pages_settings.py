"""Settings: identity names, protection, limits, network, backup, appearance."""
from __future__ import annotations

from PySide6.QtWidgets import QFileDialog, QScrollArea, QTabWidget, QTextBrowser, QVBoxLayout, QWidget

from aureom.domain.limits import Limits

from .widgets import Page, bullet_list, button, esc, form_dialog, human_size, label, notice, row

LIMIT_FIELDS = [
    ("max_document_bytes", "Largest document (bytes)"), ("max_storage_bytes", "Managed library size limit (bytes)"),
    ("max_manifest_bytes", "Largest manifest accepted (bytes)"), ("max_chunks", "Most chunks per file"),
    ("chunk_size", "Chunk size when serving (bytes)"), ("max_concurrent_transfers", "Concurrent transfers"),
    ("max_decompression_ratio", "Highest archive compression ratio"), ("max_archive_entries", "Most entries in an archive"),
    ("preview_timeout_seconds", "Extraction time limit (seconds)"), ("search_requests_per_minute", "Peer search requests per minute"),
    ("catalogue_announcements_per_hour", "Catalogue announcements per hour"), ("max_connections", "Simultaneous peer connections"),
    ("default_bandwidth_kbps", "Default per-peer bandwidth (kbps, 0 = unlimited)"), ("invitation_ttl_hours", "Invitation lifetime (hours)"),
]


class SettingsPage(Page):
    def __init__(self, window) -> None:
        super().__init__(window)
        g = lambda fn: (lambda: self.window_.safe(fn))  # noqa: E731
        tabs = QTabWidget()
        self.views: dict[str, QTextBrowser] = {}
        specs = {
            "General": [("Names…", self.edit_names), ("Import and indexing defaults…", self.edit_defaults)],
            "Protection": [("Lock library now", self.lock)],
            "Limits": [("Edit limits…", self.edit_limits)],
            "Network": [("Network settings…", self.edit_network)],
            "Backup": [("Export encrypted backup…", self.export_backup), ("Restore a backup into a new folder…", self.restore_backup)],
        }
        for name, actions in specs.items():
            page = QWidget()
            lay = QVBoxLayout(page)
            view = QTextBrowser()
            view.setOpenLinks(False)
            view.setAccessibleName(f"{name} settings")
            self.views[name] = view
            lay.addWidget(view, 1)
            lay.addLayout(row(*(button(text, g(slot)) for text, slot in actions)))
            tabs.addTab(page, name)
        self.body.addWidget(tabs)

    def refresh(self) -> None:
        s = self.ctx.settings.all()
        st = self.ctx.status()
        rep = self.ctx.protection_report()
        self.views["General"].setHtml(
            f"<h3>Names</h3><p>Device name: <b>{esc(s['device_name'])}</b><br>Your name: <b>{esc(s['account_name'] or '(not set)')}</b></p>"
            "<p style='color:gray'>Names are labels shown to people you share with. They are not proof of identity.</p>"
            f"<h3>Defaults</h3><p>New imports are {'copied into the managed library' if s['import_mode'] == 'managed' else 'referenced where they are'}."
            f"<br>Search indexing for new documents: <b>{esc(s['index_default'])}</b>.</p>"
            f"<h3>Appearance</h3><p>Theme: {esc(s['theme'])} · text scale {s['text_scale']}% (Ctrl+= / Ctrl+- / Ctrl+0).</p>"
            f"<h3>Library</h3><p>{st['library']['editions']} edition(s) · {human_size(st['library']['storage_bytes'])} of "
            f"{human_size(st['library']['storage_limit'])} used · profile folder {esc(st['profile'])}</p>")
        self.views["Protection"].setHtml(
            f"<h2>{'This library is encrypted at rest' if rep['encrypted_library'] else 'This library is not encrypted'}</h2>"
            + (f"<h3>Protected while the library is locked</h3>{bullet_list(rep['protected_when_locked'])}" if rep["encrypted_library"] else "")
            + f"<h3>Not protected</h3>{bullet_list(rep['not_protected'])}"
            f"<p>Files imported by reference: <b>{rep['referenced_files']}</b>. They are ordinary files; encrypting the "
            "library does not change them.</p>"
            f"<h3>Keys</h3><p>{esc(rep['key_storage_note'])}</p>"
            "<h3>Logs</h3><p>The diagnostic log records event types and shortened identifiers only — never titles, "
            "document text, invitation secrets or keys. The Activity journal lives inside the library database.</p>"
            + ("" if rep["encrypted_library"] else "<p>To encrypt, export a backup and restore it into a new folder "
               "with a library passphrase (Backup tab).</p>")
            + f"<h3>If a device is lost</h3>{bullet_list(rep['device_loss_guidance'])}")
        limits = self.ctx.settings.limits.model_dump()
        self.views["Limits"].setHtml(
            "<p>Every limit bounds something an untrusted document, manifest or peer could otherwise make arbitrarily large.</p>"
            "<table cellpadding='5'>" + "".join(f"<tr><td>{esc(text)}</td><td><b>{limits[key]:,}</b></td></tr>"
                                                for key, text in LIMIT_FIELDS) + "</table>")
        net = st["network"]
        self.views["Network"].setHtml(
            f"<h2>{esc(net['label'])}</h2><p>{esc(net['detail'])}</p>"
            f"<table cellpadding='5'><tr><td>Listening on</td><td><b>{esc(s['listen_host'])}:{net['port'] or s['listen_port'] or 'automatic'}</b></td></tr>"
            f"<tr><td>Addresses put in invitations</td><td>{esc(', '.join(net['addresses']) or '—')}</td></tr>"
            f"<tr><td>Local-network discovery</td><td>{'on' if s['lan_discovery'] else 'off (default)'}"
            f"{' · announcing device name' if s['lan_announce_name'] else ''}</td></tr>"
            f"<tr><td>Relay</td><td>{esc(s['relay_address'] or 'not used (default)')}"
            f"{' · connected' if net['relay_connected'] else ''}</td></tr>"
            f"<tr><td>Rendezvous / public index</td><td>{esc(s['rendezvous_url'] or 'not used (default)')}</td></tr>"
            f"<tr><td>Serve my published editions to direct visitors</td><td>{'yes' if s['serve_public_catalogue'] else 'no'}</td></tr>"
            f"<tr><td>Proposals from collection members</td><td>{esc(s['accept_proposals'])}</td></tr></table>"
            "<h3>What each stage means</h3><ul><li><b>Direct</b> — peers connect to an address you give them; TLS 1.3 "
            "with pinned device keys.</li><li><b>Local discovery</b> (opt-in) — broadcasts this device's fingerprint "
            "and port on your local network as an address hint. Discovered devices are not trusted.</li><li><b>Relay"
            "</b> (opt-in) — for peers that cannot connect directly. Content stays end-to-end encrypted; the relay "
            "sees device ids, IP addresses, timing and volume.</li><li>Automatic NAT traversal is <b>not</b> provided: "
            "without a reachable address or a shared relay, two devices cannot connect.</li></ul>"
            + ("" if net["secure_transport"] else f"<p><b>{esc(net['secure_transport_note'])}</b></p>"))
        self.views["Backup"].setHtml(
            "<h3>Encrypted backup</h3><p>A backup contains the catalogue (metadata, collections, annotations, reading "
            "progress, activity) and every managed file, encrypted with a passphrase you choose for the backup. "
            "Files imported by reference are <b>not</b> included.</p><p>Including identity keys lets a replacement "
            "device take over this device's identity and publisher keys. Only restore such a backup when the original "
            "device is gone — two devices with one identity confuse your peers.</p><p>Restoration re-verifies every "
            "file against its content hash and always goes into a new, empty folder.</p>")

    # ------------------------------------------------------------- actions
    def edit_names(self) -> None:
        s = self.ctx.settings
        a = form_dialog(self, "Names", [("device_name", "Device name", "text", s.get("device_name")),
                                        ("account_name", "Your name", "text", s.get("account_name"))])
        if a:
            for key, value in a.items():
                s.set(key, value)
            self.window_.update_status()
            self.refresh()

    def edit_defaults(self) -> None:
        s = self.ctx.settings
        a = form_dialog(self, "Import and indexing defaults", [
            ("import_mode", "New imports", "choice", s.get("import_mode"),
             [("managed", "Copy into the managed library"), ("referenced", "Reference originals where they are")]),
            ("index_default", "Search indexing for new documents", "choice", s.get("index_default"),
             [("full", "Index title, details and full text"), ("metadata", "Index title and details only"),
              ("none", "Do not index")])],
            intro="Use “details only” or “do not index” if you import sensitive documents into an unencrypted library.")
        if a:
            for key, value in a.items():
                s.set(key, value)
            self.refresh()

    def edit_limits(self) -> None:
        limits = self.ctx.settings.limits.model_dump()
        fields = [(key, text, "text", limits[key]) for key, text in LIMIT_FIELDS]
        a = form_dialog(self, "Resource limits", fields, intro="Values are validated before they are saved.")
        if a:
            defaults = Limits().model_dump()
            try:
                changes = {k: type(defaults[k])(float(v)) for k, v in a.items()}
                self.ctx.settings.set_limits(**changes)
            except ValueError as exc:
                self.window_.toast(f"Those limits were not accepted: {str(exc)[:160]}", error=True)
                return
            self.ctx.store.max_bytes = self.ctx.settings.limits.max_storage_bytes
            self.refresh()

    def edit_network(self) -> None:
        s = self.ctx.settings
        a = form_dialog(self, "Network", [
            ("listen_host", "Listen on (127.0.0.1 = this computer only; 0.0.0.0 = all interfaces)", "text", s.get("listen_host")),
            ("listen_port", "Port (0 = choose automatically)", "int", s.get("listen_port")),
            ("advertise", "Addresses to put in invitations (host:port, comma separated)", "text",
             ", ".join(s.get("advertise_addresses") or [])),
            ("lan_discovery", "Enable local-network discovery (broadcasts this device's fingerprint and port)", "check", s.get("lan_discovery")),
            ("lan_announce_name", "Include this device's name in local announcements", "check", s.get("lan_announce_name")),
            ("relay_address", "Relay host:port (optional)", "text", s.get("relay_address")),
            ("rendezvous_url", "Rendezvous / public index URL (optional)", "text", s.get("rendezvous_url")),
            ("serve_public_catalogue", "Serve my published editions to anyone who connects", "check", s.get("serve_public_catalogue")),
            ("accept_proposals", "Proposals from members", "choice", s.get("accept_proposals"),
             [("ask", "Ask me before fetching anything"), ("never", "Refuse all proposals")])],
            intro="Discovery, relay and rendezvous are optional and off by default. Changes take effect after "
                  "reconnecting.", ok_text="Save and reconnect")
        if not a:
            return
        s.set("advertise_addresses", [x.strip() for x in a.pop("advertise").split(",") if x.strip()])
        for key, value in a.items():
            s.set(key, value)
        node = self.ctx.node

        async def restart():
            await node.stop_network()
            if s.get("network_enabled"):
                await node.start_network()

        self.window_.run(restart(), lambda _r: (self.window_.update_status(), self.refresh(),
                                                self.window_.toast(self.ctx.node.status()["detail"])))

    def lock(self) -> None:
        if not self.ctx.store.encrypted:
            self.window_.toast("This library is not encrypted, so there is nothing to lock. See the Backup tab to "
                               "move it into an encrypted library.")
            return
        self.window_.close()

    def export_backup(self) -> None:
        a = form_dialog(self, "Export encrypted backup", [
            ("passphrase", "Backup passphrase", "password", ""), ("repeat", "Repeat passphrase", "password", ""),
            ("identity", "Include device, account and publisher keys", "check", True)],
            intro="Choose a passphrase for this backup. It is independent of your library passphrase and cannot be recovered.")
        if not a:
            return
        if a["passphrase"] != a["repeat"]:
            self.window_.toast("The two passphrases do not match.", error=True)
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save backup", "aureom-library.aureom-backup", "Aureom backup (*.aureom-backup)")
        if path:
            self.window_.run_blocking(
                lambda: self.ctx.export_backup(path, a["passphrase"], include_identity=a["identity"]),
                lambda m: self.window_.toast(f"Backup written: {m['objects']} file(s)"
                                             + (f"; {len(m['referenced_files_not_included'])} referenced file(s) were not included."
                                                if m["referenced_files_not_included"] else ".")))

    def restore_backup(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose a backup", "", "Aureom backup (*.aureom-backup);;All files (*)")
        if not path:
            return
        folder = QFileDialog.getExistingDirectory(self, "Choose an EMPTY folder to restore into")
        if not folder:
            return
        a = form_dialog(self, "Restore backup", [
            ("backup", "Backup passphrase", "password", ""),
            ("library", "New library passphrase (leave empty for an unencrypted library)", "password", "")],
            intro=f"The backup will be restored into:\n{folder}\n\nThis running library is not changed. Open the "
                  "restored library afterwards with:  aureom-commons --profile-dir <that folder>")
        if not a:
            return
        from aureom.node.service import Commons

        def work():
            restored = Commons.restore_backup(path, a["backup"], folder, passphrase=a["library"] or None)
            count = restored.db.scalar("SELECT COUNT(*) FROM editions WHERE deleted=0", (), 0)
            restored.close()
            return count

        self.window_.run_blocking(work, lambda n: self.window_.toast(
            f"Restored {n} edition(s) into {folder}. Every file was re-verified against its content hash."))


__all__ = ["SettingsPage", "QScrollArea", "label", "notice"]
