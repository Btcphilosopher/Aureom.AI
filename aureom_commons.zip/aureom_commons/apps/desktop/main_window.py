"""Main window: navigation rail, always-visible connection status, pages."""
from __future__ import annotations

import concurrent.futures
import logging
from typing import Any, Callable

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QButtonGroup, QFrame, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
                               QPushButton, QStackedWidget, QVBoxLayout, QWidget)

from aureom.domain.errors import CommonsError
from aureom.domain.util import group4

from . import theme
from .widgets import Bridge, bullet_list, button, esc, label, review_dialog

log = logging.getLogger("aureom.desktop")
NAV = ["Library", "Reading Room", "Collections", "Peers", "Publish", "Transfers", "Activity", "Settings"]


class MainWindow(QMainWindow):
    def __init__(self, ctx) -> None:
        super().__init__()
        self.ctx = ctx
        self.bridge = Bridge()
        self._pool = concurrent.futures.ThreadPoolExecutor(max_workers=2, thread_name_prefix="aureom-ui")
        self._dirty: set[str] = set()
        self.setWindowTitle("Aureom Commons")
        self.resize(1440, 900)
        self.setMinimumSize(1080, 680)
        self.setAcceptDrops(True)

        root = QWidget()
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ---- navigation rail
        nav = QFrame()
        nav.setObjectName("nav")
        nav.setFixedWidth(214)
        nav_lay = QVBoxLayout(nav)
        nav_lay.setContentsMargins(0, 0, 0, 0)
        nav_lay.setSpacing(0)
        wordmark = QPushButton("AUREOM")
        wordmark.setObjectName("wordmark")
        wordmark.setAccessibleName("Home")
        wordmark.setToolTip("Home (Ctrl+H)")
        wordmark.setCursor(Qt.CursorShape.PointingHandCursor)
        wordmark.clicked.connect(lambda: self.go("Home"))
        nav_lay.addWidget(wordmark)
        nav_lay.addWidget(label("COMMONS  ·  library & press", "tagline"))
        self.group = QButtonGroup(self)
        self.nav_buttons: dict[str, QPushButton] = {}
        for i, name in enumerate(NAV, 1):
            btn = QPushButton(name)
            btn.setObjectName("navbutton")
            btn.setCheckable(True)
            btn.setAccessibleName(f"{name} page")
            btn.setToolTip(f"{name} (Ctrl+{i})")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _c=False, n=name: self.go(n))
            self.group.addButton(btn)
            self.nav_buttons[name] = btn
            nav_lay.addWidget(btn)
            QShortcut(QKeySequence(f"Ctrl+{i}"), self, activated=lambda n=name: self.go(n))
        nav_lay.addStretch(1)
        self.nav_foot = label("", "navfoot", wrap=True)
        nav_lay.addWidget(self.nav_foot)
        outer.addWidget(nav)

        # ---- right side: top bar + pages
        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(0)
        top = QFrame()
        top.setObjectName("topbar")
        top_lay = QHBoxLayout(top)
        top_lay.setContentsMargins(26, 12, 20, 12)
        top_lay.setSpacing(10)
        self.page_title = label("Home", "pagetitle")
        top_lay.addWidget(self.page_title)
        top_lay.addStretch(1)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search titles, authors and text…  (Ctrl+F)")
        self.search.setAccessibleName("Search the library")
        self.search.setClearButtonEnabled(True)
        self.search.setFixedWidth(330)
        self.search.returnPressed.connect(self._global_search)
        top_lay.addWidget(self.search)
        self.status = QPushButton("Offline")
        self.status.setObjectName("status")
        self.status.setCursor(Qt.CursorShape.PointingHandCursor)
        self.status.setAccessibleName("Connection status")
        self.status.clicked.connect(self.toggle_network)
        top_lay.addWidget(self.status)
        top_lay.addWidget(button("A−", lambda: self.scale_text(-10), tip="Smaller text (Ctrl+-)", name="Smaller text"))
        top_lay.addWidget(button("A+", lambda: self.scale_text(10), tip="Larger text (Ctrl+=)", name="Larger text"))
        self.theme_btn = button("Dark", self.toggle_theme, tip="Switch between light and dark themes")
        top_lay.addWidget(self.theme_btn)
        right.addWidget(top)
        self.stack = QStackedWidget()
        right.addWidget(self.stack, 1)
        outer.addLayout(right, 1)

        self.toast_label = QLabel("", self)
        self.toast_label.setObjectName("toast")
        self.toast_label.setWordWrap(True)
        self.toast_label.hide()
        self._toast_timer = QTimer(self, singleShot=True, timeout=self.toast_label.hide)

        from .pages_library import HomePage, LibraryPage
        from .pages_publish import ActivityPage, PublishPage, TransfersPage
        from .pages_settings import SettingsPage
        from .pages_sharing import CollectionsPage, PeersPage
        from .reader import ReaderPage

        self.pages: dict[str, Any] = {}
        for name, cls in (("Home", HomePage), ("Library", LibraryPage), ("Reading Room", ReaderPage),
                          ("Collections", CollectionsPage), ("Peers", PeersPage), ("Publish", PublishPage),
                          ("Transfers", TransfersPage), ("Activity", ActivityPage), ("Settings", SettingsPage)):
            page = cls(self)
            self.pages[name] = page
            self.stack.addWidget(page)

        for keys, fn in (("Ctrl+H", lambda: self.go("Home")), ("Ctrl+F", self._focus_search),
                         ("Ctrl+I", lambda: self.pages["Library"].choose_import()),
                         ("Ctrl+=", lambda: self.scale_text(10)), ("Ctrl++", lambda: self.scale_text(10)),
                         ("Ctrl+-", lambda: self.scale_text(-10)), ("Ctrl+0", lambda: self.scale_text(0))):
            QShortcut(QKeySequence(keys), self, activated=fn)

        ctx.events.subscribe(lambda topic, data: self.bridge.post(lambda: self._on_event(topic)))
        self._refresh_timer = QTimer(self, singleShot=True, timeout=self._flush_events)
        self._tick = QTimer(self, interval=1000, timeout=self._every_second)
        self._tick.start()
        self.apply_theme()
        self.update_status()
        self.go("Home")

    # ------------------------------------------------------------ navigation
    def go(self, name: str) -> None:
        page = self.pages[name]
        self.stack.setCurrentWidget(page)
        self.page_title.setText(name)
        for n, btn in self.nav_buttons.items():
            btn.setChecked(n == name)
        if name == "Home":
            checked = self.group.checkedButton()
            if checked:
                self.group.setExclusive(False)
                checked.setChecked(False)
                self.group.setExclusive(True)
        self.safe(page.refresh)

    def current(self) -> str:
        return next(n for n, p in self.pages.items() if p is self.stack.currentWidget())

    def open_reader(self, edition_id: str) -> None:
        self.go("Reading Room")
        self.safe(self.pages["Reading Room"].open_edition, edition_id)

    def _focus_search(self) -> None:
        if self.current() == "Reading Room":
            self.pages["Reading Room"].focus_find()
        else:
            self.search.setFocus()
            self.search.selectAll()

    def _global_search(self) -> None:
        self.pages["Library"].set_query(self.search.text())
        self.go("Library")

    # ---------------------------------------------------------------- events
    def _on_event(self, topic: str) -> None:
        if self.ctx.closed:
            return
        self._dirty.add(topic)
        if not self._refresh_timer.isActive():
            self._refresh_timer.start(250)

    def _flush_events(self) -> None:
        topics, self._dirty = self._dirty, set()
        if self.ctx.closed:
            return
        if "network" in topics or "peers" in topics:
            self.update_status()
        page = self.stack.currentWidget()
        if topics & set(getattr(page, "topics", ())):
            self.safe(page.refresh)

    def _every_second(self) -> None:
        if self.ctx.closed:
            return
        self.update_status()
        page = self.stack.currentWidget()
        if hasattr(page, "tick"):
            self.safe(page.tick)

    # ------------------------------------------------------------- execution
    def safe(self, fn: Callable, *args: Any, **kwargs: Any) -> Any:
        """Run a UI action; show domain errors to the user instead of crashing."""
        try:
            return fn(*args, **kwargs)
        except CommonsError as exc:
            self.toast(str(exc) or exc.code, error=True)
        except Exception as exc:
            log.exception("interface action failed")
            self.toast(f"Something went wrong ({type(exc).__name__}). Details are in the application log.", error=True)
        return None

    def _deliver(self, future, done: Callable | None, failed: Callable | None) -> None:
        def finish() -> None:
            try:
                result = future.result()
            except CommonsError as exc:
                if failed:
                    self.safe(failed, exc)
                else:
                    self.toast(str(exc) or exc.code, error=True)
                return
            except Exception as exc:
                log.exception("background task failed")
                self.toast(f"Something went wrong ({type(exc).__name__}).", error=True)
                return
            if done:
                self.safe(done, result)

        self.bridge.post(finish)

    def run(self, coro, done: Callable | None = None, failed: Callable | None = None) -> None:
        """Run a network coroutine on the node loop; never blocks the interface."""
        try:
            future = self.ctx.node.submit(coro)
        except CommonsError as exc:
            self.toast(str(exc), error=True)
            return
        future.add_done_callback(lambda f: self._deliver(f, done, failed))

    def run_blocking(self, fn: Callable, done: Callable | None = None, failed: Callable | None = None) -> None:
        """Run slow local work (imports, backups) off the GUI thread."""
        future = self._pool.submit(fn)
        future.add_done_callback(lambda f: self._deliver(f, done, failed))

    def toast(self, message: str, error: bool = False) -> None:
        self.toast_label.setText(message)
        self.toast_label.setProperty("error", "true" if error else "false")
        self.toast_label.style().unpolish(self.toast_label)
        self.toast_label.style().polish(self.toast_label)
        self.toast_label.setFixedWidth(min(640, self.width() - 280))
        self.toast_label.adjustSize()
        self.toast_label.move(self.width() - self.toast_label.width() - 24, self.height() - self.toast_label.height() - 24)
        self.toast_label.show()
        self.toast_label.raise_()
        self._toast_timer.start(9000 if error else 5000)

    # ----------------------------------------------------------------- status
    def update_status(self) -> None:
        net = self.ctx.node.status()
        text = {"offline": "○  Offline", "direct": "●  Direct", "relay": "◆  Relay"}[net["mode"]]
        if self.status.text() != text or self.status.toolTip() != net["detail"]:
            self.status.setText(text)
            self.status.setProperty("mode", net["mode"])
            self.status.setToolTip(net["detail"] + "\n\nClick to go " + ("offline." if net["listening"] else "online."))
            self.status.setAccessibleDescription(net["detail"])
            self.status.style().unpolish(self.status)
            self.status.style().polish(self.status)
        ident = self.ctx.identity
        self.nav_foot.setText(f"{ident.device_name}\n{group4(ident.device_id[:12].upper())}\n"
                              + ("Encrypted library" if self.ctx.store.encrypted else "Library not encrypted"))

    def toggle_network(self) -> None:
        node = self.ctx.node
        if node.status()["listening"]:
            self.ctx.settings.set("network_enabled", False)
            self.run(node.stop_network(), lambda _r: (self.update_status(), self.toast(
                "You are offline. Your library and reading room keep working; nothing is shared or downloaded.")))
        else:
            self.ctx.settings.set("network_enabled", True)

            def online(_r) -> None:
                self.ctx.transfers.kick()
                self.update_status()
                self.toast(self.ctx.node.status()["detail"])

            self.run(node.start_network(), online)

    # ------------------------------------------------------------------ theme
    def apply_theme(self) -> None:
        name = self.ctx.settings.get("theme")
        scale = int(self.ctx.settings.get("text_scale") or 100)
        QApplication.instance().setStyleSheet(theme.stylesheet(name, scale))
        self.theme_btn.setText("Light" if name == "dark" else "Dark")
        for page in self.pages.values():
            if hasattr(page, "theme_changed"):
                self.safe(page.theme_changed)

    def toggle_theme(self) -> None:
        self.ctx.settings.set("theme", "light" if self.ctx.settings.get("theme") == "dark" else "dark")
        self.apply_theme()
        self.safe(self.stack.currentWidget().refresh)

    def scale_text(self, delta: int) -> None:
        current = int(self.ctx.settings.get("text_scale") or 100)
        self.ctx.settings.set("text_scale", 100 if delta == 0 else max(80, min(180, current + delta)))
        self.apply_theme()

    # ------------------------------------------------------------ drag & drop
    def dragEnterEvent(self, event) -> None:
        if event.mimeData().hasUrls() and any(u.isLocalFile() for u in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            event.acceptProposedAction()
            self.import_paths(paths)

    def import_paths(self, paths: list[str], mode: str | None = None) -> None:
        """Import files/folders into the *private* library.  Nothing is shared or announced."""
        self.toast(f"Importing {len(paths)} item(s) into your private library…")

        def done(results) -> None:
            counts = {s: sum(1 for r in results if r.status == s) for s in ("imported", "duplicate", "failed")}
            self.ctx.events.emit("library")
            rows = "".join(
                f"<tr><td>{esc(r.name)}</td><td><b>{esc(r.status)}</b></td>"
                f"<td>{esc(r.message or '; '.join(r.warnings))}</td></tr>" for r in results)
            if counts["failed"] or counts["duplicate"] or any(r.warnings for r in results):
                review_dialog(self, "Import results",
                              f"<h3>{counts['imported']} imported · {counts['duplicate']} already in your library · "
                              f"{counts['failed']} failed</h3><p>Imported works are <b>private</b>. Nothing has been "
                              f"shared, published or announced.</p><table cellpadding='5'>{rows}</table>",
                              ok_text="", cancel_text="Close")
            else:
                self.toast(f"{counts['imported']} work(s) imported. They are private until you choose to share or publish.")
            if self.current() in ("Home", "Library"):
                self.safe(self.stack.currentWidget().refresh)

        self.run_blocking(lambda: self.ctx.catalogue.import_paths(paths, mode=mode), done)

    def closeEvent(self, event) -> None:
        self._tick.stop()
        self._refresh_timer.stop()
        if self.ctx.closed:
            event.accept()
            return
        self.safe(self.pages["Reading Room"].close_current)       # saves progress, wipes temporary copies
        self._pool.shutdown(wait=False, cancel_futures=True)
        self.ctx.close()
        event.accept()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self.toast_label.isVisible():
            self.toast_label.move(self.width() - self.toast_label.width() - 24,
                                  self.height() - self.toast_label.height() - 24)


__all__ = ["MainWindow", "bullet_list"]
