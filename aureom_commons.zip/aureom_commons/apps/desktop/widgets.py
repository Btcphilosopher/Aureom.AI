"""Shared widgets and helpers for the desktop interface."""
from __future__ import annotations

import hashlib
import html
from typing import Any, Callable, Iterable

from PySide6.QtCore import QObject, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QFrame,
                               QHBoxLayout, QHeaderView, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from . import theme


class Bridge(QObject):
    """Runs callables on the GUI thread (safe to call from any thread)."""

    call = Signal(object)

    def __init__(self) -> None:
        super().__init__()
        self.call.connect(lambda fn: fn(), Qt.ConnectionType.QueuedConnection)

    def post(self, fn: Callable[[], None]) -> None:
        self.call.emit(fn)


def label(text: str = "", name: str = "", wrap: bool = False, selectable: bool = False) -> QLabel:
    lab = QLabel(text)
    if name:
        lab.setObjectName(name)
    lab.setWordWrap(wrap)
    if selectable:
        lab.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.TextSelectableByKeyboard)
    return lab


def button(text: str, slot: Callable | None = None, *, kind: str = "", tip: str = "", name: str = "") -> QPushButton:
    btn = QPushButton(text)
    if kind:
        btn.setObjectName(kind)
    btn.setAccessibleName(name or text.replace("…", "").replace("&", ""))
    if tip:
        btn.setToolTip(tip)
        btn.setAccessibleDescription(tip)
    if slot:
        btn.clicked.connect(lambda _checked=False: slot())
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    return btn


def row(*items: Any, stretch: bool = True, spacing: int = 8) -> QHBoxLayout:
    lay = QHBoxLayout()
    lay.setSpacing(spacing)
    lay.setContentsMargins(0, 0, 0, 0)
    for item in items:
        if item is None:
            lay.addStretch(1)
        elif isinstance(item, QWidget):
            lay.addWidget(item)
        elif isinstance(item, int):
            lay.addSpacing(item)
        else:
            lay.addLayout(item)
    if stretch and None not in items:
        lay.addStretch(1)
    return lay


def card(*widgets: Any, title: str = "", margins: int = 16) -> QFrame:
    frame = QFrame()
    frame.setObjectName("card")
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(margins, margins - 2, margins, margins)
    lay.setSpacing(8)
    if title:
        lay.addWidget(label(title.upper(), "h3"))
    for w in widgets:
        if isinstance(w, QWidget):
            lay.addWidget(w)
        elif w is None:
            lay.addStretch(1)
        else:
            lay.addLayout(w)
    return frame


def notice(text: str) -> QLabel:
    lab = label(text, "notice", wrap=True, selectable=True)
    lab.setTextFormat(Qt.TextFormat.PlainText)
    return lab


def badge_html(visibility: str) -> str:
    bg, fg, text = theme.BADGES.get(visibility, theme.BADGES["private"])
    return (f'<span style="background:{bg}; color:{fg}; font-weight:600; font-size:8pt;">&nbsp;&nbsp;{text.upper()}'
            f'&nbsp;&nbsp;</span>')


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def human_size(n: int | float) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return ""


def short_time(iso: str | None) -> str:
    return (iso or "")[:16].replace("T", " ") if iso else "—"


# ------------------------------------------------------------------ covers
_CLOTH = ["#16213e", "#3b2d4a", "#234039", "#5a2e2a", "#2d3f5e", "#4a3b23", "#31404a", "#4b2c3f"]


def cover_pixmap(view: dict, cover: bytes | None, size: QSize = QSize(150, 222), badge: bool = True) -> QPixmap:
    """A cover thumbnail: the embedded cover if there is one, otherwise a
    typographic cloth-bound cover drawn from the title and author."""
    ratio = 2.0
    pix = QPixmap(size * ratio)
    pix.setDevicePixelRatio(ratio)
    pix.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pix)
    painter.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform
                           | QPainter.RenderHint.TextAntialiasing)
    w, h = size.width(), size.height()
    rect = QRectF(1, 1, w - 2, h - 2)
    path = QPainterPath()
    path.addRoundedRect(rect, 4, 4)
    painter.setClipPath(path)
    image = QImage.fromData(cover) if cover else QImage()
    if not image.isNull() and image.width() <= 8000 and image.height() <= 8000:
        scaled = image.scaled(size * ratio, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                              Qt.TransformationMode.SmoothTransformation)
        painter.drawImage(rect, scaled, QRectF((scaled.width() - w * ratio) / 2, (scaled.height() - h * ratio) / 2,
                                               w * ratio, h * ratio))
    else:
        seed = int(hashlib.sha256((view.get("work_id") or view.get("title", "")).encode()).hexdigest()[:6], 16)
        painter.fillRect(rect, QColor(_CLOTH[seed % len(_CLOTH)]))
        painter.fillRect(QRectF(0, 0, 9, h), QColor(0, 0, 0, 55))
        pen = QPen(QColor(theme.COPPER_SOFT))
        pen.setWidthF(1.2)
        painter.setPen(pen)
        painter.drawRect(QRectF(17, 12, w - 29, h - 24))
        painter.setPen(QColor("#f2ecdd"))
        k = w / 150.0                                   # scale type with the thumbnail
        painter.setFont(theme.serif(max(7.0, 11.5 * k), bold=False))
        painter.drawText(QRectF(24, 26, w - 44, h * 0.5), Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignHCenter
                         | Qt.AlignmentFlag.AlignTop, view.get("title", "Untitled")[:90])
        painter.setPen(QColor(theme.COPPER_SOFT))
        painter.drawLine(int(w * 0.38), int(h * 0.66), int(w * 0.66), int(h * 0.66))
        authors = ", ".join(view.get("metadata", {}).get("authors", [])[:2])
        painter.setPen(QColor("#c9cee0"))
        painter.setFont(theme.serif(max(6.0, 8.5 * k), italic=True))
        painter.drawText(QRectF(24, h * 0.69, w - 44, h * 0.16), Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignHCenter,
                         authors[:60])
        painter.setFont(QFont(theme.sans_family(), 7))
        painter.setPen(QColor("#8f98b8"))
        painter.drawText(QRectF(24, h - 30, w - 44, 14), Qt.AlignmentFlag.AlignHCenter, view.get("format", "").upper())
    if badge:
        bg, fg, text = theme.BADGES.get(view.get("visibility", "private"), theme.BADGES["private"])
        font = QFont(theme.sans_family(), 6.5)
        font.setBold(True)
        painter.setFont(font)
        tw = painter.fontMetrics().horizontalAdvance(text.upper()) + 12
        chip = QRectF(w - tw - 7, 7, tw, 15)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(bg))
        painter.drawRoundedRect(chip, 7, 7)
        painter.setPen(QColor(fg))
        painter.drawText(chip, Qt.AlignmentFlag.AlignCenter, text.upper())
        if view.get("availability") != "local":
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(0, 0, 0, 150))
            painter.drawRect(QRectF(0, h - 20, w, 20))
            painter.setPen(QColor("#f2ecdd"))
            painter.drawText(QRectF(0, h - 20, w, 20), Qt.AlignmentFlag.AlignCenter,
                             "FROM PEER" if view.get("availability") == "peer" else "UNAVAILABLE")
    painter.end()
    return pix


# ------------------------------------------------------------------ tables
def make_table(headers: list[str], *, stretch: int = 0) -> QTableWidget:
    table = QTableWidget(0, len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.verticalHeader().setVisible(False)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    table.setAlternatingRowColors(True)
    table.setShowGrid(False)
    table.verticalHeader().setDefaultSectionSize(30)
    header = table.horizontalHeader()
    header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    header.setSectionResizeMode(stretch, QHeaderView.ResizeMode.Stretch)
    header.setHighlightSections(False)
    table.setTabKeyNavigation(False)
    return table


def fill_table(table: QTableWidget, rows: Iterable[tuple[Any, list[Any]]]) -> None:
    """``rows`` yields ``(payload, [cell values])``; the payload is stored on
    the first cell and returned by :func:`selected_payload`."""
    current = selected_payload(table)
    table.setRowCount(0)
    for payload, cells in rows:
        r = table.rowCount()
        table.insertRow(r)
        for c, value in enumerate(cells):
            if isinstance(value, QWidget):
                table.setCellWidget(r, c, value)
                item = QTableWidgetItem("")
            else:
                item = QTableWidgetItem(str(value if value is not None else ""))
                item.setToolTip(str(value if value is not None else ""))
            if c == 0:
                item.setData(Qt.ItemDataRole.UserRole, payload)
            table.setItem(r, c, item)
        if current is not None and payload == current:
            table.selectRow(r)


def selected_payload(table: QTableWidget) -> Any:
    items = table.selectedItems()
    if not items:
        return None
    return table.item(items[0].row(), 0).data(Qt.ItemDataRole.UserRole)


# ----------------------------------------------------------------- dialogs
def form_dialog(parent: QWidget, title: str, fields: list[tuple], *, intro: str = "", ok_text: str = "OK") -> dict | None:
    """Small generic form.  ``fields``: ``(key, label, kind, default[, options])``
    with kind in text | multiline | password | choice | check | int."""
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.setMinimumWidth(480)
    lay = QVBoxLayout(dlg)
    lay.setSpacing(12)
    if intro:
        lay.addWidget(notice(intro))
    form = QFormLayout()
    form.setSpacing(10)
    widgets: dict[str, QWidget] = {}
    for key, text, kind, default, *rest in fields:
        if kind == "multiline":
            w: QWidget = QPlainTextEdit(str(default or ""))
            w.setFixedHeight(84)
            w.setTabChangesFocus(True)
        elif kind == "choice":
            w = QComboBox()
            for option in rest[0]:
                value, shown = option if isinstance(option, tuple) else (option, option)
                w.addItem(str(shown), value)
            index = w.findData(default)
            w.setCurrentIndex(max(0, index))
        elif kind == "check":
            w = QCheckBox(text)
            w.setChecked(bool(default))
        elif kind == "int":
            w = QSpinBox()
            w.setRange(0, 2_000_000_000)
            w.setValue(int(default or 0))
        else:
            w = QLineEdit(str(default or ""))
            if kind == "password":
                w.setEchoMode(QLineEdit.EchoMode.Password)
        w.setAccessibleName(text)
        widgets[key] = w
        form.addRow("" if kind == "check" else text, w)
    lay.addLayout(form)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
    ok = buttons.addButton(ok_text, QDialogButtonBox.ButtonRole.AcceptRole)
    ok.setObjectName("primary")
    buttons.accepted.connect(dlg.accept)
    buttons.rejected.connect(dlg.reject)
    lay.addWidget(buttons)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return None
    out: dict[str, Any] = {}
    for key, w in widgets.items():
        if isinstance(w, QPlainTextEdit):
            out[key] = w.toPlainText().strip()
        elif isinstance(w, QComboBox):
            out[key] = w.currentData()
        elif isinstance(w, QCheckBox):
            out[key] = w.isChecked()
        elif isinstance(w, QSpinBox):
            out[key] = w.value()
        else:
            out[key] = w.text().strip() if not w.echoMode() == QLineEdit.EchoMode.Password else w.text()
    return out


def review_dialog(parent: QWidget, title: str, body_html: str, *, ok_text: str = "Continue", confirm: str = "",
                  cancel_text: str = "Cancel", width: int = 640, height: int = 560, danger: bool = False) -> bool:
    """Shows a document the user must read (a preview, a notice) and returns
    True only if they explicitly proceed — optionally after ticking a box."""
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.resize(width, height)
    lay = QVBoxLayout(dlg)
    view = QTextBrowser()
    view.setOpenLinks(False)
    view.setHtml(body_html)
    view.setAccessibleName(title)
    lay.addWidget(view, 1)
    box = None
    if confirm:
        box = QCheckBox(confirm)
        lay.addWidget(box)
    buttons = QDialogButtonBox()
    cancel = buttons.addButton(cancel_text, QDialogButtonBox.ButtonRole.RejectRole)
    ok = buttons.addButton(ok_text, QDialogButtonBox.ButtonRole.AcceptRole) if ok_text else None
    if ok:
        ok.setObjectName("danger" if danger else "primary")
        if box is not None:
            ok.setEnabled(False)
            box.toggled.connect(ok.setEnabled)
    cancel.setDefault(True)
    buttons.accepted.connect(dlg.accept)
    buttons.rejected.connect(dlg.reject)
    lay.addWidget(buttons)
    return dlg.exec() == QDialog.DialogCode.Accepted


def bullet_list(items: Iterable[Any]) -> str:
    return "<ul>" + "".join(f"<li>{esc(i)}</li>" for i in items) + "</ul>"


class Page(QWidget):
    """Base class for the main pages."""

    title = ""
    topics: tuple[str, ...] = ()        # event topics that should refresh this page

    def __init__(self, window) -> None:
        super().__init__()
        self.setObjectName("page")
        self.window_ = window
        self.ctx = window.ctx
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(26, 18, 26, 20)
        self.body.setSpacing(12)

    def refresh(self) -> None:  # pragma: no cover - overridden
        pass
