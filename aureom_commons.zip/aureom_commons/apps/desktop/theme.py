"""Visual identity: midnight-blue navigation, warm ivory reading surfaces,
muted copper accents, serif titles and sans-serif controls."""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase

MIDNIGHT, MIDNIGHT_DEEP, COPPER, COPPER_SOFT, IVORY = "#16213e", "#0f1830", "#b07047", "#c98f69", "#f7f1e3"

PALETTES = {
    "light": {
        "bg": "#f3ecdc", "surface": "#fbf7ee", "surface2": "#efe7d5", "text": "#2a2520", "muted": "#756b5e",
        "border": "#ddd2bb", "accent": COPPER, "accent_text": "#ffffff", "nav": MIDNIGHT, "nav_text": "#d9dceb",
        "nav_active": "#243357", "field": "#fffdf7", "select": "#ead9c6", "danger": "#a4443a", "ok": "#4f7a5b",
    },
    "dark": {
        "bg": "#141925", "surface": "#1c2233", "surface2": "#232b40", "text": "#e6dfcf", "muted": "#9c9685",
        "border": "#333d57", "accent": COPPER_SOFT, "accent_text": "#141925", "nav": MIDNIGHT_DEEP, "nav_text": "#c9cee0",
        "nav_active": "#243357", "field": "#161c2b", "select": "#3a3148", "danger": "#d98277", "ok": "#8fbf9c",
    },
}
READING = {
    "light": {"bg": IVORY, "text": "#2b2620", "link": "#8a4f2a", "muted": "#7a7061"},
    "sepia": {"bg": "#ecdfc4", "text": "#3b2f20", "link": "#7d4a22", "muted": "#7b6a52"},
    "dark": {"bg": "#171b26", "text": "#d8d0bd", "link": "#d9a27e", "muted": "#8d8777"},
}
BADGES = {
    "private": ("#4a5578", "#ffffff", "Private"), "shared": (COPPER, "#ffffff", "Shared"),
    "public": ("#4f7a5b", "#ffffff", "Public"),
}
AVAILABILITY = {"local": "On this device", "peer": "Available from an authorised peer", "unavailable": "Currently unavailable"}
HIGHLIGHT = {"copper": "#e9b999", "gold": "#f0d98a", "sage": "#b9d3b0", "sky": "#aecde6", "rose": "#e8b4bd"}

_SERIF = ["Iowan Old Style", "Palatino Linotype", "Palatino", "Book Antiqua", "Georgia", "Charter", "Bitstream Charter",
          "Liberation Serif", "DejaVu Serif", "Times New Roman"]
_SANS = ["Inter", "Segoe UI", "Helvetica Neue", "Noto Sans", "Liberation Sans", "DejaVu Sans", "Arial"]


def _pick(candidates: list[str], fallback: str) -> str:
    available = set(QFontDatabase.families())
    return next((name for name in candidates if name in available), fallback)


def serif_family() -> str:
    return _pick(_SERIF, "serif")


def sans_family() -> str:
    return _pick(_SANS, "sans-serif")


def serif(points: float, bold: bool = False, italic: bool = False) -> QFont:
    font = QFont(serif_family())
    font.setPointSizeF(points)
    font.setBold(bold)
    font.setItalic(italic)
    return font


def colour(theme: str, key: str) -> QColor:
    return QColor(PALETTES.get(theme, PALETTES["light"])[key])


def stylesheet(theme: str, scale: int) -> str:
    p = PALETTES.get(theme, PALETTES["light"])
    base = 10.0 * scale / 100.0
    return f"""
* {{ font-family: "{sans_family()}"; font-size: {base:.1f}pt; color: {p['text']}; }}
QMainWindow, QDialog, #page {{ background: {p['bg']}; }}
QToolTip {{ background: {p['nav']}; color: #f2ecdd; border: 1px solid {p['accent']}; padding: 5px; }}
#nav {{ background: {p['nav']}; }}
#nav QLabel {{ color: {p['nav_text']}; }}
#wordmark {{ color: #f2ecdd; font-family: "{serif_family()}"; font-size: {base * 1.55:.1f}pt; letter-spacing: 2px;
            padding: 20px 18px 2px 18px; background: transparent; border: none; text-align: left; }}
#wordmark:hover, #wordmark:focus {{ color: {COPPER_SOFT}; }}
#tagline {{ color: #8f98b8; font-size: {base * 0.82:.1f}pt; padding: 0 18px 16px 19px; }}
#navbutton {{ color: {p['nav_text']}; background: transparent; border: none; border-left: 3px solid transparent;
             text-align: left; padding: 10px 18px; font-size: {base * 1.05:.1f}pt; }}
#navbutton:hover {{ background: #1d2a4c; }}
#navbutton:checked {{ background: {p['nav_active']}; border-left: 3px solid {COPPER_SOFT}; color: #ffffff; }}
#navbutton:focus {{ border-left: 3px solid {COPPER}; background: #1d2a4c; }}
#navfoot {{ color: #7f88a8; font-size: {base * 0.8:.1f}pt; padding: 12px 18px; }}
#topbar {{ background: {p['surface']}; border-bottom: 1px solid {p['border']}; }}
#pagetitle {{ font-family: "{serif_family()}"; font-size: {base * 1.9:.1f}pt; color: {p['text']}; }}
#h2 {{ font-family: "{serif_family()}"; font-size: {base * 1.35:.1f}pt; }}
#h3 {{ font-weight: 600; font-size: {base * 0.86:.1f}pt; color: {p['muted']}; letter-spacing: 1px; }}
#muted {{ color: {p['muted']}; }}
#notice {{ background: {p['surface2']}; border-left: 3px solid {p['accent']}; padding: 9px 12px; color: {p['text']}; }}
#card {{ background: {p['surface']}; border: 1px solid {p['border']}; border-radius: 8px; }}
#status {{ border-radius: 12px; padding: 4px 12px; font-weight: 600; border: 1px solid {p['border']}; background: {p['surface2']}; }}
#status[mode="direct"] {{ color: {p['ok']}; }}
#status[mode="relay"] {{ color: {p['accent']}; }}
#status[mode="offline"] {{ color: {p['muted']}; }}
QPushButton {{ background: {p['surface']}; border: 1px solid {p['border']}; border-radius: 5px; padding: 6px 13px; }}
QPushButton:hover {{ border-color: {p['accent']}; }}
QPushButton:focus {{ border: 2px solid {p['accent']}; padding: 5px 12px; }}
QPushButton:disabled {{ color: {p['muted']}; background: {p['surface2']}; }}
QPushButton#primary {{ background: {p['accent']}; color: {p['accent_text']}; border-color: {p['accent']}; font-weight: 600; }}
QPushButton#danger {{ color: {p['danger']}; border-color: {p['danger']}; }}
QPushButton#link {{ border: none; background: transparent; color: {p['accent']}; padding: 2px 4px; text-align: left; }}
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {{ background: {p['field']};
    border: 1px solid {p['border']}; border-radius: 5px; padding: 5px 8px; selection-background-color: {p['accent']};
    selection-color: {p['accent_text']}; }}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus {{ border: 2px solid {p['accent']}; }}
QComboBox QAbstractItemView {{ background: {p['field']}; selection-background-color: {p['select']}; selection-color: {p['text']}; }}
QListWidget, QTableWidget, QTreeWidget, QTextBrowser {{ background: {p['surface']}; border: 1px solid {p['border']};
    border-radius: 6px; alternate-background-color: {p['surface2']}; outline: none; }}
QListWidget::item {{ padding: 4px; }}
QListWidget::item:selected, QTableWidget::item:selected, QTreeWidget::item:selected {{ background: {p['select']}; color: {p['text']}; }}
QListWidget:focus, QTableWidget:focus {{ border: 1px solid {p['accent']}; }}
QHeaderView::section {{ background: {p['surface2']}; color: {p['muted']}; border: none; border-bottom: 1px solid {p['border']};
    padding: 6px 8px; font-weight: 600; }}
QTableWidget {{ gridline-color: transparent; }}
QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: transparent; padding: 8px 14px; border-bottom: 2px solid transparent; color: {p['muted']}; }}
QTabBar::tab:selected {{ color: {p['text']}; border-bottom: 2px solid {p['accent']}; }}
QTabBar::tab:focus {{ color: {p['accent']}; }}
QProgressBar {{ border: 1px solid {p['border']}; border-radius: 4px; background: {p['surface2']}; text-align: center; height: 14px; }}
QProgressBar::chunk {{ background: {p['accent']}; border-radius: 3px; }}
QCheckBox::indicator, QRadioButton::indicator {{ width: 15px; height: 15px; }}
QScrollBar:vertical {{ background: transparent; width: 11px; }}
QScrollBar::handle:vertical {{ background: {p['border']}; border-radius: 5px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 11px; }}
QScrollBar::handle:horizontal {{ background: {p['border']}; border-radius: 5px; min-width: 30px; }}
QSplitter::handle {{ background: {p['border']}; width: 1px; height: 1px; }}
QScrollArea {{ border: none; background: transparent; }}
#toast {{ background: {p['nav']}; color: #f2ecdd; border-radius: 6px; padding: 10px 16px; }}
#toast[error="true"] {{ background: {p['danger']}; color: #ffffff; }}
QMenu {{ background: {p['surface']}; border: 1px solid {p['border']}; }}
QMenu::item:selected {{ background: {p['select']}; }}
"""
