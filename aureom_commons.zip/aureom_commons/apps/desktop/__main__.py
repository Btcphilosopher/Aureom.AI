"""Aureom Commons desktop application.

    aureom-commons [--profile NAME | --profile-dir PATH]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication, QInputDialog, QLineEdit, QMessageBox

from aureom.domain.errors import CommonsError
from aureom.node import Profile, profiles_root, setup_logging

from . import theme
from .widgets import form_dialog


def open_profile(root: Path):
    """Create the profile on first run; ask for the passphrase if encrypted."""
    info = Profile.info(root)
    if info is None:
        answers = form_dialog(None, "Welcome to Aureom Commons", [
            ("device_name", "Name for this device", "text", "My device"),
            ("account_name", "Your name (shown to people you share with)", "text", ""),
            ("passphrase", "Library passphrase (optional)", "password", ""),
            ("repeat", "Repeat passphrase", "password", ""),
        ], intro=(f"A new private library will be created in:\n{root}\n\n"
                  "With a passphrase, the catalogue, search index, annotations, covers, managed files and keys are "
                  "encrypted at rest and unreadable while the library is locked. The passphrase cannot be recovered "
                  "if you forget it. Without one, the library relies on your operating-system account and disk "
                  "encryption. Names are labels only — they never prove identity."), ok_text="Create library")
        if answers is None:
            return None
        if answers["passphrase"] != answers["repeat"]:
            QMessageBox.warning(None, "Aureom Commons", "The two passphrases do not match.")
            return open_profile(root)
        try:
            return Profile.create(root, device_name=answers["device_name"] or "My device",
                                  account_name=answers["account_name"], passphrase=answers["passphrase"] or None)
        except CommonsError as exc:
            QMessageBox.warning(None, "Aureom Commons", str(exc))
            return open_profile(root)
    if not info.get("encrypted"):
        return Profile.open(root)
    while True:
        passphrase, ok = QInputDialog.getText(None, "Unlock library", f"Passphrase for the library in\n{root}",
                                              QLineEdit.EchoMode.Password)
        if not ok:
            return None
        try:
            return Profile.open(root, passphrase)
        except CommonsError as exc:
            QMessageBox.warning(None, "Aureom Commons", str(exc))


def main(argv: list[str] | None = None) -> int:
    raw = sys.argv[1:] if argv is None else argv
    if raw[:1] == ["--aureom-extract-worker"]:      # isolated extraction worker inside a packaged build
        from aureom.readers import extract_worker

        sys.argv = [sys.argv[0], *raw[1:]]
        extract_worker.main()
        return 0
    parser = argparse.ArgumentParser(prog="aureom-commons", description="Private library and peer publishing.")
    parser.add_argument("--profile", default="default", help="named profile (separate library, keys and ports)")
    parser.add_argument("--profile-dir", help="explicit profile folder")
    args, qt_args = parser.parse_known_args(argv)
    app = QApplication([sys.argv[0], *qt_args])
    app.setApplicationName("Aureom Commons")
    app.setStyleSheet(theme.stylesheet("light", 100))
    root = Path(args.profile_dir) if args.profile_dir else profiles_root() / args.profile
    ctx = open_profile(root)
    if ctx is None:
        return 0
    setup_logging(ctx.path / "desktop.log")
    ctx.node.start_background()
    from .main_window import MainWindow

    window = MainWindow(ctx)
    window.setWindowTitle(f"Aureom Commons — {ctx.identity.device_name}")
    window.show()
    code = app.exec()
    ctx.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
