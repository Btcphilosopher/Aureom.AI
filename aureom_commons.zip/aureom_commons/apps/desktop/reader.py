"""Reading Room: EPUB, text, Markdown, PDF, images and audio, with
bookmarks, highlights, notes and reading progress.

Rendered documents are untrusted.  HTML is sanitised before display, the
text view can load nothing except images from inside the same book, links
never open without confirmation, and no document script is ever executed.
Everything here works with networking switched off.
"""
from __future__ import annotations

import io

from PySide6.QtCore import QPointF, QUrl, Qt
from PySide6.QtGui import QColor, QDesktopServices, QImage, QImageReader, QPainter, QPixmap, QTextCharFormat, QTextCursor, QTextDocument
from PySide6.QtWidgets import (QComboBox, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QScrollArea,
                               QSlider, QSplitter, QStackedWidget, QTextBrowser, QTextEdit, QVBoxLayout, QWidget)

from aureom.annotations.service import norm
from aureom.domain.errors import CommonsError
from aureom.readers.epub import EpubBook, decode
from aureom.readers.htmltext import (EXTERNAL_LINK, INTERNAL_LINK, RESOURCE, html_to_text, markdown_to_html,
                                     parse_internal_url, sanitize_html, sanitize_svg, text_to_html)

from . import theme
from .widgets import Page, button, esc, form_dialog, label, notice, review_dialog, row

MAX_TEXT_BYTES = 64 * 1024 * 1024
MAX_IMAGE_DIM = 12000


class SafeBrowser(QTextBrowser):
    """A text view that can load exactly one kind of resource: images that
    live inside the open book.  No network, no ``file:`` URLs, no scripts."""

    def __init__(self) -> None:
        super().__init__()
        self.book: EpubBook | None = None
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setAccessibleName("Document text")

    def loadResource(self, kind: int, url: QUrl):
        if self.book is not None and url.scheme() == RESOURCE:
            _scheme, target, _frag = parse_internal_url(url.toString())
            try:
                image = QImage.fromData(self.book.read(target, 16 * 1024 * 1024))
                if not image.isNull() and max(image.width(), image.height()) <= MAX_IMAGE_DIM:
                    if image.width() > 640:
                        image = image.scaledToWidth(640, Qt.TransformationMode.SmoothTransformation)
                    return image
            except Exception:
                pass
        return None          # everything else is refused


class ReaderPage(Page):
    topics = ("annotations",)

    def __init__(self, window) -> None:
        super().__init__(window)
        self.edition: dict | None = None
        self.file: dict | None = None
        self.book: EpubBook | None = None
        self.sections: list[tuple[str, str]] = []       # (label, href-or-empty)
        self.section = 0
        self.kind = ""
        self.pdf = None
        self.player = None
        self.reading_theme = "light"
        self.font_pt = 12.5

        self.heading = label("Reading Room", "h2")
        self.sub = label("Open a work from the Library to begin. Reading works offline.", "muted")
        self.body.addWidget(self.heading)
        self.body.addWidget(self.sub)
        bar = row(button("◂ Previous", lambda: self.step(-1), tip="Previous section or page (Alt+Left)"),
                  button("Next ▸", lambda: self.step(1), tip="Next section or page (Alt+Right)"), stretch=False)
        self.find = QLineEdit()
        self.find.setPlaceholderText("Find in this document…")
        self.find.setAccessibleName("Find in document")
        self.find.setFixedWidth(210)
        self.find.returnPressed.connect(lambda: self.window_.safe(self.find_next))
        bar.addWidget(self.find)
        bar.addStretch(1)
        for text, slot, tip in (("Bookmark", self.add_bookmark, "Bookmark this position"),
                                ("Highlight", self.add_highlight, "Highlight the selected text"),
                                ("Note", self.add_note, "Attach a private note to the selection or position")):
            bar.addWidget(button(text, lambda s=slot: self.window_.safe(s), tip=tip))
        bar.addWidget(button("A−", lambda: self.resize_text(-1), name="Smaller reading text"))
        bar.addWidget(button("A+", lambda: self.resize_text(1), name="Larger reading text"))
        self.theme_box = QComboBox()
        self.theme_box.setAccessibleName("Reading theme")
        for key, text in (("light", "Ivory"), ("sepia", "Sepia"), ("dark", "Night")):
            self.theme_box.addItem(text, key)
        self.theme_box.currentIndexChanged.connect(lambda _i: self.set_reading_theme(self.theme_box.currentData()))
        bar.addWidget(self.theme_box)
        self.body.addLayout(bar)

        split = QSplitter()
        self.toc = QListWidget()
        self.toc.setAccessibleName("Contents")
        self.toc.setMaximumWidth(250)
        self.toc.itemActivated.connect(lambda it: self.goto(it.data(Qt.ItemDataRole.UserRole)))
        self.toc.itemClicked.connect(lambda it: self.goto(it.data(Qt.ItemDataRole.UserRole)))
        split.addWidget(self.toc)

        self.stack = QStackedWidget()
        self.empty = QLabel("")
        self.empty.setWordWrap(True)
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setTextFormat(Qt.TextFormat.RichText)
        self.text = SafeBrowser()
        self.text.anchorClicked.connect(self.link_clicked)
        self.text.setFrameShape(QTextBrowser.Shape.NoFrame)
        self.image_area = QScrollArea()
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_area.setWidget(self.image_label)
        self.image_area.setWidgetResizable(True)
        self.audio_panel = QWidget()
        al = QVBoxLayout(self.audio_panel)
        al.addStretch(1)
        self.audio_title = label("", "h2")
        self.audio_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        al.addWidget(self.audio_title)
        self.audio_slider = QSlider(Qt.Orientation.Horizontal)
        self.audio_slider.setAccessibleName("Playback position")
        self.audio_slider.sliderMoved.connect(lambda v: self.player and self.player.setPosition(v))
        al.addWidget(self.audio_slider)
        self.audio_time = label("0:00", "muted")
        self.play_btn = button("Play", self.toggle_play, kind="primary")
        al.addLayout(row(None, self.play_btn, self.audio_time, None, stretch=False))
        al.addStretch(1)
        self.pdf_holder = QWidget()
        QVBoxLayout(self.pdf_holder).setContentsMargins(0, 0, 0, 0)
        for w in (self.empty, self.text, self.image_area, self.audio_panel, self.pdf_holder):
            self.stack.addWidget(w)
        split.addWidget(self.stack)

        side = QWidget()
        sl = QVBoxLayout(side)
        sl.setContentsMargins(10, 0, 0, 0)
        sl.addWidget(label("ANNOTATIONS", "h3"))
        self.notes = QListWidget()
        self.notes.setAccessibleName("Annotations for this edition")
        self.notes.setWordWrap(True)
        self.notes.itemActivated.connect(lambda it: self.jump_to(it.data(Qt.ItemDataRole.UserRole)))
        self.notes.itemClicked.connect(lambda it: self.jump_to(it.data(Qt.ItemDataRole.UserRole)))
        sl.addWidget(self.notes, 1)
        sl.addLayout(row(button("Edit", lambda: self.window_.safe(self.edit_note)),
                         button("Share…", lambda: self.window_.safe(self.share_note),
                                tip="Annotations are private unless you explicitly share one in a collection"),
                         button("Reviewed", lambda: self.window_.safe(self.mark_reviewed),
                                tip="Confirm that an annotation carried over from another edition is in the right place"),
                         button("Delete", lambda: self.window_.safe(self.delete_note), kind="danger")))
        self.progress_label = label("", "muted", wrap=True)
        sl.addWidget(self.progress_label)
        side.setMaximumWidth(330)
        split.addWidget(side)
        split.setSizes([210, 760, 300])
        self.body.addWidget(split, 1)
        self.show_empty("<p style='font-size:14pt'>Nothing is open.</p><p>Choose a work in the Library and press Read.</p>")

    # ------------------------------------------------------------- opening
    def show_empty(self, html: str, external: bool = False) -> None:
        self.empty.setText(html)
        self.stack.setCurrentWidget(self.empty)
        if external:
            if not hasattr(self, "_ext_btn"):
                self._ext_btn = button("Open in external application…", lambda: self.window_.safe(self.open_external))
                self.body.addWidget(self._ext_btn, 0, Qt.AlignmentFlag.AlignHCenter)
            self._ext_btn.show()
        elif hasattr(self, "_ext_btn"):
            self._ext_btn.hide()

    def close_current(self) -> None:
        self.save_progress()
        if self.book:
            self.book.close()
            self.book = None
        self.text.book = None
        if self.player:
            self.player.stop()
        if self.pdf is not None:
            self.pdf["doc"].close()
            self.pdf["view"].setParent(None)
            self.pdf = None
        if self.file and self.ctx.store.encrypted:
            self.ctx.store.wipe_views()
        self.edition = self.file = None

    def refresh(self) -> None:
        if self.edition:
            self.load_annotations()

    def open_edition(self, edition_id: str) -> None:
        self.close_current()
        view = self.ctx.catalogue.edition_view(edition_id)
        file = self.ctx.catalogue.primary_file(edition_id)
        self.heading.setText(view["title"])
        self.sub.setText(", ".join(view["metadata"]["authors"]) + (f"  ·  {view['label']}" if view["label"] else "")
                         + f"  ·  {view['format'].upper()}  ·  edition {view['edition_number']}")
        self.toc.clear()
        self.sections, self.section = [], 0
        if view["availability"] != "local":
            self.show_empty("<p style='font-size:14pt'>This work is not on this device.</p><p>" +
                            esc(theme.AVAILABILITY[view["availability"]]) + ". Download it from the Library first.</p>")
            return
        self.edition, self.file = view, file
        self.kind = view["kind"] if view["readable"] else "unsupported"
        fmt = view["format"]
        try:
            if fmt == "epub":
                self.book = EpubBook.open(io.BytesIO(self.ctx.catalogue.read_bytes(file)), self.ctx.settings.limits)
                self.text.book = self.book
                self.sections = [(s.label, s.href) for s in self.book.spine]
                self.kind = "text"
            elif fmt in ("txt", "md", "html"):
                self.sections = [(view["title"], "")]
                self.kind = "text"
            elif fmt == "pdf":
                self.open_pdf()
            elif view["kind"] == "image":
                self.open_image(fmt)
            elif view["kind"] == "audio":
                self.open_audio()
            else:
                self.kind = "unsupported"
        except CommonsError:
            raise
        except Exception as exc:
            self.kind = "unsupported"
            self.show_empty(f"<p style='font-size:14pt'>This file could not be displayed.</p><p>{esc(type(exc).__name__)}"
                            "</p><p>It may be damaged or use features the built-in reader does not support.</p>", True)
            return
        if self.kind == "unsupported":
            self.show_empty(f"<p style='font-size:14pt'>No built-in reader for {esc(fmt.upper())} files.</p>"
                            "<p>Aureom Commons keeps the file and its catalogue record, but cannot display this "
                            "format itself. Nothing is opened or executed automatically.</p>", True)
            self.load_annotations()
            return
        self.show_empty("")
        saved = (self.ctx.annotations.progress(edition_id)["this_device"] or {}).get("locator", {})
        if self.kind == "text":
            for i, (name, _href) in enumerate(self.sections):
                item = QListWidgetItem(name)
                item.setData(Qt.ItemDataRole.UserRole, i)
                self.toc.addItem(item)
            self.stack.setCurrentWidget(self.text)
            self.load_section(min(int(saved.get("section", 0)), len(self.sections) - 1), saved.get("fraction_in_section", 0.0))
        elif self.kind == "pdf" and saved.get("page"):
            self.pdf["view"].pageNavigator().jump(int(saved["page"]), QPointF(), self.pdf["view"].pageNavigator().currentZoom())
        self.load_annotations()
        self.update_progress_label()

    # ---------------------------------------------------------------- text
    def css(self) -> str:
        c = theme.READING[self.reading_theme]
        return (f"body {{ color: {c['text']}; font-family: '{theme.serif_family()}'; font-size: {self.font_pt}pt; "
                f"line-height: 150%; }} h1, h2, h3 {{ font-weight: normal; color: {c['text']}; }} "
                f"a {{ color: {c['link']}; }} blockquote {{ color: {c['muted']}; }} p {{ margin-bottom: 0.7em; }}")

    def load_section(self, index: int, fraction: float = 0.0, anchor: str = "") -> None:
        self.section = max(0, min(index, len(self.sections) - 1))
        fmt = self.edition["format"]
        if self.book:
            href = self.sections[self.section][1]
            body = sanitize_html(self.book.document(self.section), base=href, resolve=self.book.resolve)
        else:
            raw = decode(self.ctx.catalogue.read_bytes(self.file, MAX_TEXT_BYTES))
            body = markdown_to_html(raw) if fmt == "md" else sanitize_html(raw) if fmt == "html" else text_to_html(raw)
        c = theme.READING[self.reading_theme]
        self.text.setStyleSheet(f"QTextBrowser {{ background: {c['bg']}; border: none; padding: 18px 56px; }}")
        self.text.document().setDefaultStyleSheet(self.css())
        self.text.setHtml(f"<body>{body}</body>")
        self.text.document().setDocumentMargin(26)
        self.toc.setCurrentRow(self.section)
        if anchor:
            self.text.scrollToAnchor(anchor)
        else:
            bar = self.text.verticalScrollBar()
            bar.setValue(int(bar.maximum() * fraction))
        self.paint_highlights()
        self.update_progress_label()

    def goto(self, index: int) -> None:
        if self.kind == "text":
            self.save_progress()
            self.window_.safe(self.load_section, index)

    def step(self, delta: int) -> None:
        if self.kind == "text" and 0 <= self.section + delta < len(self.sections):
            self.goto(self.section + delta)
        elif self.kind == "pdf":
            nav = self.pdf["view"].pageNavigator()
            page = max(0, min(self.pdf["doc"].pageCount() - 1, nav.currentPage() + delta))
            nav.jump(page, QPointF(), nav.currentZoom())
            self.update_progress_label()

    def link_clicked(self, url: QUrl) -> None:
        scheme, target, fragment = parse_internal_url(url.toString())
        if url.toString().startswith("#"):
            self.text.scrollToAnchor(url.fragment())
        elif scheme == INTERNAL_LINK and self.book:
            for i, (_name, href) in enumerate(self.sections):
                if href == target:
                    self.save_progress()
                    self.load_section(i, anchor=fragment)
                    return
        elif scheme == EXTERNAL_LINK:
            if QMessageBox.question(self, "External link",
                                    f"This document links to an address outside your library:\n\n{target}\n\n"
                                    "Opening it uses your web browser and tells that site you visited. Open it?"
                                    ) == QMessageBox.StandardButton.Yes:
                QDesktopServices.openUrl(QUrl(target))

    def resize_text(self, delta: int) -> None:
        self.font_pt = max(8.0, min(28.0, self.font_pt + delta))
        if self.kind == "text" and self.edition:
            self.load_section(self.section, self._fraction())
        elif self.kind == "pdf":
            view = self.pdf["view"]
            view.setZoomFactor(max(0.4, min(4.0, view.zoomFactor() * (1.15 if delta > 0 else 1 / 1.15))))

    def set_reading_theme(self, name: str) -> None:
        self.reading_theme = name
        if self.kind == "text" and self.edition:
            self.load_section(self.section, self._fraction())

    def theme_changed(self) -> None:
        wanted = "dark" if self.ctx.settings.get("theme") == "dark" else "light"
        if self.reading_theme != wanted and (self.reading_theme == "dark") != (wanted == "dark"):
            self.theme_box.setCurrentIndex(self.theme_box.findData(wanted))

    def focus_find(self) -> None:
        self.find.setFocus()
        self.find.selectAll()

    def find_next(self) -> None:
        needle = self.find.text()
        if not needle or not self.edition:
            return
        if self.kind == "pdf":
            self.pdf["search"].setSearchString(needle)
            count = self.pdf["search"].rowCount(self.pdf["search"].index(0, 0).parent())
            self.window_.toast(f"{count} match(es) in this PDF." if count else "No matches in this PDF.")
            if count:
                self.pdf["view"].setCurrentSearchResultIndex(0)
            return
        if self.kind != "text" or self.text.find(needle):
            return
        for offset in range(1, len(self.sections) + 1):          # continue into later sections, then wrap
            index = (self.section + offset) % len(self.sections)
            if self.book:
                text, _ = html_to_text(self.book.document(index))
                if needle.lower() not in text.lower():
                    continue
            self.load_section(index)
            self.text.moveCursor(QTextCursor.MoveOperation.Start)
            if self.text.find(needle):
                return
        self.window_.toast(f"“{needle}” was not found in this document.")

    # ----------------------------------------------------------- other kinds
    def open_pdf(self) -> None:
        from PySide6.QtPdf import QPdfDocument, QPdfSearchModel
        from PySide6.QtPdfWidgets import QPdfView

        path = self.ctx.catalogue.content_path(self.file)
        doc = QPdfDocument(self)
        doc.load(str(path))
        if doc.pageCount() <= 0:
            raise ValueError("unreadable PDF")
        view = QPdfView(self.pdf_holder)
        view.setDocument(doc)
        view.setPageMode(QPdfView.PageMode.MultiPage)
        view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
        view.setAccessibleName("PDF pages")
        search = QPdfSearchModel(self)
        search.setDocument(doc)
        view.setSearchModel(search)
        self.pdf_holder.layout().addWidget(view)
        self.pdf = {"doc": doc, "view": view, "search": search}
        view.pageNavigator().currentPageChanged.connect(lambda _p: self.update_progress_label())
        self.kind = "pdf"
        for i in range(doc.pageCount()):
            item = QListWidgetItem(f"Page {i + 1}")
            item.setData(Qt.ItemDataRole.UserRole, i)
            self.toc.addItem(item)
        self.toc.itemClicked.connect(self._pdf_jump)
        self.stack.setCurrentWidget(self.pdf_holder)

    def _pdf_jump(self, item) -> None:
        if self.pdf:
            nav = self.pdf["view"].pageNavigator()
            nav.jump(int(item.data(Qt.ItemDataRole.UserRole)), QPointF(), nav.currentZoom())

    def open_image(self, fmt: str) -> None:
        data = self.ctx.catalogue.read_bytes(self.file, 128 * 1024 * 1024)
        if fmt == "svg":
            from PySide6.QtCore import QByteArray
            from PySide6.QtSvg import QSvgRenderer

            renderer = QSvgRenderer(QByteArray(sanitize_svg(data)))      # active and external content stripped first
            size = renderer.defaultSize()
            if not renderer.isValid() or size.width() <= 0 or max(size.width(), size.height()) > MAX_IMAGE_DIM:
                raise ValueError("unreadable SVG")
            scale = min(2.0, 1400 / max(size.width(), 1))
            image = QImage(int(size.width() * scale), int(size.height() * scale), QImage.Format.Format_ARGB32)
            image.fill(QColor("white"))
            painter = QPainter(image)
            renderer.render(painter)
            painter.end()
        else:
            from PySide6.QtCore import QBuffer, QByteArray

            buffer = QBuffer()
            buffer.setData(QByteArray(data))
            buffer.open(QBuffer.OpenModeFlag.ReadOnly)
            reader = QImageReader(buffer)
            size = reader.size()
            if not size.isValid() or max(size.width(), size.height()) > MAX_IMAGE_DIM:
                raise ValueError("image too large or unreadable")
            image = reader.read()
            if image.isNull():
                raise ValueError("unreadable image")
        self.image_label.setPixmap(QPixmap.fromImage(image))
        self.kind = "image"
        self.stack.setCurrentWidget(self.image_area)

    def open_audio(self) -> None:
        from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

        if self.player is None:
            self.player = QMediaPlayer(self)
            self._audio_out = QAudioOutput(self)
            self.player.setAudioOutput(self._audio_out)
            self.player.durationChanged.connect(lambda d: self.audio_slider.setRange(0, d))
            self.player.positionChanged.connect(self._audio_pos)
            self.player.errorOccurred.connect(lambda _e, msg: self.audio_time.setText(
                f"Audio cannot be played on this system ({msg}). Use “Export copy…” in the Library to play it elsewhere."))
        self.player.setSource(QUrl.fromLocalFile(str(self.ctx.catalogue.content_path(self.file))))
        self.audio_title.setText(self.edition["title"])
        self.play_btn.setText("Play")
        self.kind = "audio"
        self.stack.setCurrentWidget(self.audio_panel)

    def _audio_pos(self, pos: int) -> None:
        if not self.audio_slider.isSliderDown():
            self.audio_slider.setValue(pos)
        self.audio_time.setText(f"{pos // 60000}:{pos // 1000 % 60:02d} / "
                                f"{self.player.duration() // 60000}:{self.player.duration() // 1000 % 60:02d}")

    def toggle_play(self) -> None:
        from PySide6.QtMultimedia import QMediaPlayer

        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
            self.play_btn.setText("Play")
        else:
            self.player.play()
            self.play_btn.setText("Pause")

    def open_external(self) -> None:
        if not self.file:
            return
        if review_dialog(self, "Open outside Aureom Commons",
                         "<h3>Open this file in another application?</h3><p>The file will be handed to whatever "
                         "application your system associates with it. That application may run active content "
                         "(macros, scripts), contact the network, and keep its own copies.</p>"
                         + ("<p>This library is encrypted: a temporary <b>decrypted</b> copy is created for the other "
                            "application and removed when the library locks.</p>" if self.ctx.store.encrypted else "")
                         + "<p>Aureom Commons has checked only that the bytes match their content hash — not that the "
                           "file is safe.</p>", ok_text="Open externally", confirm="I understand and want to open it",
                         height=380):
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.ctx.catalogue.content_path(self.file))))

    # ------------------------------------------------------------ progress
    def _fraction(self) -> float:
        bar = self.text.verticalScrollBar()
        return bar.value() / bar.maximum() if bar.maximum() else 0.0

    def position(self) -> tuple[dict, float]:
        if self.kind == "text":
            inner = self._fraction()
            return ({"section": self.section, "fraction_in_section": inner, "label": self.sections[self.section][0]},
                    (self.section + inner) / max(1, len(self.sections)))
        if self.kind == "pdf":
            page, count = self.pdf["view"].pageNavigator().currentPage(), self.pdf["doc"].pageCount()
            return {"page": page, "label": f"Page {page + 1}"}, (page + 1) / max(1, count)
        if self.kind == "audio" and self.player:
            return ({"time": self.player.position() / 1000.0},
                    self.player.position() / self.player.duration() if self.player.duration() else 0.0)
        return {}, 1.0 if self.kind == "image" else 0.0

    def save_progress(self) -> None:
        if self.edition and self.kind in ("text", "pdf", "audio", "image"):
            locator, fraction = self.position()
            self.ctx.annotations.set_progress(self.edition["edition_id"], locator, fraction)

    def update_progress_label(self) -> None:
        if not self.edition:
            self.progress_label.setText("")
            return
        locator, fraction = self.position()
        others = [d for d in self.ctx.annotations.progress(self.edition["edition_id"])["devices"]
                  if d["device_id"] != self.ctx.identity.device_id]
        text = f"{round(fraction * 100)}% · {locator.get('label', '')}"
        for d in others[:2]:
            text += f"\nAnother of your devices is at {round(d['fraction'] * 100)}% ({d['locator'].get('label', '')})."
        self.progress_label.setText(text)

    def tick(self) -> None:
        if self.edition and self.kind == "text":
            self.update_progress_label()

    # --------------------------------------------------------- annotations
    def _selection(self) -> dict:
        locator, fraction = self.position()
        locator["fraction"] = fraction
        if self.kind == "text":
            cursor = self.text.textCursor()
            if cursor.hasSelection():
                doc = self.text.document()
                quote = norm(cursor.selectedText().replace(" ", " ").replace(" ", " "))
                start, end = cursor.selectionStart(), cursor.selectionEnd()
                before = QTextCursor(doc)
                before.setPosition(max(0, start - 60))
                before.setPosition(start, QTextCursor.MoveMode.KeepAnchor)
                after = QTextCursor(doc)
                after.setPosition(end)
                after.setPosition(min(doc.characterCount() - 1, end + 60), QTextCursor.MoveMode.KeepAnchor)
                locator.update(start=start, end=end, quote=quote[:2000],
                               prefix=norm(before.selectedText().replace(" ", " "))[-40:],
                               suffix=norm(after.selectedText().replace(" ", " "))[:40])
            else:
                locator["start"] = self.text.cursorForPosition(self.text.viewport().rect().topLeft()).position()
        return locator

    def _require_open(self) -> bool:
        if not self.edition:
            self.window_.toast("Open a work first.")
        return bool(self.edition)

    def add_bookmark(self) -> None:
        if self._require_open():
            self.ctx.annotations.create(self.edition["edition_id"], "bookmark", self._selection())
            self.load_annotations()

    def add_highlight(self) -> None:
        if not self._require_open():
            return
        locator = self._selection()
        if not locator.get("quote"):
            self.window_.toast("Select some text to highlight." if self.kind == "text"
                               else "Highlights need selectable text; use a bookmark or note for this format.")
            return
        self.ctx.annotations.create(self.edition["edition_id"], "highlight", locator)
        self.load_annotations()

    def add_note(self) -> None:
        if not self._require_open():
            return
        locator = self._selection()
        answer = form_dialog(self, "Private note", [("body", "Note", "multiline", ""),
                                                    ("colour", "Colour", "choice", "copper", list(theme.HIGHLIGHT))],
                             intro="Notes are stored separately from the document and are private unless you later "
                                   "choose to share one in a collection."
                                   + (f"\n\nAttached to: “{locator['quote'][:120]}”" if locator.get("quote") else ""))
        if answer and answer["body"]:
            self.ctx.annotations.create(self.edition["edition_id"], "note", locator, answer["body"], answer["colour"])
            self.load_annotations()

    def load_annotations(self) -> None:
        self.notes.clear()
        if not self.edition:
            return
        self._annotations = self.ctx.annotations.list(self.edition["edition_id"])
        for a in self._annotations:
            loc = a["locator"]
            where = loc.get("label") or (f"Page {loc['page'] + 1}" if "page" in loc else "")
            flags = []
            if not a["mine"]:
                flags.append(f"shared by {a['author_name'] or 'a member'}")
            elif not a["private"]:
                flags.append("shared in a collection")
            else:
                flags.append("private")
            if a["status"] != "ok":
                flags.append("NEEDS REVIEW" if a["status"] == "needs_review" else "NOT FOUND IN THIS EDITION")
            text = f"{a['kind'].upper()} · {where}\n"
            if loc.get("quote"):
                text += f"“{loc['quote'][:110]}”\n"
            if a["body"]:
                text += a["body"][:200] + "\n"
            if a["review_note"]:
                text += f"⚠ {a['review_note']}\n"
            item = QListWidgetItem(text + " · ".join(flags))
            item.setData(Qt.ItemDataRole.UserRole, a["annotation_id"])
            self.notes.addItem(item)
        self.paint_highlights()

    def _find_range(self, locator: dict) -> tuple[int, int] | None:
        quote = locator.get("quote")
        if not quote:
            return None
        doc = self.text.document()
        start, end = locator.get("start"), locator.get("end")
        if start is not None and end is not None and end <= doc.characterCount():
            cursor = QTextCursor(doc)
            cursor.setPosition(start)
            cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
            if norm(cursor.selectedText().replace(" ", " ")) == quote:
                return start, end
        probe = quote[:70]
        found = doc.find(probe, 0, QTextDocument.FindFlag.FindCaseSensitively)
        if found.isNull():
            return None
        return found.selectionStart(), min(doc.characterCount() - 1, found.selectionStart() + len(quote))

    def paint_highlights(self) -> None:
        if self.kind != "text" or not self.edition:
            return
        selections = []
        for a in getattr(self, "_annotations", []):
            loc = a["locator"]
            if a["kind"] == "bookmark" or (self.book and loc.get("section", self.section) != self.section):
                continue
            span = self._find_range(loc)
            if not span:
                continue
            sel = QTextEdit.ExtraSelection()
            sel.cursor = QTextCursor(self.text.document())
            sel.cursor.setPosition(span[0])
            sel.cursor.setPosition(span[1], QTextCursor.MoveMode.KeepAnchor)
            fmt = QTextCharFormat()
            colour = QColor(theme.HIGHLIGHT.get(a["colour"], theme.HIGHLIGHT["copper"]))
            if self.reading_theme == "dark":
                colour = colour.darker(240)
            fmt.setBackground(colour)
            if a["kind"] == "note":
                fmt.setUnderlineStyle(QTextCharFormat.UnderlineStyle.DashUnderline)
            sel.format = fmt
            selections.append(sel)
        self.text.setExtraSelections(selections)

    def _current_annotation(self) -> dict | None:
        item = self.notes.currentItem()
        return self.ctx.annotations.get(item.data(Qt.ItemDataRole.UserRole)) if item else None

    def jump_to(self, annotation_id: str) -> None:
        a = self.ctx.annotations.get(annotation_id)
        loc = a["locator"]
        if self.kind == "text":
            if self.book and "section" in loc and loc["section"] != self.section:
                self.load_section(loc["section"])
            span = self._find_range(loc)
            cursor = QTextCursor(self.text.document())
            cursor.setPosition(span[0] if span else min(loc.get("start", 0), self.text.document().characterCount() - 1))
            self.text.setTextCursor(cursor)
            self.text.ensureCursorVisible()
        elif self.kind == "pdf" and "page" in loc:
            nav = self.pdf["view"].pageNavigator()
            nav.jump(loc["page"], QPointF(), nav.currentZoom())
        elif self.kind == "audio" and "time" in loc and self.player:
            self.player.setPosition(int(loc["time"] * 1000))

    def edit_note(self) -> None:
        a = self._current_annotation()
        if a:
            answer = form_dialog(self, "Edit annotation", [("body", "Note", "multiline", a["body"]),
                                                           ("colour", "Colour", "choice", a["colour"], list(theme.HIGHLIGHT))])
            if answer:
                self.ctx.annotations.update(a["annotation_id"], body=answer["body"], colour=answer["colour"])
                self.load_annotations()

    def delete_note(self) -> None:
        a = self._current_annotation()
        if a:
            self.ctx.annotations.delete(a["annotation_id"])
            self.load_annotations()

    def mark_reviewed(self) -> None:
        a = self._current_annotation()
        if a and a["status"] != "ok":
            self.ctx.annotations.update(a["annotation_id"], status="ok")
            self.load_annotations()

    def share_note(self) -> None:
        a = self._current_annotation()
        if not a:
            return
        if a["shared_in"]:
            self.window_.run(self.ctx.node.share_annotation(a["annotation_id"], ""),
                             lambda _r: (self.load_annotations(), self.window_.toast("The annotation is private again. "
                                         "People who already received it may still have a copy.")))
            return
        options = [(c["collection_id"], c["name"]) for c in self.ctx.collections.list()
                   if c["kind"] == "shared" and self.edition["edition_id"] in self.ctx.collections.item_ids(c["collection_id"])]
        if not options:
            self.window_.toast("This work is not in a shared collection, so there is nowhere to share the annotation.")
            return
        answer = form_dialog(self, "Share this annotation", [("cid", "Collection", "choice", options[0][0], options)],
                             intro="Only this one annotation is shared. Members of the collection who may view it will "
                                   "see the quoted passage, your note and your name. Your other annotations stay private.",
                             ok_text="Share annotation")
        if answer:
            self.window_.run(self.ctx.node.share_annotation(a["annotation_id"], answer["cid"]),
                             lambda _r: (self.load_annotations(), self.window_.toast("Annotation shared in the collection.")))


__all__ = ["ReaderPage", "notice"]
