"""Collections (private sharing) and Peers (identities, pairing, public catalogues)."""
from __future__ import annotations

import io
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication, QImage, QPixmap
from PySide6.QtWidgets import (QDialog, QFileDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
                               QPlainTextEdit, QSplitter, QTabWidget, QTextBrowser, QVBoxLayout, QWidget)

from aureom.domain.models import PERMISSION_PRESETS
from aureom.domain.util import fingerprint_display
from aureom.permissions.collections import REVOCATION_NOTICE

from . import theme
from .widgets import (Page, badge_html, bullet_list, button, esc, fill_table, form_dialog, human_size, label,
                      make_table, notice, review_dialog, row, selected_payload, short_time)

PRESETS = [("catalogue-only", "Catalogue only — see titles and details, no downloads"),
           ("reader", "Reader — see the catalogue and download files"),
           ("contributor", "Contributor — also propose works and share annotations"),
           ("editor", "Editor — also edit the collection's name and description"),
           ("manager", "Manager — also manage membership")]


def show_invitation(parent, invitation, what: str) -> None:
    """Present a one-time invitation as text, a file and a QR code."""
    dlg = QDialog(parent)
    dlg.setWindowTitle("Invitation")
    dlg.setMinimumWidth(560)
    lay = QVBoxLayout(dlg)
    lay.addWidget(notice(f"{what}\n\nThis invitation can be used once and expires {invitation.expires_at[:16]}Z. Send "
                         "it over a channel you trust, then compare fingerprints with the recipient. It is not a link "
                         "to content: whoever redeems it must still authenticate with their own device key every time."))
    text = invitation.to_text()
    try:
        import segno

        buffer = io.BytesIO()
        segno.make(text, error="l").save(buffer, kind="png", scale=4, border=2)
        qr = QLabel()
        pix = QPixmap.fromImage(QImage.fromData(buffer.getvalue()))
        qr.setPixmap(pix.scaledToWidth(min(300, pix.width()), Qt.TransformationMode.FastTransformation))
        qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        qr.setAccessibleName("Invitation QR code")
        lay.addWidget(qr)
    except Exception:
        lay.addWidget(label("QR code unavailable (the optional “segno” package is not installed).", "muted"))
    box = QPlainTextEdit(text)
    box.setReadOnly(True)
    box.setFixedHeight(70)
    box.setAccessibleName("Invitation text")
    lay.addWidget(box)

    def save() -> None:
        path, _ = QFileDialog.getSaveFileName(dlg, "Save invitation", "invitation.aureom-invite",
                                              "Aureom invitation (*.aureom-invite)")
        if path:
            Path(path).write_text(invitation.to_json(), encoding="utf-8")

    lay.addLayout(row(button("Copy text", lambda: QGuiApplication.clipboard().setText(text)),
                      button("Save as file…", save), None, button("Done", dlg.accept, kind="primary"), stretch=False))
    dlg.exec()


def exposure_html(preview: dict) -> str:
    titles = "".join(f"<tr><td>{esc(t['title'])}</td><td>{esc(', '.join(t['authors']))}</td><td>{esc(t['filename'])}"
                     f"</td><td>{human_size(t['size'])}</td><td>{'file can be downloaded' if t['downloadable'] else 'title and details only'}</td></tr>"
                     for t in preview["titles"])
    return (f"<h2>What this invitation exposes</h2><p>Collection: <b>{esc(preview['collection']['name'])}</b></p>"
            f"<p><b>Permissions:</b> {esc(', '.join(preview['permissions']))}<br><b>Onward redistribution:</b> "
            f"{'allowed' if preview['redistribution'] else 'not granted (default)'}</p>"
            f"<h3>Titles and files ({len(preview['titles'])})</h3><table cellpadding='4'>{titles or '<tr><td><i>The collection is empty.</i></td></tr>'}</table>"
            f"<h3>Metadata fields shared</h3><p>{esc(', '.join(preview['metadata_fields']))}</p>"
            f"<h3>Annotations</h3><p>{preview['shared_annotations']} annotation(s) explicitly shared in this collection. "
            f"Private annotations are never included.</p>"
            f"<h3>About you</h3>{bullet_list(preview['identity_exposed'])}"
            f"<h3>Not exposed</h3>{bullet_list(preview['not_exposed'])}"
            f"<h3>Please note</h3>{bullet_list(preview['notices'])}")


class CollectionsPage(Page):
    topics = ("collections", "library", "transfers")

    def __init__(self, window) -> None:
        super().__init__(window)
        self.cid: str | None = None
        split = QSplitter()
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 12, 0)
        self.list = QListWidget()
        self.list.setAccessibleName("Collections")
        self.list.currentItemChanged.connect(lambda cur, _p: self._select(cur.data(Qt.ItemDataRole.UserRole) if cur else None))
        ll.addWidget(self.list, 1)
        ll.addLayout(row(button("New collection…", self.guard(self.create), kind="primary"),
                         button("Check for invitations", self.guard(self.check_shared),
                                tip="Ask your trusted peers whether they share any collections with you")))
        split.addWidget(left)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(12, 0, 0, 0)
        self.header = label("", wrap=True)
        self.header.setTextFormat(Qt.TextFormat.RichText)
        rl.addWidget(self.header)
        self.bar = row()
        self.btn = {}
        for key, text, slot, kind in (("accept", "Accept invitation", lambda: self.respond(True), "primary"),
                                      ("decline", "Decline", lambda: self.respond(False), ""),
                                      ("invite", "Invite…", self.invite, "primary"), ("rename", "Rename…", self.rename, ""),
                                      ("refresh", "Refresh from owner", self.refresh_owner, ""),
                                      ("delete", "Delete", self.delete, "danger")):
            self.btn[key] = button(text, self.guard(slot), kind=kind)
            self.bar.insertWidget(self.bar.count() - 1, self.btn[key])
        rl.addLayout(self.bar)
        tabs = QTabWidget()
        works = QWidget()
        wl = QVBoxLayout(works)
        self.items = make_table(["Title", "Format", "Size", "Availability", "State"])
        self.items.setAccessibleName("Works in this collection")
        self.items.itemActivated.connect(lambda _i: self.guard(self.read)())
        wl.addWidget(self.items)
        self.work_btn = {}
        wb = row()
        for key, text, slot in (("add", "Add from library…", self.add_work), ("remove", "Remove from collection", self.remove_work),
                                ("read", "Read", self.read), ("download", "Download", self.download),
                                ("propose", "Propose a work…", self.propose), ("accept_p", "Accept proposal", lambda: self.decide(True)),
                                ("reject_p", "Reject proposal", lambda: self.decide(False))):
            self.work_btn[key] = button(text, self.guard(slot))
            wb.insertWidget(wb.count() - 1, self.work_btn[key])
        wl.addLayout(wb)
        tabs.addTab(works, "Works")
        members = QWidget()
        ml = QVBoxLayout(members)
        self.members = make_table(["Member (self-declared name)", "Account fingerprint", "Permissions", "Status"])
        self.members.setAccessibleName("Members of this collection")
        ml.addWidget(self.members)
        ml.addLayout(row(button("Change permissions…", self.guard(self.change_permissions)),
                         button("Revoke access…", self.guard(self.revoke), kind="danger")))
        ml.addWidget(notice(REVOCATION_NOTICE))
        tabs.addTab(members, "Members")
        self.shared_notes = QTextBrowser()
        self.shared_notes.setAccessibleName("Annotations shared in this collection")
        tabs.addTab(self.shared_notes, "Shared annotations")
        self.tabs = tabs
        rl.addWidget(tabs, 1)
        split.addWidget(right)
        split.setSizes([300, 880])
        self.body.addWidget(split, 1)

    def guard(self, fn):
        return lambda: self.window_.safe(fn)

    # ---------------------------------------------------------------- data
    def refresh(self) -> None:
        cols = self.ctx.collections.list()
        self.list.blockSignals(True)
        self.list.clear()
        for c in cols:
            if c["is_owner"]:
                kind = "private shelf" if c["kind"] == "local" else f"shared · {c['member_count']} member(s)"
            else:
                kind = {"invited": "INVITATION from ", "revoked": "access ended · from ", "active": "shared by "}.get(
                    c["access_state"], "from ") + (c["owner_name"] or "a peer")
            item = QListWidgetItem(f"{c['name']}\n{kind} · {c['item_count']} work(s)")
            item.setData(Qt.ItemDataRole.UserRole, c["collection_id"])
            self.list.addItem(item)
            if c["collection_id"] == self.cid:
                self.list.setCurrentItem(item)
        self.list.blockSignals(False)
        if self.cid not in {c["collection_id"] for c in cols}:
            self.cid = cols[0]["collection_id"] if cols else None
            if self.cid:
                self.list.setCurrentRow(0)
        self.show_collection()

    def _select(self, cid: str | None) -> None:
        self.cid = cid
        self.window_.safe(self.show_collection)

    def show_collection(self) -> None:
        for b in list(self.btn.values()) + list(self.work_btn.values()):
            b.setVisible(False)
        if not self.cid:
            self.header.setText("<p><i>No collections yet.</i> A <b>private shelf</b> organises your own library. A "
                                "<b>shared collection</b> gives named people access to the works you put in it — "
                                "nothing is shared until you invite someone.</p>")
            fill_table(self.items, [])
            fill_table(self.members, [])
            self.shared_notes.setHtml("")
            return
        c = self.ctx.collections.get(self.cid)
        owner, perms = bool(c["is_owner"]), set(c["my_permissions"])
        state = c["access_state"]
        if owner:
            who = "You own this collection." + (" Sharing is suspended until a synchronisation conflict is reviewed."
                                               if state == "suspended" else "")
        elif state == "invited":
            who = (f"<b>{esc(c['owner_name'] or 'A peer')}</b> invites you to this collection with: "
                   f"{esc(', '.join(c['my_permissions']))}. Accepting lets their device know your account joined.")
        elif state == "revoked":
            who = ("Your access to this collection has ended. Works you already downloaded remain in your library; "
                   "nothing further can be downloaded from the owner.")
        else:
            who = (f"Shared with you by <b>{esc(c['owner_name'] or 'a peer')}</b> · your permissions: "
                   f"{esc(', '.join(c['my_permissions']))} · last confirmed with the owner {short_time(c['access_checked_at'])}. "
                   "While the owner's device is unreachable this view may be out of date.")
        self.header.setText(f"<span style='font-family:\"{theme.serif_family()}\"; font-size:16pt'>{esc(c['name'])}</span>"
                            f"&nbsp;&nbsp;{badge_html(c['visibility'])}<br>{esc(c['description'])}<br>"
                            f"<span style='color:gray'>{who}</span>")
        fill_table(self.items, ((i["edition_id"], [i["title"], i["format"].upper(), human_size(i["size"]),
                                                   theme.AVAILABILITY[i["availability"]],
                                                   "proposed — awaiting the owner" if i["item_state"] == "proposed" else "in collection"])
                                for i in c["items"]))
        fill_table(self.members, ((m["account_id"], [m["display_name"], fingerprint_display(m["account_id"][:16]),
                                                     ", ".join(m["permissions"]), m["status"]]) for m in c["members"]))
        self.tabs.setTabVisible(1, owner)
        notes = "".join(f"<p><b>{esc(a['author_name'] or 'You')}</b> · {esc(a['kind'])}<br>{esc(a['body'])}</p>"
                        for a in c["shared_annotations"])
        self.shared_notes.setHtml(notes or "<p><i>No annotations have been shared in this collection.</i> Annotations "
                                           "are private unless their author explicitly shares one from the Reading Room.</p>")
        show = {"invite": owner and c["kind"] == "shared", "rename": owner, "delete": True,
                "accept": state == "invited", "decline": state == "invited", "refresh": not owner and state != "invited"}
        for key, visible in show.items():
            self.btn[key].setVisible(visible)
        self.btn["delete"].setText("Delete" if owner else "Leave")
        active = owner or state == "active"
        wshow = {"add": owner, "remove": owner, "read": True, "download": not owner and active and "download" in perms,
                 "propose": not owner and active and "add_works" in perms, "accept_p": owner, "reject_p": owner}
        for key, visible in wshow.items():
            self.work_btn[key].setVisible(visible)

    # ------------------------------------------------------------- actions
    def create(self) -> None:
        a = form_dialog(self, "New collection", [
            ("name", "Name", "text", ""), ("description", "Description", "multiline", ""),
            ("kind", "Kind", "choice", "shared", [("shared", "Shared collection — you can invite specific people"),
                                                  ("local", "Private shelf — only for organising your own library")])],
            intro="Creating a collection shares nothing. Works become visible to other people only after you invite "
                  "them and they authenticate with their own device key.", ok_text="Create")
        if a:
            self.cid = self.ctx.collections.create(a["name"], a["description"], a["kind"])["collection_id"]
            self.refresh()

    def rename(self) -> None:
        c = self.ctx.collections.get(self.cid)
        a = form_dialog(self, "Rename collection", [("name", "Name", "text", c["name"]),
                                                    ("description", "Description", "multiline", c["description"])])
        if a:
            self.ctx.collections.update(self.cid, name=a["name"], description=a["description"])
            self.refresh()

    def delete(self) -> None:
        c = self.ctx.collections.get(self.cid)
        if c["is_owner"]:
            if review_dialog(self, "Delete collection", f"<h3>Delete “{esc(c['name'])}”?</h3><p>The works stay in your "
                             f"library. Members lose future access.</p><p>{esc(REVOCATION_NOTICE)}</p>",
                             ok_text="Delete collection", danger=True, height=320):
                self.ctx.collections.delete(self.cid)
        else:
            self.ctx.collections.leave(self.cid)
        self.cid = None
        self.refresh()

    def check_shared(self) -> None:
        self.window_.run(self.ctx.node.refresh_shared(), lambda found: (
            self.refresh(), self.window_.toast(f"{len(found)} collection(s) are shared with you by your trusted peers.")))

    def respond(self, accept: bool) -> None:
        self.window_.run(self.ctx.node.respond_invitation(self.cid, accept), lambda _r: (
            self.refresh(), self.window_.toast("You joined the collection." if accept else "Invitation declined.")))

    def refresh_owner(self) -> None:
        self.window_.run(self.ctx.node.refresh_collection(self.cid),
                         lambda _r: (self.refresh(), self.window_.toast("Collection refreshed from its owner.")),
                         lambda exc: (self.refresh(), self.window_.toast(str(exc), error=True)))

    def invite(self) -> None:
        known = {}
        for p in self.ctx.identity.peers():
            if p["state"] == "trusted" and not p["is_own_device"] and p["account_id"]:
                known.setdefault(p["account_id"], f"{p['display_name']}{'' if p['verified'] else ' (fingerprint not verified)'}")
        a = form_dialog(self, "Invite to collection", [
            ("who", "Recipient", "choice", "", [("", "Someone not paired yet — create a one-time invitation")] + list(known.items())),
            ("preset", "Permissions", "choice", "reader", PRESETS),
            ("redistribute", "Also allow them to pass these works on to others (not recommended)", "check", False)],
            intro="Next you will see exactly what this invitation exposes before anything is sent.", ok_text="Preview…")
        if not a:
            return
        perms = [p.value for p in PERMISSION_PRESETS[a["preset"]]] + (["redistribute"] if a["redistribute"] else [])
        preview = self.ctx.collections.exposure_preview(self.cid, perms)
        if not review_dialog(self, "Review before inviting", exposure_html(preview), ok_text="Create invitation",
                             confirm="I have reviewed what this invitation exposes"):
            return
        if a["who"]:
            self.ctx.collections.invite_account(self.cid, a["who"], perms, display_name=known[a["who"]].split(" (")[0])
            self.window_.toast("Invitation recorded. They will see it the next time their device contacts yours.")
        else:
            inv = self.ctx.node.create_invitation(purpose="collection", collection_id=self.cid, permissions=perms)
            show_invitation(self, inv, f"Invitation to “{preview['collection']['name']}” with: {', '.join(perms)}.")
        self.refresh()

    def _member(self) -> str | None:
        account = selected_payload(self.members)
        if not account:
            self.window_.toast("Select a member first.")
        return account

    def change_permissions(self) -> None:
        account = self._member()
        if account:
            a = form_dialog(self, "Change permissions", [("preset", "Permissions", "choice", "reader", PRESETS)])
            if a:
                self.ctx.collections.set_permissions(self.cid, account, a["preset"])
                self.refresh()

    def revoke(self) -> None:
        account = self._member()
        if account and review_dialog(self, "Revoke access", f"<h3>Revoke this member's access?</h3><p>{esc(REVOCATION_NOTICE)}</p>"
                                     "<p>There is no reliable “view only” for shared files: assume anything they could "
                                     "download, they may have kept.</p>", ok_text="Revoke future access", danger=True, height=330):
            result = self.ctx.collections.revoke(self.cid, account)
            self.refresh()
            self.window_.toast(result["notice"])

    def _work(self) -> str | None:
        eid = selected_payload(self.items)
        if not eid:
            self.window_.toast("Select a work first.")
        return eid

    def add_work(self) -> None:
        present = set(self.ctx.collections.item_ids(self.cid, ("active", "proposed")))
        options = [(v["edition_id"], f"{v['title']} — {v['format'].upper()}") for v in self.ctx.catalogue.list()
                   if v["edition_id"] not in present and v["availability"] == "local"]
        if not options:
            self.window_.toast("Every work in your library is already in this collection.")
            return
        a = form_dialog(self, "Add a work", [("eid", "Work", "choice", options[0][0], options)],
                        intro="Members who may download will be able to fetch this file from your device.", ok_text="Add")
        if a:
            self.ctx.collections.add_item(self.cid, a["eid"])
            self.refresh()

    def remove_work(self) -> None:
        eid = self._work()
        if eid:
            self.ctx.collections.remove_item(self.cid, eid)
            self.refresh()

    def read(self) -> None:
        eid = self._work()
        if eid:
            self.window_.open_reader(eid)

    def download(self) -> None:
        eid = self._work()
        if eid:
            self.ctx.node.download_edition(eid)
            self.window_.toast("Download queued; see Transfers.")

    def propose(self) -> None:
        options = [(v["edition_id"], v["title"]) for v in self.ctx.catalogue.list(space="private") if v["availability"] == "local"]
        if not options:
            self.window_.toast("You have no private works on this device to propose.")
            return
        a = form_dialog(self, "Propose a work", [("eid", "Work", "choice", options[0][0], options)],
                        intro="The owner is asked whether to add this work. Its title and details are sent now; the "
                              "file is only transferred if the owner accepts.", ok_text="Send proposal")
        if a:
            self.window_.run(self.ctx.node.propose_item(self.cid, a["eid"]),
                             lambda _r: (self.refresh(), self.window_.toast("Proposal sent to the collection's owner.")))

    def decide(self, accept: bool) -> None:
        eid = self._work()
        if not eid:
            return
        if accept:
            self.ctx.node.accept_proposal(self.cid, eid)
            self.window_.toast("Proposal accepted; the file is being fetched from the member's device.")
        else:
            self.ctx.node.reject_proposal(self.cid, eid)
        self.refresh()


class PeersPage(Page):
    topics = ("peers", "network", "public")

    def __init__(self, window) -> None:
        super().__init__(window)
        tabs = QTabWidget()
        g = lambda fn: (lambda: self.window_.safe(fn))  # noqa: E731

        me = QWidget()
        ml = QVBoxLayout(me)
        self.me = QTextBrowser()
        self.me.setAccessibleName("This device's identity")
        ml.addWidget(self.me, 1)
        ml.addLayout(row(button("New pairing invitation…", g(lambda: self.new_invitation("pair")), kind="primary"),
                         button("Link another of my devices…", g(lambda: self.new_invitation("link-device"))),
                         button("Accept an invitation…", g(self.accept_invitation)),
                         button("Rotate device key…", g(self.rotate))))
        tabs.addTab(me, "This device")

        trusted = QWidget()
        tl = QVBoxLayout(trusted)
        tl.addWidget(notice("Names are chosen by each device's owner and prove nothing. A device is identified by its "
                            "fingerprint; “verified” means you compared that fingerprint with its owner yourself."))
        self.peers = make_table(["Name (self-declared)", "Fingerprint", "Verified", "Kind", "State", "Last seen", "Path", "Limit"])
        self.peers.setAccessibleName("Trusted devices")
        tl.addWidget(self.peers, 1)
        tl.addLayout(row(button("Verify fingerprint…", g(self.verify)), button("Rename / addresses / limit…", g(self.edit_peer)),
                         button("Sync now", g(self.sync), tip="Synchronise catalogue records, collections, reading progress "
                                                              "and annotations with one of your own linked devices"),
                         button("Remove device", g(lambda: self.set_state("removed"))),
                         button("Block", g(lambda: self.set_state("blocked")), kind="danger")))
        tabs.addTab(trusted, "Trusted devices")

        public = QWidget()
        pl = QVBoxLayout(public)
        self.address = QLineEdit()
        self.address.setPlaceholderText("host:port of a peer's device")
        self.address.setAccessibleName("Public catalogue address")
        self.expected = QLineEdit()
        self.expected.setPlaceholderText("expected device fingerprint (optional, recommended)")
        self.expected.setAccessibleName("Expected device fingerprint")
        pl.addLayout(row(self.address, self.expected, button("Browse catalogue", g(self.fetch_public), kind="primary"),
                         button("Search index", g(self.search_index), tip="Search the optional rendezvous catalogue, if configured"),
                         stretch=False))
        split = QSplitter(Qt.Orientation.Vertical)
        self.pubs = make_table(["Title", "Edition", "Publisher (self-declared)", "Signature", "Availability", "Source"])
        self.pubs.setAccessibleName("Public editions found")
        self.pubs.itemSelectionChanged.connect(lambda: self.window_.safe(self.show_publication))
        split.addWidget(self.pubs)
        self.pub_detail = QTextBrowser()
        self.pub_detail.setAccessibleName("What was checked about the selected publication")
        split.addWidget(self.pub_detail)
        pl.addWidget(split, 1)
        pl.addLayout(row(button("Download", g(self.download_public), kind="primary"),
                         button("Remember publisher key", g(self.pin_publisher)),
                         button("Mirror on/off", g(self.mirror), tip="Opt in to re-serving this signed edition from your device"),
                         button("Report to index operator…", g(self.report))))
        tabs.addTab(public, "Public catalogues")

        lan = QWidget()
        nl = QVBoxLayout(lan)
        self.lan_note = notice("")
        nl.addWidget(self.lan_note)
        self.lan = make_table(["Announced name (unverified)", "Fingerprint", "Address", "Paired"])
        self.lan.setAccessibleName("Devices seen on the local network")
        nl.addWidget(self.lan, 1)
        tabs.addTab(lan, "Local network")
        self.body.addWidget(tabs)

    def tick(self) -> None:
        if self.ctx.node.discovery:
            self._fill_lan()

    def refresh(self) -> None:
        d, s = self.ctx.identity.describe(), self.ctx.node.status()
        self.me.setHtml(
            f"<h2 style='font-family:\"{theme.serif_family()}\"; font-weight:normal'>{esc(d['device_name'])}</h2>"
            f"<table cellpadding='5'><tr><td style='color:gray'>Device fingerprint</td><td><code>{d['device_fingerprint']}</code></td></tr>"
            f"<tr><td style='color:gray'>Account</td><td>{esc(d['account_name'] or '(no name set)')}</td></tr>"
            f"<tr><td style='color:gray'>Account fingerprint</td><td><code>{d['account_fingerprint']}</code></td></tr>"
            f"<tr><td style='color:gray'>Key storage</td><td>{esc(d['secret_storage_note'])}</td></tr>"
            f"<tr><td style='color:gray'>Network</td><td><b>{esc(s['label'])}</b> — {esc(s['detail'])}</td></tr></table>"
            "<p>Your <b>device key</b> authenticates this installation to peers. Your <b>account key</b> represents "
            "you across devices and is what collection owners grant permissions to. <b>Publisher keys</b> (Publish "
            "page) are separate again. All of them are self-issued: they prove possession of a key, never a legal "
            "identity.</p><p>To pair, exchange a one-time invitation and then read the device fingerprint to each "
            "other over a channel you trust.</p>"
            + ("<p><b>Key rotation in progress:</b> peers that have not yet been told still use your previous key.</p>"
               if d["rotation_pending"] else ""))
        fill_table(self.peers, ((p["device_id"], [
            p["display_name"], fingerprint_display(p["device_id"][:20]) + "…", "✓ verified" if p["verified"] else "not verified",
            "your own device" if p["is_own_device"] else "peer", p["state"], short_time(p["last_seen"]), p["last_path"] or "—",
            f"{p['bandwidth_kbps']} kbps" if p["bandwidth_kbps"] else "none"]) for p in self.ctx.identity.peers()))
        self._fill_pubs()
        self._fill_lan()

    def _fill_lan(self) -> None:
        on = bool(self.ctx.node.discovery)
        self.lan_note.setText("Local-network discovery is on. Devices listed here announced themselves on your network; "
                              "the announcements are not authenticated and listing a device grants it nothing. Pair with "
                              "an invitation and compare fingerprints as usual." if on else
                              "Local-network discovery is off (the default). Turn it on in Settings → Network to see "
                              "other Aureom Commons devices on your network and to let them see this device's fingerprint.")
        fill_table(self.lan, ((d["device_id"], [d["name"] or "—", fingerprint_display(d["device_id"][:20]) + "…",
                                                d["address"], "yes" if d["paired"] else "no"]) for d in self.ctx.node.discovered()))

    # ------------------------------------------------------------- pairing
    def new_invitation(self, purpose: str) -> None:
        inv = self.ctx.node.create_invitation(purpose=purpose)
        show_invitation(self, inv, "Pairing invitation." if purpose == "pair" else
                        "Device-link invitation. Whoever redeems this becomes one of YOUR devices: it receives your "
                        "account key and can synchronise your whole catalogue. Only use it on a device you control.")

    def accept_invitation(self) -> None:
        a = form_dialog(self, "Accept an invitation", [
            ("source", "From", "choice", "paste", [("paste", "Pasted text"), ("file", "An invitation file…"),
                                                   ("qr", "An image of a QR code…")]),
            ("text", "Invitation text", "multiline", "")], ok_text="Continue")
        if not a:
            return
        text = a["text"]
        if a["source"] == "file":
            path, _ = QFileDialog.getOpenFileName(self, "Open invitation", "", "Aureom invitation (*.aureom-invite *.json *.txt)")
            if not path:
                return
            text = Path(path).read_bytes()[:20000]
        elif a["source"] == "qr":
            try:
                import zxingcpp
            except ImportError:
                self.window_.toast("Reading QR images needs the optional “qrscan” extra (pip install aureom-commons[qrscan]). "
                                   "You can paste the invitation text or open the invitation file instead.", error=True)
                return
            path, _ = QFileDialog.getOpenFileName(self, "Open QR image", "", "Images (*.png *.jpg *.jpeg)")
            if not path:
                return
            image = QImage(path).convertToFormat(QImage.Format.Format_Grayscale8)
            import numpy as np

            array = np.frombuffer(image.constBits(), dtype=np.uint8).reshape(image.height(), image.bytesPerLine())[:, :image.width()]
            found = zxingcpp.read_barcodes(np.ascontiguousarray(array))
            if not found:
                self.window_.toast("No QR code was found in that image.", error=True)
                return
            text = found[0].text
        info = self.ctx.node.inspect_invitation(text)
        offer = info["collection"]
        html = (f"<h2>{esc(info['device_name'])} <span style='color:gray; font-size:10pt'>(self-declared name)</span></h2>"
                f"<p>Purpose: <b>{esc(info['purpose'])}</b>"
                + (f" — collection “{esc(offer['name'])}” ({offer['item_count']} work(s)) with: {esc(', '.join(offer['permissions']))}" if offer else "")
                + f"</p><h3>Device fingerprint</h3><p style='font-size:13pt'><code>{info['device_fingerprint']}</code></p>"
                f"<p>Account fingerprint: <code>{info['account_fingerprint']}</code><br>Address: {esc(', '.join(info['addresses']) or 'relay only')}"
                f"<br>Expires: {esc(info['expires_at'][:16])}Z</p>{bullet_list(info['notices'])}")
        if not review_dialog(self, "Check this invitation", html, ok_text="Accept and pair", height=520):
            return
        verified = QMessageBox.question(
            self, "Fingerprint", "Have you already compared this fingerprint with the sender through another channel "
                                 "(in person, by phone)?\n\nChoose No to pair now and verify later.") == QMessageBox.StandardButton.Yes
        self.window_.run(self.ctx.node.accept_invitation(text, verified=verified), lambda r: (
            self.refresh(), self.window_.toast(f"Paired with {r['device_name']}." + ("" if verified else
                                               " Remember to verify its fingerprint."))))

    def _peer(self) -> str | None:
        device = selected_payload(self.peers)
        if not device:
            self.window_.toast("Select a device first.")
        return device

    def verify(self) -> None:
        device = self._peer()
        if not device:
            return
        p = self.ctx.identity.peer(device)
        if review_dialog(self, "Verify fingerprint",
                         f"<h3>Compare with {esc(p['display_name'])}</h3><p>Ask them to open Peers → This device and read "
                         f"their device fingerprint to you over a channel you trust. It must match exactly:</p>"
                         f"<p style='font-size:13pt'><code>{p['fingerprint']}</code></p><p>Your own, for them to check:</p>"
                         f"<p><code>{self.ctx.identity.describe()['device_fingerprint']}</code></p>",
                         ok_text="They match — mark as verified", cancel_text="Not verified", height=400):
            self.ctx.identity.mark_verified(device, True)
        else:
            self.ctx.identity.mark_verified(device, False)
        self.refresh()

    def edit_peer(self) -> None:
        device = self._peer()
        if not device:
            return
        p = self.ctx.identity.peer(device)
        a = form_dialog(self, "Device settings", [
            ("alias", "Your name for this device", "text", p["local_alias"]),
            ("addresses", "Addresses (host:port, comma separated)", "text", ", ".join(p["addresses"])),
            ("relay", "Relay (host:port, optional)", "text", p["relay"]),
            ("limit", "Bandwidth limit for this peer (kbps, 0 = none)", "int", p["bandwidth_kbps"])])
        if a:
            self.ctx.identity.update_peer(device, alias=a["alias"], relay=a["relay"], bandwidth_kbps=a["limit"],
                                          addresses=[x.strip() for x in a["addresses"].split(",") if x.strip()])
            self.refresh()

    def sync(self) -> None:
        device = self._peer()
        if device:
            self.window_.run(self.ctx.node.sync_with(device), lambda s: self.window_.toast(
                f"Synchronised: {s['applied']} received, {s['sent']} sent, {s['merged']} merged, "
                f"{s['conflicts']} conflict(s) recorded for review (see Activity)."))

    def set_state(self, state: str) -> None:
        device = self._peer()
        if not device:
            return
        text = ("This device will no longer be able to authenticate to you. Copies it already holds are unaffected."
                if state == "removed" else "This device will be refused, and cannot pair with you again until unblocked.")
        if QMessageBox.question(self, "Confirm", text + "\n\nContinue?") == QMessageBox.StandardButton.Yes:
            self.ctx.identity.set_peer_state(device, state)
            self.refresh()

    def rotate(self) -> None:
        if review_dialog(self, "Rotate device key",
                         "<h3>Replace this device's key?</h3><p>A new key is generated. Your old key signs a statement "
                         "naming the new one, and each trusted peer accepts it the next time you connect.</p><p>Peers "
                         "that are not reached within 30 days must pair with you again. Your fingerprint changes, so "
                         "anyone who verified it should verify the new one.</p><p>If this device's key was <b>lost or "
                         "stolen</b>, rotation is not enough — see Settings → Protection for device-loss guidance.</p>",
                         ok_text="Rotate key", height=380):
            self.ctx.identity.rotate_device_key()
            self.window_.run(self.ctx.node.announce_rotation(), lambda r: (self.refresh(), self.window_.toast(
                f"Key rotated. {r['told']} peer(s) updated, {r['pending']} still to be told.")))

    # --------------------------------------------------------------- public
    def _fill_pubs(self) -> None:
        fill_table(self.pubs, (((e["publication_id"], e["source_device"]), [
            e["title"], f"{e['edition_number']} · {e['edition_label']}" + (" (superseded)" if e["superseded_by"] else ""),
            e["publisher"]["name"] if e["publisher"] else "—",
            "matches publisher key" if e["signature_ok"] else "unsigned", theme.AVAILABILITY[e["availability"]],
            e["source_address"]]) for e in self.ctx.publishing.remote_list()))

    def fetch_public(self) -> None:
        address = self.address.text().strip()
        expected = self.expected.text().replace(" ", "").lower() or None
        if not address:
            self.window_.toast("Enter the address of a peer's device (host:port).")
            return
        self.window_.run(self.ctx.node.fetch_public_catalogue(address, "", expected), lambda r: (
            self._fill_pubs(), self.window_.toast(f"{len(r['publications'])} public edition(s) listed. {r['endpoint_note']}")))

    def search_index(self) -> None:
        self.window_.run_blocking(lambda: self.ctx.node.rendezvous.search(""), lambda r: (
            self._fill_pubs(), self.window_.toast(f"{len(r['publications'])} edition(s) from the index. {r['note']}")))

    def show_publication(self) -> None:
        key = selected_payload(self.pubs)
        if not key:
            self.pub_detail.setHtml("")
            return
        from aureom.protocol.manifest import check_publication

        manifest, _sources = self.ctx.publishing.remote_manifest(*key)
        pinned = self.ctx.identity.publisher_pin(manifest.publisher.key_id) if manifest.publisher else None
        report = check_publication(manifest, pinned=pinned)
        files = "".join(f"<li>{esc(f.filename)} · {f.format.upper()} · {human_size(f.size)} · <code>{f.file_hash[:16]}…</code></li>"
                        for f in manifest.files)
        self.pub_detail.setHtml(
            f"<h3 style='font-family:\"{theme.serif_family()}\"; font-weight:normal; font-size:14pt'>{esc(manifest.title)}</h3>"
            f"<p>{esc(manifest.edition_label)} (edition {manifest.edition_number}) · licence: {esc(manifest.licence)}<br>"
            f"{esc(manifest.revision_notes)}</p><p>{esc(manifest.description)}</p><ul>{files}</ul>"
            f"<h3>What was checked</h3>{bullet_list(report.statements)}"
            + (f"<p>Publisher key fingerprint: <code>{fingerprint_display(report.key_id)}</code></p>" if report.key_id else ""))

    def _pub(self):
        key = selected_payload(self.pubs)
        if not key:
            self.window_.toast("Select a publication first.")
        return key

    def download_public(self) -> None:
        key = self._pub()
        if key:
            self.ctx.node.download_publication(*key)
            self.window_.toast("Download queued. Files are checked against the manifest's hashes as they arrive.")

    def pin_publisher(self) -> None:
        key = self._pub()
        if key:
            manifest, _ = self.ctx.publishing.remote_manifest(*key)
            if not manifest.publisher:
                self.window_.toast("This edition is unsigned; there is no publisher key to remember.")
                return
            self.ctx.identity.pin_publisher(manifest.publisher.key, manifest.publisher.name)
            self.show_publication()
            self.window_.toast("Publisher key remembered. Later editions signed by the same key will say so.")

    def mirror(self) -> None:
        key = self._pub()
        if key:
            entry = next(e for e in self.ctx.publishing.remote_list() if e["publication_id"] == key[0])
            self.ctx.publishing.set_mirror(key[0], not entry["mirrored"])
            self.window_.toast("Mirroring " + ("stopped." if entry["mirrored"] else
                               "enabled: your device will serve this signed edition to anyone who asks, once you hold the files."))

    def report(self) -> None:
        key = self._pub()
        if key:
            a = form_dialog(self, "Report to the index operator", [("reason", "Reason", "multiline", "")],
                            intro="Reports go to the operator of the optional public index you configured. They can "
                                  "delist an entry from that index; they cannot affect anyone's private library.")
            if a and a["reason"]:
                self.window_.run_blocking(lambda: self.ctx.node.rendezvous.report(key[0], a["reason"]),
                                          lambda _r: self.window_.toast("Report sent to the index operator."))
