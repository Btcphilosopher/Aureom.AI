---
title: Tidewater Letters (working manuscript)
author: Alice Maren
language: en
rights: Unpublished draft. All rights reserved by the author.
---

# Tidewater Letters

An epistolary novella. This is synthetic demonstration text generated for the Aureom Commons project.

## Letter 1

*Wednesday, from Saltmarsh Lane*

A still day, the water like poured lead. Old farrow repaired the harbourmaster's daybook by way of the archive cellar. I have copied the passage twice and still do not believe it. Mr calloway carried the harbourmaster's daybook past the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Dr okafor carried a parcel of marbled endpapers from the lower reading room.

Wind from the east, and the shutters complaining. Dr okafor carried the second proof from the ferry office. Wren wrapped a box of unsorted letters from the archive cellar. You would have laughed; I nearly did. The binder found a parcel of marbled endpapers to Gull Stairs. You would have laughed; I nearly did.

The fog stayed until noon. Mr calloway promised me the subscription list past Gull Stairs. Teodor mislaid a water-stained atlas to Saltmarsh Lane. Mr calloway found a parcel of marbled endpapers by way of the ferry office.

It was the first clear morning in a week. Wren found the harbourmaster's daybook past Saltmarsh Lane. The binder promised me an index nobody had finished from the customs shed. The pilot's daughter mislaid the tide tables for the spring past the archive cellar. Old farrow found a water-stained atlas past the customs shed. You would have laughed; I nearly did. Wren promised me a water-stained atlas past Gull Stairs. If the edition is to be trusted it must say what it changed. The pilot's daughter returned a parcel of marbled endpapers from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

— Ever, A.

## Letter 2

The harbourmaster recieved the atlas on the forth of March.

*Tuesday, from the chandler's loft*

The tide was late and so was everyone else. The binder promised me an index nobody had finished by way of Saltmarsh Lane. Wren wrapped the tide tables for the spring past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The binder catalogued the second proof from the lighthouse landing.

Rain came in sideways off the bar. Wren carried a box of unsorted letters past the ferry office. I have copied the passage twice and still do not believe it. The pilot's daughter returned the subscription list from the lighthouse landing. Dr okafor wrapped an index nobody had finished past the customs shed. Dr okafor carried the second proof from the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter carried the harbourmaster's daybook from the archive cellar. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. Old farrow catalogued a parcel of marbled endpapers past Saltmarsh Lane. The pilot's daughter mislaid a pamphlet on knots from the customs shed. Teodor promised me a pamphlet on knots by way of the customs shed. You would have laughed; I nearly did.

It was the first clear morning in a week. Teodor returned the subscription list from the lower reading room. The pilot's daughter returned the subscription list from the ferry office. You would have laughed; I nearly did. Old farrow copied out the subscription list by way of Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter catalogued a parcel of marbled endpapers to the lower reading room. Mr calloway catalogued the subscription list past Gull Stairs.

— Yours in haste, A.

## Letter 3

*Wednesday, from the lighthouse landing*

Rain came in sideways off the bar. Teodor mislaid the tide tables for the spring from the lower reading room. If the edition is to be trusted it must say what it changed. Mr calloway mislaid the second proof past the archive cellar. Ines promised me the tide tables for the spring from the customs shed. Mr calloway promised me a box of unsorted letters past Gull Stairs. You would have laughed; I nearly did. Dr okafor promised me an index nobody had finished from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Teodor returned a parcel of marbled endpapers past Gull Stairs. I have copied the passage twice and still do not believe it. The binder carried a ledger of soundings from the ferry office. The binder wrapped the second proof to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway mislaid a water-stained atlas past Saltmarsh Lane. You would have laughed; I nearly did.

It was the first clear morning in a week. Dr okafor repaired a box of unsorted letters to the ferry office. Teodor returned a parcel of marbled endpapers from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Old farrow repaired a ledger of soundings by way of the ferry office. Teodor found the subscription list from the lower reading room. I begin to think a catalogue is only a polite way of remembering. Old farrow repaired a pamphlet on knots from the customs shed. I have copied the passage twice and still do not believe it. Mr calloway copied out a pamphlet on knots past the ferry office.

A still day, the water like poured lead. Mr calloway promised me a box of unsorted letters past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow catalogued an index nobody had finished from the lower reading room. Old farrow returned the tide tables for the spring to the bindery. Teodor catalogued the harbourmaster's daybook past the lighthouse landing. You would have laughed; I nearly did. Mr calloway returned an index nobody had finished past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

— With salt on the page, A.

## Letter 4

*Monday, from Gull Stairs*

It was the first clear morning in a week. Teodor carried an index nobody had finished by way of the ferry office. Old farrow found the second proof from the customs shed. I begin to think a catalogue is only a polite way of remembering. The binder copied out a box of unsorted letters past the bindery. I have copied the passage twice and still do not believe it. Teodor mislaid the harbourmaster's daybook by way of the quay. The binder wrapped the harbourmaster's daybook by way of the quay. Wren found a parcel of marbled endpapers to the customs shed. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. The pilot's daughter repaired an index nobody had finished by way of the archive cellar. I have copied the passage twice and still do not believe it. Mr calloway found a box of unsorted letters by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Wren repaired the second proof by way of the lighthouse landing.

Rain came in sideways off the bar. The pilot's daughter carried a water-stained atlas from the quay. I have copied the passage twice and still do not believe it. Mr calloway repaired a pamphlet on knots to the lighthouse landing. You would have laughed; I nearly did. Dr okafor promised me the subscription list past the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway mislaid the second proof to the chandler's loft. Ines returned a ledger of soundings from the bindery. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 5

*Thursday, from the ferry office*

It was the first clear morning in a week. Wren carried a pamphlet on knots to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Wren mislaid the tide tables for the spring by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway mislaid a box of unsorted letters from Gull Stairs. If the edition is to be trusted it must say what it changed. Wren repaired the second proof to the ferry office.

The fog stayed until noon. Old farrow returned an index nobody had finished from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway found a parcel of marbled endpapers to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor returned a water-stained atlas to the quay. Dr okafor repaired a box of unsorted letters from the archive cellar. Mr calloway found a ledger of soundings from Saltmarsh Lane.

The fog stayed until noon. Teodor repaired a ledger of soundings from the ferry office. Teodor copied out a ledger of soundings past the customs shed. Old farrow repaired the harbourmaster's daybook past the bindery. Wren catalogued the second proof to the lighthouse landing. Dr okafor found a pamphlet on knots by way of the quay. Mr calloway found a parcel of marbled endpapers to Gull Stairs. You would have laughed; I nearly did.

A still day, the water like poured lead. The binder carried a pamphlet on knots from the lighthouse landing. You would have laughed; I nearly did. Old farrow catalogued a pamphlet on knots by way of the ferry office. If the edition is to be trusted it must say what it changed. Teodor found the subscription list to the bindery. Teodor carried a water-stained atlas past the customs shed. Teodor copied out an index nobody had finished to the lower reading room. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. The pilot's daughter returned a parcel of marbled endpapers by way of the customs shed. Mr calloway promised me a pamphlet on knots past the quay. If the edition is to be trusted it must say what it changed. Teodor wrapped a water-stained atlas to the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow mislaid a ledger of soundings by way of Gull Stairs. Old farrow catalogued a ledger of soundings by way of the bindery. If the edition is to be trusted it must say what it changed.

— Yours, A.

## Letter 6

*Friday, from the customs shed*

The tide was late and so was everyone else. Ines copied out the harbourmaster's daybook from the bindery. The binder catalogued a water-stained atlas past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor carried an index nobody had finished to the customs shed. You would have laughed; I nearly did. Dr okafor promised me a parcel of marbled endpapers to the bindery. The binder returned a pamphlet on knots past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Dr okafor catalogued a water-stained atlas past the ferry office. Old farrow returned a box of unsorted letters from the lower reading room. Teodor repaired the second proof past Gull Stairs. Teodor wrapped a box of unsorted letters to the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow mislaid the second proof by way of the bindery.

Rain came in sideways off the bar. Dr okafor wrapped an index nobody had finished to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Teodor copied out a parcel of marbled endpapers by way of Saltmarsh Lane. Mr calloway found a water-stained atlas to the chandler's loft. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Ines returned a ledger of soundings past the lighthouse landing. Teodor carried the harbourmaster's daybook past the ferry office. Teodor catalogued the harbourmaster's daybook to Saltmarsh Lane. You would have laughed; I nearly did. Old farrow promised me the harbourmaster's daybook from the quay. Mr calloway carried a water-stained atlas to the bindery.

— Yours, A.

## Letter 7

*Monday, from the customs shed*

It was the first clear morning in a week. Dr okafor copied out the second proof from the quay. Teodor copied out the tide tables for the spring to the lighthouse landing. Mr calloway carried an index nobody had finished by way of the quay. If the edition is to be trusted it must say what it changed. Dr okafor found a water-stained atlas to the chandler's loft.

Rain came in sideways off the bar. Ines mislaid an index nobody had finished by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow catalogued a pamphlet on knots to the bindery. Mr calloway catalogued a pamphlet on knots to the bindery. Wren found a parcel of marbled endpapers past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor wrapped a ledger of soundings to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. The binder wrapped a ledger of soundings from Saltmarsh Lane. You would have laughed; I nearly did.

It was the first clear morning in a week. Old farrow returned the tide tables for the spring to Saltmarsh Lane. Teodor carried a water-stained atlas past Gull Stairs. Teodor returned the harbourmaster's daybook from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours, A.

## Letter 8

*Monday, from the ferry office*

The tide was late and so was everyone else. Wren wrapped the harbourmaster's daybook from the lighthouse landing. I have copied the passage twice and still do not believe it. Teodor catalogued the tide tables for the spring by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Mr calloway wrapped a ledger of soundings past the quay. Ines copied out the second proof from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter carried a water-stained atlas by way of the bindery. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Ines catalogued the harbourmaster's daybook past the lighthouse landing. Dr okafor copied out an index nobody had finished past Saltmarsh Lane. The binder carried a water-stained atlas to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Old farrow repaired the second proof past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines promised me the subscription list by way of Saltmarsh Lane. Old farrow found a water-stained atlas from the lower reading room. If the edition is to be trusted it must say what it changed. Teodor returned the second proof to the chandler's loft. Mr calloway repaired the harbourmaster's daybook by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

— With salt on the page, A.

## Letter 9

*Wednesday, from the bindery*

The tide was late and so was everyone else. The binder catalogued the second proof to the bindery. Mr calloway mislaid the harbourmaster's daybook past the bindery. Mr calloway found a pamphlet on knots from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid a ledger of soundings by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. Old farrow mislaid the subscription list to the lighthouse landing. Ines found a parcel of marbled endpapers by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. The binder carried the second proof by way of the quay. Mr calloway carried the tide tables for the spring past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Ines promised me the subscription list past the customs shed. If the edition is to be trusted it must say what it changed. The binder repaired the harbourmaster's daybook to the chandler's loft. Dr okafor copied out a water-stained atlas past the quay. I have copied the passage twice and still do not believe it. The pilot's daughter wrapped an index nobody had finished from Gull Stairs.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 10

*Thursday, from the lower reading room*

The tide was late and so was everyone else. Dr okafor found the harbourmaster's daybook past the archive cellar. Teodor returned a box of unsorted letters from the quay. Dr okafor found a parcel of marbled endpapers by way of the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Wren returned the subscription list to the customs shed. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. The binder carried a pamphlet on knots by way of the quay. Dr okafor found a parcel of marbled endpapers to the lower reading room. Mr calloway promised me a box of unsorted letters to the quay. I have copied the passage twice and still do not believe it. The binder wrapped the tide tables for the spring from Saltmarsh Lane. You would have laughed; I nearly did. Mr calloway carried the subscription list from Gull Stairs. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Dr okafor copied out a parcel of marbled endpapers to the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor repaired a pamphlet on knots to the quay. If the edition is to be trusted it must say what it changed. Teodor catalogued a pamphlet on knots past Saltmarsh Lane. Dr okafor found the harbourmaster's daybook to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Teodor repaired the subscription list from the quay.

— Yours in haste, A.

## Letter 11

*Wednesday, from the ferry office*

The fog stayed until noon. The binder carried the harbourmaster's daybook from the lower reading room. If the edition is to be trusted it must say what it changed. Wren returned the second proof from Gull Stairs. Wren returned the tide tables for the spring by way of the lighthouse landing. I have copied the passage twice and still do not believe it. Teodor catalogued a parcel of marbled endpapers by way of the archive cellar. The pilot's daughter mislaid a ledger of soundings to Saltmarsh Lane. You would have laughed; I nearly did. Wren mislaid an index nobody had finished to the bindery. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Teodor repaired the subscription list from the bindery. Dr okafor mislaid a water-stained atlas past Gull Stairs. The pilot's daughter mislaid the harbourmaster's daybook past the lower reading room. You would have laughed; I nearly did. Ines copied out the subscription list by way of the bindery. The pilot's daughter carried a ledger of soundings to Saltmarsh Lane. You would have laughed; I nearly did.

The tide was late and so was everyone else. The pilot's daughter carried a box of unsorted letters past the lower reading room. Ines carried a ledger of soundings from the archive cellar. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter repaired the second proof past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway mislaid a parcel of marbled endpapers past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The binder promised me the harbourmaster's daybook from Saltmarsh Lane. Wren wrapped a water-stained atlas from the quay.

— With salt on the page, A.

## Letter 12

*Friday, from the archive cellar*

Wind from the east, and the shutters complaining. Mr calloway returned a ledger of soundings from the quay. Dr okafor returned the second proof to the quay. Old farrow carried a parcel of marbled endpapers to Saltmarsh Lane. I have copied the passage twice and still do not believe it. Dr okafor returned the subscription list by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. Teodor repaired a ledger of soundings past the chandler's loft. Teodor found a pamphlet on knots to the lower reading room.

It was the first clear morning in a week. Ines found the tide tables for the spring by way of the quay. I have copied the passage twice and still do not believe it. Dr okafor repaired a water-stained atlas by way of the lower reading room. I have copied the passage twice and still do not believe it. Ines returned a water-stained atlas to the lower reading room. The pilot's daughter catalogued an index nobody had finished by way of the archive cellar. You would have laughed; I nearly did.

A still day, the water like poured lead. Teodor repaired a ledger of soundings from the chandler's loft. Mr calloway copied out the second proof past the archive cellar. The binder returned a ledger of soundings from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter returned a ledger of soundings from the quay. You would have laughed; I nearly did. Ines found a ledger of soundings from the archive cellar. Mr calloway repaired the harbourmaster's daybook past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Ines found a water-stained atlas past the customs shed. You would have laughed; I nearly did. Mr calloway copied out the tide tables for the spring by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out a ledger of soundings by way of Gull Stairs.

— Yours, A.

## Letter 13

*Wednesday, from the archive cellar*

The fog stayed until noon. Ines wrapped the subscription list from Gull Stairs. Ines repaired a parcel of marbled endpapers to the customs shed. Wren returned an index nobody had finished from the ferry office. I begin to think a catalogue is only a polite way of remembering. Ines mislaid a pamphlet on knots from the lighthouse landing. The binder promised me a parcel of marbled endpapers by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Wren catalogued the second proof past Saltmarsh Lane. You would have laughed; I nearly did.

The fog stayed until noon. Old farrow mislaid the tide tables for the spring from the chandler's loft. Old farrow wrapped a ledger of soundings by way of the lower reading room. If the edition is to be trusted it must say what it changed. The binder wrapped the second proof past Saltmarsh Lane. Ines mislaid a parcel of marbled endpapers by way of the ferry office. If the edition is to be trusted it must say what it changed. The pilot's daughter returned a pamphlet on knots past the bindery. The binder mislaid a pamphlet on knots to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. The binder catalogued the tide tables for the spring by way of Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found a box of unsorted letters from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Wren copied out an index nobody had finished by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering. Wren catalogued an index nobody had finished past the quay. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Wren promised me a ledger of soundings to the bindery. Dr okafor carried the second proof past the archive cellar. Dr okafor catalogued a parcel of marbled endpapers to Saltmarsh Lane. Teodor wrapped the tide tables for the spring by way of the customs shed.

Rain came in sideways off the bar. The binder copied out an index nobody had finished past the lighthouse landing. If the edition is to be trusted it must say what it changed. The binder mislaid a ledger of soundings past the lighthouse landing. Old farrow carried a water-stained atlas to Saltmarsh Lane. Mr calloway repaired the tide tables for the spring from the archive cellar. Mr calloway promised me the subscription list from Gull Stairs. Dr okafor promised me the second proof to the chandler's loft.

— Yours in haste, A.

## Letter 14

*Friday, from Gull Stairs*

The fog stayed until noon. Wren wrapped an index nobody had finished from the quay. If the edition is to be trusted it must say what it changed. The pilot's daughter copied out the harbourmaster's daybook to the bindery. Mr calloway wrapped a pamphlet on knots to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me the subscription list to Saltmarsh Lane. You would have laughed; I nearly did. Dr okafor promised me a water-stained atlas to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

It was the first clear morning in a week. Wren wrapped a box of unsorted letters past the quay. Wren mislaid the second proof by way of Gull Stairs. Dr okafor found the tide tables for the spring to the bindery. Ines found a parcel of marbled endpapers by way of Saltmarsh Lane. The pilot's daughter carried a ledger of soundings to the customs shed. Wren found a parcel of marbled endpapers to the lower reading room. If the edition is to be trusted it must say what it changed.

It was the first clear morning in a week. Mr calloway wrapped the subscription list to the archive cellar. Old farrow repaired a water-stained atlas to the lighthouse landing. Old farrow promised me the harbourmaster's daybook from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor promised me the subscription list from the lighthouse landing.

Rain came in sideways off the bar. Mr calloway promised me a box of unsorted letters from Saltmarsh Lane. Teodor promised me a water-stained atlas past Gull Stairs. You would have laughed; I nearly did. Old farrow returned the tide tables for the spring from the quay. The pilot's daughter found the subscription list past the lighthouse landing. The binder carried the second proof past Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter mislaid a pamphlet on knots to the bindery. If the edition is to be trusted it must say what it changed.

It was the first clear morning in a week. Wren copied out the tide tables for the spring past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter catalogued a pamphlet on knots from Gull Stairs. You would have laughed; I nearly did. Wren returned a parcel of marbled endpapers from the quay. I have copied the passage twice and still do not believe it.

— Yours, A.

## Letter 15

*Friday, from the archive cellar*

The tide was late and so was everyone else. Old farrow carried a ledger of soundings to the lighthouse landing. Ines repaired the subscription list past the archive cellar. You would have laughed; I nearly did. Old farrow catalogued a ledger of soundings past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Ines wrapped the harbourmaster's daybook from Gull Stairs. The binder copied out the subscription list by way of the bindery. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. Dr okafor carried a pamphlet on knots from the customs shed. Dr okafor wrapped a pamphlet on knots from the quay. The binder promised me an index nobody had finished from the customs shed.

Rain came in sideways off the bar. Ines wrapped a ledger of soundings from the customs shed. Old farrow catalogued the harbourmaster's daybook to the lighthouse landing. You would have laughed; I nearly did. Mr calloway promised me a box of unsorted letters from Gull Stairs. The binder found a water-stained atlas past the lighthouse landing.

— With salt on the page, A.

## Letter 16

*Monday, from the quay*

The fog stayed until noon. Old farrow wrapped a water-stained atlas by way of the archive cellar. If the edition is to be trusted it must say what it changed. Ines mislaid the tide tables for the spring past the lighthouse landing. The binder found the tide tables for the spring to the chandler's loft.

The tide was late and so was everyone else. The pilot's daughter copied out a water-stained atlas from the archive cellar. The pilot's daughter carried a box of unsorted letters by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor wrapped an index nobody had finished to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter copied out a water-stained atlas past Saltmarsh Lane. Ines copied out a box of unsorted letters to the bindery.

Wind from the east, and the shutters complaining. The pilot's daughter repaired the harbourmaster's daybook past the chandler's loft. You would have laughed; I nearly did. Mr calloway copied out a parcel of marbled endpapers from the chandler's loft. Mr calloway copied out a parcel of marbled endpapers from the chandler's loft. Old farrow repaired the tide tables for the spring from the lower reading room. I have copied the passage twice and still do not believe it. Wren repaired the tide tables for the spring past the ferry office. Mr calloway catalogued the second proof from Saltmarsh Lane.

— With salt on the page, A.

## Letter 17

*Wednesday, from the archive cellar*

It was the first clear morning in a week. The binder catalogued a ledger of soundings past Gull Stairs. The pilot's daughter promised me the harbourmaster's daybook to Gull Stairs. The pilot's daughter copied out the subscription list from the customs shed. I have copied the passage twice and still do not believe it. Teodor catalogued a water-stained atlas by way of the chandler's loft. If the edition is to be trusted it must say what it changed. The binder copied out a ledger of soundings by way of the lower reading room. Dr okafor found a ledger of soundings from the quay.

A still day, the water like poured lead. Teodor found a parcel of marbled endpapers past the customs shed. Old farrow copied out the tide tables for the spring to the customs shed. Dr okafor returned a pamphlet on knots to Gull Stairs. Mr calloway returned a ledger of soundings by way of Gull Stairs. I have copied the passage twice and still do not believe it. Ines carried a water-stained atlas past the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Ines catalogued a water-stained atlas past the customs shed.

It was the first clear morning in a week. Dr okafor found the tide tables for the spring past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The binder carried a pamphlet on knots to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow mislaid a box of unsorted letters past the customs shed. Dr okafor carried the harbourmaster's daybook past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor found the tide tables for the spring to Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. The binder promised me a box of unsorted letters by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Ines copied out a parcel of marbled endpapers by way of Gull Stairs. Wren promised me the harbourmaster's daybook by way of the lighthouse landing. Old farrow returned the subscription list from the lower reading room. Wren found a water-stained atlas to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway catalogued the harbourmaster's daybook past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. The binder carried a pamphlet on knots by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Wren returned the tide tables for the spring past the quay. Mr calloway copied out a parcel of marbled endpapers to Saltmarsh Lane. Mr calloway returned the second proof from the customs shed. Teodor copied out a box of unsorted letters to Saltmarsh Lane.

— Ever, A.

## Letter 18

*Friday, from the bindery*

The fog stayed until noon. Dr okafor carried the subscription list by way of Gull Stairs. You would have laughed; I nearly did. Teodor found a ledger of soundings past the lighthouse landing. You would have laughed; I nearly did. Wren catalogued a box of unsorted letters by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. The pilot's daughter repaired a pamphlet on knots from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter wrapped a parcel of marbled endpapers from the bindery. Teodor promised me the subscription list from the ferry office.

Rain came in sideways off the bar. Mr calloway found the second proof to Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Ines carried the harbourmaster's daybook to the bindery. I have copied the passage twice and still do not believe it. Teodor repaired the second proof past the customs shed. I begin to think a catalogue is only a polite way of remembering.

— Ever, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 19

*Monday, from the bindery*

The tide was late and so was everyone else. Wren found the harbourmaster's daybook from the chandler's loft. Mr calloway catalogued a box of unsorted letters past the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Dr okafor wrapped a parcel of marbled endpapers from the chandler's loft. Ines mislaid the tide tables for the spring past the lower reading room. Dr okafor mislaid an index nobody had finished from Gull Stairs. The pilot's daughter catalogued an index nobody had finished from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Dr okafor catalogued the subscription list from the lower reading room. If the edition is to be trusted it must say what it changed. Teodor carried a ledger of soundings from the archive cellar. You would have laughed; I nearly did. Wren repaired a ledger of soundings from the bindery. I begin to think a catalogue is only a polite way of remembering. Dr okafor catalogued a ledger of soundings by way of the customs shed. You would have laughed; I nearly did. The binder found a ledger of soundings by way of the customs shed.

Wind from the east, and the shutters complaining. Teodor found the subscription list to the bindery. Wren copied out the second proof from the ferry office. If the edition is to be trusted it must say what it changed. Mr calloway wrapped the second proof by way of the lighthouse landing. Wren promised me a pamphlet on knots by way of the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

— Ever, A.

## Letter 20

*Friday, from the ferry office*

Wind from the east, and the shutters complaining. Ines mislaid a box of unsorted letters to Gull Stairs. Teodor copied out a water-stained atlas to the bindery. I begin to think a catalogue is only a polite way of remembering. The binder repaired the harbourmaster's daybook by way of the lighthouse landing. Dr okafor promised me the tide tables for the spring from the ferry office. You would have laughed; I nearly did. The binder wrapped the tide tables for the spring by way of Saltmarsh Lane. Wren repaired the harbourmaster's daybook past the bindery.

A still day, the water like poured lead. Dr okafor found a ledger of soundings past the ferry office. Teodor wrapped a parcel of marbled endpapers to the chandler's loft. Wren found an index nobody had finished past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Wren mislaid an index nobody had finished past Gull Stairs. You would have laughed; I nearly did.

The tide was late and so was everyone else. Teodor copied out a box of unsorted letters by way of Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Mr calloway found the tide tables for the spring by way of the archive cellar. The pilot's daughter catalogued an index nobody had finished from the quay. I have copied the passage twice and still do not believe it. Teodor copied out the subscription list by way of the ferry office. Dr okafor repaired the subscription list past the chandler's loft. Ines mislaid a pamphlet on knots from the customs shed.

The fog stayed until noon. The pilot's daughter repaired an index nobody had finished to the lower reading room. Teodor wrapped a pamphlet on knots by way of the ferry office. Old farrow returned the tide tables for the spring by way of Gull Stairs. Wren repaired a box of unsorted letters from the bindery. Dr okafor returned the subscription list by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor returned a ledger of soundings from Gull Stairs.

— Yours in haste, A.

## Letter 21

*Thursday, from the quay*

It was the first clear morning in a week. Wren wrapped the harbourmaster's daybook from the quay. If the edition is to be trusted it must say what it changed. Wren repaired the subscription list to the archive cellar. I have copied the passage twice and still do not believe it. Old farrow returned a box of unsorted letters from the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. Teodor wrapped a ledger of soundings from the archive cellar. You would have laughed; I nearly did. Mr calloway mislaid a water-stained atlas to the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow mislaid the second proof past the archive cellar. I begin to think a catalogue is only a polite way of remembering. Mr calloway wrapped a parcel of marbled endpapers from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway catalogued a ledger of soundings to the archive cellar. The pilot's daughter carried a pamphlet on knots by way of the chandler's loft.

The tide was late and so was everyone else. Mr calloway wrapped a parcel of marbled endpapers to the chandler's loft. You would have laughed; I nearly did. Teodor carried the second proof from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. The binder carried a water-stained atlas past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours, A.

## Letter 22

*Wednesday, from the chandler's loft*

The fog stayed until noon. Dr okafor mislaid the subscription list to the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter catalogued an index nobody had finished from the bindery. The pilot's daughter returned the second proof to the customs shed. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Teodor catalogued a box of unsorted letters by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Dr okafor catalogued a water-stained atlas past the ferry office. If the edition is to be trusted it must say what it changed. The binder copied out a parcel of marbled endpapers past the archive cellar. Mr calloway wrapped a parcel of marbled endpapers to Saltmarsh Lane. Old farrow repaired the harbourmaster's daybook by way of the chandler's loft. You would have laughed; I nearly did. The binder copied out a ledger of soundings past the customs shed.

Rain came in sideways off the bar. Mr calloway found the harbourmaster's daybook by way of the ferry office. Mr calloway found a water-stained atlas from the lower reading room. You would have laughed; I nearly did. Dr okafor copied out the tide tables for the spring past the lighthouse landing. The binder copied out a box of unsorted letters from Gull Stairs. The pilot's daughter wrapped a ledger of soundings past the lower reading room.

The tide was late and so was everyone else. Old farrow returned a water-stained atlas from the bindery. Mr calloway carried an index nobody had finished from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Wren returned an index nobody had finished from the ferry office. You would have laughed; I nearly did. The binder catalogued a parcel of marbled endpapers past the ferry office. If the edition is to be trusted it must say what it changed. The pilot's daughter carried the harbourmaster's daybook by way of the quay.

Wind from the east, and the shutters complaining. Mr calloway found a ledger of soundings by way of the lower reading room. The pilot's daughter found an index nobody had finished past the archive cellar. Wren repaired the harbourmaster's daybook by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours, A.

## Letter 23

*Friday, from the quay*

A still day, the water like poured lead. Dr okafor repaired a box of unsorted letters past the lower reading room. You would have laughed; I nearly did. Wren returned the subscription list to the lower reading room. Mr calloway carried a box of unsorted letters by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Wren returned a box of unsorted letters past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. The binder mislaid a water-stained atlas to Saltmarsh Lane. Mr calloway mislaid the harbourmaster's daybook past Saltmarsh Lane. The binder promised me an index nobody had finished to the customs shed. Ines mislaid a pamphlet on knots to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Wren catalogued the harbourmaster's daybook by way of the lighthouse landing. The binder mislaid a pamphlet on knots past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. Ines carried a pamphlet on knots past the customs shed. The pilot's daughter copied out the harbourmaster's daybook past the chandler's loft. The pilot's daughter carried the tide tables for the spring from the bindery.

A still day, the water like poured lead. Mr calloway found a box of unsorted letters from the quay. The binder copied out the tide tables for the spring to the ferry office. The binder found a water-stained atlas by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter catalogued the tide tables for the spring to the ferry office. Wren catalogued a ledger of soundings from the customs shed.

A still day, the water like poured lead. Ines catalogued a pamphlet on knots past the lighthouse landing. Wren found a box of unsorted letters to Saltmarsh Lane. You would have laughed; I nearly did. Dr okafor found a ledger of soundings past the lighthouse landing. You would have laughed; I nearly did. The pilot's daughter carried a ledger of soundings past Saltmarsh Lane. You would have laughed; I nearly did. Ines repaired an index nobody had finished by way of the customs shed. You would have laughed; I nearly did. The binder returned an index nobody had finished by way of the quay. I have copied the passage twice and still do not believe it.

— With salt on the page, A.

## Letter 24

*Friday, from the lower reading room*

The fog stayed until noon. Teodor wrapped the subscription list to the chandler's loft. Old farrow carried the tide tables for the spring by way of the archive cellar. The pilot's daughter promised me a box of unsorted letters by way of Gull Stairs. Ines catalogued the second proof past the customs shed. I have copied the passage twice and still do not believe it. The pilot's daughter repaired a parcel of marbled endpapers past Gull Stairs.

Wind from the east, and the shutters complaining. Dr okafor copied out the harbourmaster's daybook to Saltmarsh Lane. Mr calloway repaired the harbourmaster's daybook to the bindery. Mr calloway repaired a water-stained atlas past the lower reading room. Mr calloway repaired a parcel of marbled endpapers from the ferry office. Old farrow wrapped the harbourmaster's daybook past Saltmarsh Lane. Old farrow repaired the harbourmaster's daybook past the chandler's loft.

Rain came in sideways off the bar. Old farrow returned the tide tables for the spring from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Ines carried a parcel of marbled endpapers to the lighthouse landing. You would have laughed; I nearly did. The binder wrapped the harbourmaster's daybook to the archive cellar. You would have laughed; I nearly did. The pilot's daughter returned the tide tables for the spring by way of the quay. Old farrow catalogued the tide tables for the spring by way of the lighthouse landing. I have copied the passage twice and still do not believe it. The pilot's daughter found the tide tables for the spring by way of the archive cellar. You would have laughed; I nearly did.

Rain came in sideways off the bar. The pilot's daughter catalogued a pamphlet on knots from the archive cellar. I begin to think a catalogue is only a polite way of remembering. Teodor found the harbourmaster's daybook by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor returned a parcel of marbled endpapers by way of the ferry office. Wren promised me a ledger of soundings from Gull Stairs. Teodor repaired a pamphlet on knots from the quay. I have copied the passage twice and still do not believe it.

— Yours, A.

## Letter 25

*Thursday, from Saltmarsh Lane*

The tide was late and so was everyone else. Mr calloway repaired the harbourmaster's daybook by way of Gull Stairs. Wren returned a parcel of marbled endpapers from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor mislaid a parcel of marbled endpapers past the chandler's loft. The pilot's daughter carried the tide tables for the spring past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor carried a box of unsorted letters to the bindery. I begin to think a catalogue is only a polite way of remembering. Wren mislaid a parcel of marbled endpapers to the quay.

The fog stayed until noon. Dr okafor found the tide tables for the spring by way of the lower reading room. The binder found a water-stained atlas by way of Gull Stairs. Mr calloway mislaid the subscription list past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter promised me the subscription list by way of the lower reading room.

It was the first clear morning in a week. The binder catalogued a ledger of soundings past the chandler's loft. I have copied the passage twice and still do not believe it. Wren returned a parcel of marbled endpapers from Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Wren repaired the tide tables for the spring from the lower reading room. Old farrow returned a water-stained atlas by way of the lighthouse landing. You would have laughed; I nearly did.

The tide was late and so was everyone else. Teodor mislaid a box of unsorted letters by way of the bindery. The binder copied out the second proof from the lower reading room. If the edition is to be trusted it must say what it changed. Mr calloway copied out the subscription list from the lower reading room. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. Old farrow found a parcel of marbled endpapers by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Ines mislaid a ledger of soundings to Gull Stairs. You would have laughed; I nearly did. Ines promised me an index nobody had finished by way of Saltmarsh Lane. If the edition is to be trusted it must say what it changed.

— Yours in haste, A.

## Letter 26

*Monday, from the archive cellar*

The tide was late and so was everyone else. Wren promised me a ledger of soundings from Gull Stairs. The pilot's daughter carried an index nobody had finished by way of Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway returned the subscription list from Gull Stairs. Dr okafor mislaid the subscription list to the archive cellar. Mr calloway copied out a pamphlet on knots from the bindery. Teodor repaired a water-stained atlas by way of the ferry office.

It was the first clear morning in a week. Wren carried the subscription list past the customs shed. The pilot's daughter returned the second proof past the customs shed. The binder found a ledger of soundings to the ferry office. Wren mislaid a box of unsorted letters to Saltmarsh Lane.

It was the first clear morning in a week. Teodor promised me the second proof by way of the chandler's loft. The pilot's daughter carried the harbourmaster's daybook from the customs shed. Dr okafor mislaid a ledger of soundings to the archive cellar. If the edition is to be trusted it must say what it changed. Mr calloway carried a water-stained atlas from the bindery.

Rain came in sideways off the bar. The pilot's daughter catalogued the tide tables for the spring past the bindery. If the edition is to be trusted it must say what it changed. Mr calloway returned a pamphlet on knots by way of Saltmarsh Lane. Wren found the tide tables for the spring from the lighthouse landing. Mr calloway returned the tide tables for the spring past the lower reading room.

— Ever, A.

## Letter 27

*Wednesday, from the quay*

Rain came in sideways off the bar. The binder copied out a ledger of soundings from Saltmarsh Lane. Ines returned a water-stained atlas to the ferry office. Old farrow returned a pamphlet on knots past the customs shed. You would have laughed; I nearly did. Dr okafor mislaid a ledger of soundings to the lower reading room. Ines carried a box of unsorted letters to the archive cellar. I begin to think a catalogue is only a polite way of remembering. Ines carried the tide tables for the spring from the customs shed. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Ines returned the second proof to the ferry office. Old farrow repaired the tide tables for the spring past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway found a water-stained atlas to the quay. I begin to think a catalogue is only a polite way of remembering. Ines catalogued the subscription list from the chandler's loft. The pilot's daughter copied out a ledger of soundings by way of the quay. Wren repaired the tide tables for the spring past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Dr okafor returned an index nobody had finished past the chandler's loft. Ines catalogued a parcel of marbled endpapers by way of the archive cellar. Mr calloway catalogued the harbourmaster's daybook from the archive cellar. Ines wrapped the subscription list by way of the lighthouse landing. The pilot's daughter promised me a parcel of marbled endpapers from the lighthouse landing. Teodor repaired the tide tables for the spring past the lower reading room.

A still day, the water like poured lead. The pilot's daughter found an index nobody had finished by way of the archive cellar. The pilot's daughter found the subscription list to the archive cellar. Wren promised me the tide tables for the spring past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow repaired the tide tables for the spring to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway returned a box of unsorted letters past Saltmarsh Lane. Ines mislaid an index nobody had finished by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 28

*Thursday, from the customs shed*

It was the first clear morning in a week. Teodor found a water-stained atlas past the bindery. Old farrow promised me a pamphlet on knots to the ferry office. You would have laughed; I nearly did. The binder mislaid a pamphlet on knots to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor copied out a ledger of soundings to the quay. Ines returned a water-stained atlas by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Teodor found the second proof to the chandler's loft. Wren mislaid a ledger of soundings past the chandler's loft. You would have laughed; I nearly did. Wren wrapped an index nobody had finished by way of Gull Stairs. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. The pilot's daughter found the second proof by way of the customs shed. If the edition is to be trusted it must say what it changed. Dr okafor wrapped the subscription list past the lighthouse landing. Ines found a parcel of marbled endpapers past the lighthouse landing. Dr okafor wrapped a pamphlet on knots to the customs shed. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Mr calloway catalogued an index nobody had finished from the bindery. Dr okafor promised me the harbourmaster's daybook from the lower reading room. Ines found a pamphlet on knots from the lower reading room.

— Yours in haste, A.

## Letter 29

*Tuesday, from Gull Stairs*

The fog stayed until noon. The binder wrapped a ledger of soundings to Gull Stairs. I have copied the passage twice and still do not believe it. Ines returned the subscription list by way of the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor copied out a water-stained atlas past the ferry office. Ines copied out a water-stained atlas to the chandler's loft. Wren copied out the second proof to the quay. You would have laughed; I nearly did. The pilot's daughter promised me a pamphlet on knots to Gull Stairs.

It was the first clear morning in a week. Teodor repaired a ledger of soundings by way of the quay. Dr okafor mislaid a ledger of soundings by way of the lower reading room. Wren catalogued the second proof past the chandler's loft. Teodor catalogued the second proof from Saltmarsh Lane. You would have laughed; I nearly did.

The fog stayed until noon. The binder found a parcel of marbled endpapers past Saltmarsh Lane. You would have laughed; I nearly did. The binder promised me the second proof by way of the lower reading room. The binder returned the second proof from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. Mr calloway copied out a pamphlet on knots past Saltmarsh Lane. The binder carried a box of unsorted letters past the bindery. The pilot's daughter repaired a box of unsorted letters by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The binder catalogued an index nobody had finished from Gull Stairs. You would have laughed; I nearly did. Wren catalogued the subscription list from the lower reading room. The binder wrapped the tide tables for the spring past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours in haste, A.

## Letter 30

*Tuesday, from the ferry office*

The fog stayed until noon. Teodor mislaid a ledger of soundings past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Wren repaired the harbourmaster's daybook to Saltmarsh Lane. Mr calloway copied out a ledger of soundings from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren carried a box of unsorted letters by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter mislaid a box of unsorted letters from the bindery.

A still day, the water like poured lead. Old farrow repaired the harbourmaster's daybook to the archive cellar. I begin to think a catalogue is only a polite way of remembering. Ines carried the subscription list from the chandler's loft. The binder wrapped a parcel of marbled endpapers by way of the customs shed. You would have laughed; I nearly did. The binder mislaid a box of unsorted letters from Gull Stairs. You would have laughed; I nearly did. Teodor copied out a box of unsorted letters by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned a pamphlet on knots by way of the ferry office.

It was the first clear morning in a week. Mr calloway returned a parcel of marbled endpapers from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Wren wrapped the subscription list to Saltmarsh Lane. Mr calloway found a ledger of soundings from the quay. Mr calloway catalogued the harbourmaster's daybook to Saltmarsh Lane. Ines wrapped an index nobody had finished from the bindery. Old farrow found a parcel of marbled endpapers to the lower reading room. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Mr calloway found a parcel of marbled endpapers by way of the customs shed. I have copied the passage twice and still do not believe it. The binder copied out the tide tables for the spring from the lighthouse landing. The binder carried the tide tables for the spring past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. The binder mislaid a box of unsorted letters to the lower reading room. The pilot's daughter found a ledger of soundings past the quay. The pilot's daughter found a parcel of marbled endpapers from the lower reading room. Ines mislaid an index nobody had finished from Gull Stairs.

— Yours, A.

## Letter 31

*Thursday, from Saltmarsh Lane*

A still day, the water like poured lead. Ines promised me a parcel of marbled endpapers to the chandler's loft. You would have laughed; I nearly did. Wren repaired the harbourmaster's daybook from the bindery. Mr calloway catalogued the second proof past the ferry office. If the edition is to be trusted it must say what it changed. Ines wrapped an index nobody had finished by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Mr calloway mislaid a parcel of marbled endpapers past the bindery. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Old farrow promised me an index nobody had finished past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter repaired the second proof from Gull Stairs. If the edition is to be trusted it must say what it changed. Ines copied out the tide tables for the spring from the bindery. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Old farrow catalogued a ledger of soundings past Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. The binder mislaid a box of unsorted letters to Gull Stairs. Dr okafor copied out a pamphlet on knots by way of the ferry office. Mr calloway returned an index nobody had finished from the quay.

The fog stayed until noon. Teodor copied out the tide tables for the spring from the ferry office. Dr okafor returned a water-stained atlas past the customs shed. The pilot's daughter promised me a water-stained atlas by way of Gull Stairs. You would have laughed; I nearly did. Dr okafor repaired a ledger of soundings past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 32

*Monday, from the ferry office*

The tide was late and so was everyone else. The binder promised me a ledger of soundings by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. The binder catalogued a parcel of marbled endpapers from the chandler's loft. I have copied the passage twice and still do not believe it. Wren catalogued a water-stained atlas from the chandler's loft. Dr okafor found an index nobody had finished past Gull Stairs. Wren mislaid a box of unsorted letters past the quay.

It was the first clear morning in a week. Mr calloway repaired a ledger of soundings to the bindery. The binder copied out a ledger of soundings by way of the chandler's loft. The pilot's daughter returned a water-stained atlas by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor wrapped the harbourmaster's daybook by way of Gull Stairs. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Old farrow catalogued a parcel of marbled endpapers past the ferry office. The binder mislaid a ledger of soundings to the bindery. Teodor repaired an index nobody had finished from the bindery. You would have laughed; I nearly did. Dr okafor repaired a water-stained atlas from the bindery. I begin to think a catalogue is only a polite way of remembering. Ines repaired a parcel of marbled endpapers by way of Gull Stairs.

It was the first clear morning in a week. Mr calloway found the subscription list from the archive cellar. Dr okafor found a water-stained atlas to Saltmarsh Lane. Old farrow wrapped an index nobody had finished by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter returned a box of unsorted letters past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow wrapped the harbourmaster's daybook from the archive cellar.

— Yours, A.

## Letter 33

*Thursday, from the lower reading room*

A still day, the water like poured lead. The binder returned the second proof to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Ines wrapped a water-stained atlas to the chandler's loft. Wren found a parcel of marbled endpapers by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found the tide tables for the spring from Gull Stairs. I have copied the passage twice and still do not believe it. Old farrow found the tide tables for the spring to the quay.

Rain came in sideways off the bar. Wren repaired a ledger of soundings past the archive cellar. Ines carried the subscription list past the customs shed. Wren mislaid the tide tables for the spring to the lower reading room. Mr calloway copied out a parcel of marbled endpapers from the lower reading room. Ines repaired a water-stained atlas past Gull Stairs. You would have laughed; I nearly did. Wren found a parcel of marbled endpapers from the chandler's loft. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Ines mislaid the subscription list by way of the bindery. If the edition is to be trusted it must say what it changed. The binder wrapped a pamphlet on knots past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow wrapped a box of unsorted letters by way of the lower reading room. I have copied the passage twice and still do not believe it. Ines promised me the second proof to the bindery. You would have laughed; I nearly did.

It was the first clear morning in a week. Ines found the tide tables for the spring to the chandler's loft. You would have laughed; I nearly did. Wren repaired the tide tables for the spring to the archive cellar. The pilot's daughter copied out the harbourmaster's daybook from Saltmarsh Lane.

The tide was late and so was everyone else. Teodor found the tide tables for the spring from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Teodor found the tide tables for the spring by way of the lighthouse landing. The binder found the subscription list by way of the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

— With salt on the page, A.

## Letter 34

*Monday, from the lower reading room*

It was the first clear morning in a week. Dr okafor returned an index nobody had finished to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor carried a ledger of soundings from the lighthouse landing. Mr calloway repaired the harbourmaster's daybook by way of Gull Stairs. Teodor promised me the second proof from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor found the harbourmaster's daybook to the lower reading room. I have copied the passage twice and still do not believe it. Teodor found a parcel of marbled endpapers from the lighthouse landing. You would have laughed; I nearly did.

A still day, the water like poured lead. Teodor promised me a parcel of marbled endpapers to the customs shed. Dr okafor found the second proof to the quay. You would have laughed; I nearly did. Mr calloway carried the second proof from the lower reading room. Ines promised me a ledger of soundings past the lower reading room.

Rain came in sideways off the bar. Dr okafor copied out a ledger of soundings to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Old farrow returned a box of unsorted letters to the archive cellar. Old farrow repaired an index nobody had finished from the customs shed.

Wind from the east, and the shutters complaining. Old farrow carried the subscription list by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway carried a box of unsorted letters past the lower reading room. You would have laughed; I nearly did. Mr calloway wrapped the harbourmaster's daybook from the ferry office.

A still day, the water like poured lead. Old farrow catalogued the harbourmaster's daybook from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Wren returned a pamphlet on knots by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering. Ines found a parcel of marbled endpapers to the ferry office. If the edition is to be trusted it must say what it changed.

— Ever, A.

## Letter 35

*Monday, from the quay*

A still day, the water like poured lead. The binder wrapped a ledger of soundings to the archive cellar. Teodor copied out a box of unsorted letters by way of the bindery. Ines mislaid an index nobody had finished from Saltmarsh Lane. You would have laughed; I nearly did.

A still day, the water like poured lead. The pilot's daughter copied out the second proof from the chandler's loft. The pilot's daughter catalogued the subscription list by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter found the subscription list to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid the tide tables for the spring from the ferry office. If the edition is to be trusted it must say what it changed. The binder catalogued the subscription list from the ferry office. If the edition is to be trusted it must say what it changed. Old farrow catalogued the second proof by way of the quay.

The tide was late and so was everyone else. The binder promised me a parcel of marbled endpapers to the bindery. Mr calloway mislaid a water-stained atlas from the customs shed. Mr calloway copied out a parcel of marbled endpapers to the customs shed.

— Yours, A.

## Letter 36

*Wednesday, from the customs shed*

A still day, the water like poured lead. Ines found the tide tables for the spring from Saltmarsh Lane. Teodor repaired a water-stained atlas past Saltmarsh Lane. Wren copied out an index nobody had finished past Saltmarsh Lane. You would have laughed; I nearly did.

The fog stayed until noon. The pilot's daughter mislaid the second proof from the chandler's loft. Mr calloway found the second proof by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Mr calloway found the harbourmaster's daybook to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. The binder carried a box of unsorted letters past the customs shed. Ines wrapped a water-stained atlas from the archive cellar. Ines found a water-stained atlas from the bindery.

Rain came in sideways off the bar. The pilot's daughter repaired a box of unsorted letters to Gull Stairs. Wren mislaid the tide tables for the spring to the ferry office. Mr calloway returned a water-stained atlas past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway wrapped the tide tables for the spring to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Ines found an index nobody had finished by way of the lower reading room. If the edition is to be trusted it must say what it changed.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 37

*Thursday, from the customs shed*

The tide was late and so was everyone else. Old farrow wrapped the harbourmaster's daybook past the lighthouse landing. Mr calloway wrapped a pamphlet on knots from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter promised me a pamphlet on knots to Gull Stairs. Old farrow repaired the second proof past the lower reading room. Dr okafor found a ledger of soundings past the ferry office. I have copied the passage twice and still do not believe it. The binder repaired the tide tables for the spring to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. The binder found a pamphlet on knots by way of the customs shed. You would have laughed; I nearly did. The pilot's daughter found the harbourmaster's daybook past the lighthouse landing. I have copied the passage twice and still do not believe it. Ines repaired a ledger of soundings past the quay. Mr calloway promised me a parcel of marbled endpapers to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Ines mislaid a box of unsorted letters to the quay. Old farrow promised me the second proof from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. The pilot's daughter catalogued the harbourmaster's daybook past the quay. Ines mislaid a pamphlet on knots to the customs shed. Teodor catalogued a parcel of marbled endpapers to the lower reading room. Mr calloway copied out a pamphlet on knots by way of the lower reading room. The pilot's daughter carried an index nobody had finished to Gull Stairs. You would have laughed; I nearly did.

— Yours in haste, A.

## Letter 38

*Friday, from Gull Stairs*

Rain came in sideways off the bar. The binder copied out a parcel of marbled endpapers past the lighthouse landing. Dr okafor returned a water-stained atlas to the ferry office. If the edition is to be trusted it must say what it changed. The binder returned the subscription list to the archive cellar. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. Dr okafor returned the harbourmaster's daybook past the chandler's loft. I have copied the passage twice and still do not believe it. Mr calloway returned a water-stained atlas past the customs shed. I begin to think a catalogue is only a polite way of remembering. Ines copied out the harbourmaster's daybook by way of Saltmarsh Lane. Dr okafor found the subscription list past the bindery.

A still day, the water like poured lead. Teodor catalogued a pamphlet on knots by way of the ferry office. Mr calloway wrapped the harbourmaster's daybook by way of the archive cellar. You would have laughed; I nearly did. Wren catalogued an index nobody had finished by way of the ferry office. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 39

*Friday, from the lighthouse landing*

A still day, the water like poured lead. Ines promised me a pamphlet on knots by way of Saltmarsh Lane. The pilot's daughter catalogued an index nobody had finished from the lower reading room. Dr okafor returned the second proof by way of Gull Stairs. If the edition is to be trusted it must say what it changed. The pilot's daughter returned the second proof to the bindery. I have copied the passage twice and still do not believe it. The binder wrapped a parcel of marbled endpapers past the customs shed.

The tide was late and so was everyone else. The pilot's daughter mislaid an index nobody had finished by way of Saltmarsh Lane. Ines returned an index nobody had finished by way of the customs shed. Wren repaired the second proof to the archive cellar. Mr calloway mislaid a water-stained atlas by way of Saltmarsh Lane. Teodor carried the second proof from the archive cellar.

A still day, the water like poured lead. Ines found a ledger of soundings to the customs shed. Ines returned the second proof to the bindery. Mr calloway carried a ledger of soundings from the customs shed. Mr calloway returned a pamphlet on knots by way of the customs shed. The pilot's daughter copied out an index nobody had finished past the bindery. I begin to think a catalogue is only a polite way of remembering.

— With salt on the page, A.

## Letter 40

*Tuesday, from the bindery*

The fog stayed until noon. Wren returned the tide tables for the spring by way of the ferry office. Mr calloway repaired a ledger of soundings to the chandler's loft. You would have laughed; I nearly did. Ines catalogued a water-stained atlas from the lighthouse landing. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Teodor promised me the second proof from the lighthouse landing. The binder carried the second proof to the customs shed. Teodor catalogued a water-stained atlas past the ferry office. Ines carried the second proof from the lower reading room.

Rain came in sideways off the bar. Mr calloway returned the second proof by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me the tide tables for the spring by way of the chandler's loft. You would have laughed; I nearly did. Wren carried a parcel of marbled endpapers by way of the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway returned a box of unsorted letters to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired the subscription list by way of the lighthouse landing. Old farrow found the harbourmaster's daybook past the chandler's loft.

— With salt on the page, A.

## Letter 41

*Friday, from the lower reading room*

It was the first clear morning in a week. Dr okafor mislaid the subscription list past Gull Stairs. Old farrow promised me the harbourmaster's daybook by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. The binder found a pamphlet on knots from the bindery. The pilot's daughter wrapped the subscription list from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines carried a water-stained atlas to the ferry office. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter returned the subscription list past Saltmarsh Lane. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. The pilot's daughter found the second proof past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor promised me the second proof to the archive cellar. Teodor wrapped the second proof to the lower reading room. Teodor found the subscription list by way of the lower reading room. I have copied the passage twice and still do not believe it. Teodor returned a parcel of marbled endpapers by way of Gull Stairs. You would have laughed; I nearly did.

It was the first clear morning in a week. Dr okafor carried a ledger of soundings to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Ines carried the tide tables for the spring to Gull Stairs. Wren mislaid a water-stained atlas by way of the archive cellar. If the edition is to be trusted it must say what it changed. Wren found the second proof from the chandler's loft.

Wind from the east, and the shutters complaining. Ines returned a box of unsorted letters by way of the bindery. The pilot's daughter wrapped an index nobody had finished by way of Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter carried the tide tables for the spring to Gull Stairs. The binder repaired a ledger of soundings past Gull Stairs.

— Yours, A.

## Letter 42

*Tuesday, from Gull Stairs*

Rain came in sideways off the bar. Old farrow found the tide tables for the spring from the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me a ledger of soundings to the lighthouse landing. Wren promised me an index nobody had finished by way of the archive cellar.

It was the first clear morning in a week. The pilot's daughter found a parcel of marbled endpapers from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway catalogued the second proof by way of the ferry office. You would have laughed; I nearly did. Old farrow carried a pamphlet on knots past the quay. Dr okafor found a box of unsorted letters by way of the ferry office. The pilot's daughter found the second proof from the lower reading room. You would have laughed; I nearly did.

The tide was late and so was everyone else. Dr okafor found an index nobody had finished to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The binder promised me the subscription list from Saltmarsh Lane. Dr okafor repaired a box of unsorted letters to the quay. Old farrow mislaid a ledger of soundings from the lower reading room.

Wind from the east, and the shutters complaining. Teodor returned the subscription list to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Ines wrapped a box of unsorted letters by way of the archive cellar. If the edition is to be trusted it must say what it changed. Mr calloway repaired a pamphlet on knots from the customs shed. The pilot's daughter returned the second proof by way of the lower reading room.

— Ever, A.

## Letter 43

*Tuesday, from the archive cellar*

Rain came in sideways off the bar. Teodor catalogued a water-stained atlas past the ferry office. I begin to think a catalogue is only a polite way of remembering. Teodor found the harbourmaster's daybook past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway repaired the tide tables for the spring past the lower reading room.

Rain came in sideways off the bar. Dr okafor mislaid a parcel of marbled endpapers past the bindery. You would have laughed; I nearly did. Mr calloway promised me the harbourmaster's daybook to the lower reading room. Old farrow repaired a water-stained atlas to the chandler's loft. Teodor promised me a pamphlet on knots by way of the lighthouse landing.

The tide was late and so was everyone else. The binder catalogued the harbourmaster's daybook by way of the chandler's loft. Dr okafor found the tide tables for the spring past Gull Stairs. You would have laughed; I nearly did. Dr okafor returned a pamphlet on knots from the quay. Teodor mislaid the subscription list past the chandler's loft.

— Ever, A.

## Letter 44

*Friday, from the quay*

Rain came in sideways off the bar. Dr okafor mislaid a parcel of marbled endpapers to Gull Stairs. The binder repaired the subscription list past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Ines mislaid a pamphlet on knots past the lighthouse landing. I have copied the passage twice and still do not believe it. Ines mislaid the subscription list by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor copied out a ledger of soundings by way of the chandler's loft. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Wren mislaid a water-stained atlas past Saltmarsh Lane. Dr okafor carried the harbourmaster's daybook to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The binder copied out the second proof to the quay. I begin to think a catalogue is only a polite way of remembering.

A still day, the water like poured lead. The binder repaired the subscription list from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Ines promised me an index nobody had finished past the customs shed. The binder returned a water-stained atlas from the customs shed. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. The pilot's daughter returned the harbourmaster's daybook past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter catalogued the tide tables for the spring from the chandler's loft. If the edition is to be trusted it must say what it changed. Wren promised me the second proof past the quay.

A still day, the water like poured lead. The binder returned a box of unsorted letters by way of the quay. I have copied the passage twice and still do not believe it. Ines promised me the subscription list from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped the subscription list to the quay. The binder promised me a box of unsorted letters past Saltmarsh Lane.

— Yours in haste, A.

## Letter 45

*Friday, from the ferry office*

It was the first clear morning in a week. Mr calloway wrapped an index nobody had finished by way of the lighthouse landing. The binder mislaid an index nobody had finished to the bindery. Mr calloway carried a parcel of marbled endpapers by way of Gull Stairs. Wren mislaid a box of unsorted letters past the bindery. Old farrow promised me a ledger of soundings to the chandler's loft. Dr okafor copied out a parcel of marbled endpapers past the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Wren found a parcel of marbled endpapers past the lighthouse landing. Wren found a pamphlet on knots by way of the customs shed. You would have laughed; I nearly did. Wren catalogued the harbourmaster's daybook by way of the bindery. Mr calloway repaired the subscription list past the archive cellar. Wren promised me the tide tables for the spring past the lighthouse landing. Ines returned a water-stained atlas from the archive cellar.

Wind from the east, and the shutters complaining. The pilot's daughter wrapped the second proof by way of the ferry office. If the edition is to be trusted it must say what it changed. Ines found the harbourmaster's daybook from the lower reading room. Teodor found a water-stained atlas by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned the subscription list by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 46

*Tuesday, from the bindery*

The fog stayed until noon. The binder copied out the harbourmaster's daybook past the ferry office. Teodor catalogued the harbourmaster's daybook past the lighthouse landing. Ines wrapped the second proof past the lighthouse landing. Mr calloway copied out a box of unsorted letters from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. Teodor promised me a water-stained atlas by way of the customs shed. The pilot's daughter returned the tide tables for the spring from Gull Stairs. I begin to think a catalogue is only a polite way of remembering. The binder promised me a parcel of marbled endpapers by way of Gull Stairs. I have copied the passage twice and still do not believe it. The binder mislaid a ledger of soundings by way of the lower reading room. Wren promised me the tide tables for the spring by way of the lighthouse landing. Mr calloway repaired a box of unsorted letters by way of the lower reading room.

It was the first clear morning in a week. Mr calloway found an index nobody had finished from the lower reading room. Mr calloway repaired the subscription list from the lower reading room. Wren found the second proof from the bindery. If the edition is to be trusted it must say what it changed. Old farrow copied out the tide tables for the spring from the ferry office. You would have laughed; I nearly did. The binder carried a parcel of marbled endpapers to Saltmarsh Lane.

Rain came in sideways off the bar. Mr calloway found a water-stained atlas by way of the chandler's loft. You would have laughed; I nearly did. Ines found a parcel of marbled endpapers past the customs shed. Wren repaired a box of unsorted letters past Gull Stairs.

— Yours in haste, A.

## Letter 47

*Monday, from the quay*

Wind from the east, and the shutters complaining. The binder mislaid the tide tables for the spring to Gull Stairs. The pilot's daughter copied out the subscription list to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow found a box of unsorted letters by way of the ferry office. Old farrow repaired a pamphlet on knots past the lighthouse landing. Ines carried the second proof past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Mr calloway mislaid the second proof from the lighthouse landing.

The tide was late and so was everyone else. Teodor carried the second proof from the lighthouse landing. Mr calloway carried a parcel of marbled endpapers to the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter found the tide tables for the spring from the chandler's loft. Old farrow repaired a pamphlet on knots to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. The pilot's daughter found the subscription list past Saltmarsh Lane.

The tide was late and so was everyone else. The binder carried a water-stained atlas from Gull Stairs. I have copied the passage twice and still do not believe it. Mr calloway repaired an index nobody had finished to the lower reading room. Dr okafor copied out a pamphlet on knots from the lower reading room.

The fog stayed until noon. Dr okafor found the second proof past the customs shed. Wren mislaid the tide tables for the spring to the bindery. The pilot's daughter catalogued a ledger of soundings past the chandler's loft. Dr okafor found a box of unsorted letters from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

## Letter 48

*Monday, from the chandler's loft*

A still day, the water like poured lead. Wren catalogued the harbourmaster's daybook past the archive cellar. Wren found a parcel of marbled endpapers past Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Dr okafor returned a ledger of soundings to the archive cellar. Ines found the harbourmaster's daybook by way of the lower reading room. I have copied the passage twice and still do not believe it. Wren mislaid a box of unsorted letters by way of the chandler's loft. Wren returned a pamphlet on knots past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Mr calloway returned a water-stained atlas from the customs shed. Old farrow catalogued a ledger of soundings to the quay. Old farrow copied out a parcel of marbled endpapers by way of the ferry office. Teodor repaired the second proof by way of the ferry office. You would have laughed; I nearly did. The pilot's daughter returned the tide tables for the spring by way of the ferry office. Mr calloway copied out the subscription list to the ferry office. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Ines repaired a water-stained atlas by way of the customs shed. Teodor mislaid the subscription list past the lower reading room. Dr okafor repaired a water-stained atlas by way of the chandler's loft. Ines copied out a pamphlet on knots by way of the lower reading room.

It was the first clear morning in a week. Teodor mislaid the harbourmaster's daybook by way of the lower reading room. Dr okafor copied out the tide tables for the spring from the bindery. The pilot's daughter mislaid an index nobody had finished from the chandler's loft. Wren catalogued the tide tables for the spring by way of the lighthouse landing. You would have laughed; I nearly did. The binder promised me the harbourmaster's daybook by way of the lower reading room. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. The pilot's daughter wrapped a pamphlet on knots by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The binder returned the tide tables for the spring by way of the quay. Mr calloway mislaid a ledger of soundings to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. The binder mislaid the subscription list from the customs shed.

— Yours, A.

## Letter 49

*Friday, from the chandler's loft*

It was the first clear morning in a week. Dr okafor wrapped a box of unsorted letters past the quay. Old farrow mislaid the tide tables for the spring to the quay. Mr calloway catalogued a ledger of soundings to the bindery. You would have laughed; I nearly did.

Rain came in sideways off the bar. Teodor mislaid the harbourmaster's daybook from the archive cellar. You would have laughed; I nearly did. Old farrow repaired a pamphlet on knots from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid a ledger of soundings to the customs shed. If the edition is to be trusted it must say what it changed. Mr calloway wrapped the second proof by way of the archive cellar. You would have laughed; I nearly did.

The fog stayed until noon. Wren promised me a pamphlet on knots past the quay. If the edition is to be trusted it must say what it changed. Teodor catalogued a parcel of marbled endpapers to the archive cellar. Dr okafor returned the harbourmaster's daybook by way of the lighthouse landing. Old farrow copied out a pamphlet on knots to the quay. I begin to think a catalogue is only a polite way of remembering. The binder mislaid a ledger of soundings past the chandler's loft.

It was the first clear morning in a week. The pilot's daughter returned the harbourmaster's daybook past the customs shed. I have copied the passage twice and still do not believe it. Mr calloway catalogued an index nobody had finished by way of Gull Stairs. Wren copied out the harbourmaster's daybook by way of the customs shed. I have copied the passage twice and still do not believe it. The pilot's daughter returned the tide tables for the spring from Gull Stairs. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter catalogued an index nobody had finished from Saltmarsh Lane.

Rain came in sideways off the bar. The pilot's daughter wrapped a water-stained atlas to Saltmarsh Lane. Teodor returned the tide tables for the spring from the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor carried a pamphlet on knots past the lower reading room. Old farrow returned a box of unsorted letters by way of the ferry office. I have copied the passage twice and still do not believe it. The binder repaired the tide tables for the spring by way of the ferry office. Teodor found a box of unsorted letters by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

— Ever, A.

## Letter 50

*Thursday, from Gull Stairs*

Rain came in sideways off the bar. Teodor promised me the subscription list to the quay. Old farrow found a parcel of marbled endpapers from the archive cellar. The binder copied out the harbourmaster's daybook to the ferry office. I have copied the passage twice and still do not believe it. Mr calloway promised me the harbourmaster's daybook past the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway mislaid the tide tables for the spring from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. Old farrow carried a box of unsorted letters by way of the bindery. You would have laughed; I nearly did. Old farrow catalogued a pamphlet on knots by way of the ferry office. Ines copied out the second proof by way of the customs shed.

A still day, the water like poured lead. The binder wrapped the subscription list past the chandler's loft. Teodor catalogued the second proof by way of the bindery. Mr calloway returned a water-stained atlas past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid a pamphlet on knots by way of the ferry office. The pilot's daughter wrapped the second proof to Gull Stairs. Dr okafor returned the subscription list to the chandler's loft.

The tide was late and so was everyone else. Mr calloway catalogued the tide tables for the spring from the bindery. You would have laughed; I nearly did. Old farrow promised me a water-stained atlas past the archive cellar. Mr calloway mislaid an index nobody had finished from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The binder returned a water-stained atlas from the chandler's loft.

The tide was late and so was everyone else. Mr calloway found a box of unsorted letters past Saltmarsh Lane. The binder mislaid the second proof past the chandler's loft. I begin to think a catalogue is only a polite way of remembering. The binder catalogued a box of unsorted letters past the archive cellar. Teodor repaired a pamphlet on knots from the quay. Mr calloway promised me a ledger of soundings from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway returned the tide tables for the spring by way of the customs shed.

— Yours in haste, A.

## Letter 51

*Tuesday, from the bindery*

It was the first clear morning in a week. Ines carried the second proof to the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow copied out a pamphlet on knots to the bindery. If the edition is to be trusted it must say what it changed. Mr calloway mislaid the second proof past the customs shed.

The fog stayed until noon. The pilot's daughter found a pamphlet on knots past the quay. Mr calloway mislaid a ledger of soundings by way of the chandler's loft. I have copied the passage twice and still do not believe it. Dr okafor catalogued a water-stained atlas past the customs shed.

Wind from the east, and the shutters complaining. Dr okafor repaired a pamphlet on knots by way of Saltmarsh Lane. Dr okafor catalogued a ledger of soundings to the lighthouse landing. Mr calloway repaired the subscription list from the customs shed. Dr okafor carried a ledger of soundings by way of the lighthouse landing. Mr calloway promised me a box of unsorted letters by way of the chandler's loft. Mr calloway returned an index nobody had finished from the bindery. If the edition is to be trusted it must say what it changed.

— With salt on the page, A.

## Letter 52

*Friday, from the archive cellar*

It was the first clear morning in a week. The binder carried the harbourmaster's daybook by way of the quay. Wren repaired a box of unsorted letters from the customs shed. Old farrow copied out a ledger of soundings by way of Saltmarsh Lane.

A still day, the water like poured lead. Old farrow found the subscription list past the bindery. Teodor wrapped the harbourmaster's daybook past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter promised me an index nobody had finished past the ferry office. Wren found a parcel of marbled endpapers from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. The binder promised me an index nobody had finished by way of Gull Stairs. I have copied the passage twice and still do not believe it. The binder wrapped a box of unsorted letters by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. Ines promised me a water-stained atlas past the customs shed. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out the subscription list from the chandler's loft. If the edition is to be trusted it must say what it changed. Old farrow carried a ledger of soundings to the ferry office. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 53

*Friday, from the lower reading room*

Wind from the east, and the shutters complaining. The binder copied out an index nobody had finished past the bindery. The pilot's daughter carried a parcel of marbled endpapers from the ferry office. Dr okafor copied out a parcel of marbled endpapers from the customs shed. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Wren promised me a water-stained atlas to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor mislaid a water-stained atlas by way of the ferry office. I have copied the passage twice and still do not believe it. Teodor mislaid the second proof by way of the customs shed. I have copied the passage twice and still do not believe it. Wren copied out the tide tables for the spring to the chandler's loft.

Wind from the east, and the shutters complaining. Mr calloway wrapped a pamphlet on knots by way of the archive cellar. The binder repaired a box of unsorted letters from the customs shed. You would have laughed; I nearly did. The binder mislaid a water-stained atlas to the chandler's loft. Old farrow copied out the harbourmaster's daybook to the lighthouse landing. Dr okafor carried the second proof past the chandler's loft.

Rain came in sideways off the bar. Wren wrapped a parcel of marbled endpapers past the ferry office. If the edition is to be trusted it must say what it changed. The binder repaired the tide tables for the spring past the quay. Mr calloway found the subscription list to Gull Stairs. Wren promised me a pamphlet on knots by way of the bindery. The binder repaired a box of unsorted letters to the customs shed. I have copied the passage twice and still do not believe it.

Wind from the east, and the shutters complaining. Teodor mislaid the harbourmaster's daybook to Saltmarsh Lane. Mr calloway mislaid a water-stained atlas by way of the customs shed. If the edition is to be trusted it must say what it changed. Ines wrapped the second proof past the lighthouse landing. You would have laughed; I nearly did. Dr okafor carried the harbourmaster's daybook to the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 54

*Thursday, from the chandler's loft*

A still day, the water like poured lead. Mr calloway promised me a water-stained atlas to the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow carried a parcel of marbled endpapers past the ferry office. If the edition is to be trusted it must say what it changed. The binder repaired a pamphlet on knots by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Dr okafor catalogued a water-stained atlas by way of the quay. The pilot's daughter repaired the harbourmaster's daybook from Gull Stairs. You would have laughed; I nearly did. Wren copied out an index nobody had finished past the lighthouse landing. The pilot's daughter found a parcel of marbled endpapers to the customs shed. You would have laughed; I nearly did. The binder catalogued a box of unsorted letters to the lighthouse landing.

Rain came in sideways off the bar. Teodor promised me a ledger of soundings to the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me a ledger of soundings from the lighthouse landing. Old farrow wrapped the second proof to the quay. Mr calloway mislaid a water-stained atlas past the chandler's loft. You would have laughed; I nearly did. Ines mislaid a ledger of soundings past the lower reading room. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. Ines wrapped a pamphlet on knots past Gull Stairs. Dr okafor mislaid a ledger of soundings past the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor repaired the subscription list past the customs shed.

The tide was late and so was everyone else. Teodor wrapped the subscription list from the customs shed. Teodor copied out a ledger of soundings past the archive cellar. I begin to think a catalogue is only a polite way of remembering. Teodor catalogued the tide tables for the spring past the chandler's loft. You would have laughed; I nearly did.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 55

*Wednesday, from the bindery*

Rain came in sideways off the bar. Ines wrapped a pamphlet on knots to the archive cellar. Wren repaired a ledger of soundings by way of the quay. You would have laughed; I nearly did. Ines catalogued a ledger of soundings to the bindery. If the edition is to be trusted it must say what it changed. Mr calloway repaired a parcel of marbled endpapers by way of the archive cellar. Old farrow catalogued a pamphlet on knots past Gull Stairs. If the edition is to be trusted it must say what it changed. The binder repaired a water-stained atlas by way of the quay.

The tide was late and so was everyone else. Old farrow returned a ledger of soundings past the ferry office. Old farrow mislaid the tide tables for the spring from Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Ines found a pamphlet on knots to the lighthouse landing.

The fog stayed until noon. The binder copied out the second proof from the quay. Wren found a box of unsorted letters past the ferry office. The pilot's daughter returned a box of unsorted letters by way of the chandler's loft. Teodor copied out a water-stained atlas to Saltmarsh Lane.

It was the first clear morning in a week. Mr calloway carried the harbourmaster's daybook to the bindery. Wren mislaid the harbourmaster's daybook by way of the lighthouse landing. The binder promised me the harbourmaster's daybook from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The binder catalogued the harbourmaster's daybook from the customs shed.

The tide was late and so was everyone else. The binder catalogued a pamphlet on knots from the chandler's loft. Old farrow carried an index nobody had finished by way of the lower reading room. If the edition is to be trusted it must say what it changed. The pilot's daughter promised me the subscription list by way of Saltmarsh Lane.

— Yours in haste, A.

## Letter 56

*Wednesday, from the chandler's loft*

It was the first clear morning in a week. Mr calloway wrapped the tide tables for the spring past the bindery. You would have laughed; I nearly did. Teodor copied out an index nobody had finished from the customs shed. I have copied the passage twice and still do not believe it. Teodor wrapped a water-stained atlas past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. Dr okafor catalogued a ledger of soundings past the chandler's loft. The pilot's daughter wrapped the harbourmaster's daybook from the chandler's loft. Wren wrapped the subscription list to the bindery. If the edition is to be trusted it must say what it changed. Wren promised me a parcel of marbled endpapers to Saltmarsh Lane.

A still day, the water like poured lead. Dr okafor carried a water-stained atlas past Gull Stairs. Mr calloway wrapped a ledger of soundings past the chandler's loft. Old farrow found the second proof by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Dr okafor mislaid an index nobody had finished from the lower reading room. I have copied the passage twice and still do not believe it. Old farrow promised me an index nobody had finished by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway repaired the subscription list past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor promised me a ledger of soundings past the archive cellar. Ines returned a ledger of soundings by way of the bindery. Mr calloway catalogued a pamphlet on knots by way of the lighthouse landing.

— Yours, A.

## Letter 57

*Friday, from the customs shed*

A still day, the water like poured lead. The binder catalogued the harbourmaster's daybook past Saltmarsh Lane. Wren mislaid the harbourmaster's daybook to the ferry office. If the edition is to be trusted it must say what it changed. Mr calloway found a ledger of soundings from the lighthouse landing. You would have laughed; I nearly did.

The tide was late and so was everyone else. The pilot's daughter promised me the second proof by way of Saltmarsh Lane. The binder promised me the tide tables for the spring to the archive cellar. Dr okafor repaired the harbourmaster's daybook to the bindery. Wren repaired the second proof from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter carried a ledger of soundings past the chandler's loft.

A still day, the water like poured lead. Wren promised me the second proof to the bindery. You would have laughed; I nearly did. The pilot's daughter repaired a pamphlet on knots by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Ines repaired an index nobody had finished by way of the lighthouse landing. You would have laughed; I nearly did. Mr calloway promised me a ledger of soundings past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Wren copied out a box of unsorted letters past the archive cellar.

— Ever, A.

## Letter 58

*Wednesday, from the ferry office*

Wind from the east, and the shutters complaining. Mr calloway copied out an index nobody had finished by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway returned a box of unsorted letters past the bindery. I have copied the passage twice and still do not believe it. The binder found a water-stained atlas by way of the ferry office. You would have laughed; I nearly did. Teodor copied out the subscription list by way of the bindery.

A still day, the water like poured lead. Mr calloway mislaid the second proof by way of the lower reading room. Wren mislaid a ledger of soundings by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. The binder catalogued the tide tables for the spring from Gull Stairs. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Wren found a parcel of marbled endpapers past the lighthouse landing. I have copied the passage twice and still do not believe it. Ines mislaid an index nobody had finished by way of the ferry office. If the edition is to be trusted it must say what it changed. The pilot's daughter returned the second proof by way of the archive cellar. Mr calloway catalogued the second proof from the lower reading room. Mr calloway returned the subscription list past Gull Stairs. The pilot's daughter carried the second proof to the chandler's loft.

The tide was late and so was everyone else. Ines mislaid a ledger of soundings from the bindery. If the edition is to be trusted it must say what it changed. The binder repaired the subscription list to the customs shed. The binder wrapped a box of unsorted letters by way of the lower reading room. The pilot's daughter promised me the harbourmaster's daybook past Gull Stairs.

— Ever, A.

## Letter 59

*Wednesday, from the quay*

The tide was late and so was everyone else. Mr calloway repaired the subscription list from the lighthouse landing. Mr calloway found the tide tables for the spring to the customs shed. I have copied the passage twice and still do not believe it. The pilot's daughter mislaid the harbourmaster's daybook past the customs shed. Ines copied out an index nobody had finished past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Mr calloway promised me a box of unsorted letters from the lower reading room. Dr okafor catalogued the harbourmaster's daybook from the ferry office. Ines returned a ledger of soundings past the lighthouse landing.

A still day, the water like poured lead. Wren carried an index nobody had finished by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor catalogued the second proof to Saltmarsh Lane. You would have laughed; I nearly did. Wren returned a pamphlet on knots past Gull Stairs. Ines wrapped an index nobody had finished from the ferry office. Old farrow promised me a parcel of marbled endpapers from the chandler's loft.

The tide was late and so was everyone else. The binder returned the subscription list past Saltmarsh Lane. Dr okafor copied out a water-stained atlas from the lower reading room. You would have laughed; I nearly did. The pilot's daughter found the subscription list to the ferry office. I begin to think a catalogue is only a polite way of remembering. Old farrow mislaid the second proof by way of the lower reading room. If the edition is to be trusted it must say what it changed. The binder carried the harbourmaster's daybook past the lighthouse landing. Mr calloway wrapped a water-stained atlas to Saltmarsh Lane.

— Yours, A.

## Letter 60

*Thursday, from Saltmarsh Lane*

It was the first clear morning in a week. The pilot's daughter found the second proof past the customs shed. You would have laughed; I nearly did. The pilot's daughter repaired the subscription list to the quay. Ines promised me a parcel of marbled endpapers past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor wrapped the harbourmaster's daybook past the lower reading room.

It was the first clear morning in a week. The binder wrapped a water-stained atlas by way of the bindery. Old farrow promised me a ledger of soundings by way of the customs shed. If the edition is to be trusted it must say what it changed. The binder found the tide tables for the spring from the lower reading room. The binder carried a water-stained atlas past Gull Stairs. Mr calloway catalogued a pamphlet on knots by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway returned the tide tables for the spring from Gull Stairs.

A still day, the water like poured lead. The binder carried an index nobody had finished to the customs shed. Teodor promised me a parcel of marbled endpapers to the customs shed. Ines wrapped an index nobody had finished to the ferry office. Old farrow catalogued a pamphlet on knots by way of the lower reading room. The pilot's daughter found a pamphlet on knots to the ferry office. You would have laughed; I nearly did. Old farrow mislaid a parcel of marbled endpapers from the customs shed. I have copied the passage twice and still do not believe it.

— Ever, A.

## Letter 61

*Friday, from Gull Stairs*

The tide was late and so was everyone else. The pilot's daughter repaired the second proof to the bindery. The binder repaired a water-stained atlas by way of the archive cellar. Teodor returned a water-stained atlas by way of the lighthouse landing. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Teodor returned the second proof by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor promised me an index nobody had finished to Gull Stairs. Dr okafor copied out a box of unsorted letters by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. The binder returned the tide tables for the spring past the ferry office.

Rain came in sideways off the bar. The binder mislaid the subscription list by way of the quay. Dr okafor returned the harbourmaster's daybook by way of the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor mislaid a parcel of marbled endpapers to the bindery. The pilot's daughter carried a parcel of marbled endpapers from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

## Letter 62

*Friday, from the customs shed*

Wind from the east, and the shutters complaining. Mr calloway catalogued a pamphlet on knots by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Wren found an index nobody had finished by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Mr calloway mislaid a water-stained atlas by way of the bindery. Mr calloway carried the harbourmaster's daybook past Gull Stairs. Dr okafor mislaid a water-stained atlas to Saltmarsh Lane. Wren returned a parcel of marbled endpapers from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

It was the first clear morning in a week. The binder repaired an index nobody had finished past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines mislaid a box of unsorted letters from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. The binder copied out a water-stained atlas from the ferry office. Dr okafor returned the subscription list by way of Gull Stairs. If the edition is to be trusted it must say what it changed. The binder promised me an index nobody had finished to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter repaired the second proof past Gull Stairs.

The fog stayed until noon. Teodor found the subscription list from the archive cellar. I begin to think a catalogue is only a polite way of remembering. The binder mislaid the tide tables for the spring past the quay. Old farrow returned an index nobody had finished by way of Gull Stairs. You would have laughed; I nearly did. Wren found the tide tables for the spring by way of Gull Stairs. Teodor promised me a ledger of soundings by way of the bindery. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Ines mislaid the subscription list past Gull Stairs. The pilot's daughter promised me a water-stained atlas to the customs shed. Wren found the second proof past the quay. I have copied the passage twice and still do not believe it. Wren repaired the subscription list to the chandler's loft. Old farrow returned the second proof from Saltmarsh Lane.

The tide was late and so was everyone else. Mr calloway carried the second proof from the lower reading room. The binder wrapped the subscription list to Saltmarsh Lane. Dr okafor promised me a water-stained atlas from the lower reading room.

— With salt on the page, A.

## Letter 63

*Friday, from the lighthouse landing*

It was the first clear morning in a week. The binder promised me a box of unsorted letters by way of the quay. Teodor repaired the subscription list to the quay. You would have laughed; I nearly did. Dr okafor mislaid a parcel of marbled endpapers from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Teodor found the harbourmaster's daybook past Gull Stairs. You would have laughed; I nearly did. Teodor found a pamphlet on knots past the archive cellar. I have copied the passage twice and still do not believe it. The pilot's daughter promised me the second proof past the customs shed. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. Dr okafor catalogued the second proof to the lower reading room. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out a water-stained atlas from the quay. Wren repaired an index nobody had finished by way of the archive cellar. The binder promised me a pamphlet on knots past the bindery. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. The binder repaired a ledger of soundings past Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow mislaid a ledger of soundings by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter mislaid the tide tables for the spring by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me the subscription list by way of the lower reading room. Old farrow carried the tide tables for the spring to the chandler's loft.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 64

*Wednesday, from the ferry office*

The fog stayed until noon. The pilot's daughter found a parcel of marbled endpapers past the archive cellar. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped a ledger of soundings by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Ines catalogued the subscription list past the customs shed. The pilot's daughter found the subscription list by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Teodor promised me the second proof to the ferry office.

Wind from the east, and the shutters complaining. Teodor copied out an index nobody had finished to the customs shed. Ines repaired the subscription list from Saltmarsh Lane. Teodor mislaid a box of unsorted letters past the chandler's loft. Wren wrapped the second proof from the customs shed. The binder returned a water-stained atlas past the archive cellar.

A still day, the water like poured lead. Ines carried a parcel of marbled endpapers by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Wren catalogued the second proof from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway found the second proof to the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped the tide tables for the spring past Saltmarsh Lane.

— Yours, A.

## Letter 65

*Tuesday, from Gull Stairs*

The tide was late and so was everyone else. Old farrow found a pamphlet on knots past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter returned the harbourmaster's daybook past the lighthouse landing. Dr okafor returned a parcel of marbled endpapers past the lighthouse landing. If the edition is to be trusted it must say what it changed. Wren repaired the harbourmaster's daybook to Gull Stairs. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Mr calloway promised me an index nobody had finished past the chandler's loft. The binder catalogued the second proof by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow promised me a box of unsorted letters past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Ines repaired an index nobody had finished to the quay.

A still day, the water like poured lead. Mr calloway mislaid an index nobody had finished by way of the lower reading room. I have copied the passage twice and still do not believe it. Mr calloway repaired a water-stained atlas to the quay. The pilot's daughter repaired a ledger of soundings from the bindery. You would have laughed; I nearly did. Old farrow carried an index nobody had finished past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

A still day, the water like poured lead. The binder carried a box of unsorted letters past Gull Stairs. Teodor carried a water-stained atlas by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Teodor carried the subscription list past the customs shed. Teodor found the harbourmaster's daybook by way of the quay. I have copied the passage twice and still do not believe it. Mr calloway wrapped the second proof from Gull Stairs. Dr okafor returned the subscription list from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

— Ever, A.

## Letter 66

*Tuesday, from Gull Stairs*

The tide was late and so was everyone else. The pilot's daughter wrapped a box of unsorted letters past the lower reading room. Ines catalogued the tide tables for the spring past the lower reading room. Mr calloway copied out a ledger of soundings by way of the chandler's loft.

The tide was late and so was everyone else. Old farrow found the harbourmaster's daybook from the bindery. Teodor carried the harbourmaster's daybook from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway wrapped an index nobody had finished to the bindery. You would have laughed; I nearly did. The pilot's daughter promised me a box of unsorted letters past the bindery. Teodor carried a water-stained atlas to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter carried the subscription list to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Ines returned a pamphlet on knots to the quay. The pilot's daughter wrapped the second proof past the quay. Mr calloway mislaid a box of unsorted letters past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. The binder carried the subscription list by way of the archive cellar.

The fog stayed until noon. Old farrow promised me a pamphlet on knots to the lighthouse landing. Old farrow repaired a pamphlet on knots from the quay. I have copied the passage twice and still do not believe it. Mr calloway wrapped the subscription list from the quay. I have copied the passage twice and still do not believe it. Wren found the harbourmaster's daybook to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours, A.

## Letter 67

*Wednesday, from the lower reading room*

The tide was late and so was everyone else. Dr okafor catalogued a water-stained atlas past the chandler's loft. I have copied the passage twice and still do not believe it. The binder returned a box of unsorted letters by way of Saltmarsh Lane. The binder repaired the second proof past the ferry office.

Rain came in sideways off the bar. The binder returned an index nobody had finished from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow catalogued the harbourmaster's daybook from the quay. Old farrow found the tide tables for the spring to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter wrapped a parcel of marbled endpapers past the ferry office.

A still day, the water like poured lead. Ines copied out the second proof to Saltmarsh Lane. Teodor catalogued an index nobody had finished past the lower reading room. Old farrow promised me an index nobody had finished past the bindery. Dr okafor copied out a pamphlet on knots from the lighthouse landing.

Wind from the east, and the shutters complaining. Teodor returned the subscription list by way of the bindery. If the edition is to be trusted it must say what it changed. Old farrow found a box of unsorted letters past the lighthouse landing. Teodor repaired a water-stained atlas by way of the chandler's loft.

— Yours, A.

## Letter 68

*Monday, from the ferry office*

It was the first clear morning in a week. The binder mislaid the tide tables for the spring by way of the chandler's loft. Ines returned a box of unsorted letters to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor returned a parcel of marbled endpapers past the archive cellar. Ines catalogued the tide tables for the spring from Saltmarsh Lane. Old farrow copied out the tide tables for the spring past the lighthouse landing. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. Wren repaired the second proof to the lighthouse landing. If the edition is to be trusted it must say what it changed. Old farrow catalogued a pamphlet on knots from the chandler's loft. Wren found the harbourmaster's daybook from Gull Stairs. Mr calloway promised me the harbourmaster's daybook past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Ines returned the second proof past the archive cellar. If the edition is to be trusted it must say what it changed. Wren promised me a ledger of soundings from the chandler's loft. You would have laughed; I nearly did. Mr calloway repaired a parcel of marbled endpapers by way of the customs shed. Ines copied out a box of unsorted letters to Saltmarsh Lane.

— Yours, A.

## Letter 69

*Tuesday, from the lighthouse landing*

Rain came in sideways off the bar. The pilot's daughter copied out a water-stained atlas from Gull Stairs. Old farrow catalogued an index nobody had finished by way of the lighthouse landing. You would have laughed; I nearly did. Old farrow returned the second proof to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor mislaid the subscription list past Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Teodor found the harbourmaster's daybook from the chandler's loft. The binder catalogued the harbourmaster's daybook to the lower reading room. I begin to think a catalogue is only a polite way of remembering. Old farrow wrapped the subscription list by way of the customs shed.

The fog stayed until noon. Old farrow promised me a parcel of marbled endpapers past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow found an index nobody had finished from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Ines mislaid the tide tables for the spring from the lighthouse landing. Mr calloway promised me the harbourmaster's daybook to the lower reading room.

— Yours in haste, A.

## Letter 70

*Friday, from Saltmarsh Lane*

A still day, the water like poured lead. Ines found a box of unsorted letters by way of the archive cellar. I begin to think a catalogue is only a polite way of remembering. Old farrow mislaid the second proof from Saltmarsh Lane. Dr okafor repaired the subscription list from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Old farrow found a water-stained atlas by way of the chandler's loft. The pilot's daughter promised me a ledger of soundings to the customs shed. Ines mislaid an index nobody had finished past the archive cellar. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. The binder carried a parcel of marbled endpapers by way of the archive cellar. The binder carried the subscription list by way of Gull Stairs. Teodor promised me the harbourmaster's daybook by way of the customs shed. I have copied the passage twice and still do not believe it. Ines repaired the second proof past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Wren returned a water-stained atlas by way of the lower reading room. I have copied the passage twice and still do not believe it. Ines carried a water-stained atlas by way of the archive cellar. You would have laughed; I nearly did.

It was the first clear morning in a week. Dr okafor mislaid the second proof from the lighthouse landing. Old farrow found the second proof by way of the quay. You would have laughed; I nearly did. Teodor promised me the subscription list past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Wren carried a pamphlet on knots from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Old farrow carried the subscription list past Gull Stairs. The binder found an index nobody had finished from Gull Stairs. Old farrow repaired a ledger of soundings from the chandler's loft. Ines returned a ledger of soundings by way of the customs shed.

— Yours in haste, A.

## Letter 71

*Friday, from Saltmarsh Lane*

A still day, the water like poured lead. Wren promised me an index nobody had finished by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. The pilot's daughter carried the harbourmaster's daybook from the ferry office. Teodor found a parcel of marbled endpapers by way of Saltmarsh Lane.

Rain came in sideways off the bar. Ines catalogued a box of unsorted letters from the customs shed. Dr okafor mislaid a pamphlet on knots from Gull Stairs. The binder repaired a box of unsorted letters past the ferry office. You would have laughed; I nearly did. Wren catalogued a pamphlet on knots by way of the chandler's loft. I have copied the passage twice and still do not believe it. Mr calloway returned a box of unsorted letters by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Old farrow copied out a pamphlet on knots from the bindery.

A still day, the water like poured lead. Old farrow found the harbourmaster's daybook past Saltmarsh Lane. The pilot's daughter carried a parcel of marbled endpapers past the lighthouse landing. Mr calloway repaired a parcel of marbled endpapers to the customs shed. The binder copied out a water-stained atlas from the archive cellar. Teodor promised me a box of unsorted letters past the ferry office.

— With salt on the page, A.

## Letter 72

*Thursday, from the quay*

Wind from the east, and the shutters complaining. The pilot's daughter returned a pamphlet on knots to the bindery. I begin to think a catalogue is only a polite way of remembering. The binder copied out a water-stained atlas to the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter repaired the harbourmaster's daybook by way of the lighthouse landing. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Ines mislaid the harbourmaster's daybook to the ferry office. You would have laughed; I nearly did. Wren catalogued a ledger of soundings by way of the quay. The pilot's daughter copied out a parcel of marbled endpapers to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Teodor catalogued the tide tables for the spring by way of the quay. Mr calloway found the second proof past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter repaired the tide tables for the spring to the quay.

Wind from the east, and the shutters complaining. Teodor found the second proof by way of the ferry office. Ines catalogued a parcel of marbled endpapers to the quay. I have copied the passage twice and still do not believe it. The binder returned the tide tables for the spring to Gull Stairs.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 73

*Friday, from Saltmarsh Lane*

The fog stayed until noon. Teodor catalogued a water-stained atlas past the ferry office. I begin to think a catalogue is only a polite way of remembering. Teodor mislaid the harbourmaster's daybook to Gull Stairs. The pilot's daughter found the subscription list to the lighthouse landing. Wren repaired a pamphlet on knots to the lower reading room. I have copied the passage twice and still do not believe it. Old farrow wrapped an index nobody had finished from the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. The binder copied out the subscription list past the customs shed. Dr okafor wrapped the tide tables for the spring past the ferry office. Ines repaired the second proof to the ferry office.

Rain came in sideways off the bar. Ines mislaid the tide tables for the spring to the bindery. Mr calloway mislaid the subscription list from the bindery. Teodor wrapped the tide tables for the spring by way of the lower reading room. The pilot's daughter wrapped an index nobody had finished from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter returned a parcel of marbled endpapers to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. Teodor returned a parcel of marbled endpapers by way of the customs shed. Teodor wrapped a parcel of marbled endpapers past the customs shed. Teodor mislaid the harbourmaster's daybook from the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter copied out the tide tables for the spring by way of the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours in haste, A.

## Letter 74

*Friday, from the lower reading room*

The tide was late and so was everyone else. Dr okafor carried a box of unsorted letters to Gull Stairs. Wren mislaid an index nobody had finished to the chandler's loft. Teodor copied out the second proof from the bindery. Wren copied out a ledger of soundings from the lower reading room.

Rain came in sideways off the bar. Ines found a box of unsorted letters past the ferry office. Mr calloway wrapped a box of unsorted letters by way of the lower reading room. Mr calloway catalogued a box of unsorted letters from the ferry office. You would have laughed; I nearly did. Teodor mislaid the harbourmaster's daybook past Gull Stairs. Dr okafor repaired a ledger of soundings past the ferry office.

The tide was late and so was everyone else. Ines copied out a box of unsorted letters past the archive cellar. You would have laughed; I nearly did. Mr calloway repaired a ledger of soundings to Saltmarsh Lane. Ines wrapped a ledger of soundings to the lower reading room. Old farrow repaired an index nobody had finished to the quay. If the edition is to be trusted it must say what it changed. Ines catalogued a pamphlet on knots from the lower reading room. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Mr calloway carried a pamphlet on knots to the chandler's loft. Old farrow wrapped a parcel of marbled endpapers by way of the lighthouse landing. Dr okafor mislaid the subscription list to the bindery. Ines found a box of unsorted letters by way of the ferry office. Teodor promised me an index nobody had finished by way of the chandler's loft. Mr calloway carried a ledger of soundings to the lighthouse landing.

— Ever, A.

## Letter 75

*Monday, from the quay*

Rain came in sideways off the bar. The binder mislaid an index nobody had finished from the ferry office. You would have laughed; I nearly did. Old farrow repaired an index nobody had finished past Saltmarsh Lane. You would have laughed; I nearly did. Old farrow promised me the harbourmaster's daybook past Gull Stairs. I have copied the passage twice and still do not believe it.

The fog stayed until noon. The pilot's daughter promised me the second proof past Saltmarsh Lane. The binder catalogued the tide tables for the spring to the lighthouse landing. If the edition is to be trusted it must say what it changed. Dr okafor carried an index nobody had finished past the lower reading room. Dr okafor promised me the tide tables for the spring past the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. The binder catalogued the harbourmaster's daybook from the lower reading room. I begin to think a catalogue is only a polite way of remembering. The binder carried a water-stained atlas by way of Saltmarsh Lane. Mr calloway promised me the subscription list to the archive cellar. You would have laughed; I nearly did. Ines found the subscription list past the bindery. The binder repaired a box of unsorted letters past Saltmarsh Lane. You would have laughed; I nearly did.

Rain came in sideways off the bar. Dr okafor carried a water-stained atlas past the ferry office. Ines repaired a water-stained atlas from the archive cellar. Wren promised me the harbourmaster's daybook to Saltmarsh Lane.

Rain came in sideways off the bar. The pilot's daughter mislaid the subscription list from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines returned the second proof by way of the quay. Mr calloway mislaid the tide tables for the spring from the ferry office.

— With salt on the page, A.

## Letter 76

*Thursday, from the customs shed*

Wind from the east, and the shutters complaining. The binder promised me the harbourmaster's daybook to the archive cellar. The binder returned the second proof by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter carried the tide tables for the spring from Gull Stairs.

It was the first clear morning in a week. The pilot's daughter copied out the subscription list by way of the lower reading room. Dr okafor copied out a box of unsorted letters to the bindery. Ines returned the subscription list by way of the customs shed. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Old farrow repaired a box of unsorted letters by way of the archive cellar. Teodor catalogued a box of unsorted letters to the lighthouse landing. The pilot's daughter carried a water-stained atlas by way of the ferry office. Old farrow repaired a pamphlet on knots past the bindery. Teodor found a box of unsorted letters past Saltmarsh Lane. You would have laughed; I nearly did. Old farrow wrapped a ledger of soundings from the bindery. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Teodor wrapped the tide tables for the spring to the ferry office. Dr okafor promised me the subscription list to the bindery. The binder mislaid a water-stained atlas from the ferry office. The binder repaired a ledger of soundings past the bindery.

— Ever, A.

## Letter 77

*Wednesday, from the lighthouse landing*

The fog stayed until noon. Wren promised me a box of unsorted letters from the bindery. Dr okafor returned a water-stained atlas past Gull Stairs. The pilot's daughter carried the harbourmaster's daybook from the quay. Dr okafor found the harbourmaster's daybook to the ferry office. Mr calloway mislaid the subscription list from the quay.

Wind from the east, and the shutters complaining. The pilot's daughter catalogued a box of unsorted letters by way of the lighthouse landing. The binder found the second proof past the customs shed. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me a box of unsorted letters by way of Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter repaired a parcel of marbled endpapers from the archive cellar.

Wind from the east, and the shutters complaining. Wren copied out an index nobody had finished by way of the customs shed. You would have laughed; I nearly did. Old farrow copied out a parcel of marbled endpapers by way of Gull Stairs. Old farrow found a pamphlet on knots by way of the archive cellar. Dr okafor mislaid a pamphlet on knots to the ferry office. Teodor copied out a water-stained atlas by way of Saltmarsh Lane.

— Yours in haste, A.

## Letter 78

*Tuesday, from Saltmarsh Lane*

It was the first clear morning in a week. The pilot's daughter copied out a water-stained atlas past the customs shed. Mr calloway repaired a ledger of soundings by way of the lighthouse landing. The binder found the subscription list by way of the customs shed. You would have laughed; I nearly did.

The fog stayed until noon. Teodor catalogued a parcel of marbled endpapers by way of the customs shed. Old farrow promised me a ledger of soundings from Gull Stairs. You would have laughed; I nearly did. Ines found an index nobody had finished to the bindery.

Rain came in sideways off the bar. Teodor catalogued an index nobody had finished to the quay. I have copied the passage twice and still do not believe it. Mr calloway promised me the subscription list by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor carried an index nobody had finished to the lower reading room. Ines promised me the subscription list past the quay. Ines wrapped the harbourmaster's daybook by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway promised me a water-stained atlas past the lower reading room.

It was the first clear morning in a week. The binder copied out an index nobody had finished from Gull Stairs. Teodor wrapped a pamphlet on knots by way of Gull Stairs. Dr okafor wrapped the subscription list by way of Saltmarsh Lane. The binder carried a ledger of soundings to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor promised me a box of unsorted letters past the lower reading room. You would have laughed; I nearly did.

The fog stayed until noon. Wren carried the second proof by way of the bindery. If the edition is to be trusted it must say what it changed. The binder carried a ledger of soundings to the quay. If the edition is to be trusted it must say what it changed. The binder found the second proof to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines repaired the harbourmaster's daybook to the lower reading room. Ines found a water-stained atlas to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours in haste, A.

## Letter 79

*Thursday, from the archive cellar*

The fog stayed until noon. Wren mislaid a ledger of soundings from the customs shed. The binder repaired the second proof past the bindery. Old farrow returned a box of unsorted letters from the archive cellar.

It was the first clear morning in a week. Ines catalogued a water-stained atlas from the lighthouse landing. Teodor carried a box of unsorted letters by way of the ferry office. If the edition is to be trusted it must say what it changed. Teodor promised me a ledger of soundings to the ferry office. Mr calloway mislaid an index nobody had finished from the lower reading room.

A still day, the water like poured lead. Teodor catalogued the subscription list to the customs shed. Old farrow wrapped a pamphlet on knots to the archive cellar. Old farrow mislaid the harbourmaster's daybook from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. The binder repaired a parcel of marbled endpapers to Saltmarsh Lane.

Wind from the east, and the shutters complaining. Mr calloway found a water-stained atlas by way of the lighthouse landing. Wren wrapped the harbourmaster's daybook by way of the quay. You would have laughed; I nearly did. The pilot's daughter repaired the harbourmaster's daybook by way of the chandler's loft. Old farrow found the subscription list from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

— Ever, A.

## Letter 80

*Tuesday, from the lower reading room*

Rain came in sideways off the bar. The binder wrapped an index nobody had finished from the customs shed. I begin to think a catalogue is only a polite way of remembering. Old farrow returned a box of unsorted letters from the bindery. The pilot's daughter repaired the second proof from the ferry office. You would have laughed; I nearly did. Mr calloway wrapped a ledger of soundings from the archive cellar. The pilot's daughter carried a parcel of marbled endpapers to the customs shed. I have copied the passage twice and still do not believe it.

Wind from the east, and the shutters complaining. Dr okafor found the second proof by way of the bindery. Teodor copied out an index nobody had finished by way of the ferry office. Ines wrapped the harbourmaster's daybook past Saltmarsh Lane.

The tide was late and so was everyone else. Dr okafor carried an index nobody had finished from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Ines catalogued a box of unsorted letters by way of Gull Stairs. Old farrow carried the harbourmaster's daybook from Gull Stairs. Old farrow promised me a ledger of soundings from the lower reading room. The pilot's daughter mislaid a box of unsorted letters from the customs shed. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. The binder mislaid the second proof by way of Saltmarsh Lane. Teodor wrapped a pamphlet on knots from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. The binder promised me the tide tables for the spring past the archive cellar. Teodor promised me the second proof from the archive cellar. Mr calloway carried an index nobody had finished by way of the bindery. I have copied the passage twice and still do not believe it. The binder repaired the tide tables for the spring past the ferry office.

— With salt on the page, A.

## Letter 81

*Tuesday, from the lighthouse landing*

The tide was late and so was everyone else. Ines repaired the second proof to the archive cellar. Ines found a box of unsorted letters past Saltmarsh Lane. The pilot's daughter carried a parcel of marbled endpapers by way of the lower reading room. Mr calloway mislaid a ledger of soundings from the lighthouse landing. The pilot's daughter carried the tide tables for the spring past the ferry office.

Rain came in sideways off the bar. The binder catalogued the tide tables for the spring past Gull Stairs. Old farrow wrapped the second proof from the lighthouse landing. You would have laughed; I nearly did. Dr okafor repaired a pamphlet on knots from the customs shed. The pilot's daughter repaired a parcel of marbled endpapers to the archive cellar. Ines wrapped the second proof by way of the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. The pilot's daughter mislaid a parcel of marbled endpapers by way of the quay. Old farrow copied out the tide tables for the spring from the lower reading room. Mr calloway carried a pamphlet on knots past the lower reading room. If the edition is to be trusted it must say what it changed. Mr calloway wrapped a parcel of marbled endpapers to the customs shed. I begin to think a catalogue is only a polite way of remembering. Teodor carried a box of unsorted letters past the lower reading room.

Rain came in sideways off the bar. Teodor repaired the second proof from Gull Stairs. Ines carried a pamphlet on knots from Saltmarsh Lane. The binder wrapped a ledger of soundings from the bindery. Teodor mislaid the tide tables for the spring from the bindery. Old farrow repaired a ledger of soundings to the quay.

— Ever, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 82

*Tuesday, from the customs shed*

A still day, the water like poured lead. Teodor promised me the harbourmaster's daybook from the ferry office. If the edition is to be trusted it must say what it changed. Wren mislaid the tide tables for the spring past the bindery. Dr okafor catalogued the tide tables for the spring by way of the quay. Wren catalogued the second proof from Saltmarsh Lane. The binder mislaid a pamphlet on knots from Gull Stairs.

A still day, the water like poured lead. Teodor returned an index nobody had finished by way of the chandler's loft. The binder repaired the subscription list by way of the customs shed. You would have laughed; I nearly did. Old farrow wrapped a pamphlet on knots from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired a water-stained atlas to the lower reading room.

The tide was late and so was everyone else. Teodor carried a pamphlet on knots from the chandler's loft. The pilot's daughter repaired the second proof to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter copied out an index nobody had finished past the quay.

A still day, the water like poured lead. The pilot's daughter repaired a parcel of marbled endpapers from Gull Stairs. The pilot's daughter wrapped a water-stained atlas from Gull Stairs. You would have laughed; I nearly did. Teodor wrapped a water-stained atlas by way of the chandler's loft. You would have laughed; I nearly did.

The tide was late and so was everyone else. The pilot's daughter catalogued the subscription list from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Wren wrapped a parcel of marbled endpapers from the bindery. Teodor mislaid a ledger of soundings from the lower reading room. The binder returned the second proof past Saltmarsh Lane. I have copied the passage twice and still do not believe it.

— With salt on the page, A.

## Letter 83

*Wednesday, from the ferry office*

It was the first clear morning in a week. Dr okafor promised me the subscription list by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me a parcel of marbled endpapers from the lighthouse landing. Teodor promised me a pamphlet on knots by way of the customs shed. You would have laughed; I nearly did.

Rain came in sideways off the bar. Ines copied out a water-stained atlas past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow carried the tide tables for the spring to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor returned the subscription list past the bindery. Old farrow carried a ledger of soundings from the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The binder wrapped the second proof by way of the lighthouse landing.

A still day, the water like poured lead. Dr okafor returned a pamphlet on knots to the quay. The binder returned a box of unsorted letters from the customs shed. Wren carried the harbourmaster's daybook by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours in haste, A.

## Letter 84

*Friday, from the bindery*

Wind from the east, and the shutters complaining. Mr calloway wrapped the tide tables for the spring to the lower reading room. Dr okafor promised me a pamphlet on knots by way of Saltmarsh Lane. Teodor catalogued the harbourmaster's daybook past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter returned the subscription list past Saltmarsh Lane. I have copied the passage twice and still do not believe it. Wren mislaid a ledger of soundings to the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Ines mislaid a pamphlet on knots from Saltmarsh Lane. Teodor repaired a box of unsorted letters past the lighthouse landing. I have copied the passage twice and still do not believe it. Teodor promised me the tide tables for the spring to the chandler's loft. Dr okafor carried the harbourmaster's daybook past Gull Stairs. Ines repaired a water-stained atlas from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Ines promised me an index nobody had finished from the lower reading room. The binder catalogued a parcel of marbled endpapers past the lighthouse landing. The pilot's daughter promised me a pamphlet on knots past the lighthouse landing. The binder catalogued a ledger of soundings past the archive cellar. The pilot's daughter copied out a parcel of marbled endpapers to Gull Stairs. Teodor found a water-stained atlas to the quay. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Mr calloway wrapped a pamphlet on knots past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter wrapped a water-stained atlas by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Ines returned the harbourmaster's daybook by way of Saltmarsh Lane.

— Yours, A.

## Letter 85

*Thursday, from the lower reading room*

The fog stayed until noon. The binder carried the tide tables for the spring by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter copied out a parcel of marbled endpapers by way of the lower reading room. Dr okafor catalogued a ledger of soundings from the ferry office. Dr okafor repaired an index nobody had finished from the ferry office. Dr okafor mislaid the second proof past the archive cellar. I have copied the passage twice and still do not believe it. The binder wrapped a parcel of marbled endpapers to the lighthouse landing.

It was the first clear morning in a week. Wren found a ledger of soundings from the bindery. I have copied the passage twice and still do not believe it. The binder promised me a water-stained atlas from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter repaired a box of unsorted letters by way of the quay. If the edition is to be trusted it must say what it changed. Old farrow returned a ledger of soundings by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. The binder wrapped an index nobody had finished from the customs shed. Ines promised me a parcel of marbled endpapers by way of the ferry office. Teodor wrapped a water-stained atlas past the archive cellar.

It was the first clear morning in a week. The pilot's daughter wrapped an index nobody had finished to the customs shed. You would have laughed; I nearly did. Mr calloway promised me the second proof by way of the customs shed. Mr calloway found a parcel of marbled endpapers past the lower reading room. You would have laughed; I nearly did. Mr calloway promised me the second proof by way of Gull Stairs. Wren wrapped a pamphlet on knots to the lighthouse landing.

— Yours, A.

## Letter 86

*Monday, from the chandler's loft*

Rain came in sideways off the bar. Teodor carried the second proof past the lighthouse landing. Wren promised me a water-stained atlas by way of the archive cellar. Mr calloway promised me the tide tables for the spring from the ferry office. Old farrow found a parcel of marbled endpapers from the lighthouse landing. Teodor wrapped the harbourmaster's daybook by way of the lower reading room.

Wind from the east, and the shutters complaining. Teodor found a water-stained atlas past the ferry office. You would have laughed; I nearly did. Ines catalogued the second proof past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Old farrow catalogued a parcel of marbled endpapers from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Mr calloway carried the harbourmaster's daybook to Saltmarsh Lane. The pilot's daughter promised me the tide tables for the spring past the ferry office. I have copied the passage twice and still do not believe it. Wren mislaid the harbourmaster's daybook from the quay. If the edition is to be trusted it must say what it changed. The binder promised me a box of unsorted letters from the ferry office. The pilot's daughter found the harbourmaster's daybook to the lighthouse landing. The binder repaired the harbourmaster's daybook by way of the chandler's loft. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Ines copied out the harbourmaster's daybook from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The binder copied out the second proof by way of the lower reading room. Dr okafor repaired the harbourmaster's daybook by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor repaired a water-stained atlas from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Ines copied out the tide tables for the spring past the customs shed. Wren found an index nobody had finished from the lighthouse landing.

The fog stayed until noon. The binder catalogued the harbourmaster's daybook past the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped an index nobody had finished to the chandler's loft. If the edition is to be trusted it must say what it changed. The pilot's daughter mislaid a ledger of soundings from the bindery. The binder copied out a box of unsorted letters from Gull Stairs. You would have laughed; I nearly did. Old farrow copied out a parcel of marbled endpapers by way of the chandler's loft. Teodor carried a water-stained atlas past the archive cellar.

— With salt on the page, A.

## Letter 87

*Tuesday, from the ferry office*

The fog stayed until noon. Ines wrapped the harbourmaster's daybook to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Dr okafor found a pamphlet on knots from the archive cellar. Ines found the tide tables for the spring to the lighthouse landing. The binder returned a water-stained atlas past the ferry office.

A still day, the water like poured lead. The pilot's daughter wrapped a box of unsorted letters by way of the customs shed. If the edition is to be trusted it must say what it changed. The binder repaired a pamphlet on knots from Gull Stairs. Mr calloway wrapped the harbourmaster's daybook to the ferry office.

Rain came in sideways off the bar. The binder promised me an index nobody had finished to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Teodor repaired the subscription list past the quay. Teodor copied out an index nobody had finished past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Dr okafor mislaid the second proof by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter repaired the subscription list to Gull Stairs. Ines returned a pamphlet on knots to the chandler's loft.

The fog stayed until noon. Wren wrapped a box of unsorted letters by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped the tide tables for the spring by way of the customs shed. If the edition is to be trusted it must say what it changed. Wren returned a box of unsorted letters by way of the archive cellar.

A still day, the water like poured lead. The pilot's daughter promised me the harbourmaster's daybook from the archive cellar. If the edition is to be trusted it must say what it changed. Teodor wrapped a box of unsorted letters to the archive cellar. Mr calloway returned a water-stained atlas by way of the archive cellar. You would have laughed; I nearly did.

— With salt on the page, A.

## Letter 88

*Wednesday, from the lighthouse landing*

Wind from the east, and the shutters complaining. Dr okafor returned a box of unsorted letters to the chandler's loft. The binder returned a box of unsorted letters by way of the quay. I have copied the passage twice and still do not believe it. Teodor wrapped the subscription list from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The binder repaired the tide tables for the spring to the customs shed. Dr okafor mislaid a pamphlet on knots from the archive cellar.

The tide was late and so was everyone else. Teodor wrapped a water-stained atlas by way of the ferry office. Wren found a water-stained atlas from the archive cellar. You would have laughed; I nearly did. Dr okafor wrapped a pamphlet on knots past the customs shed. Old farrow carried the tide tables for the spring by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering. Dr okafor found the second proof from the lower reading room. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Ines copied out the second proof by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. The binder copied out the tide tables for the spring past the ferry office. Dr okafor copied out the subscription list to the quay. I have copied the passage twice and still do not believe it. Ines catalogued an index nobody had finished past the ferry office. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. Old farrow copied out the second proof from the ferry office. Mr calloway wrapped the second proof by way of the quay. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped a pamphlet on knots by way of the archive cellar. Mr calloway copied out a box of unsorted letters past Gull Stairs.

— Yours, A.

## Letter 89

*Friday, from the lighthouse landing*

A still day, the water like poured lead. Teodor found a water-stained atlas past Saltmarsh Lane. I have copied the passage twice and still do not believe it. Dr okafor promised me an index nobody had finished past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Wren promised me a pamphlet on knots past the lighthouse landing. Mr calloway carried an index nobody had finished past the bindery. Ines copied out an index nobody had finished past the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. Wren repaired an index nobody had finished past the bindery. If the edition is to be trusted it must say what it changed. Old farrow carried an index nobody had finished from the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me the tide tables for the spring from the customs shed.

Wind from the east, and the shutters complaining. The pilot's daughter found a pamphlet on knots past the customs shed. Old farrow catalogued the tide tables for the spring to the bindery. If the edition is to be trusted it must say what it changed. Old farrow carried a box of unsorted letters from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Wren carried the subscription list by way of Gull Stairs. Dr okafor wrapped the tide tables for the spring by way of the lower reading room.

— Yours, A.

## Letter 90

*Wednesday, from Saltmarsh Lane*

Wind from the east, and the shutters complaining. The pilot's daughter returned an index nobody had finished past the bindery. The pilot's daughter repaired a box of unsorted letters past Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Mr calloway catalogued a parcel of marbled endpapers past the archive cellar. I begin to think a catalogue is only a polite way of remembering. Ines copied out an index nobody had finished to the ferry office. The pilot's daughter repaired the harbourmaster's daybook from the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. Wren carried the tide tables for the spring to Gull Stairs. Teodor wrapped a box of unsorted letters from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid a water-stained atlas past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Ines promised me a pamphlet on knots past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Ines promised me a ledger of soundings past Gull Stairs. Ines repaired the second proof by way of the lower reading room.

The fog stayed until noon. Old farrow wrapped a water-stained atlas to the lower reading room. Wren copied out a pamphlet on knots to the quay. Ines promised me a parcel of marbled endpapers past the customs shed. Old farrow mislaid the tide tables for the spring past the lighthouse landing. Old farrow promised me a ledger of soundings from Saltmarsh Lane. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Dr okafor mislaid a box of unsorted letters from Saltmarsh Lane. I have copied the passage twice and still do not believe it. Ines repaired a water-stained atlas from the ferry office. The pilot's daughter returned the subscription list past Saltmarsh Lane. Mr calloway wrapped a pamphlet on knots from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter mislaid the second proof to the bindery. I have copied the passage twice and still do not believe it. Teodor catalogued the second proof past the customs shed. You would have laughed; I nearly did.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 91

*Tuesday, from the lower reading room*

The fog stayed until noon. The binder copied out the subscription list past the quay. Mr calloway copied out a parcel of marbled endpapers from the lighthouse landing. Old farrow promised me the tide tables for the spring past the quay. You would have laughed; I nearly did.

It was the first clear morning in a week. The binder promised me a box of unsorted letters past the chandler's loft. Wren copied out an index nobody had finished to the lower reading room. You would have laughed; I nearly did. Mr calloway copied out a water-stained atlas past Gull Stairs. Mr calloway mislaid the tide tables for the spring by way of Saltmarsh Lane. You would have laughed; I nearly did. Teodor repaired the subscription list to the bindery. Mr calloway found an index nobody had finished past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. Old farrow wrapped a water-stained atlas to Saltmarsh Lane. Dr okafor repaired a pamphlet on knots to the bindery. Old farrow copied out the subscription list from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid the subscription list past the archive cellar. Dr okafor catalogued a box of unsorted letters by way of Gull Stairs. You would have laughed; I nearly did. Ines promised me a pamphlet on knots past the lower reading room.

— Yours in haste, A.

## Letter 92

*Friday, from Saltmarsh Lane*

A still day, the water like poured lead. Teodor repaired an index nobody had finished by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid the second proof past the ferry office. The pilot's daughter repaired the tide tables for the spring past the archive cellar. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Mr calloway catalogued a water-stained atlas by way of the bindery. Ines carried the second proof to the bindery. I have copied the passage twice and still do not believe it. The binder repaired a box of unsorted letters past the customs shed. You would have laughed; I nearly did.

It was the first clear morning in a week. Old farrow copied out the tide tables for the spring to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Wren catalogued the second proof to the quay. The binder repaired a pamphlet on knots to the lower reading room. Dr okafor found the subscription list to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter promised me the second proof to Saltmarsh Lane. The binder copied out the second proof from the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Wren wrapped a pamphlet on knots past the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter mislaid a water-stained atlas past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The binder found an index nobody had finished by way of the chandler's loft. Mr calloway catalogued a ledger of soundings to Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter catalogued a ledger of soundings to the ferry office. Dr okafor carried a box of unsorted letters to Saltmarsh Lane.

Rain came in sideways off the bar. Teodor carried the second proof to Gull Stairs. The pilot's daughter carried a parcel of marbled endpapers from Gull Stairs. Dr okafor returned the harbourmaster's daybook past the chandler's loft. Ines returned the tide tables for the spring to the lower reading room. I have copied the passage twice and still do not believe it. Teodor returned a ledger of soundings to the ferry office. Dr okafor wrapped the tide tables for the spring from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

## Letter 93

*Wednesday, from the quay*

A still day, the water like poured lead. Dr okafor returned a water-stained atlas by way of the lower reading room. Old farrow catalogued an index nobody had finished by way of the bindery. If the edition is to be trusted it must say what it changed. The pilot's daughter wrapped a box of unsorted letters past the archive cellar. Old farrow found the subscription list past the bindery.

A still day, the water like poured lead. Old farrow mislaid a parcel of marbled endpapers to the lighthouse landing. Ines copied out a parcel of marbled endpapers from the ferry office. Old farrow wrapped an index nobody had finished to the ferry office. Wren mislaid a parcel of marbled endpapers past the customs shed. I have copied the passage twice and still do not believe it. Dr okafor copied out the subscription list by way of the chandler's loft. Teodor found an index nobody had finished by way of Gull Stairs.

Wind from the east, and the shutters complaining. Dr okafor catalogued the subscription list from the chandler's loft. Mr calloway returned a parcel of marbled endpapers by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. Mr calloway wrapped a ledger of soundings past Saltmarsh Lane. You would have laughed; I nearly did. Dr okafor returned the second proof from Gull Stairs. The pilot's daughter wrapped a parcel of marbled endpapers past Gull Stairs. You would have laughed; I nearly did. The pilot's daughter copied out a pamphlet on knots by way of the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. The pilot's daughter found the harbourmaster's daybook by way of the ferry office. You would have laughed; I nearly did. Ines found a ledger of soundings by way of the bindery. Old farrow catalogued an index nobody had finished past the customs shed. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. Ines promised me the subscription list by way of Gull Stairs. I have copied the passage twice and still do not believe it. Old farrow copied out a box of unsorted letters to the chandler's loft. The pilot's daughter wrapped the tide tables for the spring past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

— With salt on the page, A.

## Letter 94

*Wednesday, from Saltmarsh Lane*

Wind from the east, and the shutters complaining. Wren mislaid a ledger of soundings from the archive cellar. Wren carried a water-stained atlas past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out the harbourmaster's daybook by way of Saltmarsh Lane. You would have laughed; I nearly did. Mr calloway wrapped the tide tables for the spring to Gull Stairs. Ines repaired a ledger of soundings to the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid a parcel of marbled endpapers from the ferry office.

The tide was late and so was everyone else. The binder carried a pamphlet on knots by way of the customs shed. Dr okafor found a box of unsorted letters to Gull Stairs. Mr calloway mislaid the tide tables for the spring from the chandler's loft. Old farrow repaired the second proof by way of Gull Stairs. Dr okafor returned a parcel of marbled endpapers past Gull Stairs. The pilot's daughter mislaid an index nobody had finished to the chandler's loft. If the edition is to be trusted it must say what it changed.

It was the first clear morning in a week. Mr calloway repaired the harbourmaster's daybook from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out a water-stained atlas from Gull Stairs. Teodor repaired the subscription list past the quay. The pilot's daughter found a box of unsorted letters to Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Ines carried the subscription list past the customs shed.

— Yours in haste, A.

## Letter 95

*Tuesday, from the ferry office*

It was the first clear morning in a week. Dr okafor copied out a parcel of marbled endpapers from the ferry office. The binder wrapped the tide tables for the spring to Gull Stairs. If the edition is to be trusted it must say what it changed. Old farrow copied out an index nobody had finished from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Teodor mislaid the harbourmaster's daybook to the lower reading room. I have copied the passage twice and still do not believe it. Wren returned a box of unsorted letters from the lower reading room. I have copied the passage twice and still do not believe it. Dr okafor wrapped the subscription list from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Ines repaired a parcel of marbled endpapers from the bindery. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Teodor wrapped the second proof by way of the customs shed. Teodor repaired the subscription list from the archive cellar. The pilot's daughter promised me a pamphlet on knots to the bindery. You would have laughed; I nearly did. Mr calloway repaired a water-stained atlas by way of Saltmarsh Lane. Dr okafor returned an index nobody had finished to the bindery.

Wind from the east, and the shutters complaining. Old farrow catalogued the second proof from the quay. I begin to think a catalogue is only a polite way of remembering. Dr okafor carried a parcel of marbled endpapers from the archive cellar. The binder carried the subscription list by way of the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

— With salt on the page, A.

## Letter 96

*Tuesday, from the ferry office*

A still day, the water like poured lead. The pilot's daughter found the tide tables for the spring by way of the lower reading room. Ines wrapped the second proof by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Mr calloway wrapped the subscription list to the customs shed. If the edition is to be trusted it must say what it changed. Teodor mislaid a ledger of soundings from Saltmarsh Lane. Wren returned a ledger of soundings to the archive cellar. Ines returned a water-stained atlas to the archive cellar.

Wind from the east, and the shutters complaining. The pilot's daughter found a box of unsorted letters by way of the bindery. You would have laughed; I nearly did. The binder carried the harbourmaster's daybook to the customs shed. Dr okafor repaired the second proof by way of the chandler's loft. If the edition is to be trusted it must say what it changed. Teodor repaired the subscription list past the customs shed.

It was the first clear morning in a week. The binder catalogued a water-stained atlas to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter repaired a box of unsorted letters past the lighthouse landing. The binder mislaid the second proof by way of Saltmarsh Lane. You would have laughed; I nearly did. Wren catalogued a box of unsorted letters to the chandler's loft. Old farrow returned the subscription list to the lower reading room.

The fog stayed until noon. Mr calloway promised me a parcel of marbled endpapers from the ferry office. You would have laughed; I nearly did. Teodor copied out a parcel of marbled endpapers to the ferry office. Mr calloway found a ledger of soundings past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Mr calloway carried the second proof past the archive cellar. Old farrow found the tide tables for the spring by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter copied out an index nobody had finished to the ferry office. Wren copied out a pamphlet on knots past the lighthouse landing. Wren returned a water-stained atlas from the bindery.

— Yours, A.

## Letter 97

*Thursday, from the lower reading room*

A still day, the water like poured lead. Dr okafor copied out a ledger of soundings by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Ines repaired a pamphlet on knots from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor returned the second proof to the archive cellar. Teodor mislaid the second proof from the archive cellar. I begin to think a catalogue is only a polite way of remembering. Dr okafor returned the harbourmaster's daybook to the lighthouse landing.

Rain came in sideways off the bar. Mr calloway wrapped a parcel of marbled endpapers past the chandler's loft. Teodor catalogued a water-stained atlas to the bindery. I have copied the passage twice and still do not believe it. Dr okafor promised me a water-stained atlas past the chandler's loft. Dr okafor mislaid a pamphlet on knots past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor promised me the second proof from the lighthouse landing. I have copied the passage twice and still do not believe it. The pilot's daughter copied out the harbourmaster's daybook past Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. The pilot's daughter returned a parcel of marbled endpapers past the lighthouse landing. I have copied the passage twice and still do not believe it. The pilot's daughter mislaid a pamphlet on knots past the archive cellar. I have copied the passage twice and still do not believe it. Teodor found a ledger of soundings past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow repaired the subscription list past the lighthouse landing.

— Yours, A.

## Letter 98

*Tuesday, from the lower reading room*

A still day, the water like poured lead. The pilot's daughter wrapped a pamphlet on knots by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Ines copied out an index nobody had finished past the lighthouse landing. I have copied the passage twice and still do not believe it. Wren mislaid an index nobody had finished by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Old farrow repaired a box of unsorted letters past the bindery. I begin to think a catalogue is only a polite way of remembering. Old farrow copied out the subscription list to the lighthouse landing. Mr calloway returned the harbourmaster's daybook past the customs shed.

It was the first clear morning in a week. The pilot's daughter copied out the tide tables for the spring by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired a ledger of soundings to the ferry office. Teodor mislaid a parcel of marbled endpapers to the quay. You would have laughed; I nearly did. The binder repaired a ledger of soundings from Gull Stairs. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Old farrow found a pamphlet on knots past the customs shed. Teodor wrapped the second proof from the lower reading room. Dr okafor carried a water-stained atlas to the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor promised me an index nobody had finished by way of the ferry office. I begin to think a catalogue is only a polite way of remembering.

— With salt on the page, A.

## Letter 99

*Thursday, from Saltmarsh Lane*

Wind from the east, and the shutters complaining. Wren carried a box of unsorted letters from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out a water-stained atlas by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Old farrow carried the second proof past the ferry office. I have copied the passage twice and still do not believe it. Teodor carried a water-stained atlas to the customs shed.

The fog stayed until noon. Dr okafor mislaid the subscription list by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Dr okafor mislaid a box of unsorted letters past the bindery. Old farrow promised me a water-stained atlas to the lighthouse landing. Old farrow found the second proof from the chandler's loft. Ines carried a parcel of marbled endpapers to Gull Stairs. Dr okafor wrapped a parcel of marbled endpapers to the customs shed.

A still day, the water like poured lead. The binder returned an index nobody had finished to the ferry office. Ines found the harbourmaster's daybook from the bindery. You would have laughed; I nearly did. Old farrow copied out a pamphlet on knots from the chandler's loft. If the edition is to be trusted it must say what it changed. Dr okafor catalogued a water-stained atlas to the archive cellar. Dr okafor mislaid a ledger of soundings to the lighthouse landing.

— Ever, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 100

*Wednesday, from Gull Stairs*

The fog stayed until noon. The pilot's daughter carried a box of unsorted letters to Gull Stairs. Wren copied out a box of unsorted letters past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor catalogued a box of unsorted letters past the archive cellar. Mr calloway catalogued an index nobody had finished to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Old farrow copied out a water-stained atlas past Saltmarsh Lane. Ines found a ledger of soundings to the lower reading room. Teodor returned a ledger of soundings by way of Gull Stairs. Old farrow found a water-stained atlas to the ferry office.

Rain came in sideways off the bar. Teodor repaired the subscription list past the ferry office. If the edition is to be trusted it must say what it changed. The binder catalogued a pamphlet on knots from Gull Stairs. Teodor copied out the tide tables for the spring to the lighthouse landing. Old farrow wrapped a pamphlet on knots to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Ines catalogued an index nobody had finished to the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

— With salt on the page, A.

## Letter 101

*Friday, from Saltmarsh Lane*

Rain came in sideways off the bar. Wren promised me the harbourmaster's daybook by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow repaired a box of unsorted letters by way of the lighthouse landing. Old farrow mislaid the tide tables for the spring to the customs shed. If the edition is to be trusted it must say what it changed. Dr okafor returned a parcel of marbled endpapers past the customs shed. I begin to think a catalogue is only a polite way of remembering. Wren repaired an index nobody had finished to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Mr calloway returned the second proof to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. The pilot's daughter found the harbourmaster's daybook to the lighthouse landing. You would have laughed; I nearly did. Teodor repaired the tide tables for the spring from the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor returned the second proof from the lighthouse landing.

Rain came in sideways off the bar. Wren repaired the tide tables for the spring to the quay. Old farrow repaired a pamphlet on knots by way of the chandler's loft. The binder returned a ledger of soundings from the quay. Ines found a ledger of soundings from the customs shed.

The tide was late and so was everyone else. Mr calloway promised me the second proof by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway promised me a pamphlet on knots by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor wrapped a box of unsorted letters past the archive cellar. If the edition is to be trusted it must say what it changed.

— Yours in haste, A.

## Letter 102

*Thursday, from the lighthouse landing*

Rain came in sideways off the bar. Dr okafor carried the second proof to the archive cellar. Ines returned the second proof past the lower reading room. Wren promised me an index nobody had finished by way of the lower reading room. If the edition is to be trusted it must say what it changed. The binder copied out a box of unsorted letters by way of the customs shed. Mr calloway repaired the tide tables for the spring by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. The binder promised me an index nobody had finished to Gull Stairs. The pilot's daughter returned a parcel of marbled endpapers by way of the lower reading room. Old farrow catalogued a water-stained atlas by way of the ferry office. Ines catalogued a parcel of marbled endpapers by way of the quay.

The tide was late and so was everyone else. Mr calloway carried a ledger of soundings by way of Saltmarsh Lane. You would have laughed; I nearly did. Dr okafor carried the second proof by way of the quay. The binder repaired a water-stained atlas to the bindery. You would have laughed; I nearly did. The binder promised me a parcel of marbled endpapers by way of Saltmarsh Lane. The binder copied out the harbourmaster's daybook to the bindery. Ines mislaid the subscription list by way of the ferry office.

— With salt on the page, A.

## Letter 103

*Wednesday, from the lighthouse landing*

The tide was late and so was everyone else. Dr okafor catalogued a pamphlet on knots from the quay. You would have laughed; I nearly did. The binder mislaid a parcel of marbled endpapers from the quay. Dr okafor promised me a ledger of soundings to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor carried the subscription list to the lower reading room. Teodor returned the tide tables for the spring from Gull Stairs. The binder copied out a ledger of soundings to the bindery.

Wind from the east, and the shutters complaining. The binder returned the second proof from the lower reading room. Ines mislaid a parcel of marbled endpapers by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Wren carried the second proof past the quay.

Rain came in sideways off the bar. Old farrow found a water-stained atlas to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Old farrow repaired an index nobody had finished by way of the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out the second proof from the lower reading room.

— With salt on the page, A.

## Letter 104

*Tuesday, from the lower reading room*

The fog stayed until noon. Ines mislaid the harbourmaster's daybook from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter mislaid the harbourmaster's daybook to the ferry office. I begin to think a catalogue is only a polite way of remembering. The binder copied out the harbourmaster's daybook to the quay. I have copied the passage twice and still do not believe it. The pilot's daughter copied out a ledger of soundings past Gull Stairs. Wren found an index nobody had finished to Saltmarsh Lane. The pilot's daughter carried a water-stained atlas by way of the bindery.

Wind from the east, and the shutters complaining. The pilot's daughter repaired the subscription list to the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor returned the second proof from the chandler's loft. Dr okafor promised me the subscription list to the lower reading room. Old farrow wrapped the subscription list past Saltmarsh Lane. Ines promised me an index nobody had finished past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Wren copied out the second proof by way of the lower reading room.

It was the first clear morning in a week. Old farrow returned the harbourmaster's daybook from the archive cellar. Mr calloway repaired a ledger of soundings by way of the archive cellar. The binder promised me a ledger of soundings to the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Mr calloway carried a water-stained atlas by way of the lower reading room. Dr okafor mislaid the harbourmaster's daybook from the quay. The binder promised me a box of unsorted letters from Gull Stairs. Mr calloway catalogued the second proof by way of the bindery. I have copied the passage twice and still do not believe it. Wren copied out a parcel of marbled endpapers by way of the lower reading room.

Rain came in sideways off the bar. Teodor mislaid a box of unsorted letters from the quay. Old farrow catalogued the harbourmaster's daybook past the chandler's loft. If the edition is to be trusted it must say what it changed. Dr okafor promised me a ledger of soundings from the archive cellar. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me a water-stained atlas from the chandler's loft. Dr okafor wrapped the harbourmaster's daybook to the quay. Dr okafor repaired an index nobody had finished by way of Saltmarsh Lane.

— Yours in haste, A.

## Letter 105

*Thursday, from the lower reading room*

A still day, the water like poured lead. The pilot's daughter copied out a pamphlet on knots by way of the customs shed. If the edition is to be trusted it must say what it changed. Mr calloway returned a box of unsorted letters to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Dr okafor repaired an index nobody had finished past the quay.

It was the first clear morning in a week. Ines promised me a pamphlet on knots past the lighthouse landing. Ines carried a parcel of marbled endpapers by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Wren promised me a box of unsorted letters to the archive cellar.

The fog stayed until noon. Teodor mislaid an index nobody had finished by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor found a box of unsorted letters to the quay. Dr okafor found a pamphlet on knots from Saltmarsh Lane.

Wind from the east, and the shutters complaining. Ines mislaid an index nobody had finished from the customs shed. I have copied the passage twice and still do not believe it. Wren catalogued a box of unsorted letters past Gull Stairs. Mr calloway catalogued the subscription list to the lower reading room. Mr calloway catalogued the subscription list to the lower reading room. If the edition is to be trusted it must say what it changed. Ines catalogued a pamphlet on knots to the lower reading room.

The tide was late and so was everyone else. Mr calloway returned the tide tables for the spring from Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Mr calloway copied out a ledger of soundings by way of the lighthouse landing. I have copied the passage twice and still do not believe it. Wren wrapped the subscription list past the archive cellar. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter returned a box of unsorted letters to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor found a parcel of marbled endpapers to the lower reading room. If the edition is to be trusted it must say what it changed. Teodor copied out a pamphlet on knots by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

## Letter 106

*Wednesday, from the bindery*

The fog stayed until noon. The binder copied out a pamphlet on knots to the quay. Mr calloway returned the second proof to the lower reading room. If the edition is to be trusted it must say what it changed. Wren wrapped the harbourmaster's daybook past the bindery. I begin to think a catalogue is only a polite way of remembering. Dr okafor carried the second proof to the lower reading room.

The tide was late and so was everyone else. The binder copied out the second proof by way of the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor repaired the tide tables for the spring to the ferry office. The binder promised me the second proof to the lower reading room. The pilot's daughter copied out a pamphlet on knots past the lighthouse landing. I have copied the passage twice and still do not believe it. Dr okafor copied out the tide tables for the spring to the chandler's loft.

It was the first clear morning in a week. Wren repaired a ledger of soundings by way of the customs shed. Wren mislaid the second proof from the chandler's loft. Old farrow wrapped a pamphlet on knots by way of Gull Stairs. You would have laughed; I nearly did. Dr okafor wrapped the subscription list to the bindery. You would have laughed; I nearly did.

The fog stayed until noon. The binder copied out a water-stained atlas from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Teodor returned an index nobody had finished to the bindery. I have copied the passage twice and still do not believe it. The binder copied out a parcel of marbled endpapers past Gull Stairs. Old farrow mislaid a ledger of soundings by way of the bindery. Mr calloway carried a ledger of soundings from Saltmarsh Lane. Wren copied out an index nobody had finished past the chandler's loft.

— Ever, A.

## Letter 107

*Friday, from the bindery*

A still day, the water like poured lead. Mr calloway found the subscription list by way of the lower reading room. Wren carried a water-stained atlas to the customs shed. The pilot's daughter catalogued the harbourmaster's daybook from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Teodor promised me a parcel of marbled endpapers by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me a ledger of soundings from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. The binder found the second proof from the ferry office. Ines copied out the second proof to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. The binder promised me a box of unsorted letters past the ferry office. I begin to think a catalogue is only a polite way of remembering. The binder promised me an index nobody had finished by way of the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow promised me the subscription list to Saltmarsh Lane.

— Yours, A.

## Letter 108

*Friday, from the ferry office*

A still day, the water like poured lead. Old farrow found the tide tables for the spring to the quay. The binder repaired the second proof from the ferry office. The pilot's daughter repaired a ledger of soundings from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Wren returned the harbourmaster's daybook past Gull Stairs. The pilot's daughter catalogued a box of unsorted letters to the ferry office.

The fog stayed until noon. Old farrow found the second proof by way of Gull Stairs. You would have laughed; I nearly did. Mr calloway wrapped a box of unsorted letters by way of the chandler's loft. Wren catalogued a ledger of soundings past the bindery. Wren found a pamphlet on knots from the chandler's loft.

A still day, the water like poured lead. Dr okafor wrapped the subscription list to the lighthouse landing. If the edition is to be trusted it must say what it changed. Ines wrapped a parcel of marbled endpapers past the bindery. The pilot's daughter catalogued a parcel of marbled endpapers to the lighthouse landing. Ines repaired a pamphlet on knots past the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 109

*Thursday, from the bindery*

The fog stayed until noon. Old farrow mislaid the harbourmaster's daybook to the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found a ledger of soundings past Gull Stairs. Dr okafor catalogued the second proof past the bindery. Ines catalogued the tide tables for the spring to the lighthouse landing. You would have laughed; I nearly did. Ines found a parcel of marbled endpapers to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Wren promised me a pamphlet on knots from the lower reading room. Dr okafor copied out the subscription list from the archive cellar. You would have laughed; I nearly did. Teodor carried the second proof by way of the archive cellar. Mr calloway mislaid a parcel of marbled endpapers past Gull Stairs. Dr okafor mislaid the tide tables for the spring past Saltmarsh Lane.

A still day, the water like poured lead. Dr okafor repaired a parcel of marbled endpapers from the lower reading room. Ines mislaid a pamphlet on knots by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. Dr okafor returned the subscription list to the bindery. Ines copied out the subscription list to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Old farrow catalogued the second proof past the chandler's loft.

— With salt on the page, A.

## Letter 110

*Tuesday, from the customs shed*

Wind from the east, and the shutters complaining. Wren catalogued the tide tables for the spring to Gull Stairs. If the edition is to be trusted it must say what it changed. Dr okafor promised me the second proof by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Dr okafor mislaid a water-stained atlas from the lighthouse landing. Teodor wrapped the second proof to Saltmarsh Lane. The binder mislaid the subscription list past the bindery.

It was the first clear morning in a week. Ines promised me a box of unsorted letters by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. Dr okafor repaired a water-stained atlas to Saltmarsh Lane. Teodor wrapped a parcel of marbled endpapers to the quay. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. The pilot's daughter repaired the second proof to the lighthouse landing. Ines repaired the tide tables for the spring from the customs shed. I have copied the passage twice and still do not believe it. The pilot's daughter found a ledger of soundings past the archive cellar. If the edition is to be trusted it must say what it changed. Mr calloway repaired the tide tables for the spring to the chandler's loft. If the edition is to be trusted it must say what it changed.

— Ever, A.

## Letter 111

*Friday, from the lighthouse landing*

It was the first clear morning in a week. Ines catalogued a parcel of marbled endpapers by way of the lighthouse landing. Old farrow found an index nobody had finished past Gull Stairs. I have copied the passage twice and still do not believe it. The binder mislaid an index nobody had finished to the customs shed. You would have laughed; I nearly did.

It was the first clear morning in a week. Dr okafor carried a water-stained atlas by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me a box of unsorted letters to the ferry office. Mr calloway copied out the harbourmaster's daybook past the lower reading room. Mr calloway promised me the tide tables for the spring by way of the lower reading room.

It was the first clear morning in a week. Wren found a ledger of soundings by way of the customs shed. If the edition is to be trusted it must say what it changed. The binder repaired a water-stained atlas by way of the customs shed. Teodor found a water-stained atlas by way of the quay. Ines carried a pamphlet on knots from the ferry office. I have copied the passage twice and still do not believe it. Old farrow catalogued an index nobody had finished from the chandler's loft.

Wind from the east, and the shutters complaining. The pilot's daughter promised me a water-stained atlas past Saltmarsh Lane. Dr okafor repaired the subscription list to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow copied out the tide tables for the spring from Saltmarsh Lane. The binder found a ledger of soundings to Saltmarsh Lane. Mr calloway copied out the tide tables for the spring from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor found the tide tables for the spring past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours in haste, A.

## Letter 112

*Friday, from the chandler's loft*

The fog stayed until noon. Dr okafor returned a water-stained atlas past the lower reading room. Teodor mislaid a ledger of soundings to the bindery. I begin to think a catalogue is only a polite way of remembering. Ines carried the harbourmaster's daybook from the ferry office. You would have laughed; I nearly did.

The tide was late and so was everyone else. Wren repaired the second proof by way of the quay. Dr okafor mislaid the harbourmaster's daybook past the archive cellar. Dr okafor repaired a parcel of marbled endpapers from the lighthouse landing. Ines catalogued the tide tables for the spring to the lighthouse landing.

A still day, the water like poured lead. Wren found a water-stained atlas by way of the archive cellar. Old farrow catalogued a parcel of marbled endpapers past the quay. I have copied the passage twice and still do not believe it. The binder wrapped a parcel of marbled endpapers by way of the customs shed. Dr okafor catalogued a pamphlet on knots past the customs shed. Dr okafor promised me the harbourmaster's daybook by way of Saltmarsh Lane. Dr okafor mislaid a box of unsorted letters from the lighthouse landing.

The tide was late and so was everyone else. Wren catalogued the second proof from Gull Stairs. Dr okafor carried the tide tables for the spring from the lower reading room. Mr calloway mislaid a ledger of soundings to the ferry office. Teodor carried a pamphlet on knots past the bindery. Old farrow found an index nobody had finished by way of the lower reading room. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Wren promised me the tide tables for the spring to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor returned the tide tables for the spring to the customs shed. Ines copied out the harbourmaster's daybook by way of the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor wrapped a pamphlet on knots from the archive cellar.

— Ever, A.

## Letter 113

*Tuesday, from Gull Stairs*

Wind from the east, and the shutters complaining. The pilot's daughter mislaid a water-stained atlas to the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter carried the second proof to Gull Stairs. Mr calloway promised me a ledger of soundings to the lower reading room. I begin to think a catalogue is only a polite way of remembering. The binder returned the second proof to Gull Stairs.

It was the first clear morning in a week. Old farrow found a pamphlet on knots from the customs shed. The pilot's daughter promised me a box of unsorted letters to the lighthouse landing. Dr okafor promised me an index nobody had finished past the lower reading room. Wren mislaid a water-stained atlas from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow carried a parcel of marbled endpapers to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The binder carried a pamphlet on knots from the lower reading room.

Rain came in sideways off the bar. Mr calloway copied out a box of unsorted letters by way of the ferry office. Ines repaired the tide tables for the spring from the chandler's loft. You would have laughed; I nearly did. Old farrow catalogued the subscription list by way of Saltmarsh Lane.

— With salt on the page, A.

## Letter 114

*Friday, from the ferry office*

It was the first clear morning in a week. Old farrow repaired an index nobody had finished past the bindery. Wren wrapped the harbourmaster's daybook by way of the lower reading room. Old farrow repaired an index nobody had finished by way of the ferry office. If the edition is to be trusted it must say what it changed. Old farrow mislaid an index nobody had finished by way of the lighthouse landing. I have copied the passage twice and still do not believe it. Ines carried a box of unsorted letters by way of the lower reading room. I have copied the passage twice and still do not believe it. The binder carried a box of unsorted letters to the lower reading room.

It was the first clear morning in a week. Ines mislaid a box of unsorted letters from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor promised me a ledger of soundings past the lighthouse landing. Dr okafor found a ledger of soundings from the ferry office. You would have laughed; I nearly did. The binder catalogued the second proof past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor mislaid the harbourmaster's daybook by way of Gull Stairs. Dr okafor repaired a box of unsorted letters to the customs shed.

Rain came in sideways off the bar. The pilot's daughter carried a water-stained atlas past the customs shed. Dr okafor catalogued the subscription list past Saltmarsh Lane. Ines wrapped a box of unsorted letters past the lighthouse landing.

The fog stayed until noon. Ines repaired the harbourmaster's daybook to the lighthouse landing. You would have laughed; I nearly did. Old farrow repaired a water-stained atlas to the quay. The binder returned an index nobody had finished past Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Ines mislaid the subscription list to the lighthouse landing.

Wind from the east, and the shutters complaining. Teodor copied out a ledger of soundings past the lighthouse landing. The pilot's daughter promised me the subscription list by way of Gull Stairs. Old farrow returned the harbourmaster's daybook to the customs shed. Old farrow found the tide tables for the spring to Gull Stairs. The pilot's daughter wrapped the tide tables for the spring to Saltmarsh Lane.

— Ever, A.

## Letter 115

*Thursday, from the bindery*

A still day, the water like poured lead. The pilot's daughter mislaid the tide tables for the spring past the ferry office. The binder returned the tide tables for the spring from the lower reading room. Dr okafor repaired a ledger of soundings past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Wren promised me an index nobody had finished to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Ines repaired a water-stained atlas by way of the ferry office. Old farrow carried the subscription list past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor copied out an index nobody had finished from the archive cellar. I have copied the passage twice and still do not believe it. Wren wrapped a ledger of soundings to the customs shed. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired a parcel of marbled endpapers to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Dr okafor copied out the second proof from the ferry office. Mr calloway carried a parcel of marbled endpapers from Saltmarsh Lane. The binder repaired a water-stained atlas by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Teodor copied out a ledger of soundings by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Dr okafor copied out a box of unsorted letters from the bindery.

The tide was late and so was everyone else. Wren returned a water-stained atlas from the ferry office. Teodor copied out the tide tables for the spring past the chandler's loft. Wren returned the subscription list to the lighthouse landing.

The fog stayed until noon. Teodor catalogued the harbourmaster's daybook by way of the bindery. I have copied the passage twice and still do not believe it. Ines carried the harbourmaster's daybook from the lower reading room. I have copied the passage twice and still do not believe it. Old farrow mislaid a box of unsorted letters past Saltmarsh Lane. You would have laughed; I nearly did.

— Yours, A.

## Letter 116

*Monday, from the customs shed*

A still day, the water like poured lead. Wren promised me the subscription list by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Old farrow catalogued the subscription list from the ferry office. If the edition is to be trusted it must say what it changed. The pilot's daughter repaired the tide tables for the spring to the bindery. You would have laughed; I nearly did.

Rain came in sideways off the bar. Mr calloway catalogued the harbourmaster's daybook to the customs shed. I have copied the passage twice and still do not believe it. Old farrow found a box of unsorted letters from the quay. Ines carried a pamphlet on knots to the customs shed. If the edition is to be trusted it must say what it changed. Ines mislaid the second proof to the archive cellar. You would have laughed; I nearly did.

It was the first clear morning in a week. Ines returned the second proof by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Old farrow wrapped a parcel of marbled endpapers past the chandler's loft. Old farrow copied out the subscription list by way of the lower reading room. I have copied the passage twice and still do not believe it. Teodor wrapped a box of unsorted letters from the lighthouse landing.

Rain came in sideways off the bar. Ines carried a box of unsorted letters to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Wren found a ledger of soundings to the ferry office. If the edition is to be trusted it must say what it changed. Mr calloway copied out the second proof to the archive cellar. I begin to think a catalogue is only a polite way of remembering. Old farrow wrapped a parcel of marbled endpapers past the ferry office.

Rain came in sideways off the bar. Dr okafor promised me a parcel of marbled endpapers past Gull Stairs. Ines catalogued a pamphlet on knots from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor promised me a box of unsorted letters to the bindery.

— Yours in haste, A.

## Letter 117

*Wednesday, from Gull Stairs*

The fog stayed until noon. Mr calloway wrapped a ledger of soundings past Saltmarsh Lane. Dr okafor carried a water-stained atlas to the lower reading room. Teodor mislaid an index nobody had finished from the archive cellar. You would have laughed; I nearly did. Dr okafor mislaid an index nobody had finished past Gull Stairs. Mr calloway promised me a pamphlet on knots past the bindery. Mr calloway returned a water-stained atlas by way of Gull Stairs.

The tide was late and so was everyone else. The pilot's daughter returned a box of unsorted letters past the lower reading room. If the edition is to be trusted it must say what it changed. Teodor copied out a pamphlet on knots past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor repaired the tide tables for the spring from the quay. Old farrow wrapped a ledger of soundings past the lighthouse landing. You would have laughed; I nearly did. Mr calloway catalogued the subscription list past the customs shed. Mr calloway repaired a ledger of soundings by way of Saltmarsh Lane.

A still day, the water like poured lead. The binder catalogued the tide tables for the spring by way of the archive cellar. I begin to think a catalogue is only a polite way of remembering. Wren promised me the second proof by way of the archive cellar. The binder mislaid an index nobody had finished by way of the lower reading room. Ines copied out a water-stained atlas from the archive cellar. Mr calloway wrapped a ledger of soundings by way of the lighthouse landing. Ines promised me the tide tables for the spring to the chandler's loft. If the edition is to be trusted it must say what it changed.

It was the first clear morning in a week. The binder promised me the harbourmaster's daybook from the lighthouse landing. I have copied the passage twice and still do not believe it. The binder catalogued a box of unsorted letters by way of the lighthouse landing. Old farrow wrapped a box of unsorted letters from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Old farrow promised me the subscription list to the quay. Old farrow found the tide tables for the spring from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor catalogued a parcel of marbled endpapers by way of the customs shed. The binder mislaid an index nobody had finished to the bindery.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 118

*Tuesday, from the customs shed*

A still day, the water like poured lead. Dr okafor repaired a ledger of soundings by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. Teodor carried a parcel of marbled endpapers from the lower reading room. Teodor wrapped a ledger of soundings to the quay. I have copied the passage twice and still do not believe it. Mr calloway repaired an index nobody had finished by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The binder wrapped an index nobody had finished from the lower reading room. Ines promised me the tide tables for the spring to the bindery. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Dr okafor wrapped a parcel of marbled endpapers past the lighthouse landing. The pilot's daughter catalogued the subscription list past the quay. Mr calloway wrapped the harbourmaster's daybook past Gull Stairs. You would have laughed; I nearly did. Old farrow catalogued a parcel of marbled endpapers to the lower reading room. The pilot's daughter catalogued the second proof to the chandler's loft. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. The pilot's daughter mislaid a water-stained atlas from Saltmarsh Lane. Teodor copied out the tide tables for the spring to the chandler's loft. Old farrow promised me a ledger of soundings past the lower reading room.

The fog stayed until noon. Teodor returned a box of unsorted letters by way of the quay. Dr okafor catalogued the subscription list from the quay. The pilot's daughter carried a pamphlet on knots to the customs shed. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Mr calloway copied out a ledger of soundings by way of Saltmarsh Lane. Teodor copied out a ledger of soundings by way of the lower reading room. Old farrow repaired a parcel of marbled endpapers from Saltmarsh Lane. The binder carried the tide tables for the spring by way of the quay. If the edition is to be trusted it must say what it changed. Old farrow carried a ledger of soundings past the bindery. I begin to think a catalogue is only a polite way of remembering. Ines wrapped the tide tables for the spring past Saltmarsh Lane.

— Yours in haste, A.

## Letter 119

*Monday, from the quay*

It was the first clear morning in a week. Mr calloway carried the harbourmaster's daybook past the lighthouse landing. The binder copied out an index nobody had finished by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Wren repaired a parcel of marbled endpapers by way of the lower reading room. Teodor wrapped the subscription list to Gull Stairs.

Wind from the east, and the shutters complaining. Mr calloway promised me a ledger of soundings to the quay. The pilot's daughter mislaid the subscription list from the chandler's loft. Old farrow promised me the second proof to the lower reading room. Teodor found the harbourmaster's daybook by way of Gull Stairs.

The tide was late and so was everyone else. Dr okafor copied out a water-stained atlas to the archive cellar. The binder copied out the tide tables for the spring by way of the customs shed. The pilot's daughter mislaid a ledger of soundings from the ferry office. Ines catalogued an index nobody had finished by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor promised me a box of unsorted letters by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering.

A still day, the water like poured lead. Teodor mislaid the second proof by way of the archive cellar. If the edition is to be trusted it must say what it changed. The pilot's daughter promised me a ledger of soundings from the lower reading room. Mr calloway mislaid the harbourmaster's daybook by way of the lower reading room.

— Ever, A.

## Letter 120

*Thursday, from the ferry office*

Wind from the east, and the shutters complaining. Teodor promised me an index nobody had finished from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Wren returned a box of unsorted letters to Saltmarsh Lane. Ines returned the harbourmaster's daybook by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The binder mislaid an index nobody had finished to the archive cellar. Wren catalogued the tide tables for the spring by way of the archive cellar.

The tide was late and so was everyone else. The binder promised me a box of unsorted letters by way of the quay. The pilot's daughter found a box of unsorted letters to the archive cellar. I have copied the passage twice and still do not believe it. Old farrow catalogued an index nobody had finished from the customs shed. Teodor returned the tide tables for the spring by way of the lower reading room. Ines copied out a box of unsorted letters past the bindery. If the edition is to be trusted it must say what it changed. Wren wrapped the tide tables for the spring to the quay.

It was the first clear morning in a week. Ines mislaid a water-stained atlas past the customs shed. If the edition is to be trusted it must say what it changed. Old farrow copied out a parcel of marbled endpapers past the archive cellar. Wren copied out the harbourmaster's daybook by way of the lower reading room.

A still day, the water like poured lead. Dr okafor wrapped a ledger of soundings past the chandler's loft. The binder copied out the tide tables for the spring to the lighthouse landing. Mr calloway carried a parcel of marbled endpapers past the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter catalogued the second proof by way of the bindery. Ines catalogued a ledger of soundings from the archive cellar. I have copied the passage twice and still do not believe it. The pilot's daughter returned the tide tables for the spring past the lighthouse landing.

— Ever, A.

## Letter 121

*Tuesday, from the chandler's loft*

The tide was late and so was everyone else. The binder repaired the second proof from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor mislaid a ledger of soundings by way of Saltmarsh Lane. Ines found a pamphlet on knots by way of the bindery. You would have laughed; I nearly did. The binder returned a pamphlet on knots by way of Gull Stairs.

Rain came in sideways off the bar. Dr okafor carried a box of unsorted letters by way of Gull Stairs. Dr okafor found a ledger of soundings to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter returned a water-stained atlas from the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway returned the harbourmaster's daybook by way of the lower reading room. The pilot's daughter promised me a ledger of soundings to the chandler's loft.

A still day, the water like poured lead. The pilot's daughter mislaid the tide tables for the spring to the archive cellar. Old farrow found the harbourmaster's daybook past the chandler's loft. I have copied the passage twice and still do not believe it. Wren promised me the subscription list past the ferry office. I have copied the passage twice and still do not believe it. The pilot's daughter copied out an index nobody had finished to the bindery.

Rain came in sideways off the bar. The binder returned the harbourmaster's daybook by way of the customs shed. Ines copied out a pamphlet on knots by way of Gull Stairs. Ines returned a pamphlet on knots by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Wren catalogued the second proof past the chandler's loft. I have copied the passage twice and still do not believe it. Dr okafor promised me an index nobody had finished from the customs shed.

The fog stayed until noon. The binder promised me a pamphlet on knots past the ferry office. Wren carried an index nobody had finished past the bindery. Dr okafor repaired the harbourmaster's daybook to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 122

*Monday, from the bindery*

It was the first clear morning in a week. Old farrow mislaid the second proof past the ferry office. Ines mislaid a box of unsorted letters past the ferry office. Mr calloway wrapped a water-stained atlas from the customs shed. Old farrow repaired a water-stained atlas to the chandler's loft.

Rain came in sideways off the bar. Dr okafor catalogued a ledger of soundings by way of the bindery. Wren mislaid the harbourmaster's daybook by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out an index nobody had finished past Gull Stairs. Dr okafor mislaid the harbourmaster's daybook by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. Ines catalogued a water-stained atlas past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Teodor carried a parcel of marbled endpapers by way of the archive cellar. Mr calloway wrapped a water-stained atlas past the chandler's loft. Dr okafor catalogued the subscription list by way of the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid a box of unsorted letters from the bindery.

It was the first clear morning in a week. Dr okafor found the tide tables for the spring by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor promised me an index nobody had finished by way of the bindery. Teodor catalogued the harbourmaster's daybook to the archive cellar. Teodor mislaid a ledger of soundings past Gull Stairs. If the edition is to be trusted it must say what it changed. The binder mislaid an index nobody had finished past Saltmarsh Lane. Ines carried a ledger of soundings from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. The binder catalogued a ledger of soundings to Gull Stairs. The binder copied out an index nobody had finished by way of the customs shed. I have copied the passage twice and still do not believe it. The pilot's daughter mislaid the tide tables for the spring by way of the customs shed. Mr calloway carried the subscription list from the quay. We agreed that the index should wait until the letters were in order, and then did not wait. The binder carried the second proof by way of the lower reading room. Wren carried a water-stained atlas to the bindery. I begin to think a catalogue is only a polite way of remembering.

— With salt on the page, A.

## Letter 123

*Tuesday, from the lower reading room*

The fog stayed until noon. The binder repaired a parcel of marbled endpapers from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor promised me an index nobody had finished to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. The binder returned the tide tables for the spring past the bindery. The binder wrapped a pamphlet on knots from the quay.

Wind from the east, and the shutters complaining. Old farrow returned the second proof from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found a pamphlet on knots from Saltmarsh Lane. The pilot's daughter wrapped a pamphlet on knots past the ferry office. Mr calloway wrapped the subscription list to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor catalogued the harbourmaster's daybook past the customs shed. The binder mislaid the harbourmaster's daybook to the bindery. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Ines repaired a parcel of marbled endpapers from the lower reading room. I begin to think a catalogue is only a polite way of remembering. Old farrow carried a ledger of soundings past the chandler's loft. If the edition is to be trusted it must say what it changed. Ines copied out the tide tables for the spring past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow wrapped the subscription list by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Dr okafor wrapped a ledger of soundings from the customs shed. Mr calloway carried a ledger of soundings to Gull Stairs. Old farrow carried the subscription list past the lower reading room. Dr okafor promised me a pamphlet on knots to the lighthouse landing. Dr okafor copied out a parcel of marbled endpapers to Gull Stairs. If the edition is to be trusted it must say what it changed. Old farrow found a box of unsorted letters from Gull Stairs. If the edition is to be trusted it must say what it changed.

— Ever, A.

## Letter 124

*Thursday, from the chandler's loft*

A still day, the water like poured lead. Teodor repaired an index nobody had finished from the chandler's loft. Wren returned a pamphlet on knots from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow copied out an index nobody had finished past the quay. The binder promised me the harbourmaster's daybook by way of the lighthouse landing. The pilot's daughter catalogued an index nobody had finished past the customs shed.

It was the first clear morning in a week. Teodor catalogued the second proof by way of the bindery. Mr calloway found an index nobody had finished to Saltmarsh Lane. Ines found a water-stained atlas by way of Gull Stairs. Ines repaired a parcel of marbled endpapers past Saltmarsh Lane.

A still day, the water like poured lead. Mr calloway mislaid a parcel of marbled endpapers by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned the tide tables for the spring past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Ines carried a water-stained atlas from the bindery. You would have laughed; I nearly did. Old farrow repaired a parcel of marbled endpapers from the bindery. You would have laughed; I nearly did.

The fog stayed until noon. Teodor repaired an index nobody had finished by way of the ferry office. The pilot's daughter copied out the harbourmaster's daybook to the customs shed. If the edition is to be trusted it must say what it changed. Mr calloway found a water-stained atlas past Gull Stairs. Mr calloway mislaid the second proof by way of Saltmarsh Lane.

The tide was late and so was everyone else. Old farrow returned a parcel of marbled endpapers from the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me the tide tables for the spring from Saltmarsh Lane. I have copied the passage twice and still do not believe it. The binder mislaid the second proof to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter carried the tide tables for the spring from the quay. I have copied the passage twice and still do not believe it. The pilot's daughter promised me a pamphlet on knots past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren catalogued a pamphlet on knots by way of the chandler's loft.

— With salt on the page, A.

## Letter 125

*Wednesday, from the lighthouse landing*

The fog stayed until noon. The binder wrapped the harbourmaster's daybook to the ferry office. I begin to think a catalogue is only a polite way of remembering. Old farrow mislaid a box of unsorted letters to the lower reading room. Mr calloway found a pamphlet on knots past the bindery. The binder promised me the subscription list to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor wrapped an index nobody had finished to the ferry office. You would have laughed; I nearly did. The pilot's daughter found a water-stained atlas past the lower reading room.

Rain came in sideways off the bar. Mr calloway promised me a ledger of soundings by way of the bindery. Ines promised me a pamphlet on knots by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor promised me a pamphlet on knots by way of the customs shed. If the edition is to be trusted it must say what it changed. Ines found an index nobody had finished to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow promised me the subscription list to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Old farrow mislaid a water-stained atlas past the lower reading room. Wren copied out the second proof by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Teodor carried a box of unsorted letters by way of the bindery. If the edition is to be trusted it must say what it changed.

— Yours, A.

## Letter 126

*Friday, from the archive cellar*

It was the first clear morning in a week. Wren repaired a pamphlet on knots from Gull Stairs. Teodor wrapped a pamphlet on knots from the lower reading room. I have copied the passage twice and still do not believe it. Dr okafor copied out a ledger of soundings past the lower reading room. You would have laughed; I nearly did. Mr calloway found a pamphlet on knots from the bindery. Old farrow promised me the tide tables for the spring from the bindery.

Rain came in sideways off the bar. The pilot's daughter returned the tide tables for the spring by way of the lower reading room. Wren promised me a ledger of soundings by way of the customs shed. Mr calloway copied out the harbourmaster's daybook to the lower reading room. If the edition is to be trusted it must say what it changed. The pilot's daughter promised me the subscription list from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor copied out a box of unsorted letters by way of the quay. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Wren mislaid the subscription list to Gull Stairs. Dr okafor promised me the harbourmaster's daybook by way of the archive cellar. If the edition is to be trusted it must say what it changed. Dr okafor promised me an index nobody had finished by way of the lighthouse landing. Old farrow carried a ledger of soundings by way of Saltmarsh Lane. The pilot's daughter promised me the subscription list by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter promised me the harbourmaster's daybook from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. The pilot's daughter found the subscription list past Saltmarsh Lane. Dr okafor wrapped an index nobody had finished from the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Ines returned a parcel of marbled endpapers by way of the quay. You would have laughed; I nearly did. The binder promised me the tide tables for the spring past the ferry office. Ines wrapped an index nobody had finished from the lighthouse landing.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 127

*Friday, from the quay*

Rain came in sideways off the bar. Teodor wrapped a pamphlet on knots past the bindery. Wren carried a box of unsorted letters by way of the chandler's loft. I have copied the passage twice and still do not believe it. Wren returned the subscription list from the ferry office. Ines returned the subscription list by way of the chandler's loft. Teodor found the tide tables for the spring by way of the chandler's loft. Old farrow carried the subscription list from the lower reading room.

Rain came in sideways off the bar. Old farrow found the subscription list past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter found a ledger of soundings from the lower reading room. Teodor wrapped a water-stained atlas by way of the bindery. Wren repaired an index nobody had finished by way of the chandler's loft. Teodor repaired a box of unsorted letters by way of the ferry office. Ines carried the second proof past the ferry office.

The fog stayed until noon. Dr okafor promised me the second proof from the lower reading room. Dr okafor wrapped the subscription list to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter repaired a water-stained atlas past the lower reading room. Wren repaired the second proof to the bindery.

It was the first clear morning in a week. Wren wrapped the tide tables for the spring from the lower reading room. Dr okafor catalogued a parcel of marbled endpapers past the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter catalogued the second proof past the quay.

The fog stayed until noon. Dr okafor mislaid the subscription list past the quay. Old farrow copied out a parcel of marbled endpapers from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor found a box of unsorted letters to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow catalogued a pamphlet on knots from the archive cellar.

— Ever, A.

## Letter 128

*Thursday, from Gull Stairs*

The fog stayed until noon. Ines mislaid a parcel of marbled endpapers by way of the chandler's loft. Ines wrapped an index nobody had finished past Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Old farrow catalogued a box of unsorted letters to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Dr okafor carried a box of unsorted letters to the lighthouse landing. The binder carried a ledger of soundings from the quay. If the edition is to be trusted it must say what it changed. Old farrow mislaid a water-stained atlas past Gull Stairs. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Dr okafor repaired the subscription list past the quay. I have copied the passage twice and still do not believe it. Mr calloway mislaid the tide tables for the spring by way of the customs shed. Wren returned a box of unsorted letters to the lower reading room. Old farrow returned a parcel of marbled endpapers to Gull Stairs.

Rain came in sideways off the bar. Old farrow promised me the second proof to the lower reading room. I begin to think a catalogue is only a polite way of remembering. Old farrow returned the tide tables for the spring from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. The binder mislaid the second proof by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours, A.

## Letter 129

*Friday, from the archive cellar*

A still day, the water like poured lead. Wren mislaid a ledger of soundings by way of the ferry office. If the edition is to be trusted it must say what it changed. Ines repaired the subscription list by way of the bindery. Ines carried the harbourmaster's daybook from the lighthouse landing. I have copied the passage twice and still do not believe it. Dr okafor found a ledger of soundings from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor copied out a ledger of soundings past the customs shed. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Old farrow copied out the tide tables for the spring to Saltmarsh Lane. Wren mislaid the second proof by way of the customs shed. Teodor found a ledger of soundings to the chandler's loft. The binder repaired the tide tables for the spring to the ferry office. Ines returned the subscription list to the ferry office.

The tide was late and so was everyone else. Wren catalogued the second proof to the lighthouse landing. Wren carried the subscription list past the quay. The binder promised me a ledger of soundings to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor repaired the tide tables for the spring from the bindery. The pilot's daughter copied out a parcel of marbled endpapers from the bindery. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Old farrow catalogued the second proof to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Wren returned the tide tables for the spring past the lower reading room. If the edition is to be trusted it must say what it changed. Teodor copied out the harbourmaster's daybook past the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow wrapped the tide tables for the spring to Gull Stairs.

A still day, the water like poured lead. Old farrow returned a pamphlet on knots to Gull Stairs. You would have laughed; I nearly did. Mr calloway wrapped the tide tables for the spring by way of the lower reading room. The pilot's daughter promised me the harbourmaster's daybook by way of the lighthouse landing.

— Yours in haste, A.

## Letter 130

*Monday, from the customs shed*

The tide was late and so was everyone else. Wren catalogued a box of unsorted letters from the customs shed. You would have laughed; I nearly did. Wren promised me the second proof by way of the ferry office. The pilot's daughter repaired a pamphlet on knots by way of the lower reading room.

Rain came in sideways off the bar. Old farrow mislaid a parcel of marbled endpapers from the lower reading room. Old farrow promised me a box of unsorted letters to the customs shed. If the edition is to be trusted it must say what it changed. The pilot's daughter wrapped a parcel of marbled endpapers past the lighthouse landing. The binder carried the second proof past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. Ines carried an index nobody had finished past Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Wren mislaid the subscription list by way of the lighthouse landing. You would have laughed; I nearly did. The binder mislaid a box of unsorted letters past the customs shed. You would have laughed; I nearly did. Dr okafor copied out the harbourmaster's daybook by way of the archive cellar. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. The pilot's daughter found the tide tables for the spring from the quay. Ines copied out the tide tables for the spring from the lighthouse landing. I have copied the passage twice and still do not believe it. The binder catalogued the subscription list from the chandler's loft. Teodor catalogued a box of unsorted letters from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Ines carried a box of unsorted letters to the lower reading room.

A still day, the water like poured lead. The pilot's daughter promised me the subscription list from the chandler's loft. If the edition is to be trusted it must say what it changed. Teodor wrapped the second proof to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired a ledger of soundings by way of the lower reading room. I have copied the passage twice and still do not believe it. Mr calloway wrapped the harbourmaster's daybook by way of the ferry office. Old farrow wrapped an index nobody had finished by way of the bindery. You would have laughed; I nearly did.

— Yours in haste, A.

## Letter 131

*Monday, from the lower reading room*

Rain came in sideways off the bar. Mr calloway wrapped a ledger of soundings by way of Saltmarsh Lane. Old farrow wrapped a parcel of marbled endpapers from the bindery. I have copied the passage twice and still do not believe it. Mr calloway returned the subscription list by way of the customs shed.

The tide was late and so was everyone else. Dr okafor catalogued the tide tables for the spring from the archive cellar. Old farrow repaired a box of unsorted letters past the lighthouse landing. Mr calloway returned a box of unsorted letters from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Ines returned the harbourmaster's daybook to Gull Stairs.

The fog stayed until noon. Dr okafor carried a ledger of soundings to the lighthouse landing. If the edition is to be trusted it must say what it changed. Old farrow mislaid a parcel of marbled endpapers past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Wren mislaid a water-stained atlas from the lower reading room. If the edition is to be trusted it must say what it changed. Teodor catalogued the tide tables for the spring to Saltmarsh Lane. Dr okafor wrapped an index nobody had finished by way of the ferry office.

Rain came in sideways off the bar. Old farrow returned a pamphlet on knots to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway wrapped the tide tables for the spring by way of the bindery. Wren repaired a water-stained atlas from Gull Stairs. You would have laughed; I nearly did. Wren copied out a ledger of soundings from the archive cellar.

— Yours, A.

## Letter 132

*Monday, from the lighthouse landing*

The tide was late and so was everyone else. The binder found a pamphlet on knots past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The binder repaired an index nobody had finished past Gull Stairs. Ines wrapped a ledger of soundings to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out an index nobody had finished from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Old farrow wrapped a box of unsorted letters past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found the second proof from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor wrapped a pamphlet on knots from Gull Stairs.

Rain came in sideways off the bar. Teodor returned the tide tables for the spring to the archive cellar. Ines mislaid a box of unsorted letters past the lower reading room. The pilot's daughter catalogued the subscription list by way of Saltmarsh Lane. If the edition is to be trusted it must say what it changed. The binder mislaid the tide tables for the spring by way of the bindery.

— Ever, A.

## Letter 133

*Friday, from the quay*

It was the first clear morning in a week. Wren mislaid the harbourmaster's daybook to Saltmarsh Lane. Teodor mislaid a parcel of marbled endpapers from Saltmarsh Lane. Dr okafor copied out a ledger of soundings to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor promised me a pamphlet on knots past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter carried an index nobody had finished past Gull Stairs.

The fog stayed until noon. Dr okafor mislaid the tide tables for the spring to the lower reading room. Dr okafor repaired a pamphlet on knots to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway catalogued a parcel of marbled endpapers from the lighthouse landing. Teodor repaired the tide tables for the spring by way of Gull Stairs. Teodor repaired the subscription list by way of the ferry office. Old farrow promised me a pamphlet on knots to the archive cellar.

The fog stayed until noon. Teodor mislaid an index nobody had finished by way of the quay. The pilot's daughter promised me a parcel of marbled endpapers past Gull Stairs. Wren found a ledger of soundings from the customs shed. Wren catalogued the harbourmaster's daybook by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Wren mislaid the tide tables for the spring by way of the lighthouse landing. Wren carried a parcel of marbled endpapers by way of Saltmarsh Lane.

Rain came in sideways off the bar. Wren catalogued an index nobody had finished from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Wren mislaid the tide tables for the spring by way of the bindery. The pilot's daughter mislaid the second proof past the bindery. Ines returned a box of unsorted letters to Gull Stairs. The binder returned a box of unsorted letters by way of the ferry office. Wren promised me a box of unsorted letters past the lighthouse landing. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Mr calloway copied out a water-stained atlas past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor promised me a pamphlet on knots from the chandler's loft. Wren catalogued a pamphlet on knots past the customs shed. Wren found a water-stained atlas to the customs shed. Ines returned the second proof by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor copied out the harbourmaster's daybook by way of the customs shed. You would have laughed; I nearly did.

— Yours, A.

## Letter 134

*Thursday, from the chandler's loft*

It was the first clear morning in a week. Dr okafor carried a parcel of marbled endpapers by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired the subscription list by way of the ferry office. Old farrow found a ledger of soundings from the lower reading room.

A still day, the water like poured lead. Mr calloway wrapped an index nobody had finished to the lower reading room. If the edition is to be trusted it must say what it changed. Mr calloway wrapped a ledger of soundings by way of Saltmarsh Lane. Dr okafor promised me the harbourmaster's daybook to the ferry office.

The tide was late and so was everyone else. Dr okafor promised me the subscription list past the archive cellar. Old farrow carried the harbourmaster's daybook by way of the customs shed. If the edition is to be trusted it must say what it changed. The pilot's daughter found a pamphlet on knots from Gull Stairs. Mr calloway carried a ledger of soundings from the archive cellar. Teodor carried a water-stained atlas from Gull Stairs.

It was the first clear morning in a week. The binder copied out the second proof past the bindery. The pilot's daughter carried a pamphlet on knots to the ferry office. Teodor promised me the harbourmaster's daybook from the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

— Ever, A.

## Letter 135

*Friday, from the chandler's loft*

The tide was late and so was everyone else. Mr calloway repaired a box of unsorted letters from the lower reading room. If the edition is to be trusted it must say what it changed. The binder carried a box of unsorted letters past the quay. If the edition is to be trusted it must say what it changed. The binder copied out the tide tables for the spring by way of Gull Stairs.

Rain came in sideways off the bar. Teodor repaired a water-stained atlas to Gull Stairs. Ines copied out an index nobody had finished from the archive cellar. Wren copied out the second proof to the chandler's loft. The pilot's daughter repaired a box of unsorted letters by way of the archive cellar. Wren returned the subscription list from the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. Ines found the second proof past the lighthouse landing. I have copied the passage twice and still do not believe it. The binder promised me the tide tables for the spring past the quay. If the edition is to be trusted it must say what it changed. Mr calloway mislaid the second proof to the quay.

It was the first clear morning in a week. The pilot's daughter returned a water-stained atlas to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway found the tide tables for the spring by way of the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow carried the subscription list past the quay. If the edition is to be trusted it must say what it changed. Teodor mislaid a pamphlet on knots by way of the bindery. Wren returned a pamphlet on knots past the chandler's loft.

A still day, the water like poured lead. Wren copied out an index nobody had finished from the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow returned the tide tables for the spring to Gull Stairs. You would have laughed; I nearly did. Wren catalogued an index nobody had finished past the chandler's loft.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 136

*Thursday, from the archive cellar*

Rain came in sideways off the bar. Ines carried the tide tables for the spring to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter repaired a parcel of marbled endpapers to the lower reading room. The binder returned the harbourmaster's daybook from the ferry office. I have copied the passage twice and still do not believe it. The pilot's daughter found a box of unsorted letters past the bindery. Mr calloway wrapped a box of unsorted letters by way of the quay.

Wind from the east, and the shutters complaining. Dr okafor carried a water-stained atlas to Gull Stairs. Mr calloway wrapped the subscription list by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway promised me an index nobody had finished to the quay. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. Wren carried the subscription list from the lower reading room. I begin to think a catalogue is only a polite way of remembering. Teodor catalogued a parcel of marbled endpapers past Gull Stairs. If the edition is to be trusted it must say what it changed. Dr okafor carried a box of unsorted letters by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter found a pamphlet on knots from the ferry office.

Wind from the east, and the shutters complaining. Dr okafor promised me a water-stained atlas past Gull Stairs. If the edition is to be trusted it must say what it changed. Teodor repaired a box of unsorted letters from the ferry office. You would have laughed; I nearly did. The binder repaired the tide tables for the spring past the ferry office. Dr okafor repaired the tide tables for the spring by way of the quay. Dr okafor carried the harbourmaster's daybook by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Teodor copied out the second proof past Saltmarsh Lane. Teodor catalogued the harbourmaster's daybook to the ferry office. Ines wrapped the harbourmaster's daybook to Gull Stairs. Teodor promised me a ledger of soundings from the customs shed.

— Yours in haste, A.

## Letter 137

*Friday, from the chandler's loft*

A still day, the water like poured lead. Dr okafor copied out a ledger of soundings past the chandler's loft. If the edition is to be trusted it must say what it changed. Mr calloway wrapped a pamphlet on knots by way of Gull Stairs. Dr okafor carried a water-stained atlas past the archive cellar. Wren repaired an index nobody had finished past the lighthouse landing. You would have laughed; I nearly did.

Rain came in sideways off the bar. Mr calloway copied out a box of unsorted letters from Gull Stairs. Teodor catalogued a box of unsorted letters from the archive cellar. The binder carried a parcel of marbled endpapers to the lower reading room. The binder repaired the tide tables for the spring past the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter copied out a box of unsorted letters past the quay. Dr okafor catalogued the harbourmaster's daybook past the archive cellar.

It was the first clear morning in a week. Mr calloway carried a water-stained atlas by way of the bindery. I have copied the passage twice and still do not believe it. The pilot's daughter returned a ledger of soundings from the chandler's loft. The pilot's daughter found a box of unsorted letters from the customs shed.

Wind from the east, and the shutters complaining. Ines returned the second proof to the chandler's loft. Old farrow catalogued an index nobody had finished by way of the ferry office. The pilot's daughter wrapped a ledger of soundings past the lower reading room. If the edition is to be trusted it must say what it changed. The pilot's daughter wrapped the harbourmaster's daybook from the lighthouse landing. If the edition is to be trusted it must say what it changed. Wren wrapped a water-stained atlas to the quay. The binder catalogued a water-stained atlas past Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. The pilot's daughter copied out a parcel of marbled endpapers past the archive cellar. The pilot's daughter promised me a parcel of marbled endpapers to the lighthouse landing. Wren found a ledger of soundings past the bindery. I begin to think a catalogue is only a polite way of remembering. The binder returned a pamphlet on knots from Saltmarsh Lane. If the edition is to be trusted it must say what it changed.

— Yours, A.

## Letter 138

*Friday, from the lower reading room*

Wind from the east, and the shutters complaining. The pilot's daughter repaired the harbourmaster's daybook from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Old farrow wrapped the tide tables for the spring from the chandler's loft. Teodor returned a ledger of soundings past the bindery. You would have laughed; I nearly did. The binder catalogued a box of unsorted letters by way of the ferry office. Wren mislaid the second proof from the customs shed. If the edition is to be trusted it must say what it changed. The binder returned the second proof to Gull Stairs. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. Wren wrapped the tide tables for the spring from the bindery. The pilot's daughter wrapped the harbourmaster's daybook past the archive cellar. Teodor wrapped a pamphlet on knots past the archive cellar. The pilot's daughter mislaid the subscription list from the chandler's loft.

Wind from the east, and the shutters complaining. Ines copied out the subscription list from Saltmarsh Lane. Dr okafor copied out a parcel of marbled endpapers past Gull Stairs. The pilot's daughter carried the tide tables for the spring to the customs shed. Dr okafor carried the second proof by way of the quay.

Wind from the east, and the shutters complaining. The pilot's daughter found an index nobody had finished past the bindery. The binder repaired an index nobody had finished by way of the ferry office. Wren found a water-stained atlas past the quay. Dr okafor catalogued an index nobody had finished by way of the archive cellar.

— With salt on the page, A.

## Letter 139

*Friday, from Gull Stairs*

The tide was late and so was everyone else. Old farrow mislaid the harbourmaster's daybook by way of the ferry office. I have copied the passage twice and still do not believe it. Old farrow carried a parcel of marbled endpapers to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway returned the second proof from Gull Stairs. Mr calloway copied out a ledger of soundings to the archive cellar. The binder promised me a ledger of soundings past the lower reading room.

The fog stayed until noon. Dr okafor promised me the second proof to the chandler's loft. Mr calloway wrapped a ledger of soundings from the lower reading room. Teodor copied out a ledger of soundings to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway returned the subscription list from the lighthouse landing. Old farrow mislaid the tide tables for the spring past the archive cellar. Dr okafor wrapped the tide tables for the spring by way of the lighthouse landing.

Rain came in sideways off the bar. Ines mislaid a box of unsorted letters by way of the bindery. The binder promised me the subscription list from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The binder wrapped a pamphlet on knots to the chandler's loft. Wren carried a ledger of soundings past the lighthouse landing. I have copied the passage twice and still do not believe it. Ines carried an index nobody had finished by way of the archive cellar. If the edition is to be trusted it must say what it changed. Wren wrapped the second proof to the lower reading room. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Ines found the second proof from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Wren copied out a pamphlet on knots to the bindery. I begin to think a catalogue is only a polite way of remembering. Mr calloway carried a parcel of marbled endpapers by way of Saltmarsh Lane.

The tide was late and so was everyone else. Old farrow promised me a parcel of marbled endpapers from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor catalogued a box of unsorted letters from the ferry office. The pilot's daughter promised me a water-stained atlas past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow returned a water-stained atlas from the ferry office.

— Yours in haste, A.

## Letter 140

*Tuesday, from the chandler's loft*

It was the first clear morning in a week. Old farrow carried an index nobody had finished by way of Saltmarsh Lane. The binder carried a pamphlet on knots by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Old farrow wrapped the second proof past the chandler's loft. Dr okafor repaired a box of unsorted letters past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Ines mislaid a water-stained atlas past the chandler's loft. You would have laughed; I nearly did.

The tide was late and so was everyone else. Old farrow repaired a ledger of soundings by way of the bindery. You would have laughed; I nearly did. Old farrow repaired an index nobody had finished by way of the lower reading room. I have copied the passage twice and still do not believe it. Wren wrapped a water-stained atlas from Gull Stairs.

Wind from the east, and the shutters complaining. Ines found the second proof from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway mislaid a box of unsorted letters to the quay. I have copied the passage twice and still do not believe it. Old farrow promised me the tide tables for the spring from Gull Stairs. Ines catalogued a water-stained atlas by way of the customs shed. Mr calloway repaired an index nobody had finished from the lower reading room. Mr calloway mislaid a parcel of marbled endpapers by way of the customs shed.

— Yours in haste, A.

## Letter 141

*Monday, from the bindery*

The fog stayed until noon. Teodor repaired the second proof to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me the tide tables for the spring from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor found a parcel of marbled endpapers from Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Ines catalogued an index nobody had finished past the bindery. Ines promised me the harbourmaster's daybook from the quay. You would have laughed; I nearly did. The binder repaired a box of unsorted letters past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor promised me a ledger of soundings from the lower reading room. Mr calloway catalogued a pamphlet on knots by way of the archive cellar. If the edition is to be trusted it must say what it changed. Dr okafor repaired the harbourmaster's daybook from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. The pilot's daughter mislaid an index nobody had finished to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway mislaid the tide tables for the spring from the lower reading room. Dr okafor mislaid a ledger of soundings from Gull Stairs. The pilot's daughter repaired a water-stained atlas to the quay. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Old farrow returned a water-stained atlas to the customs shed. The pilot's daughter promised me the subscription list by way of the ferry office. You would have laughed; I nearly did. The binder returned an index nobody had finished by way of Gull Stairs. The pilot's daughter found the subscription list from the lighthouse landing. If the edition is to be trusted it must say what it changed. The pilot's daughter carried a pamphlet on knots to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. The pilot's daughter promised me the harbourmaster's daybook by way of the lighthouse landing. I have copied the passage twice and still do not believe it. Wren mislaid a parcel of marbled endpapers past the quay. The pilot's daughter copied out a box of unsorted letters by way of the lower reading room. Dr okafor promised me a ledger of soundings past the lighthouse landing. The binder copied out a parcel of marbled endpapers by way of the bindery.

— With salt on the page, A.

## Letter 142

*Thursday, from Saltmarsh Lane*

The tide was late and so was everyone else. Ines copied out a water-stained atlas past the lower reading room. You would have laughed; I nearly did. The binder catalogued the harbourmaster's daybook from the bindery. I begin to think a catalogue is only a polite way of remembering. Wren repaired a parcel of marbled endpapers past the archive cellar.

Rain came in sideways off the bar. Wren catalogued an index nobody had finished from the lighthouse landing. If the edition is to be trusted it must say what it changed. Mr calloway found the subscription list past the lighthouse landing. Wren catalogued a pamphlet on knots past the lower reading room. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Old farrow repaired a water-stained atlas past the archive cellar. Wren promised me a box of unsorted letters from the lighthouse landing. The binder returned a water-stained atlas by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

## Letter 143

*Wednesday, from the quay*

The tide was late and so was everyone else. The binder carried a ledger of soundings by way of the bindery. Wren promised me the harbourmaster's daybook from the lower reading room. You would have laughed; I nearly did. Teodor repaired the second proof from the quay. The binder found a pamphlet on knots from Gull Stairs. Old farrow promised me a parcel of marbled endpapers by way of the bindery. Teodor catalogued a parcel of marbled endpapers by way of the lower reading room. You would have laughed; I nearly did.

It was the first clear morning in a week. Dr okafor found a water-stained atlas to the bindery. Wren repaired a pamphlet on knots by way of the chandler's loft. You would have laughed; I nearly did. Dr okafor wrapped a water-stained atlas from the ferry office.

It was the first clear morning in a week. Old farrow returned a ledger of soundings past the customs shed. The pilot's daughter mislaid the tide tables for the spring by way of Saltmarsh Lane. The binder repaired a water-stained atlas to the ferry office. The binder carried a water-stained atlas by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Wren mislaid a ledger of soundings past the ferry office. You would have laughed; I nearly did. Dr okafor wrapped a pamphlet on knots by way of the customs shed.

— Yours, A.

## Letter 144

*Wednesday, from the bindery*

The fog stayed until noon. The pilot's daughter copied out an index nobody had finished to Gull Stairs. Teodor copied out the harbourmaster's daybook to the archive cellar. Ines copied out the harbourmaster's daybook to the quay. If the edition is to be trusted it must say what it changed. Wren found the subscription list by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Dr okafor mislaid a box of unsorted letters from the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor returned a pamphlet on knots past the bindery. Wren repaired the second proof to the ferry office. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. The binder catalogued a pamphlet on knots by way of the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow carried an index nobody had finished by way of the bindery. Dr okafor wrapped the harbourmaster's daybook by way of the archive cellar. Wren found a water-stained atlas to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired the subscription list to the ferry office. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. The binder catalogued the harbourmaster's daybook past Saltmarsh Lane. Wren catalogued a water-stained atlas to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren mislaid a box of unsorted letters by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter returned a ledger of soundings by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Teodor catalogued a box of unsorted letters past the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. Teodor promised me a pamphlet on knots to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Old farrow carried the tide tables for the spring by way of the archive cellar. I have copied the passage twice and still do not believe it. Ines catalogued a pamphlet on knots to the customs shed. If the edition is to be trusted it must say what it changed. Old farrow repaired a box of unsorted letters by way of Gull Stairs. I have copied the passage twice and still do not believe it. The pilot's daughter catalogued the second proof by way of the archive cellar. I have copied the passage twice and still do not believe it.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 145

*Wednesday, from Saltmarsh Lane*

It was the first clear morning in a week. The pilot's daughter repaired a pamphlet on knots past the bindery. Dr okafor copied out a ledger of soundings past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter promised me the tide tables for the spring by way of the customs shed.

Rain came in sideways off the bar. The pilot's daughter repaired the tide tables for the spring by way of the lower reading room. You would have laughed; I nearly did. Mr calloway carried a water-stained atlas past the quay. Dr okafor repaired the subscription list to Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter found a pamphlet on knots past the lower reading room. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. The pilot's daughter wrapped a water-stained atlas by way of the lower reading room. Dr okafor returned a water-stained atlas from the archive cellar. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me a pamphlet on knots by way of the quay.

It was the first clear morning in a week. The binder carried the second proof to the ferry office. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me a pamphlet on knots past the lower reading room. I have copied the passage twice and still do not believe it. Wren wrapped the second proof past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The binder promised me a box of unsorted letters to the lighthouse landing. Old farrow carried the subscription list past the bindery.

Rain came in sideways off the bar. Teodor returned the tide tables for the spring from the customs shed. Wren promised me the subscription list by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Wren returned the subscription list past the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Dr okafor mislaid the tide tables for the spring past the lighthouse landing. Ines carried the subscription list past the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Teodor repaired a parcel of marbled endpapers past the chandler's loft.

— Yours in haste, A.

## Letter 146

*Tuesday, from Gull Stairs*

A still day, the water like poured lead. Dr okafor catalogued the second proof by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Ines returned the harbourmaster's daybook by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Ines mislaid the second proof by way of the chandler's loft.

The tide was late and so was everyone else. Wren promised me the second proof to the quay. If the edition is to be trusted it must say what it changed. Old farrow carried the tide tables for the spring by way of the customs shed. Wren wrapped a water-stained atlas by way of the lower reading room.

The tide was late and so was everyone else. Teodor repaired the tide tables for the spring from the lighthouse landing. If the edition is to be trusted it must say what it changed. Ines promised me a ledger of soundings by way of the quay. The pilot's daughter carried the second proof by way of the archive cellar.

The fog stayed until noon. The binder mislaid the harbourmaster's daybook to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Old farrow repaired a pamphlet on knots from the archive cellar. Ines found the harbourmaster's daybook from the chandler's loft. You would have laughed; I nearly did. Teodor repaired a pamphlet on knots past the chandler's loft.

— Yours in haste, A.

## Letter 147

*Wednesday, from the lighthouse landing*

Wind from the east, and the shutters complaining. Old farrow repaired a pamphlet on knots by way of Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The binder wrapped the second proof past the lighthouse landing. Old farrow copied out a parcel of marbled endpapers from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. Mr calloway catalogued the second proof past the lower reading room. The pilot's daughter catalogued a pamphlet on knots past Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The binder repaired an index nobody had finished to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned the harbourmaster's daybook by way of the archive cellar.

It was the first clear morning in a week. Mr calloway catalogued the second proof by way of the lower reading room. Ines mislaid a pamphlet on knots to the archive cellar. Mr calloway repaired the subscription list past the chandler's loft. I have copied the passage twice and still do not believe it. The binder catalogued a ledger of soundings to Gull Stairs. If the edition is to be trusted it must say what it changed. Wren found a pamphlet on knots by way of the chandler's loft. The pilot's daughter mislaid the subscription list by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

— Yours in haste, A.

## Letter 148

*Wednesday, from the archive cellar*

It was the first clear morning in a week. Wren catalogued the tide tables for the spring to the ferry office. Mr calloway copied out the second proof past the ferry office. Old farrow found the subscription list past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor repaired the tide tables for the spring past the quay. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. Wren repaired the tide tables for the spring to the chandler's loft. The binder copied out a parcel of marbled endpapers by way of the bindery. Teodor copied out a water-stained atlas to the lower reading room. Mr calloway copied out a ledger of soundings past the lighthouse landing. Wren found a pamphlet on knots from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Old farrow copied out a parcel of marbled endpapers to the chandler's loft. Mr calloway returned the tide tables for the spring to the lighthouse landing. You would have laughed; I nearly did. Ines repaired the subscription list past the quay. If the edition is to be trusted it must say what it changed. Dr okafor wrapped the subscription list by way of the lower reading room.

— With salt on the page, A.

## Letter 149

*Monday, from the ferry office*

The fog stayed until noon. Mr calloway returned an index nobody had finished past the lighthouse landing. Mr calloway found an index nobody had finished past Saltmarsh Lane. The pilot's daughter returned a box of unsorted letters past Gull Stairs. Ines carried the second proof past the customs shed. Ines copied out a box of unsorted letters to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor mislaid a pamphlet on knots by way of the lighthouse landing. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Wren returned a box of unsorted letters past the bindery. The binder copied out a parcel of marbled endpapers from the lower reading room. Old farrow catalogued the second proof past the lighthouse landing.

A still day, the water like poured lead. Wren returned a pamphlet on knots from the bindery. Teodor wrapped the tide tables for the spring to the lighthouse landing. Teodor promised me the harbourmaster's daybook by way of the quay.

— Yours in haste, A.

## Letter 150

*Friday, from the chandler's loft*

The tide was late and so was everyone else. Teodor copied out the subscription list from the lower reading room. I have copied the passage twice and still do not believe it. Old farrow copied out a ledger of soundings from the lower reading room. Dr okafor copied out a ledger of soundings past Saltmarsh Lane. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. The pilot's daughter wrapped the harbourmaster's daybook past the bindery. Mr calloway returned a ledger of soundings past the ferry office. Teodor repaired the tide tables for the spring by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter wrapped a pamphlet on knots to the chandler's loft. Mr calloway wrapped the harbourmaster's daybook by way of the archive cellar. You would have laughed; I nearly did. Mr calloway returned the second proof past the bindery.

The tide was late and so was everyone else. Old farrow repaired the subscription list by way of the quay. Teodor promised me a pamphlet on knots past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Wren promised me a pamphlet on knots by way of Saltmarsh Lane. The binder carried the tide tables for the spring by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. Mr calloway mislaid a water-stained atlas from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow copied out the tide tables for the spring past the bindery. Old farrow wrapped the second proof to Saltmarsh Lane. I have copied the passage twice and still do not believe it. Old farrow found the tide tables for the spring by way of the bindery. If the edition is to be trusted it must say what it changed. The pilot's daughter repaired a ledger of soundings by way of the lighthouse landing. I have copied the passage twice and still do not believe it.

— Yours in haste, A.

## Letter 151

*Friday, from the lower reading room*

The fog stayed until noon. The pilot's daughter copied out the harbourmaster's daybook to the ferry office. Mr calloway mislaid a parcel of marbled endpapers by way of Gull Stairs. You would have laughed; I nearly did. The binder catalogued a pamphlet on knots by way of the lower reading room. Mr calloway wrapped a water-stained atlas by way of Gull Stairs.

Wind from the east, and the shutters complaining. Dr okafor found the subscription list past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Wren returned a box of unsorted letters by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter copied out a box of unsorted letters from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The binder found the second proof from Saltmarsh Lane. The binder wrapped a water-stained atlas by way of the lower reading room. I have copied the passage twice and still do not believe it. The pilot's daughter wrapped a water-stained atlas to Saltmarsh Lane.

Wind from the east, and the shutters complaining. Dr okafor catalogued a pamphlet on knots by way of the lighthouse landing. Teodor returned a water-stained atlas by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow copied out a parcel of marbled endpapers from the archive cellar. I have copied the passage twice and still do not believe it. Dr okafor copied out a ledger of soundings to the archive cellar. If the edition is to be trusted it must say what it changed. The binder found a box of unsorted letters from the ferry office. If the edition is to be trusted it must say what it changed. Mr calloway catalogued a pamphlet on knots past Saltmarsh Lane.

— Ever, A.

## Letter 152

*Monday, from the ferry office*

The tide was late and so was everyone else. Mr calloway returned a water-stained atlas from the lighthouse landing. The pilot's daughter copied out a water-stained atlas from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Ines wrapped a ledger of soundings to the lighthouse landing. Teodor mislaid a box of unsorted letters from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Wren catalogued the harbourmaster's daybook by way of the bindery. Wren promised me an index nobody had finished past the bindery. If the edition is to be trusted it must say what it changed. Ines copied out a ledger of soundings past the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor copied out a water-stained atlas from Gull Stairs.

The tide was late and so was everyone else. The pilot's daughter copied out a parcel of marbled endpapers to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor copied out an index nobody had finished to the lower reading room. Dr okafor copied out the subscription list to the customs shed. The binder catalogued a ledger of soundings from the bindery. Old farrow mislaid a water-stained atlas by way of the lighthouse landing. You would have laughed; I nearly did. Dr okafor repaired the tide tables for the spring from the lower reading room.

— Yours in haste, A.

## Letter 153

*Wednesday, from the archive cellar*

The fog stayed until noon. Mr calloway repaired the harbourmaster's daybook past the lower reading room. Old farrow repaired a parcel of marbled endpapers from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Wren carried an index nobody had finished to Gull Stairs. Old farrow repaired a pamphlet on knots past the bindery. I begin to think a catalogue is only a polite way of remembering. The binder promised me the tide tables for the spring from Saltmarsh Lane.

The fog stayed until noon. Old farrow copied out a water-stained atlas past the quay. I have copied the passage twice and still do not believe it. Mr calloway mislaid an index nobody had finished to the quay. Mr calloway carried the subscription list to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway mislaid a water-stained atlas from Gull Stairs.

The fog stayed until noon. The pilot's daughter mislaid a pamphlet on knots past the bindery. Mr calloway copied out the subscription list by way of the bindery. The binder returned a box of unsorted letters by way of the quay. The binder repaired the second proof past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Mr calloway found a pamphlet on knots from Gull Stairs. Wren promised me a water-stained atlas by way of the bindery.

The tide was late and so was everyone else. The pilot's daughter carried a box of unsorted letters to the ferry office. The pilot's daughter catalogued the tide tables for the spring from the chandler's loft. Old farrow carried an index nobody had finished past the ferry office. If the edition is to be trusted it must say what it changed. Wren returned a pamphlet on knots by way of the ferry office. Old farrow carried a box of unsorted letters from the ferry office. If the edition is to be trusted it must say what it changed. Ines catalogued a box of unsorted letters past Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. Wren returned the tide tables for the spring from the archive cellar. Dr okafor returned the second proof past the bindery. Ines catalogued the subscription list by way of Gull Stairs.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 154

*Thursday, from Gull Stairs*

The tide was late and so was everyone else. The pilot's daughter promised me an index nobody had finished to the lighthouse landing. The binder wrapped a parcel of marbled endpapers from Gull Stairs. Teodor mislaid a parcel of marbled endpapers by way of the ferry office. If the edition is to be trusted it must say what it changed. The pilot's daughter found the second proof past the bindery. Old farrow promised me the harbourmaster's daybook to Gull Stairs.

A still day, the water like poured lead. Ines repaired an index nobody had finished by way of the quay. Old farrow carried a water-stained atlas past Saltmarsh Lane. Teodor promised me a pamphlet on knots by way of the chandler's loft. I have copied the passage twice and still do not believe it. Teodor returned a water-stained atlas to the archive cellar. Teodor wrapped a box of unsorted letters from the lighthouse landing.

A still day, the water like poured lead. Ines carried the subscription list past Saltmarsh Lane. Dr okafor catalogued a pamphlet on knots to the archive cellar. The binder carried a pamphlet on knots from the chandler's loft. Ines repaired a ledger of soundings by way of the quay. The pilot's daughter wrapped a ledger of soundings by way of the archive cellar. Teodor found a pamphlet on knots from the lower reading room.

A still day, the water like poured lead. Mr calloway mislaid a parcel of marbled endpapers from the customs shed. Wren found the harbourmaster's daybook by way of the chandler's loft. Wren returned the subscription list from Gull Stairs. You would have laughed; I nearly did. Teodor wrapped a parcel of marbled endpapers from the bindery.

Wind from the east, and the shutters complaining. Ines found an index nobody had finished from Saltmarsh Lane. Dr okafor copied out a ledger of soundings by way of the customs shed. Ines repaired the subscription list by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway copied out an index nobody had finished to the lower reading room. I begin to think a catalogue is only a polite way of remembering.

— Ever, A.

## Letter 155

*Monday, from the ferry office*

It was the first clear morning in a week. Ines catalogued the harbourmaster's daybook to the lighthouse landing. Teodor found the subscription list past the ferry office. You would have laughed; I nearly did. Old farrow found the tide tables for the spring from Saltmarsh Lane. Ines found the subscription list past the lower reading room.

Rain came in sideways off the bar. The binder promised me the harbourmaster's daybook by way of the lighthouse landing. Mr calloway carried an index nobody had finished from Gull Stairs. The pilot's daughter repaired a water-stained atlas to the bindery. The pilot's daughter returned an index nobody had finished to Saltmarsh Lane. The binder found the tide tables for the spring by way of the chandler's loft. Mr calloway copied out an index nobody had finished past the lighthouse landing.

A still day, the water like poured lead. The binder mislaid the tide tables for the spring from the ferry office. I have copied the passage twice and still do not believe it. The pilot's daughter carried a ledger of soundings by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Old farrow returned the tide tables for the spring from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Ines repaired a water-stained atlas from the quay. I have copied the passage twice and still do not believe it. Ines repaired the harbourmaster's daybook past the ferry office. Mr calloway returned the second proof by way of the lower reading room.

The tide was late and so was everyone else. Ines copied out a box of unsorted letters by way of the chandler's loft. The pilot's daughter mislaid a ledger of soundings by way of the chandler's loft. Dr okafor mislaid an index nobody had finished to the quay. The pilot's daughter copied out the second proof by way of the chandler's loft. Dr okafor returned the subscription list to the lighthouse landing.

— Ever, A.

## Letter 156

*Monday, from the archive cellar*

The tide was late and so was everyone else. Mr calloway found a parcel of marbled endpapers to the lighthouse landing. You would have laughed; I nearly did. Teodor found a box of unsorted letters past the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired a pamphlet on knots by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Dr okafor promised me an index nobody had finished from the archive cellar. The pilot's daughter mislaid the harbourmaster's daybook by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. Ines found the second proof to the archive cellar. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. Dr okafor returned a water-stained atlas past the archive cellar. Mr calloway mislaid the harbourmaster's daybook from the bindery. Old farrow copied out the subscription list past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Wren carried a parcel of marbled endpapers from the lower reading room. You would have laughed; I nearly did. Teodor repaired the second proof by way of the ferry office.

A still day, the water like poured lead. Old farrow carried a water-stained atlas from the chandler's loft. Teodor wrapped a pamphlet on knots from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Ines repaired the harbourmaster's daybook by way of the chandler's loft. Old farrow copied out a water-stained atlas to Saltmarsh Lane. I have copied the passage twice and still do not believe it. Teodor wrapped a ledger of soundings from the archive cellar. You would have laughed; I nearly did.

The tide was late and so was everyone else. Dr okafor returned the harbourmaster's daybook by way of the customs shed. Dr okafor repaired a pamphlet on knots by way of the customs shed. If the edition is to be trusted it must say what it changed. Mr calloway repaired the subscription list to the lower reading room.

Wind from the east, and the shutters complaining. Wren carried the tide tables for the spring past the customs shed. Old farrow repaired a parcel of marbled endpapers to the lighthouse landing. If the edition is to be trusted it must say what it changed. Wren carried a ledger of soundings to the chandler's loft. I have copied the passage twice and still do not believe it. Ines promised me a ledger of soundings by way of the lower reading room. Dr okafor mislaid a box of unsorted letters to the quay. The binder returned the second proof to the customs shed.

— Yours in haste, A.

## Letter 157

*Monday, from Gull Stairs*

Wind from the east, and the shutters complaining. The pilot's daughter returned a water-stained atlas by way of the lighthouse landing. Old farrow carried the subscription list to the bindery. Wren wrapped a pamphlet on knots by way of the customs shed. I have copied the passage twice and still do not believe it. Old farrow wrapped the harbourmaster's daybook from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Wren mislaid a parcel of marbled endpapers by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Ines found a water-stained atlas by way of the lower reading room. You would have laughed; I nearly did. Teodor copied out a pamphlet on knots past the chandler's loft. The binder carried a water-stained atlas from the customs shed. The pilot's daughter carried the subscription list to the quay. Teodor mislaid the subscription list past the lighthouse landing. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Mr calloway found a parcel of marbled endpapers from the ferry office. I begin to think a catalogue is only a polite way of remembering. Wren found an index nobody had finished past the customs shed. Mr calloway returned a pamphlet on knots past the lighthouse landing. Wren catalogued a pamphlet on knots past Saltmarsh Lane. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Mr calloway returned the subscription list past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The binder repaired a parcel of marbled endpapers from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. The binder repaired the harbourmaster's daybook past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The binder catalogued a pamphlet on knots to the customs shed. You would have laughed; I nearly did. The binder returned an index nobody had finished by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Ines returned a ledger of soundings to the bindery.

The fog stayed until noon. Dr okafor wrapped a box of unsorted letters past Gull Stairs. Ines copied out the tide tables for the spring past the customs shed. If the edition is to be trusted it must say what it changed. Old farrow repaired an index nobody had finished to the lighthouse landing. I have copied the passage twice and still do not believe it. Teodor catalogued the harbourmaster's daybook from Saltmarsh Lane. Dr okafor returned an index nobody had finished by way of the archive cellar.

— Yours, A.

## Letter 158

*Tuesday, from the quay*

Wind from the east, and the shutters complaining. Dr okafor copied out a box of unsorted letters to the bindery. Dr okafor copied out a parcel of marbled endpapers to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway carried a water-stained atlas to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. The binder returned the harbourmaster's daybook by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter catalogued a water-stained atlas from the archive cellar. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Wren returned an index nobody had finished past the ferry office. Wren wrapped the tide tables for the spring past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Wren wrapped an index nobody had finished past the bindery. You would have laughed; I nearly did.

Rain came in sideways off the bar. Mr calloway copied out a ledger of soundings past the lighthouse landing. Dr okafor returned the harbourmaster's daybook from the customs shed. Wren returned the harbourmaster's daybook past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow catalogued the harbourmaster's daybook to the lower reading room. The pilot's daughter copied out the harbourmaster's daybook past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Old farrow mislaid a water-stained atlas from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Wren found a parcel of marbled endpapers past Saltmarsh Lane. Mr calloway copied out a pamphlet on knots to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Ines carried a water-stained atlas by way of the ferry office. Mr calloway copied out the tide tables for the spring by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. Dr okafor copied out a pamphlet on knots past the ferry office. I have copied the passage twice and still do not believe it. Old farrow mislaid a parcel of marbled endpapers to the bindery.

— Yours, A.

## Letter 159

*Tuesday, from Saltmarsh Lane*

The tide was late and so was everyone else. The binder returned a pamphlet on knots from the archive cellar. I have copied the passage twice and still do not believe it. Teodor mislaid a parcel of marbled endpapers past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired a ledger of soundings past Gull Stairs. Wren carried the second proof to the quay. Mr calloway wrapped the second proof from the customs shed. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Wren carried a box of unsorted letters by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Ines returned a ledger of soundings to the archive cellar. Ines found a pamphlet on knots from the customs shed. You would have laughed; I nearly did. Ines repaired a box of unsorted letters to Saltmarsh Lane. You would have laughed; I nearly did. Dr okafor repaired the second proof from the lighthouse landing. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Teodor copied out the harbourmaster's daybook past the lower reading room. Teodor promised me the second proof past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor promised me a parcel of marbled endpapers to the lighthouse landing. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Teodor repaired the tide tables for the spring past the bindery. If the edition is to be trusted it must say what it changed. Wren returned a water-stained atlas past the quay. Wren promised me a parcel of marbled endpapers by way of the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Teodor mislaid a ledger of soundings to Gull Stairs. Wren repaired the harbourmaster's daybook to the ferry office. Mr calloway wrapped the subscription list to the bindery. Dr okafor repaired a box of unsorted letters by way of the chandler's loft.

— Ever, A.

## Letter 160

*Tuesday, from Gull Stairs*

A still day, the water like poured lead. Old farrow catalogued the second proof to Saltmarsh Lane. Dr okafor repaired the second proof past the chandler's loft. Mr calloway wrapped a pamphlet on knots by way of the lighthouse landing. Old farrow promised me the tide tables for the spring past the customs shed. You would have laughed; I nearly did.

A still day, the water like poured lead. The pilot's daughter carried a box of unsorted letters from Gull Stairs. Mr calloway carried the subscription list past the customs shed. You would have laughed; I nearly did. The pilot's daughter carried a ledger of soundings past the lighthouse landing. The binder found a parcel of marbled endpapers to Gull Stairs.

A still day, the water like poured lead. The binder found a pamphlet on knots by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway repaired a ledger of soundings from the ferry office. You would have laughed; I nearly did. Old farrow returned a pamphlet on knots from Gull Stairs. If the edition is to be trusted it must say what it changed. Ines found a box of unsorted letters to the lower reading room. You would have laughed; I nearly did. Ines repaired an index nobody had finished past the bindery.

Rain came in sideways off the bar. Old farrow mislaid a ledger of soundings past Gull Stairs. The pilot's daughter repaired a parcel of marbled endpapers from the customs shed. Mr calloway wrapped the subscription list to Saltmarsh Lane.

— With salt on the page, A.

## Letter 161

*Monday, from the customs shed*

The fog stayed until noon. Dr okafor promised me a parcel of marbled endpapers from the chandler's loft. Old farrow promised me the subscription list to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out a box of unsorted letters past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Dr okafor returned a ledger of soundings past the ferry office. Ines promised me the subscription list by way of the quay. You would have laughed; I nearly did. Old farrow repaired the tide tables for the spring to the chandler's loft. I have copied the passage twice and still do not believe it. Ines catalogued the second proof from the quay. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Ines found a ledger of soundings by way of the chandler's loft. Old farrow catalogued a parcel of marbled endpapers from Gull Stairs. Teodor found a box of unsorted letters past the bindery. The binder carried a box of unsorted letters by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Ines promised me a parcel of marbled endpapers by way of the ferry office. Old farrow returned a pamphlet on knots to the customs shed.

— Ever, A.

## Letter 162

*Friday, from the quay*

It was the first clear morning in a week. Old farrow carried a parcel of marbled endpapers to the bindery. Mr calloway wrapped a ledger of soundings by way of the bindery. Teodor mislaid a pamphlet on knots past the bindery. Ines carried the second proof to Saltmarsh Lane. Mr calloway found the tide tables for the spring past the bindery.

Wind from the east, and the shutters complaining. Wren catalogued a box of unsorted letters by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter returned an index nobody had finished past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor promised me a water-stained atlas to the lighthouse landing.

Rain came in sideways off the bar. Dr okafor copied out an index nobody had finished by way of the customs shed. Dr okafor carried the harbourmaster's daybook past the archive cellar. Old farrow copied out a pamphlet on knots from the chandler's loft.

Wind from the east, and the shutters complaining. Old farrow returned the second proof by way of Saltmarsh Lane. Old farrow carried a parcel of marbled endpapers past Gull Stairs. You would have laughed; I nearly did. Wren found a parcel of marbled endpapers from the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. The binder promised me a ledger of soundings past the archive cellar. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me the subscription list to the archive cellar. Old farrow promised me a parcel of marbled endpapers past the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired a pamphlet on knots past the bindery. Dr okafor repaired a ledger of soundings from the ferry office. Mr calloway wrapped the second proof past the bindery.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 163

*Wednesday, from the lower reading room*

The fog stayed until noon. Ines returned a ledger of soundings past Gull Stairs. Wren found the tide tables for the spring from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway catalogued the subscription list by way of the lower reading room.

Rain came in sideways off the bar. The binder copied out the subscription list by way of Gull Stairs. Wren found the tide tables for the spring from the bindery. Wren mislaid a parcel of marbled endpapers by way of Saltmarsh Lane. Old farrow mislaid the subscription list from the chandler's loft. Teodor mislaid a ledger of soundings by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Ines copied out a pamphlet on knots past Gull Stairs. You would have laughed; I nearly did.

Rain came in sideways off the bar. Teodor wrapped a parcel of marbled endpapers to the ferry office. I begin to think a catalogue is only a polite way of remembering. Dr okafor promised me a box of unsorted letters to the archive cellar. You would have laughed; I nearly did. Ines carried a ledger of soundings by way of the archive cellar. The pilot's daughter mislaid a parcel of marbled endpapers to the chandler's loft. The pilot's daughter found the tide tables for the spring to the lighthouse landing.

— Yours in haste, A.

## Letter 164

*Friday, from the chandler's loft*

A still day, the water like poured lead. Ines repaired a parcel of marbled endpapers from Gull Stairs. If the edition is to be trusted it must say what it changed. Mr calloway promised me a ledger of soundings to Saltmarsh Lane. Teodor found a parcel of marbled endpapers to the lighthouse landing. Ines found the tide tables for the spring by way of Saltmarsh Lane.

The tide was late and so was everyone else. Ines wrapped the tide tables for the spring past the ferry office. Mr calloway wrapped a water-stained atlas from the lighthouse landing. Old farrow wrapped the harbourmaster's daybook from the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Ines carried a water-stained atlas by way of the customs shed. The binder wrapped a pamphlet on knots from the ferry office. You would have laughed; I nearly did.

Rain came in sideways off the bar. Mr calloway copied out a parcel of marbled endpapers by way of the lighthouse landing. Wren promised me a pamphlet on knots to the customs shed. If the edition is to be trusted it must say what it changed. Teodor carried an index nobody had finished to the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Ines returned a box of unsorted letters past the bindery. You would have laughed; I nearly did. Ines carried a pamphlet on knots to the customs shed.

A still day, the water like poured lead. Teodor carried the harbourmaster's daybook by way of Gull Stairs. Teodor wrapped the second proof to the customs shed. Ines carried the second proof past the lighthouse landing. The pilot's daughter catalogued an index nobody had finished by way of the customs shed. If the edition is to be trusted it must say what it changed. Ines promised me a pamphlet on knots past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter found the subscription list from the lighthouse landing.

— Yours, A.

## Letter 165

*Tuesday, from the lower reading room*

The fog stayed until noon. Mr calloway repaired a pamphlet on knots to Gull Stairs. If the edition is to be trusted it must say what it changed. The binder carried the subscription list to the quay. You would have laughed; I nearly did. Teodor promised me a water-stained atlas from the bindery. You would have laughed; I nearly did. Mr calloway mislaid a box of unsorted letters past the quay. Dr okafor copied out a pamphlet on knots to the lighthouse landing. Old farrow repaired a ledger of soundings from the lower reading room.

It was the first clear morning in a week. The binder copied out the second proof by way of Saltmarsh Lane. Dr okafor promised me a ledger of soundings from Gull Stairs. The binder found the second proof from the customs shed. Wren found the tide tables for the spring past the chandler's loft.

Wind from the east, and the shutters complaining. Old farrow mislaid a ledger of soundings from the ferry office. The pilot's daughter promised me a pamphlet on knots to the chandler's loft. If the edition is to be trusted it must say what it changed. Wren found the tide tables for the spring past the chandler's loft. Dr okafor copied out a pamphlet on knots to Gull Stairs. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. The binder repaired a ledger of soundings to the bindery. The binder found the second proof past Saltmarsh Lane. I have copied the passage twice and still do not believe it. The binder found a ledger of soundings by way of the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Ines returned a parcel of marbled endpapers past Saltmarsh Lane. I have copied the passage twice and still do not believe it. The binder returned a water-stained atlas from Saltmarsh Lane.

It was the first clear morning in a week. The pilot's daughter promised me the tide tables for the spring from the chandler's loft. Dr okafor found the harbourmaster's daybook by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow catalogued a parcel of marbled endpapers from the archive cellar. I have copied the passage twice and still do not believe it. The pilot's daughter returned a box of unsorted letters from the bindery.

— With salt on the page, A.

## Letter 166

*Tuesday, from the bindery*

The fog stayed until noon. The pilot's daughter repaired a parcel of marbled endpapers to the ferry office. Wren mislaid an index nobody had finished from Saltmarsh Lane. Dr okafor promised me the tide tables for the spring from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. Old farrow wrapped a water-stained atlas from the ferry office. The pilot's daughter copied out the second proof from the archive cellar. Wren wrapped a ledger of soundings to Gull Stairs. Wren copied out a ledger of soundings past the lower reading room.

It was the first clear morning in a week. Teodor catalogued a ledger of soundings to the customs shed. Mr calloway mislaid the harbourmaster's daybook to the lighthouse landing. Ines catalogued a water-stained atlas past the bindery. Wren wrapped the subscription list by way of the customs shed.

Rain came in sideways off the bar. The binder wrapped a ledger of soundings by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor catalogued the harbourmaster's daybook past Gull Stairs. I have copied the passage twice and still do not believe it. Teodor returned an index nobody had finished past the lower reading room.

— Ever, A.

## Letter 167

*Wednesday, from the quay*

Wind from the east, and the shutters complaining. Wren repaired the subscription list to the ferry office. The binder promised me a ledger of soundings past the ferry office. The pilot's daughter catalogued the subscription list past the archive cellar. The binder found a ledger of soundings past the lighthouse landing.

The tide was late and so was everyone else. The binder copied out a water-stained atlas past the chandler's loft. Mr calloway found a ledger of soundings to the quay. Ines promised me the second proof by way of the bindery. You would have laughed; I nearly did.

It was the first clear morning in a week. Wren catalogued the tide tables for the spring past Gull Stairs. If the edition is to be trusted it must say what it changed. Ines catalogued a parcel of marbled endpapers past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor promised me the second proof to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Ines promised me an index nobody had finished past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow promised me an index nobody had finished by way of the bindery. I begin to think a catalogue is only a polite way of remembering.

— Yours, A.

## Letter 168

*Tuesday, from the quay*

The tide was late and so was everyone else. Wren wrapped a ledger of soundings from the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow returned a water-stained atlas to the archive cellar. Mr calloway carried the tide tables for the spring past the chandler's loft. Wren wrapped the tide tables for the spring to the ferry office. Old farrow copied out the subscription list by way of the archive cellar. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. The pilot's daughter found a parcel of marbled endpapers from Gull Stairs. Ines found the tide tables for the spring by way of the lower reading room. You would have laughed; I nearly did. Mr calloway repaired the second proof by way of the ferry office. The binder repaired the subscription list to the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Wren found a pamphlet on knots to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow catalogued a water-stained atlas by way of the quay. If the edition is to be trusted it must say what it changed. The binder repaired a ledger of soundings by way of Saltmarsh Lane.

It was the first clear morning in a week. Mr calloway copied out the harbourmaster's daybook from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor copied out an index nobody had finished by way of the ferry office. Mr calloway promised me the subscription list to Gull Stairs.

Rain came in sideways off the bar. The pilot's daughter found an index nobody had finished by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired a parcel of marbled endpapers from the ferry office. I begin to think a catalogue is only a polite way of remembering. Wren repaired a ledger of soundings from Saltmarsh Lane.

— Ever, A.

## Letter 169

*Monday, from the chandler's loft*

Wind from the east, and the shutters complaining. Old farrow found the second proof past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired the subscription list from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Ines wrapped the subscription list past the quay.

The tide was late and so was everyone else. Teodor returned a box of unsorted letters past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired an index nobody had finished past the lower reading room. Ines returned the harbourmaster's daybook to the lower reading room. Mr calloway carried the subscription list past the quay. Mr calloway returned the harbourmaster's daybook from the ferry office.

It was the first clear morning in a week. Wren mislaid the second proof from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren carried the second proof from the lower reading room. Dr okafor found a ledger of soundings past Saltmarsh Lane. You would have laughed; I nearly did. The binder catalogued the second proof past the archive cellar. Dr okafor wrapped a pamphlet on knots by way of the quay. If the edition is to be trusted it must say what it changed. The pilot's daughter returned an index nobody had finished to the quay.

It was the first clear morning in a week. Dr okafor promised me the harbourmaster's daybook to the customs shed. Teodor promised me a parcel of marbled endpapers past the ferry office. The binder catalogued the harbourmaster's daybook past the chandler's loft. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Dr okafor found a box of unsorted letters past the chandler's loft. Teodor returned a ledger of soundings from the archive cellar. Mr calloway copied out an index nobody had finished by way of the lighthouse landing. Old farrow promised me the second proof from the bindery. Old farrow carried the second proof past the bindery. You would have laughed; I nearly did. Dr okafor returned the tide tables for the spring to the lighthouse landing.

— Yours in haste, A.

## Letter 170

*Monday, from the lighthouse landing*

The fog stayed until noon. Ines promised me a box of unsorted letters past the lighthouse landing. If the edition is to be trusted it must say what it changed. Wren returned a ledger of soundings from the customs shed. Ines copied out the second proof past the lighthouse landing. You would have laughed; I nearly did. Teodor catalogued the harbourmaster's daybook by way of the lighthouse landing. Dr okafor mislaid a box of unsorted letters from the bindery.

Wind from the east, and the shutters complaining. The binder carried a box of unsorted letters by way of the quay. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired an index nobody had finished from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow catalogued the second proof to the chandler's loft. Old farrow catalogued the tide tables for the spring to the quay. Mr calloway mislaid the second proof by way of the ferry office.

The tide was late and so was everyone else. The binder returned a parcel of marbled endpapers from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor copied out the subscription list by way of the lighthouse landing. Teodor wrapped the tide tables for the spring from the bindery. If the edition is to be trusted it must say what it changed. The binder repaired the second proof to the quay. Teodor mislaid the second proof to the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway copied out a parcel of marbled endpapers from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Dr okafor returned a water-stained atlas from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Ines copied out a pamphlet on knots from the lighthouse landing. I have copied the passage twice and still do not believe it. Mr calloway wrapped the subscription list from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Ines promised me a ledger of soundings to Saltmarsh Lane. Teodor catalogued the second proof to the ferry office.

— Yours, A.

## Letter 171

*Thursday, from the quay*

Rain came in sideways off the bar. Dr okafor repaired the second proof from the ferry office. Teodor carried a water-stained atlas from the ferry office. You would have laughed; I nearly did. Old farrow mislaid a ledger of soundings by way of the ferry office. The pilot's daughter returned a ledger of soundings by way of the ferry office. Teodor wrapped a box of unsorted letters to the bindery.

The tide was late and so was everyone else. The binder catalogued a pamphlet on knots from Gull Stairs. The pilot's daughter carried a box of unsorted letters to Gull Stairs. Dr okafor repaired the second proof past the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter returned the tide tables for the spring past the lighthouse landing.

It was the first clear morning in a week. Ines repaired the harbourmaster's daybook from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow promised me a parcel of marbled endpapers past the customs shed. You would have laughed; I nearly did. Ines catalogued a parcel of marbled endpapers past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Ines promised me a box of unsorted letters to the lower reading room. Wren found a pamphlet on knots to the ferry office.

The tide was late and so was everyone else. The pilot's daughter mislaid the tide tables for the spring to the ferry office. The pilot's daughter catalogued a pamphlet on knots from the quay. Old farrow found a pamphlet on knots past Saltmarsh Lane. The pilot's daughter returned a box of unsorted letters to the quay. The binder returned the harbourmaster's daybook by way of the chandler's loft.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 172

*Friday, from Saltmarsh Lane*

The fog stayed until noon. Wren returned a ledger of soundings from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway repaired the harbourmaster's daybook to the lighthouse landing. Old farrow carried the second proof from Gull Stairs. The binder found the tide tables for the spring by way of the ferry office. Old farrow catalogued a water-stained atlas from the ferry office.

Rain came in sideways off the bar. The binder wrapped the harbourmaster's daybook past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Dr okafor wrapped the second proof from Saltmarsh Lane. Mr calloway found the harbourmaster's daybook to the customs shed. Wren catalogued the harbourmaster's daybook by way of the lighthouse landing. Mr calloway returned a parcel of marbled endpapers to the bindery. Ines mislaid the second proof to Saltmarsh Lane.

The fog stayed until noon. Ines catalogued an index nobody had finished to the quay. I begin to think a catalogue is only a polite way of remembering. Teodor promised me the subscription list to the bindery. I have copied the passage twice and still do not believe it. Dr okafor wrapped a pamphlet on knots by way of Gull Stairs.

Wind from the east, and the shutters complaining. Wren copied out the second proof past Gull Stairs. Dr okafor promised me a pamphlet on knots past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow promised me a pamphlet on knots to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Wren wrapped the second proof by way of the customs shed. Ines copied out a ledger of soundings from the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Mr calloway carried a ledger of soundings from the customs shed.

— Ever, A.

## Letter 173

*Monday, from the quay*

The tide was late and so was everyone else. Mr calloway found a parcel of marbled endpapers by way of the customs shed. Old farrow copied out a water-stained atlas by way of the ferry office. Dr okafor promised me a ledger of soundings from the ferry office. Dr okafor returned a pamphlet on knots past the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor copied out the tide tables for the spring from Gull Stairs. I have copied the passage twice and still do not believe it. The binder copied out the subscription list from the ferry office.

It was the first clear morning in a week. The binder catalogued the harbourmaster's daybook from the chandler's loft. If the edition is to be trusted it must say what it changed. The pilot's daughter returned a pamphlet on knots by way of the lower reading room. Teodor carried a ledger of soundings by way of the lower reading room. Old farrow wrapped a parcel of marbled endpapers to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Teodor mislaid the subscription list from the lower reading room.

A still day, the water like poured lead. The pilot's daughter catalogued the tide tables for the spring past the quay. The pilot's daughter found a water-stained atlas by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Wren mislaid the second proof from the ferry office. Teodor found a pamphlet on knots to Gull Stairs. If the edition is to be trusted it must say what it changed. The pilot's daughter copied out the tide tables for the spring past Gull Stairs.

A still day, the water like poured lead. Dr okafor carried the harbourmaster's daybook past the customs shed. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter wrapped a ledger of soundings from the lower reading room. The pilot's daughter promised me the tide tables for the spring by way of Saltmarsh Lane. Ines copied out the subscription list by way of Gull Stairs. I have copied the passage twice and still do not believe it. Dr okafor wrapped a box of unsorted letters from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Old farrow catalogued a water-stained atlas past Saltmarsh Lane. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Wren copied out a water-stained atlas past the chandler's loft. The pilot's daughter wrapped a box of unsorted letters from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Wren promised me a box of unsorted letters past the lighthouse landing. Ines repaired the subscription list past the customs shed. I begin to think a catalogue is only a polite way of remembering. Dr okafor returned the harbourmaster's daybook from the lighthouse landing.

— Yours, A.

## Letter 174

*Wednesday, from Gull Stairs*

The tide was late and so was everyone else. Mr calloway carried an index nobody had finished from the chandler's loft. Mr calloway catalogued a pamphlet on knots past Gull Stairs. Old farrow catalogued a pamphlet on knots by way of the quay.

A still day, the water like poured lead. Old farrow returned an index nobody had finished to the quay. Dr okafor promised me the second proof by way of the quay. I have copied the passage twice and still do not believe it. Wren found the tide tables for the spring past the lower reading room. Dr okafor returned a water-stained atlas from the customs shed.

The fog stayed until noon. The pilot's daughter carried the subscription list from the chandler's loft. I have copied the passage twice and still do not believe it. Ines copied out a parcel of marbled endpapers to the customs shed. The binder returned the subscription list past the ferry office. I begin to think a catalogue is only a polite way of remembering. The binder mislaid a water-stained atlas from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Ines copied out the harbourmaster's daybook by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Teodor mislaid a box of unsorted letters to the lighthouse landing.

The fog stayed until noon. The pilot's daughter catalogued the harbourmaster's daybook from Saltmarsh Lane. Teodor wrapped a pamphlet on knots by way of the quay. If the edition is to be trusted it must say what it changed. The pilot's daughter promised me a ledger of soundings by way of the quay.

— With salt on the page, A.

## Letter 175

*Monday, from the customs shed*

The fog stayed until noon. Wren carried a parcel of marbled endpapers by way of the customs shed. Wren catalogued a parcel of marbled endpapers past the quay. I have copied the passage twice and still do not believe it. Old farrow promised me a box of unsorted letters from Saltmarsh Lane. Dr okafor carried a parcel of marbled endpapers by way of the ferry office. I have copied the passage twice and still do not believe it. Teodor catalogued a ledger of soundings by way of the lighthouse landing.

Rain came in sideways off the bar. Wren catalogued a parcel of marbled endpapers to Gull Stairs. I have copied the passage twice and still do not believe it. Ines found a ledger of soundings to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The binder returned the subscription list past the customs shed. Dr okafor copied out the harbourmaster's daybook from the quay. Old farrow catalogued the harbourmaster's daybook past the lighthouse landing.

A still day, the water like poured lead. Mr calloway carried the second proof past the quay. I begin to think a catalogue is only a polite way of remembering. Mr calloway returned the harbourmaster's daybook to the archive cellar. I have copied the passage twice and still do not believe it. Dr okafor returned the subscription list to Saltmarsh Lane. Mr calloway found the second proof to the quay. Wren catalogued a parcel of marbled endpapers by way of the ferry office. The binder catalogued a ledger of soundings by way of the chandler's loft. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. Wren returned a box of unsorted letters from the bindery. The pilot's daughter copied out a water-stained atlas by way of Saltmarsh Lane. Old farrow returned a water-stained atlas to the lighthouse landing. Ines promised me the harbourmaster's daybook by way of the lower reading room. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Teodor catalogued a ledger of soundings to Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter found a pamphlet on knots from the chandler's loft. Mr calloway wrapped a parcel of marbled endpapers past the lighthouse landing. If the edition is to be trusted it must say what it changed.

— Ever, A.

## Letter 176

*Thursday, from the archive cellar*

It was the first clear morning in a week. Mr calloway promised me the subscription list to Saltmarsh Lane. Dr okafor wrapped a water-stained atlas past the quay. Ines repaired a ledger of soundings to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow carried the harbourmaster's daybook from the quay. Mr calloway carried a water-stained atlas by way of the quay. Wren wrapped the subscription list past the archive cellar. You would have laughed; I nearly did.

The fog stayed until noon. Ines mislaid a ledger of soundings past Saltmarsh Lane. Teodor mislaid a water-stained atlas from the lighthouse landing. Teodor copied out a water-stained atlas by way of Saltmarsh Lane. Ines found a water-stained atlas past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway promised me the subscription list by way of the customs shed. Mr calloway repaired the second proof from Saltmarsh Lane. You would have laughed; I nearly did.

It was the first clear morning in a week. Teodor mislaid a water-stained atlas by way of the customs shed. I have copied the passage twice and still do not believe it. Old farrow carried the tide tables for the spring by way of the chandler's loft. Mr calloway returned the tide tables for the spring by way of the chandler's loft. The binder catalogued a box of unsorted letters by way of the bindery. Ines mislaid the second proof by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering. Teodor found a pamphlet on knots to the customs shed.

— Yours in haste, A.

## Letter 177

*Thursday, from the chandler's loft*

It was the first clear morning in a week. The pilot's daughter catalogued a box of unsorted letters past the lighthouse landing. The pilot's daughter returned the tide tables for the spring past the chandler's loft. Dr okafor repaired the harbourmaster's daybook to the quay. The binder wrapped the harbourmaster's daybook past the archive cellar. The pilot's daughter carried the subscription list from the customs shed. If the edition is to be trusted it must say what it changed. The pilot's daughter found a box of unsorted letters from the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. The binder returned a parcel of marbled endpapers past Gull Stairs. You would have laughed; I nearly did. Teodor catalogued the harbourmaster's daybook to the customs shed. I begin to think a catalogue is only a polite way of remembering. Mr calloway mislaid the subscription list past Gull Stairs.

It was the first clear morning in a week. The binder carried a parcel of marbled endpapers to the bindery. Teodor mislaid a parcel of marbled endpapers to the quay. The pilot's daughter wrapped a parcel of marbled endpapers to the chandler's loft. Ines repaired an index nobody had finished from the bindery. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. Mr calloway promised me a ledger of soundings to the bindery. The binder copied out the harbourmaster's daybook past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow mislaid the second proof past the quay.

The fog stayed until noon. Old farrow returned the harbourmaster's daybook from Gull Stairs. Ines found the second proof to the chandler's loft. I have copied the passage twice and still do not believe it. The pilot's daughter copied out the second proof by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Old farrow copied out the harbourmaster's daybook to the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

— With salt on the page, A.

## Letter 178

*Thursday, from the lower reading room*

A still day, the water like poured lead. The binder returned the subscription list by way of the quay. Mr calloway mislaid an index nobody had finished from the lower reading room. The pilot's daughter found the harbourmaster's daybook from the archive cellar. The binder repaired a parcel of marbled endpapers from the lighthouse landing. The pilot's daughter mislaid a parcel of marbled endpapers past the archive cellar. You would have laughed; I nearly did. Dr okafor found a pamphlet on knots to the bindery.

The fog stayed until noon. Wren catalogued the second proof from the quay. Old farrow copied out an index nobody had finished from the archive cellar. The binder carried the tide tables for the spring past the archive cellar. You would have laughed; I nearly did. Wren wrapped a box of unsorted letters from the quay. The binder promised me a box of unsorted letters past the bindery. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Dr okafor returned a box of unsorted letters from the lower reading room. Ines promised me a box of unsorted letters past the quay. If the edition is to be trusted it must say what it changed. The binder catalogued a ledger of soundings past the bindery. Mr calloway catalogued the subscription list from the lower reading room. Wren wrapped the second proof from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Wren carried an index nobody had finished to the lighthouse landing. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Ines wrapped a water-stained atlas from the ferry office. The pilot's daughter mislaid a water-stained atlas to the lighthouse landing. The binder found a ledger of soundings by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait.

— Ever, A.

## Letter 179

*Wednesday, from the lighthouse landing*

A still day, the water like poured lead. The binder copied out a water-stained atlas from Saltmarsh Lane. Teodor catalogued a ledger of soundings from the lower reading room. I begin to think a catalogue is only a polite way of remembering. Old farrow returned a parcel of marbled endpapers from the customs shed.

The tide was late and so was everyone else. Dr okafor catalogued the tide tables for the spring from the bindery. The pilot's daughter wrapped the harbourmaster's daybook past the bindery. Teodor promised me the harbourmaster's daybook by way of the lighthouse landing. Dr okafor carried a ledger of soundings from Saltmarsh Lane. The pilot's daughter wrapped the second proof past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. The pilot's daughter wrapped a ledger of soundings past Saltmarsh Lane. You would have laughed; I nearly did. Wren repaired a ledger of soundings by way of the chandler's loft. I have copied the passage twice and still do not believe it. The pilot's daughter returned the subscription list past the quay. You would have laughed; I nearly did.

It was the first clear morning in a week. Teodor repaired the second proof to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter promised me a ledger of soundings to the chandler's loft. Dr okafor carried the second proof to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Wren catalogued the tide tables for the spring from the bindery. I begin to think a catalogue is only a polite way of remembering. Ines wrapped a parcel of marbled endpapers from the quay.

— Ever, A.

## Letter 180

*Wednesday, from the chandler's loft*

The fog stayed until noon. The pilot's daughter carried a box of unsorted letters from the quay. The binder repaired a box of unsorted letters past the bindery. I have copied the passage twice and still do not believe it. Ines returned a pamphlet on knots past Gull Stairs.

Rain came in sideways off the bar. The pilot's daughter promised me the harbourmaster's daybook past the chandler's loft. Old farrow copied out a box of unsorted letters past the customs shed. Dr okafor returned the tide tables for the spring to the lower reading room. Teodor found the harbourmaster's daybook past the ferry office.

A still day, the water like poured lead. The pilot's daughter repaired the subscription list to the quay. Dr okafor returned a water-stained atlas from the bindery. I begin to think a catalogue is only a polite way of remembering. Old farrow mislaid an index nobody had finished to the quay. The binder returned the tide tables for the spring past the lower reading room. Old farrow found the second proof past the lower reading room. You would have laughed; I nearly did. Ines mislaid the subscription list from the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Wren promised me a pamphlet on knots by way of Gull Stairs. You would have laughed; I nearly did. Dr okafor carried the harbourmaster's daybook past the quay. You would have laughed; I nearly did. Mr calloway promised me the second proof to Saltmarsh Lane. Old farrow carried the second proof from the lower reading room. I have copied the passage twice and still do not believe it.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 181

*Friday, from Saltmarsh Lane*

The tide was late and so was everyone else. Teodor returned a pamphlet on knots past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Dr okafor repaired the second proof past the quay. You would have laughed; I nearly did. The pilot's daughter mislaid a parcel of marbled endpapers from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Ines promised me a ledger of soundings from the bindery. Teodor wrapped a ledger of soundings past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me the second proof to Saltmarsh Lane. You would have laughed; I nearly did.

The tide was late and so was everyone else. Old farrow promised me the second proof from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Dr okafor found a parcel of marbled endpapers by way of Gull Stairs. Ines repaired a ledger of soundings past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway found an index nobody had finished by way of the ferry office. You would have laughed; I nearly did. Teodor returned the second proof from Gull Stairs. I have copied the passage twice and still do not believe it. The binder returned an index nobody had finished from Gull Stairs.

Rain came in sideways off the bar. The binder repaired a pamphlet on knots from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow found a parcel of marbled endpapers from the lower reading room. The pilot's daughter mislaid the second proof by way of the ferry office. Wren returned a ledger of soundings by way of the archive cellar. You would have laughed; I nearly did. Mr calloway copied out the second proof past the archive cellar. You would have laughed; I nearly did.

It was the first clear morning in a week. Dr okafor mislaid a pamphlet on knots to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow catalogued an index nobody had finished past the archive cellar. I have copied the passage twice and still do not believe it. Teodor catalogued the tide tables for the spring to Gull Stairs. Ines copied out a box of unsorted letters from the ferry office. The pilot's daughter returned a box of unsorted letters to the chandler's loft.

Wind from the east, and the shutters complaining. Wren carried a parcel of marbled endpapers past the bindery. Teodor promised me the subscription list by way of the customs shed. I have copied the passage twice and still do not believe it. Mr calloway repaired a water-stained atlas by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Wren carried the subscription list to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid an index nobody had finished to the ferry office. Mr calloway wrapped an index nobody had finished to Saltmarsh Lane.

— Ever, A.

## Letter 182

*Wednesday, from the customs shed*

The fog stayed until noon. Ines wrapped the subscription list past the chandler's loft. Teodor returned a pamphlet on knots to the ferry office. I have copied the passage twice and still do not believe it. Ines found the harbourmaster's daybook by way of Gull Stairs. Teodor catalogued a box of unsorted letters to the archive cellar. I have copied the passage twice and still do not believe it. Ines repaired the tide tables for the spring past the chandler's loft.

A still day, the water like poured lead. The pilot's daughter carried the subscription list by way of the customs shed. Wren promised me a ledger of soundings by way of the quay. Dr okafor carried a parcel of marbled endpapers by way of the ferry office. You would have laughed; I nearly did.

It was the first clear morning in a week. Wren returned the harbourmaster's daybook past the chandler's loft. I have copied the passage twice and still do not believe it. Ines catalogued the tide tables for the spring to the archive cellar. Dr okafor promised me a box of unsorted letters from the customs shed. Dr okafor mislaid the tide tables for the spring by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. The binder catalogued the harbourmaster's daybook past the lower reading room.

It was the first clear morning in a week. Dr okafor found an index nobody had finished by way of the archive cellar. Wren carried a box of unsorted letters by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter wrapped a ledger of soundings past the bindery.

— With salt on the page, A.

## Letter 183

*Friday, from the archive cellar*

A still day, the water like poured lead. Ines carried a parcel of marbled endpapers from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor wrapped the subscription list past Gull Stairs. You would have laughed; I nearly did. Wren wrapped the tide tables for the spring by way of the lower reading room. The pilot's daughter promised me the subscription list by way of the lower reading room.

Wind from the east, and the shutters complaining. Mr calloway mislaid the subscription list from Gull Stairs. Mr calloway carried the tide tables for the spring by way of the quay. If the edition is to be trusted it must say what it changed. Wren returned the subscription list from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor repaired a water-stained atlas by way of the bindery. Dr okafor catalogued a parcel of marbled endpapers past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter wrapped a parcel of marbled endpapers from the chandler's loft.

It was the first clear morning in a week. Ines catalogued a box of unsorted letters from the quay. Mr calloway repaired a water-stained atlas from the lower reading room. If the edition is to be trusted it must say what it changed. The binder mislaid a parcel of marbled endpapers past Gull Stairs. If the edition is to be trusted it must say what it changed. Dr okafor found the tide tables for the spring from Saltmarsh Lane. Old farrow carried a water-stained atlas from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned a ledger of soundings by way of the quay.

— Yours, A.

## Letter 184

*Friday, from Gull Stairs*

Wind from the east, and the shutters complaining. Ines found a ledger of soundings past the chandler's loft. If the edition is to be trusted it must say what it changed. Mr calloway returned a water-stained atlas by way of the quay. Old farrow promised me a pamphlet on knots to the chandler's loft.

Rain came in sideways off the bar. Old farrow found a water-stained atlas past the bindery. I have copied the passage twice and still do not believe it. Dr okafor carried the harbourmaster's daybook by way of the ferry office. Ines copied out a pamphlet on knots from Gull Stairs. Old farrow promised me a water-stained atlas from Saltmarsh Lane. You would have laughed; I nearly did. Wren copied out the subscription list from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. The binder carried a box of unsorted letters from the quay.

The fog stayed until noon. The binder carried a ledger of soundings by way of Gull Stairs. Dr okafor carried a water-stained atlas to the bindery. You would have laughed; I nearly did. Dr okafor returned a water-stained atlas by way of the chandler's loft. Dr okafor returned a pamphlet on knots to the bindery. The binder wrapped the harbourmaster's daybook past the lighthouse landing. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. The pilot's daughter repaired an index nobody had finished by way of the customs shed. Wren catalogued a water-stained atlas from Saltmarsh Lane. Mr calloway found a water-stained atlas to the lighthouse landing.

— Yours in haste, A.

## Letter 185

*Monday, from the chandler's loft*

Wind from the east, and the shutters complaining. Ines catalogued a box of unsorted letters to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me a parcel of marbled endpapers from the bindery. Dr okafor wrapped the harbourmaster's daybook to the lighthouse landing. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Old farrow promised me the subscription list to Gull Stairs. Ines promised me a box of unsorted letters past the lighthouse landing. If the edition is to be trusted it must say what it changed. Dr okafor carried the tide tables for the spring to the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway found the subscription list from Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

A still day, the water like poured lead. Ines promised me the harbourmaster's daybook by way of Saltmarsh Lane. The binder repaired a pamphlet on knots to the ferry office. I begin to think a catalogue is only a polite way of remembering. The binder repaired the harbourmaster's daybook from the bindery. You would have laughed; I nearly did. Dr okafor mislaid a pamphlet on knots past the lighthouse landing. You would have laughed; I nearly did. Mr calloway copied out the tide tables for the spring by way of the ferry office. Wren found a pamphlet on knots from the bindery.

— With salt on the page, A.

## Letter 186

*Thursday, from the bindery*

Rain came in sideways off the bar. Dr okafor returned a pamphlet on knots by way of the customs shed. Wren wrapped the harbourmaster's daybook past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found the second proof from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. The binder copied out a pamphlet on knots from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Teodor repaired a water-stained atlas past the customs shed. The pilot's daughter mislaid a parcel of marbled endpapers to the lower reading room. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. Dr okafor returned a ledger of soundings by way of the archive cellar. The pilot's daughter carried a water-stained atlas from Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor returned the harbourmaster's daybook to the customs shed. Wren wrapped the subscription list to the lighthouse landing. The pilot's daughter wrapped a pamphlet on knots from the customs shed.

— Yours, A.

## Letter 187

*Wednesday, from the bindery*

Rain came in sideways off the bar. Old farrow wrapped a water-stained atlas by way of the bindery. If the edition is to be trusted it must say what it changed. Wren promised me the second proof past the lighthouse landing. Mr calloway promised me the tide tables for the spring past the lower reading room. I have copied the passage twice and still do not believe it. The binder repaired a ledger of soundings to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The binder repaired a water-stained atlas to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow found the subscription list by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. The binder promised me a box of unsorted letters from the bindery. Ines wrapped a water-stained atlas from the lighthouse landing. The binder found an index nobody had finished past the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired a ledger of soundings from the chandler's loft.

It was the first clear morning in a week. Old farrow catalogued an index nobody had finished from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. The binder wrapped a water-stained atlas past the archive cellar. You would have laughed; I nearly did. Ines copied out a pamphlet on knots from Saltmarsh Lane. Wren catalogued a pamphlet on knots past the customs shed. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. Wren found the second proof past Gull Stairs. Mr calloway catalogued the harbourmaster's daybook from Gull Stairs. Teodor mislaid a water-stained atlas past Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Teodor repaired a ledger of soundings past the customs shed. Mr calloway carried a water-stained atlas by way of the ferry office.

Wind from the east, and the shutters complaining. Wren returned a water-stained atlas to the chandler's loft. Mr calloway copied out the tide tables for the spring to the bindery. Dr okafor carried a box of unsorted letters by way of the lower reading room.

— Yours in haste, A.

## Letter 188

*Monday, from the customs shed*

It was the first clear morning in a week. Dr okafor found the second proof by way of Saltmarsh Lane. Old farrow promised me the tide tables for the spring past the customs shed. Wren carried a box of unsorted letters from the lighthouse landing. I have copied the passage twice and still do not believe it. Wren wrapped the subscription list to the chandler's loft. I have copied the passage twice and still do not believe it. The pilot's daughter mislaid a parcel of marbled endpapers to the quay. Teodor found the tide tables for the spring by way of the ferry office. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. Teodor copied out a parcel of marbled endpapers from the lighthouse landing. Wren catalogued a water-stained atlas from the quay. Mr calloway wrapped the second proof by way of Saltmarsh Lane. You would have laughed; I nearly did. Mr calloway promised me a water-stained atlas from the chandler's loft. Teodor wrapped a box of unsorted letters past the quay.

Wind from the east, and the shutters complaining. Dr okafor returned a parcel of marbled endpapers by way of the lower reading room. The pilot's daughter carried a pamphlet on knots from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter mislaid the harbourmaster's daybook by way of the chandler's loft. The pilot's daughter repaired a pamphlet on knots to the customs shed. You would have laughed; I nearly did. Ines mislaid the second proof past the archive cellar. Teodor copied out a ledger of soundings by way of the customs shed.

Wind from the east, and the shutters complaining. Ines found a water-stained atlas past the chandler's loft. If the edition is to be trusted it must say what it changed. The binder repaired an index nobody had finished past the customs shed. Teodor carried the harbourmaster's daybook past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. Teodor carried the tide tables for the spring to the lower reading room. Wren copied out a box of unsorted letters to the lower reading room. I have copied the passage twice and still do not believe it. Old farrow mislaid the harbourmaster's daybook from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway repaired a box of unsorted letters by way of Gull Stairs. If the edition is to be trusted it must say what it changed. Teodor promised me an index nobody had finished by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours in haste, A.

## Letter 189

*Tuesday, from Gull Stairs*

A still day, the water like poured lead. Old farrow returned a box of unsorted letters to Gull Stairs. Wren repaired an index nobody had finished past Gull Stairs. Wren promised me the tide tables for the spring from the customs shed. Old farrow wrapped a parcel of marbled endpapers to the ferry office. Wren mislaid the tide tables for the spring to the chandler's loft.

Wind from the east, and the shutters complaining. Mr calloway repaired the second proof past the archive cellar. You would have laughed; I nearly did. Mr calloway carried a box of unsorted letters past the chandler's loft. You would have laughed; I nearly did. Old farrow repaired a water-stained atlas from the bindery. Ines found a ledger of soundings from the chandler's loft.

Rain came in sideways off the bar. Wren wrapped a ledger of soundings to the ferry office. Mr calloway promised me a parcel of marbled endpapers to the ferry office. Teodor carried a ledger of soundings past the customs shed. Dr okafor promised me a water-stained atlas to the archive cellar. The pilot's daughter carried the second proof from Saltmarsh Lane. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Old farrow returned the second proof to the customs shed. Old farrow promised me the tide tables for the spring by way of the ferry office. Old farrow promised me a pamphlet on knots to Gull Stairs. The binder promised me the harbourmaster's daybook to Gull Stairs.

— Yours, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 190

*Friday, from the bindery*

Rain came in sideways off the bar. Mr calloway promised me a parcel of marbled endpapers past the bindery. Mr calloway promised me a box of unsorted letters by way of the archive cellar. Mr calloway repaired a box of unsorted letters from the ferry office. I begin to think a catalogue is only a polite way of remembering. Wren mislaid the subscription list past the lighthouse landing. Mr calloway promised me the tide tables for the spring to the archive cellar. I have copied the passage twice and still do not believe it. Dr okafor wrapped a box of unsorted letters to the lower reading room. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Dr okafor repaired the subscription list by way of the customs shed. Old farrow wrapped a water-stained atlas by way of Saltmarsh Lane. You would have laughed; I nearly did. Dr okafor returned a pamphlet on knots past Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Ines promised me a box of unsorted letters past the lighthouse landing. The binder returned the tide tables for the spring from the archive cellar.

The fog stayed until noon. Ines carried a box of unsorted letters to the ferry office. Mr calloway wrapped the subscription list to the quay. I have copied the passage twice and still do not believe it. Ines copied out a water-stained atlas by way of the archive cellar. If the edition is to be trusted it must say what it changed. Mr calloway carried the second proof to the bindery. Dr okafor catalogued the second proof by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. The binder wrapped a pamphlet on knots to Gull Stairs. The binder promised me the harbourmaster's daybook past Gull Stairs. The binder catalogued a parcel of marbled endpapers past Gull Stairs. You would have laughed; I nearly did.

The fog stayed until noon. Ines catalogued a ledger of soundings from the lower reading room. You would have laughed; I nearly did. Old farrow promised me an index nobody had finished to the archive cellar. If the edition is to be trusted it must say what it changed. The binder mislaid a ledger of soundings to the ferry office. If the edition is to be trusted it must say what it changed. The binder wrapped a parcel of marbled endpapers by way of the lower reading room.

— With salt on the page, A.

## Letter 191

*Thursday, from the bindery*

Wind from the east, and the shutters complaining. The pilot's daughter promised me a box of unsorted letters from the quay. Mr calloway copied out the harbourmaster's daybook by way of the lower reading room. Mr calloway copied out the subscription list from the lighthouse landing. The pilot's daughter repaired the subscription list from the lighthouse landing.

A still day, the water like poured lead. Teodor promised me an index nobody had finished by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me a ledger of soundings past the quay. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter returned the tide tables for the spring past the bindery. You would have laughed; I nearly did. Wren promised me a pamphlet on knots past the lower reading room. Ines copied out an index nobody had finished past the bindery. You would have laughed; I nearly did.

A still day, the water like poured lead. The pilot's daughter catalogued a box of unsorted letters to the quay. The pilot's daughter copied out an index nobody had finished by way of the customs shed. Dr okafor repaired the second proof by way of the bindery. You would have laughed; I nearly did. Dr okafor carried the harbourmaster's daybook from Gull Stairs. The binder promised me a box of unsorted letters from Gull Stairs. Old farrow returned a parcel of marbled endpapers by way of Gull Stairs. You would have laughed; I nearly did.

Rain came in sideways off the bar. The pilot's daughter catalogued a pamphlet on knots to the quay. Wren catalogued a parcel of marbled endpapers by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor wrapped the harbourmaster's daybook from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Dr okafor wrapped a pamphlet on knots past the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Wren carried the subscription list past Gull Stairs.

— Ever, A.

## Letter 192

*Friday, from the ferry office*

The fog stayed until noon. Ines wrapped a parcel of marbled endpapers by way of the customs shed. You would have laughed; I nearly did. Old farrow promised me the tide tables for the spring from the bindery. If the edition is to be trusted it must say what it changed. Wren mislaid a pamphlet on knots by way of the customs shed. The pilot's daughter catalogued a box of unsorted letters past the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

Wind from the east, and the shutters complaining. The binder wrapped the subscription list by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Dr okafor found the second proof from Gull Stairs. You would have laughed; I nearly did. The pilot's daughter mislaid the harbourmaster's daybook from the lighthouse landing. Old farrow repaired the tide tables for the spring to the ferry office. Old farrow promised me a water-stained atlas past the bindery. Dr okafor carried the harbourmaster's daybook past the ferry office.

Rain came in sideways off the bar. Mr calloway catalogued a water-stained atlas by way of Gull Stairs. I have copied the passage twice and still do not believe it. Dr okafor mislaid an index nobody had finished past the bindery. If the edition is to be trusted it must say what it changed. Wren mislaid a water-stained atlas from the lower reading room.

It was the first clear morning in a week. Wren copied out the second proof past the archive cellar. If the edition is to be trusted it must say what it changed. The binder found a ledger of soundings from the quay. Mr calloway copied out an index nobody had finished from the lower reading room. Wren promised me a water-stained atlas past the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait.

— Ever, A.

## Letter 193

*Friday, from the quay*

It was the first clear morning in a week. Ines carried the harbourmaster's daybook from the lighthouse landing. I have copied the passage twice and still do not believe it. Ines wrapped the harbourmaster's daybook to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The binder wrapped a box of unsorted letters past Saltmarsh Lane. Mr calloway mislaid a pamphlet on knots by way of the chandler's loft.

The fog stayed until noon. The binder promised me a water-stained atlas to the bindery. Mr calloway returned the second proof to the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor returned the tide tables for the spring to the lighthouse landing. If the edition is to be trusted it must say what it changed. The binder found an index nobody had finished past the lower reading room. Dr okafor returned a water-stained atlas from the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. The pilot's daughter repaired a parcel of marbled endpapers by way of the archive cellar. The pilot's daughter copied out a water-stained atlas past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren promised me the second proof past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway carried the subscription list from the customs shed. I begin to think a catalogue is only a polite way of remembering. Wren catalogued a ledger of soundings to Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

## Letter 194

*Friday, from Gull Stairs*

The tide was late and so was everyone else. The binder mislaid the subscription list from the quay. The pilot's daughter carried the harbourmaster's daybook by way of the lighthouse landing. Mr calloway copied out the subscription list from the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Wren mislaid a pamphlet on knots from the archive cellar. Old farrow mislaid a pamphlet on knots from Gull Stairs. You would have laughed; I nearly did.

A still day, the water like poured lead. Wren wrapped a box of unsorted letters from the ferry office. Old farrow repaired the tide tables for the spring to Gull Stairs. The pilot's daughter returned a pamphlet on knots by way of the quay. You would have laughed; I nearly did. The binder promised me a ledger of soundings by way of the archive cellar. The binder carried a water-stained atlas from the ferry office.

The tide was late and so was everyone else. Mr calloway mislaid a box of unsorted letters to Saltmarsh Lane. Dr okafor repaired a parcel of marbled endpapers to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor returned the second proof past Gull Stairs. Teodor catalogued an index nobody had finished past the bindery. Old farrow found an index nobody had finished past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Teodor repaired the subscription list from the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor returned a water-stained atlas past Gull Stairs. Wren found the harbourmaster's daybook from the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. Old farrow found a ledger of soundings to the ferry office. Wren repaired the harbourmaster's daybook past the lower reading room. Old farrow mislaid an index nobody had finished from Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Ines mislaid a box of unsorted letters to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor wrapped a ledger of soundings from the ferry office. The binder returned a pamphlet on knots from the bindery.

— Yours in haste, A.

## Letter 195

*Friday, from Gull Stairs*

Rain came in sideways off the bar. Wren wrapped a pamphlet on knots by way of Gull Stairs. Teodor copied out a ledger of soundings past the quay. The pilot's daughter repaired the tide tables for the spring by way of the quay.

Rain came in sideways off the bar. The binder mislaid a water-stained atlas by way of Gull Stairs. Dr okafor catalogued the second proof to the quay. I have copied the passage twice and still do not believe it. Ines copied out the subscription list from the customs shed. If the edition is to be trusted it must say what it changed. Ines found the subscription list from the quay. Old farrow catalogued a ledger of soundings from the chandler's loft. You would have laughed; I nearly did.

The tide was late and so was everyone else. Wren promised me the harbourmaster's daybook to the lower reading room. Dr okafor found the subscription list to Saltmarsh Lane. The pilot's daughter wrapped a parcel of marbled endpapers by way of the archive cellar. The pilot's daughter found a ledger of soundings from the lower reading room. I have copied the passage twice and still do not believe it. Dr okafor carried the second proof from the quay.

— Yours, A.

## Letter 196

*Wednesday, from the lighthouse landing*

Rain came in sideways off the bar. Old farrow mislaid the harbourmaster's daybook by way of the ferry office. You would have laughed; I nearly did. The binder catalogued a ledger of soundings to the customs shed. I have copied the passage twice and still do not believe it. The binder promised me a ledger of soundings from the customs shed. You would have laughed; I nearly did. Teodor catalogued the tide tables for the spring past the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway returned a ledger of soundings by way of the lower reading room. Old farrow carried a ledger of soundings from Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. Wren mislaid the second proof past the archive cellar. Teodor catalogued a pamphlet on knots by way of the bindery. I have copied the passage twice and still do not believe it. Ines carried an index nobody had finished past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Ines carried the second proof past the lower reading room. You would have laughed; I nearly did. Old farrow copied out an index nobody had finished to the archive cellar. If the edition is to be trusted it must say what it changed. Wren repaired an index nobody had finished by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Wren wrapped a box of unsorted letters to Saltmarsh Lane. Old farrow returned the subscription list past the bindery. The pilot's daughter wrapped a box of unsorted letters past the lower reading room.

— With salt on the page, A.

## Letter 197

*Tuesday, from the bindery*

Wind from the east, and the shutters complaining. Wren returned the harbourmaster's daybook to the lower reading room. Old farrow returned a pamphlet on knots from the lower reading room. Teodor catalogued a ledger of soundings by way of the lighthouse landing.

The tide was late and so was everyone else. Dr okafor copied out the tide tables for the spring past Saltmarsh Lane. I have copied the passage twice and still do not believe it. Wren returned a ledger of soundings from the lighthouse landing. The binder returned the second proof past the quay. We agreed that the index should wait until the letters were in order, and then did not wait. The binder promised me the tide tables for the spring past Saltmarsh Lane. I have copied the passage twice and still do not believe it. Old farrow catalogued the tide tables for the spring to the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. Wren copied out the subscription list from the chandler's loft. If the edition is to be trusted it must say what it changed. Ines mislaid an index nobody had finished past the ferry office. The binder found the subscription list from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor found a ledger of soundings by way of the quay. The binder wrapped a ledger of soundings by way of the lower reading room. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Teodor carried a ledger of soundings by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines found a parcel of marbled endpapers to the archive cellar. Dr okafor promised me a pamphlet on knots from Gull Stairs. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. Dr okafor copied out the tide tables for the spring past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway repaired the second proof past the ferry office. Mr calloway promised me a box of unsorted letters by way of Gull Stairs. You would have laughed; I nearly did.

— Yours in haste, A.

## Letter 198

*Thursday, from the chandler's loft*

The fog stayed until noon. The pilot's daughter copied out a parcel of marbled endpapers from the bindery. Teodor promised me the subscription list past Gull Stairs. The binder mislaid an index nobody had finished past Gull Stairs.

Rain came in sideways off the bar. Old farrow repaired a pamphlet on knots from the lighthouse landing. Wren mislaid an index nobody had finished by way of the ferry office. If the edition is to be trusted it must say what it changed. Old farrow wrapped the second proof past the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

It was the first clear morning in a week. Mr calloway returned the subscription list by way of the bindery. If the edition is to be trusted it must say what it changed. Ines found the subscription list from the bindery. Dr okafor returned the subscription list by way of the quay. You would have laughed; I nearly did. The binder wrapped a pamphlet on knots from the ferry office.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 199

*Friday, from the quay*

A still day, the water like poured lead. Dr okafor mislaid a water-stained atlas past the chandler's loft. Dr okafor promised me the second proof from Saltmarsh Lane. Old farrow wrapped an index nobody had finished by way of the customs shed. Mr calloway promised me a parcel of marbled endpapers from the lighthouse landing.

Wind from the east, and the shutters complaining. Old farrow mislaid a parcel of marbled endpapers to the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway copied out a ledger of soundings to the customs shed. You would have laughed; I nearly did. The binder repaired a parcel of marbled endpapers past the archive cellar. I begin to think a catalogue is only a polite way of remembering. Teodor mislaid the second proof from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Wren repaired a ledger of soundings past Saltmarsh Lane.

It was the first clear morning in a week. Wren catalogued a parcel of marbled endpapers from the lower reading room. Wren returned a pamphlet on knots to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway mislaid the second proof by way of the quay. The binder catalogued the second proof past Gull Stairs.

— With salt on the page, A.

## Letter 200

*Tuesday, from the customs shed*

A still day, the water like poured lead. Dr okafor returned an index nobody had finished by way of the quay. Teodor repaired the tide tables for the spring to the lower reading room. Teodor catalogued a ledger of soundings to the ferry office. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. The binder wrapped a box of unsorted letters from the lower reading room. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter carried the subscription list by way of the customs shed. Teodor found a pamphlet on knots to the customs shed. You would have laughed; I nearly did. Old farrow found a parcel of marbled endpapers from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

Wind from the east, and the shutters complaining. Wren catalogued a box of unsorted letters by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned a ledger of soundings from the bindery. The binder promised me a parcel of marbled endpapers to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter carried the tide tables for the spring past the bindery. I begin to think a catalogue is only a polite way of remembering.

— Ever, A.

## Letter 201

*Monday, from Saltmarsh Lane*

A still day, the water like poured lead. Teodor promised me a parcel of marbled endpapers past the bindery. The binder wrapped the tide tables for the spring by way of the archive cellar. Ines mislaid a box of unsorted letters from Gull Stairs.

Rain came in sideways off the bar. Dr okafor repaired the second proof to the bindery. The pilot's daughter promised me a ledger of soundings from the ferry office. Old farrow repaired the second proof from Saltmarsh Lane. I have copied the passage twice and still do not believe it. Mr calloway carried the tide tables for the spring from the archive cellar.

It was the first clear morning in a week. The binder returned a ledger of soundings to the lighthouse landing. You would have laughed; I nearly did. Wren catalogued the harbourmaster's daybook to the archive cellar. The pilot's daughter repaired the harbourmaster's daybook past the archive cellar. I have copied the passage twice and still do not believe it. The pilot's daughter promised me a ledger of soundings from the bindery. If the edition is to be trusted it must say what it changed. Mr calloway promised me the harbourmaster's daybook by way of Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. Teodor found the harbourmaster's daybook to the chandler's loft. You would have laughed; I nearly did. Dr okafor carried a parcel of marbled endpapers by way of the customs shed. The binder catalogued the tide tables for the spring to the chandler's loft. Dr okafor returned an index nobody had finished to the lighthouse landing.

— Yours, A.

## Letter 202

*Monday, from Saltmarsh Lane*

The tide was late and so was everyone else. Teodor copied out a water-stained atlas past the quay. Wren catalogued the second proof by way of the customs shed. Wren returned a water-stained atlas to the chandler's loft. The binder carried the tide tables for the spring by way of the quay. Old farrow returned a ledger of soundings from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Wren wrapped a pamphlet on knots past the lower reading room. You would have laughed; I nearly did.

The fog stayed until noon. Teodor copied out an index nobody had finished past the archive cellar. The binder repaired the harbourmaster's daybook to the archive cellar. I have copied the passage twice and still do not believe it. The binder repaired a pamphlet on knots to the chandler's loft. I have copied the passage twice and still do not believe it. Dr okafor catalogued a pamphlet on knots by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Teodor promised me a water-stained atlas past Gull Stairs. I have copied the passage twice and still do not believe it. Teodor copied out an index nobody had finished to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor copied out a water-stained atlas to the lighthouse landing. Dr okafor repaired the tide tables for the spring to the quay. Teodor repaired a parcel of marbled endpapers to the customs shed. The binder promised me a parcel of marbled endpapers to the lighthouse landing.

Rain came in sideways off the bar. The pilot's daughter carried a box of unsorted letters to the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway wrapped a pamphlet on knots from Saltmarsh Lane. Mr calloway mislaid the tide tables for the spring past the archive cellar. I have copied the passage twice and still do not believe it. The binder returned a box of unsorted letters by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Wren found a ledger of soundings by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. The binder mislaid a water-stained atlas by way of the customs shed.

The tide was late and so was everyone else. Wren carried the second proof from the ferry office. Ines found the harbourmaster's daybook from the customs shed. I have copied the passage twice and still do not believe it. Mr calloway repaired the tide tables for the spring to Gull Stairs. Old farrow mislaid the harbourmaster's daybook past Gull Stairs.

— Yours, A.

## Letter 203

*Monday, from the lighthouse landing*

The fog stayed until noon. Wren mislaid an index nobody had finished from the ferry office. The binder carried a ledger of soundings to Saltmarsh Lane. The binder wrapped the harbourmaster's daybook by way of the lighthouse landing. You would have laughed; I nearly did. Mr calloway mislaid the subscription list to the lighthouse landing. The pilot's daughter catalogued the tide tables for the spring to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Old farrow returned a box of unsorted letters past the bindery. If the edition is to be trusted it must say what it changed.

It was the first clear morning in a week. Dr okafor mislaid a parcel of marbled endpapers from the ferry office. Dr okafor wrapped a box of unsorted letters from the archive cellar. Mr calloway catalogued a pamphlet on knots by way of the quay. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me the subscription list to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Ines carried the subscription list to the lower reading room. I have copied the passage twice and still do not believe it. Wren mislaid the harbourmaster's daybook to Saltmarsh Lane. Ines wrapped an index nobody had finished from the ferry office. Dr okafor carried a ledger of soundings by way of Gull Stairs. Teodor promised me a water-stained atlas by way of the archive cellar. You would have laughed; I nearly did. Mr calloway mislaid a box of unsorted letters from the archive cellar.

It was the first clear morning in a week. Wren wrapped an index nobody had finished by way of the archive cellar. Old farrow promised me a water-stained atlas by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Dr okafor repaired the subscription list by way of the lighthouse landing. Teodor found a water-stained atlas from the ferry office.

The tide was late and so was everyone else. Teodor mislaid a box of unsorted letters past the quay. Wren returned a pamphlet on knots to Gull Stairs. Teodor catalogued a parcel of marbled endpapers past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. The binder promised me the tide tables for the spring past the ferry office. You would have laughed; I nearly did. Dr okafor copied out a box of unsorted letters past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor returned the harbourmaster's daybook from the archive cellar.

— With salt on the page, A.

## Letter 204

*Friday, from the customs shed*

Rain came in sideways off the bar. Dr okafor carried the subscription list to the archive cellar. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter mislaid a water-stained atlas to Saltmarsh Lane. I have copied the passage twice and still do not believe it. Wren promised me the harbourmaster's daybook from the lighthouse landing.

The tide was late and so was everyone else. Wren found an index nobody had finished from the chandler's loft. The pilot's daughter repaired the tide tables for the spring by way of the archive cellar. Old farrow wrapped a water-stained atlas past the ferry office. Dr okafor repaired a water-stained atlas by way of the quay.

It was the first clear morning in a week. Dr okafor carried a parcel of marbled endpapers from Gull Stairs. Ines repaired a parcel of marbled endpapers from the bindery. Old farrow copied out a pamphlet on knots by way of the lower reading room. You would have laughed; I nearly did. Ines wrapped a box of unsorted letters past Gull Stairs. Old farrow carried the second proof past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor carried a box of unsorted letters from the chandler's loft.

The tide was late and so was everyone else. Wren carried a box of unsorted letters past the bindery. Mr calloway found the tide tables for the spring from the lower reading room. Ines catalogued the harbourmaster's daybook to the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid a ledger of soundings from the lighthouse landing. If the edition is to be trusted it must say what it changed. Ines wrapped a water-stained atlas by way of the lighthouse landing.

— With salt on the page, A.

## Letter 205

*Wednesday, from the lighthouse landing*

The tide was late and so was everyone else. Ines mislaid a pamphlet on knots past the lighthouse landing. The binder carried the harbourmaster's daybook past the chandler's loft. Mr calloway carried a ledger of soundings to the bindery. I have copied the passage twice and still do not believe it. Teodor mislaid the harbourmaster's daybook from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Wren promised me a box of unsorted letters to the bindery. The pilot's daughter returned an index nobody had finished to the lighthouse landing. Old farrow returned an index nobody had finished past the lower reading room.

Wind from the east, and the shutters complaining. Mr calloway promised me a pamphlet on knots past the customs shed. Ines copied out a ledger of soundings to the ferry office. Wren carried the second proof to the lighthouse landing. The binder promised me an index nobody had finished by way of Saltmarsh Lane. Old farrow promised me the subscription list by way of the customs shed. Teodor repaired a box of unsorted letters to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Old farrow repaired a water-stained atlas past the archive cellar. I begin to think a catalogue is only a polite way of remembering. Teodor catalogued an index nobody had finished from the bindery. I have copied the passage twice and still do not believe it. Wren wrapped the harbourmaster's daybook past the chandler's loft. Ines carried a water-stained atlas by way of the chandler's loft. The binder repaired a box of unsorted letters past the customs shed. I begin to think a catalogue is only a polite way of remembering. Teodor promised me the second proof by way of the chandler's loft.

Wind from the east, and the shutters complaining. The binder found the tide tables for the spring by way of the lighthouse landing. Ines found an index nobody had finished by way of the bindery. Old farrow carried a pamphlet on knots to the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor wrapped a ledger of soundings to Gull Stairs.

— Ever, A.

## Letter 206

*Wednesday, from the bindery*

The tide was late and so was everyone else. Dr okafor carried an index nobody had finished past Gull Stairs. I have copied the passage twice and still do not believe it. Ines carried a water-stained atlas from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired an index nobody had finished from Gull Stairs.

The fog stayed until noon. Mr calloway catalogued a pamphlet on knots to the customs shed. Ines catalogued a parcel of marbled endpapers from the bindery. Mr calloway promised me the tide tables for the spring to the customs shed. The pilot's daughter copied out a parcel of marbled endpapers by way of the quay.

It was the first clear morning in a week. Teodor promised me a water-stained atlas by way of the quay. Dr okafor mislaid a water-stained atlas past the lighthouse landing. Old farrow found an index nobody had finished past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Ines catalogued the harbourmaster's daybook from Gull Stairs.

The fog stayed until noon. Mr calloway returned an index nobody had finished to the ferry office. Teodor repaired the harbourmaster's daybook by way of the archive cellar. The binder promised me the harbourmaster's daybook to the customs shed. The binder repaired a ledger of soundings from the archive cellar. The pilot's daughter carried the subscription list to the quay. If the edition is to be trusted it must say what it changed. Mr calloway found the tide tables for the spring by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours, A.

## Letter 207

*Thursday, from the chandler's loft*

A still day, the water like poured lead. Wren catalogued the second proof past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines mislaid a parcel of marbled endpapers past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid a ledger of soundings to the lighthouse landing. If the edition is to be trusted it must say what it changed.

It was the first clear morning in a week. The pilot's daughter mislaid a pamphlet on knots past Gull Stairs. You would have laughed; I nearly did. Dr okafor returned a pamphlet on knots past the bindery. Old farrow copied out the harbourmaster's daybook from the archive cellar. The pilot's daughter found a parcel of marbled endpapers past the quay.

A still day, the water like poured lead. Wren found the subscription list past the chandler's loft. Wren wrapped a parcel of marbled endpapers by way of the lighthouse landing. Dr okafor returned the tide tables for the spring to the quay. I begin to think a catalogue is only a polite way of remembering.

— Yours in haste, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 208

*Monday, from the ferry office*

A still day, the water like poured lead. The pilot's daughter mislaid a box of unsorted letters past the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Wren promised me a ledger of soundings to the quay. Wren mislaid the subscription list past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor copied out a parcel of marbled endpapers to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. The pilot's daughter found a water-stained atlas by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. Wren copied out the tide tables for the spring past the customs shed. If the edition is to be trusted it must say what it changed. Mr calloway copied out a ledger of soundings by way of the bindery. Ines wrapped a water-stained atlas from the lighthouse landing. Dr okafor promised me the subscription list from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Dr okafor mislaid a ledger of soundings to the quay. I have copied the passage twice and still do not believe it. Old farrow copied out the second proof past the archive cellar. Teodor found a box of unsorted letters from the ferry office.

The fog stayed until noon. Mr calloway copied out the tide tables for the spring to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor mislaid the second proof by way of the lower reading room. Old farrow returned a water-stained atlas by way of the quay. You would have laughed; I nearly did. Old farrow carried a pamphlet on knots to the lower reading room. I have copied the passage twice and still do not believe it.

— Yours, A.

## Letter 209

*Friday, from the chandler's loft*

It was the first clear morning in a week. Old farrow mislaid the second proof past the customs shed. Dr okafor promised me an index nobody had finished from the bindery. Old farrow repaired the second proof by way of the customs shed. Old farrow carried a ledger of soundings from Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Teodor repaired the tide tables for the spring past the quay. Dr okafor found a water-stained atlas to the chandler's loft.

The tide was late and so was everyone else. Mr calloway mislaid a water-stained atlas to the quay. The binder found the harbourmaster's daybook from the chandler's loft. I have copied the passage twice and still do not believe it. Ines repaired a water-stained atlas from the customs shed. Old farrow found a box of unsorted letters by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering. Ines mislaid the harbourmaster's daybook from the quay. Mr calloway copied out a parcel of marbled endpapers from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Ines wrapped a water-stained atlas from the lighthouse landing. You would have laughed; I nearly did. Dr okafor carried the tide tables for the spring to the ferry office. Ines carried a parcel of marbled endpapers from the customs shed. I begin to think a catalogue is only a polite way of remembering. Ines carried the second proof to Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

— Ever, A.

## Letter 210

*Friday, from Saltmarsh Lane*

It was the first clear morning in a week. Ines returned a ledger of soundings to the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway mislaid an index nobody had finished by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. The binder returned a box of unsorted letters by way of the archive cellar. Mr calloway promised me an index nobody had finished by way of the lighthouse landing. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Teodor copied out a box of unsorted letters to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Ines repaired the second proof to the quay. Teodor wrapped the subscription list to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Dr okafor copied out a parcel of marbled endpapers to the lower reading room. I begin to think a catalogue is only a polite way of remembering. Wren promised me a box of unsorted letters by way of the archive cellar. Dr okafor returned a water-stained atlas past the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Mr calloway wrapped a box of unsorted letters from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor wrapped a box of unsorted letters to the lower reading room. Wren repaired the second proof to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Ines repaired a box of unsorted letters to the quay. The pilot's daughter promised me the tide tables for the spring by way of the customs shed.

— With salt on the page, A.

## Letter 211

*Friday, from the lower reading room*

Wind from the east, and the shutters complaining. The pilot's daughter found the subscription list past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor found a box of unsorted letters to the bindery. I have copied the passage twice and still do not believe it. Dr okafor found the harbourmaster's daybook from Gull Stairs. I have copied the passage twice and still do not believe it. Teodor promised me an index nobody had finished from the quay. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me a pamphlet on knots to the customs shed. I begin to think a catalogue is only a polite way of remembering. Wren catalogued a parcel of marbled endpapers past the chandler's loft. You would have laughed; I nearly did.

The tide was late and so was everyone else. The pilot's daughter carried the subscription list by way of the chandler's loft. If the edition is to be trusted it must say what it changed. Wren copied out the second proof to the archive cellar. Mr calloway carried a water-stained atlas by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Teodor copied out a parcel of marbled endpapers to the customs shed. Old farrow promised me a ledger of soundings by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Wren catalogued the harbourmaster's daybook to the archive cellar.

— With salt on the page, A.

## Letter 212

*Tuesday, from Gull Stairs*

Rain came in sideways off the bar. Teodor returned the second proof to the archive cellar. Old farrow promised me a pamphlet on knots from the chandler's loft. Teodor wrapped a pamphlet on knots to the customs shed. The binder repaired a pamphlet on knots from Gull Stairs. Ines returned an index nobody had finished by way of the customs shed. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. The pilot's daughter wrapped an index nobody had finished by way of the chandler's loft. Mr calloway mislaid a parcel of marbled endpapers by way of the bindery. If the edition is to be trusted it must say what it changed. Dr okafor wrapped a parcel of marbled endpapers by way of the quay. I have copied the passage twice and still do not believe it.

The fog stayed until noon. Old farrow returned the harbourmaster's daybook to Gull Stairs. The pilot's daughter copied out a box of unsorted letters by way of the lighthouse landing. You would have laughed; I nearly did. The binder carried the second proof by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor repaired the harbourmaster's daybook by way of the quay. Ines promised me an index nobody had finished to Gull Stairs.

— Yours in haste, A.

## Letter 213

*Wednesday, from the quay*

The tide was late and so was everyone else. The pilot's daughter catalogued an index nobody had finished past the quay. Mr calloway carried a parcel of marbled endpapers to the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned the harbourmaster's daybook past the lighthouse landing.

A still day, the water like poured lead. The pilot's daughter returned the harbourmaster's daybook to the ferry office. Ines catalogued an index nobody had finished from Gull Stairs. The binder carried a parcel of marbled endpapers past the chandler's loft. If the edition is to be trusted it must say what it changed. Teodor repaired the second proof from the archive cellar. Teodor copied out a box of unsorted letters past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter repaired an index nobody had finished to Saltmarsh Lane.

Rain came in sideways off the bar. Dr okafor catalogued an index nobody had finished from the lighthouse landing. Teodor repaired a ledger of soundings from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor repaired a pamphlet on knots to the lighthouse landing. Mr calloway wrapped an index nobody had finished from the lighthouse landing. The pilot's daughter found an index nobody had finished from the archive cellar.

A still day, the water like poured lead. Old farrow copied out an index nobody had finished to the customs shed. Wren copied out a water-stained atlas to the ferry office. Teodor returned a box of unsorted letters from the lighthouse landing. Ines promised me a water-stained atlas past the ferry office. Old farrow carried a water-stained atlas to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Ines promised me a ledger of soundings from the ferry office. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. The binder found a ledger of soundings by way of Gull Stairs. I have copied the passage twice and still do not believe it. Dr okafor copied out a parcel of marbled endpapers to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor returned the subscription list by way of the customs shed.

— Yours, A.

## Letter 214

*Friday, from the chandler's loft*

Rain came in sideways off the bar. The pilot's daughter mislaid an index nobody had finished by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The binder carried the harbourmaster's daybook to the bindery. Teodor wrapped a water-stained atlas from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering.

It was the first clear morning in a week. The pilot's daughter copied out a parcel of marbled endpapers from the bindery. The binder catalogued the harbourmaster's daybook from the quay. Old farrow copied out the second proof by way of Saltmarsh Lane.

Rain came in sideways off the bar. Teodor mislaid a box of unsorted letters past the bindery. Mr calloway found a water-stained atlas to the quay. The binder promised me a box of unsorted letters from the lighthouse landing. Mr calloway wrapped a box of unsorted letters past the bindery. I have copied the passage twice and still do not believe it. Teodor catalogued the harbourmaster's daybook past the lighthouse landing. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. The pilot's daughter found the harbourmaster's daybook by way of the archive cellar. You would have laughed; I nearly did. Ines wrapped a parcel of marbled endpapers past the ferry office. The binder promised me a ledger of soundings from the archive cellar. I have copied the passage twice and still do not believe it. Teodor catalogued a parcel of marbled endpapers by way of the bindery. I begin to think a catalogue is only a polite way of remembering. Mr calloway found the second proof to the ferry office. The binder catalogued an index nobody had finished by way of the customs shed.

The tide was late and so was everyone else. Teodor catalogued the harbourmaster's daybook by way of the lower reading room. The binder carried the harbourmaster's daybook by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Wren wrapped a parcel of marbled endpapers by way of the bindery. The pilot's daughter repaired a water-stained atlas by way of the customs shed.

— Yours, A.

## Letter 215

*Monday, from the bindery*

It was the first clear morning in a week. Teodor returned a pamphlet on knots to the ferry office. The binder returned a pamphlet on knots by way of the archive cellar. If the edition is to be trusted it must say what it changed. Old farrow returned a pamphlet on knots past the bindery. The pilot's daughter returned the tide tables for the spring past Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow repaired the subscription list past the ferry office. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Mr calloway repaired a parcel of marbled endpapers to the ferry office. You would have laughed; I nearly did. The binder wrapped an index nobody had finished from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Ines catalogued an index nobody had finished to the archive cellar. Dr okafor copied out a box of unsorted letters from the ferry office. The pilot's daughter mislaid an index nobody had finished past the quay.

Rain came in sideways off the bar. The pilot's daughter mislaid a parcel of marbled endpapers from the quay. You would have laughed; I nearly did. Old farrow returned a box of unsorted letters by way of the ferry office. The pilot's daughter repaired a ledger of soundings from the ferry office.

Rain came in sideways off the bar. Old farrow returned a water-stained atlas to the chandler's loft. You would have laughed; I nearly did. The pilot's daughter copied out a water-stained atlas past the ferry office. Old farrow found a parcel of marbled endpapers past the lighthouse landing. If the edition is to be trusted it must say what it changed. The pilot's daughter found the harbourmaster's daybook by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter mislaid the harbourmaster's daybook to the chandler's loft. Teodor wrapped a ledger of soundings past the bindery. You would have laughed; I nearly did.

The fog stayed until noon. Mr calloway returned a parcel of marbled endpapers by way of Gull Stairs. Teodor carried a box of unsorted letters to Saltmarsh Lane. Old farrow mislaid a ledger of soundings from the ferry office. Teodor repaired a pamphlet on knots to the lower reading room.

— Ever, A.

## Letter 216

*Monday, from Gull Stairs*

A still day, the water like poured lead. Old farrow carried a pamphlet on knots by way of the customs shed. The pilot's daughter repaired the subscription list past the customs shed. I begin to think a catalogue is only a polite way of remembering. Teodor promised me a box of unsorted letters from the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Ines catalogued the tide tables for the spring from Gull Stairs. You would have laughed; I nearly did. The binder wrapped a box of unsorted letters from the lower reading room. The pilot's daughter found a parcel of marbled endpapers to the chandler's loft. I have copied the passage twice and still do not believe it. Old farrow catalogued a pamphlet on knots from the lighthouse landing.

The fog stayed until noon. Ines promised me the subscription list by way of Gull Stairs. The pilot's daughter wrapped the second proof past the ferry office. Mr calloway returned a ledger of soundings from the quay.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 217

*Tuesday, from the customs shed*

Wind from the east, and the shutters complaining. Old farrow catalogued a water-stained atlas by way of the bindery. Wren promised me a ledger of soundings past Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow wrapped a water-stained atlas past the lighthouse landing. If the edition is to be trusted it must say what it changed. The pilot's daughter wrapped the harbourmaster's daybook from the bindery. The pilot's daughter carried a box of unsorted letters past the archive cellar.

The tide was late and so was everyone else. Wren catalogued the tide tables for the spring to Gull Stairs. Dr okafor mislaid the subscription list from the ferry office. The pilot's daughter carried a water-stained atlas past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. The binder promised me the harbourmaster's daybook from the ferry office. Dr okafor catalogued a pamphlet on knots by way of the lower reading room.

The fog stayed until noon. Ines copied out an index nobody had finished to the archive cellar. I have copied the passage twice and still do not believe it. Old farrow returned the harbourmaster's daybook to the lighthouse landing. You would have laughed; I nearly did. Teodor carried a ledger of soundings to the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Teodor promised me a pamphlet on knots by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Old farrow found a pamphlet on knots past the chandler's loft. Mr calloway mislaid a water-stained atlas by way of the bindery. Teodor carried the tide tables for the spring past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on.

— Ever, A.

## Letter 218

*Tuesday, from the archive cellar*

Rain came in sideways off the bar. Teodor repaired the tide tables for the spring from the lower reading room. Teodor returned a pamphlet on knots from the customs shed. Teodor found the tide tables for the spring by way of the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

A still day, the water like poured lead. Mr calloway found the tide tables for the spring from the ferry office. Teodor mislaid the subscription list past the customs shed. I begin to think a catalogue is only a polite way of remembering. Old farrow mislaid a ledger of soundings by way of the chandler's loft. The pilot's daughter repaired an index nobody had finished to the bindery. Old farrow wrapped a ledger of soundings to the bindery.

A still day, the water like poured lead. Mr calloway returned an index nobody had finished past the archive cellar. You would have laughed; I nearly did. Wren copied out a box of unsorted letters to the customs shed. Wren mislaid an index nobody had finished to Saltmarsh Lane. Wren copied out the subscription list from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Wren found the subscription list past the ferry office. Ines catalogued the subscription list to the lower reading room. I begin to think a catalogue is only a polite way of remembering.

A still day, the water like poured lead. Dr okafor found a box of unsorted letters from the customs shed. Old farrow mislaid the second proof past the chandler's loft. Teodor found a parcel of marbled endpapers by way of the lighthouse landing.

— Yours, A.

## Letter 219

*Monday, from the bindery*

Rain came in sideways off the bar. Mr calloway wrapped the second proof to the lighthouse landing. Mr calloway returned the second proof to Saltmarsh Lane. I have copied the passage twice and still do not believe it. The pilot's daughter found an index nobody had finished past the bindery. Teodor found a pamphlet on knots to the lower reading room. Wren repaired a parcel of marbled endpapers past the archive cellar. The pilot's daughter catalogued a parcel of marbled endpapers to the ferry office.

The fog stayed until noon. Mr calloway returned the subscription list from the chandler's loft. If the edition is to be trusted it must say what it changed. Wren catalogued a ledger of soundings from the archive cellar. Wren carried an index nobody had finished past the lower reading room. If the edition is to be trusted it must say what it changed. Dr okafor mislaid an index nobody had finished to the bindery. The pilot's daughter found a box of unsorted letters past the quay. The binder catalogued a ledger of soundings from the customs shed. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Mr calloway catalogued the harbourmaster's daybook from Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter copied out the tide tables for the spring from the customs shed. The pilot's daughter mislaid a water-stained atlas from the ferry office. If the edition is to be trusted it must say what it changed.

Rain came in sideways off the bar. Teodor returned a parcel of marbled endpapers from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter promised me the second proof from the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway copied out a ledger of soundings to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Dr okafor catalogued a ledger of soundings past the archive cellar. Mr calloway wrapped a ledger of soundings by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor carried an index nobody had finished from the lower reading room. I begin to think a catalogue is only a polite way of remembering.

Wind from the east, and the shutters complaining. The pilot's daughter catalogued a pamphlet on knots past the archive cellar. Wren returned a box of unsorted letters to the ferry office. If the edition is to be trusted it must say what it changed. The binder catalogued a pamphlet on knots from the archive cellar. Ines catalogued the second proof by way of Saltmarsh Lane. The pilot's daughter found the harbourmaster's daybook from the ferry office. I have copied the passage twice and still do not believe it.

— Yours in haste, A.

## Letter 220

*Monday, from the bindery*

The fog stayed until noon. The pilot's daughter wrapped a pamphlet on knots to the chandler's loft. If the edition is to be trusted it must say what it changed. Ines found a pamphlet on knots past the ferry office. Old farrow promised me the harbourmaster's daybook past the ferry office. I begin to think a catalogue is only a polite way of remembering. The binder catalogued a box of unsorted letters from the archive cellar. Mr calloway promised me a box of unsorted letters from the lighthouse landing.

The fog stayed until noon. Mr calloway repaired the harbourmaster's daybook past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor returned the subscription list to the ferry office. I begin to think a catalogue is only a polite way of remembering. Teodor mislaid the second proof from the customs shed. Teodor promised me a parcel of marbled endpapers to Saltmarsh Lane. Dr okafor returned a pamphlet on knots by way of the lighthouse landing. Teodor catalogued a parcel of marbled endpapers past the quay. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. The binder found a pamphlet on knots by way of the ferry office. The binder wrapped the harbourmaster's daybook to the lighthouse landing. Teodor promised me the harbourmaster's daybook from Saltmarsh Lane.

A still day, the water like poured lead. Dr okafor wrapped the second proof by way of the ferry office. You would have laughed; I nearly did. Wren repaired the subscription list to the bindery. The binder returned a ledger of soundings from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering.

— With salt on the page, A.

## Letter 221

*Friday, from the bindery*

It was the first clear morning in a week. Wren carried a pamphlet on knots to Gull Stairs. You would have laughed; I nearly did. Ines mislaid an index nobody had finished past the quay. You would have laughed; I nearly did. Teodor repaired a box of unsorted letters past Saltmarsh Lane. The binder mislaid a parcel of marbled endpapers to the customs shed. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. Old farrow repaired a pamphlet on knots by way of the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow copied out the subscription list past the bindery. The binder found a box of unsorted letters past the bindery. Ines found the subscription list to the archive cellar. The binder repaired a ledger of soundings from the quay. Old farrow promised me a ledger of soundings by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. Old farrow returned a box of unsorted letters to the customs shed. Mr calloway repaired the tide tables for the spring from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway found the tide tables for the spring past the archive cellar. Dr okafor mislaid the subscription list by way of the bindery. Old farrow copied out an index nobody had finished from the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Ines copied out a ledger of soundings from Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering.

— Yours, A.

## Letter 222

*Friday, from the bindery*

The tide was late and so was everyone else. Wren catalogued a ledger of soundings by way of Saltmarsh Lane. Dr okafor promised me a pamphlet on knots past the bindery. Wren returned the tide tables for the spring to the bindery. I have copied the passage twice and still do not believe it. Teodor wrapped a box of unsorted letters from the archive cellar. The binder copied out the second proof from the chandler's loft. The pilot's daughter returned the tide tables for the spring to the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. The binder catalogued the harbourmaster's daybook from the quay. You would have laughed; I nearly did. Teodor catalogued a box of unsorted letters to Saltmarsh Lane. Wren carried the subscription list past the bindery. I have copied the passage twice and still do not believe it. The pilot's daughter catalogued a box of unsorted letters past the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. The binder repaired the second proof from the customs shed. I begin to think a catalogue is only a polite way of remembering. Old farrow repaired a ledger of soundings by way of the chandler's loft. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. The pilot's daughter returned a pamphlet on knots by way of the customs shed. Mr calloway found the subscription list past the lower reading room. Dr okafor mislaid a box of unsorted letters to the quay. You would have laughed; I nearly did. Ines found a parcel of marbled endpapers past the quay. Teodor carried an index nobody had finished by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Ines carried a box of unsorted letters to the lighthouse landing.

The fog stayed until noon. The pilot's daughter copied out the subscription list by way of the ferry office. I have copied the passage twice and still do not believe it. Dr okafor found an index nobody had finished by way of the bindery. Wren repaired the second proof past the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The binder promised me a ledger of soundings past the lighthouse landing. I have copied the passage twice and still do not believe it. Ines catalogued a parcel of marbled endpapers past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Mr calloway promised me a box of unsorted letters from the quay. I have copied the passage twice and still do not believe it. Ines mislaid a pamphlet on knots by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Teodor repaired the second proof from the quay. I have copied the passage twice and still do not believe it. Old farrow promised me a pamphlet on knots past the lower reading room.

— Yours, A.

## Letter 223

*Wednesday, from the bindery*

Rain came in sideways off the bar. Teodor wrapped a box of unsorted letters to the bindery. Dr okafor copied out a ledger of soundings past the customs shed. If the edition is to be trusted it must say what it changed. The pilot's daughter catalogued an index nobody had finished past the lower reading room.

Wind from the east, and the shutters complaining. Mr calloway found a water-stained atlas by way of the ferry office. If the edition is to be trusted it must say what it changed. Mr calloway found an index nobody had finished by way of the lighthouse landing. Mr calloway repaired the subscription list by way of the lower reading room. You would have laughed; I nearly did. Old farrow catalogued the subscription list by way of the bindery.

Rain came in sideways off the bar. Ines found the harbourmaster's daybook by way of the customs shed. If the edition is to be trusted it must say what it changed. Mr calloway mislaid a water-stained atlas past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter carried a water-stained atlas past the chandler's loft. You would have laughed; I nearly did. Teodor copied out the tide tables for the spring by way of Gull Stairs. If the edition is to be trusted it must say what it changed. The binder mislaid the subscription list from the lighthouse landing. You would have laughed; I nearly did. The binder copied out the second proof past the customs shed.

— With salt on the page, A.

## Letter 224

*Wednesday, from the chandler's loft*

Wind from the east, and the shutters complaining. Mr calloway repaired an index nobody had finished by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow returned a box of unsorted letters to the chandler's loft. The binder carried the harbourmaster's daybook by way of the customs shed. Wren repaired the subscription list by way of the bindery. If the edition is to be trusted it must say what it changed. The binder carried the harbourmaster's daybook past the lower reading room.

Rain came in sideways off the bar. The pilot's daughter found a parcel of marbled endpapers to the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter repaired a pamphlet on knots by way of the customs shed. I have copied the passage twice and still do not believe it. Teodor found the subscription list by way of Gull Stairs.

The fog stayed until noon. Mr calloway promised me the second proof by way of the ferry office. I have copied the passage twice and still do not believe it. Teodor catalogued a box of unsorted letters by way of the archive cellar. Teodor mislaid the harbourmaster's daybook from the lighthouse landing. Wren catalogued a box of unsorted letters by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Teodor repaired a pamphlet on knots from the bindery.

A still day, the water like poured lead. Ines found a water-stained atlas from the quay. Wren repaired the harbourmaster's daybook from the archive cellar. Wren returned a parcel of marbled endpapers from Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Ines copied out the harbourmaster's daybook to the customs shed. Mr calloway carried a parcel of marbled endpapers by way of the bindery. I have copied the passage twice and still do not believe it. Dr okafor repaired a box of unsorted letters by way of the lower reading room. You would have laughed; I nearly did. Old farrow returned a water-stained atlas by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. The pilot's daughter copied out the subscription list by way of the ferry office.

— With salt on the page, A.

## Letter 225

*Monday, from Saltmarsh Lane*

The tide was late and so was everyone else. Old farrow promised me a parcel of marbled endpapers from Saltmarsh Lane. Dr okafor catalogued the harbourmaster's daybook to the lower reading room. Mr calloway copied out a ledger of soundings to the quay. Dr okafor found a water-stained atlas from Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow found a pamphlet on knots from the customs shed. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Dr okafor promised me a box of unsorted letters by way of the lower reading room. Teodor found the subscription list past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Teodor wrapped the second proof by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow mislaid a parcel of marbled endpapers from Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out a water-stained atlas past the bindery.

Wind from the east, and the shutters complaining. Old farrow catalogued the harbourmaster's daybook by way of the quay. If the edition is to be trusted it must say what it changed. The pilot's daughter catalogued the second proof past Saltmarsh Lane. Ines catalogued the harbourmaster's daybook past the ferry office. Mr calloway repaired the second proof from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Teodor mislaid the subscription list from the bindery. The binder promised me a pamphlet on knots to the archive cellar.

Wind from the east, and the shutters complaining. Wren carried a box of unsorted letters by way of Saltmarsh Lane. The binder wrapped a ledger of soundings from Saltmarsh Lane. I have copied the passage twice and still do not believe it. Dr okafor promised me an index nobody had finished from the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Old farrow carried a parcel of marbled endpapers from the lower reading room. I have copied the passage twice and still do not believe it. Old farrow returned a water-stained atlas past the customs shed. I begin to think a catalogue is only a polite way of remembering.

— Ever, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 226

*Monday, from Saltmarsh Lane*

A still day, the water like poured lead. Wren copied out the harbourmaster's daybook by way of the archive cellar. The pilot's daughter repaired the tide tables for the spring from the ferry office. I have copied the passage twice and still do not believe it. Wren returned the tide tables for the spring from the quay.

Rain came in sideways off the bar. Dr okafor promised me the tide tables for the spring past the ferry office. Mr calloway catalogued the second proof by way of the archive cellar. Old farrow wrapped a water-stained atlas by way of the quay.

A still day, the water like poured lead. The binder copied out the subscription list past the ferry office. I begin to think a catalogue is only a polite way of remembering. Dr okafor mislaid the subscription list from the lighthouse landing. If the edition is to be trusted it must say what it changed. Teodor found the subscription list by way of Gull Stairs. Teodor promised me the tide tables for the spring to the chandler's loft. Wren found the second proof to the lower reading room.

— Ever, A.

## Letter 227

*Thursday, from the customs shed*

The tide was late and so was everyone else. Ines catalogued the subscription list by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The binder catalogued the harbourmaster's daybook to the bindery. Teodor promised me a ledger of soundings past Saltmarsh Lane.

The fog stayed until noon. Ines promised me a box of unsorted letters to the bindery. The binder copied out the subscription list from the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow wrapped a parcel of marbled endpapers from the quay. Ines returned the tide tables for the spring to the archive cellar.

It was the first clear morning in a week. Mr calloway promised me the subscription list from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow wrapped a parcel of marbled endpapers from the bindery. If the edition is to be trusted it must say what it changed. The binder returned the subscription list to the lower reading room.

Wind from the east, and the shutters complaining. Mr calloway copied out the tide tables for the spring from the chandler's loft. Old farrow repaired a box of unsorted letters from the quay. Dr okafor catalogued the subscription list by way of the chandler's loft. You would have laughed; I nearly did.

— Ever, A.

## Letter 228

*Wednesday, from Gull Stairs*

A still day, the water like poured lead. The binder found the subscription list by way of the ferry office. Wren carried a water-stained atlas to the bindery. Ines returned an index nobody had finished by way of the archive cellar. Ines carried a water-stained atlas past the archive cellar. Old farrow repaired an index nobody had finished from Gull Stairs. Mr calloway wrapped a parcel of marbled endpapers from the archive cellar.

Rain came in sideways off the bar. Mr calloway found the subscription list by way of the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid a parcel of marbled endpapers from Saltmarsh Lane. The binder wrapped an index nobody had finished to the lower reading room. You would have laughed; I nearly did. Wren wrapped a pamphlet on knots to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. The binder wrapped the subscription list past the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. The pilot's daughter catalogued a water-stained atlas to the ferry office. Teodor mislaid the second proof past the customs shed. Ines catalogued the harbourmaster's daybook to the lighthouse landing. You would have laughed; I nearly did. The pilot's daughter copied out an index nobody had finished past the chandler's loft. Dr okafor carried a pamphlet on knots to Gull Stairs. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter returned a water-stained atlas from the bindery.

The fog stayed until noon. Ines wrapped the second proof by way of the lighthouse landing. The binder carried a ledger of soundings by way of the chandler's loft. You would have laughed; I nearly did. Teodor repaired the subscription list past the ferry office. Mr calloway found a ledger of soundings by way of Gull Stairs. Old farrow wrapped a parcel of marbled endpapers by way of the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

The fog stayed until noon. Old farrow returned a pamphlet on knots to the ferry office. The pilot's daughter carried a box of unsorted letters by way of the archive cellar. If the edition is to be trusted it must say what it changed. The pilot's daughter returned a water-stained atlas from Gull Stairs. Dr okafor carried an index nobody had finished to the lower reading room. Wren catalogued the harbourmaster's daybook past Gull Stairs.

— Ever, A.

## Letter 229

*Wednesday, from the bindery*

Rain came in sideways off the bar. The pilot's daughter repaired a parcel of marbled endpapers from the quay. Mr calloway repaired the harbourmaster's daybook from the lower reading room. Dr okafor copied out the subscription list to the chandler's loft. Wren catalogued the tide tables for the spring by way of the ferry office. If the edition is to be trusted it must say what it changed. Old farrow carried a box of unsorted letters by way of the bindery. Dr okafor repaired a ledger of soundings to Saltmarsh Lane.

A still day, the water like poured lead. The pilot's daughter promised me a pamphlet on knots from the lighthouse landing. I have copied the passage twice and still do not believe it. The pilot's daughter found a ledger of soundings to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter carried a water-stained atlas from Gull Stairs. Mr calloway found a parcel of marbled endpapers to the customs shed. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. Mr calloway returned an index nobody had finished from the customs shed. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired the harbourmaster's daybook to the ferry office. I have copied the passage twice and still do not believe it. Ines promised me the tide tables for the spring to the bindery. Teodor returned a ledger of soundings by way of the bindery. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter carried a parcel of marbled endpapers past the lighthouse landing. If the edition is to be trusted it must say what it changed. The pilot's daughter returned a pamphlet on knots by way of the chandler's loft.

The fog stayed until noon. Ines returned the second proof by way of Gull Stairs. Teodor mislaid a pamphlet on knots by way of the lower reading room. Teodor promised me the second proof from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Ines wrapped the tide tables for the spring past the lighthouse landing.

— Yours, A.

## Letter 230

*Thursday, from the bindery*

Rain came in sideways off the bar. Teodor catalogued a pamphlet on knots by way of the lighthouse landing. If the edition is to be trusted it must say what it changed. The pilot's daughter found a parcel of marbled endpapers from the lighthouse landing. You would have laughed; I nearly did. The pilot's daughter catalogued the tide tables for the spring from Gull Stairs. If the edition is to be trusted it must say what it changed. Wren returned the tide tables for the spring from the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

A still day, the water like poured lead. The pilot's daughter mislaid the second proof to the lower reading room. Ines returned a water-stained atlas from the lighthouse landing. The binder mislaid a water-stained atlas by way of the quay. Dr okafor wrapped the subscription list from Gull Stairs. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. The binder repaired the harbourmaster's daybook to the archive cellar. I have copied the passage twice and still do not believe it. Dr okafor promised me the tide tables for the spring to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter copied out a ledger of soundings past the lighthouse landing. Old farrow found the tide tables for the spring past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Wren promised me the tide tables for the spring past the bindery.

— Yours in haste, A.

## Letter 231

*Tuesday, from the bindery*

Rain came in sideways off the bar. Ines catalogued the subscription list to the bindery. You would have laughed; I nearly did. Ines promised me an index nobody had finished past the bindery. I begin to think a catalogue is only a polite way of remembering. The binder found a pamphlet on knots past the quay. The pilot's daughter promised me the harbourmaster's daybook by way of Saltmarsh Lane. The pilot's daughter carried a box of unsorted letters past Saltmarsh Lane. Teodor returned a water-stained atlas from the archive cellar.

Rain came in sideways off the bar. The pilot's daughter promised me a pamphlet on knots by way of the lighthouse landing. You would have laughed; I nearly did. The pilot's daughter promised me a ledger of soundings by way of the quay. Old farrow catalogued the second proof to the customs shed.

Wind from the east, and the shutters complaining. Dr okafor copied out a water-stained atlas to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. The binder promised me the second proof to the lighthouse landing. Ines wrapped a ledger of soundings past the ferry office. The pilot's daughter catalogued the harbourmaster's daybook from the lighthouse landing.

A still day, the water like poured lead. The binder promised me the harbourmaster's daybook past the bindery. I have copied the passage twice and still do not believe it. Wren found a pamphlet on knots by way of the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter returned a water-stained atlas past the ferry office.

— Ever, A.

## Letter 232

*Tuesday, from Saltmarsh Lane*

Wind from the east, and the shutters complaining. Mr calloway carried a parcel of marbled endpapers from Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Mr calloway returned the second proof to Gull Stairs. Teodor wrapped the harbourmaster's daybook to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Wren repaired a water-stained atlas from the bindery. The binder repaired the tide tables for the spring to the ferry office. Old farrow catalogued a pamphlet on knots from the quay.

A still day, the water like poured lead. Mr calloway wrapped the tide tables for the spring to the ferry office. You would have laughed; I nearly did. Wren found a ledger of soundings from the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired the harbourmaster's daybook to Saltmarsh Lane. Dr okafor mislaid a pamphlet on knots past the lower reading room. You would have laughed; I nearly did. Dr okafor repaired the second proof to the customs shed. The binder found a parcel of marbled endpapers past the lower reading room.

The tide was late and so was everyone else. Ines returned a parcel of marbled endpapers past the customs shed. I begin to think a catalogue is only a polite way of remembering. Mr calloway returned the second proof by way of the lighthouse landing. Old farrow copied out the tide tables for the spring past Saltmarsh Lane. Old farrow wrapped the harbourmaster's daybook by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me a box of unsorted letters by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Wren catalogued a water-stained atlas to Gull Stairs. Teodor found an index nobody had finished by way of the bindery. If the edition is to be trusted it must say what it changed. Teodor mislaid the harbourmaster's daybook to the lower reading room. Mr calloway mislaid the second proof past Saltmarsh Lane. Old farrow copied out the tide tables for the spring past the lighthouse landing. If the edition is to be trusted it must say what it changed. Wren catalogued the subscription list by way of the lighthouse landing.

— Yours, A.

## Letter 233

*Monday, from the lighthouse landing*

Wind from the east, and the shutters complaining. The binder mislaid a ledger of soundings to Gull Stairs. Dr okafor returned an index nobody had finished by way of the chandler's loft. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out a parcel of marbled endpapers past the customs shed. The pilot's daughter mislaid a parcel of marbled endpapers past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter found a ledger of soundings by way of the quay. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Wren carried the harbourmaster's daybook to Saltmarsh Lane. Mr calloway wrapped the harbourmaster's daybook to the customs shed. Wren carried the tide tables for the spring to the chandler's loft. I have copied the passage twice and still do not believe it. Dr okafor mislaid the tide tables for the spring by way of Saltmarsh Lane.

The fog stayed until noon. Teodor promised me a box of unsorted letters by way of the archive cellar. I begin to think a catalogue is only a polite way of remembering. The binder copied out the tide tables for the spring from the archive cellar. Ines found the harbourmaster's daybook from the lighthouse landing. If the edition is to be trusted it must say what it changed. Dr okafor mislaid the subscription list by way of the chandler's loft. Mr calloway wrapped a parcel of marbled endpapers to Gull Stairs. You would have laughed; I nearly did. The binder promised me a water-stained atlas by way of the lighthouse landing. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Dr okafor promised me a ledger of soundings from the lower reading room. Old farrow promised me a parcel of marbled endpapers to the archive cellar. Ines promised me a water-stained atlas by way of the quay. I have copied the passage twice and still do not believe it. Mr calloway returned a water-stained atlas to the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

— Ever, A.

## Letter 234

*Monday, from Gull Stairs*

Wind from the east, and the shutters complaining. Dr okafor wrapped an index nobody had finished to the quay. Teodor mislaid a water-stained atlas to the chandler's loft. Wren mislaid a ledger of soundings from the archive cellar. Old farrow wrapped a box of unsorted letters to the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. The binder copied out an index nobody had finished from the customs shed. Teodor carried a pamphlet on knots past the ferry office.

The fog stayed until noon. Mr calloway copied out the subscription list from the lighthouse landing. If the edition is to be trusted it must say what it changed. Mr calloway carried a water-stained atlas to the customs shed. Mr calloway promised me the harbourmaster's daybook to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway copied out the second proof from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter found a box of unsorted letters by way of the chandler's loft.

A still day, the water like poured lead. The binder promised me the second proof to the lighthouse landing. If the edition is to be trusted it must say what it changed. The binder copied out a water-stained atlas by way of the lower reading room. Old farrow mislaid a ledger of soundings by way of Gull Stairs. Wren catalogued the harbourmaster's daybook from the archive cellar. I begin to think a catalogue is only a polite way of remembering. Old farrow repaired the tide tables for the spring to the bindery. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Mr calloway found the second proof by way of the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. The binder found a box of unsorted letters past the customs shed. Mr calloway wrapped a water-stained atlas past the archive cellar. Mr calloway found the subscription list past the bindery. I have copied the passage twice and still do not believe it. The binder copied out the harbourmaster's daybook from the lower reading room.

It was the first clear morning in a week. The pilot's daughter carried a box of unsorted letters from the ferry office. Wren carried the tide tables for the spring to the lower reading room. I begin to think a catalogue is only a polite way of remembering. Wren returned the subscription list to the archive cellar. Teodor copied out a ledger of soundings past the bindery. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 235

*Monday, from the chandler's loft*

The tide was late and so was everyone else. The pilot's daughter promised me a parcel of marbled endpapers from the lower reading room. Dr okafor returned a parcel of marbled endpapers to the bindery. The pilot's daughter mislaid the second proof by way of the bindery. Ines returned a water-stained atlas to Gull Stairs.

It was the first clear morning in a week. Dr okafor wrapped the tide tables for the spring past the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter repaired a water-stained atlas past Saltmarsh Lane. Mr calloway returned the subscription list by way of the bindery. Wren found a water-stained atlas past Saltmarsh Lane. Old farrow mislaid a ledger of soundings from the quay. I have copied the passage twice and still do not believe it.

Wind from the east, and the shutters complaining. Dr okafor repaired a box of unsorted letters past the lower reading room. Teodor mislaid a parcel of marbled endpapers to the lighthouse landing. Teodor mislaid a ledger of soundings to the ferry office. I have copied the passage twice and still do not believe it. Dr okafor mislaid the subscription list by way of the lighthouse landing.

Wind from the east, and the shutters complaining. Wren wrapped a box of unsorted letters to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Teodor mislaid a box of unsorted letters past the bindery. You would have laughed; I nearly did. Mr calloway carried the tide tables for the spring by way of Gull Stairs. Wren mislaid the subscription list to the customs shed. Dr okafor found a box of unsorted letters from the lighthouse landing. I have copied the passage twice and still do not believe it. Mr calloway found the second proof from Saltmarsh Lane. You would have laughed; I nearly did.

— Yours in haste, A.

## Letter 236

*Thursday, from the ferry office*

The fog stayed until noon. Teodor returned the second proof to the lower reading room. The binder carried a box of unsorted letters by way of the lower reading room. Mr calloway carried a water-stained atlas from the quay. Wren repaired a water-stained atlas by way of the quay. I begin to think a catalogue is only a polite way of remembering. The binder promised me the tide tables for the spring by way of the bindery.

A still day, the water like poured lead. Ines found a box of unsorted letters from the chandler's loft. The pilot's daughter mislaid the subscription list by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Ines found a pamphlet on knots past the quay. I begin to think a catalogue is only a polite way of remembering. Mr calloway copied out a ledger of soundings from the customs shed. The binder copied out a box of unsorted letters past Saltmarsh Lane.

It was the first clear morning in a week. The binder returned a box of unsorted letters from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. The pilot's daughter wrapped a ledger of soundings by way of the ferry office. You would have laughed; I nearly did. The pilot's daughter found the harbourmaster's daybook past the chandler's loft. If the edition is to be trusted it must say what it changed. Mr calloway promised me the tide tables for the spring past the archive cellar. You would have laughed; I nearly did. The pilot's daughter catalogued a ledger of soundings from the ferry office.

— Yours in haste, A.

## Letter 237

*Wednesday, from Saltmarsh Lane*

Wind from the east, and the shutters complaining. Mr calloway catalogued a ledger of soundings to the lower reading room. The binder copied out a pamphlet on knots by way of the chandler's loft. The pilot's daughter found the tide tables for the spring by way of the lighthouse landing. If the edition is to be trusted it must say what it changed.

Wind from the east, and the shutters complaining. Mr calloway mislaid a water-stained atlas past the lighthouse landing. The pilot's daughter promised me a box of unsorted letters past the customs shed. Ines returned the second proof from the customs shed. The binder returned the harbourmaster's daybook to the ferry office. Wren mislaid an index nobody had finished to the bindery. I have copied the passage twice and still do not believe it. Dr okafor mislaid a ledger of soundings by way of the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Ines carried a box of unsorted letters to Gull Stairs. You would have laughed; I nearly did. Old farrow found the subscription list by way of the quay. The binder carried a parcel of marbled endpapers to the quay. Dr okafor returned an index nobody had finished past Saltmarsh Lane.

A still day, the water like poured lead. Old farrow found a pamphlet on knots past the archive cellar. Teodor repaired a ledger of soundings to the quay. The binder carried a box of unsorted letters past the lighthouse landing. Dr okafor wrapped a ledger of soundings past the quay. Old farrow catalogued the second proof to the quay.

— Yours, A.

## Letter 238

*Monday, from the ferry office*

It was the first clear morning in a week. Wren returned an index nobody had finished from the chandler's loft. Old farrow repaired the second proof to the ferry office. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter mislaid a water-stained atlas past the customs shed.

The tide was late and so was everyone else. Old farrow carried the harbourmaster's daybook by way of Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Wren catalogued the tide tables for the spring from the chandler's loft. Old farrow catalogued a parcel of marbled endpapers from the quay. Teodor copied out the second proof past the customs shed. If the edition is to be trusted it must say what it changed. The binder repaired a box of unsorted letters to the archive cellar. Wren repaired a pamphlet on knots to the lower reading room.

Wind from the east, and the shutters complaining. The binder mislaid an index nobody had finished from Saltmarsh Lane. You would have laughed; I nearly did. Teodor found a water-stained atlas to the archive cellar. Dr okafor wrapped a ledger of soundings to Gull Stairs. The pilot's daughter copied out a pamphlet on knots to the chandler's loft.

Wind from the east, and the shutters complaining. The binder returned a box of unsorted letters from the bindery. You would have laughed; I nearly did. Dr okafor carried the second proof to the ferry office. Dr okafor found a pamphlet on knots past the bindery. If the edition is to be trusted it must say what it changed. Old farrow carried an index nobody had finished past the lower reading room. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Dr okafor carried a box of unsorted letters by way of the chandler's loft. The pilot's daughter found a parcel of marbled endpapers by way of the quay. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter copied out the second proof by way of Saltmarsh Lane.

— With salt on the page, A.

## Letter 239

*Wednesday, from the customs shed*

The fog stayed until noon. Teodor repaired the harbourmaster's daybook to the customs shed. I have copied the passage twice and still do not believe it. Teodor promised me a water-stained atlas to Saltmarsh Lane. I have copied the passage twice and still do not believe it. Old farrow returned a box of unsorted letters by way of the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Wren promised me a pamphlet on knots from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait.

It was the first clear morning in a week. Old farrow copied out the subscription list to Gull Stairs. Teodor mislaid the subscription list to the archive cellar. Dr okafor wrapped an index nobody had finished to the quay. I begin to think a catalogue is only a polite way of remembering.

The tide was late and so was everyone else. The pilot's daughter promised me a water-stained atlas to the ferry office. The pilot's daughter found an index nobody had finished from the ferry office. Dr okafor mislaid the second proof past the customs shed. Dr okafor catalogued an index nobody had finished by way of the ferry office. Dr okafor mislaid a water-stained atlas by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow wrapped the harbourmaster's daybook by way of the quay. If the edition is to be trusted it must say what it changed.

— With salt on the page, A.

## Letter 240

*Friday, from Saltmarsh Lane*

Wind from the east, and the shutters complaining. Old farrow mislaid the tide tables for the spring past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor returned the harbourmaster's daybook by way of the chandler's loft. I have copied the passage twice and still do not believe it. Dr okafor repaired the second proof to the ferry office. Mr calloway copied out the subscription list from the chandler's loft. Wren promised me the subscription list by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. Teodor found the harbourmaster's daybook past the bindery.

Rain came in sideways off the bar. Old farrow returned an index nobody had finished to the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor carried the harbourmaster's daybook from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter returned the tide tables for the spring past Gull Stairs. Teodor carried the harbourmaster's daybook to Gull Stairs. Teodor carried the harbourmaster's daybook to the bindery.

It was the first clear morning in a week. Wren wrapped the second proof past the bindery. I have copied the passage twice and still do not believe it. The pilot's daughter promised me a water-stained atlas from the quay. Mr calloway wrapped an index nobody had finished to the quay. I have copied the passage twice and still do not believe it. Teodor catalogued a box of unsorted letters to the ferry office. Ines wrapped a box of unsorted letters past the customs shed.

Rain came in sideways off the bar. Mr calloway found the tide tables for the spring by way of the archive cellar. I begin to think a catalogue is only a polite way of remembering. Mr calloway found an index nobody had finished by way of the archive cellar. The pilot's daughter wrapped a water-stained atlas to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow found a box of unsorted letters by way of the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow mislaid the subscription list to the bindery. I begin to think a catalogue is only a polite way of remembering. Teodor copied out a ledger of soundings by way of the lighthouse landing. If the edition is to be trusted it must say what it changed.

A still day, the water like poured lead. Teodor copied out the harbourmaster's daybook from the chandler's loft. Ines carried the harbourmaster's daybook past the archive cellar. You would have laughed; I nearly did. Mr calloway carried a ledger of soundings by way of the lower reading room.

— Yours, A.

## Letter 241

*Monday, from Saltmarsh Lane*

It was the first clear morning in a week. The binder copied out the tide tables for the spring from the bindery. You would have laughed; I nearly did. Ines wrapped an index nobody had finished past the lower reading room. I begin to think a catalogue is only a polite way of remembering. Teodor carried a pamphlet on knots past Saltmarsh Lane. Dr okafor carried the tide tables for the spring to the quay.

Rain came in sideways off the bar. Ines found the tide tables for the spring to Saltmarsh Lane. Old farrow returned a parcel of marbled endpapers by way of Saltmarsh Lane. The pilot's daughter returned the tide tables for the spring to the quay. I have copied the passage twice and still do not believe it. Mr calloway wrapped the harbourmaster's daybook from the chandler's loft. You would have laughed; I nearly did. The binder carried the harbourmaster's daybook past Gull Stairs. Teodor carried a pamphlet on knots by way of the lighthouse landing. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Teodor carried an index nobody had finished to the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Wren carried a box of unsorted letters to the archive cellar. If the edition is to be trusted it must say what it changed. The pilot's daughter wrapped the harbourmaster's daybook to the ferry office.

— With salt on the page, A.

## Letter 242

*Friday, from Gull Stairs*

The tide was late and so was everyone else. Old farrow found the subscription list from the lighthouse landing. Ines carried a pamphlet on knots past the archive cellar. I begin to think a catalogue is only a polite way of remembering. Wren found the subscription list from the lower reading room. Wren promised me the subscription list past Gull Stairs. The pilot's daughter catalogued a pamphlet on knots to Gull Stairs. Mr calloway promised me a water-stained atlas past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Old farrow wrapped the subscription list by way of the lighthouse landing. Dr okafor found the tide tables for the spring by way of the lower reading room. Teodor promised me the subscription list from the bindery. The binder found a pamphlet on knots from the lighthouse landing. Mr calloway mislaid the tide tables for the spring to the ferry office. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Wren found the subscription list from the bindery. Dr okafor returned the harbourmaster's daybook by way of Saltmarsh Lane. I have copied the passage twice and still do not believe it. Mr calloway mislaid a water-stained atlas from the archive cellar. Mr calloway copied out the harbourmaster's daybook by way of the bindery. The pilot's daughter returned the tide tables for the spring past Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid a pamphlet on knots to Saltmarsh Lane.

The tide was late and so was everyone else. The pilot's daughter returned a box of unsorted letters to the customs shed. The binder copied out the second proof from the archive cellar. The pilot's daughter found a parcel of marbled endpapers from the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. The binder returned the tide tables for the spring past Gull Stairs. I have copied the passage twice and still do not believe it. Old farrow found the subscription list past the customs shed.

The tide was late and so was everyone else. The binder wrapped the tide tables for the spring to Gull Stairs. The binder catalogued the second proof to the chandler's loft. Mr calloway found a parcel of marbled endpapers from the customs shed. I begin to think a catalogue is only a polite way of remembering. Old farrow promised me the second proof past the archive cellar. Old farrow mislaid a parcel of marbled endpapers from Gull Stairs. The binder wrapped a ledger of soundings past the chandler's loft.

— Yours, A.

## Letter 243

*Tuesday, from the lighthouse landing*

The tide was late and so was everyone else. Teodor wrapped a parcel of marbled endpapers past the lower reading room. Wren wrapped a ledger of soundings from Gull Stairs. Teodor returned the subscription list past the lower reading room. You would have laughed; I nearly did. Wren promised me the second proof from the bindery. Old farrow mislaid the subscription list by way of Gull Stairs.

The tide was late and so was everyone else. Dr okafor found the harbourmaster's daybook by way of Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow carried a box of unsorted letters from the quay. Wren returned the second proof by way of the customs shed. The pilot's daughter promised me an index nobody had finished by way of the ferry office. I have copied the passage twice and still do not believe it. Mr calloway copied out a water-stained atlas from the ferry office.

The fog stayed until noon. Mr calloway carried the harbourmaster's daybook to the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor returned the subscription list to the lower reading room. The binder mislaid the second proof to the customs shed. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. Wren wrapped the tide tables for the spring by way of the customs shed. Wren mislaid the subscription list past the lower reading room. Wren returned a water-stained atlas to Saltmarsh Lane. Old farrow returned the second proof by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on.

The fog stayed until noon. Wren promised me the harbourmaster's daybook to the ferry office. Teodor returned an index nobody had finished by way of Gull Stairs. The binder mislaid a pamphlet on knots from the quay. You would have laughed; I nearly did.

— Ever, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 244

*Tuesday, from the lighthouse landing*

Wind from the east, and the shutters complaining. Wren carried a pamphlet on knots to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Ines returned a ledger of soundings to the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow promised me a box of unsorted letters from Gull Stairs.

The tide was late and so was everyone else. Dr okafor promised me a parcel of marbled endpapers to Gull Stairs. The binder mislaid an index nobody had finished from the customs shed. Ines promised me a water-stained atlas past the quay. I begin to think a catalogue is only a polite way of remembering. The binder carried the tide tables for the spring by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Wren carried a water-stained atlas from the quay. You would have laughed; I nearly did.

Rain came in sideways off the bar. Dr okafor catalogued a parcel of marbled endpapers past the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. Mr calloway promised me a water-stained atlas from the lighthouse landing. The binder catalogued the subscription list from the quay. I have copied the passage twice and still do not believe it. Wren returned a pamphlet on knots by way of the ferry office. You would have laughed; I nearly did. Wren repaired the subscription list from the archive cellar. Teodor repaired a water-stained atlas past the chandler's loft.

The fog stayed until noon. Ines mislaid the tide tables for the spring from the lower reading room. Mr calloway carried a pamphlet on knots by way of the bindery. Wren found the subscription list past the lighthouse landing. You would have laughed; I nearly did.

A still day, the water like poured lead. Mr calloway found a ledger of soundings past the lighthouse landing. Teodor repaired a box of unsorted letters from Saltmarsh Lane. The pilot's daughter wrapped a pamphlet on knots from the archive cellar. We agreed that the index should wait until the letters were in order, and then did not wait. The binder repaired a box of unsorted letters to Gull Stairs. I have copied the passage twice and still do not believe it.

— Ever, A.

## Letter 245

*Monday, from the ferry office*

A still day, the water like poured lead. Mr calloway mislaid a box of unsorted letters by way of the quay. Old farrow wrapped a water-stained atlas past the lower reading room. Nobody warns you how much of a book is the paper it happens to be printed on. Old farrow repaired the second proof past Gull Stairs. You would have laughed; I nearly did. Wren found a parcel of marbled endpapers from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor copied out an index nobody had finished by way of the customs shed.

The fog stayed until noon. Wren promised me the tide tables for the spring by way of the lighthouse landing. Teodor copied out a parcel of marbled endpapers by way of Saltmarsh Lane. Old farrow copied out a ledger of soundings by way of Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. The pilot's daughter returned an index nobody had finished by way of the bindery. I have copied the passage twice and still do not believe it.

Rain came in sideways off the bar. Teodor wrapped an index nobody had finished from the lighthouse landing. The binder returned the subscription list from the ferry office. The binder repaired the tide tables for the spring to the lighthouse landing. Ines promised me the tide tables for the spring from the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Mr calloway carried a pamphlet on knots to the quay. Ines catalogued the harbourmaster's daybook to the archive cellar.

— Yours in haste, A.

## Letter 246

*Monday, from the lower reading room*

The tide was late and so was everyone else. Dr okafor carried the second proof from the lower reading room. I have copied the passage twice and still do not believe it. Wren found a water-stained atlas from Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Mr calloway promised me the tide tables for the spring from the lighthouse landing. Mr calloway returned a water-stained atlas by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait.

The tide was late and so was everyone else. Wren promised me the subscription list from the archive cellar. Dr okafor promised me the subscription list past Gull Stairs. Dr okafor promised me an index nobody had finished by way of the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Dr okafor mislaid the second proof to the lighthouse landing. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. The binder found the second proof from the bindery. Old farrow mislaid the subscription list to Gull Stairs. The binder catalogued a box of unsorted letters past the lighthouse landing. You would have laughed; I nearly did. Old farrow catalogued a ledger of soundings to the lighthouse landing. I have copied the passage twice and still do not believe it.

The tide was late and so was everyone else. The pilot's daughter carried an index nobody had finished to the lower reading room. Teodor repaired the tide tables for the spring to Saltmarsh Lane. Dr okafor wrapped a pamphlet on knots from Gull Stairs. Teodor wrapped the subscription list by way of the quay. Old farrow copied out an index nobody had finished past the lighthouse landing. Teodor returned a box of unsorted letters to the customs shed. If the edition is to be trusted it must say what it changed.

— Yours in haste, A.

## Letter 247

*Monday, from the lower reading room*

It was the first clear morning in a week. Dr okafor copied out the second proof to Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. The binder catalogued the second proof past Saltmarsh Lane. Old farrow repaired the harbourmaster's daybook past the archive cellar.

Wind from the east, and the shutters complaining. Dr okafor found the second proof past the ferry office. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter promised me the tide tables for the spring past the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor copied out the second proof past the lighthouse landing. Dr okafor returned an index nobody had finished by way of the ferry office. Ines carried a ledger of soundings to Saltmarsh Lane. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. The binder promised me the second proof past the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait. Ines mislaid the second proof from the quay. You would have laughed; I nearly did. Ines returned the second proof from the lighthouse landing. The pilot's daughter copied out the tide tables for the spring past the ferry office.

— Yours in haste, A.

## Letter 248

*Wednesday, from the quay*

It was the first clear morning in a week. The binder wrapped a pamphlet on knots from the bindery. I have copied the passage twice and still do not believe it. Ines carried the second proof from the bindery. Ines repaired the harbourmaster's daybook by way of the archive cellar.

It was the first clear morning in a week. Mr calloway carried the subscription list to the customs shed. Ines mislaid a water-stained atlas past the bindery. I have copied the passage twice and still do not believe it. Old farrow catalogued the tide tables for the spring past the bindery. Dr okafor catalogued the subscription list past the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on.

Rain came in sideways off the bar. Teodor promised me the tide tables for the spring to Saltmarsh Lane. Dr okafor repaired the harbourmaster's daybook to the lighthouse landing. You would have laughed; I nearly did. Ines catalogued a ledger of soundings to Saltmarsh Lane.

— With salt on the page, A.

## Letter 249

*Thursday, from Gull Stairs*

It was the first clear morning in a week. Mr calloway mislaid the tide tables for the spring to the customs shed. Dr okafor mislaid a box of unsorted letters by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Teodor promised me the second proof by way of the customs shed. You would have laughed; I nearly did. Teodor carried a pamphlet on knots from the quay. If the edition is to be trusted it must say what it changed. The binder returned the harbourmaster's daybook past the customs shed.

A still day, the water like poured lead. Old farrow carried a box of unsorted letters from the lighthouse landing. The pilot's daughter found a ledger of soundings by way of the lower reading room. Old farrow catalogued the tide tables for the spring to Gull Stairs. Old farrow carried a parcel of marbled endpapers past Gull Stairs.

It was the first clear morning in a week. Mr calloway returned the harbourmaster's daybook by way of the bindery. The pilot's daughter promised me a box of unsorted letters to Saltmarsh Lane. You would have laughed; I nearly did. Wren carried an index nobody had finished from the ferry office. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Old farrow repaired a box of unsorted letters to the ferry office. I have copied the passage twice and still do not believe it. Old farrow found the tide tables for the spring from the lighthouse landing. You would have laughed; I nearly did. Old farrow catalogued a parcel of marbled endpapers past the lower reading room. Teodor mislaid a ledger of soundings from the bindery. I have copied the passage twice and still do not believe it. Old farrow returned the second proof to the customs shed. Nobody warns you how much of a book is the paper it happens to be printed on.

The tide was late and so was everyone else. Dr okafor repaired an index nobody had finished to the ferry office. Old farrow repaired a water-stained atlas to the bindery. I begin to think a catalogue is only a polite way of remembering. The pilot's daughter returned a pamphlet on knots to the bindery. You would have laughed; I nearly did. Old farrow carried a ledger of soundings past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor wrapped a box of unsorted letters to Gull Stairs. Old farrow copied out a parcel of marbled endpapers by way of the quay. Nobody warns you how much of a book is the paper it happens to be printed on.

— With salt on the page, A.

## Letter 250

*Monday, from the chandler's loft*

A still day, the water like poured lead. Mr calloway repaired the harbourmaster's daybook to the bindery. I have copied the passage twice and still do not believe it. Teodor repaired a box of unsorted letters by way of Gull Stairs. The pilot's daughter copied out a parcel of marbled endpapers from the lower reading room. Wren repaired a pamphlet on knots by way of the customs shed. If the edition is to be trusted it must say what it changed. The pilot's daughter catalogued the subscription list by way of the quay.

A still day, the water like poured lead. Dr okafor carried a water-stained atlas past the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor repaired a pamphlet on knots by way of the ferry office. Mr calloway found a box of unsorted letters by way of the ferry office. I begin to think a catalogue is only a polite way of remembering. Ines repaired the harbourmaster's daybook from the customs shed. I have copied the passage twice and still do not believe it. Old farrow copied out the second proof from the lower reading room. I begin to think a catalogue is only a polite way of remembering. Wren found the second proof past the quay. I have copied the passage twice and still do not believe it.

Wind from the east, and the shutters complaining. Wren mislaid the tide tables for the spring to the lower reading room. If the edition is to be trusted it must say what it changed. Wren carried the harbourmaster's daybook by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Dr okafor copied out an index nobody had finished to Gull Stairs. Mr calloway catalogued the tide tables for the spring past the lower reading room.

— With salt on the page, A.

## Letter 251

*Wednesday, from the bindery*

Rain came in sideways off the bar. The pilot's daughter repaired a parcel of marbled endpapers past the lower reading room. You would have laughed; I nearly did. Teodor repaired a ledger of soundings past the lighthouse landing. Old farrow copied out the subscription list by way of Saltmarsh Lane. Mr calloway mislaid a pamphlet on knots to the bindery. You would have laughed; I nearly did.

The fog stayed until noon. Teodor copied out a ledger of soundings by way of the customs shed. If the edition is to be trusted it must say what it changed. Teodor mislaid a ledger of soundings past Saltmarsh Lane. Mr calloway returned a pamphlet on knots by way of the ferry office. You would have laughed; I nearly did.

Wind from the east, and the shutters complaining. Mr calloway mislaid the second proof to the quay. You would have laughed; I nearly did. Wren carried a water-stained atlas from the chandler's loft. Old farrow catalogued a box of unsorted letters to the archive cellar. The binder copied out the second proof from the lighthouse landing. You would have laughed; I nearly did. Ines returned the second proof from the ferry office.

— Yours, A.

## Letter 252

*Thursday, from the lighthouse landing*

Rain came in sideways off the bar. Mr calloway catalogued the tide tables for the spring past the quay. Nobody warns you how much of a book is the paper it happens to be printed on. Wren copied out a parcel of marbled endpapers to the bindery. Dr okafor repaired an index nobody had finished to the customs shed.

It was the first clear morning in a week. Dr okafor repaired a water-stained atlas to the customs shed. You would have laughed; I nearly did. The pilot's daughter carried the tide tables for the spring from the lighthouse landing. You would have laughed; I nearly did. The binder copied out the tide tables for the spring past the bindery. If the edition is to be trusted it must say what it changed. Dr okafor repaired the harbourmaster's daybook past the chandler's loft. I begin to think a catalogue is only a polite way of remembering.

Rain came in sideways off the bar. Dr okafor carried a parcel of marbled endpapers by way of the bindery. I have copied the passage twice and still do not believe it. Dr okafor returned a box of unsorted letters by way of the chandler's loft. If the edition is to be trusted it must say what it changed. Dr okafor found a parcel of marbled endpapers from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor carried a water-stained atlas by way of the quay. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor mislaid a water-stained atlas by way of Gull Stairs. I begin to think a catalogue is only a polite way of remembering. Dr okafor found a water-stained atlas from the quay.

The fog stayed until noon. Teodor found a water-stained atlas from the quay. Dr okafor repaired a box of unsorted letters by way of the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor copied out an index nobody had finished to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. The binder repaired a box of unsorted letters past the chandler's loft. If the edition is to be trusted it must say what it changed. Mr calloway carried a ledger of soundings by way of Gull Stairs. Dr okafor carried the second proof from the customs shed.

— Ever, A.

> [private note to self: check this date against the daybook before anyone sees it]

## Letter 253

*Tuesday, from the bindery*

The tide was late and so was everyone else. Teodor wrapped the subscription list by way of Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. Wren found the harbourmaster's daybook to the chandler's loft. Mr calloway wrapped the second proof to the quay. Ines copied out the second proof from the archive cellar. Dr okafor carried a ledger of soundings to the ferry office.

The tide was late and so was everyone else. Dr okafor found the subscription list to the bindery. The binder wrapped a box of unsorted letters past the bindery. Wren copied out a water-stained atlas past Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Dr okafor catalogued the subscription list past the ferry office. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor wrapped an index nobody had finished to the chandler's loft. The binder returned the harbourmaster's daybook to the lighthouse landing. We agreed that the index should wait until the letters were in order, and then did not wait.

A still day, the water like poured lead. Teodor found the harbourmaster's daybook by way of the bindery. Ines repaired an index nobody had finished by way of the customs shed. The pilot's daughter wrapped a ledger of soundings past Gull Stairs. Old farrow returned a ledger of soundings to the ferry office. I begin to think a catalogue is only a polite way of remembering. Dr okafor returned the tide tables for the spring past Saltmarsh Lane. I have copied the passage twice and still do not believe it.

It was the first clear morning in a week. The pilot's daughter copied out the harbourmaster's daybook from the lower reading room. The pilot's daughter promised me a parcel of marbled endpapers from the chandler's loft. Dr okafor copied out the second proof to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. The pilot's daughter copied out the tide tables for the spring by way of Gull Stairs. Wren mislaid the subscription list to Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours, A.

## Letter 254

*Friday, from the ferry office*

A still day, the water like poured lead. Wren copied out the tide tables for the spring to the lower reading room. Mr calloway mislaid the harbourmaster's daybook by way of the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor copied out the harbourmaster's daybook from the lighthouse landing.

Wind from the east, and the shutters complaining. The pilot's daughter found the second proof past the archive cellar. Mr calloway catalogued a box of unsorted letters from the lighthouse landing. You would have laughed; I nearly did. Ines repaired a ledger of soundings from the archive cellar. Mr calloway returned the subscription list to Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Wren copied out an index nobody had finished to Gull Stairs. Wren promised me a ledger of soundings by way of Saltmarsh Lane.

The tide was late and so was everyone else. Wren wrapped the second proof past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait. Teodor mislaid a pamphlet on knots from the bindery. We agreed that the index should wait until the letters were in order, and then did not wait. The binder wrapped the tide tables for the spring to the ferry office. Nobody warns you how much of a book is the paper it happens to be printed on. Wren repaired the harbourmaster's daybook past the lower reading room. Wren mislaid a pamphlet on knots to Gull Stairs. Nobody warns you how much of a book is the paper it happens to be printed on. Wren repaired an index nobody had finished to the lighthouse landing.

— Yours in haste, A.

## Letter 255

*Monday, from the archive cellar*

It was the first clear morning in a week. Wren found the harbourmaster's daybook to the chandler's loft. I have copied the passage twice and still do not believe it. Teodor found a parcel of marbled endpapers past the lighthouse landing. Ines repaired a box of unsorted letters by way of the bindery. If the edition is to be trusted it must say what it changed.

The fog stayed until noon. Ines carried the second proof to the chandler's loft. If the edition is to be trusted it must say what it changed. Mr calloway catalogued the tide tables for the spring to the quay. The pilot's daughter carried the second proof from the quay. Nobody warns you how much of a book is the paper it happens to be printed on. The binder found a parcel of marbled endpapers to the archive cellar. Old farrow found a water-stained atlas to the ferry office.

Rain came in sideways off the bar. Mr calloway promised me the second proof by way of the lighthouse landing. Mr calloway promised me the harbourmaster's daybook past Gull Stairs. Old farrow repaired a water-stained atlas by way of the lighthouse landing. I begin to think a catalogue is only a polite way of remembering. Ines found a water-stained atlas past the bindery.

Wind from the east, and the shutters complaining. The pilot's daughter returned the second proof by way of the chandler's loft. Old farrow returned the subscription list past the bindery. Ines catalogued the second proof to Gull Stairs. The pilot's daughter repaired a water-stained atlas past the customs shed. Wren wrapped a pamphlet on knots from the archive cellar.

— Ever, A.

## Letter 256

*Thursday, from the lighthouse landing*

Rain came in sideways off the bar. Ines promised me a parcel of marbled endpapers to Saltmarsh Lane. If the edition is to be trusted it must say what it changed. Old farrow returned a parcel of marbled endpapers to Saltmarsh Lane. The pilot's daughter promised me the second proof from the lighthouse landing. Ines repaired a parcel of marbled endpapers to the archive cellar. The pilot's daughter repaired a pamphlet on knots to the archive cellar.

A still day, the water like poured lead. The binder copied out the subscription list past the archive cellar. Wren found a pamphlet on knots from the quay. Old farrow found the harbourmaster's daybook past the bindery. Teodor returned the subscription list by way of the chandler's loft. Mr calloway wrapped a box of unsorted letters to the customs shed. I begin to think a catalogue is only a polite way of remembering.

The fog stayed until noon. The pilot's daughter wrapped the second proof from Gull Stairs. Mr calloway carried a parcel of marbled endpapers by way of the bindery. Ines copied out the subscription list to the bindery. The binder mislaid a parcel of marbled endpapers past the ferry office. If the edition is to be trusted it must say what it changed.

— With salt on the page, A.

## Letter 257

*Friday, from the lighthouse landing*

A still day, the water like poured lead. Dr okafor returned a parcel of marbled endpapers from the ferry office. Ines copied out a water-stained atlas to the ferry office. Wren wrapped a pamphlet on knots by way of the chandler's loft. We agreed that the index should wait until the letters were in order, and then did not wait. Wren promised me a ledger of soundings to the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Wren wrapped a parcel of marbled endpapers by way of the customs shed. I begin to think a catalogue is only a polite way of remembering. Ines found a parcel of marbled endpapers to the chandler's loft.

The tide was late and so was everyone else. Teodor found a box of unsorted letters to the lower reading room. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow found the harbourmaster's daybook by way of the quay. Teodor promised me a parcel of marbled endpapers by way of the ferry office. I have copied the passage twice and still do not believe it.

A still day, the water like poured lead. Mr calloway carried a ledger of soundings to the ferry office. If the edition is to be trusted it must say what it changed. The pilot's daughter promised me the tide tables for the spring from the archive cellar. Mr calloway copied out an index nobody had finished to the lower reading room. I have copied the passage twice and still do not believe it. Mr calloway repaired a ledger of soundings past the lower reading room. The pilot's daughter returned a pamphlet on knots to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. The binder wrapped the subscription list by way of the archive cellar. You would have laughed; I nearly did.

— Ever, A.

## Letter 258

*Monday, from the archive cellar*

It was the first clear morning in a week. The pilot's daughter found a water-stained atlas by way of the archive cellar. If the edition is to be trusted it must say what it changed. The pilot's daughter found the tide tables for the spring by way of the quay. The binder promised me an index nobody had finished by way of the archive cellar. You would have laughed; I nearly did. Old farrow returned a box of unsorted letters past Gull Stairs.

Wind from the east, and the shutters complaining. Ines repaired a ledger of soundings past the archive cellar. Ines returned the harbourmaster's daybook past the customs shed. You would have laughed; I nearly did. Ines promised me the second proof past the ferry office.

It was the first clear morning in a week. Teodor repaired a pamphlet on knots to the bindery. Mr calloway returned a parcel of marbled endpapers from Saltmarsh Lane. We agreed that the index should wait until the letters were in order, and then did not wait. The binder repaired a water-stained atlas from Gull Stairs. Ines wrapped a ledger of soundings from Gull Stairs. Dr okafor copied out a box of unsorted letters past the bindery.

The fog stayed until noon. The pilot's daughter mislaid the tide tables for the spring by way of Saltmarsh Lane. I begin to think a catalogue is only a polite way of remembering. Wren carried the tide tables for the spring past the archive cellar. You would have laughed; I nearly did. Wren mislaid the tide tables for the spring from the ferry office. You would have laughed; I nearly did. The pilot's daughter carried the second proof from the chandler's loft. The binder wrapped a water-stained atlas by way of Gull Stairs. If the edition is to be trusted it must say what it changed. The pilot's daughter carried a ledger of soundings to the chandler's loft.

It was the first clear morning in a week. Teodor returned the tide tables for the spring by way of the lighthouse landing. Teodor promised me a box of unsorted letters by way of the archive cellar. Old farrow copied out a box of unsorted letters past the chandler's loft. Nobody warns you how much of a book is the paper it happens to be printed on. The binder returned a box of unsorted letters by way of the bindery. We agreed that the index should wait until the letters were in order, and then did not wait.

— Yours in haste, A.

## Letter 259

*Thursday, from the customs shed*

It was the first clear morning in a week. Wren catalogued a pamphlet on knots by way of the ferry office. Old farrow catalogued the harbourmaster's daybook to Saltmarsh Lane. The pilot's daughter catalogued a ledger of soundings by way of the customs shed. You would have laughed; I nearly did.

The fog stayed until noon. Dr okafor promised me a pamphlet on knots from Saltmarsh Lane. You would have laughed; I nearly did. The pilot's daughter found an index nobody had finished by way of the ferry office. Mr calloway returned a pamphlet on knots by way of Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Old farrow promised me a ledger of soundings to Gull Stairs. If the edition is to be trusted it must say what it changed.

The tide was late and so was everyone else. Wren catalogued the subscription list from the lighthouse landing. I have copied the passage twice and still do not believe it. Dr okafor wrapped the second proof by way of the archive cellar. Wren copied out a pamphlet on knots past the chandler's loft. If the edition is to be trusted it must say what it changed. Teodor promised me a parcel of marbled endpapers by way of the archive cellar. Wren carried the tide tables for the spring to the customs shed.

— Ever, A.

## Letter 260

*Monday, from the lighthouse landing*

Rain came in sideways off the bar. Ines promised me the harbourmaster's daybook from Gull Stairs. If the edition is to be trusted it must say what it changed. Ines promised me a water-stained atlas by way of Gull Stairs. I have copied the passage twice and still do not believe it. Ines carried a ledger of soundings from the chandler's loft. Dr okafor found a box of unsorted letters by way of Gull Stairs. The pilot's daughter mislaid a parcel of marbled endpapers past the customs shed. We agreed that the index should wait until the letters were in order, and then did not wait.

Rain came in sideways off the bar. Old farrow returned the second proof from Gull Stairs. I have copied the passage twice and still do not believe it. Teodor catalogued a pamphlet on knots from the bindery. I begin to think a catalogue is only a polite way of remembering. Old farrow carried the harbourmaster's daybook past the ferry office. Ines wrapped a pamphlet on knots by way of the lower reading room. You would have laughed; I nearly did.

A still day, the water like poured lead. Dr okafor promised me the harbourmaster's daybook by way of the quay. Mr calloway repaired a box of unsorted letters past the bindery. The pilot's daughter mislaid the second proof by way of the lower reading room. I begin to think a catalogue is only a polite way of remembering. Mr calloway repaired a water-stained atlas past the customs shed. Teodor carried the harbourmaster's daybook from the archive cellar. Nobody warns you how much of a book is the paper it happens to be printed on. The binder mislaid an index nobody had finished past Gull Stairs.

A still day, the water like poured lead. Teodor wrapped a parcel of marbled endpapers by way of the lower reading room. Mr calloway promised me a pamphlet on knots past the quay. Ines returned the second proof by way of the archive cellar. Teodor catalogued a pamphlet on knots by way of the lower reading room. The pilot's daughter wrapped the second proof to the quay. Mr calloway returned the harbourmaster's daybook to the lower reading room.

The tide was late and so was everyone else. Teodor carried an index nobody had finished from Gull Stairs. We agreed that the index should wait until the letters were in order, and then did not wait. Dr okafor carried a box of unsorted letters to the bindery. Nobody warns you how much of a book is the paper it happens to be printed on. Wren returned the harbourmaster's daybook to the customs shed. I begin to think a catalogue is only a polite way of remembering. Dr okafor found a ledger of soundings past the lighthouse landing. Nobody warns you how much of a book is the paper it happens to be printed on. Teodor mislaid the subscription list by way of the archive cellar. Wren found the second proof to the quay.

— Ever, A.
