"""Drives the desktop interface's own actions off-screen — the same methods
the buttons call — with dialogs answered programmatically.  Any exception or
unexpected error toast fails the test."""
import os
import time

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtGui import QTextCursor  # noqa: E402
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox  # noqa: E402

from aureom.apps.desktop import pages_library, pages_publish, pages_settings, pages_sharing, reader as reader_mod  # noqa: E402
from aureom.apps.desktop.main_window import MainWindow  # noqa: E402
from tests.conftest import CORRECTED, EPUB, FAST_KDF, FIRST, FIX, MANUSCRIPT, PDF, call  # noqa: E402
from tests.unit.test_reading_annotations_publishing import _published  # noqa: E402


@pytest.fixture
def desk(make, tmp_path, monkeypatch):
    app = QApplication.instance() or QApplication([])
    alice, ben = make("alice", start=True), make("ben", start=True)
    answers: dict[str, dict] = {}
    files = {"open": "", "save": "", "dir": str(tmp_path)}
    captured, errors = [], []

    def fake_form(_parent, title, fields, **_kw):
        out = {f[0]: f[3] for f in fields}
        out.update(answers.get(title, {}))
        return out

    for module in (pages_library, pages_sharing, pages_publish, pages_settings, reader_mod):
        monkeypatch.setattr(module, "form_dialog", fake_form)
        if hasattr(module, "review_dialog"):
            monkeypatch.setattr(module, "review_dialog", lambda *a, **k: True)
    monkeypatch.setattr(pages_sharing, "show_invitation", lambda _p, inv, _w: captured.append(inv))
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (files["open"], ""))
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: ([files["open"]], ""))
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (files["save"], ""))
    monkeypatch.setattr(QFileDialog, "getExistingDirectory", lambda *a, **k: files["dir"])
    monkeypatch.setattr(reader_mod.QDesktopServices, "openUrl", lambda url: captured.append(url))
    window = MainWindow(alice)
    original = window.toast
    monkeypatch.setattr(window, "toast", lambda msg, error=False: (errors.append(msg) if error else None, original(msg, error))[1])
    window.show()

    def pump(condition=lambda: False, timeout=20.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            app.processEvents()
            if condition():
                return
            time.sleep(0.02)
        if condition is not pump.__defaults__[0]:
            raise AssertionError("interface did not reach the expected state; errors: " + repr(errors))

    yield type("Desk", (), dict(app=app, alice=alice, ben=ben, window=window, answers=answers, files=files,
                                captured=captured, errors=errors, pump=staticmethod(pump), tmp=tmp_path))
    window.pages["Reading Room"].close_current()
    monkeypatch.setattr(alice, "close", lambda: None)        # the profile itself is closed by the `make` fixture
    window.close()
    app.processEvents()


def test_library_collections_peers_and_reader_actions(desk):
    w, alice, ben, pages = desk.window, desk.alice, desk.ben, desk.window.pages
    w.import_paths([str(FIX)])
    desk.pump(lambda: len(alice.catalogue.list()) == 11)
    lib = pages["Library"]
    w.go("Library")
    by_file = {v["filename"]: v["edition_id"] for v in alice.catalogue.list()}
    epub, first = by_file[EPUB.name], by_file[FIRST.name]
    lib.selected = epub
    desk.answers["Edit details"] = {"title": "The Lantern Archive (my copy)", "tags": "essays; libraries"}
    lib.edit_metadata()
    assert alice.catalogue.effective_metadata(epub).tags == ["essays", "libraries"]
    assert alice.catalogue.metadata_layers(epub)["imported"]["title"] == "The Lantern Archive"
    desk.answers["Search indexing for this document"] = {"mode": "metadata"}
    lib.set_index_mode()
    assert alice.catalogue.edition_view(epub)["index_mode"] == "metadata"
    lib.toggle_view(); lib.set_query("lantern"); lib.reload(); lib.set_query("")          # noqa: E702
    lib.export()
    assert (desk.tmp / EPUB.name).read_bytes() == EPUB.read_bytes()

    # collections: create → add → preview → invitation → member → permissions → revoke
    col = pages["Collections"]
    w.go("Collections")
    desk.answers["New collection"] = {"name": "Reading circle", "kind": "shared"}
    col.create()
    cid = col.cid
    desk.answers["Add a work"] = {"eid": epub}
    col.add_work()
    desk.answers["Invite to collection"] = {"who": "", "preset": "contributor"}
    col.invite()
    invitation = desk.captured.pop()
    assert invitation.collection.permissions == ["view_metadata", "download", "add_works", "share_annotations"]
    call(ben, ben.node.accept_invitation(invitation.to_text()))
    desk.pump(lambda: col.members.rowCount() == 1)
    assert alice.catalogue.edition_view(epub)["visibility"] == "shared"
    col.tabs.setCurrentIndex(1)
    col.members.selectRow(0)
    desk.answers["Change permissions"] = {"preset": "reader"}
    col.change_permissions()
    assert alice.collections.members(cid)[0]["permissions"] == ["view_metadata", "download"]
    col.members.selectRow(0)
    col.revoke()
    assert alice.collections.members(cid)[0]["status"] == "revoked" and "cannot erase copies" in w.toast_label.text()
    col.rename(); col.check_shared(); desk.pump(timeout=0.5)                               # noqa: E702

    # peers: invitations, verification, public catalogue of another peer
    peers = pages["Peers"]
    w.go("Peers")
    peers.new_invitation("pair")
    assert desk.captured.pop().purpose == "pair"
    peers.peers.selectRow(0)
    peers.verify()
    assert alice.identity.peers()[0]["verified"] == 1
    peers.peers.selectRow(0)
    desk.answers["Device settings"] = {"alias": "Ben (book club)", "limit": 512}
    peers.edit_peer()
    assert alice.identity.peers()[0]["display_name"] == "Ben (book club)"
    pub, _ = _published(ben)
    peers.address.setText(ben.node.advertised_addresses()[0])
    peers.fetch_public()
    desk.pump(lambda: peers.pubs.rowCount() == 1)
    peers.pubs.selectRow(0)
    desk.app.processEvents()
    assert "does not prove who holds the key" in peers.pub_detail.toPlainText()
    assert "verified" not in peers.pub_detail.toPlainText().lower()
    peers.pin_publisher(); peers.download_public()                                         # noqa: E702
    desk.pump(lambda: bool(alice.catalogue.list(space="public")) and alice.catalogue.list(space="public")[0]["availability"] == "local")
    peers.pubs.selectRow(0); peers.mirror(); peers.rotate()                                # noqa: E702
    desk.pump(lambda: alice.identity.previous_device is None)

    # reading room: every format, annotations, find, progress
    reader = pages["Reading Room"]
    for name, kind in ((EPUB.name, "text"), (MANUSCRIPT.name, "text"), (PDF.name, "pdf"), ("harbour-chart.svg", "image"),
                       ("harbour-chart.png", "image"), ("tide-bell.wav", "audio")):
        w.open_reader(by_file[name])
        desk.app.processEvents()
        assert reader.kind == kind, name
        reader.add_bookmark(); reader.step(1); reader.resize_text(1)                       # noqa: E702
    w.open_reader(epub)
    reader.goto(3)
    cursor = reader.text.document().find("Compare the fingerprints aloud.")
    assert not cursor.isNull()
    reader.text.setTextCursor(cursor)
    reader.add_highlight()
    reader.text.setTextCursor(cursor)
    desk.answers["Private note"] = {"body": "Read this aloud."}
    reader.add_note()
    notes = alice.annotations.list(epub)
    assert {a["kind"] for a in notes} >= {"highlight", "note", "bookmark"} and all(a["private"] for a in notes)
    assert any(a["locator"].get("quote") == "Compare the fingerprints aloud." for a in notes)
    assert len(reader.text.extraSelections()) == 2                                         # painted in the document
    reader.find.setText("subscription"); reader.find_next()                                # noqa: E702
    assert reader.section == 5 and reader.text.textCursor().selectedText() == "subscription"
    reader.notes.setCurrentRow(reader.notes.count() - 1)
    desk.answers["Edit annotation"] = {"body": "edited"}
    reader.edit_note(); reader.notes.setCurrentRow(0); reader.delete_note()                # noqa: E702
    reader.set_reading_theme("dark"); reader.save_progress()                               # noqa: E702
    assert alice.annotations.progress(epub)["this_device"]["fraction"] > 0.5
    junk = desk.tmp / "ledger.bin"
    junk.write_bytes(bytes(range(256)) * 20)
    w.open_reader(alice.catalogue.import_file(junk).edition_id)
    assert reader.kind == "unsupported" and "No built-in reader" in reader.empty.text()
    reader.open_external()                                                                 # explicit, confirmed
    assert desk.captured and desk.captured[-1].isLocalFile()
    w.toggle_theme(); w.scale_text(10); w.go("Home"); w.go("Activity"); w.go("Transfers")  # noqa: E702
    pages["Transfers"].act("pause")
    w.toggle_network()
    desk.pump(lambda: alice.node.status()["mode"] == "offline" and "Offline" in w.status.text())   # always shown
    w.open_reader(epub)                                                                    # reading still works offline
    assert reader.kind == "text"
    w.toggle_network()
    desk.pump(lambda: alice.node.status()["mode"] == "direct" and "Direct" in w.status.text())
    assert desk.errors == [], desk.errors


def test_publish_workflow_and_settings_actions(desk):
    w, alice, pages = desk.window, desk.alice, desk.window.pages
    first = alice.catalogue.import_file(FIRST).edition_id
    publish = pages["Publish"]
    desk.answers["New publisher identity"] = {"name": "Saltmarsh Press"}
    publish.new_imprint()
    publish.start_draft(first)
    pid = publish.pid
    desk.answers["Publication package"] = {"edition_label": "First edition", "subjects": "letters; sea",
                                           "publisher": alice.identity.publishers()[0]["publisher_id"]}
    publish.edit()
    assert alice.publishing.get(pid)["package"]["subjects"] == ["letters", "sea"]
    publish.publish()                                           # too early: must be refused, nothing public
    desk.pump(timeout=0.5)
    assert alice.publishing.get(pid)["state"] == "draft" and desk.errors
    desk.errors.clear()
    publish.preview()
    desk.answers["Rights review"] = {"licence_confirmed": True, "no_private_material": True, "understands_permanence": True}
    publish.rights()
    publish.publish()
    desk.pump(lambda: alice.publishing.get(pid)["state"] == "published" and "Published." in w.toast_label.text())
    assert alice.publishing.get(pid)["manifest"]["signature"] and alice.catalogue.edition_view(first)["visibility"] == "public"
    desk.files["open"] = str(CORRECTED)
    desk.answers["New edition"] = {"label": "Corrected edition", "notes": "Fixed two typos."}
    publish.revise()
    assert publish.pid != pid and alice.publishing.get(publish.pid)["state"] == "draft"
    publish.announce()                                          # no index configured: explains, does nothing
    publish._select(pid)
    publish.withdraw()
    desk.pump(lambda: alice.publishing.get(pid)["state"] == "withdrawn")
    assert "may persist" in w.toast_label.text()

    settings = pages["Settings"]
    w.go("Settings")
    desk.answers["Names"] = {"device_name": "Study laptop"}
    settings.edit_names()
    assert "Study laptop" in w.nav_foot.text()
    desk.answers["Resource limits"] = {"max_concurrent_transfers": "2"}
    settings.edit_limits()
    assert alice.settings.limits.max_concurrent_transfers == 2
    desk.answers["Resource limits"] = {"chunk_size": "12"}
    settings.edit_limits()                                      # invalid value is rejected, not saved
    assert alice.settings.limits.chunk_size == 16 * 1024 and desk.errors.pop()
    settings.edit_defaults()
    desk.answers["Network"] = {"lan_discovery": False, "listen_port": 0}
    settings.edit_network()
    desk.pump(lambda: alice.node.status()["listening"])
    backup = desk.tmp / "lib.aureom-backup"
    desk.files["save"] = str(backup)
    desk.answers["Export encrypted backup"] = {"passphrase": "backup passphrase", "repeat": "backup passphrase"}
    monkey_kdf = alice.export_backup
    alice.export_backup = lambda *a, **k: monkey_kdf(*a, **(k | {"kdf": FAST_KDF}))
    settings.export_backup()
    desk.pump(lambda: backup.exists() and "Backup written" in w.toast_label.text())
    desk.files["open"], desk.files["dir"] = str(backup), str(desk.tmp / "restored")
    desk.answers["Restore backup"] = {"backup": "backup passphrase", "library": ""}
    settings.restore_backup()
    desk.pump(lambda: "Restored" in w.toast_label.text())
    assert (desk.tmp / "restored" / "profile.json").exists()
    settings.lock()                                             # unencrypted: explains instead of locking
    assert desk.errors == [], desk.errors
