"""Runs the reproducible demonstration (three separate node processes driven
through their local APIs) and requires every one of its 15 asserted steps."""
import subprocess
import sys

from tests.conftest import ROOT


def test_alice_ben_cara_storyline(tmp_path):
    result = subprocess.run([sys.executable, str(ROOT / "scripts" / "demo_three_peers.py"), "--workdir", str(tmp_path / "demo")],
                            capture_output=True, text=True, timeout=300)
    assert result.returncode == 0, result.stdout[-3000:] + result.stderr[-2000:]
    assert "All 15 demonstration steps passed." in result.stdout and "✗" not in result.stdout
    for name in ("alice", "ben", "cara"):                    # separate databases, object stores and keys
        profile = tmp_path / "demo" / name
        assert (profile / "profile.json").exists() and (profile / "objects").is_dir()
    assert (tmp_path / "demo" / "ben" / "catalogue.db.enc").exists() and (tmp_path / "demo" / "alice" / "catalogue.db").exists()
