"""Drives the real PySide6 interface off-screen: builds two profiles, pairs
them, visits every page, opens every fixture format in the Reading Room and
switches themes.  Fails on any exception raised by the interface."""
import os
import subprocess
import sys

import pytest

from tests.conftest import ROOT

pytest.importorskip("PySide6")


def test_every_page_renders_offscreen(tmp_path):
    env = dict(os.environ, QT_QPA_PLATFORM="offscreen", AUREOM_DISABLE_KEYRING="1")
    result = subprocess.run([sys.executable, str(ROOT / "scripts" / "render_screenshots.py"), str(tmp_path)],
                            capture_output=True, text=True, timeout=240, env=env)
    assert result.returncode == 0, result.stderr[-3000:]
    assert "Traceback" not in result.stderr, result.stderr[-3000:]
    shots = sorted(p.name for p in tmp_path.glob("*.png"))
    assert len(shots) == 15 and all((tmp_path / s).stat().st_size > 10_000 for s in shots)
