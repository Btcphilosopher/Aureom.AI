"""End-to-end proof: an unauthorised peer cannot retrieve a private manifest or file.

Two kinds of outsider are exercised against a real listener over TLS:
* an **anonymous** client (no client certificate), and
* a **paired but non-member** device (authenticated, simply not authorised),
each armed with the exact collection id, edition id and file hash."""
import pytest

from aureom.domain.errors import CommonsError
from aureom.protocol import messages as m
from tests.conftest import EPUB, MANUSCRIPT, call, files_containing, pair, share
from tests.integration.test_private_sharing import addr


@pytest.mark.parametrize("paired", [False, True], ids=["anonymous", "paired-non-member"])
def test_outsider_gets_nothing_and_cannot_tell_real_ids_from_invented_ones(make, tmp_path, paired):
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    cid, eds = share(alice, ben, [MANUSCRIPT, EPUB])
    edition = eds["tidewater-letters-manuscript.md"]
    real_hash = alice.catalogue.primary_file(edition)["content_hash"]
    if paired:
        pair(alice, cara)

    async def attempt(message):
        """Returns (error code, error message, bytes received from Alice)."""
        session = await (cara.node.connect_peer(alice.identity.device_id) if paired
                         else cara.node.connect_public(addr(alice), alice.identity.device_id))
        async with session:
            before = session.frames.bytes_in
            try:
                if isinstance(message, m.GetChunk):
                    await session.get_chunk(message)
                else:
                    await session.request(message)
                return "ALLOWED", "", session.frames.bytes_in - before
            except CommonsError as exc:
                return exc.code, str(exc), session.frames.bytes_in - before

    def variants(collection_id, file_hash):
        scope = m.Scope(kind="collection", id=collection_id)
        return [m.GetCollection(collection_id=collection_id),
                m.GetManifest(scope=scope, file_hash=file_hash),
                m.GetChunk(scope=scope, file_hash=file_hash, index=0, chunk_size=16384),
                m.GetManifest(scope=m.Scope(kind="public"), file_hash=file_hash),
                m.GetChunk(scope=m.Scope(kind="public"), file_hash=file_hash, index=0, chunk_size=16384),
                m.GetManifest(scope=m.Scope(kind="device"), file_hash=file_hash),
                m.GetChunk(scope=m.Scope(kind="device"), file_hash=file_hash, index=3, chunk_size=16384),
                m.Propose(collection_id=collection_id, op="share_annotation", payload={"annotation_id": "x"}),
                m.InvitationResponse(collection_id=collection_id, accept=True)]

    real = [call(cara, attempt(msg)) for msg in variants(cid, real_hash)]
    invented = [call(cara, attempt(msg)) for msg in variants("f" * 32, "e" * 64)]
    assert all(code == "not_found_or_forbidden" for code, _, _ in real)
    assert real == invented                       # same code, same text, same size: no oracle for what exists
    assert all(size < 200 for _, _, size in real)  # an error frame only — no metadata, manifest or chunk bytes

    # listing endpoints reveal nothing either
    if paired:
        assert call(cara, attempt(m.ListShared()))[0] == "ALLOWED"
        async def listed():
            async with await cara.node.connect_peer(alice.identity.device_id) as s:
                return await s.request(m.ListShared())
        assert call(cara, listed()) == {"collections": []}
    else:
        assert call(cara, attempt(m.ListShared()))[0] == "not_found_or_forbidden"
        assert call(cara, attempt(m.SyncDigest()))[0] == "not_found_or_forbidden"
    assert call(cara, cara.node.fetch_public_catalogue(addr(alice)))["publications"] == []

    # and nothing of Alice's private library ended up on Cara's disk
    assert cara.catalogue.list() == [] and cara.store.usage_bytes() == 0 and cara.transfers.list() == []
    cara_dir = tmp_path / "cara"
    for trace in (b"harbourmaster", b"Tidewater", b"Circle", real_hash.encode(), cid.encode()):
        assert files_containing(cara_dir, trace) == [], trace
    # while the authorised member is served normally
    async def member():
        async with await ben.node.connect_peer(alice.identity.device_id) as s:
            data = await s.request(m.GetManifest(scope=m.Scope(kind="collection", id=cid), file_hash=real_hash))
            return data["manifest"]["file_hash"]
    assert call(ben, member()) == real_hash
