"""Offline reading, annotations and their re-anchoring, the publishing state machine."""
import sqlite3

import pytest

from aureom.annotations.service import locate
from aureom.domain.errors import InvalidInput, PermissionDenied, StateError
from tests.conftest import CORRECTED, EPUB, FIRST, MANUSCRIPT, PDF

RIGHTS = {"rights_basis": "author", "licence_confirmed": True, "no_private_material": True, "understands_permanence": True}


def test_library_reading_and_annotation_work_with_no_network(make):
    """Nothing here starts networking: the application is useful offline."""
    ctx = make("solo")
    eid = ctx.catalogue.import_file(EPUB).edition_id
    assert ctx.node.status()["mode"] == "offline" and ctx.node.status()["label"] == "Offline"
    file = ctx.catalogue.primary_file(eid)
    assert ctx.catalogue.read_bytes(file)[:2] == b"PK" and ctx.catalogue.verify_file(file)
    assert ctx.catalogue.list("fingerprint wax")[0]["edition_id"] == eid
    note = ctx.annotations.create(eid, "highlight", {"section": 3, "quote": "Compare the fingerprints aloud."})
    assert note["private"] and note["content_hash"] == file["content_hash"]      # anchored to the exact file
    ctx.annotations.set_progress(eid, {"section": 3}, 0.5)
    assert ctx.annotations.progress(eid)["current"]["fraction"] == 0.5
    assert ctx.catalogue.recent_reading()[0]["edition_id"] == eid
    assert ctx.catalogue.read_bytes(file) == EPUB.read_bytes()                   # the original is never modified
    with pytest.raises(Exception):
        ctx.node.download_edition(eid)                                            # nothing to fetch, nothing attempted


def test_annotations_are_private_by_default_and_owned(make):
    ctx = make("a")
    eid = ctx.catalogue.import_file(EPUB).edition_id
    a = ctx.annotations.create(eid, "note", {"page": 2}, "mine")
    assert a["shared_in"] == "" and a["mine"]
    with pytest.raises(InvalidInput):
        ctx.annotations.set_shared(a["annotation_id"], "no-such-collection")
    ctx.db.execute("UPDATE annotations SET author_account='someone' WHERE annotation_id=?", (a["annotation_id"],))
    with pytest.raises(PermissionDenied):
        ctx.annotations.update(a["annotation_id"], body="hijack")


@pytest.mark.parametrize("quote,prefix,status", [
    ("the quince-coloured ledger was heavy", "", "ok"),                    # unique passage
    ("ledger", "the quince-coloured ", "ok"),                              # short but context matches
    ("ledger", "some other words ", "needs_review"),                       # short, context changed
    ("It rained.", "", "needs_review"),                                    # appears twice
    ("the quince coloured ledger was very heavy indeed", "", "needs_review"),   # text edited
    ("an entirely absent sentence about marmalade", "", "orphaned"),
])
def test_locate_classifies_matches(quote, prefix, status):
    text = "It rained. Then the quince-coloured ledger was heavy and nobody carried it. It rained."
    assert locate(quote, prefix, "", text)["status"] == status


def test_annotations_follow_a_new_edition_and_uncertain_ones_are_flagged(make):
    ctx = make("a")
    old = ctx.catalogue.import_file(FIRST)
    new = ctx.catalogue.import_file(CORRECTED, work_id=old.work_id, previous_edition_id=old.edition_id)
    make_ = lambda kind, quote, body="": ctx.annotations.create(old.edition_id, kind, {"quote": quote}, body)  # noqa: E731
    make_("highlight", "An epistolary novella. This is synthetic demonstration text")
    make_("note", "The harbourmaster recieved the atlas on the forth of March.", "check the date")
    make_("note", "A sentence that the author deleted entirely from the book.", "gone")
    ctx.annotations.create(old.edition_id, "bookmark", {"page": 3})
    report = ctx.annotations.migrate(old.edition_id, new.edition_id)
    assert report == {"ok": 1, "needs_review": 2, "orphaned": 1, "skipped": 0}
    moved = {a["body"] or a["kind"]: a for a in ctx.annotations.list(new.edition_id)}
    assert moved["check the date"]["status"] == "needs_review" and "received the atlas" in moved["check the date"]["locator"]["quote"]
    assert moved["gone"]["status"] == "orphaned" and moved["gone"]["review_note"]
    assert all(a["content_hash"] == ctx.catalogue.primary_file(new.edition_id)["content_hash"] for a in moved.values())
    assert len(ctx.annotations.list(old.edition_id)) == 4                 # originals stay on the old edition
    assert len(ctx.annotations.review_queue()) == 3
    assert ctx.annotations.migrate(old.edition_id, new.edition_id)["skipped"] == 4      # idempotent


# ---------------------------------------------------------------- publishing
def _published(ctx, path=FIRST, signed=True):
    eid = ctx.catalogue.import_file(path).edition_id
    imprint = ctx.identity.create_publisher("Saltmarsh Press")["publisher_id"] if signed else ""
    pid = ctx.publishing.create_draft(eid, publisher_id=imprint)["publication_id"]
    if not ctx.publishing.get(pid)["package"]["licence"]:
        ctx.publishing.update_draft(pid, {"licence": "CC BY 4.0"})          # a licence statement is mandatory
    digest = ctx.publishing.enter_preview(pid)["digest"]
    ctx.publishing.submit_rights_review(pid, RIGHTS)
    return ctx.publishing.publish(pid, disclosure_digest=digest, confirm=True), eid


def test_workflow_steps_cannot_be_skipped(make):
    ctx = make("a")
    eid = ctx.catalogue.import_file(FIRST).edition_id
    pid = ctx.publishing.create_draft(eid)["publication_id"]
    digest = ctx.publishing.disclosure(pid)["digest"]
    with pytest.raises(StateError):
        ctx.publishing.publish(pid, disclosure_digest=digest, confirm=True)      # no preview, no review
    with pytest.raises(StateError):
        ctx.publishing.submit_rights_review(pid, RIGHTS)                          # review before preview
    ctx.publishing.enter_preview(pid)
    with pytest.raises(InvalidInput):
        ctx.publishing.submit_rights_review(pid, RIGHTS | {"no_private_material": False})
    ctx.publishing.submit_rights_review(pid, RIGHTS)
    with pytest.raises(InvalidInput):
        ctx.publishing.publish(pid, disclosure_digest=digest)                     # no explicit confirmation
    with pytest.raises(StateError) as e:
        ctx.publishing.publish(pid, disclosure_digest="0" * 64, confirm=True)     # not what was previewed
    assert e.value.code == "preview_out_of_date"
    ctx.publishing.update_draft(pid, {"title": "Changed after review"})
    assert ctx.publishing.get(pid)["state"] == "draft"                            # any edit restarts the workflow
    assert ctx.publishing.public_entries() == [] and ctx.catalogue.edition_view(eid)["visibility"] == "private"


def test_disclosure_lists_what_is_and_is_not_published(make):
    ctx = make("a")
    eid = ctx.catalogue.import_file(FIRST).edition_id
    ctx.catalogue.update_user_metadata(eid, {"tags": ["secret-project"]})
    ctx.annotations.create(eid, "note", {"quote": "Tidewater"}, "private thought")
    d = ctx.publishing.disclosure(ctx.publishing.create_draft(eid)["publication_id"])
    text = str(d["will_become_public"])
    assert "secret-project" not in text and "private thought" not in text and "file:" not in text
    assert d["will_become_public"]["files"][0]["sha256"] == ctx.catalogue.primary_file(eid)["content_hash"]
    assert any("copyright ownership" in n for n in d["notices"]) and any("annotations" in n for n in d["will_not_be_published"])


def test_published_editions_are_immutable_even_at_the_database_level(make):
    ctx = make("a")
    pub, _ = _published(ctx)
    pid = pub["publication_id"]
    with pytest.raises(StateError):
        ctx.publishing.update_draft(pid, {"title": "rewrite history"})
    with pytest.raises(StateError):
        ctx.publishing.discard_draft(pid)
    for sql in ("UPDATE publications SET manifest='{}' WHERE publication_id=?",
                "UPDATE publications SET package='{}' WHERE publication_id=?",
                "DELETE FROM publications WHERE publication_id=?"):
        with pytest.raises(sqlite3.DatabaseError, match="immutable"):
            ctx.db.execute(sql, (pid,))
    assert ctx.publishing.get(pid)["manifest"]["title"] == "Tidewater Letters"


def test_revision_creates_a_distinct_linked_edition_and_withdrawal_stops_serving(make):
    ctx = make("a")
    first, eid1 = _published(ctx)
    with pytest.raises(InvalidInput):
        ctx.publishing.create_revision(first["publication_id"], FIRST, label="Same", notes="identical bytes")
    with pytest.raises(InvalidInput):
        ctx.publishing.create_revision(first["publication_id"], CORRECTED, label="Corrected", notes="")
    draft = ctx.publishing.create_revision(first["publication_id"], CORRECTED, label="Corrected edition", notes="Fixed typos.")
    assert draft["state"] == "draft" and ctx.publishing.get(first["publication_id"])["state"] == "published"
    digest = ctx.publishing.enter_preview(draft["publication_id"])["digest"]
    ctx.publishing.submit_rights_review(draft["publication_id"], RIGHTS)
    second = ctx.publishing.publish(draft["publication_id"], disclosure_digest=digest, confirm=True)
    old = ctx.publishing.get(first["publication_id"])
    assert old["state"] == "revised" and old["superseded_by"] == second["publication_id"]
    assert old["manifest"] == first["manifest"]                                       # untouched
    m2 = second["manifest"]
    assert m2["previous_manifest_id"] == first["manifest_id"] and m2["edition_number"] == 2 and m2["work_id"] == first["work_id"]
    assert m2["files"][0]["file_hash"] != first["manifest"]["files"][0]["file_hash"]
    entries = ctx.publishing.public_entries()
    assert {e["edition_label"] for e in entries} == {"Edition 1", "Corrected edition"} or len(entries) == 2
    h1 = first["manifest"]["files"][0]["file_hash"]
    assert ctx.publishing.public_file(h1).file_hash == h1
    result = ctx.publishing.withdraw(first["publication_id"], "superseded")
    assert "may persist" in result["notice"]
    with pytest.raises(PermissionDenied):
        ctx.publishing.public_file(h1)                                               # no longer distributed
    assert len(ctx.publishing.public_entries()) == 1 and ctx.store.has(h1)           # still in the author's own library
    assert ctx.catalogue.edition_view(eid1)["visibility"] == "private"


def test_unsigned_publication_and_other_formats(make):
    ctx = make("a")
    pub, _ = _published(ctx, PDF, signed=False)
    assert pub["manifest"]["signature"] is None and pub["manifest"]["publisher"] is None
    assert pub["manifest"]["files"][0]["format"] == "pdf"


def test_private_copy_of_manuscript_is_never_in_the_public_catalogue(make):
    ctx = make("a")
    ctx.catalogue.import_file(MANUSCRIPT)
    _published(ctx)
    listing = str(ctx.publishing.public_entries())
    assert "working manuscript" not in listing and len(ctx.publishing.public_entries()) == 1
    private_hash = ctx.catalogue.list("working manuscript")[0]["content_hash"]
    with pytest.raises(PermissionDenied):
        ctx.publishing.public_file(private_hash)
