"""Sanitisation, safe archive reading, manifests, signatures, framing."""
import asyncio
import datetime as dt
import io
import struct

import pytest

from aureom.domain.errors import IntegrityFailure, InvalidInput, LimitExceeded, ProtocolError
from aureom.domain.limits import Limits
from aureom.identity.keys import AccountIdentity, DeviceIdentity, PublisherIdentity, RotationStatement
from aureom.identity.pairing import parse_invitation
from aureom.protocol import messages as m
from aureom.protocol.framing import FrameStream
from aureom.protocol.manifest import (PublicationManifest, build_file_manifest, check_publication, parse_file_manifest,
                                      parse_publication)
from aureom.readers.epub import EpubBook
from aureom.readers.htmltext import markdown_to_html, sanitize_html, sanitize_svg
from aureom.readers.safezip import SafeZip, normalise_member
from tests.conftest import EPUB, hostile_zip


def test_html_is_made_inert():
    dirty = ('<h1 onclick="steal()">T</h1><script>alert(1)</script><style>*{}</style><p>ok</p>'
             '<img src="http://tracker.example/p.gif"><img src="pic.png" onerror="x()"><img src="data:image/png;base64,AA">'
             '<a href="javascript:alert(1)">j</a><a href="https://example.org/x">ext</a><a href="ch2.xhtml#s">in</a>'
             '<iframe src="http://x"></iframe><form action="http://x"><input name="q"></form><object data="x"></object>')
    clean = sanitize_html(dirty, base="OEBPS/ch1.xhtml", resolve=lambda base, href: "OEBPS/" + href.split("#")[0])
    for bad in ("script", "onclick", "onerror", "javascript:", "tracker.example", "iframe", "<form", "<input", "<object",
                "data:image", "alert", "<style"):
        assert bad not in clean, bad
    assert 'src="aureom-res:OEBPS/pic.png"' in clean                  # internal image rewritten to our own scheme
    assert 'href="aureom-ext:https%3A%2F%2Fexample.org%2Fx"' in clean  # external link needs confirmation
    assert 'href="aureom-doc:OEBPS/ch2.xhtml#s"' in clean
    assert "src" not in sanitize_html('<img src="pic.png">')          # no resolver → nothing to load
    assert "<script" not in markdown_to_html("# T\n\n<script>x</script>\n\n[a](javascript:x)")


def test_svg_active_and_external_content_is_stripped():
    svg = (b'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" onload="x()">'
           b'<script>x</script><foreignObject><p>x</p></foreignObject><image xlink:href="file:///etc/passwd"/>'
           b'<use href="#ok"/><rect id="ok" width="1" height="1" onclick="y()" style="fill:url(http://x)"/></svg>')
    out = sanitize_svg(svg).decode()
    for bad in ("script", "foreignObject", "onload", "onclick", "file:", "http://x"):
        assert bad not in out, bad
    assert "#ok" in out and "<rect" in out
    with pytest.raises(Exception):
        sanitize_svg(b'<!DOCTYPE svg [<!ENTITY a "aaaa">]><svg>&a;</svg>')     # entity tricks are refused outright


def test_zip_limits_and_member_paths(tmp_path):
    with pytest.raises(LimitExceeded):
        SafeZip(hostile_zip(tmp_path / "bomb.zip", "bomb"), Limits())
    with pytest.raises(LimitExceeded):
        SafeZip(hostile_zip(tmp_path / "many.zip", "many"), Limits())
    z = SafeZip(hostile_zip(tmp_path / "t.zip", "traversal"), Limits())
    assert all(".." not in name for name in z.names())               # traversal members are unreachable
    for bad in ("../x", "/etc/passwd", "a/../../x", "C:\\x", "a\x00b"):
        with pytest.raises(InvalidInput):
            normalise_member(bad)
    with pytest.raises(InvalidInput):
        EpubBook.open(tmp_path / "t.zip")


def test_fixture_epub_parses_with_metadata_contents_and_cover():
    book = EpubBook.open(io.BytesIO(EPUB.read_bytes()))
    assert book.metadata["title"] == "The Lantern Archive" and book.metadata["authors"] == ["Marguerite Ashdown"]
    assert len(book.spine) == 7 and book.toc[3].label == "What a Fingerprint Proves"
    assert book.cover(4_000_000)[1] == "image/png"
    assert book.resolve("OEBPS/chapter-3.xhtml", "../../../etc/passwd") is None


# ------------------------------------------------------------------ manifests
def _manifest(size=100_000, chunk=16384):
    data = bytes(range(256)) * (size // 256 + 1)
    return build_file_manifest(iter([data[:size]]), chunk_size=chunk, fmt="txt", media_type="text/plain",
                               filename="../../evil name.txt", edition_id="e1"), data[:size]


def test_manifest_describes_file_and_sanitises_name():
    manifest, data = _manifest()
    assert manifest.size == len(data) and len(manifest.chunks) == 7 and manifest.chunks[-1].size == 100_000 - 6 * 16384
    assert manifest.filename == "evil name.txt"
    assert parse_file_manifest(manifest.model_dump(), Limits(), expected_hash=manifest.file_hash) == manifest


@pytest.mark.parametrize("mutate,error", [
    (lambda d: d["chunks"].pop(), ProtocolError),                                    # chunk count vs size
    (lambda d: d["chunks"][0].update(size=5), ProtocolError),                        # sizes do not add up
    (lambda d: d["chunks"][1].update(index=5), ProtocolError),                       # non-contiguous
    (lambda d: d.update(size=d["size"] + 1), ProtocolError),
    (lambda d: d.update(chunk_size=1024), ProtocolError),                            # below minimum chunk size
    (lambda d: d.update(edition_id="../x"), ProtocolError),
    (lambda d: d.update(extra_field=1), ProtocolError),
    (lambda d: d.update(protocol_min=99), ProtocolError),
])
def test_inconsistent_manifests_are_rejected(mutate, error):
    doc = _manifest()[0].model_dump()
    mutate(doc)
    with pytest.raises(error):
        parse_file_manifest(doc, Limits())


def test_oversized_manifests_are_rejected_before_use():
    manifest, _ = _manifest(size=600_000)
    doc = manifest.model_dump()
    with pytest.raises(LimitExceeded) as e:
        parse_file_manifest(doc, Limits(max_chunks=8))
    assert e.value.code == "too_many_chunks"
    with pytest.raises(LimitExceeded) as e:
        parse_file_manifest(doc, Limits(max_manifest_bytes=1024))
    assert e.value.code == "manifest_too_large"
    with pytest.raises(LimitExceeded) as e:
        parse_file_manifest(doc, Limits(max_document_bytes=1000))
    assert e.value.code == "document_too_large"
    with pytest.raises(IntegrityFailure):
        parse_file_manifest(doc, Limits(), expected_hash="0" * 64)


def _publication(signed=True):
    manifest, _ = _manifest()
    pub = PublicationManifest(publication_id="p1", work_id="w1", edition_id="e1", edition_number=1, title="T",
                              licence="CC0", files=[manifest], published_at="2026-01-01T00:00:00Z")
    key = PublisherIdentity.generate()
    return (pub.sign_with(key, "Saltmarsh Press") if signed else pub), key


def test_publication_signature_states_exactly_what_was_checked():
    pub, key = _publication()
    report = check_publication(pub)
    assert report.signed and report.signature_valid and not report.key_previously_pinned
    text = " ".join(report.statements)
    assert "does not prove who holds the key" in text and "not that they are safe" in text
    assert "verified" not in text.lower()                              # never a bare "verified"
    assert check_publication(pub, pinned={"name": "Saltmarsh Press"}).key_previously_pinned


def test_invalid_publication_signatures_are_detected():
    pub, _ = _publication()
    altered = pub.model_copy(update={"title": "Different"})
    assert not check_publication(altered).signature_valid
    other = PublisherIdentity.generate()
    forged = pub.model_copy(deep=True)
    forged.signature.value = __import__("aureom.domain.util", fromlist=["b64e"]).b64e(
        other.sign("publication-manifest", forged.signing_payload()))
    assert not check_publication(forged).signature_valid               # signed by a different key than it names
    stripped = pub.model_copy(update={"signature": None})
    report = check_publication(stripped)
    assert not report.signed and "not signed" in " ".join(report.statements)
    assert pub.manifest_id == stripped.manifest_id != altered.manifest_id
    with pytest.raises(ProtocolError):
        parse_publication(pub.model_dump(mode="json") | {"files": []}, Limits())


def test_endorsements_and_rotation_statements_cannot_be_forged():
    account, other, device = AccountIdentity.generate(), AccountIdentity.generate(), DeviceIdentity.generate()
    good = account.endorse(device.device_id)
    assert good.is_valid_for(device.device_id) and not good.is_valid_for(DeviceIdentity.generate().device_id)
    assert not good.model_copy(update={"account_id": other.id}).is_valid_for(device.device_id)
    new = DeviceIdentity.generate()
    statement = RotationStatement.create(device, new, account)
    assert statement.verify_against(device.cert_der) == new.cert_der
    attacker = DeviceIdentity.generate()
    with pytest.raises(IntegrityFailure):
        RotationStatement.create(attacker, new, None).verify_against(device.cert_der)      # signed by the wrong old key
    with pytest.raises(IntegrityFailure):
        statement.model_copy(update={"new_cert": __import__("aureom.domain.util", fromlist=["b64e"]).b64e(attacker.cert_der),
                                     "new_device_id": attacker.device_id}).verify_against(device.cert_der)


def test_invitations_reject_tampering_and_expiry(make):
    ctx = make("a", start=True)
    inv = ctx.node.create_invitation()
    assert parse_invitation(inv.to_text()).device_id == ctx.identity.device_id
    assert parse_invitation(inv.to_json()).token == inv.token
    with pytest.raises(InvalidInput) as e:
        parse_invitation(inv.model_copy(update={"addresses": ["evil.example:1"]}).to_json())
    assert e.value.code == "bad_signature"
    old = inv.model_copy(update={"expires_at": (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=1)).isoformat()})
    with pytest.raises(InvalidInput) as e:
        parse_invitation(old.sign_with(ctx.identity.device).to_json())
    assert e.value.code == "invitation_expired"
    for junk in ("", "aureom-invite:!!!!", "{}", "aureom-invite:" + "A" * 30000, b"\xff\xfe"):
        with pytest.raises(InvalidInput):
            parse_invitation(junk)


def test_messages_reject_unknown_types_and_fields():
    assert isinstance(m.parse_request(b'{"t":"ping"}'), m.Ping)
    for bad in (b'{"t":"delete_everything"}', b'{"t":"ping","extra":1}', b"not json", b'{"t":"get_chunk"}',
                b'{"t":"get_manifest","scope":{"kind":"collection","id":"../x"},"file_hash":"' + b"0" * 64 + b'"}'):
        with pytest.raises(ProtocolError):
            m.parse_request(bad)
    with pytest.raises(ProtocolError):
        m.negotiate([7, 9])


def test_frame_length_is_checked_before_reading_payload():
    async def run():
        reader = asyncio.StreamReader()
        reader.feed_data(struct.pack(">IB", 500 * 1024 * 1024, 1))     # claims a 500 MiB JSON frame
        with pytest.raises(ProtocolError) as e:
            await FrameStream(reader, None).recv(1)
        assert e.value.code == "frame_too_large"

    asyncio.run(run())
