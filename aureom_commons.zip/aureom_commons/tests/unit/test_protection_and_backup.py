"""Encrypted library, search-index protection when locked, backup/restore."""
import io
import sqlite3
import tarfile

import pytest

from aureom.domain.errors import IntegrityFailure, InvalidInput, LibraryLocked
from aureom.node import Profile
from aureom.node.service import Commons
from aureom.storage import backup as backup_mod
from aureom.storage.crypto import StreamEncryptor, decrypt_bytes, derive_passphrase_key, encrypt_bytes
from tests.conftest import EPUB, FAST_KDF, MANUSCRIPT, files_containing

PHRASES = [b"harbourmaster", b"Tidewater", b"quince-coloured note", b"tidewater-letters-manuscript"]


def _populate(ctx):
    eid = ctx.catalogue.import_file(MANUSCRIPT).edition_id
    ctx.annotations.create(eid, "note", {"quote": "The harbourmaster recieved"}, "a quince-coloured note")
    ctx.collections.create("Secret circle of Tidewater readers")
    ctx.catalogue.import_file(EPUB)
    return eid


def test_stream_encryption_detects_tampering_truncation_and_wrong_key():
    import os

    key, data = os.urandom(32), os.urandom(200_000)
    blob = encrypt_bytes(key, data)
    assert decrypt_bytes(key, blob) == data and data[:64] not in blob
    for damaged in (blob[:-1], blob[:70000], blob[:100] + bytes([blob[100] ^ 1]) + blob[101:],
                    blob[:28] + blob[28 + 65552:]):                       # last one drops a whole chunk
        with pytest.raises(IntegrityFailure):
            decrypt_bytes(key, damaged)
    with pytest.raises(IntegrityFailure):
        decrypt_bytes(os.urandom(32), blob)


def test_plain_profile_contains_readable_text_so_the_next_check_is_meaningful(make, tmp_path):
    ctx = make("plain")
    _populate(ctx)
    ctx.close()
    for phrase in PHRASES:
        assert files_containing(tmp_path / "plain", phrase), phrase


def test_locked_library_leaves_no_readable_text_index_titles_or_annotations(make, tmp_path):
    """The claim “encrypted library” covers the search index, catalogue,
    annotations, filenames and managed files — verified byte-for-byte on disk."""
    ctx = make("enc", passphrase="a long passphrase")
    eid = _populate(ctx)
    assert ctx.catalogue.list("harbourmaster")                           # search works while unlocked
    path = ctx.catalogue.content_path(ctx.catalogue.primary_file(eid))   # a viewer needed a temporary plaintext copy
    assert path.read_bytes().startswith(b"---") and oct(path.stat().st_mode & 0o777) == "0o600"
    ctx.close()
    root = tmp_path / "enc"
    assert not path.exists()                                             # temporary plaintext wiped on lock
    for phrase in PHRASES + [b"SQLite format 3", b"Secret circle"]:
        assert files_containing(root, phrase) == [], phrase
    assert not (root / "catalogue.db").exists() and not (root / "secrets.json").exists()
    with pytest.raises(sqlite3.DatabaseError):
        sqlite3.connect(root / "catalogue.db.enc").execute("SELECT * FROM sqlite_master")
    with pytest.raises(LibraryLocked):
        Profile.open(root)
    with pytest.raises(InvalidInput) as e:
        Profile.open(root, "wrong passphrase")
    assert e.value.code == "bad_passphrase"
    reopened = Profile.open(root, "a long passphrase")
    try:
        assert reopened.catalogue.list("harbourmaster") and reopened.annotations.list(eid)[0]["body"] == "a quince-coloured note"
        assert reopened.protection_report()["encrypted_library"]
        with pytest.raises(LibraryLocked):
            ctx.catalogue.list("harbourmaster")                          # the locked handle is unusable
    finally:
        reopened.close()


def test_referenced_files_are_reported_as_not_protected(make):
    ctx = make("enc", passphrase="a long passphrase")
    r = ctx.catalogue.import_file(MANUSCRIPT, mode="referenced")
    view = ctx.catalogue.edition_view(r.edition_id)
    assert view["storage"] == "referenced" and ctx.store.usage_bytes() == 0
    report = ctx.protection_report()
    assert report["referenced_files"] == 1 and any("by reference" in line for line in report["not_protected"])


@pytest.mark.parametrize("src_pass,dst_pass", [(None, "new library passphrase"), ("old library passphrase", None)])
def test_backup_and_restoration_round_trip(make, tmp_path, src_pass, dst_pass):
    ctx = make("src", passphrase=src_pass)
    eid = _populate(ctx)
    ctx.identity.create_publisher("Saltmarsh Press")
    device, hashes = ctx.identity.device_id, sorted(ctx.catalogue.managed_hashes())
    out = tmp_path / "lib.aureom-backup"
    manifest = ctx.export_backup(out, "backup passphrase", kdf=FAST_KDF)
    assert manifest["includes_identity_keys"] and all(files_containing(tmp_path, p) == [] or src_pass is None
                                                      for p in [b"harbourmaster"])
    assert b"harbourmaster" not in out.read_bytes() and b"SQLite format 3" not in out.read_bytes()
    restored = Commons.restore_backup(out, "backup passphrase", tmp_path / "restored", passphrase=dst_pass, kdf=FAST_KDF)
    try:
        assert restored.store.encrypted == bool(dst_pass)
        assert sorted(restored.catalogue.managed_hashes()) == hashes
        assert all(restored.store.verify(h) for h in hashes)             # every object re-verified
        assert restored.annotations.list(eid)[0]["body"] == "a quince-coloured note"
        assert restored.collections.list()[0]["name"].startswith("Secret circle")
        assert restored.catalogue.list("harbourmaster")[0]["availability"] == "local"
        assert restored.identity.device_id == device and len(restored.identity.publishers()) == 1
    finally:
        restored.close()
    if dst_pass:
        assert files_containing(tmp_path / "restored", b"harbourmaster") == []


def test_backup_without_identity_restores_as_a_new_device(make, tmp_path):
    ctx = make("src", passphrase="old library passphrase")
    _populate(ctx)
    out = tmp_path / "b.aureom-backup"
    assert not ctx.export_backup(out, "backup passphrase", include_identity=False, kdf=FAST_KDF)["includes_identity_keys"]
    restored = Commons.restore_backup(out, "backup passphrase", tmp_path / "r")
    try:
        assert restored.identity.device_id != ctx.identity.device_id     # keys did not travel, even via the database
        assert restored.db.scalar("SELECT COUNT(*) FROM secrets") == 0 and len(restored.catalogue.list()) == 2
    finally:
        restored.close()


def test_wrong_passphrase_and_tampered_backups_are_rejected(make, tmp_path):
    ctx = make("src")
    _populate(ctx)
    out = tmp_path / "b.aureom-backup"
    ctx.export_backup(out, "backup passphrase", kdf=FAST_KDF)
    with pytest.raises(InvalidInput) as e:
        Commons.restore_backup(out, "not the passphrase", tmp_path / "r1")
    assert e.value.code == "bad_passphrase" and not (tmp_path / "r1").exists()
    blob = bytearray(out.read_bytes())
    blob[len(blob) // 2] ^= 0xFF
    (tmp_path / "bad.aureom-backup").write_bytes(bytes(blob))
    with pytest.raises(IntegrityFailure):
        Commons.restore_backup(tmp_path / "bad.aureom-backup", "backup passphrase", tmp_path / "r2")
    assert not (tmp_path / "r2").exists()                                # nothing half-restored is left behind
    with pytest.raises(InvalidInput):
        Commons.restore_backup(MANUSCRIPT, "backup passphrase", tmp_path / "r3")


def test_backup_with_unexpected_member_names_is_rejected(tmp_path):
    """A crafted (but correctly encrypted) archive cannot write outside the profile."""
    import json
    import os
    import struct

    salt = os.urandom(16)
    key = derive_passphrase_key("backup passphrase", salt, FAST_KDF)
    header = json.dumps({"version": 1, "kdf": FAST_KDF, "salt": salt.hex()}).encode()
    inner = io.BytesIO()
    with tarfile.open(fileobj=inner, mode="w") as tar:
        info = tarfile.TarInfo("../../outside.txt")
        info.size = 4
        tar.addfile(info, io.BytesIO(b"evil"))
    path = tmp_path / "crafted.aureom-backup"
    with open(path, "wb") as fh:
        fh.write(backup_mod.BACKUP_MAGIC + struct.pack(">I", len(header)) + header)
        enc = StreamEncryptor(key, fh)
        enc.write(inner.getvalue())
        enc.close()
    with pytest.raises(IntegrityFailure):
        Commons.restore_backup(path, "backup passphrase", tmp_path / "r")
    assert not (tmp_path / "outside.txt").exists() and not (tmp_path.parent / "outside.txt").exists()
