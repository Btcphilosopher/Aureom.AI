"""Import pipeline, deduplication, edition separation, limits, unsafe names."""
import os

import pytest

from aureom.domain.errors import InvalidInput, StateError
from aureom.domain.util import safe_filename
from tests.conftest import CORRECTED, EPUB, FIRST, FIX, MANUSCRIPT, hostile_zip


def test_identical_bytes_are_deduplicated_by_hash_not_by_name(make, tmp_path):
    """Same bytes imported twice — and under another name, and by reference —
    yield one catalogue record."""
    ctx = make("a")
    first = ctx.catalogue.import_file(EPUB)
    copy = tmp_path / "renamed-copy.epub"
    copy.write_bytes(EPUB.read_bytes())
    assert first.status == "imported"
    for path, mode in ((EPUB, "managed"), (copy, "managed"), (copy, "referenced")):
        again = ctx.catalogue.import_file(path, mode=mode)
        assert again.status == "duplicate" and again.edition_id == first.edition_id
    assert len(ctx.catalogue.list()) == 1


def test_same_title_different_bytes_are_never_merged(make):
    """Two editions that share a title stay separate works unless the user links them."""
    ctx = make("a")
    one, two = ctx.catalogue.import_file(FIRST), ctx.catalogue.import_file(CORRECTED)
    v1, v2 = ctx.catalogue.edition_view(one.edition_id), ctx.catalogue.edition_view(two.edition_id)
    assert v1["title"] == v2["title"] == "Tidewater Letters"
    assert v1["work_id"] != v2["work_id"] and v1["content_hash"] != v2["content_hash"]


def test_explicit_new_edition_is_linked_and_distinguishable(make, tmp_path):
    ctx = make("a")
    one = ctx.catalogue.import_file(FIRST)
    two = ctx.catalogue.import_file(CORRECTED, work_id=one.work_id, previous_edition_id=one.edition_id,
                                    relation="correction-of", label="Corrected edition", revision_notes="typos")
    editions = ctx.catalogue.editions_of_work(one.work_id)
    assert [e["edition_number"] for e in editions] == [1, 2]
    assert editions[1]["previous_edition_id"] == one.edition_id and editions[1]["relation"] == "correction-of"
    assert editions[0]["content_hash"] != editions[1]["content_hash"]
    assert ctx.store.verify(editions[0]["content_hash"])          # the first edition was not overwritten


def test_import_is_private_and_announces_nothing(make):
    ctx = make("a")
    r = ctx.catalogue.import_file(MANUSCRIPT)
    assert ctx.catalogue.edition_view(r.edition_id)["visibility"] == "private"
    assert ctx.publishing.public_entries() == [] and ctx.collections.list() == []
    assert ctx.node.status()["mode"] == "offline"                 # never even started networking


def test_user_corrections_are_kept_apart_from_imported_metadata(make):
    ctx = make("a")
    eid = ctx.catalogue.import_file(EPUB).edition_id
    ctx.catalogue.update_user_metadata(eid, {"title": "My Lantern Book", "tags": ["mine"]})
    layers = ctx.catalogue.metadata_layers(eid)
    assert layers["imported"]["title"] == "The Lantern Archive" and layers["user"]["title"] == "My Lantern Book"
    assert ctx.catalogue.list("lantern book")[0]["edition_id"] == eid
    ctx.catalogue.update_user_metadata(eid, {"title": None})       # revert the correction
    assert ctx.catalogue.effective_metadata(eid).title == "The Lantern Archive"
    with pytest.raises(InvalidInput):
        ctx.catalogue.update_user_metadata(eid, {"not_a_field": "x"})


def test_failures_are_reported_per_file_and_batch_continues(make, tmp_path):
    ctx = make("a", max_document_bytes=100_000)
    (tmp_path / "in").mkdir()
    (tmp_path / "in" / "empty.txt").write_bytes(b"")
    (tmp_path / "in" / "ok.txt").write_text("A small note about quinces.")
    results = {r.name: r for r in ctx.catalogue.import_paths([tmp_path / "in", MANUSCRIPT, tmp_path / "missing.pdf"])}
    assert results["ok.txt"].status == "imported"
    assert results["empty.txt"].status == "failed"
    assert results["tidewater-letters-manuscript.md"].status == "failed" and "size limit" in results["tidewater-letters-manuscript.md"].message
    assert results["missing.pdf"].status == "failed"


def test_storage_quota_is_enforced(make):
    ctx = make("a")
    ctx.store.max_bytes = 50_000
    assert ctx.catalogue.import_file(MANUSCRIPT).status == "failed"
    assert ctx.store.usage_bytes() == 0


def test_symlinks_and_hidden_files_inside_folders_are_skipped(make, tmp_path):
    ctx = make("a")
    folder = tmp_path / "drop"
    folder.mkdir()
    (folder / "real.txt").write_text("real file")
    (folder / ".hidden").write_text("hidden")
    os.symlink("/etc/hostname", folder / "link.txt")
    assert [r.name for r in ctx.catalogue.import_paths([folder])] == ["real.txt"]


@pytest.mark.parametrize("raw,expected", [
    ("../../etc/passwd", "passwd"), ("..\\..\\boot.ini", "boot.ini"), ("/abs/path/book.epub", "book.epub"),
    ("CON.txt", "_CON.txt"), ("", "file"), ("..", "file"), ("a\x00b\x1f.pdf", "ab.pdf"), ("   .hidden  ", "hidden"),
    pytest.param("x" * 300 + ".epub", "x" * 115 + ".epub", id="long-name-keeps-extension"),
])
def test_untrusted_filenames_are_reduced_to_safe_components(raw, expected):
    assert safe_filename(raw) == expected


def test_malicious_archives_are_contained(make, tmp_path):
    """A zip bomb, an archive with thousands of entries and one with traversal
    names cannot exhaust resources or escape; the import still records the file."""
    ctx = make("a")
    for kind in ("bomb", "many", "traversal"):
        r = ctx.catalogue.import_file(hostile_zip(tmp_path / f"{kind}.epub", kind))
        assert r.status == "imported" and r.warnings, kind
        assert "extraction did not complete" in r.warnings[0]
    assert not (tmp_path.parent / "evil.txt").exists()


def test_extraction_time_limit_falls_back_to_basic_details(make):
    ctx = make("a", preview_timeout_seconds=0.001)
    r = ctx.catalogue.import_file(EPUB)
    assert r.status == "imported" and "time limit" in r.warnings[0]
    assert ctx.catalogue.edition_view(r.edition_id)["title"] == "the lantern archive"


def test_sensitive_documents_can_be_kept_out_of_the_index(make):
    ctx = make("a")
    eid = ctx.catalogue.import_file(MANUSCRIPT).edition_id
    assert ctx.catalogue.list("harbourmaster")
    ctx.catalogue.set_index_mode(eid, "metadata")
    assert not ctx.catalogue.list("harbourmaster") and ctx.catalogue.list("tidewater")
    ctx.catalogue.set_index_mode(eid, "none")
    assert not ctx.catalogue.list("tidewater") and len(ctx.catalogue.list()) == 1


def test_search_filters_and_injection_safety(make):
    ctx = make("a")
    ctx.catalogue.import_paths([FIX])
    assert {v["format"] for v in ctx.catalogue.list(fmt="pdf")} == {"pdf"}
    assert [v["title"] for v in ctx.catalogue.list(author="okafor")] == ["Field Notes on Tidal Catalogues"]
    assert all(v["metadata"]["language"] == "en" for v in ctx.catalogue.list(language="en"))
    assert ctx.catalogue.list(title="lantern", space="private") and not ctx.catalogue.list(title="lantern", space="public")
    assert ctx.catalogue.list('fingerprint" OR title:* NEAR(') == [] or True      # must not raise
    assert ctx.catalogue.list(availability="local", date_from="2026-01-01")


def test_published_edition_cannot_be_removed_without_withdrawal(make):
    ctx = make("a")
    eid = ctx.catalogue.import_file(FIRST).edition_id
    pid = ctx.publishing.create_draft(eid)["publication_id"]
    d = ctx.publishing.enter_preview(pid)
    ctx.publishing.submit_rights_review(pid, {"rights_basis": "author", "licence_confirmed": True,
                                              "no_private_material": True, "understands_permanence": True})
    ctx.publishing.publish(pid, disclosure_digest=d["digest"], confirm=True)
    with pytest.raises(StateError):
        ctx.catalogue.remove_edition(eid)
