"""Synchronisation between one person's linked devices, and its conflict rules."""
import pytest

from aureom.domain.errors import PermissionDenied
from aureom.protocol import messages as m
from aureom.sync.engine import compare
from tests.conftest import EPUB, call, pair, wait_transfer
from tests.integration.test_private_sharing import outcome


@pytest.fixture
def devices(make):
    laptop, tablet = make("laptop", start=True), make("tablet", start=True)
    pair(laptop, tablet, "link-device")
    return laptop, tablet


def sync(a, b) -> dict:
    return call(a, a.node.sync_with(b.identity.device_id))


def test_version_vector_comparison():
    assert compare({"a": 1}, {"a": 1}) == "equal" and compare({"a": 2}, {"a": 1}) == "newer"
    assert compare({"a": 1}, {"a": 1, "b": 1}) == "older" and compare({"a": 2}, {"a": 1, "b": 1}) == "concurrent"


def test_linking_makes_one_account_and_sync_is_refused_to_everyone_else(devices, make):
    laptop, tablet = devices
    assert tablet.identity.account_id == laptop.identity.account_id
    assert laptop.identity.peer(tablet.identity.device_id)["is_own_device"]
    stranger = make("ben", start=True)
    pair(laptop, stranger)
    with pytest.raises(PermissionDenied) as e:
        call(stranger, stranger.node.sync_with(laptop.identity.device_id))
    assert e.value.code == "not_own_device"
    assert outcome(stranger, laptop, m.SyncDigest()) == "not_found_or_forbidden"
    assert outcome(stranger, laptop, m.SyncPush(records=[])) == "not_found_or_forbidden"


def test_metadata_syncs_but_file_bytes_replicate_only_on_request(devices):
    laptop, tablet = devices
    eid = laptop.catalogue.import_file(EPUB).edition_id
    laptop.annotations.create(eid, "note", {"quote": "Every library begins"}, "from the laptop")
    laptop.annotations.set_progress(eid, {"section": 2}, 0.3)
    stats = sync(tablet, laptop)
    assert stats["applied"] >= 3
    view = tablet.catalogue.edition_view(eid)
    assert view["title"] == "The Lantern Archive" and view["availability"] == "peer"
    assert tablet.store.usage_bytes() == 0                                # no bytes moved with the metadata
    assert tablet.annotations.list(eid)[0]["body"] == "from the laptop"
    tablet.annotations.set_progress(eid, {"section": 5}, 0.8)
    sync(tablet, laptop)
    for device in devices:                                                # one position per device; neither overwritten
        progress = device.annotations.progress(eid)
        assert {round(d["fraction"], 1) for d in progress["devices"]} == {0.3, 0.8} and progress["furthest"] == 0.8
    assert wait_transfer(tablet, tablet.node.download_edition(eid))["state"] == "completed"
    assert tablet.catalogue.edition_view(eid)["availability"] == "local"
    assert sync(tablet, laptop)["applied"] == 0 and sync(laptop, tablet)["applied"] == 0      # converged


def test_concurrent_metadata_edits_merge_by_field_and_conflicts_are_kept(devices):
    laptop, tablet = devices
    eid = laptop.catalogue.import_file(EPUB).edition_id
    sync(tablet, laptop)
    laptop.catalogue.update_user_metadata(eid, {"publisher": "Laptop Press"})
    tablet.catalogue.update_user_metadata(eid, {"tags": ["from-tablet"]})
    stats = sync(tablet, laptop)
    assert stats["conflicts"] == 0
    for device in devices:                                                # different fields: both changes survive
        meta = device.catalogue.effective_metadata(eid)
        assert meta.publisher == "Laptop Press" and meta.tags == ["from-tablet"]
    laptop.catalogue.update_user_metadata(eid, {"title": "Laptop's Title"})
    tablet.catalogue.update_user_metadata(eid, {"title": "Tablet's Title"})
    assert sync(tablet, laptop)["conflicts"] == 1
    titles = {d.catalogue.effective_metadata(eid).title for d in devices}
    assert len(titles) == 1 and titles <= {"Laptop's Title", "Tablet's Title"}      # both devices converge
    for device in devices:                                                # ...and the other value is not lost anywhere
        conflict = device.sync.conflicts()[0]
        assert conflict["rule"] == "concurrent-metadata-edit" and conflict["field"] == "title"
        assert {conflict["local_value"], conflict["remote_value"]} == {"Laptop's Title", "Tablet's Title"}
    loser = ({"Laptop's Title", "Tablet's Title"} - titles).pop()
    tablet.sync.resolve(tablet.sync.conflicts()[0]["conflict_id"], "use_other")
    sync(tablet, laptop)
    assert {d.catalogue.effective_metadata(eid).title for d in devices} == {loser}
    assert tablet.sync.conflicts() == []


def test_annotation_conflicts_keep_both_versions(devices):
    laptop, tablet = devices
    eid = laptop.catalogue.import_file(EPUB).edition_id
    edited = laptop.annotations.create(eid, "note", {"quote": "Every library begins"}, "original")["annotation_id"]
    doomed = laptop.annotations.create(eid, "note", {"quote": "Compare the fingerprints"}, "to delete")["annotation_id"]
    sync(tablet, laptop)
    laptop.annotations.update(edited, body="laptop wording")
    tablet.annotations.update(edited, body="tablet wording")
    laptop.annotations.delete(doomed)
    tablet.annotations.update(doomed, body="edited on the tablet meanwhile")
    assert sync(tablet, laptop)["conflicts"] == 2
    sync(laptop, tablet)
    for device in devices:
        notes = device.annotations.list(eid)
        bodies = sorted(a["body"] for a in notes)
        assert bodies == ["edited on the tablet meanwhile", "laptop wording", "tablet wording"]   # nothing discarded
        survivor = next(a for a in notes if a["annotation_id"] == doomed)
        assert survivor["status"] == "needs_review" and "deleted on one device" in survivor["review_note"]
        assert sum(1 for a in notes if "Conflicting edit" in a["review_note"]) == 1


def test_revocation_dominates_and_old_records_cannot_restore_access(devices, make):
    laptop, tablet = devices
    ben = make("ben", start=True)
    eid = laptop.catalogue.import_file(EPUB).edition_id
    cid = laptop.collections.create("Circle")["collection_id"]
    laptop.collections.add_item(cid, eid)
    pair(laptop, ben, "collection", collection_id=cid, permissions="reader")
    account = ben.identity.account_id
    sync(tablet, laptop)
    assert tablet.collections.permissions_of(cid, account) == {"view_metadata", "download"}
    stale = tablet.sync.export([("member", f"{cid}:{account}")])            # an old 'active' membership record
    laptop.collections.revoke(cid, account)                                # revoked on one device…
    tablet.collections.set_permissions(cid, account, "editor")             # …while the other widened the grant
    assert sync(tablet, laptop)["conflicts"] == 1
    for device in devices:
        assert device.collections.permissions_of(cid, account) == set()
        assert device.collections.members(cid)[0]["status"] == "revoked"
    assert any(c["rule"] == "revocation-dominates" for c in tablet.sync.conflicts())
    before = laptop.collections.get(cid)["permission_version"]
    assert laptop.sync.apply(stale, tablet.identity.device_id)["ignored"] == 1      # replaying the old record does nothing
    assert laptop.collections.permissions_of(cid, account) == set()
    assert laptop.collections.get(cid)["permission_version"] == before
    scope = m.Scope(kind="collection", id=cid)
    file_hash = laptop.catalogue.primary_file(eid)["content_hash"]
    assert outcome(ben, laptop, m.GetManifest(scope=scope, file_hash=file_hash)) == "not_found_or_forbidden"


def test_collection_deleted_on_one_device_and_edited_on_another_is_suspended_not_lost(devices):
    laptop, tablet = devices
    cid = laptop.collections.create("Circle")["collection_id"]
    sync(tablet, laptop)
    laptop.collections.delete(cid)
    tablet.collections.update(cid, name="Renamed on the tablet")
    assert sync(tablet, laptop)["conflicts"] >= 1
    sync(laptop, tablet)
    for device in devices:
        col = device.collections.get(cid)                                  # still there…
        assert col["access_state"] == "suspended"                          # …but shares nothing until reviewed
        assert device.collections.permissions_of(cid, device.identity.account_id) == set()
    conflict = next(c for c in tablet.sync.conflicts() if c["rule"] == "collection-delete-vs-edit")
    tablet.sync.resolve(conflict["conflict_id"], "restore")
    sync(tablet, laptop)
    assert all(d.collections.get(cid)["access_state"] == "active" for d in devices)
