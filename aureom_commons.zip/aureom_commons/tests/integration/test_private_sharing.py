"""Pairing, invitations, permission enforcement, metadata isolation, revocation.
All requests travel over real mutually-authenticated TLS between profiles."""
import pytest

from aureom.domain.errors import CommonsError, PermissionDenied, TransportError
from aureom.protocol import messages as m
from tests.conftest import EPUB, MANUSCRIPT, PDF, call, pair, share, wait_for, wait_transfer


def addr(ctx) -> str:
    return ctx.node.advertised_addresses()[0]


async def ask(ctx, target, message, paired=True):
    session = await (ctx.node.connect_peer(target.identity.device_id) if paired
                     else ctx.node.connect_public(addr(target), target.identity.device_id))
    async with session:
        if isinstance(message, m.GetChunk):
            return await session.get_chunk(message)
        return await session.request(message)


def outcome(ctx, target, message, paired=True) -> str:
    try:
        call(ctx, ask(ctx, target, message, paired))
        return "ALLOWED"
    except CommonsError as exc:
        return exc.code


def file_requests(cid: str, file_hash: str, version: int = 0):
    scope = m.Scope(kind="collection", id=cid)
    return [m.GetCollection(collection_id=cid, known_version=version),
            m.GetManifest(scope=scope, file_hash=file_hash, known_version=version),
            m.GetChunk(scope=scope, file_hash=file_hash, index=0, chunk_size=16384, known_version=version)]


def fetch(member, title_part: str) -> tuple[str, dict]:
    view = next(v for v in member.catalogue.list() if title_part in v["title"])
    tid = member.node.download_edition(view["edition_id"])
    return view["edition_id"], wait_transfer(member, tid)


# ------------------------------------------------------------------- pairing
def test_invitation_is_single_use_expiring_and_cancellable(make):
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    inv = alice.node.create_invitation()
    call(ben, ben.node.accept_invitation(inv.to_text()))
    assert ben.identity.peer(alice.identity.device_id)["state"] == "trusted"
    assert alice.identity.peer(ben.identity.device_id)["state"] == "trusted"
    for replayer in (cara, ben):                                        # another device, and the same device again
        with pytest.raises(PermissionDenied) as e:
            call(replayer, replayer.node.accept_invitation(inv.to_text()))
        assert e.value.code == "invitation_invalid"
    assert cara.identity.peers() == [] and len(alice.identity.peers()) == 1     # failed attempts leave no trust behind

    expired = alice.node.create_invitation()
    alice.db.execute("UPDATE pairing_invitations SET expires_at='2020-01-01T00:00:00Z' WHERE invitation_id=?",
                     (expired.invitation_id,))
    cancelled = alice.node.create_invitation()
    alice.identity.cancel_invitation(cancelled.invitation_id)
    for dead in (expired, cancelled):
        with pytest.raises(PermissionDenied) as e:
            call(cara, cara.node.accept_invitation(dead.to_text()))
        assert e.value.code == "invitation_invalid"
    wrong = m.PairRequest(token="guess" * 8, device_cert=__import__("aureom.domain.util", fromlist=["b64e"]).b64e(
        cara.identity.device.cert_der), endorsement=cara.identity.endorsement())
    assert outcome(cara, alice, wrong, paired=False) == "invitation_invalid"
    states = {i["invitation_id"]: i["state"] for i in alice.identity.invitations()}
    assert states[inv.invitation_id] == "confirmed" and states[expired.invitation_id] == "expired"


def test_unpaired_certificate_is_rejected_and_names_prove_nothing(make):
    """Cara claims Ben's device name; identity is the key, so it gets her nowhere."""
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    pair(alice, ben)
    cara.settings.set("device_name", ben.identity.device_name)
    cara.identity.upsert_peer(cert_der=alice.identity.device.cert_der, device_name="Alice", endorsement=None,
                              state="trusted", addresses=[addr(alice)])
    with pytest.raises(TransportError) as e:
        call(cara, cara.node.connect_peer(alice.identity.device_id))
    assert e.value.code == "not_trusted_by_peer"
    with pytest.raises(TransportError) as e:                              # and nobody can impersonate Alice to Ben
        call(ben, ben.node.connect_public(addr(cara), alice.identity.device_id))
    assert e.value.code == "fingerprint_mismatch"


# --------------------------------------------------------------- permissions
def test_catalogue_only_member_sees_titles_but_no_content_identifiers(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    cid, eds = share(alice, ben, [EPUB], permissions="catalogue-only")
    file_hash = alice.catalogue.primary_file(eds["the-lantern-archive.epub"])["content_hash"]
    payload = call(ben, ask(ben, alice, m.GetCollection(collection_id=cid)))["collection"]
    assert payload["items"][0]["metadata"]["title"] == "The Lantern Archive"
    assert "file_hash" not in payload["items"][0]["files"][0] and file_hash not in str(payload)
    view = ben.catalogue.list()[0]
    with pytest.raises(PermissionDenied) as e:
        ben.node.download_edition(view["edition_id"])
    assert e.value.code == "no_download_permission"
    _, manifest, chunk = file_requests(cid, file_hash)                    # even knowing the hash does not help
    assert outcome(ben, alice, manifest) == outcome(ben, alice, chunk) == "not_found_or_forbidden"
    with pytest.raises(PermissionDenied):
        call(ben, ben.node.propose_item(cid, view["edition_id"]))


def test_reader_can_download_but_not_contribute_edit_or_manage(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    cid, _ = share(alice, ben, [EPUB])
    eid, t = fetch(ben, "Lantern")
    assert t["state"] == "completed" and ben.catalogue.edition_view(eid)["availability"] == "local"
    own = ben.catalogue.import_file(PDF).edition_id
    for op, payload in (("add_item", {"edition_id": own, "file": {"file_hash": "0" * 64}}),
                        ("update_collection", {"name": "Hijacked"}),
                        ("share_annotation", {"annotation_id": "a1", "kind": "note", "edition_id": eid}),
                        ("set_member", {"account_id": ben.identity.account_id, "permissions": ["manage_members"]}),
                        ("revoke_member", {"account_id": ben.identity.account_id})):
        assert outcome(ben, alice, m.Propose(collection_id=cid, op=op, payload=payload)) == "not_found_or_forbidden", op
    assert alice.collections.get(cid)["name"] == "Circle"


def test_contributor_proposals_wait_for_the_owner_and_shared_annotations_are_explicit(make):
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    cid, eds = share(alice, ben, [EPUB], permissions="contributor")
    own = ben.catalogue.import_file(PDF).edition_id
    assert call(ben, ben.node.propose_item(cid, own))["state"] == "proposed"
    proposal = alice.pending_proposals()[0]
    assert proposal["title"] == "Field Notes on Tidal Catalogues" and alice.transfers.list() == []     # nothing fetched yet
    assert not alice.store.has(ben.catalogue.primary_file(own)["content_hash"])
    t = wait_transfer(alice, alice.node.accept_proposal(cid, own))
    assert t["state"] == "completed" and alice.catalogue.edition_view(own)["availability"] == "local"
    assert own in alice.collections.item_ids(cid)
    # annotations: private unless explicitly shared
    eid, _ = fetch(ben, "Lantern")
    private = ben.annotations.create(eid, "note", {"quote": "Every library begins"}, "Ben's private thought")
    shared = ben.annotations.create(eid, "note", {"quote": "Compare the fingerprints aloud."}, "Ben's shared remark")
    call(ben, ben.node.share_annotation(shared["annotation_id"], cid))
    seen = alice.collections.get(cid)["shared_annotations"]
    assert [a["body"] for a in seen] == ["Ben's shared remark"] and seen[0]["author_account"] == ben.identity.account_id
    pair(alice, cara, "collection", collection_id=cid, permissions="reader")
    text = str(call(cara, ask(cara, alice, m.GetCollection(collection_id=cid))))
    assert "Ben's shared remark" in text and "private thought" not in text
    assert ben.annotations.get(private["annotation_id"])["private"]
    call(ben, ben.node.share_annotation(shared["annotation_id"], ""))     # un-share
    assert alice.collections.get(cid)["shared_annotations"] == []


def test_editor_changes_detect_a_stale_base_and_managers_cannot_escalate(make):
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    cid, _ = share(alice, ben, [EPUB], permissions="manager")
    pair(alice, cara)
    call(ben, ben.node.propose_collection_update(cid, name="Lantern circle"))
    assert alice.collections.get(cid)["name"] == "Lantern circle"
    stale = m.Propose(collection_id=cid, op="update_collection", payload={"name": "Overwrite"}, base="2020-01-01T00:00:00Z")
    assert outcome(ben, alice, stale) == "conflict" and alice.collections.get(cid)["name"] == "Lantern circle"
    grant = lambda perms: m.Propose(collection_id=cid, op="set_member",  # noqa: E731
                                    payload={"account_id": cara.identity.account_id, "permissions": perms})
    assert outcome(ben, alice, grant(["view_metadata", "redistribute"])) == "not_found_or_forbidden"   # more than he holds
    assert outcome(ben, alice, grant(["view_metadata", "download"])) == "ALLOWED"
    assert alice.collections.permissions_of(cid, cara.identity.account_id, include_invited=True) == {"view_metadata", "download"}
    owner = m.Propose(collection_id=cid, op="revoke_member", payload={"account_id": alice.identity.account_id})
    assert outcome(ben, alice, owner) == "not_found_or_forbidden"         # the owner cannot be removed
    revoke = m.Propose(collection_id=cid, op="revoke_member", payload={"account_id": cara.identity.account_id})
    assert outcome(ben, alice, revoke) == "ALLOWED"
    assert alice.collections.permissions_of(cid, cara.identity.account_id, include_invited=True) == set()


def test_no_onward_redistribution_by_default(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    cid, _ = share(alice, ben, [EPUB])
    eid, _ = fetch(ben, "Lantern")
    mine = ben.collections.create("Ben's own circle")["collection_id"]
    with pytest.raises(PermissionDenied) as e:
        ben.collections.add_item(mine, eid)
    assert e.value.code == "no_redistribution"
    with pytest.raises(PermissionDenied) as e:
        ben.publishing.create_draft(eid)
    assert e.value.code == "no_redistribution"
    assert alice.collections.exposure_preview(cid, "reader")["redistribution"] is False
    alice.collections.set_permissions(cid, ben.identity.account_id, ["view_metadata", "download", "redistribute"])
    call(ben, ben.node.refresh_collection(cid))
    ben.collections.add_item(mine, eid)                                    # allowed only once explicitly granted


# ------------------------------------------------------------------ isolation
def test_private_details_never_leave_the_owner(make):
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    cid, eds = share(alice, ben, [EPUB])
    secret = alice.catalogue.import_file(MANUSCRIPT).edition_id
    alice.collections.create("Unrelated secret shelf", kind="local")
    alice.catalogue.update_user_metadata(eds["the-lantern-archive.epub"], {"tags": ["my-private-tag"]})
    alice.annotations.create(eds["the-lantern-archive.epub"], "note", {"quote": "Every library"}, "Alice's private note")
    payload = str(call(ben, ask(ben, alice, m.GetCollection(collection_id=cid))))
    for leak in ("my-private-tag", "private note", "Unrelated secret shelf", "working manuscript", "file:", "import_source",
                 alice.catalogue.primary_file(secret)["content_hash"]):
        assert leak not in payload, leak
    listed = call(ben, ask(ben, alice, m.ListShared()))["collections"]
    assert [c["name"] for c in listed] == ["Circle"]
    pair(alice, cara)
    assert call(cara, ask(cara, alice, m.ListShared()))["collections"] == []
    assert call(cara, cara.node.fetch_public_catalogue(addr(alice)))["publications"] == []
    preview = alice.collections.exposure_preview(cid, "reader")
    assert [t["title"] for t in preview["titles"]] == ["The Lantern Archive"] and "tags" not in preview["metadata_fields"]


# ----------------------------------------------------------------- revocation
def test_revocation_stops_future_access_but_not_existing_copies(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    cid, eds = share(alice, ben, [EPUB, MANUSCRIPT])
    kept, _ = fetch(ben, "Lantern")
    other = next(v for v in ben.catalogue.list() if "Tidewater" in v["title"])
    file_hash = alice.catalogue.primary_file(eds["tidewater-letters-manuscript.md"])["content_hash"]
    version = alice.collections.get(cid)["permission_version"]
    assert outcome(ben, alice, file_requests(cid, file_hash)[1]) == "ALLOWED"
    stale = m.GetManifest(scope=m.Scope(kind="collection", id=cid), file_hash=file_hash, known_version=version + 50)
    assert outcome(ben, alice, stale) == "stale_authority"                # an out-of-date authority refuses to serve

    result = alice.collections.revoke(cid, ben.identity.account_id)
    assert "cannot erase copies" in result["notice"] and result["permission_version"] > version
    for request in file_requests(cid, file_hash) + file_requests(cid, file_hash, version):     # old version number is no help
        assert outcome(ben, alice, request) == "not_found_or_forbidden"
    assert call(ben, ask(ben, alice, m.ListShared()))["collections"] == []
    with pytest.raises(PermissionDenied) as e:
        call(ben, ben.node.refresh_collection(cid))
    assert e.value.code == "access_revoked" and "already downloaded remain" in str(e.value)
    assert ben.collections.get(cid)["access_state"] == "revoked"
    assert ben.catalogue.edition_view(other["edition_id"])["availability"] == "unavailable"
    with pytest.raises(PermissionDenied):
        ben.node.download_edition(other["edition_id"])
    view = ben.catalogue.edition_view(kept)                                # the copy he already has is untouched
    assert view["availability"] == "local" and ben.catalogue.verify_file(ben.catalogue.primary_file(kept))
    assert ben.catalogue.read_bytes(ben.catalogue.primary_file(kept)) == EPUB.read_bytes()


def test_revocation_takes_effect_in_the_middle_of_a_transfer(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    cid, eds = share(alice, ben, [MANUSCRIPT])
    ben.identity.update_peer(alice.identity.device_id, bandwidth_kbps=480)
    view = ben.catalogue.list()[0]
    tid = ben.node.download_edition(view["edition_id"])
    wait_for(lambda: ben.transfers.get(tid)["chunks_done"] >= 3)
    alice.collections.revoke(cid, ben.identity.account_id)
    t = wait_transfer(ben, tid)
    assert t["state"] == "failed" and "revoked" in t["error"] and t["chunks_done"] < t["chunks_total"]
    assert not ben.store.has(view["content_hash"]) and ben.catalogue.edition_view(view["edition_id"])["availability"] != "local"


def test_deleting_a_collection_and_blocking_or_removing_a_device(make):
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    cid, eds = share(alice, ben, [EPUB])
    file_hash = alice.catalogue.primary_file(eds["the-lantern-archive.epub"])["content_hash"]
    pair(alice, cara, "collection", collection_id=cid)
    alice.identity.set_peer_state(cara.identity.device_id, "removed")      # device removal
    with pytest.raises(TransportError) as e:
        call(cara, ask(cara, alice, m.Ping()))
    assert e.value.code == "not_trusted_by_peer"
    alice.collections.delete(cid)
    assert all(outcome(ben, alice, r) == "not_found_or_forbidden" for r in file_requests(cid, file_hash))
    alice.identity.block_account(ben.identity.account_id)
    with pytest.raises(TransportError):
        call(ben, ask(ben, alice, m.Ping()))
    with pytest.raises(CommonsError):                                      # a blocked account cannot simply pair again
        pair(alice, ben)
    assert alice.identity.peer(ben.identity.device_id)["state"] == "blocked"
