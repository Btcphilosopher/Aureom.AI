"""The loopback API exposes the same facade, behind a bearer token."""
import pytest
from fastapi.testclient import TestClient

from aureom.apps.local_api.app import create_app
from tests.conftest import EPUB, MANUSCRIPT


@pytest.fixture
def api(make):
    ctx = make("alice")
    with TestClient(create_app(ctx, "s3cret-token")) as client:
        client.headers["Authorization"] = "Bearer s3cret-token"
        yield client, ctx


def test_token_is_required(api):
    client, _ = api
    for headers in ({"Authorization": ""}, {"Authorization": "Bearer wrong"}, {"Authorization": "s3cret-token"}):
        assert client.get("/status", headers=headers).status_code == 401
    assert client.get("/status").json()["network"]["mode"] in ("direct", "offline")


def test_import_search_annotate_and_error_mapping(api):
    client, ctx = api
    results = client.post("/library/import", json={"paths": [str(EPUB), str(MANUSCRIPT), "/no/such/file"]}).json()
    assert sorted(r["status"] for r in results) == ["failed", "imported", "imported"]
    eid = next(r["edition_id"] for r in results if r["name"].endswith(".epub"))
    assert client.get("/library", params={"q": "fingerprint wax"}).json()[0]["edition_id"] == eid
    assert client.get("/library", params={"space": "public"}).json() == []
    assert client.patch(f"/editions/{eid}/metadata", json={"tags": ["essays"]}).json()["tags"] == ["essays"]
    note = client.post(f"/editions/{eid}/annotations", json={"kind": "note", "body": "hello", "locator": {"page": 1}}).json()
    assert note["private"] and client.get(f"/editions/{eid}/annotations").json()[0]["body"] == "hello"
    assert client.get(f"/editions/{eid}/text").json()["hash_verified"] is True
    assert client.get("/editions/does-not-exist").status_code == 404
    assert client.patch(f"/editions/{eid}/metadata", json={"bogus": 1}).status_code == 422
    assert client.patch("/settings/limits", json={"chunk_size": 5}).status_code == 422
    assert client.patch("/settings", json={"no_such_setting": 1}).status_code == 422
    draft = client.post("/publications", json={"edition_id": eid}).json()
    assert client.post(f"/publications/{draft['publication_id']}/publish",
                       json={"disclosure_digest": "x", "confirm": True}).status_code == 409
    assert client.post("/debug/corrupt-chunk", json={}).status_code == 404        # fault injection is off by default
    home = client.get("/home").json()
    assert len(home["publication_drafts"]) == 1 and client.get("/protection").json()["encrypted_library"] is False
