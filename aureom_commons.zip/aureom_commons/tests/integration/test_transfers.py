"""Chunked transfers: integrity, interruption, resume, limits, multi-source."""
import pytest

from aureom.node import Profile
from tests.conftest import FIRST, MANUSCRIPT, call, files_containing, pair, share, wait_for, wait_transfer
from tests.integration.test_private_sharing import addr
from tests.unit.test_reading_annotations_publishing import _published


def start_download(member, slow_kbps: int = 0, owner=None):
    if slow_kbps:
        member.identity.update_peer(owner.identity.device_id, bandwidth_kbps=slow_kbps)
    view = member.catalogue.list()[0]
    return view, member.node.download_edition(view["edition_id"])


def part_files(ctx):
    folder = ctx.store.tmp / "transfers"
    return sorted(p.name for p in folder.iterdir()) if folder.exists() else []


def test_corrupted_chunk_is_rejected_and_refetched(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    share(alice, ben, [MANUSCRIPT])
    view = ben.catalogue.list()[0]
    alice.node.server.faults[(view["content_hash"], 5)] = 1
    alice.node.server.faults[(view["content_hash"], 31)] = 2
    t = wait_transfer(ben, ben.node.download_edition(view["edition_id"]))
    assert t["state"] == "completed" and t["corrupt_chunks"] == 3 and t["chunks_total"] == 32
    assert ben.store.verify(view["content_hash"])
    assert ben.catalogue.read_bytes(ben.catalogue.primary_file(view["edition_id"])) == MANUSCRIPT.read_bytes()
    kinds = [a["kind"] for a in ben.activity.recent(50)]
    assert kinds.count("transfer.chunk_rejected") == 3 and "transfer.completed" in kinds
    assert ben.catalogue.list("harbourmaster")                          # indexed only after verification
    assert part_files(ben) == []                                        # temporary storage cleaned up


def test_persistently_corrupt_source_never_gets_bad_bytes_into_the_library(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    share(alice, ben, [MANUSCRIPT])
    view = ben.catalogue.list()[0]
    alice.node.server.faults[(view["content_hash"], 0)] = 10_000
    t = wait_transfer(ben, ben.node.download_edition(view["edition_id"]), timeout=90)
    assert t["state"] == "failed" and t["corrupt_chunks"] >= 3
    assert not ben.store.has(view["content_hash"])
    assert ben.catalogue.edition_view(view["edition_id"])["availability"] == "peer"
    assert "transfer.source_dropped" in [a["kind"] for a in ben.activity.recent(80)]


def test_interrupted_transfer_resumes_from_saved_chunks(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    share(alice, ben, [MANUSCRIPT])
    view, tid = start_download(ben, 640, alice)
    wait_for(lambda: ben.transfers.get(tid)["chunks_done"] >= 6)
    call(alice, alice.node.stop_network())                              # the source disappears
    t = wait_transfer(ben, tid, until=("retrying",))
    held = t["chunks_done"]
    assert 6 <= held < t["chunks_total"] and "retrying" in t["error"].lower()
    assert not ben.store.has(view["content_hash"])                      # nothing promoted while incomplete
    call(alice, alice.node.start_network())
    ben.identity.update_peer(alice.identity.device_id, bandwidth_kbps=0)
    low = held
    while (t := ben.transfers.get(tid))["state"] not in ("completed", "failed"):
        low = min(low, t["chunks_done"] or held)
    assert t["state"] == "completed" and low >= held                    # never restarted from zero
    assert ben.transfers.get(tid)["retries"] >= 1 and ben.store.verify(view["content_hash"])


def test_pause_resume_and_cancel(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    share(alice, ben, [MANUSCRIPT])
    view, tid = start_download(ben, 640, alice)
    wait_for(lambda: ben.transfers.get(tid)["chunks_done"] >= 3)
    ben.transfers.pause(tid)
    t = wait_transfer(ben, tid, until=("paused",))
    held = t["chunks_done"]
    assert part_files(ben) == [f"{tid}.part"]
    ben.transfers.resume(tid)
    wait_for(lambda: ben.transfers.get(tid)["chunks_done"] > held)
    ben.transfers.cancel(tid)
    assert wait_transfer(ben, tid)["state"] == "cancelled"
    assert part_files(ben) == [] and not ben.store.has(view["content_hash"])
    ben.identity.update_peer(alice.identity.device_id, bandwidth_kbps=0)
    assert wait_transfer(ben, ben.node.download_edition(view["edition_id"]))["state"] == "completed"


def test_transfer_survives_closing_and_reopening_the_encrypted_library(make, tmp_path):
    """Progress is durable, and a partial download in an encrypted library is not plaintext on disk."""
    alice = make("alice", start=True)
    ben = make("ben", start=True, passphrase="ben's passphrase")
    share(alice, ben, [MANUSCRIPT])
    view, tid = start_download(ben, 640, alice)
    wait_for(lambda: ben.transfers.get(tid)["chunks_done"] >= 5)
    ben.transfers.pause(tid)
    held = wait_transfer(ben, tid, until=("paused",))["chunks_done"]
    ben.close()
    assert (tmp_path / "ben" / "tmp" / "transfers" / f"{tid}.part").stat().st_size > 5 * 16384
    for phrase in (b"harbourmaster", b"Letter 1", b"Tidewater"):
        assert files_containing(tmp_path / "ben", phrase) == []
    again = Profile.open(tmp_path / "ben", "ben's passphrase")
    try:
        again.node.start_background()
        assert again.transfers.get(tid)["state"] == "paused" and again.transfers.get(tid)["chunks_done"] == held
        again.identity.update_peer(alice.identity.device_id, bandwidth_kbps=0)
        again.transfers.resume(tid)
        assert wait_transfer(again, tid)["state"] == "completed" and again.store.verify(view["content_hash"])
    finally:
        again.close()


@pytest.mark.parametrize("limits,needle", [
    ({"max_chunks": 8}, "too many chunks"), ({"max_manifest_bytes": 1024}, "manifest exceeds"),
    ({"max_document_bytes": 100_000}, "document size limit"),
])
def test_oversized_manifests_are_refused_before_any_chunk_is_fetched(make, limits, needle):
    alice, ben = make("alice", start=True), make("ben", start=True, **limits)
    share(alice, ben, [MANUSCRIPT])
    view, tid = start_download(ben)
    t = wait_transfer(ben, tid)
    assert t["state"] == "failed" and needle in t["error"] and t["bytes_done"] == 0
    assert part_files(ben) == [] and not ben.store.has(view["content_hash"])


def test_manifest_for_a_different_file_is_refused(make, monkeypatch):
    """A serving peer that answers with another file's manifest is caught immediately."""
    alice, ben = make("alice", start=True), make("ben", start=True)
    share(alice, ben, [MANUSCRIPT])
    decoy = alice.catalogue.import_file(FIRST)
    decoy_manifest = alice.manifest_for(alice.catalogue.primary_file(decoy.edition_id))
    monkeypatch.setattr(alice, "manifest_for", lambda file: decoy_manifest)
    view, tid = start_download(ben)
    t = wait_transfer(ben, tid)
    assert t["state"] == "failed" and "different file" in t["error"] and part_files(ben) == []


def test_public_download_uses_several_sources_and_survives_a_corrupt_one(make):
    alice, cara, dave = (make(n, start=True) for n in ("alice", "cara", "dave"))
    pub, _ = _published(alice)
    pid, file_hash = pub["publication_id"], pub["manifest"]["files"][0]["file_hash"]
    call(cara, cara.node.fetch_public_catalogue(addr(alice)))
    assert all(wait_transfer(cara, t)["state"] == "completed" for t in cara.node.download_publication(pid))
    cara.publishing.set_mirror(pid, True)                               # Cara opts in to re-serving the signed edition
    for source in (alice, cara):
        listing = call(dave, dave.node.fetch_public_catalogue(addr(source)))
        assert listing["publications"][0]["check"]["signature_valid"]
    assert len(dave.publishing.remote_manifest(pid)[1]) == 2
    for index in range(15):
        alice.node.server.faults[(file_hash, index)] = 10_000           # Alice's copy has gone bad
    tids = dave.node.download_publication(pid)
    assert all(wait_transfer(dave, t, timeout=90)["state"] == "completed" for t in tids)
    assert dave.store.verify(file_hash) and dave.transfers.get(tids[0])["corrupt_chunks"] >= 1
    assert dave.catalogue.list(space="public")[0]["title"] == "Tidewater Letters"


def test_nothing_can_be_pushed_to_a_peer_uninvited(make):
    """Transfers are pull-only: pairing with someone gives them no way to make this device download or store anything."""
    alice, ben = make("alice", start=True), make("ben", start=True)
    pair(alice, ben)
    ben.catalogue.import_file(MANUSCRIPT)
    assert alice.transfers.list() == [] and alice.store.usage_bytes() == 0 and alice.catalogue.list() == []
    assert alice.pending_proposals() == []
