"""Opt-in local discovery: beacons are hints, never trust."""
import json

from aureom.transport.discovery import LanDiscovery
from tests.conftest import call, pair, wait_for


def test_beacons_are_validated_and_contain_no_private_data():
    me, other = "a" * 52, "b" * 52
    d = LanDiscovery(me, 4000)
    beacon = json.loads(d.beacon())
    assert set(beacon) == {"app", "v", "device_id", "port"}              # no name unless opted in, never titles
    assert "name" in json.loads(LanDiscovery(me, 4000, "Alice's laptop").beacon())
    good = json.dumps({"app": "aureom-commons", "v": 1, "device_id": other, "port": 5000, "name": "x‮evil"}).encode()
    for junk in (b"", b"{", b"x" * 600, d.beacon(), json.dumps({"app": "other", "v": 1, "device_id": other, "port": 1}).encode(),
                 json.dumps({"app": "aureom-commons", "v": 1, "device_id": "short", "port": 1}).encode(),
                 json.dumps({"app": "aureom-commons", "v": 1, "device_id": other, "port": 99999}).encode()):
        d._received(junk, ("10.0.0.9", 1))
    assert d.devices() == []
    d._received(good, ("10.0.0.9", 1))
    assert d.devices()[0]["address"] == "10.0.0.9:5000" and d.devices()[0]["name"] == "xevil"   # bidi override stripped
    for i in range(500):                                                 # flooding cannot grow the table without bound
        d._received(json.dumps({"app": "aureom-commons", "v": 1, "device_id": f"{i:052d}", "port": 5000}).encode(), ("10.0.0.9", 1))
    assert len(d.seen) <= 200


def test_discovery_is_off_by_default_and_discovered_devices_are_not_trusted(make):
    alice, ben = make("alice"), make("ben")
    assert alice.settings.get("lan_discovery") is False
    alice.settings.set("listen_host", "0.0.0.0")                         # reachable at the address beacons come from
    for ctx in (alice, ben):
        ctx.settings.set("lan_discovery", True)
        ctx.settings.set("_lan_interval", 0.2)
        ctx.node.start_background()
    assert alice.node.status()["lan_discovery"]
    try:
        wait_for(lambda: alice.node.discovered() and ben.node.discovered(), timeout=6)
    except AssertionError:
        import pytest

        pytest.skip("multicast is not available in this environment")
    seen = alice.node.discovered()[0]
    assert seen["device_id"] == ben.identity.device_id and seen["paired"] is False and "Unverified" in seen["note"]
    assert alice.identity.peers() == []                                  # seeing a beacon grants nothing
    pair(alice, ben)
    ben.identity.update_peer(alice.identity.device_id, addresses=[])     # only the beacon tells Ben where Alice is
    from aureom.protocol import messages as m
    from tests.integration.test_private_sharing import ask

    assert call(ben, ask(ben, alice, m.Ping())) == {}                    # hint used; identity still checked by pin
