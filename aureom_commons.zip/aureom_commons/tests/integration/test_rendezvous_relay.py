"""Optional extensions: relay (end-to-end encrypted through it) and rendezvous index."""
import asyncio
import json
import socket
import threading
import time

import httpx
import pytest
import uvicorn

from aureom.apps.rendezvous.app import create_app
from aureom.apps.rendezvous.relay import RelayService
from aureom.domain.errors import CommonsError, TransportError
from aureom.transport.relay import relay_dial
from aureom.transport.rendezvous import signed_envelope
from tests.conftest import MANUSCRIPT, call, pair, share, wait_for, wait_transfer
from tests.unit.test_reading_annotations_publishing import _published


def test_transfer_through_relay_is_end_to_end_encrypted(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    seen = bytearray()                                                   # everything a relay operator could capture
    relay = RelayService(record=seen)
    relay_addr = f"127.0.0.1:{call(alice, relay.start())}"
    for ctx in (alice, ben):
        ctx.settings.set("relay_address", relay_addr)
        call(ctx, ctx.node.stop_network())
        call(ctx, ctx.node.start_network())
    wait_for(lambda: alice.node.status()["relay_connected"] and ben.node.status()["relay_connected"])
    cid, _ = share(alice, ben, [MANUSCRIPT])
    ben.identity.update_peer(alice.identity.device_id, addresses=["127.0.0.1:9"])     # no direct route any more
    view = ben.catalogue.list()[0]
    t = wait_transfer(ben, ben.node.download_edition(view["edition_id"]))
    assert t["state"] == "completed" and ben.store.verify(view["content_hash"])
    status = ben.node.status()
    assert status["mode"] == "relay" and "end-to-end encrypted" in status["detail"]
    assert ben.identity.peer(alice.identity.device_id)["last_path"] == "relay"
    assert alice.identity.peer(ben.identity.device_id)["last_path"] == "relay"
    assert len(seen) > 513_000 and relay.stats["sessions"] >= 1
    for secret in (b"harbourmaster", b"Tidewater", view["content_hash"].encode(), cid.encode(), b"Circle", b'"t":'):
        assert secret not in seen, secret                                # the relay saw only ciphertext
    with pytest.raises(TransportError) as e:                             # dialling someone who is not registered
        call(ben, relay_dial(relay_addr, ben.identity.device, "a" * 52))
    assert e.value.code == "peer_offline"

    async def forged_registration():
        reader, writer = await asyncio.open_connection("127.0.0.1", relay.port)
        from aureom.domain.util import b64e

        writer.write(json.dumps({"op": "hello", "role": "listen", "device_id": alice.identity.device_id,
                                 "public_key": b64e(alice.identity.device.public_raw)}).encode() + b"\n")
        await reader.readline()
        writer.write(json.dumps({"signature": b64e(b"\x00" * 64)}).encode() + b"\n")
        reply = json.loads(await reader.readline())
        writer.close()
        return reply

    assert call(ben, forged_registration()) == {"ok": False, "error": "bad_signature"}
    call(alice, relay.stop())


@pytest.fixture
def rendezvous(tmp_path):
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    app = create_app(str(tmp_path / "rv.sqlite"), operator_token="operator-secret")
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{port}"
    for _ in range(100):
        try:
            httpx.get(url + "/v1/info", timeout=1)
            break
        except httpx.HTTPError:
            time.sleep(0.05)
    yield url, tmp_path / "rv.sqlite"
    server.should_exit = True
    thread.join(5)


def test_rendezvous_index_lookup_reports_and_moderation(make, rendezvous):
    url, db_path = rendezvous
    alice, ben, cara = (make(n, start=True) for n in ("alice", "ben", "cara"))
    with pytest.raises(CommonsError):
        alice.node.rendezvous.search("")                                 # off unless configured (opt-in)
    for ctx in (alice, ben, cara):
        ctx.settings.set("rendezvous_url", url)
    share(alice, ben, [MANUSCRIPT])                                      # a private collection that must never leak
    pub, _ = _published(alice)
    pid = pub["publication_id"]
    assert alice.node.rendezvous.announce(pid)["listed"]
    found = cara.node.rendezvous.search("tidewater")["publications"]
    assert len(found) == 1 and found[0]["check"]["signature_valid"]
    assert wait_transfer(cara, cara.node.download_publication(pid)[0])["state"] == "completed"
    stored = db_path.read_bytes()
    for private in (b"working manuscript", b"Circle", b"harbourmaster"):
        assert private not in stored
    # address lookup: only devices the target named as contacts
    alice.node.rendezvous.register()
    assert ben.node.rendezvous.lookup(alice.identity.device_id) == alice.node.advertised_addresses()
    with pytest.raises(CommonsError):
        cara.node.rendezvous.lookup(alice.identity.device_id)
    # signed requests: tampering and replay are refused
    envelope = signed_envelope(cara.identity.device, "/v1/reports", {"publication_id": pid, "reason": "test"})
    assert httpx.post(url + "/v1/reports", json=envelope).status_code == 200
    assert httpx.post(url + "/v1/reports", json=envelope).status_code == 401                  # replay
    forged = signed_envelope(cara.identity.device, "/v1/reports", {"publication_id": pid, "reason": "a"})
    forged["body"]["reason"] = "b"
    assert httpx.post(url + "/v1/reports", json=forged).status_code == 401
    wrong_path = signed_envelope(cara.identity.device, "/v1/catalogue/withdraw", {"publication_id": pid})
    assert httpx.post(url + "/v1/reports", json=wrong_path).status_code == 401
    # moderation affects the index only
    assert httpx.get(url + "/v1/admin/reports").status_code == 403
    admin = {"X-Operator-Token": "operator-secret"}
    assert len(httpx.get(url + "/v1/admin/reports", headers=admin).json()) == 1
    assert httpx.post(url + "/v1/admin/delist", headers=admin, json={"publication_id": pid}).json()["delisted"]
    assert cara.node.rendezvous.search("tidewater")["publications"] == []
    with pytest.raises(CommonsError):
        alice.node.rendezvous.announce(pid)                              # cannot simply re-announce a delisted edition
    assert alice.publishing.get(pid)["state"] == "published"             # the publisher's own catalogue is unaffected
    assert cara.catalogue.list(space="public")[0]["availability"] == "local"
