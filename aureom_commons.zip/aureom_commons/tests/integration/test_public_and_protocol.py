"""Public catalogue, signature handling over the wire, protocol robustness, key rotation."""
import asyncio
import ssl
import struct

import pytest

from aureom.domain.errors import CommonsError, PermissionDenied, TransportError
from aureom.protocol import messages as m
from tests.conftest import CORRECTED, MANUSCRIPT, call, pair, share, wait_transfer
from tests.integration.test_private_sharing import addr, ask, outcome
from tests.unit.test_reading_annotations_publishing import RIGHTS, _published


def test_public_edition_is_discoverable_verifiable_and_private_works_are_not(make):
    alice, cara = make("alice", start=True), make("cara", start=True)
    alice.catalogue.import_file(MANUSCRIPT)
    assert call(cara, cara.node.fetch_public_catalogue(addr(alice)))["publications"] == []
    pub, _ = _published(alice)
    listing = call(cara, cara.node.fetch_public_catalogue(addr(alice), "", alice.identity.device_id))
    assert "matched the fingerprint" in listing["endpoint_note"] and len(listing["publications"]) == 1
    item = listing["publications"][0]
    assert item["check"]["signature_valid"] and not item["check"]["key_previously_pinned"]
    assert "working manuscript" not in str(listing)
    assert alice.identity.peers() == [] and cara.identity.peers() == []          # public reading needs no pairing
    tids = cara.node.download_publication(pub["publication_id"])
    assert all(wait_transfer(cara, t)["state"] == "completed" for t in tids)
    view = cara.catalogue.list(space="public")[0]
    assert view["origin"] == "public" and view["availability"] == "local" and view["metadata"]["publisher"] == "Saltmarsh Press"
    with pytest.raises(CommonsError):
        cara.publishing.create_draft(view["edition_id"])                         # cannot republish someone else's edition
    with pytest.raises(TransportError) as e:
        call(cara, cara.node.fetch_public_catalogue(addr(alice), "", cara.identity.device_id))
    assert e.value.code == "fingerprint_mismatch"                                # wrong expected endpoint key


def test_second_edition_is_linked_and_withdrawal_stops_distribution(make):
    alice, cara = make("alice", start=True), make("cara", start=True)
    first, _ = _published(alice)
    cara.identity.pin_publisher(first["manifest"]["publisher"]["key"], "Saltmarsh Press")
    draft = alice.publishing.create_revision(first["publication_id"], CORRECTED, label="Corrected edition", notes="Typos.")
    digest = alice.publishing.enter_preview(draft["publication_id"])["digest"]
    alice.publishing.submit_rights_review(draft["publication_id"], RIGHTS)
    second = alice.publishing.publish(draft["publication_id"], disclosure_digest=digest, confirm=True)
    listing = call(cara, cara.node.fetch_public_catalogue(addr(alice)))["publications"]
    by_number = {p["entry"]["edition_number"]: p for p in listing}
    assert by_number[1]["entry"]["superseded_by"] == second["publication_id"] and by_number[2]["entry"]["superseded_by"] == ""
    assert by_number[1]["entry"]["manifest_id"] != by_number[2]["entry"]["manifest_id"]
    assert all(p["check"]["key_previously_pinned"] for p in listing)
    alice.publishing.withdraw(first["publication_id"])
    assert len(call(cara, cara.node.fetch_public_catalogue(addr(alice)))["publications"]) == 1
    t = wait_transfer(cara, cara.node.download_publication(first["publication_id"])[0])
    assert t["state"] == "failed" and not cara.store.has(first["manifest"]["files"][0]["file_hash"])
    alice.settings.set("serve_public_catalogue", False)
    assert outcome(cara, alice, m.PublicCatalogue(), paired=False) == "not_found_or_forbidden"


def test_tampered_or_resigned_manifests_are_rejected_on_receipt(make):
    alice, cara = make("alice", start=True), make("cara")
    pub, _ = _published(alice)
    tampered = dict(pub["manifest"], title="A Different Book")
    with pytest.raises(PermissionDenied) as e:
        cara.publishing.record_remote("dev", "addr", tampered)
    assert e.value.code == "bad_signature" and cara.publishing.remote_list() == []
    unsigned = dict(pub["manifest"], signature=None, publisher=None)
    report = cara.publishing.record_remote("dev", "addr", unsigned)["check"]
    assert not report["signed"] and "not signed" in " ".join(report["statements"])
    with pytest.raises(CommonsError):
        cara.publishing.set_mirror(pub["publication_id"], True)                   # unsigned editions are not mirrored


def test_search_requests_from_peers_are_rate_limited(make):
    alice, cara = make("alice", start=True, search_requests_per_minute=3), make("cara", start=True)

    async def hammer():
        async with await cara.node.connect_public(addr(alice)) as session:
            codes = []
            for _ in range(6):
                try:
                    await session.request(m.PublicCatalogue(query="x"))
                    codes.append("ok")
                except CommonsError as exc:
                    codes.append(exc.code)
            return codes

    assert call(cara, hammer()) == ["ok"] * 3 + ["rate_limited"] * 3


def test_malformed_traffic_does_not_disturb_the_listener(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    pair(alice, ben)
    host, port = addr(alice).split(":")

    async def send(payloads, tls=True):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
        reader, writer = await asyncio.open_connection(host, int(port), ssl=ctx if tls else None)
        try:
            for p in payloads:
                writer.write(p)
            await writer.drain()
            return await asyncio.wait_for(reader.read(4096), 1.5)
        except (ConnectionError, ssl.SSLError, asyncio.TimeoutError):
            return b""
        finally:
            writer.close()

    frame = lambda body, kind=1: struct.pack(">IB", len(body) + 1, kind) + body  # noqa: E731
    hello = frame(b'{"t":"hello","versions":[1]}')
    cases = [[b"GET / HTTP/1.1\r\n\r\n"], [frame(b"{not json")], [struct.pack(">IB", 2 ** 31, 1)],
             [frame(b'{"t":"hello","versions":[99]}')], [hello, frame(b'{"t":"format_disk"}')],
             [hello, frame(b"\x00" * 100, kind=9)], [hello, frame(b'{"t":"ping","x":1}')], [b"\x00" * 3]]
    for payloads in cases:
        call(alice, send(payloads))
    call(alice, send([b"plaintext, not TLS at all\n"], tls=False))
    assert call(ben, ask(ben, alice, m.Ping())) == {}                             # still serving normally
    assert alice.identity.peers()[0]["state"] == "trusted" and alice.catalogue.list() == []


def test_device_key_rotation_is_accepted_only_from_the_old_key(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    cid, _ = share(alice, ben, [MANUSCRIPT])
    old_id = alice.identity.device_id
    alice.identity.rotate_device_key()
    new_id = alice.identity.device_id
    assert new_id != old_id and alice.identity.previous_device is not None
    assert call(alice, alice.node.announce_rotation()) == {"told": 1, "pending": 0}
    peer = ben.identity.peer(new_id)
    assert peer["rotated_from"] == old_id and peer["state"] == "trusted"
    assert ben.db.one("SELECT 1 FROM peers WHERE device_id=?", (old_id,)) is None
    assert alice.identity.previous_device is None                                 # grace period over: all peers updated
    assert ben.collections.get(cid)["owner_device"] == new_id
    view = ben.catalogue.list()[0]
    assert wait_transfer(ben, ben.node.download_edition(view["edition_id"]))["state"] == "completed"
    with pytest.raises(TransportError):                                           # the retired key no longer works
        call(ben, ben.node.connect_public(addr(alice), old_id))


def test_peer_learns_rotation_when_it_dials_the_old_identity(make):
    alice, ben = make("alice", start=True), make("ben", start=True)
    pair(alice, ben)
    old_id = alice.identity.device_id
    alice.identity.rotate_device_key()                                            # Alice has not reached Ben yet
    async def dial_known_key():
        async with await ben.node.connect_peer(old_id) as session:                # Ben dials the key he knows
            return await session.request(m.Ping())

    assert call(ben, dial_known_key()) == {}
    assert ben.identity.peer(alice.identity.device_id)["rotated_from"] == old_id  # …and learns the new one, signed by the old
    assert call(ben, ask(ben, alice, m.Ping())) == {}
