"""Shared fixtures.  Every test runs against real profiles on disk and — for
network tests — real TLS 1.3 connections over loopback.  Nothing is mocked."""
from __future__ import annotations

import os
import time
import zipfile
from pathlib import Path

import pytest

os.environ["AUREOM_DISABLE_KEYRING"] = "1"

from aureom.node import Profile  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
FIX = ROOT / "fixtures"
FAST_KDF = {"name": "scrypt", "n": 2 ** 10, "r": 8, "p": 1}       # tests only; the real default is 2**16
EPUB, MANUSCRIPT = FIX / "the-lantern-archive.epub", FIX / "tidewater-letters-manuscript.md"
FIRST, CORRECTED = FIX / "tidewater-letters-first-edition.md", FIX / "tidewater-letters-corrected-edition.md"
PDF = FIX / "field-notes-on-tidal-catalogues.pdf"
TERMINAL = ("completed", "failed", "cancelled")


@pytest.fixture
def make(tmp_path):
    """Factory for isolated profiles; everything is closed afterwards."""
    made = []

    def factory(name: str, *, passphrase: str | None = None, start: bool = False, **limits):
        ctx = Profile.create(tmp_path / name, device_name=f"{name}'s device", account_name=name,
                             passphrase=passphrase, kdf=FAST_KDF)
        ctx.settings.set_limits(chunk_size=16 * 1024, **limits)
        made.append(ctx)
        if start:
            ctx.node.start_background()
        return ctx

    yield factory
    for ctx in made:
        ctx.close()


def call(ctx, coro, timeout: float = 30.0):
    return ctx.node.call(coro, timeout)


def pair(inviter, joiner, purpose: str = "pair", **kw) -> None:
    invitation = inviter.node.create_invitation(purpose=purpose, **kw)
    call(joiner, joiner.node.accept_invitation(invitation.to_text()))


def share(owner, member, paths, permissions="reader"):
    """Owner imports ``paths`` into a new shared collection and invites ``member``.
    Returns ``(collection_id, {filename: owner_edition_id})``."""
    results = owner.catalogue.import_paths(paths)
    assert all(r.status == "imported" for r in results), results
    cid = owner.collections.create("Circle")["collection_id"]
    for r in results:
        owner.collections.add_item(cid, r.edition_id)
    pair(owner, member, "collection", collection_id=cid, permissions=permissions)
    return cid, {r.name: r.edition_id for r in results}


def wait_transfer(ctx, tid: str, until=TERMINAL, timeout: float = 40.0) -> dict:
    deadline = time.time() + timeout
    while time.time() < deadline:
        t = ctx.transfers.get(tid)
        if t["state"] in until:
            return t
        time.sleep(0.05)
    raise AssertionError(f"transfer stuck: {ctx.transfers.get(tid)}")


def wait_for(predicate, timeout: float = 20.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return
        time.sleep(0.05)
    raise AssertionError("condition not reached")


def files_containing(root: Path, needle: bytes) -> list[str]:
    return [str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and needle in p.read_bytes()]


def hostile_zip(path: Path, kind: str) -> Path:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        if kind == "bomb":
            z.writestr("mimetype", "application/epub+zip")
            z.writestr("big.xhtml", b"0" * (40 * 1024 * 1024))        # ~1000:1
        elif kind == "many":
            for i in range(6000):
                z.writestr(f"f{i}", b"")
        elif kind == "traversal":
            z.writestr("mimetype", "application/epub+zip")
            z.writestr("META-INF/container.xml", '<container><rootfiles><rootfile full-path="../../etc/passwd"/></rootfiles></container>')
            z.writestr("../../evil.txt", "x")
    return path
