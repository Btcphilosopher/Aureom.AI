# GrocerHQ — Enterprise Retail Platform

An integrated headquarters system for a large supermarket business: stores, a distribution centre,
suppliers, online retail and customer service, in one modular application.

> **Generic concept.** A brand-neutral headquarters platform for a multi-format grocery retailer. It is
> not modelled on, or connected to, any real company's systems, customer records or APIs. Every company,
> store, supplier, customer, employee, price and transaction in it is fictional.
> Loyalty rules are labelled demonstration policies and do not describe any real programme.

Generation model: Claude · Technology: Aureom.AI

## Screenshots

| | |
|---|---|
| ![Executive overview](docs/screenshots/02-executive-overview.png) | ![Price simulator](docs/screenshots/11-price-simulator.png) |
| ![Reorder recommendations](docs/screenshots/06-reorder-recommendations.png) | ![Route plans](docs/screenshots/08-route-plans.png) |

All 13 screenshots are in `docs/screenshots/`.

## What is in the box

| Path | Contents |
|---|---|
| `backend/` | Python 3.12 · FastAPI · SQLAlchemy 2 · PostgreSQL · Redis. Modular monolith: `app/domains/<domain>/{models,service,api}.py` |
| `backend/alembic/` | Schema migration (102 tables) plus database-level guarantees (immutable ledgers, balanced journals) |
| `backend/app/worker.py` | Background worker: outbox relay, price-publication confirmation, forecasts, imports, housekeeping |
| `backend/app/adapters/` | Integration boundaries (interfaces) and their simulators: payments, POS, scanners, tracking, POD, HR, supplier EDI, loyalty |
| `backend/app/seed/` | Fictional master data, 14 days of trading history, and the 12-step demonstration scenario |
| `backend/tests/` | 39 automated tests against a real PostgreSQL database |
| `frontend/` | React 18 · TypeScript · Tailwind headquarters console (15 workspaces + approvals inbox) |
| `docs/` | Architecture, ERD, API reference, demonstration walkthrough and transcript, known limitations |
| `docker-compose.yml` | PostgreSQL, Redis, MinIO (object storage), API, worker, web |

## Run it with Docker

Requires Docker with Compose v2.

```bash
docker compose up --build
```

First start runs the migration and loads the demonstration data (about a minute). Then open:

* Console — http://localhost:8080
* API documentation (OpenAPI / Swagger) — http://localhost:8000/docs
* Object-storage console (MinIO) — http://localhost:9001

Sign in with any demonstration user; the password for all of them is `demo1234`. The sign-in page lists
them. Useful ones:

| User | Sees |
|---|---|
| `exec@grocerhq.example` | Everything, read-only, all sites |
| `buyer@grocerhq.example` / `procurement.manager@grocerhq.example` | Raise purchase orders / approve them |
| `warehouse@grocerhq.example` | Goods receipt, warehouse queue, routes — distribution centre only |
| `pricing.analyst@grocerhq.example` / `pricing.manager@grocerhq.example` | Propose prices and promotions / approve and publish |
| `store.ashbourne@grocerhq.example` | One store: till, online picking, stock, rota |
| `finance.clerk@grocerhq.example` / `finance.controller@grocerhq.example` | Match invoices, request payments / approve payments |
| `service@grocerhq.example`, `loyalty@grocerhq.example`, `hr@grocerhq.example`, `auditor@grocerhq.example`, `admin@grocerhq.example`, `security@grocerhq.example` | Their function |

Other commands:

```bash
docker compose run --rm api pytest                     # run the test suite (uses the ghq_test database)
```

```bash
docker compose run --rm api python -m app.seed --reset # wipe and rebuild the demonstration data
```

```bash
docker compose down -v                                 # stop and delete all data
```

## Run it without Docker

Requires PostgreSQL 14+, Python 3.12+, Node 20+. Redis is optional (the cache and worker wake-up fail soft).

```bash
createuser ghq --pwprompt && createdb ghq -O ghq && createdb ghq_test -O ghq    # password: ghq
```

```bash
cd backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
```

```bash
export DATABASE_URL=postgresql+psycopg://ghq:ghq@localhost:5432/ghq REDIS_URL=redis://localhost:6379/0
alembic upgrade head && python -m app.seed
```

```bash
uvicorn app.main:app --port 8000        # terminal 1
```

```bash
python -m app.worker                    # terminal 2 (same environment variables)
```

```bash
cd frontend && npm ci && npm run dev    # terminal 3 → http://localhost:5173 (proxies /api to :8000)
```

```bash
cd backend && TEST_DATABASE_URL=postgresql+psycopg://ghq:ghq@localhost:5432/ghq_test pytest
```

Without `S3_ENDPOINT`, documents are stored in a local directory instead of object storage.

## Where to look first

1. **Executive Overview** — orders, completed sales, revenue, cash receipts, refunds, gross profit and
   inventory value as seven separate figures; each tile has *Definition* (formula, period, unit, source,
   numerator/denominator) and *View records* (the rows behind it). Actual, budget and forecast are
   separate series.
2. **Approvals & Exceptions** — the seeded scenario leaves purchase orders, a price change, a stock
   adjustment and a permission change waiting for a second person, and about sixty open exceptions.
3. **Pricing › Price simulator** — build a basket and read the rule trace that produced the total.
4. `docs/DEMO.md` — the 12-step walkthrough, with the console path for each step.

## Documentation

* `docs/ARCHITECTURE.md` — domain boundaries, consistency guarantees, permissions, metric definitions
* `docs/ERD.md` — entity-relationship diagrams (Mermaid), one per domain
* `docs/API.md` — versioned API reference and integration entry points
* `docs/DEMO.md` and `docs/DEMO_TRANSCRIPT.txt` — demonstration walkthrough and its recorded output
* `docs/LIMITATIONS.md` — what this is not, and what was and was not verified
