/** GrocerHQ palette: deep green navigation, orange primary actions, red reserved for exceptions, light-grey working surfaces. */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: "#1B6B4A", dark: "#134E36", deep: "#0C3A27", light: "#E7F2EC" },
        action: { DEFAULT: "#E8590C", dark: "#C2410C", light: "#FFF1E6" },
        alert: { DEFAULT: "#D92D20", dark: "#B42318", light: "#FEECEB" },
        surface: "#F2F4F6",
        ink: { DEFAULT: "#1B2733", soft: "#4A5A6A", mute: "#7A8896" },
        line: "#D8DEE4",
        ok: "#1F7A3D", warn: "#9A6200",
        series: { actual: "#00539F", budget: "#C26A00", forecast: "#00947F" },
      },
      fontFamily: { sans: ['"Inter"', "system-ui", "-apple-system", '"Segoe UI"', "Roboto", "Arial", "sans-serif"] },
    },
  },
  plugins: [],
};
